# -*- coding: utf-8 -*-
"""
語意向量快取：沒改的規章，段落文字一樣，BGE-M3 算出來的向量也一樣，下次直接拿。

存在 skill 資料夾的 memoization/語意向量.sqlite（一個檔，標準函式庫 sqlite3，不用另外裝東西；見 batch.cache_dir）。
鑰匙＝比對單位的正規化文字的 SHA-256（見 semantic_candidates._sentence_units），加上模型代號：
換了模型就是另一組向量，不混用。模型代號除了資料夾名稱，還帶模型內容的指紋（見 model_fingerprint）。

只存兩種：
    dense   語意向量（1024 個數，半精度存，一段約 2KB）
    sparse  關鍵詞權重（詞 → 權重，JSON）
不存 colbert 逐字向量：每字 1024 個數，一段動輒上百 KB，三百本規章要幾十 GB。
有快取時三分數合併改成「dense＋sparse 全排名（都從快取來）→ 前 RERANK_TOP 名才現算 colbert」，
見 semantic_candidates.HybridScorer。

刪掉這個檔不會出錯，只是下次要從頭算。
"""

import hashlib
import json
import os
import sqlite3
import struct

FILE = "語意向量.sqlite"


def text_key(text):
    return hashlib.sha256((text or "").encode("utf-8")).hexdigest()


def _pack(vec):
    # 單精度（一個數 4 bytes）。以前存半精度：第一輪用剛算的全精度、第二輪從快取拿半精度，
    # 分數差千分之幾，粗排前 N 名的邊界偶爾多一筆少一筆（審查 B5）。鍵加了 |f32，舊的半精度列不會被讀到
    values = [float(x) for x in vec]
    return struct.pack("<%df" % len(values), *values)


def _unpack(blob):
    return list(struct.unpack("<%df" % (len(blob) // 4), blob))


# 向量存法的版本：換存法就換鍵，舊列留著不讀（刪掉 語意向量.sqlite 可以清掉）
_VECTOR_FORMAT = "f32"


class VectorCache(object):
    """model_key：模型代號（資料夾名＋模型內容指紋＋分數方式），換模型不混用。"""

    def __init__(self, path, model_key):
        folder = os.path.dirname(os.path.abspath(path))
        if folder and not os.path.isdir(folder):
            os.makedirs(folder)
        self.path = path
        self.model_key = model_key
        self.db = sqlite3.connect(path)
        self.db.execute("CREATE TABLE IF NOT EXISTS vec (model TEXT, key TEXT, dense BLOB, sparse TEXT,"
                        " PRIMARY KEY (model, key))")
        self.hits = 0
        self.misses = 0

    def get_many(self, texts):
        """{文字: {"dense": [...], "sparse": {...} 或 None}}，只回有存的。"""
        keys = dict((text_key(t), t) for t in texts)
        out = {}
        items = list(keys.items())
        for start in range(0, len(items), 500):
            chunk = items[start:start + 500]
            marks = ",".join("?" * len(chunk))
            for key, dense, sparse in self.db.execute(
                    "SELECT key, dense, sparse FROM vec WHERE model=? AND key IN (%s)" % marks,
                    [self.model_key] + [k for k, _ in chunk]):
                out[keys[key]] = {"dense": _unpack(dense), "sparse": json.loads(sparse) if sparse else None}
        self.hits += len(out)
        self.misses += len(set(texts)) - len(out)
        return out

    def put_many(self, pairs):
        """pairs：[(文字, dense 向量, sparse 權重 dict 或 None)]。"""
        rows = [(self.model_key, text_key(t), _pack(d),
                 json.dumps(dict((str(k), float(v)) for k, v in s.items())) if s is not None else None)
                for t, d, s in pairs]
        if rows:
            self.db.executemany("INSERT OR REPLACE INTO vec VALUES (?, ?, ?, ?)", rows)
            self.db.commit()

    def close(self):
        self.db.close()


class PairCache(object):
    """重排序分數快取：（改動句, 候選整段）這一對，同一個重排序模型算出來的分數一樣，下次直接拿。
    跟向量放同一個 sqlite 檔、另一張表。"""

    def __init__(self, path, model_key):
        folder = os.path.dirname(os.path.abspath(path))
        if folder and not os.path.isdir(folder):
            os.makedirs(folder)
        self.path = path
        self.model_key = model_key
        self.db = sqlite3.connect(path)
        self.db.execute("CREATE TABLE IF NOT EXISTS pair (model TEXT, key TEXT, score REAL,"
                        " PRIMARY KEY (model, key))")
        self.hits = 0
        self.misses = 0

    @staticmethod
    def pair_key(query, passage):
        return text_key("%s\x00%s" % (query or "", passage or ""))

    def get_many(self, pairs):
        """{(改動句, 候選段): 分數}，只回有存的。"""
        keys = dict((self.pair_key(q, p), (q, p)) for q, p in pairs)
        out = {}
        items = list(keys.items())
        for start in range(0, len(items), 500):
            chunk = items[start:start + 500]
            marks = ",".join("?" * len(chunk))
            for key, score in self.db.execute(
                    "SELECT key, score FROM pair WHERE model=? AND key IN (%s)" % marks,
                    [self.model_key] + [k for k, _ in chunk]):
                out[keys[key]] = score
        self.hits += len(out)
        self.misses += len(keys) - len(out)
        return out

    def put_many(self, scored):
        """scored：[(改動句, 候選段, 分數)]。"""
        rows = [(self.model_key, self.pair_key(q, p), float(s)) for q, p, s in scored]
        if rows:
            self.db.executemany("INSERT OR REPLACE INTO pair VALUES (?, ?, ?)", rows)
            self.db.commit()

    def close(self):
        self.db.close()


# 模型指紋只看會影響算出來的向量的檔：權重、設定、分詞器。說明文件、圖片、版控資料夾
# 改了不影響向量，算進去只會讓快取白白作廢。
_FINGERPRINT_SKIP_EXT = (".md", ".png", ".jpg", ".jpeg", ".gif", ".svg")
_FINGERPRINT_SKIP_DIRS = (".git", ".cache", "__pycache__", ".huggingface")
# 大檔（權重動輒 2GB）不整份算 SHA：取頭、中、尾三段各 1MB。微調過的模型權重處處不同，
# 三段一定有差；整份讀一遍每一次開快取都要多花十幾秒，不值得。
_SAMPLE = 1024 * 1024
_fingerprints = {}


def _file_digest(path, size):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        if size <= 3 * _SAMPLE:
            h.update(f.read())
        else:
            for offset in (0, (size - _SAMPLE) // 2, size - _SAMPLE):
                f.seek(offset)
                h.update(f.read(_SAMPLE))
    return h.hexdigest()


def model_fingerprint(model_path):
    """模型資料夾內容的指紋（16 碼）；model_path 不是資料夾（模型名稱、路徑打錯）回 ""。

    以前快取鍵只用模型資料夾名稱：把另一個模型（微調版、換了版本的 bge-m3）放進同名資料夾，
    就會拿到舊模型算的向量，分數整批不對而且看不出來（第三批）。
    刻意不看修改時間：快取放在 skill 資料夾的 memoization/，會跟著 skill 複製到別台電腦，
    同一個模型複製過去修改時間可能變，只看時間會讓快取整批作廢。改看相對路徑＋大小＋內容取樣。"""
    folder = os.path.abspath(model_path or "")
    if not model_path or not os.path.isdir(folder):
        return ""
    if folder in _fingerprints:
        return _fingerprints[folder]
    h = hashlib.sha256()
    for root, dirs, files in os.walk(folder):
        dirs[:] = sorted(d for d in dirs if d not in _FINGERPRINT_SKIP_DIRS)
        for name in sorted(files):
            if name.startswith(".") or name.lower().endswith(_FINGERPRINT_SKIP_EXT):
                continue
            path = os.path.join(root, name)
            try:
                size = os.path.getsize(path)
                digest = _file_digest(path, size)
            except OSError:
                continue
            rel = os.path.relpath(path, folder).replace(os.sep, "/")
            h.update(("%s\0%d\0%s\n" % (rel, size, digest)).encode("utf-8"))
    _fingerprints[folder] = h.hexdigest()[:16]
    return _fingerprints[folder]


def open_cache(folder, model_path, mode):
    """folder 是 skill 資料夾的 memoization/（batch.cache_dir）；沒給回 None＝不用快取。

    舊版鍵（只有資料夾名＋分數方式）存的向量不會再被讀到：換版後第一次要重算一次。"""
    if not folder:
        return None
    name = os.path.basename(os.path.normpath(model_path or "")) or "model"
    fingerprint = model_fingerprint(model_path)
    key = "%s|%s|%s" % (name, fingerprint, mode) if fingerprint else "%s|%s" % (name, mode)
    if mode != "rerank":
        key += "|" + _VECTOR_FORMAT
    return (PairCache if mode == "rerank" else VectorCache)(os.path.join(folder, FILE), key)
