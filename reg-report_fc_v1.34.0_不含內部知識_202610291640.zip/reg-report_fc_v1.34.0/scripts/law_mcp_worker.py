# -*- coding: utf-8 -*-
"""選用 MCP SDK 的隔離工作程序。輸入／輸出各一個 JSON；不經 shell。"""
import asyncio
import json
import sys


async def call(payload):
    from mcp import ClientSession, StdioServerParameters
    from mcp.client.stdio import stdio_client
    command = payload["command"]
    async with stdio_client(StdioServerParameters(command=command[0], args=command[1:])) as (read, write):
        async with ClientSession(read, write) as session:
            await session.initialize()
            result = await session.call_tool(payload["tool"], payload["arguments"])
            if getattr(result, "isError", False):
                raise RuntimeError(str(result.content))
            value = getattr(result, "structuredContent", None)
            if value is not None:
                return value
            for item in result.content:
                if getattr(item, "type", "") == "text":
                    return json.loads(item.text)
            raise ValueError("MCP 沒有回傳 JSON")


async def session():
    from mcp import ClientSession, StdioServerParameters
    from mcp.client.stdio import stdio_client
    command = json.loads(sys.stdin.readline())["command"]
    async with stdio_client(StdioServerParameters(command=command[0], args=command[1:])) as (read, write):
        async with ClientSession(read, write) as client:
            await client.initialize()
            while True:
                line = await asyncio.to_thread(sys.stdin.readline)
                if not line:
                    return
                payload = json.loads(line)
                try:
                    result = await client.call_tool(payload["tool"], payload["arguments"])
                    if getattr(result, "isError", False):
                        raise RuntimeError(str(result.content))
                    value = getattr(result, "structuredContent", None)
                    if value is None:
                        value = next(json.loads(item.text) for item in result.content if getattr(item, "type", "") == "text")
                except Exception as exc:
                    value = {"error": "%s：%s" % (type(exc).__name__, exc)}
                print(json.dumps(value, ensure_ascii=False), flush=True)


if __name__ == "__main__":
    try:
        if "--session" in sys.argv:
            asyncio.run(session())
        else:
            print(json.dumps(asyncio.run(call(json.load(sys.stdin))), ensure_ascii=False))
    except Exception as exc:
        print(json.dumps({"error": "%s：%s" % (type(exc).__name__, exc)}, ensure_ascii=False), flush=True)
        sys.exit(1)
