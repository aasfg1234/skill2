# -*- coding: utf-8 -*-
"""
從 AI 判過的答案學東西（v1.20.0）：套語、同義詞建議。

一、套語（memoization/內部知識/套語.json）
    比對時 AI 判〔套語命中〕的候選：程式找出那一對（候選段、異動段）共同的那一截字
    （「陳報主管核定後辦理」），記下來、數判過幾次。下一次打包，候選跟異動共同的字只有這一截、
    而且以前判過兩次以上，就在那個候選區塊加一行提示，AI 一眼知道多半是套語。只提示、不刪候選。

二、同義詞建議（AI審查/AI同義詞建議.csv → 設定.html 資料區塊的「同義詞建議」）
    AI 審查時看到兩段講同一件事、用字不同（「帳戶」「帳號」），程式沒當成同義的，可以順手填這張表（選填）。
    匯入時寫進設定頁，人在「同義詞表」那一頁按「採用」才加進詞組。

都是本單位資料：打包分享時照使用者選擇決定要不要包。
"""

import csv
import datetime
import difflib
import io
import json
import os
import re

PHRASE_FILE = "套語.json"
PHRASE_MIN, PHRASE_MAX = 4, 40
PHRASE_HINT_TIMES = 2             # 判過幾次以上才提示
BOILER_LABEL = "套語命中"
SYN_TABLE = "AI同義詞建議.csv"
SYN_HEADER = ["代表詞", "其他寫法", "理由", "例子"]
SYN_KEY = "同義詞建議"
REFUSED_KEY = "同義詞已拒絕"
SKIP_ENV = "REG_NO_ANSWER_BANK"       # 測試用：跟 AI 答案庫同一個開關（舊測試共用快取資料夾）
_PUNCT = re.compile(r"[\s，。、；：「」（）()《》,.;:]+")


def _folder():
    import precedents as pc
    return pc.folder()


def _read_json(name, default):
    import precedents as pc
    return pc.read_json(os.path.join(_folder(), name), default)     # BOM 也收；壞檔改名留著


def _write_json(name, value):
    os.makedirs(_folder(), exist_ok=True)
    path = os.path.join(_folder(), name)
    with io.open(path + ".tmp", "w", encoding="utf-8") as f:
        json.dump(value, f, ensure_ascii=False, indent=1)
    os.replace(path + ".tmp", path)


# ---------------------------------------------------------------------------
# 套語
# ---------------------------------------------------------------------------

def common_phrase(a, b):
    """兩段共同最長的那一截（去掉標點、空白比）；太短回 ""。"""
    a, b = _PUNCT.sub("", a or ""), _PUNCT.sub("", b or "")
    if not a or not b:
        return ""
    m = difflib.SequenceMatcher(None, a, b, autojunk=False).find_longest_match(0, len(a), 0, len(b))
    return a[m.a:m.a + m.size][:PHRASE_MAX] if m.size >= PHRASE_MIN else ""


def _change_texts(row, book):
    import review_pack as rp
    texts = []
    try:
        for _name, change in rp.changes_for_row(row, book):
            texts += [change.get("new_text") or "", change.get("old_text") or ""]
    except Exception:
        pass
    return [t for t in texts if t]


def learn_boilerplate(rows, ai_rows, book):
    """匯入一本之後：AI 判〔套語命中〕的候選，記下候選跟異動共同的那一截。回傳記了幾則。"""
    from _common import tw_now, tw_today
    if os.environ.get(SKIP_ENV) == "1":
        return 0
    table = _read_json(PHRASE_FILE, {})
    today = tw_today().isoformat()
    added = 0
    for ai in ai_rows or []:
        if BOILER_LABEL not in (ai.get("AI理由") or "")[:12]:
            continue
        rid = (ai.get("列ID") or "").strip()
        if not rid.startswith("R") or not rid[1:].isdigit() or int(rid[1:]) > len(rows):
            continue
        row = rows[int(rid[1:]) - 1]
        best = ""
        for text in _change_texts(row, book):
            phrase = common_phrase(row.get("候選全文") or "", text)
            best = phrase if len(phrase) > len(best) else best
        sha = (ai.get("審查內容SHA256") or rid).strip()
        if best:
            # v1.22.0：照列指紋去重——同一列重匯、每一輪沿用來的同一個答案只算一次（以前一次判斷重匯兩次就湊滿門檻）
            entry = table.setdefault(best, {"次數": 0, "第一次": today})
            seen = entry.setdefault("指紋", [])
            if sha in seen:
                continue
            seen.append(sha)
            entry["指紋"] = seen[-50:]
            entry["次數"] += 1
            entry["最後一次"] = today
            added += 1
    if added:
        _write_json(PHRASE_FILE, table)
    return added


def boilerplate_hint(row, book, table=None):
    """打包候選區塊時：候選跟異動共同的字只有一句學過的套語，回一行提示；不是就回 ""。"""
    table = _read_json(PHRASE_FILE, {}) if table is None else table
    if not table:
        return ""
    best = ""
    for text in _change_texts(row, book):
        phrase = common_phrase(row.get("候選全文") or "", text)
        best = phrase if len(phrase) > len(best) else best
    if not best:
        return ""
    for phrase, entry in table.items():
        if (entry or {}).get("次數", 0) >= PHRASE_HINT_TIMES and (best in phrase or phrase in best) \
                and len(best) <= len(phrase) + 4:
            return ("（提示：這個候選跟異動最長的共同字是「%s」，本單位以前判過 %d 次〔套語命中〕。"
                    "先看候選有沒有異動的舊值、是不是同一件義務；內容真的有關照常給分）" % (phrase, entry["次數"]))
    return ""


_phrase_cache = {}


def phrases():
    """學過的套語（檔案沒變就不重讀：打包時每個候選都要看一次）。"""
    if os.environ.get(SKIP_ENV) == "1":
        return {}
    path = os.path.join(_folder(), PHRASE_FILE)
    try:
        stamp = os.stat(path).st_mtime_ns
    except OSError:
        return {}
    hit = _phrase_cache.get(path)
    if not hit or hit[0] != stamp:
        hit = _phrase_cache[path] = (stamp, _read_json(PHRASE_FILE, {}))
    return hit[1]


# ---------------------------------------------------------------------------
# 同義詞建議
# ---------------------------------------------------------------------------

def synonym_table(root):
    import ai_tables
    return os.path.join(ai_tables.folder(root), SYN_TABLE)


def ensure_synonym_template(root):
    path = synonym_table(root)
    if not os.path.isfile(path):
        os.makedirs(os.path.dirname(path), exist_ok=True)
        with io.open(path, "w", encoding="utf-8-sig", newline="") as f:
            csv.writer(f, quoting=csv.QUOTE_ALL).writerow(SYN_HEADER)
    return path


def synonym_readme_lines():
    return ["", "## 同義詞建議（選填）", "",
            "審查時看到兩段講同一件事、只是用字不同（例：「帳戶」與「帳號」、「核保」與「承保作業」），"
            "而程式沒有把它們配成候選的，可以在 `%s` 加一列：代表詞、其他寫法（頓號分隔）、理由、例子（規章與段次）。"
            "不確定就不要填；人會在設定頁「同義詞表」看到建議，按「採用」才生效。" % SYN_TABLE]


def _split(text):
    return [x.strip() for x in re.split(r"[、,，;；\s]+", text or "") if x.strip()]


def import_synonyms(root, html_path=None):
    """匯入時：AI同義詞建議.csv 裡新的、詞組還沒有的建議寫進設定頁。回傳加了幾組。"""
    from _common import tw_now, tw_today
    from _common import config_section, open_csv, write_config_key, load_config
    path = synonym_table(root)
    if not os.path.isfile(path):
        return 0
    try:
        with open_csv(path) as f:
            rows = list(csv.DictReader(f))
    except (OSError, UnicodeDecodeError, csv.Error, ValueError):
        return 0
    groups = (config_section("同義詞").get("詞組") or {}) if html_path is None else \
        ((load_config(html_path).get("同義詞") or {}).get("詞組") or {})
    known = set()
    for canon, variants in groups.items():
        known.add(canon)
        known.update(variants if isinstance(variants, list) else _split(variants))
    config = load_config(html_path) if html_path else load_config()
    current = config.get(SYN_KEY)
    current = list(current) if isinstance(current, list) else []
    seen = set((s.get("代表詞"), tuple(s.get("寫法") or ())) for s in current if isinstance(s, dict))
    # v1.22.0：人在設定頁按「不要」的，記在「同義詞已拒絕」：同一組（同代表詞、寫法都在拒絕過的裡面）不再加回來
    refused = {}
    for s in config.get(REFUSED_KEY) or []:
        if isinstance(s, dict):
            refused.setdefault(s.get("代表詞"), set()).update(s.get("寫法") or [])
    added = 0
    for row in rows:
        canon = (row.get("代表詞") or "").strip()
        variants = [v for v in _split(row.get("其他寫法")) if v != canon and len(v) > 1]
        if len(canon) < 2 or not variants:
            continue
        variants = [v for v in variants if v not in known] if canon in known else variants
        variants = [v for v in variants if v not in refused.get(canon, set())]
        if not variants or (canon, tuple(variants)) in seen:
            continue
        current.append({"代表詞": canon, "寫法": variants, "理由": (row.get("理由") or "").strip()[:200],
                        "例子": (row.get("例子") or "").strip()[:100],
                        "來源": os.path.basename(os.path.normpath(root)),
                        "日期": tw_today().isoformat()})
        seen.add((canon, tuple(variants)))
        added += 1
    if added:
        write_config_key(SYN_KEY, current, html_path)
    return added
