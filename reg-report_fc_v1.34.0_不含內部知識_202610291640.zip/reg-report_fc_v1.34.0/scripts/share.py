# -*- coding: utf-8 -*-
"""
打包分享（v1.20.0）：把這個 skill 打成一個 zip 給別人用。

skill 資料夾裡除了程式，還有越做越準累積的「內部知識」（本單位的 AI 判斷、判例、語意向量、內部規範……）。
**一定要先問使用者要不要包進去**：沒指定「--內部知識 含／不含」就不打包，只列出內部知識有哪些、多大，
AI 照這個用選擇框問使用者，再帶著使用者的選擇重跑。

不含內部知識時：內部的檔不放進 zip，設定.html 的分析單位基本資料、AI 單位資料建議、電腦資訊、工作區路徑回到預設。
zip 放在 skill 資料夾旁邊的 分享/（不放在 skill 裡面，免得下一次打包把上一次的 zip 也包進去）。
"""

import datetime
import fnmatch
import io
import json
import os
import shutil
import tempfile
import zipfile

HERE = os.path.dirname(os.path.abspath(__file__))
SKILL = os.path.dirname(HERE)
OUT_FOLDER = "分享"
# 內部知識（相對 skill 資料夾，/ 分隔；* 可以配任何字）
INTERNAL = [
    ("memoization/內部知識/*", "越做越準累積的本單位知識：判例、錯漏字白名單、跨工作區的 AI 答案、報告審查經驗、套語、同義詞建議"),
    ("memoization/AI查證紀錄.json", "外部引用查證紀錄（理由會寫到手冊內容）"),
    ("memoization/語意向量.sqlite", "手冊段落的語意向量"),
    ("memoization/外部規章排除表.csv", "不是外部法規的名稱（含本單位手冊名稱）"),
    ("memoization/資料庫快取/*", "規範資料庫讀出的文字（含內部規範）"),
    ("memoization/法規追蹤/適用判斷.json", "法規適用判斷（理由寫到本單位）"),
    ("memoization/法規追蹤/候選快取.json", "法規對到手冊的哪幾段"),
    ("memoization/法規追蹤/補查紀錄.json", "AI 上網補查紀錄（結果偶爾提到手冊段落）"),
    ("memoization/法規追蹤/[0-9a-f]*/*", "各工作區的法規已審查答案（含手冊段落原文）"),
    ("資料庫/內部規範/*", "使用者放的本行內部規範全文"),
    ("資料庫/轉文字/內部規範/*", "內部規範的圖片轉文字"),
    ("資料庫/目錄.csv", "規範資料庫目錄（列出內部規範名稱）"),
    ("資料庫/待轉文字.txt", "待轉文字清單"),
]
# v1.22.0：memoization/ 改成「只有這幾樣算公開」，其他（含備份檔 .bak、-journal、某某備份、「- 複製」）一律算內部。
# 以前是列出哪些算內部，清單外的檔（S8 外部規章表裡的「本行內規」名稱、備份檔）不含內部知識也照包。
PUBLIC_MEMO = [
    "memoization/法規追蹤/法規版本表.json",       # 法規最新修正日（公開資料）
    "memoization/法規追蹤/重複公告.json",         # 哪幾則公告是同一次修正（公開資料）
    "memoization/法規追蹤/網頁快取/*",            # 抓過的官方公告
    "memoization/法規追蹤/PDF文字/*",
    "memoization/S8_外部規章表.csv",              # 外部法規名稱；「本行內規」那幾列打包時拿掉（見 _public_s8）
]
OTHER_INTERNAL = "其他累積資料（AI 答案、快取、備份檔等）"
S8 = "memoization/S8_外部規章表.csv"
INTERNAL_CATEGORY = "本行內規"
SKIP = ("__pycache__", ".tmp", "~$")
SETTINGS_RESET = {"法規機構類型": "", "法規業務範圍": "", "法規追蹤主題": "保險,洗錢,個人資料,資訊安全", "工作區根目錄": "",
                  "語意模型路徑": "", "重排序模型路徑": "", "法規資料庫": []}   # v1.22.0：模型路徑會帶電腦使用者名稱、自訂資料庫可能是內網
DROP_KEYS = ("單位資料建議", "電腦資訊", "同義詞建議", "同義詞已拒絕")


def _files():
    for folder, dirs, names in os.walk(SKILL):
        dirs[:] = [d for d in dirs if not any(d.startswith(s) or d == s for s in SKIP)]
        for name in names:
            if name.endswith(".tmp") or name.startswith("~$"):
                continue
            path = os.path.join(folder, name)
            yield os.path.relpath(path, SKILL).replace(os.sep, "/"), path


def internal_reason(rel):
    """這個檔算不算內部（回傳說明；公開回 ""）。memoization/ 底下不在 PUBLIC_MEMO 的一律算內部。"""
    for pattern, reason in INTERNAL:
        if fnmatch.fnmatch(rel, pattern):
            return reason
    for pattern, reason in INTERNAL:
        # 備份、改名的變體（AI查證紀錄.json.bak、語意向量.sqlite-journal、目錄.csv 的備份）跟原檔同一類
        if "*" not in pattern and rel.startswith(pattern):
            return reason
    if rel.startswith("memoization/") and not any(fnmatch.fnmatch(rel, p) for p in PUBLIC_MEMO):
        return OTHER_INTERNAL
    return ""


def _public_s8(path):
    """S8 外部規章表拿掉「本行內規」那幾列（會寫出本單位手冊、甚至機構全名）。回傳過濾後的文字。"""
    import csv
    with io.open(path, encoding="utf-8-sig", newline="") as f:
        rows = list(csv.reader(f))
    out = io.StringIO()
    writer = csv.writer(out, lineterminator="\r\n")
    for i, row in enumerate(rows):
        if i and len(row) > 1 and row[1].strip() == INTERNAL_CATEGORY:
            continue
        writer.writerow(row)
    return "\ufeff" + out.getvalue()


def inventory():
    """內部知識有哪些：[(說明, 檔數, 大小 bytes)]（照 INTERNAL 的順序，沒有檔的不列）。"""
    found = {}
    for rel, path in _files():
        reason = internal_reason(rel)
        if reason:
            count, size = found.get(reason, (0, 0))
            found[reason] = (count + 1, size + os.path.getsize(path))
    order = [reason for _p, reason in INTERNAL] + [OTHER_INTERNAL]
    return [(reason,) + found[reason] for reason in order if reason in found]


def _size(n):
    return "%.1f MB" % (n / 1024 / 1024) if n >= 1024 * 1024 else "%d KB" % max(1, n // 1024)


def _clean_settings(path):
    """不含內部知識：設定.html 的本單位資料回到預設（只動資料區塊）。"""
    import settings_server as ss
    text = io.open(path, encoding="utf-8-sig").read()
    match = ss._DATA_RE.search(text)
    data = json.loads(match.group(2)) if match else {}
    for key in DROP_KEYS:
        data.pop(key, None)
    data.setdefault("設定", {}).update(SETTINGS_RESET)
    ss.write_data(path, data)


def pack(include_internal, out_dir=None, say=print):
    """打包。include_internal：True 含內部知識、False 不含。回傳 zip 路徑。"""
    from _common import tw_now, tw_today
    out_dir = out_dir or os.path.join(os.path.dirname(SKILL), OUT_FOLDER)
    os.makedirs(out_dir, exist_ok=True)
    name = "%s_%s內部知識_%s.zip" % (os.path.basename(SKILL), "含" if include_internal else "不含",
                                   tw_now().strftime("%Y%m%d%H%M"))
    target = os.path.join(out_dir, name)
    skipped = 0
    work = tempfile.mkdtemp(prefix="reg-share-")
    try:
        settings_copy = os.path.join(work, "設定.html")
        shutil.copy2(os.path.join(SKILL, "設定.html"), settings_copy)
        if not include_internal:
            _clean_settings(settings_copy)
        with zipfile.ZipFile(target, "w", zipfile.ZIP_DEFLATED) as z:
            for rel, path in _files():
                if not include_internal and internal_reason(rel):
                    skipped += 1
                    continue
                if not include_internal and rel == S8:
                    z.writestr(os.path.basename(SKILL) + "/" + rel, _public_s8(path).encode("utf-8"))
                    continue
                source = settings_copy if rel == "設定.html" else path
                z.write(source, os.path.basename(SKILL) + "/" + rel)
    finally:
        shutil.rmtree(work, ignore_errors=True)
    say("已打包：%s（%s 內部知識%s）" % (target, "含" if include_internal else "不含",
                                   "，略過 %d 個內部檔、設定頁的單位資料回到預設" % skipped if skipped else ""))
    return target


def ask_lines():
    """還沒選含不含：印給 AI 照著問使用者的那幾行。"""
    items = inventory()
    lines = ["[先問分享] 要不要把內部知識庫一起包進去？（這是本單位越做越準累積的資料，給別人用可能會外流）"]
    if items:
        lines += ["  內部知識有："] + ["  - %s：%d 個檔、%s" % (reason, count, _size(size)) for reason, count, size in items]
    else:
        lines.append("  （目前沒有內部知識）")
    lines += ["  另外：外部規章表裡的「本行內規」名稱、設定頁的分析單位基本資料、AI 單位資料建議、AI 同義詞建議、電腦資訊、"
              "工作區路徑、模型路徑、自訂法規資料庫也算本單位資料（選不含會拿掉、回到預設）；設定頁的同義詞表照包（比對用的詞組）",
              "  要包：加 --內部知識 含 再跑一次；不要包：加 --內部知識 不含 再跑一次"]
    return lines
