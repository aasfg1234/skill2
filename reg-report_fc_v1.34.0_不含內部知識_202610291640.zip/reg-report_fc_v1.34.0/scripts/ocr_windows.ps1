﻿# 規範資料庫（v1.9.0）：用 Windows 內建的文字辨識（OCR）把圖片轉成文字。不用安裝、不連網。
# 用法：powershell -NoProfile -ExecutionPolicy Bypass -File ocr_windows.ps1 -ListFile 圖片清單.txt -OutFile 結果.json
# 圖片清單一行一個檔案完整路徑（UTF-8）；結果是 {"路徑": ["第一行", "第二行", ...]}，失敗的寫 {"路徑": {"錯誤": "..."}}。
param(
    [Parameter(Mandatory = $true)][string]$ListFile,
    [Parameter(Mandatory = $true)][string]$OutFile,
    [string]$Language = "zh-Hant-TW"
)
$ErrorActionPreference = "Stop"
Add-Type -AssemblyName System.Runtime.WindowsRuntime
$null = [Windows.Storage.StorageFile, Windows.Storage, ContentType = WindowsRuntime]
$null = [Windows.Storage.Streams.IRandomAccessStream, Windows.Storage.Streams, ContentType = WindowsRuntime]
$null = [Windows.Media.Ocr.OcrEngine, Windows.Foundation, ContentType = WindowsRuntime]
$null = [Windows.Graphics.Imaging.BitmapDecoder, Windows.Graphics, ContentType = WindowsRuntime]
$null = [Windows.Graphics.Imaging.SoftwareBitmap, Windows.Graphics, ContentType = WindowsRuntime]
$null = [Windows.Globalization.Language, Windows.Globalization, ContentType = WindowsRuntime]

$asTask = [System.WindowsRuntimeSystemExtensions].GetMethods() | Where-Object {
    $_.Name -eq "AsTask" -and $_.GetParameters().Count -eq 1 -and
    $_.GetParameters()[0].ParameterType.Name -eq "IAsyncOperation``1" } | Select-Object -First 1

function Wait-Op($operation, [Type]$type) {
    $task = $asTask.MakeGenericMethod($type).Invoke($null, @($operation))
    $null = $task.Wait(-1)
    return $task.Result
}

$engine = [Windows.Media.Ocr.OcrEngine]::TryCreateFromLanguage((New-Object Windows.Globalization.Language $Language))
if ($null -eq $engine) {
    throw "這台電腦沒有 $Language 的文字辨識語言套件"
}
$result = [ordered]@{}
foreach ($path in (Get-Content -LiteralPath $ListFile -Encoding UTF8)) {
    if (-not $path.Trim()) { continue }
    try {
        $file = Wait-Op ([Windows.Storage.StorageFile]::GetFileFromPathAsync($path)) ([Windows.Storage.StorageFile])
        $stream = Wait-Op ($file.OpenAsync([Windows.Storage.FileAccessMode]::Read)) ([Windows.Storage.Streams.IRandomAccessStream])
        try {
            $decoder = Wait-Op ([Windows.Graphics.Imaging.BitmapDecoder]::CreateAsync($stream)) ([Windows.Graphics.Imaging.BitmapDecoder])
            $bitmap = Wait-Op ($decoder.GetSoftwareBitmapAsync()) ([Windows.Graphics.Imaging.SoftwareBitmap])
            $ocr = Wait-Op ($engine.RecognizeAsync($bitmap)) ([Windows.Media.Ocr.OcrResult])
            $result[$path] = @($ocr.Lines | ForEach-Object { $_.Text })
        } finally {
            $stream.Dispose()
        }
    } catch {
        $result[$path] = @{ "錯誤" = $_.Exception.Message }
    }
}
$json = $result | ConvertTo-Json -Depth 5
[System.IO.File]::WriteAllText($OutFile, $json, (New-Object System.Text.UTF8Encoding $false))
