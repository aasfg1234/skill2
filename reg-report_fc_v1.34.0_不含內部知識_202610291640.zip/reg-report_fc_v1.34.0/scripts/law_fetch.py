# -*- coding: utf-8 -*-
"""全國法規資料庫原文的離線快取與批次擷取。"""
import concurrent.futures
import datetime
import difflib
import hashlib
from html.parser import HTMLParser
import json
import os
from pathlib import Path
import re
import time
import threading
import unicodedata
from urllib.parse import quote, urlparse, parse_qs

import law_sources
import rule_library

BASE = 'https://law.moj.gov.tw/'
_memory = {}
_semaphore = threading.BoundedSemaphore(4)
_round = None
_generation = 0
_lock = threading.RLock()


def begin_round():
    global _round
    with _lock:
        _round = {'start': time.monotonic(), 'names': set(), 'jobs': {}, 'summary': True,
                  'found': set(), 'failed': set(), 'articles': 0, 'checked': 0, 'used': False}


def normalize(value):
    return re.sub(r'\s+', '', unicodedata.normalize('NFKC', value or ''))


def report(laws, article_count, checked_count):
    found = {normalize(n) for n, d in laws.items() if d.get('pcode') and not d.get('error') and not d.get('revoked')}
    failed = {normalize(n) for n, d in laws.items() if d.get('error') or not d.get('pcode') or d.get('revoked')}
    with _lock:
        state = _round
        if state and state.get('summary'):
            state['used'] = True
            state['found'].update(found)
            state['failed'].update(failed)
            state['articles'] += article_count
            state['checked'] += checked_count
            return
    print(_summary(found, failed, article_count, checked_count))


def _summary(found, failed, articles, checked):
    return ('外部引用：先抓好 %d 部法規的官方原文（%d 條引用附了原文、%d 條未指明條號程式已核對；%d 部沒抓到，交給 AI 查）'
            % (len(found), articles, checked, len(failed - found)))


def finish_round():
    with _lock:
        if _round and _round.get('summary'):
            if _round['used']:
                print(_summary(_round['found'], _round['failed'], _round['articles'], _round['checked']))
            _round['summary'] = False


class SearchPage(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.results, self.revoked, self.active = [], False, None
        self.in_heading, self.heading, self.result_structure = False, [], False

    def handle_starttag(self, tag, attrs):
        attrs = dict(attrs)
        if tag == 'h2':
            self.in_heading = True
        if attrs.get('id') == 'plLeftCount':
            self.result_structure = True
        if tag == 'tr':
            self.revoked = False
        if tag == 'span' and 'label-fei' in attrs.get('class', '').split():
            self.revoked = True
        if tag == 'a' and attrs.get('id') == 'hlkLawLink':
            code = parse_qs(urlparse(attrs.get('href', '')).query).get('pcode', [''])[0]
            self.active = [attrs.get('title', ''), code, self.revoked, []]

    def handle_data(self, data):
        if self.in_heading:
            self.heading.append(data)
        if self.active is not None:
            self.active[3].append(data)

    def handle_endtag(self, tag):
        if tag == 'h2':
            self.in_heading = False
        if tag == 'a' and self.active is not None:
            name, code, revoked, parts = self.active
            if code:
                self.results.append((name or ''.join(parts).strip(), code, revoked))
            self.active = None


def article_key(value):
    value = normalize(value)
    if re.fullmatch(r'\d+(?:-\d+)?', value):
        value = '§' + value
    return rule_library.cite_key(value)


def _path(folder, name):
    return Path(folder) / '法條原文' / (hashlib.sha256(normalize(name).encode('utf-8')).hexdigest() + '.json')


def _read(folder, name):
    try:
        return json.loads(_path(folder, name).read_text(encoding='utf-8'))
    except (OSError, ValueError, TypeError):
        return {}


def _fresh(stamp, days):
    try:
        age = (datetime.date.today() - datetime.date.fromisoformat(stamp)).days
        return 0 <= age < days
    except (TypeError, ValueError):
        return False


def _save(folder, name, data):
    if not folder:
        return
    path = _path(folder, name)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, ensure_ascii=False), encoding='utf-8')


def _date_field(html, label):
    match = re.search(r'<th\b[^>]*>\s*' + label + r'\s*[：:]\s*</th>\s*<td\b[^>]*>(.*?)</td>', html, re.I | re.S)
    if not match:
        return ''
    import html as html_module
    return re.sub(r'\s+', ' ', html_module.unescape(re.sub(r'<[^>]+>', ' ', match.group(1)))).strip()


def _law(name, folder, fetch):
    data = _read(folder, name) if folder else {}
    today = datetime.date.today().isoformat()
    if 'ambiguous' not in data or not _fresh(data.get('search_date'), 30 if data.get('pcode') or data.get('ambiguous') else 7):
        page = SearchPage()
        page.feed(law_sources.decode(fetch(BASE + 'Law/LawSearchResult.aspx?ty=ONEBAR&kw=' + quote(name))))
        if '整合查詢查詢結果' not in ''.join(page.heading) or not (page.result_structure or page.results):
            raise ValueError('官方頁面不是預期的搜尋結果（可能在維護）')
        exact = list({x[1]: x for x in page.results if normalize(x[0]) == normalize(name)}.values())
        current = [x for x in exact if not x[2]]
        ranked = sorted(page.results, key=lambda x: difflib.SequenceMatcher(None, normalize(name), normalize(x[0])).ratio(), reverse=True)
        similar = list(dict.fromkeys(x[0] for x in ranked if difflib.SequenceMatcher(None, normalize(name), normalize(x[0])).ratio() >= .5))[:3]
        selected = current[0] if len(current) == 1 else exact[0] if exact and not current else None
        data = {'name': name, 'search_date': today, 'pcode': selected[1] if selected else '',
                'revoked': selected[2] if selected else False, 'similar': similar,
                'ambiguous': [{'name': x[0], 'pcode': x[1]} for x in current] if len(current) > 1 else []}
    if not data.get('pcode'):
        return data
    if not _fresh(data.get('article_date'), 7) or 'law_date' not in data:
        html = law_sources.decode(fetch(BASE + 'LawClass/LawAll.aspx?pcode=' + data['pcode']))
        page = law_sources.MojPage()
        page.feed(html)
        revoked = data.get('revoked') or bool(re.search(r'<th\b[^>]*>\s*廢止日期\s*[：:]\s*</th>', html))
        if not revoked and not page.articles:
            raise ValueError('官方頁面沒有可解析的條文')
        data.update(articles=page.articles, article_date=today, revoked=bool(revoked),
                    law_date=_date_field(html, '廢止日期' if revoked else '修正日期'))
    return data


def fetch_batch(pairs, folder, fetch=None, limit=80, seconds=120):
    """回傳名稱對資料的對照；可注入 fetch 供離線測試。"""
    fetch = fetch or law_sources.fetch
    global _round
    names = list(dict.fromkeys(name for name, _ in pairs if name))
    result = {}
    futures = {}
    with _lock:
        if _round is None:
            begin_round()
            _round['summary'] = False
        state = _round
    executor = concurrent.futures.ThreadPoolExecutor(max_workers=4)
    for name in names:
        normalized = normalize(name)
        key = (str(folder), normalized)
        with _lock:
            if time.monotonic() - state['start'] >= seconds or (normalized not in state['names'] and len(state['names']) >= limit):
                result[name] = {'error': '這一輪沒抓（時間或數量上限）'}
                continue
            state['names'].add(normalized)
            cached = _memory.get(key)
            valid = cached and _fresh(cached.get('search_date'), 30 if cached.get('pcode') or cached.get('ambiguous') else 7) and (not cached.get('pcode') or _fresh(cached.get('article_date'), 7))
            if valid:
                result[name] = cached
                continue
            job = state['jobs'].get(key)
            if job is None:
                generation = _generation
                def run(n=name, k=key, gen=generation):
                    def guarded_fetch(url):
                        with _lock:
                            if gen != _generation or time.monotonic() - state['start'] >= seconds:
                                raise RuntimeError('這一輪沒抓（時間或數量上限或快取已作廢）')
                        return fetch(url)
                    with _semaphore:
                        with _lock:
                            if gen != _generation or time.monotonic() - state['start'] >= seconds:
                                raise RuntimeError('這一輪沒抓（時間或數量上限或快取已作廢）')
                        data = _law(n, folder, guarded_fetch)
                    with _lock:
                        if gen == _generation and time.monotonic() - state['start'] < seconds:
                            _save(folder, n, data)
                            _memory[k] = data
                    return data
                job = executor.submit(run)
                state['jobs'][key] = job
            futures.setdefault(job, []).append(name)
    done, pending = concurrent.futures.wait(futures, timeout=max(0, seconds - (time.monotonic() - state['start'])))
    for future in done:
        try:
            value = future.result()
        except Exception as exc:
            value = {'error': str(exc) or type(exc).__name__}
        for name in futures[future]:
            result[name] = value
        with _lock:
            key = (str(folder), normalize(futures[future][0]))
            if state['jobs'].get(key) is future:
                del state['jobs'][key]
    for future in pending:
        for name in futures[future]:
            result[name] = {'error': '這一輪沒抓（時間或數量上限）'}
    executor.shutdown(wait=False)
    return result


def invalidate(folder, names=(), everything=False):
    global _generation
    with _lock:
        _generation += 1
        if _round is not None:
            _round['jobs'].clear()
        _invalidate_locked(folder, names, everything)


def _invalidate_locked(folder, names, everything):
    if not folder:
        return
    directory = Path(folder) / '法條原文'
    for path in directory.glob('*.json'):
        try:
            data = json.loads(path.read_text(encoding='utf-8'))
            if everything or normalize(data.get('name')) in {normalize(n) for n in names}:
                path.unlink()
        except (OSError, ValueError):
            continue
    for key in list(_memory):
        if key[0] == str(folder) and (everything or key[1] in {normalize(n) for n in names}):
            del _memory[key]
