# -*- coding: utf-8 -*-
"""
批次「開始」的各本初比對同時跑：每一本一個行程，結果跟一本一本跑完全一樣。

十本規章的「開始」有三分之二的時間花在逐本初比對（_batch_full_compare），而每一本彼此
獨立——第一本的比對不看第二本的任何東西，跨本的連帶是全部比完之後才算。所以讓好幾本
同時比，主程式再照清單順序把結果一本一本收回來。

「跟一本一本跑一樣」要顧三件事：
  畫面輸出   每本在自己的行程裡收起來，主程式照清單順序印——不會兩本的字交錯。
  提醒清單   notices 是模組層的狀態（提醒、講過了沒）。一本一本跑時，每一本開頭
             run_compare 會 reset，開頭之前的提醒（設定檔讀不出來之類）由清單第一本收走。
             這裡照樣：第一本帶著主程式當下的狀態出發，每一本跑完把它最後的狀態交回來。
  中途失敗   一本一本跑時，失敗那一本之後的本根本不會跑。同時跑時它們可能已經跑完了：
             收回來時不印它們的輸出、刪掉它們新建的資料夾，等於沒跑過。

只有兩本以上要整套比對時才開行程；開不起來（受限的環境）就退回一本一本跑。
"""

import contextlib
import importlib.util
import io
import os
import shutil

HERE = os.path.dirname(os.path.abspath(__file__))
MAX_WORKERS = 8

_MAIN = []


def _main_module():
    """各行程自己載一份 scripts/run_all.py（它跟 regdiff/run_all.py 同名，不能直接 import）。"""
    if not _MAIN:
        spec = importlib.util.spec_from_file_location("reg_batch_worker_run_all",
                                                      os.path.join(HERE, "run_all.py"))
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        _MAIN.append(module)
    return _MAIN[0]


def compare_book(job):
    """（在子行程裡跑）整套初比對一本。回傳 (畫面輸出, 這一本的狀態或 None, 跑完時的提醒狀態, 例外)。"""
    import notices as nt
    main = _main_module()
    main._DISPLAY_ROOT[0] = job["display_root"]
    nt.restore(job["notices"])
    out = io.StringIO()
    try:
        with contextlib.redirect_stdout(out):
            t = main._batch_full_compare(job["doc"], job["outdir"], job["args"], job["settings"],
                                         main.load_regdiff_runner(), job["params"], job["verbose"],
                                         health=bool(getattr(job["args"], "health", False)))
    except BaseException as exc:          # SystemExit（讀檔失敗）也要帶回主程式照原樣丟出去
        return out.getvalue(), None, None, exc
    return out.getvalue(), t, nt.snapshot(), None


def worker_count(books):
    return min(books, MAX_WORKERS, max(1, (os.cpu_count() or 1) - 1))


class ParallelCompare(object):
    """主程式這一邊：start() 一次把要整套比對的本全部送出去，take(name) 照清單順序一本一本收。"""

    def __init__(self, docs, outdir, args, settings, params, verbose, display_root, book_dir, all_books=False):
        self.docs, self.outdir, self.args, self.settings = docs, outdir, args, settings
        self.params, self.verbose, self.display_root = params, verbose, display_root
        self.book_dir = book_dir
        self.all_books = all_books      # 體檢：沒有草稿的本也整套跑
        self.pool = None
        self.futures = {}
        self.existed = {}

    def start(self):
        """送出去；本數不到兩本或開不了行程就回 False（呼叫端照舊一本一本跑）。"""
        import notices as nt
        full = [doc for doc in self.docs if self.all_books or doc["有草稿"] or doc["發布根目錄"]]
        if len(full) < 2 or worker_count(len(full)) < 2:
            return False
        # args 裡的 func 是主程式的函式，子行程不一定找得到（測試用檔案路徑載入時）；比對用不到它
        args = _plain_namespace(self.args)
        try:
            from concurrent.futures import ProcessPoolExecutor
            self.pool = ProcessPoolExecutor(max_workers=worker_count(len(full)))
            for doc in full:
                name = doc["規章名"]
                self.existed[name] = os.path.isdir(self.book_dir(self.outdir, name, legacy=False))
                # 開頭之前的提醒只歸清單第一本（一本一本跑時，第一本以外開跑前都已經被收走了）
                state = nt.snapshot() if doc is self.docs[0] else nt.snapshot(empty=True)
                self.futures[name] = self.pool.submit(compare_book, {
                    "doc": doc, "outdir": self.outdir, "args": args, "settings": self.settings,
                    "params": self.params, "verbose": self.verbose,
                    "display_root": self.display_root, "notices": state})
        except Exception:
            self.close()
            self.futures = {}
            return False
        return True

    def take(self, name, fallback):
        """收回一本：照它跑的時候的樣子印出畫面輸出、換上它跑完的提醒狀態，回傳它的結果。
        行程壞掉（BrokenProcessPool 之類）就在主程式裡用 fallback() 重跑這一本。"""
        import notices as nt
        future = self.futures.pop(name)
        try:
            out, t, state, exc = future.result()
        except Exception:
            return fallback()
        print(out, end="", flush=True)
        if exc is not None:
            self.abandon()
            raise exc
        if t is None:
            self.abandon()
            return None
        nt.restore(state)
        return t

    def abandon(self):
        """失敗那一本之後的本：一本一本跑時根本不會跑到。等它們停下來，刪掉它們新建的資料夾。"""
        for future in self.futures.values():
            future.cancel()
        self.close()
        for name in self.futures:
            path = self.book_dir(self.outdir, name, legacy=False)
            if not self.existed.get(name) and os.path.isdir(path):
                shutil.rmtree(path, ignore_errors=True)
        self.futures = {}

    def close(self):
        if self.pool is not None:
            self.pool.shutdown(wait=True)
            self.pool = None


def _plain_namespace(args):
    import argparse
    plain = argparse.Namespace(**vars(args))
    if hasattr(plain, "func"):
        del plain.func
    return plain
