# -*- coding: utf-8 -*-
"""
一本的比對：一次跑完 Step 0.5 → 1 → 1.6 → 2（run_compare），中間結果全部在記憶體裡傳遞。
由 scripts/run_all.py 的 開始（批次）逐本呼叫，不單獨跑。
"""

import os
import re
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from _common import (AtomicWrites, read_paragraphs_with_metadata,
                     build_hierarchy, list_label, structure_view,
                     diff_runs, normalize_terms, extract_article_no,
                     load_synonyms, load_table_format, load_term_groups,
                     resolve_output, warn_if_versions_swapped)
import diff_compare
import fuzzy_duplicate_finder as fuzzy
import notices as nt
import renumber
import rule_checks
# BaselineReleaseError：scripts/run_all.py 以 runner.BaselineReleaseError 接
from baseline_release import BaselineReleaseError, load_baseline_release  # noqa: F401


class CompareAbort(Exception):
    """比對前的防呆沒過，整支不要再往下跑。

    上層（reg/scripts/run_all.py 的 _compare_core、以及本檔的 __main__）
    比照 BaselineReleaseError 接住，印「[中止] …」並 exit 1。
    這種情況不能只印警告就繼續：0 段的那一邊會讓對照表把另一邊每一條
    都標成「刪除」或「新增」，而且退出碼 0，看起來像一次成功的執行。
    """


def banner(title):
    print("\n" + "=" * 66)
    print(title)
    print("=" * 66)


# 「編號調整」的收尾提醒。以前寫「另有 N 處只是編號調整，內容未變動。」——
# 條文的字確實沒動，但條號或款號動了，別的條文寫「第七條」的地方就指到別的東西。
# 在同一行下「內容未變動」的結論，等於叫人不要再看交叉引用那一段。
# 定義放在 diff_compare，兩支各寫一份就會又漂開。
RENUMBERED_ONLY_NOTE = diff_compare.RENUMBERED_ONLY_NOTE

# 兩邊段數少於這個數就提醒：正式內規再短也有標題、依據、施行日期三段，
# 只讀到一兩段通常代表拿錯檔、或內容在程式不讀的地方。
MIN_SANE_PARAGRAPHS = 3
# 兩邊段數的倍數超過這個就提醒：一次修法不太可能讓篇幅差到十倍。
MAX_SANE_RATIO = 10


def check_paragraph_counts(old_paragraphs, new_paragraphs, old_file, new_file):
    """讀完檔的三態防呆：0 段中止、段數異常提醒、正常就什麼都不印。

    回傳提醒字串清單。留底已經由 notices 負責（發出去的每一則都在 提醒.txt 裡），
    呼叫端不需要接這個回傳值；留著是給測試直接斷言「這組段數會不會提醒」用的。
    """
    n, m = len(old_paragraphs), len(new_paragraphs)
    if not n or not m:
        if not n and not m:
            side, where = "舊版與新版都", "%s、%s" % (old_file, new_file)
        elif not n:
            side, where = "舊版", old_file
        else:
            side, where = "新版", new_file
        raise CompareAbort(
            "%s讀不到任何段落（%s）。"
            "可能是檔案加密、損壞，或內容都在程式不讀的地方（文字方塊、註腳、頁首頁尾）。"
            % (side, where))

    lines = []
    if n < MIN_SANE_PARAGRAPHS or m < MIN_SANE_PARAGRAPHS:
        lines.append("舊版 %d 段、新版 %d 段，段數很少，請確認拿對檔——"
                     "內容有沒有放在文字方塊、附件或頁首頁尾裡？" % (n, m))
    lo, hi = min(n, m), max(n, m)
    if hi > lo * MAX_SANE_RATIO:
        lines.append("舊版 %d 段、新版 %d 段，兩邊段數差很大（約 %.0f 倍），"
                     "請確認拿對檔，別把草稿或別本規章當成另一版。" % (n, m, hi / float(lo)))
    # 走 notices：這兩句在畫面上會被後面幾百行比對輸出洗掉，留底才看得到
    for line in lines:
        nt.notice(nt.REMINDER, line, "讀檔")
    return lines


# step_renumber 附帶的結果（回傳值只有段落，其他呼叫端不用改）；run_compare 每次先清空
_last_step = {}


def _to_original(findings, structure, original):
    """改號檢查是對結構文字做的；要進決定表的發現換回原文：文字換成原文、位置扣掉前面那段
    自動編號的長度。位置落在自動編號裡面的（Word 畫的編號程式不會去改）就拿掉位置，
    決定表就不給建議改法，留給人看。沒有自動編號的段落原封不動。"""
    for finding in findings or []:
        index = finding.get("index")
        if not isinstance(index, int) or not 0 < index <= len(original):
            continue
        shift = len(structure[index - 1]) - len(original[index - 1])
        if not shift:
            continue
        if "text" in finding:
            finding["text"] = original[index - 1]
        for key in ("span", "ref_span"):
            span = finding.get(key)
            if span:
                finding[key] = (span[0] - shift, span[1] - shift) if span[0] >= shift else ()
        if finding.get("start") is not None:
            if finding["start"] >= shift:
                finding["start"] -= shift
                if finding.get("end") is not None:
                    finding["end"] -= shift
            else:
                finding.pop("start")
                finding.pop("end", None)


def step_renumber(old_paragraphs, new_paragraphs, apply_changes, rewrite_refs,
                  old_kinds=None, new_kinds=None):
    """
    Step 0.5：款目編號檢查（以及選用的重編）。

    回傳可能已重編過的新版段落。不論有沒有 --apply-renumber，
    交叉引用的問題都會完整報告出來——那是人要處理的，不能默默跳過。

    編號與引用一律看結構文字（Word 自動編號＋原文）：自動編號不在段落文字裡，只看原文的話
    款目編號、「第三款」指到誰全都看不到。要進決定表的發現最後換回原文（_to_original），
    回傳的段落也一定是原文——比對、標註、套用都用原文。
    """
    banner("Step 0.5　款目編號與交叉引用檢查")
    original_new = new_paragraphs
    auto_numbered = any(list_label(new_kinds, i) for i in range(len(new_paragraphs)))
    old_paragraphs, old_kinds = structure_view(old_paragraphs, old_kinds)
    new_paragraphs, new_kinds = structure_view(new_paragraphs, new_kinds)

    entries = renumber.scan(new_paragraphs, new_kinds)
    # 沒有「第X條」的文件不在這裡發提醒：renumber.report 收尾時併成一則（見 NO_ARTICLE_NOTE），
    # 以前這裡一則、report 又一則，同一件事每本每輪講兩次
    applicable = renumber.numbering_check_applicable(entries)
    problems = renumber.find_numbering_gaps(entries)
    changes, clause_map, item_map = renumber.plan_renumber(new_paragraphs, entries)

    known_articles = {c["article"] for c in build_hierarchy(new_paragraphs, new_kinds)
                      if c["level"] == "條" and c["article"]}
    # 條層級的引用要靠「舊條號 → 新條號」對照才判得了，這裡一定有舊版，所以一定要算
    article_map = renumber.plan_article_map(old_paragraphs, new_paragraphs,
                                            old_kinds, new_kinds)
    # 自己也被改過的那些段落，條層級引用一律降級成危險：改過之後「作者已經改好的
    # 新號」跟「還沒改的舊號」文字上一模一樣，程式分不出來，猜錯就是把對的改成錯的。
    changed_paragraphs = renumber.find_changed_paragraphs(
        old_paragraphs, new_paragraphs, old_kinds, new_kinds)
    # 給舊版：「前條」「前項」「前二款」與款、項號要新舊版各推算一次指到誰（只看新版的話，
    # 前條永遠指得到新版的前一條，刪條、插條後改指別條都判「通過」）
    references = renumber.scan_references(
        new_paragraphs, entries, clause_map, item_map,
        known_articles=known_articles, kinds=new_kinds, article_map=article_map,
        changed_paragraphs=changed_paragraphs,
        old_paragraphs=old_paragraphs, old_kinds=old_kinds)

    deleted_articles = renumber.find_deleted_articles(old_paragraphs, new_paragraphs,
                                                      old_kinds, new_kinds,
                                                      article_map=article_map)
    drift = renumber.scan_reference_drift(old_paragraphs, new_paragraphs,
                                          old_kinds, new_kinds)

    outline_drift = []
    outline = renumber.scan_outline_references(old_paragraphs, new_paragraphs,
                                               old_kinds, new_kinds, drift=outline_drift)
    # 「內容變了」跟交叉引用講的是同一處就只留交叉引用那一筆（決定表上同一段只說一次）
    drift = renumber.dedupe_drift(drift + outline_drift, references)
    # 沒有條的文件：點的編號照查（本來就有的也報，跟這次改出來的分開講）；
    # 章節標題的編號不分文件型態都查，只報這次改出來的
    point_issues = (None if applicable else
                    renumber.point_numbering_issues(old_paragraphs, new_paragraphs,
                                                    old_kinds, new_kinds))
    heading_issues = renumber.heading_numbering_issues(old_paragraphs, new_paragraphs,
                                                       old_kinds, new_kinds)
    renumber.report(problems, changes, deleted_articles, references, drift,
                    numbering_applicable=applicable, article_map=article_map,
                    outline=outline, point_issues=point_issues,
                    heading_issues=heading_issues)
    renumber.notice_outline_references(outline[1])
    renumber.notice_article_references(references, drift)
    renumber.notice_numbering_issues(point_issues or [], heading_issues)
    for findings in (outline[1], references, drift):
        _to_original(findings, new_paragraphs, original_new)
    # 章節引用要進連帶決定表（見 scripts/run_all._compare_core）：回傳值維持「段落」不變，
    # 另外留在這裡讓 run_compare 放進 outcome
    _last_step["章節引用"] = outline[1]
    # 條、款、項引用與「內容變了」也進決定表。--apply-renumber --rewrite-refs 已經自動改好的
    # 那幾處不再列（決定表的候選全文是重編後的那一份，裡面已經是新號碼）
    applied = bool(changes) and apply_changes and rewrite_refs
    _last_step["條文引用"] = {
        "references": [r for r in references
                       if not (applied and renumber._auto_rewritable(r))],
        "drift": drift}

    if not changes:
        return original_new

    if not apply_changes:
        nt.notice(nt.REMINDER,
                  "偵測到 %d 段需要重編，但沒有加 --apply-renumber，本次不更動編號；"
                  "後續步驟會以「未重編」的內容比對，對照表可能出現編號不連續的段落"
                  % len(changes), "Step 0.5")
        return original_new

    if auto_numbered:
        # 重編是改寫段落文字裡的號碼；Word 自動編號不在文字裡，改寫結構文字等於把「一、」
        # 寫進原文，套用時 Word 又畫一次編號，變成「一、一、」。自動編號 Word 本來就會自己重排。
        nt.notice(nt.REMINDER,
                  "偵測到 %d 段需要重編，但這份用了 Word 自動編號，程式不改寫文字；"
                  "請在 Word 裡確認編號，手打的編號請人工重編" % len(changes), "Step 0.5")
        return original_new

    updated = renumber.apply_changes(new_paragraphs, changes, references, rewrite_refs)
    print("\n已重編 %d 段款目編號%s。"
          % (len(changes), "，並改寫可機械式處理的交叉引用" if rewrite_refs else ""))
    return updated


def step_diff(old_paragraphs, new_paragraphs, outdir, prefix, title,
              table_format, source_docx=None, baseline=None,
              old_kinds=None, new_kinds=None, old_metadata=None, new_metadata=None, reasons=None):
    """Step 1：精確比對並產出全部檔案。回傳比對結果供後續步驟使用。

    old_kinds／new_kinds：每一段是本文段落還是表格儲存格，只用來算條號層級。
    reasons：終比對時由 finalize 給（change_reasons.make_drafter）：寫修正對照表之前
    在每一列填「修改依據」「依據來源」。初比對不給，那一欄留白。
    """
    banner("Step 1　精確文字比對")

    results = diff_compare.compare_paragraphs(old_paragraphs, new_paragraphs,
                                              old_kinds, new_kinds, old_metadata, new_metadata)
    diff_compare.attach_table_positions(results, old_metadata, new_metadata)
    if baseline:
        baseline.annotate_results(results)

    counts = {"added": 0, "deleted": 0, "modified": 0, "renumbered": 0,
              "cosmetic": 0}
    for item in results:
        if item["type"] in counts:
            counts[item["type"]] += 1
    substantive = counts["added"] + counts["deleted"] + counts["modified"]

    print("實質異動 %d 處（新增 %d、刪除 %d、修改 %d）"
          % (substantive, counts["added"], counts["deleted"], counts["modified"]))
    if counts["renumbered"]:
        # 條層級的編號調整（「第十八條」變「第十九條」）跟款目層級（「三、」變「二、」）
        # 的後果完全不同：條號是別的規章、公文、系統設定引用的對外座標，一旦整批位移，
        # 全文與其他規章裡所有「第X條」都可能指錯。兩處以上就不是單一筆誤，
        # 是整批位移，要升級成警告並留底（只印在畫面上會被後面的統計洗掉）。
        article_renumbered = [
            item for item in results
            if item["type"] == "renumbered"
            and re.match(r"^第.+條", extract_article_no(item["old_text"] or ""))
            and re.match(r"^第.+條", extract_article_no(item["new_text"] or ""))]
        if len(article_renumbered) > 1:
            nt.notice(nt.WARNING,
                      "本次有 %d 處條層級編號調整（條號整批位移）。依內規慣例條號不應遞補；"
                      "全文及其他規章裡所有「第X條」引用都必須複核，"
                      "見交叉引用檢查與修正對照表的「條號」欄" % len(article_renumbered),
                      "Step 1 比對")
        else:
            nt.notice(nt.REMINDER, RENUMBERED_ONLY_NOTE % counts["renumbered"],
                      "Step 1 比對")
    if counts["cosmetic"]:
        print("另有 %d 處只有字形或空白差異（全半形、空格），不算實質異動；"
              "修正對照表上標示為「%s」。" % (counts["cosmetic"], diff_compare.COSMETIC_LABEL))
    moves = sum(1 for r in results if r.get("moved_to"))
    if moves:
        print(diff_compare.MOVED_NOTE % moves)

    if reasons:
        reasons(results)

    table_base = os.path.splitext(
        resolve_output(outdir, prefix, "修正對照表.xlsx"))[0]
    table = resolve_output(outdir, prefix, "修正對照表.docx")
    # 標註版全文只出一種格式：來源是 .docx 就在原檔上標註（字型、縮排、頁首頁尾、
    # 表格全部留著），不是 .docx 就沒有原檔可以改，退純文字版。以前兩份都寫，
    # 資料夾裡同一件事有兩個檔，人不知道該看哪一個。
    in_place = diff_compare.can_annotate_source(source_docx)
    annotated = resolve_output(outdir, prefix,
                               "標註版全文.docx" if in_place else "標註版全文.txt")
    if not in_place:
        print(diff_compare.SOURCE_NOT_WORD_NOTE
              % os.path.basename(str(source_docx or "純文字")))
    # 全部一起原子寫出（實測 no 12）：舊寫法一份一份直接覆寫正式檔名，第三份失敗
    # 時前兩份已經是新的、後兩份還是上一輪的舊檔，資料夾裡新舊混雜又看不出來。
    # 例外不吞，往外丟給 main() 印「[中止]」。
    with AtomicWrites() as aw:
        report_paths = diff_compare.write_table_report(
            results, table_base, table_format=table_format, path_for=aw.path)
        if in_place:
            # 傳新版原檔進去，標註版才能在原檔上改而不是新開一份空白 Word。
            # text_fallback：在原檔上標註走不下去、這台電腦又沒有 python-docx 時，
            # export_to_docx 會改寫這個純文字路徑並回傳它——以前那種情形是
            # 「一個檔都沒有，提醒卻說純文字版會產生」。
            annotated = diff_compare.export_to_docx(
                results, aw.path(annotated), table_format=table_format,
                source_docx=source_docx,
                text_fallback=resolve_output(outdir, prefix, "標註版全文.txt"),
                path_for=aw.path) or annotated
        else:
            diff_compare.write_annotated_text(results, aw.path(annotated))
        diff_compare.export_table_to_docx(results, aw.path(table), title=title,
                                          table_format=table_format)

    # 正式路徑要等 commit 完（離開 with）才會存在；修正對照表.docx 在沒裝
    # python-docx 時本來就不會產生，所以逐一確認再收進清單。
    produced = [path for path in (list(report_paths) + [annotated, table])
                if os.path.exists(path)]

    return results, produced


def step_rule_checks(old_paragraphs, new_paragraphs, results, outdir, prefix, terms,
                     old_kinds=None, new_kinds=None, health=False):
    """Step 1.6：十項條文品質與風險檢查。

    old_kinds／new_kinds：每一段是本文段落還是表格儲存格。條文檢查報告的條號欄
    要跟修正對照表一致，兩邊就得用同一份層級脈絡。
    """
    banner("Step 1.6　條文品質與風險檢查")

    # 查編號本身的兩項（條號重複跳號、編號格式）看結構文字，Word 自動編號才看得到；
    # 其餘照原文：外部引用的位置要能對回原文改字，定義的新舊版也要同一種文字才比得準。
    # 原文那幾項算條號時，種類身上的自動編號會由 build_hierarchy 自己帶進去。
    new_structure, new_plain_kinds = structure_view(new_paragraphs, new_kinds)
    old_structure, old_plain_kinds = structure_view(old_paragraphs, old_kinds)
    findings = []
    findings += rule_checks.check_article_integrity(new_structure, old_structure,
                                                    new_plain_kinds, old_plain_kinds)
    findings += rule_checks.check_external_refs(new_paragraphs, new_kinds)
    findings += rule_checks.check_placeholders(new_paragraphs, new_kinds)
    findings += rule_checks.check_format_consistency(new_structure)
    findings += rule_checks.check_term_consistency(new_paragraphs, terms)
    findings += rule_checks.check_attachments(new_paragraphs, new_kinds)
    findings += rule_checks.check_definitions(new_paragraphs, results, new_kinds)
    findings += rule_checks.check_modal_changes(results)
    findings += rule_checks.check_proviso_changes(results)
    findings += rule_checks.check_numeric_changes(results)
    findings += rule_checks.check_threshold_changes(results)
    findings += rule_checks.check_effective_date(new_paragraphs, results)

    rule_checks.report(findings)

    # 高風險那幾筆另存一份給 review-pack 交給 AI 查證（見 rule_checks.ai_review_findings）。
    # 沒有發現也要寫（空的）：上一輪的留著，會被當成這一輪要查的。
    import io
    import json
    # 先寫 .tmp 再換名：寫到一半被中斷留下半個 json，之後打包、匯入都會炸（審查 C6）
    review_path = resolve_output(outdir, prefix, rule_checks.AI_REVIEW_FILE)
    with io.open(review_path + ".tmp", "w", encoding="utf-8") as f:
        json.dump(rule_checks.ai_review_findings(findings, health=health), f, ensure_ascii=False, indent=1)
    os.replace(review_path + ".tmp", review_path)

    produced = []
    # 提醒也寫進這張表（「提醒」等級）：它是複核時一定會打開的檔案，
    # 只印在畫面上的提醒會被後面的輸出洗掉。完整留底另見 2_Log檔案/提醒.txt。
    collected = nt.collected()
    if findings or collected:
        base = os.path.splitext(
            resolve_output(outdir, prefix, "條文檢查報告.xlsx"))[0]
        produced += rule_checks.write_report_table(findings, base, notices=collected)
    # 定義變更連動、定義刪除也進連帶決定表（scripts/run_all._compare_core 接 run_compare 的
    # outcome），再發一則警告留進 提醒.txt。放在條文檢查報告寫完之後：報告裡已經有那一列，不重複
    for item in findings:
        if item["check"] in rule_checks.DEFINITION_LINK_CHECKS:
            nt.notice(nt.WARNING, "%s　%s（用到這個詞的段落已列進連帶決定表，"
                      "來源「定義連動」，請逐筆確認）" % (item["check"], item["detail"]), "Step 1.6")
    return findings, produced


def step_duplicates(new_paragraphs, results, outdir, prefix, threshold, top,
                    synonyms, context_span=1, changed_top=8, baseline=None,
                    sentence_threshold=fuzzy.DEFAULT_SENTENCE_THRESHOLD,
                    new_kinds=None):
    """
    Step 2：跨章節重複條文。

    這裡直接吃 Step 1 的比對結果，不像分步版那樣去讀 修正對照表——
    中間檔不必存在，也就不怕它在下一次執行時消失。
    """
    banner("Step 2　跨章節重複條文（最重要的一步）")

    # 缺 rapidfuzz 時一定要講。實測 1,199 段的內規，內建 difflib 抓到的候選數
    # 比 rapidfuzz 少約 7%——這是一個抓漏改的工具，少 7% 的候選要讓人知道。
    if not fuzzy.HAS_RAPIDFUZZ:
        # 提醒本身在 run_compare 開頭就發過了（要趕在 條文檢查報告 寫出去之前），
        # 這裡只留一行指回去，免得看 Step 2 的人以為這件事沒講。
        print("（環境提醒見上方：這個環境沒有 rapidfuzz，改用 difflib 比對。）")

    if synonyms:
        print("已載入同義詞表：%d 組變體（用來抓「用詞完全換掉」的重複條文）"
              % len(synonyms))
    else:
        print("未使用同義詞表，只做純字面比對。")

    # 跟 Step 1 用同一份層級脈絡（含表格儲存格的標記），候選的條號才會跟對照表一致
    contexts = build_hierarchy(new_paragraphs, new_kinds)
    new_line_ids = baseline.annotate_results(results) if baseline else {}
    changes = []
    for item in results:
        if item["type"] == "unchanged":
            continue
        if item["type"] == "renumbered":
            continue      # 純編號位移，內容沒變，不需要找重複
        if item["type"] == "cosmetic":
            continue      # 只差字形或空白，內容沒變，跟沒改一樣不必找重複
        moved = item.get("moved_to") or item.get("moved_from")
        if moved and (item.get("moved_to") or moved.get("identical")):
            # 搬移（diff_compare._mark_moves）：刪掉的那段原封不動搬到別處了，拿它去找
            # 「別章還留著同樣規定沒刪」，第一個找到的就是搬過去的那段，等於叫人把它刪掉；
            # 內容一樣的那一筆新增也跟編號調整一樣，內容沒變，不必找重複。
            # 搬過去又改了字的（幾乎一樣）新增那一筆照舊找。
            continue
        if item["type"] == "deleted":
            text, line_no = item["old_text"], None
        else:
            text, line_no = item["new_text"], item.get("new_index")
        if text:
            article_no = (baseline.change_label(item) if baseline
                          else item.get("ref", "")) or ""
            if not article_no:
                # 作業手冊型文件沒有「第X條」，ref 是空字串，決定表的「異動條文ID」
                # 就整欄空白；審查包 _find_changes 三階全部對不上，候選底下列不出
                # 任何異動，人看到的是一張「不知道為什麼被列出來」的候選表。
                # 給它一個段次身分，審查包才連得回來（刪除型沒有新版段次，用舊版的）。
                if item["type"] == "deleted":
                    if item.get("old_index"):
                        article_no = "舊版段次 %d" % item["old_index"]
                elif line_no:
                    article_no = "段次 %d" % line_no
            # 這一處異動在哪一段（決定表「異動段次」欄要的字串，寫法跟
            # decision_table.change_position_map 一致：新增／修改寫「N」，
            # 刪除寫「舊版 N」）。候選列自己帶著它，決定表就不必拿 異動條文ID
            # 去查表——手冊型文件每一章的「1.」共用同一個鍵，查表會把別章那處
            # 異動的段次也一起帶進來。
            if item["type"] == "deleted":
                position = "舊版 %d" % item["old_index"] if item.get("old_index") else ""
            else:
                position = "%d" % line_no if line_no else ""
            changes.append({"article_no": article_no, "text": text,
                            "position": position,
                            # 候選 CSV 的「異動段全文」欄對刪除型放的是舊版原文，
                            # 所以一定要同時寫出修改類型，看表的人才知道那一欄怎麼讀
                            "type": diff_compare.TYPE_LABELS.get(item["type"], ""),
                            "old_text": item.get("old_text") or "",
                            # 一段裡寫了好幾款、只改其中一款時（diff_compare.refine_item_refs），
                            # 找相似拿那一款比：整段幾款一起比，分數被沒改的那幾款稀釋到門檻以下
                            "focus_text": item.get("focus_new_text") or "",
                            "focus_old_text": item.get("focus_old_text") or "",
                            "line_number": line_no,
                            "deleted": item["type"] == "deleted"})

    if not changes:
        print("沒有實質異動，略過。")
        return [], [], [], []

    print("針對 %d 個異動段落比對全文 %d 段（門檻 %.0f%%）..."
          % (len(changes), len(new_paragraphs), threshold))

    csv_rows = []
    changed_rows = []
    sentence_rows = []
    # 片段／文脈／舊值每處只列前 changed_top 段：被擠掉的段數要講（畫面、候選明細、提醒）
    unlisted_total = 0
    unlisted_changes = 0
    for change in changes:
        candidates = fuzzy.find_duplicates(
            change.get("focus_text") or change["text"], new_paragraphs, threshold=threshold, top=top,
            exclude_index=change["line_number"], contexts=contexts,
            synonyms=synonyms, context_span=context_span,
            changed_old_text=change.get("focus_old_text") or change.get("old_text"),
            # 整條刪除沒有新版段次（exclude_index 是 None），要靠這個旗標
            # 才不會把一字不差的孿生條當成「它自己」跳掉
            is_deleted=bool(change.get("deleted")))
        if baseline:
            for candidate in candidates:
                baseline.apply_candidate_identity(candidate, new_line_ids)
        fuzzy.print_candidates(change["text"], candidates, threshold)
        # 整條比對抓不到的東西，改用「這次改動的文字」再搜一次。
        # 實測：某條加了「及火險保單」，講火險與保單的兩條整條相似度只有
        # 26.5 與 16.7 分，門檻下一條都抓不到，用改動文字搜就找得到。
        if change.get("deleted"):
            # 整段刪除：new_text 就是 old_text，changed_fragments／context_fragments
            # 拿一模一樣的兩段文字去比對，diff 永遠是空的。改用舊文本身抽詞去搜；
            # 沒有新文，「找不到再退文脈」的退路沒有意義，不做退路。
            fragments = fuzzy.deleted_fragments(change.get("old_text") or "")
            search_mode = "片段"
            whole_only = False
        else:
            fragments = fuzzy.changed_fragments(
                change.get("old_text") or "", change["text"], diff_runs)
            search_mode = "片段"
            whole_only = False
            if not fragments:
                # 一字之差（五→七）沒有片段可搜，改用改動處左右文脈
                fragments = fuzzy.context_fragments(change.get("old_text") or "", change["text"], diff_runs)
                search_mode = "文脈"
                whole_only = True
        # reference_text：同樣命中幾個字的段，跟這處異動整段比較像的排前面（不再照段次截）
        extra_counts = {}
        extra = fuzzy.find_by_changed_text(
            fragments, new_paragraphs,
            exclude_index=change["line_number"], contexts=contexts,
            synonyms=synonyms, normalize=normalize_terms,
            extract_article_no=extract_article_no,
            format_scope=fuzzy.format_scope, top=changed_top, whole_only=whole_only,
            reference_text=change["text"], counts=extra_counts)
        # 片段抽得出來、但拿去搜是 0 筆：以前就整條放棄，連一個字都不印。
        # 實測（should_fix no 34）「三十日」→「六十日」抽得到片段「六十」，
        # 但全文只有這一處寫「六十」，搜 0 筆；真正該找的是講「日內繳納」的
        # 那幾條——那是文脈才搜得到的。所以片段這一路空手時要退文脈再搜一次，
        # 不是只有「抽不出片段」才退。（刪除型沒有新文，不做這個退路。）
        if not extra and fragments and not change.get("deleted") and search_mode == "片段":
            context_pieces = fuzzy.context_fragments(
                change.get("old_text") or "", change["text"], diff_runs)
            if context_pieces:
                fragments = context_pieces
                search_mode = "文脈"
                whole_only = True
                extra = fuzzy.find_by_changed_text(
                    fragments, new_paragraphs,
                    exclude_index=change["line_number"], contexts=contexts,
                    synonyms=synonyms, normalize=normalize_terms,
                    extract_article_no=extract_article_no,
                    format_scope=fuzzy.format_scope, top=changed_top,
                    whole_only=whole_only, reference_text=change["text"], counts=extra_counts)
        # 舊值：被換掉的字別處還原樣留著（定義改名、表格裡的「三日內」）。只拿新字搜找不到這些
        old_values = []
        old_counts = {}
        if not change.get("deleted") and change.get("old_text"):
            old_terms = fuzzy.old_value_fragments(change["old_text"], change["text"], diff_runs)
            old_values = fuzzy.find_by_old_value(
                old_terms, change["old_text"], new_paragraphs,
                exclude_index=change["line_number"], kinds=new_kinds,
                contexts=contexts, top=changed_top, counts=old_counts)
            if baseline:
                for hit in old_values:
                    baseline.apply_candidate_identity(hit, new_line_ids)
            if old_values:
                print("── 被換掉的舊字別處還在 ──")
                for hit in old_values:
                    print("   %s：%s" % (fuzzy.scoped_label(hit["scope"], hit["article_no"], hit["line_number"]),
                                      "".join("「%s」" % t for _, t in hit["matched"])))
                if old_counts.get("unlisted"):
                    print("   另有 %d 段舊字也還在，因每處上限沒列（列的是上下文跟舊文最像的那幾段）"
                          % old_counts["unlisted"])
        if baseline:
            for hit in extra:
                baseline.apply_candidate_identity(hit, new_line_ids)
        fuzzy.print_changed_text_hits(fragments, extra, unlisted=extra_counts.get("unlisted", 0))
        # 候選明細「這次改動的片段」欄（決定表不讀這一欄）補一句被上限擠掉幾段，
        # 只看候選明細的人也知道這幾列不是全部
        extra_note = ("（另有 %d 段因上限沒列）" % extra_counts["unlisted"]
                      if extra_counts.get("unlisted") else "")
        old_note = ("（另有 %d 段因上限沒列）" % old_counts["unlisted"]
                    if old_counts.get("unlisted") else "")
        unlisted = extra_counts.get("unlisted", 0) + old_counts.get("unlisted", 0)
        if unlisted:
            unlisted_total += unlisted
            unlisted_changes += 1
        for hit in old_values:
            changed_rows.append([
                change["article_no"], change.get("type") or "", change["text"],
                "、".join(t for _, t in hit["matched"]) + old_note, hit.get("scope", ""),
                hit["article_no"], hit["line_number"], hit["text"],
                "、".join(t for _, t in hit["matched"]), "",
                "定義" if hit["definition"] else "舊值",
                change.get("position", ""),
            ])
        if not candidates and not extra and not old_values:
            # 三路（整條相似、改動片段、改動處文脈）全部 0 筆。以前整條靜默跳過，
            # 人看不出「這條是真的沒有連帶條文」還是「工具根本沒搜」。
            # 只 print 不發 notice：每條沒中的都發一則會把 提醒.txt 洗掉。
            print("  這一條找不到任何候選（整條、片段、文脈都 0 筆）")
        for hit in extra:
            changed_rows.append([
                change["article_no"], change.get("type") or "", change["text"],
                "、".join(fragments) + extra_note, hit.get("scope", ""),
                hit["article_no"], hit["line_number"], hit["text"],
                "、".join(t for _, t in hit["matched"]), "", search_mode,
                change.get("position", ""),
            ])

        # 句子層級：改到的那一句去比全文每一句
        if sentence_threshold and sentence_threshold > 0:
            # 刪除段沒有新文；new_text 傳空字串，changed_sentences 才會退回
            # 「舊文最長前 limit 句」，而不是拿舊文跟自己比出空結果。
            sentence_new_text = "" if change.get("deleted") else change["text"]
            sentences = fuzzy.changed_sentences(change.get("old_text") or "", sentence_new_text, diff_runs)
            # changed_text：兩邊都只有一句時不再比（那就是整段相似那一路），見 find_by_sentence
            sentence_hits = fuzzy.find_by_sentence(
                sentences, new_paragraphs, threshold=sentence_threshold,
                top=top, exclude_index=change["line_number"],
                contexts=contexts, synonyms=synonyms, changed_text=change["text"])
            if baseline:
                for hit in sentence_hits:
                    baseline.apply_candidate_identity(hit, new_line_ids)
            for hit in sentence_hits:
                sentence_rows.append([
                    change["article_no"], hit["changed_sentence"], hit.get("scope", ""),
                    hit["article_no"], hit["line_number"], hit["matched_sentence"],
                    hit["sentence_score"], hit["text"], "、".join(hit.get("synonym_evidence") or []),
                ])
            print("  句子層級候選 %d 筆" % len(sentence_hits))

        for candidate in candidates:
            csv_rows.append([
                change["article_no"], change.get("type") or "", change["text"],
                candidate.get("scope", ""), candidate["article_no"],
                candidate["line_number"], candidate["text"],
                candidate["similarity"], candidate["fragment_len"],
                candidate.get("fragment_position", ""),
                candidate["common_fragment"],
                "、".join(candidate.get("synonym_evidence", [])),
                candidate.get("coverage", ""),
                candidate.get("difference", ""),
                candidate.get("context_before", ""),
                candidate.get("context_after", ""), "",
                change.get("position", ""),
            ])

    # 以前這裡另寫一份 候選明細.xlsx（三張表）：候選已經全部進連帶決定表、檢視報告，
    # 沒有程式讀它，不再產生。
    produced = []

    # 三條路各抓到幾筆要分開報（小瑕疵 12）。以前只印「共列出 N 筆候選」，
    # 而那個 N 只算整段相似那一路——片段／文脈與句子層級抓到的全部沒被算進去，
    # 決定表上卻看得到，兩個數字對不起來，人會以為表上多出來的列是哪裡冒出來的。
    print("\n候選：整段相似 %d、片段／文脈 %d、句子 %d。"
          "提醒：這是輔助抓取的建議，不保證完整覆蓋，最終仍需人工確認。"
          % (len(csv_rows), len(changed_rows), len(sentence_rows)))
    if unlisted_total:
        # 一則總結就好（每處各發一則會把 提醒.txt 洗掉）；畫面上每處都已經印了另有幾段
        nt.notice(nt.REMINDER,
                  "片段／文脈／舊值搜尋：%d 處異動命中的段超過每處上限 %d 段，另有 %d 段因上限沒列"
                  "（列的是命中最強的那幾段；要看全部可加大 --changed-top，或 0＝不限）"
                  % (unlisted_changes, changed_top, unlisted_total), "Step 2")
    return csv_rows, changed_rows, sentence_rows, produced


def add_compare_arguments(parser):
    """compare 用的全部參數。reg 總入口的 compare／finalize 子命令也用這一組。"""
    parser.add_argument("old_file", help="舊版內規檔案（.docx / .txt / .md）")
    parser.add_argument("new_file", help="新版內規檔案（.docx / .txt / .md）")
    parser.add_argument("--outdir", default="", help="輸出資料夾")
    parser.add_argument("--prefix", default="", help="輸出檔名前綴")
    parser.add_argument("--title", default="修正對照表", help="修正對照表 Word 檔的標題")
    parser.add_argument("--apply-renumber", action="store_true",
                        help="實際重編款目編號（預設只檢查不動）")
    parser.add_argument("--rewrite-refs", action="store_true",
                        help="連可機械式改寫的交叉引用一起改；引用到已刪除款目的一律不動")
    parser.add_argument("--threshold", type=float, default=fuzzy.DEFAULT_THRESHOLD,
                        help="Step 2 相似度門檻，預設 %g" % fuzzy.DEFAULT_THRESHOLD)
    parser.add_argument("--top", type=int, default=fuzzy.DEFAULT_TOP,
                        help="每個異動段落最多列幾筆候選，預設 %d" % fuzzy.DEFAULT_TOP)
    parser.add_argument("--synonyms", default=None, help="同義詞表路徑，預設用 設定.html 的「同義詞表」")
    parser.add_argument("--no-synonyms", action="store_true", help="關閉同義詞正規化，只做純字面比對")
    parser.add_argument("--context", type=int, default=1,
                        help="候選條文附帶前後各幾段，預設 1；設 0 表示不附")
    parser.add_argument("--changed-top", type=int, default=8,
                        help="「以改動文字搜尋全文」最多列幾條，預設 8；設 0 表示不限筆數")
    parser.add_argument("--sentence-threshold", dest="sentence_threshold", type=float,
                        default=fuzzy.DEFAULT_SENTENCE_THRESHOLD,
                        help="句子層級比對門檻，預設 %g；設 0 關閉" % fuzzy.DEFAULT_SENTENCE_THRESHOLD)
    parser.add_argument("--terms", default=None, help="自訂用語混用對照表（JSON，二維陣列）")
    parser.add_argument("--format", default=None, help="對照表版面設定檔，預設用 設定.html 的「對照表版面」")
    parser.add_argument("--baseline-release", default=None,
                        help="diff-cut S12 發布根目錄；必須含 LATEST.json")
    return parser


# 新舊版完全沒有實質差異時要講的那一句（裁定 7）。
# 為什麼一定要講：0 異動最常見的原因不是「這次真的沒改」，而是把同一份檔案放了兩次、
# 或新舊版拿反了之後又挑到同一本。畫面上原本只會印「實質異動 0 處」＋「下一步：用
# Excel 開連帶決定表」，使用者於是去開一張空表，填不出東西又不知道是哪裡錯。
ZERO_CHANGE_TEXT = ("新舊版沒有任何實質差異，可能拿錯檔或放了同一份；"
                    "本次不產生候選，也不需要填連帶決定表")


def zero_change_notice(args, results):
    """新舊版一處差異都沒有時發一則提醒並回傳 True；有任何差異就回傳 False。

    等級由呼叫端用 args.zero_change_level 決定（裁定 7）：
        單本 compare  警告（預設）——這是「可能拿錯檔」，要看得見
        批次的每一本  提醒——沒改的本在批次裡很正常，不能因此翻轉整批的結論
        終比對        None（不發）——finalize 比的是「原始草稿 → 套用後乾淨版」，
                      決定表一列都沒填時 0 異動是正常結果，不是拿錯檔
    文字可用 args.zero_change_text 換掉（例如批次裡「這本根本沒有草稿」）。
    這一則必須在 run_compare 內部發，才會進到這一本自己的 提醒.txt。
    """
    # 「三個數字全部是零」指的是實質異動三類；但編號調整（renumbered）與字形差異
    # （cosmetic）也是「兩份檔不一樣」的證據——只要有一處，這兩份就不可能是同一份檔，
    # 拿錯檔的推論不成立。以前只看三類，條號整批位移的那一本會同時印
    # 「條層級編號調整…必須複核」與「沒有任何實質差異，可能拿錯檔」兩則互相矛盾的
    # 警告，批次還把它列進「無異動 N 本」，看的人以為那本不用處理。
    if [r for r in results
            if r["type"] in ("added", "deleted", "modified", "renumbered", "cosmetic")]:
        return False
    level = getattr(args, "zero_change_level", nt.WARNING)
    if level:
        nt.notice(level, getattr(args, "zero_change_text", "") or ZERO_CHANGE_TEXT,
                  "Step 1 比對")
    return True


def notice_text_box_changes(old_file, new_file):
    """文字方塊裡的字不比對、不標註（見 _common.read_docx_stdlib）。新舊版的方塊文字拿來比一次：
    一樣就不講；不一樣才提醒，並舉第一處讓人知道去哪裡看。"""
    from _common import docx_text_boxes
    import difflib
    old, new = docx_text_boxes(old_file), docx_text_boxes(new_file)
    if old == new:
        return
    ops = [op for op in difflib.SequenceMatcher(None, old, new, autojunk=False).get_opcodes()
           if op[0] != "equal"]
    tag, i1, i2, j1, j2 = ops[0]
    sample = "「%s」→「%s」" % ("／".join(old[i1:i2])[:30] or "（無）", "／".join(new[j1:j2])[:30] or "（無）")
    nt.notice(nt.REMINDER,
              "%s 的文字方塊有 %d 處內容跟現行版不同（例：%s）。方塊裡的字程式不比對、不標註，請人工確認"
              % (os.path.basename(new_file), len(ops), sample), "讀檔")


def run_compare(args):
    banner("內規修正比對　單次執行")
    print("舊版：%s" % args.old_file)
    print("新版：%s" % args.new_file)

    # 一次比對就是一次作業：先清空，這一本的 提醒.txt 才不會混進上一本的提醒
    # （批次是同一個 process 一本一本跑的）。
    nt.reset()
    # 環境層的提醒要趕在 條文檢查報告 寫出去之前發，不然那張表會少一列。
    if not fuzzy.HAS_RAPIDFUZZ:
        nt.notice(nt.REMINDER,
                  "這個環境沒有 rapidfuzz，改用 Python 內建的 difflib 比對；"
                  "結果相近但不完全相同，實測大型內規的候選數約少 7%，"
                  "人工複核時請留意可能有少數候選沒被列出", "環境")
    warn_if_versions_swapped(args.old_file, args.new_file)
    # 連「這一段是本文還是表格儲存格」一起讀出來：表格的表頭格、備註格不能被
    # 算成前一條的「第X項」，那會在正式修正對照表上寫出不存在的條號。
    old_paragraphs, old_kinds, old_metadata = read_paragraphs_with_metadata(args.old_file)
    new_paragraphs, new_kinds, new_metadata = read_paragraphs_with_metadata(args.new_file)
    print("舊版 %d 段、新版 %d 段" % (len(old_paragraphs), len(new_paragraphs)))
    check_paragraph_counts(old_paragraphs, new_paragraphs,
                           args.old_file, args.new_file)
    notice_text_box_changes(args.old_file, args.new_file)

    baseline = None
    if args.baseline_release:
        # 規格包的全文是 S1P 匯出的（含 Word 自動編號）：對位用同一種結構文字，段次照舊
        baseline = load_baseline_release(args.baseline_release, args.old_file,
                                         old_paragraphs=structure_view(old_paragraphs, old_kinds)[0])
        print("已驗證 diff-cut 正式基準：%s（%d 筆條文；內容定位 %d，無法定位 %d）"
              % (baseline.version, len(baseline.items),
                 baseline.binding_stats["已定位"], baseline.binding_stats["無法定位"]))
        if baseline.binding_stats["無法定位"]:
            nt.notice(nt.REMINDER,
                      "正式基準有 %d 筆條文無法定位到舊版段落，這幾筆的連帶複核只能靠"
                      "規格包本身的資料，位置與段次對不上舊版全文，請人工確認"
                      % baseline.binding_stats["無法定位"], "Step 1.2")

    _last_step.clear()
    new_paragraphs = step_renumber(
        old_paragraphs, new_paragraphs, args.apply_renumber, args.rewrite_refs,
        old_kinds=old_kinds, new_kinds=new_kinds)

    produced = []
    review_rows = []
    results, files = step_diff(old_paragraphs, new_paragraphs,
                               args.outdir, args.prefix, args.title,
                               load_table_format(args.format),
                               source_docx=args.new_file, baseline=baseline,
                               old_kinds=old_kinds, new_kinds=new_kinds,
                               old_metadata=old_metadata, new_metadata=new_metadata,
                               reasons=getattr(args, "reason_fn", None))
    produced += files

    # 「一處差異都沒有」要在這裡就講（趕在 條文檢查報告 與 提醒.txt 寫出去之前），
    # 不然使用者拿到的只有「實質異動 0 處」這個數字，沒有人告訴他這通常代表拿錯檔。
    # 注意：只有編號調整或字形差異的那一本不算——那兩份檔確實不一樣，不是拿錯檔。
    zero_change = zero_change_notice(args, results)

    if baseline:
        banner("Step 1.2　正式規格包連帶複核")
        base = os.path.splitext(
            resolve_output(args.outdir, args.prefix, "規格包連帶複核.xlsx"))[0]
        review_rows, files = baseline.write_review_table(results, base)
        located = len(set(row["異動條文ID"] for row in review_rows
                          if row["異動條文ID"]))
        unmapped = sum(row["關聯類型"] == "無舊版條文ID" for row in review_rows)
        print("已用基準版定位 %d 筆異動條文，展開 %d 列複核資料；"
              "另有 %d 筆沒有舊版ID。" % (located, len(review_rows), unmapped))
        print("條文ID與位置來自正式基準；連帶關係仍須和 Step 2 新候選一起人工判斷。")
        produced += files

    rule_findings, files = step_rule_checks(
        old_paragraphs, new_paragraphs, results, args.outdir, args.prefix,
        load_term_groups(args.terms, rule_checks.DEFAULT_TERM_GROUPS),
        old_kinds=old_kinds, new_kinds=new_kinds, health=bool(getattr(args, "health", False)))
    produced += files

    synonyms = [] if args.no_synonyms else load_synonyms(args.synonyms)
    csv_rows, changed_rows, sentence_rows, files = step_duplicates(
        new_paragraphs, results, args.outdir, args.prefix,
        args.threshold, args.top, synonyms,
        context_span=args.context,
        changed_top=args.changed_top, baseline=baseline,
        sentence_threshold=args.sentence_threshold, new_kinds=new_kinds)
    produced += files

    # 重編過的話，把結果也寫出來，否則使用者手上沒有那份修好編號的全文
    if args.apply_renumber:
        path = resolve_output(args.outdir, args.prefix, "重編後_新版全文.txt")
        with open(path, "w", encoding="utf-8") as f:
            f.write("\n".join(new_paragraphs) + "\n")
        print("\n已產生重編後全文：%s" % path)
        produced.append(path)

    # 收尾：把這次印過的提醒全部寫成一個檔。畫面會被截斷、會被往上捲走，
    # 產出資料夾裡的這一份才是留得住的。一則都沒有也照寫，讓人看得出是真的沒有。
    notice_path = nt.write_notices(args.outdir, args.prefix)
    print("\n本次提醒 %d 則，已留底：%s" % (len(nt.collected()), notice_path))
    produced.append(notice_path)

    return {"results": results, "csv_rows": csv_rows, "changed_rows": changed_rows,
            "sentence_rows": sentence_rows,
            # 這一本是不是一處差異都沒有（實質異動、編號調整、字形差異全是 0）。
            # 呼叫端要靠它決定「下一步」那一句怎麼寫、
            # 批次摘要要不要把它算進「無異動 N 本」。
            "零異動": zero_change,
            "review_rows": review_rows, "produced": produced,
            "old_paragraphs": old_paragraphs, "new_paragraphs": new_paragraphs,
            # 段落的來源種類（"p"／"cell"）：跨本比對、審查包要用同一份層級脈絡
            "old_kinds": old_kinds, "new_kinds": new_kinds,
            "baseline": baseline,
            # Step 0.5 的章節引用（目標換號或被刪的）：呼叫端把它們併進連帶決定表
            "章節引用": list(_last_step.get("章節引用") or []),
            # Step 0.5 的條、款、項引用與「內容變了」，Step 1.6 的定義變更連動與定義刪除：同上
            "條文引用": dict(_last_step.get("條文引用") or {}),
            "定義連動": [f for f in rule_findings
                     if f["check"] in rule_checks.DEFINITION_LINK_CHECKS]}

