# -*- coding: utf-8 -*-
"""純 stdlib 寫 .xlsx（這台電腦沒有 openpyxl，而且我們不裝套件）。
.xlsx 就是一個 zip，裡面幾個 XML。只做報告需要的：多工作表、inline 字串、數字格、
一種字型（微軟正黑體 11）、靠左垂直置中自動換行、標題列粗體、欄寬照內容算。"""
import csv, io, os, re, sys, unicodedata, zipfile
from xml.sax.saxutils import escape

_REGDIFF = os.path.join(os.path.dirname(os.path.abspath(__file__)), "regdiff")
if _REGDIFF not in sys.path:
    sys.path.insert(0, _REGDIFF)
from _common import XML_CLEANUP_NOTICE, sanitize_for_xml, stable_zip_info
import notices as nt

_CTRL = re.compile(r"[\x00-\x08\x0b\x0c\x0e-\x1f]")

# 這一份 .xlsx 清掉了幾個 XML 不合法字元。_CTRL 只清低位控制字元，U+FFFE、
# U+FFFF 與未配對代理字照樣寫進去——.xlsx 打不開，程式卻回報成功、exit 0
# （實測 no 32）。寫完一份發一則提醒，不是每一格一則。
_XML_CLEANED = [0]
_CELL_LIMIT = 32767      # Excel 儲存格上限
_CELL_KEEP = 32000       # 截斷後留的長度，留空間給截斷提示
# 這一張工作表截斷了幾格（_sheet_xml 每張表開頭歸零）。有截斷的表另存一份完整的 csv。
_TRUNCATED = [0]
# 上一次 write_xlsx 因為截斷而另存的完整 csv（正式路徑），write_tables_or_csv 拿去併進回傳清單
_SPILLED = []


class XlsxOptionError(ValueError):
    """工作表選項格式不正確，不能改用 CSV 掩蓋設定錯誤。"""


class RichText:
    """同一個 Excel 儲存格內含一般文字與局部樣式的安全資料物件。

    ``runs`` 是 ``(文字, 樣式名稱)`` 的序列。目前只公開 ``red_underline``，
    用於人用報告標示真正有變動的字。``str()`` 一律回原文，CSV 退路與欄寬
    計算不會看到 Python 物件表示法。
    """

    def __init__(self, runs):
        normalized = []
        for run in runs or ():
            if isinstance(run, (list, tuple)) and len(run) == 2:
                text, style = run
            else:
                text, style = run, ""
            text = "" if text is None else str(text)
            if text:
                normalized.append((text, str(style or "")))
        self.runs = tuple(normalized)

    @property
    def text(self):
        return "".join(text for text, _style in self.runs)

    def __str__(self):
        return self.text

    def __len__(self):
        return len(self.text)

    def __contains__(self, value):
        return str(value) in self.text


def rich_text(value, highlight_ranges=()):
    """把原文字串與 0 起算、尾端不含的差異範圍組成 ``RichText``。

    重疊或相鄰範圍會合併；無效範圍安全略過。呼叫端只需提供原文與差異位置，
    不必自己處理 Excel XML。
    """
    text = "" if value is None else str(value)
    ranges = []
    for item in highlight_ranges or ():
        if not isinstance(item, (list, tuple)) or len(item) != 2:
            continue
        try:
            start, end = int(item[0]), int(item[1])
        except (TypeError, ValueError):
            continue
        start, end = max(0, start), min(len(text), end)
        if end > start:
            ranges.append((start, end))
    ranges.sort()
    merged = []
    for start, end in ranges:
        if merged and start <= merged[-1][1]:
            merged[-1] = (merged[-1][0], max(merged[-1][1], end))
        else:
            merged.append((start, end))
    if not merged:
        return RichText(((text, ""),))

    runs, cursor = [], 0
    for start, end in merged:
        if start > cursor:
            runs.append((text[cursor:start], ""))
        runs.append((text[start:end], "red_underline"))
        cursor = end
    if cursor < len(text):
        runs.append((text[cursor:], ""))
    return RichText(runs)


# 工作表選項只接受固定欄位。未知欄位一律擋下，避免拼錯後被靜默忽略。
_SHEET_OPTION_KEYS = frozenset(("freeze_header", "freeze_columns", "auto_filter", "row_styles", "hidden_rows",
                                "links", "column_widths"))
_ROW_STYLE_IDS = {
    "body": 1,
    "header": 2,
    "section": 3,
    "warn": 4,
    "danger": 5,
}
_LINK_STYLE_IDS = {
    "body": 6,
    "header": 7,
    "section": 8,
    "warn": 9,
    "danger": 10,
}
_CELL_REF_RE = re.compile(r"^\$?([A-Za-z]{1,3})\$?([1-9][0-9]*)$")
_MAX_EXCEL_COLUMN = 16384  # XFD
_MAX_EXCEL_ROW = 1048576


def truncate_note(sheet_name, csv_names=None):
    """某一格超過 Excel 上限被截斷時，格子裡留的那句提示（小瑕疵 17）。

    以前這句寫死成「全文見 _候選.csv」——那是「候選審查」那一張表的檔名，
    別張工作表被截斷時會把人指到一個跟它無關的檔案（「總結」表的長格子
    叫人去看 _候選.csv）。改成把**這一張工作表自己**的名字與對應的 csv
    寫進去，指到的才是真的有全文的那一份。

    csv_names：{工作表名: 該張表的 csv 檔名}。不給就用 write_tables_or_csv
    的預設命名（<同名>_<工作表名>.csv）。
    """
    target = (csv_names or {}).get(sheet_name) or ("_%s.csv" % sheet_name)
    return "…（已截斷，工作表「%s」的全文見同資料夾的 %s）" % (sheet_name, target)


def _csv_safe(value):
    """人會用 Excel 開的 CSV：格子以 = + - @ 或 tab／換行開頭時 Excel 會當公式算（「-」「=合計」變成 #NAME?
    或真的執行公式），前面補一個單引號讓它當文字。只用在這裡的退路 CSV（純給人看，程式不讀回）；
    決定表、AI 表程式會讀回去比指紋，不能動（審查 C14）。"""
    text = "" if value is None else str(value)
    return "'" + text if text[:1] in ("=", "+", "-", "@", "\t", "\r") else text


def _write_csv(path, header, rows):
    with io.open(path, "w", encoding="utf-8-sig", newline="") as f:
        writer = csv.writer(f)
        writer.writerow(header)
        for row in rows:
            writer.writerow([_csv_safe(cell) for cell in row])

def display_width(text):
    w = 0
    for ch in str(text):
        w += 2 if unicodedata.east_asian_width(ch) in ("W", "F") else 1
    return w

def column_widths(header, rows, lo=8, hi=80):
    # 欄數不能只看 header：像「總結」那種前面是兩欄統計、後面接一段 5 欄子表的參差列，
    # 資料列可能比 header 長，欄數要照最寬的那一列算，不然多出來的欄完全沒有 <col> 寬度。
    n = max(len(header), max((len(row) for row in rows), default=0))
    best = [0] * n
    for row in [header] + list(rows):
        for i in range(min(n, len(row))):
            for line in str(row[i] if row[i] is not None else "").split("\n"):
                best[i] = max(best[i], display_width(line))
    return [min(hi, max(lo, round(b * 1.1 + 2, 1))) for b in best]

def _col(i):  # 0 → A, 26 → AA
    s = ""
    i += 1
    while i:
        i, r = divmod(i - 1, 26)
        s = chr(65 + r) + s
    return s

def _clean_cell_text(value):
    """把一段儲存格文字清成 Excel XML 可接受的內容。"""
    text = ("" if value is None else str(value)).replace("\r", "")
    text = _CTRL.sub("", text)
    text, removed = sanitize_for_xml(text)
    _XML_CLEANED[0] += removed
    return text


def _rich_inline_string(value):
    """輸出 inline rich text；非標示文字沿用儲存格本身的字型。"""
    parts = []
    for text, run_style in value.runs:
        clean = _clean_cell_text(text)
        if not clean:
            continue
        properties = ""
        if run_style == "red_underline":
            properties = '<rPr><color rgb="FFFF0000"/><u/></rPr>'
        parts.append('<r>%s<t xml:space="preserve">%s</t></r>'
                     % (properties, escape(clean)))
    return "".join(parts) or '<t xml:space="preserve"></t>'


def _cell(ref, value, style, note=""):
    if isinstance(value, bool):
        value = str(value)
    if isinstance(value, int):
        return '<c r="%s" s="%d"><v>%d</v></c>' % (ref, style, value)
    if isinstance(value, float):
        # 分數這類欄要寫成數字格：寫成文字格的話，Excel 排序是照字串排（「9」排在「85」後面）
        return '<c r="%s" s="%d"><v>%s</v></c>' % (ref, style, repr(value))

    rich = value if isinstance(value, RichText) else None
    text = _clean_cell_text(rich.text if rich is not None else value)
    if len(text) > _CELL_LIMIT:
        # Excel 一格上限 32,767 字元，超過整份 .xlsx 打不開；全文另外看同名的
        # csv（沒有這個上限，見 truncate_note）。那份 csv 由 write_xlsx 真的寫出來
        # ——以前只有這句提示、沒有那個檔，截掉的字就不見了。
        text = text[:_CELL_KEEP] + note
        _TRUNCATED[0] += 1
        rich = None                 # 截斷後不可能再安全對回原差異位置
    if rich is not None:
        return '<c r="%s" s="%d" t="inlineStr"><is>%s</is></c>' % (
            ref, style, _rich_inline_string(rich))
    return '<c r="%s" s="%d" t="inlineStr"><is><t xml:space="preserve">%s</t></is></c>' % (
        ref, style, escape(text))

def _column_number(letters):
    """欄名轉成 1 起算數字，給儲存格座標驗證與排序使用。"""
    value = 0
    for letter in letters.upper():
        value = value * 26 + ord(letter) - ord("A") + 1
    return value


def _normal_cell_ref(value, label):
    """驗證單一 Excel 儲存格座標，並統一成沒有錨點符號的大寫形式。"""
    if not isinstance(value, str):
        raise XlsxOptionError("%s 必須是 Excel 儲存格座標，例如 A1" % label)
    match = _CELL_REF_RE.match(value.strip())
    if not match:
        raise XlsxOptionError("%s 不是有效的 Excel 儲存格座標：%r" % (label, value))
    letters, row_text = match.groups()
    column = _column_number(letters)
    row = int(row_text)
    if column > _MAX_EXCEL_COLUMN or row > _MAX_EXCEL_ROW:
        raise XlsxOptionError("%s 超出 Excel 工作表範圍：%s" % (label, value))
    return "%s%d" % (letters.upper(), row)


def _cell_ref_position(ref):
    """已正規化的儲存格座標回傳（列號、0 起算欄號）。"""
    match = _CELL_REF_RE.match(ref)
    return int(match.group(2)), _column_number(match.group(1)) - 1


def _safe_sheet_names(sheets):
    """產生 Excel 可接受而且不撞名的工作表名，保留原名到安全名的順序對應。"""
    used = set()
    names = []
    for index, (name, _header, _rows) in enumerate(sheets, 1):
        # 控制字元與 XML 不允許字元同樣不能留在工作表名裡，否則整份 xlsx 會壞掉。
        safe = re.sub(r"[\x00-\x1f\\\\/?*\[\]:]", "_", str(name))
        safe, _removed = sanitize_for_xml(safe, filler="_")
        safe = safe[:31] or "Sheet%d" % index
        base, serial = safe, 2
        # Excel 以不分大小寫的方式看工作表名，大小寫不同也必須避開。
        while safe.casefold() in used:
            suffix = "_%d" % serial
            safe = base[:31 - len(suffix)] + suffix
            serial += 1
        used.add(safe.casefold())
        names.append(safe)
    return names


def _sheet_location(sheet_name, cell_ref):
    """內部超連結位置；工作表名一律加引號，內含單引號時照 Excel 規則重複。"""
    return "'%s'!%s" % (sheet_name.replace("'", "''"), cell_ref)


def _prepare_sheet_options(sheet_options, sheets):
    """驗證工作表選項，並把超連結目標改成工作表索引，避免清理名稱後指錯表。"""
    if sheet_options is None:
        return [None] * len(sheets)
    if not isinstance(sheet_options, (list, tuple)):
        raise XlsxOptionError("sheet_options 必須是與 sheets 同順序的 list 或 tuple")
    if len(sheet_options) != len(sheets):
        raise XlsxOptionError("sheet_options 數量必須與 sheets 相同")

    originals = [name for name, _header, _rows in sheets]
    positions = {}
    for index, name in enumerate(originals):
        positions.setdefault(name, []).append(index)

    prepared = []
    for sheet_index, option in enumerate(sheet_options, 1):
        if option is None:
            prepared.append(None)
            continue
        if not isinstance(option, dict):
            raise XlsxOptionError("第 %d 個 sheet_options 必須是 dict 或 None" % sheet_index)
        unknown = set(option) - _SHEET_OPTION_KEYS
        if unknown:
            raise XlsxOptionError("第 %d 個 sheet_options 有不支援的欄位：%s"
                                  % (sheet_index, "、".join(sorted(map(str, unknown)))))

        values = {
            "freeze_header": option.get("freeze_header", False),
            "freeze_columns": option.get("freeze_columns", 0),
            "auto_filter": option.get("auto_filter", False),
            "row_styles": option.get("row_styles", {}),
            "hidden_rows": option.get("hidden_rows", ()),
            "links": option.get("links", []),
            "column_widths": option.get("column_widths"),
        }
        for key in ("freeze_header", "auto_filter"):
            if not isinstance(values[key], bool):
                raise XlsxOptionError("第 %d 個 sheet_options 的 %s 必須是 bool"
                                      % (sheet_index, key))
        freeze_columns = values["freeze_columns"]
        if isinstance(freeze_columns, bool) or not isinstance(freeze_columns, int) or not 0 <= freeze_columns <= 20:
            raise XlsxOptionError("第 %d 個 sheet_options 的 freeze_columns 必須是 0 到 20 的整數" % sheet_index)

        row_styles = values["row_styles"]
        if not isinstance(row_styles, dict):
            raise XlsxOptionError("第 %d 個 sheet_options 的 row_styles 必須是 dict"
                                  % sheet_index)
        checked_styles = {}
        for row, style in row_styles.items():
            if isinstance(row, bool) or not isinstance(row, int) or not 1 <= row <= _MAX_EXCEL_ROW:
                raise XlsxOptionError("第 %d 個 sheet_options 的 row_styles 列號必須是 1 到 %d 的整數"
                                      % (sheet_index, _MAX_EXCEL_ROW))
            if style not in _ROW_STYLE_IDS:
                raise XlsxOptionError("第 %d 個 sheet_options 的 row_styles 樣式不支援：%r"
                                      % (sheet_index, style))
            checked_styles[row] = style

        hidden_rows = values["hidden_rows"]
        if not isinstance(hidden_rows, (list, tuple, set, frozenset)):
            raise XlsxOptionError("第 %d 個 sheet_options 的 hidden_rows 必須是列號序列" % sheet_index)
        checked_hidden = set()
        for row in hidden_rows:
            if isinstance(row, bool) or not isinstance(row, int) or not 2 <= row <= _MAX_EXCEL_ROW:
                raise XlsxOptionError("第 %d 個 sheet_options 的 hidden_rows 列號必須是 2 到 %d 的整數"
                                      % (sheet_index, _MAX_EXCEL_ROW))
            checked_hidden.add(row)

        raw_widths = values["column_widths"]
        checked_widths = None
        if raw_widths is not None:
            if not isinstance(raw_widths, (list, tuple)):
                raise XlsxOptionError("第 %d 個 sheet_options 的 column_widths 必須是 list、tuple 或 None"
                                      % sheet_index)
            _name, header, rows = sheets[sheet_index - 1]
            columns = max(len(header), max((len(row) for row in rows), default=0))
            if len(raw_widths) != columns:
                raise XlsxOptionError("第 %d 個 sheet_options 的 column_widths 數量必須是 %d"
                                      % (sheet_index, columns))
            checked_widths = []
            for column_index, width in enumerate(raw_widths, 1):
                if isinstance(width, bool) or not isinstance(width, (int, float)) or not 0 < width <= 255:
                    raise XlsxOptionError("第 %d 個 sheet_options 的第 %d 個 column_widths 必須是 0 到 255 的數字"
                                          % (sheet_index, column_index))
                checked_widths.append(float(width))

        links = values["links"]
        if not isinstance(links, (list, tuple)):
            raise XlsxOptionError("第 %d 個 sheet_options 的 links 必須是 list 或 tuple"
                                  % sheet_index)
        checked_links = []
        seen_refs = set()
        for link_index, link in enumerate(links, 1):
            if not isinstance(link, dict):
                raise XlsxOptionError("第 %d 個 sheet_options 的第 %d 個 links 項目必須是 dict"
                                      % (sheet_index, link_index))
            keys = set(link)
            if keys == {"ref", "url"}:
                # 對外網址（查證來源）：只收 http／https，別的協定（file:、javascript:）一律不寫
                ref = _normal_cell_ref(link["ref"], "links[%d].ref" % link_index)
                url = link["url"]
                if not isinstance(url, str) or not re.match(r"^https?://[^\s<>\"]+$", url):
                    raise XlsxOptionError("links[%d].url 必須是 http(s) 網址" % link_index)
                if ref in seen_refs:
                    raise XlsxOptionError("第 %d 個 sheet_options 的 links 重複設定儲存格：%s"
                                          % (sheet_index, ref))
                seen_refs.add(ref)
                row, column = _cell_ref_position(ref)
                checked_links.append({"ref": ref, "row": row, "column": column, "url": url})
                continue
            required = frozenset(("ref", "target_sheet", "target_ref"))
            if keys != required:
                missing = required - keys
                extra = keys - required
                parts = []
                if missing:
                    parts.append("缺少 %s" % "、".join(sorted(missing)))
                if extra:
                    parts.append("多出 %s" % "、".join(sorted(map(str, extra))))
                raise XlsxOptionError("第 %d 個 sheet_options 的第 %d 個 links 項目格式錯誤（%s）"
                                      % (sheet_index, link_index, "；".join(parts)))
            ref = _normal_cell_ref(link["ref"], "links[%d].ref" % link_index)
            target_ref = _normal_cell_ref(link["target_ref"], "links[%d].target_ref" % link_index)
            target_sheet = link["target_sheet"]
            if not isinstance(target_sheet, str):
                raise XlsxOptionError("links[%d].target_sheet 必須是原工作表名稱字串" % link_index)
            candidates = positions.get(target_sheet, [])
            if not candidates:
                raise XlsxOptionError("links[%d].target_sheet 找不到原工作表名稱：%s"
                                      % (link_index, target_sheet))
            if len(candidates) != 1:
                raise XlsxOptionError("links[%d].target_sheet 指到重複的原工作表名稱：%s"
                                      % (link_index, target_sheet))
            if ref in seen_refs:
                raise XlsxOptionError("第 %d 個 sheet_options 的 links 重複設定儲存格：%s"
                                      % (sheet_index, ref))
            seen_refs.add(ref)
            row, column = _cell_ref_position(ref)
            checked_links.append({
                "ref": ref,
                "row": row,
                "column": column,
                "target_index": candidates[0],
                "target_ref": target_ref,
            })
        prepared.append({
            "freeze_header": values["freeze_header"],
            "freeze_columns": freeze_columns,
            "auto_filter": values["auto_filter"],
            "row_styles": checked_styles,
            "hidden_rows": checked_hidden,
            "links": checked_links,
            "column_widths": checked_widths,
        })
    return prepared


def _extended_styles_needed(options):
    """只有需要新樣式時才擴充 styles.xml，未給選項的舊輸出保持原樣。"""
    for option in options:
        if not option:
            continue
        if option["links"]:
            return True
        if any(style not in ("body", "header") for style in option["row_styles"].values()):
            return True
    return False


def _sheet_xml_old(header, rows, note=""):
    """舊版工作表 XML，供未給 sheet_options 時完全沿用。"""
    widths = column_widths(header, rows)
    out = ['<?xml version="1.0" encoding="UTF-8" standalone="yes"?>',
           '<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">',
           "<cols>"]
    for i, width in enumerate(widths):
        out.append('<col min="%d" max="%d" width="%s" customWidth="1"/>' % (i + 1, i + 1, width))
    out.append("</cols><sheetData>")
    for row_number, row in enumerate([header] + list(rows), 1):
        style = 2 if row_number == 1 else 1
        cells = "".join(_cell("%s%d" % (_col(column), row_number), value, style, note)
                        for column, value in enumerate(row))
        out.append('<row r="%d">%s</row>' % (row_number, cells))
    out.append("</sheetData></worksheet>")
    return "".join(out)


def _sheet_xml(header, rows, note="", option=None, sheet_names=None):
    """建立單張工作表 XML；option 為 None 時保留舊版輸出。"""
    if option is None:
        return _sheet_xml_old(header, rows, note)

    widths = option["column_widths"] or column_widths(header, rows)
    data_rows = [list(header)] + [list(row) for row in rows]
    links_by_row = {}
    for link in option["links"]:
        links_by_row.setdefault(link["row"], {})[link["column"]] = link

    out = ['<?xml version="1.0" encoding="UTF-8" standalone="yes"?>',
           '<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"'
           ' xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">']
    frozen_columns = option.get("freeze_columns") or 0
    if option["freeze_header"] or frozen_columns:
        # ySplit=1 固定表頭列；xSplit 固定左邊幾欄（往右捲看長文時，序號、判定還在畫面上）。
        # topLeftCell 指向凍結區之後的第一格，Excel 才會把凍結的列、欄留在原位。
        rows_frozen = 1 if option["freeze_header"] else 0
        first = "%s%d" % (_col(frozen_columns), rows_frozen + 1)
        pane = ("bottomRight" if rows_frozen and frozen_columns
                else "bottomLeft" if rows_frozen else "topRight")
        split = ((' xSplit="%d"' % frozen_columns) if frozen_columns else "") +                 ((' ySplit="%d"' % rows_frozen) if rows_frozen else "")
        out.append('<sheetViews><sheetView workbookViewId="0"><pane%s topLeftCell="%s" activePane="%s" state="frozen"/>'
                   '<selection pane="%s" activeCell="%s" sqref="%s"/></sheetView></sheetViews>'
                   % (split, first, pane, pane, first, first))
    out.append("<cols>")
    for index, width in enumerate(widths):
        out.append('<col min="%d" max="%d" width="%s" customWidth="1"/>'
                   % (index + 1, index + 1, width))
    out.append("</cols><sheetData>")

    row_numbers = list(range(1, len(data_rows) + 1))
    row_numbers.extend(sorted(row for row in links_by_row if row > len(data_rows)))
    for row_number in row_numbers:
        row = data_rows[row_number - 1] if row_number <= len(data_rows) else []
        row_style = option["row_styles"].get(
            row_number, "header" if row_number == 1 else "body")
        link_columns = links_by_row.get(row_number, {})
        cells = []
        for column, value in enumerate(row):
            ref = "%s%d" % (_col(column), row_number)
            style = (_LINK_STYLE_IDS[row_style] if column in link_columns
                     else _ROW_STYLE_IDS[row_style])
            cells.append(_cell(ref, value, style, note))
        # 參差列或表格外的連結格也要真的建立儲存格，藍色底線才會看得到。
        for column in sorted(column for column in link_columns if column >= len(row)):
            ref = "%s%d" % (_col(column), row_number)
            cells.append(_cell(ref, None, _LINK_STYLE_IDS[row_style], note))
        hidden = ' hidden="1"' if row_number in option["hidden_rows"] else ''
        out.append('<row r="%d"%s>%s</row>' % (row_number, hidden, "".join(cells)))
    out.append("</sheetData>")

    if option["auto_filter"] and widths:
        out.append('<autoFilter ref="A1:%s%d"/>' % (_col(len(widths) - 1), len(data_rows)))
    if option["links"]:
        out.append("<hyperlinks>")
        url_index = 0
        for link in option["links"]:
            if link.get("url"):
                url_index += 1           # 對外網址：r:id 對到這一張的 _rels（見 sheet_url_rels）
                out.append('<hyperlink ref="%s" r:id="rIdU%d"/>' % (link["ref"], url_index))
                continue
            location = _sheet_location(sheet_names[link["target_index"]], link["target_ref"])
            out.append('<hyperlink ref="%s" location="%s"/>'
                       % (link["ref"], escape(location, {'"': "&quot;"})))
        out.append("</hyperlinks>")
    out.append("</worksheet>")
    return "".join(out)


def sheet_url_rels(option):
    """這一張工作表的對外網址關係檔（xl/worksheets/_rels/sheetN.xml.rels）；沒有網址回 None。"""
    urls = [link["url"] for link in (option or {}).get("links") or [] if link.get("url")]
    if not urls:
        return None
    rels = ['<?xml version="1.0" encoding="UTF-8" standalone="yes"?>',
            '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">']
    for index, url in enumerate(urls, 1):
        rels.append('<Relationship Id="rIdU%d" Type="http://schemas.openxmlformats.org/officeDocument/2006/'
                    'relationships/hyperlink" Target="%s" TargetMode="External"/>'
                    % (index, escape(url, {'"': "&quot;"})))
    rels.append("</Relationships>")
    return "".join(rels)


def _styles_xml_old(font_name, font_size):
    return ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            '<styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">'
            '<fonts count="2"><font><sz val="%(s)s"/><name val="%(f)s"/></font>'
            '<font><b/><sz val="%(s)s"/><name val="%(f)s"/></font></fonts>'
            '<fills count="2"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill></fills>'
            '<borders count="1"><border><left/><right/><top/><bottom/><diagonal/></border></borders>'
            '<cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs>'
            '<cellXfs count="3">'
            '<xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/>'
            '<xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0" applyFont="1" applyAlignment="1"><alignment horizontal="left" vertical="center" wrapText="1"/></xf>'
            '<xf numFmtId="0" fontId="1" fillId="0" borderId="0" xfId="0" applyFont="1" applyAlignment="1"><alignment horizontal="left" vertical="center" wrapText="1"/></xf>'
            '</cellXfs><cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles></styleSheet>'
            ) % {"f": escape(str(font_name), {'"': "&quot;"}), "s": font_size}


def _styles_xml(font_name, font_size, extended=False):
    """建立樣式表；前三個樣式保持不變，新增樣式只在有選項時附加。"""
    if not extended:
        return _styles_xml_old(font_name, font_size)
    font = escape(str(font_name), {'"': "&quot;"})
    # style 0／1／2 的 XML 與舊版相同。3～5 是列樣式，6～10 是相同列樣式的藍色底線連結版。
    return ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            '<styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">'
            '<fonts count="4">'
            '<font><sz val="%(s)s"/><name val="%(f)s"/></font>'
            '<font><b/><sz val="%(s)s"/><name val="%(f)s"/></font>'
            '<font><color rgb="FF0000FF"/><u/><sz val="%(s)s"/><name val="%(f)s"/></font>'
            '<font><b/><color rgb="FF0000FF"/><u/><sz val="%(s)s"/><name val="%(f)s"/></font>'
            '</fonts>'
            '<fills count="5">'
            '<fill><patternFill patternType="none"/></fill>'
            '<fill><patternFill patternType="gray125"/></fill>'
            '<fill><patternFill patternType="solid"><fgColor rgb="FFD9EAD3"/><bgColor indexed="64"/></patternFill></fill>'
            '<fill><patternFill patternType="solid"><fgColor rgb="FFFFF2CC"/><bgColor indexed="64"/></patternFill></fill>'
            '<fill><patternFill patternType="solid"><fgColor rgb="FFF4CCCC"/><bgColor indexed="64"/></patternFill></fill>'
            '</fills>'
            '<borders count="1"><border><left/><right/><top/><bottom/><diagonal/></border></borders>'
            '<cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs>'
            '<cellXfs count="11">'
            '<xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/>'
            '<xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0" applyFont="1" applyAlignment="1"><alignment horizontal="left" vertical="center" wrapText="1"/></xf>'
            '<xf numFmtId="0" fontId="1" fillId="0" borderId="0" xfId="0" applyFont="1" applyAlignment="1"><alignment horizontal="left" vertical="center" wrapText="1"/></xf>'
            '<xf numFmtId="0" fontId="0" fillId="2" borderId="0" xfId="0" applyFont="1" applyFill="1" applyAlignment="1"><alignment horizontal="left" vertical="center" wrapText="1"/></xf>'
            '<xf numFmtId="0" fontId="0" fillId="3" borderId="0" xfId="0" applyFont="1" applyFill="1" applyAlignment="1"><alignment horizontal="left" vertical="center" wrapText="1"/></xf>'
            '<xf numFmtId="0" fontId="0" fillId="4" borderId="0" xfId="0" applyFont="1" applyFill="1" applyAlignment="1"><alignment horizontal="left" vertical="center" wrapText="1"/></xf>'
            '<xf numFmtId="0" fontId="2" fillId="0" borderId="0" xfId="0" applyFont="1" applyAlignment="1"><alignment horizontal="left" vertical="center" wrapText="1"/></xf>'
            '<xf numFmtId="0" fontId="3" fillId="0" borderId="0" xfId="0" applyFont="1" applyAlignment="1"><alignment horizontal="left" vertical="center" wrapText="1"/></xf>'
            '<xf numFmtId="0" fontId="2" fillId="2" borderId="0" xfId="0" applyFont="1" applyFill="1" applyAlignment="1"><alignment horizontal="left" vertical="center" wrapText="1"/></xf>'
            '<xf numFmtId="0" fontId="2" fillId="3" borderId="0" xfId="0" applyFont="1" applyFill="1" applyAlignment="1"><alignment horizontal="left" vertical="center" wrapText="1"/></xf>'
            '<xf numFmtId="0" fontId="2" fillId="4" borderId="0" xfId="0" applyFont="1" applyFill="1" applyAlignment="1"><alignment horizontal="left" vertical="center" wrapText="1"/></xf>'
            '</cellXfs><cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles></styleSheet>'
            ) % {"f": font, "s": font_size}


def write_xlsx(path, sheets, font_name="微軟正黑體", font_size=11, csv_names=None,
               csv_dir=None, path_for=None, source="", sheet_options=None):
    """寫入多張工作表。

    sheets 維持 [(工作表名, header, rows), ...] 舊格式。sheet_options 與 sheets 同順序，
    每個元素可設定凍結表頭、篩選、列樣式與內部超連結；未給時沿用舊版 XML。
    csv_names、csv_dir、path_for 與 source 的行為不變，另存完整 csv 的路徑仍記在 _SPILLED。
    """
    sheets = [(str(name), list(header), list(rows)) for name, header, rows in sheets]
    # 先驗選項再開檔；設定錯誤時不會留下半份 zip，也不會讓 CSV 退路把錯誤吞掉。
    options = _prepare_sheet_options(sheet_options, sheets)
    safe_sheet_names = _safe_sheet_names(sheets)
    # 未給選項時保留舊版對工作表名的處理，避免既有輸出無端改名。
    if sheet_options is None:
        safe_sheet_names = []
        used = set()
        for index, (name, _header, _rows) in enumerate(sheets, 1):
            safe_name = re.sub(r'[\\/?*\[\]:]', "_", str(name))[:31] or "Sheet%d" % index
            base, serial = safe_name, 2
            while safe_name in used:
                suffix = "_%d" % serial
                safe_name = base[:31 - len(suffix)] + suffix
                serial += 1
            used.add(safe_name)
            safe_sheet_names.append(safe_name)
    _XML_CLEANED[0] = 0
    del _SPILLED[:]
    stem = os.path.splitext(os.path.basename(path))[0]
    names = {name: "%s_%s.csv" % (stem, name) for name, _header, _rows in sheets}
    names.update({str(key): value for key, value in (csv_names or {}).items() if value})
    truncated = []
    ct = ['<?xml version="1.0" encoding="UTF-8" standalone="yes"?>',
          '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">',
          '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>',
          '<Default Extension="xml" ContentType="application/xml"/>',
          '<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>',
          '<Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>']
    wb = ['<?xml version="1.0" encoding="UTF-8" standalone="yes"?>',
          '<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">']
    if any(option and (option["freeze_header"] or option["freeze_columns"]) for option in options):
        # 有凍結窗格時活頁簿也要宣告 bookViews，Excel 才能穩定辨識工作表檢視。
        wb.append('<bookViews><workbookView/></bookViews>')
    wb.append('<sheets>')
    rels = ['<?xml version="1.0" encoding="UTF-8" standalone="yes"?>',
            '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">']
    parts = {}
    for index, ((name, header, rows), safe_name, option) in enumerate(
            zip(sheets, safe_sheet_names, options), 1):
        ct.append('<Override PartName="/xl/worksheets/sheet%d.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>' % index)
        wb.append('<sheet name="%s" sheetId="%d" r:id="rId%d"/>'
                  % (escape(safe_name, {'"': "&quot;"}), index, index))
        rels.append('<Relationship Id="rId%d" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet%d.xml"/>' % (index, index))
        # 截斷提示用原始工作表名：人是照程式原本傳入的名稱找對應 csv，不是 Excel 清理後的名稱。
        _TRUNCATED[0] = 0
        parts["xl/worksheets/sheet%d.xml" % index] = _sheet_xml(
            header, rows, truncate_note(name, names), option, safe_sheet_names)
        url_rels = sheet_url_rels(option)
        if url_rels:
            parts["xl/worksheets/_rels/sheet%d.xml.rels" % index] = url_rels
        if _TRUNCATED[0]:
            truncated.append((name, header, rows, _TRUNCATED[0]))
    total_sheets = len(sheets)
    rels.append('<Relationship Id="rId%d" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/></Relationships>' % (total_sheets + 1))
    ct.append('</Types>')
    wb.append('</sheets></workbook>')
    parts['[Content_Types].xml'] = ''.join(ct)
    parts['_rels/.rels'] = ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
                            '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
                            '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>')
    parts['xl/workbook.xml'] = ''.join(wb)
    parts['xl/_rels/workbook.xml.rels'] = ''.join(rels)
    parts['xl/styles.xml'] = _styles_xml(
        font_name, font_size, extended=_extended_styles_needed(options))
    with zipfile.ZipFile(path, 'w', zipfile.ZIP_DEFLATED) as archive:
        for part_name in ('[Content_Types].xml', '_rels/.rels', 'xl/workbook.xml',
                          'xl/_rels/workbook.xml.rels', 'xl/styles.xml'):
            archive.writestr(stable_zip_info(part_name), parts[part_name].encode('utf-8'))
        for part_name in sorted(key for key in parts if key.startswith('xl/worksheets/')):
            archive.writestr(stable_zip_info(part_name), parts[part_name].encode('utf-8'))
    if _XML_CLEANED[0]:
        nt.notice(nt.REMINDER, XML_CLEANUP_NOTICE % _XML_CLEANED[0], '審查包 xlsx')
    _XML_CLEANED[0] = 0
    folder = csv_dir or os.path.dirname(os.path.abspath(path))
    for name, header, rows, count in truncated:
        final = os.path.join(folder, names[name])
        _write_csv((path_for or (lambda value: value))(final), header, rows)
        _SPILLED.append(final)
        nt.notice(nt.REMINDER,
                  '工作表「%s」有 %d 格超過 Excel 一格 %d 字的上限，xlsx 裡已截斷；'
                  '完整內容另存在同資料夾的 %s' % (name, count, _CELL_LIMIT, names[name]),
                  source or '產出表格')
    return path


def csv_names_for(base_path, sheets):
    """每張工作表退成 csv 時要叫什麼檔名（只有檔名，不含資料夾）。

    一張表就 <同名>.csv，多張表就 <同名>_<工作表名>.csv——多張表擠成同一個
    檔名會互相蓋掉，而「候選明細」那三張表正是要分開看的三件事。
    """
    base = os.path.basename(base_path)
    names = [str(name) for name, _h, _r in sheets]
    if len(names) == 1:
        return {names[0]: base + ".csv"}
    return {name: "%s_%s.csv" % (base, name) for name in names}


def _locked(path, exc):
    """xlsx 寫不進去是因為被 Excel 開著（PermissionError，或旁邊有 Excel 的 ~$ 鎖定檔）。"""
    lock = os.path.join(os.path.dirname(path), '~$' + os.path.basename(path))
    return isinstance(exc, PermissionError) or os.path.exists(lock)


def _remove_old_copies(base_path):
    """正式那一份寫成功了：Excel 開著時另存的「報告_HHMMSS.xlsx」舊副本清掉（還開著的刪不掉就留著）。"""
    folder = os.path.dirname(base_path) or '.'
    stem = os.path.basename(base_path)
    pattern = re.compile(r'^%s_\d{6}\.xlsx$' % re.escape(stem))
    try:
        names = os.listdir(folder)
    except OSError:
        return
    for name in names:
        if pattern.match(name):
            try:
                os.remove(os.path.join(folder, name))
            except OSError:
                pass


def write_tables_or_csv(base_path, sheets, source="", path_for=None, csv_names=None,
                        sheet_options=None):
    """給人看的表只出一種格式：先試 .xlsx，寫不出來才退 .csv。

    base_path 不帶副檔名。sheet_options 與 sheets 同順序，傳給 write_xlsx；設定格式錯誤
    會直接拋出 XlsxOptionError，不可改用 csv 掩蓋。其餘 OSError／ValueError 仍保留 csv 退路。
    """
    from _common import tw_now, tw_today
    path_for = path_for or (lambda path: path)
    sheets = [(str(name), list(header), list(rows)) for name, header, rows in sheets]
    folder = os.path.dirname(base_path)
    names = csv_names_for(base_path, sheets)
    names.update({str(key): value for key, value in (csv_names or {}).items() if key in names})
    xlsx_final = base_path + '.xlsx'
    target = path_for(xlsx_final)
    try:
        write_xlsx(target, sheets, csv_names=names, csv_dir=folder,
                   path_for=path_for, source=source, sheet_options=sheet_options)
        _remove_old_copies(base_path)
    except XlsxOptionError:
        # 設定錯誤是呼叫端的資料問題，不能寫成一份看似成功、實際少掉格式與連結的 csv。
        raise
    except (OSError, ValueError) as exc:
        if isinstance(exc, OSError) and _locked(xlsx_final, exc):
            # v1.11.0：報告正在 Excel 裡開著（Windows 鎖檔）。以前改出一堆 csv、叫人關 Excel 再重跑；
            # 現在改存成加時間的檔名，這一次的結果照樣是 xlsx，講清楚開哪一份
            import time
            other = '%s_%s.xlsx' % (base_path, tw_now().strftime('%H%M%S'))
            try:
                write_xlsx(path_for(other), sheets, csv_names=names, csv_dir=folder,
                           path_for=path_for, source=source, sheet_options=sheet_options)
            except (OSError, ValueError):
                pass
            else:
                message = ('%s 正在 Excel 裡開著，這次的結果存成 %s：關掉舊的那一份，打開這一份'
                           % (os.path.basename(xlsx_final), os.path.basename(other)))
                nt.notice(nt.REMINDER, message, source or '產出表格')   # notice 自己會印（v1.24.0：以前另外 print，同一句印兩次）
                return [other] + list(_SPILLED)
        # 半份 zip 一定要清掉：走 AtomicWrites 時那個 .tmp 會在收尾被當成這一次的產物搬走。
        # 上一輪的正式 xlsx 也要清掉，否則人可能打開舊報告，以為那是這一次的結果。
        for stale in (target, xlsx_final):
            try:
                if os.path.exists(stale):
                    os.remove(stale)
            except OSError:
                pass
        nt.notice(nt.REMINDER, 'xlsx 寫不出來（%s），已改出 csv' % exc,
                  source or '產出表格')
        written = []
        for name, header, rows in sheets:
            final = os.path.join(folder, names[name])
            _write_csv(path_for(final), header, rows)
            written.append(final)
        return written
    # 有格子被截斷的工作表另存了完整的 csv：也是這一次真的寫出來的檔，一起回報。
    return [xlsx_final] + list(_SPILLED)

