# -*- coding: utf-8 -*-
"""
法規追蹤報告：1_結果彙整/法規追蹤報告_YYYYMMDDNNN.xlsx（承辦看的，v1.28.0 起只放兩頁）

    依段落彙整     一列＝一段要處理的內規：相關法規、合起來的建議改法；引用版本過時的段也併在這裡（v1.28.0）
    段次總表       現行內規每一段；報告上的段次點下去就跳到這裡

過程明細另放 2_Log檔案/法規分析/法規追蹤明細_YYYYMMDDNNN.xlsx（v1.28.0 以前在報告裡）：
    法規影響報告   一列＝一條法規 × 一段內規：序號、AI判定、判定分數、判定理由……建議處理
    法規適用總表   一列＝一條法規：適用判斷、候選段數、未列入候選的段數、官方來源；適用的排前面
    來源查詢狀態   每一個來源抓得怎樣、缺了什麼、AI 補查了什麼

分數 0–3 的列、判不適用或重複的法規的列，移到最後並隱藏（篩選打開就看得到）；還沒匯入的列寫「AI 審查尚未完成」。
v1.4.0 一次出七個檔（兩份 xlsx 十五頁、md、json、docx），給程式讀的 json 也放在給人看的資料夾；這一版只出這一份。
"""

import csv
import io
import os
import re

import human_report as hr
import law_impact as li
import xlsx_writer as xw

REPORT_NAME = "法規追蹤報告"           # v1.26.0 以前叫 檢視報告（跟比對同名）；實際檔名接日期序號，見 report_base
PARAGRAPH_SHEET = "依段落彙整"
PARAGRAPH_HEADER = ["序號", "最高判定", "最高分數", "規章", "段次", "段落原文", "相關法規", "建議處理", "判定理由",
                    "事件ID"]
IMPACT_SHEET = "法規影響報告"
IMPACT_HEADER = ["序號", "AI判定", "判定分數(0-10)", "判定理由", "法規名稱", "條號", "公布或修正日", "法規原文",
                 "規章", "段次", "段落原文", "建議處理", "官方來源", "事件ID", "列ID"]
APPLY_SHEET = "法規適用總表"
APPLY_HEADER = ["序號", "事件ID", "法規名稱", "條號", "公布或修正日", "施行日", "效力", "適用判斷", "判斷理由",
                "候選段數", "未列入候選段數", "官方來源", "註記"]
SOURCE_SHEET = "來源查詢狀態"
SOURCE_HEADER = ["序號", "來源", "方式", "狀態", "取得異動筆數", "查詢時間", "範圍與缺漏"]
SEGMENT_SHEET = "段次總表"
SEGMENT_HEADER = ["規章", "版本", "段次", "位置", "全文"]
_WIDTHS = {"法規名稱": 22, "條號": 10, "公布或修正日": 12, "施行日": 12, "效力": 8, "事件ID": 8, "列ID": 8, "適用判斷": 9,
           "法規原文": 40, "段落原文": 50, "建議處理": 45, "官方來源": 30, "判斷理由": 45, "判定理由": 45,
           "候選段數": 9, "未列入候選段數": 10, "註記": 30, "來源": 24, "方式": 10, "狀態": 12, "取得異動筆數": 8,
           "查詢時間": 16, "範圍與缺漏": 50, "最高判定": 10, "最高分數": 8, "相關法規": 34,
           "引用的法規": 30, "手冊寫的版本": 12, "已知最新版": 12, "依據": 24}
# 不用逐段看的法規：它的候選列沒有分數，跟 0–3 分一起收到最後
SKIPPED_APPLICABILITY = ("不適用", "重複")
_APPLY_ORDER = {"適用": 0, "待確認": 1, "重複": 2, "不適用": 3}
# 建議改法本身就是一句「段612改為…」「將…改為…」：前面不再加「改成：」（以前變成「改成：段612改為：」）
_CHANGE_VERB = re.compile(r"^\s*(?:段\s*\d|改為|改成|將|把|於|在|刪除|刪去|增列|增訂|新增|補上|補列|加列|加註|「)")
SEARCH_LOG = "AI補查紀錄.csv"         # AI 上網補查了什麼（v1.18.0）：報告的「來源查詢狀態」照列
SEARCH_LOG_HEADER = ["序號", "查了什麼", "法規名稱", "最新修正日", "來源網址", "查詢日期", "結果", "處理"]
DETAIL_NAME = "法規追蹤明細"             # v1.28.0：法規影響報告、法規適用總表、來源查詢狀態放 2_Log檔案/法規分析/
VERSION_SHEET = "引用版本檢查"
VERSION_HEADER = ["序號", "規章", "段次", "段落原文", "引用的法規", "手冊寫的版本", "已知最新版", "建議處理", "依據", "官方來源"]


def _answers(output, state):
    """匯入過就用匯入的答案；還沒匯入就只有程式列（AI 欄空白）。回傳 (適用 {事件ID: 列}, 影響列 list)。"""
    accepted = state.get("accepted")
    if accepted:
        return dict((r["事件ID"], r) for r in accepted["適用"]), list(accepted["影響"])
    apply_rows, impact_rows = li._program_rows(state)
    return dict((r["事件ID"], r) for r in apply_rows), impact_rows


def _flat(text):
    return re.sub(r"[\s，。；、：「」（）()]", "", text or "")


def _suggestion(row, event):
    verdict, reason = row.get("AI判斷", ""), row.get("AI理由", "")
    if not verdict:
        return "等 AI 審查"
    if verdict == "建議修改":
        change = (row.get("建議改法") or "").strip()
        if not change:
            text = "請依 AI 判定修正"
        elif _CHANGE_VERB.match(change) or re.search(r"改為|改成", change[:30]):
            text = change          # v1.24.0：「標題改為…」本身就講了怎麼改，不再前面多加「改成：」
        else:
            text = "改成：%s" % change
        if row.get("法定期限"):
            text += "；法定期限 %s（依據：%s，請人工核對起算日）" % (row["法定期限"], row.get("期限依據", ""))
        return text
    if verdict == "需再檢查":
        action = hr._action_sentences(reason) or "請確認後處理"
        # 理由整句就是「請確認…」：建議處理不再一字不差重抄一次
        bare = re.sub(r"^\s*〔[^〕]*〕", "", reason or "")
        if _flat(action) in (_flat(hr._friendly_reason(reason)), _flat(bare)):
            # v1.23.1：理由整句只有一句時，取「請確認…」那一截當建議處理（以前一律寫「照判定理由確認後處理」，看不出要做什麼）
            asked = re.search(r"(請(?:確認|承辦|問|查|釐清|核對)[^。；;]*)", bare)
            return asked.group(1) if asked and len(asked.group(1)) < len(_flat(bare)) else "照判定理由確認後處理"
        return action
    return "不用改"


def _paragraph_text(titles, row):
    book = titles.get(row.get("規章", ""))
    line = row.get("段次", "")
    if book and str(line).isdigit() and 1 <= int(line) <= len(book["paragraphs"]):
        return book["paragraphs"][int(line) - 1]
    return ""


def _impact_page(state, apply_by, impact_rows):
    page = hr._page(IMPACT_SHEET, IMPACT_HEADER)
    events = li._events_by_number(state)
    titles = li._book_by_title(state)
    done = bool(state.get("accepted"))
    rows = []
    for row in impact_rows:
        event = events.get(row.get("事件ID"))
        if not event:
            continue
        line = row.get("段次", "")
        text = _paragraph_text(titles, row)
        reason = row.get("AI理由", "")
        apply_row = apply_by.get(row["事件ID"]) or {}
        applicability = apply_row.get("AI判斷", "")
        skipped = applicability in SKIPPED_APPLICABILITY
        if not row.get("AI判斷"):
            if applicability == "不適用":
                reason = "這條法規判不適用：%s" % (apply_row.get("AI理由") or "")
            elif applicability == "重複":
                reason = "這條法規跟另一條重複（同一次修正已在那一條判過）：%s" % (apply_row.get("AI理由") or "")
            else:
                reason = "AI 審查尚未完成：這一列還沒有 AI 判定。" if not done else "AI 未判"
        if row.get("列ID") == li.NEW_ROW and not row.get("規章"):
            text = "（內規沒有寫到這項義務；查證範圍：%s）" % (row.get("查證範圍") or "未寫")
        rows.append((int(row["事件ID"][1:]), [
            "", row.get("AI判斷", "") or ("不用改" if skipped else ""), row.get("AI分數", ""),
            hr._friendly_reason(reason), event["law_name"], event["article_no"], event["event_date"],
            row.get("法規原文", ""), row.get("規章", "") or "（新增義務）", line, text,
            _suggestion(row, event) if row.get("AI判斷") else ("不用改" if skipped else "等 AI 審查"),
            event["source_url"], row.get("事件ID", ""), row.get("列ID", "")]))
    # 分數高的排前面；同分照法規編號；還沒判的排在有分數的後面
    rows.sort(key=lambda item: (-(int(item[1][2]) if str(item[1][2]).isdigit() else -1), item[0]))
    for _, row in rows:
        hr._append(page, row)

    def quiet(row):
        score = str(row[2])
        if score.isdigit():
            return int(score) <= 3 and not hr._keeps_visible(row[3])
        return row[1] == "不用改"          # 判不適用、重複的法規：沒有逐段分數
    hr._move_rows_to_bottom(page, quiet)
    return page


def _paragraph_page(state, apply_by, impact_rows):
    """依段落彙整（v1.18.0）：同一段被好幾條法規各判一次（合作推廣規範第一點到第十點各一列）合成一列，
    列出相關法規與合起來的建議改法；只收 4 分以上（要人動手的）。"""
    page = hr._page(PARAGRAPH_SHEET, PARAGRAPH_HEADER)
    events = li._events_by_number(state)
    titles = li._book_by_title(state)
    groups = {}
    for row in impact_rows:
        score = str(row.get("AI分數", ""))
        event = events.get(row.get("事件ID"))
        if not event or not score.isdigit() or int(score) < 4 or not row.get("AI判斷"):
            continue
        if row.get("規章"):
            key = (row["規章"], str(row.get("段次", "")))
        else:
            key = ("（新增義務）", row["事件ID"])
        groups.setdefault(key, []).append((int(score), row, event))
    merged = []
    for (title, line), items in groups.items():
        items.sort(key=lambda item: (-item[0], int(item[1]["事件ID"][1:])))
        top_score, top_row, _ = items[0]
        laws = _law_list([e for _s, _r, e in items])
        actions = _unique_actions([_suggestion(r, e) for _s, r, e in items])
        reason_text = _merge_reasons([hr._friendly_reason(r.get("AI理由", "")) for _s, r, _e in items],
                                     [e["law_name"] for _s, _r, e in items])
        if title == "（新增義務）":
            text, shown_line = "（內規沒有寫到這項義務；查證範圍：%s）" % (top_row.get("查證範圍") or "未寫"), ""
        else:
            text, shown_line = _paragraph_text(titles, top_row), line
        merged.append((top_score, title, int(shown_line) if shown_line.isdigit() else 0, [
            "", top_row.get("AI判斷", ""), str(top_score), title, shown_line, text, "\n".join(laws),
            "\n".join(actions), reason_text, "、".join(dict.fromkeys(r["事件ID"] for _s, r, _e in items))]))
    _merge_version_rows(merged, state)
    merged.sort(key=lambda item: (-item[0], item[1], item[2]))
    for number, (_s, _t, _l, row) in enumerate(merged, 1):
        row[0] = str(number)
        hr._append(page, row)
    if not merged:
        hr._append(page, ["1", "", "", "（沒有要處理的段落）", "", "", "", "",
                          "這一輪沒有 4 分以上的列；0–3 分的細節在 2_Log檔案/法規分析/%s 的「法規影響報告」" % DETAIL_NAME, ""])
    return page


def _law_list(events):
    """相關法規（v1.28.0）：同一部法規的條號合成一行（「保險代理人管理規則 第21條、第33條之1」），不寫分數——
    分數在「最高分數」欄，每條各寫一次只是重複。"""
    order, articles = [], {}
    for event in events:
        name = event["law_name"]
        if name not in articles:
            order.append(name)
            articles[name] = []
        article = (event.get("article_no") or "").strip()
        if article and article not in articles[name]:
            articles[name].append(article)
    return ["%s %s" % (name, "、".join(sorted(articles[name], key=_article_order))) if articles[name] else name
            for name in order]


_CN_DIGITS = dict(zip("零一二三四五六七八九", range(10)))


def _cn_number(text):
    """「二十一」→21、「十」→10、「21」→21；看不懂回 None。"""
    if text.isdigit():
        return int(text)
    total, digit = 0, 0
    for ch in text:
        if ch in _CN_DIGITS:
            digit = _CN_DIGITS[ch]
        elif ch == "百":
            total += (digit or 1) * 100
            digit = 0
        elif ch == "十":
            total += (digit or 1) * 10
            digit = 0
        else:
            return None
    return total + digit


def _article_order(article):
    """條號照數字排（第一點、第二點…第十點；第21條、第33條之1、第49條）；看不懂的照原順序排在後面。"""
    hit = re.match(r"第\s*([0-9]+|[零一二三四五六七八九十百]+)\s*[條點](?:之\s*([0-9]+|[一二三四五六七八九十]+))?", article)
    if not hit:
        return (1, 0, 0)
    main = _cn_number(hit.group(1))
    sub = _cn_number(hit.group(2)) if hit.group(2) else 0
    return (0, main if main is not None else 0, sub or 0)


def _unique_actions(actions):
    """建議處理（v1.28.0）：一模一樣的只留一個；一句整句包含在另一句裡（另一句多補了幾句話）只留長的那句。"""
    actions = [a for a in dict.fromkeys(a for a in actions if a and a.strip())]
    flat = [_flat(a) for a in actions]
    keep = []
    for i, action in enumerate(actions):
        if any(j != i and flat[i] in flat[j] and (len(flat[j]) > len(flat[i]) or j < i) for j in range(len(actions))):
            continue
        keep.append(action)
    return keep


_OPENERS, _CLOSERS = "「『（(", "」』）)"


def _fragments(text):
    """理由切成小段（照 。；， 切，引號、括號裡的不切），每段帶著它後面的標點。"""
    parts, buf, depth = [], [], 0
    for ch in text or "":
        if ch in _OPENERS:
            depth += 1
        elif ch in _CLOSERS and depth:
            depth -= 1
        buf.append(ch)
        if ch in "。；，\n" and depth == 0:
            parts.append("".join(buf))
            buf = []
    if buf:
        parts.append("".join(buf))
    return parts


def _merge_reasons(reasons, law_names=()):
    """判定理由（v1.28.0）：好幾條法規的理由合在一段時，相同的句子只寫一次，每則只留它跟前面不一樣的部分；
    開頭跟「相關法規」重複的法規名稱（「保險代理人管理規則：」）拿掉；同一個〔標籤〕只寫第一次。
    以前同一段被合作推廣規範第一點到第十點各判一次，理由把同一大段抄十次（只放前三則，再寫「另有 8 則」）。"""
    names = sorted(set(n for n in law_names if n), key=len, reverse=True)
    seen, labels, out = set(), set(), []
    for reason in dict.fromkeys(r for r in reasons if r and r.strip()):
        text = reason.strip()
        for name in names:
            text = re.sub(r"^「?%s[^」：:]{0,20}」?[：:]\s*" % re.escape(name), "", text)
        kept = []
        for piece in _fragments(text):
            body = piece.strip()
            label = re.match(r"^〔[^〕]*〕", body)
            if label:
                if label.group(0) in labels:
                    body = body[label.end():].strip()
                labels.add(label.group(0))
            key = re.sub(r"[\s。；，、]", "", re.sub(r"^〔[^〕]*〕", "", body))
            if not key or key in seen:
                continue
            seen.add(key)
            kept.append(body)
        if kept:
            line = "".join(kept).rstrip("，；、 ")
            out.append(line if line.endswith(("。", "）", "」")) else line + "。")
    return "\n".join(out)


def _merge_version_rows(merged, state):
    """引用版本檢查（v1.28.0）併進依段落彙整：手冊括註的法規版本已不是最新的段。
    那一段本來就在表上：相關法規、建議處理、理由補上版本那一句；不在表上：多一列（排在 7 分的列後面）。"""
    import law_memory as lm
    paragraphs = [(book["title"], i + 1, text) for book in state["books"] for i, text in enumerate(book["paragraphs"])]
    rows = dict(((item[1], str(item[2])), item) for item in merged)
    for hit in lm.version_lag(paragraphs):
        key = (hit["規章"], str(hit["段次"]))
        action = "版本註記改成最新版（%s 修正），並確認摘錄的條文是否跟著改" % hit["已知最新版"]
        reason = "〔版本過時〕手冊寫的是 %s 的版本，已知最新是 %s 修正（依據：%s%s）" % (
            hit["手冊寫的版本"], hit["已知最新版"], hit["依據"], "；" + hit["來源"] if hit.get("來源") else "")
        if key in rows:
            row = rows[key][3]
            if hit["法規名稱"] not in row[6]:
                row[6] = "\n".join(x for x in (row[6], hit["法規名稱"]) if x)
            if "版本" not in row[8] and "最新版" not in row[7]:
                # 那一段的理由已經講版本過時（AI 判〔法源過時〕、改法寫了新版號）就不再補一次
                row[7] = "\n".join(x for x in (row[7], action) if x)
                row[8] = "\n".join(x for x in (row[8], reason) if x)
            continue
        line = str(hit["段次"])
        merged.append((7, hit["規章"], int(line) if line.isdigit() else 0, [
            "", "建議修改", "", hit["規章"], line, hit["全文"], hit["法規名稱"], action, reason, ""]))
        rows[key] = merged[-1]


def _same_notice(state):
    """同一則公告（網頁、附件 PDF）抓成好幾條：{事件ID: 其他事件ID list}。名稱與日期都一樣、沒有條號的才算。"""
    groups = {}
    for event in state["events"]:
        if not event.get("article_no"):
            groups.setdefault((event["law_name"], event["event_date"]), []).append(state["numbers"][event["id"]])
    found = {}
    for numbers in groups.values():
        if len(numbers) > 1:
            for number in numbers:
                found[number] = [n for n in numbers if n != number]
    return found


def _apply_notes(event, judged, twins):
    notes = event.get("notes") or ""
    if judged:
        # AI 已經讀過全文判斷：不再寫「需 AI 核對」（以前判完了還這樣寫，讀的人以為沒看過）
        notes = notes.replace("整份來源文件，需 AI 核對正文、附件與適用條件；", "整份公告全文（AI 已讀過判斷）；")
    parts = []
    if twins:
        parts.append("同一則公告另有 %s（網頁版／附件版）" % "、".join(twins))
    parts += [notes, "" if event["old_text"] else "舊條文待補，只做現況檢查"]
    return "；".join(filter(None, parts))


def _apply_page(state, apply_by):
    page = hr._page(APPLY_SHEET, APPLY_HEADER)
    dropped = state.get("candidate_dropped") or {}
    twins = _same_notice(state)
    rows = []
    for event in state["events"]:
        number = state["numbers"][event["id"]]
        row = apply_by.get(number) or {}
        verdict = row.get("AI判斷", "")
        rows.append((_APPLY_ORDER.get(verdict, 4), int(number[1:]), [
            "", number, event["law_name"], event["article_no"], event["event_date"],
            event["effective_date"], event["status"], verdict or "等 AI 審查",
            row.get("AI理由", ""), str(len(state["candidates"].get(event["id"], []))),
            str(dropped.get(event["id"], 0)), event["source_url"], _apply_notes(event, bool(verdict), twins.get(number))]))
    # 適用、待確認的排前面（以前照編號排，二十幾條適用的散在九十幾條不適用中間）
    rows.sort(key=lambda item: (item[0], item[1]))
    for _o, _n, row in rows:
        hr._append(page, row)
    for number, row in enumerate(page["rows"], 1):
        row[0] = str(number)
    if not state["events"]:
        hr._append(page, ["1", "", "（這一輪還沒有法規異動證據）", "", "", "", "", "", "查不到不等於沒有修法：AI 補查官方來源後用「法規補入」加入",
                          "", "", "", ""])
    return page


def _when(value):
    """2026-10-25T16:56:45+08:00 → 2026-10-25 16:56。"""
    found = re.match(r"(\d{4}-\d{2}-\d{2})[T ](\d{2}:\d{2})", str(value or ""))
    return "%s %s" % found.groups() if found else str(value or "")


def search_log_rows(output, strict=False):
    """AI補查紀錄.csv 的列（v1.18.0）。沒有這個檔回 []。"""
    path = os.path.join(li.ai_dir(output), SEARCH_LOG)
    if not os.path.isfile(path):
        return []
    from _common import open_csv, warn_read_failure
    try:
        with open_csv(path) as f:
            rows = list(csv.DictReader(f))
    except (OSError, ValueError, csv.Error) as exc:
        warn_read_failure(path, exc, "報告缺少補查紀錄；匯入時將中止，不更新版本表與記憶", "法規補查")
        if strict:
            raise li.ImpactError("%s 讀不出來，已中止匯入；請關閉 Excel 或另存成 CSV UTF-8 後重跑（%s）" % (path, exc)) from exc
        return []
    return [r for r in rows if (r.get("查了什麼") or "").strip()]


def _source_page(output, state):
    page = hr._page(SOURCE_SHEET, SOURCE_HEADER)
    names = []
    for item in state.get("coverage") or []:
        name, kind, status = item.get("name", ""), item.get("kind", ""), item.get("status", "")
        if kind == "檔案":
            # AI 或人補進來的證據檔：讀到就是讀到了，不寫「部分完成」（看起來像失敗）
            name, status = "證據檔：%s" % name, ("已讀取" if status == "部分完成" else status)
        names.append(item.get("name", ""))
        detail = item.get("detail", "")
        found = re.search(r"(\d+) 筆公告", detail)
        if kind == "公告清單" and found and str(item.get("count", "")).isdigit() and int(item["count"]) != int(found.group(1)):
            # 「61 筆公告」卻「取得 105 筆」：同一則公告的網頁與附件各算一筆（以前兩個數字擺一起，讀的人對不起來）
            detail = "%s（%s 筆公告連同附件，合計抓成 %s 筆法規異動：同一則公告的網頁與附件各算一筆）" % (
                detail, found.group(1), item["count"])
        hr._append(page, ["", name, kind, status, str(item.get("count", "")), _when(item.get("checked_at")), detail])
    for row in search_log_rows(output):
        latest = "最新修正日 %s" % row["最新修正日"] if (row.get("最新修正日") or "").strip() else ""
        hr._append(page, ["", row.get("查了什麼", ""), "AI 補查", row.get("處理", ""), "",
                          row.get("查詢日期", ""), "；".join(filter(None, [row.get("結果", ""), latest, row.get("來源網址", "")]))])
    for text in state.get("warnings") or []:
        # 「來源「xx」部分完成：…」跟上面那一列同一句：不再重抄一次
        if any(text.startswith("來源「%s」" % name) for name in names):
            continue
        hr._append(page, ["", "（提醒）", "提醒", "", "", "", text])
    hr._append(page, ["", "（範圍說明）", "說明", "", "", "",
                      "只限本輪來源與現行內規；來源失敗、查不到、沒列到的候選，都不等於沒有修法或已完全符合"])
    hr._append(page, ["", "（欄位說明）", "說明", "", "", "",
                      "法規適用總表的「未列入候選段數」：關鍵詞分數較低、超過每條法規候選上限而沒列給 AI 逐段判的段數；"
                      "AI 已被要求依主題用內規全文索引補查，有關係的會自己加「新增」列"])
    for number, row in enumerate(page["rows"], 1):
        row[0] = str(number)
    return page


def version_page(paragraphs):
    """引用版本檢查（v1.19.0）：手冊寫的「法規名稱(113.07.22…修正)」比法規版本表舊的段落，不限這一輪的查詢期間。
    paragraphs＝[(規章, 段次, 全文)]。版本表是 memoization/法規追蹤/法規版本表.json（每一輪法規追蹤、AI 補查累積）。"""
    import law_memory as lm
    page = hr._page(VERSION_SHEET, VERSION_HEADER)
    for number, hit in enumerate(lm.version_lag(paragraphs), 1):
        hr._append(page, [str(number), hit["規章"], hit["段次"], hit["全文"], hit["法規名稱"], hit["手冊寫的版本"],
                          hit["已知最新版"], "版本註記改成最新版（%s 修正），並確認摘錄的條文是否跟著改" % hit["已知最新版"],
                          hit["依據"], hit["來源"]])
    if lm.read_failed(lm.VERSIONS):
        hr._append(page, ["1", "版本檢查未完成（版本表讀不出來）", "", "", "", "", "",
                          "請修復法規版本表後重跑；本輪未更新此表", "", ""])
        return page
    if not page["rows"]:
        hr._append(page, ["1", "（沒有發現過時的版本註記）", "", "", "", "", "",
                          "只比對法規版本表裡有的法規；表會隨每一輪法規追蹤與 AI 補查越來越完整", "", ""])
    return page


def _segment_page(state):
    page = hr._page(SEGMENT_SHEET, SEGMENT_HEADER)
    for book in state["books"]:
        for i, text in enumerate(book["paragraphs"]):
            hr._append(page, [book["title"], "現行版", str(i + 1), book["labels"][i] or "", text])
    return page


def _options(page, segment_map):
    links = []
    header = page["header"]
    book_col = header.index("規章") if "規章" in header and page["name"] != SEGMENT_SHEET else None
    line_col = header.index("段次") if book_col is not None and "段次" in header else None
    url_col = header.index("官方來源") if "官方來源" in header else None
    for row_number, row in enumerate(page["rows"], 2):
        if line_col is not None and str(row[line_col]).isdigit():
            target = segment_map.get((str(row[book_col]), "現行版", int(row[line_col])))
            if target:
                links.append({"ref": "%s%d" % (hr._column(line_col), row_number),
                              "target_sheet": SEGMENT_SHEET, "target_ref": "A%d" % target})
        if url_col is not None:
            urls = hr._URL_RE.findall(str(row[url_col]))
            if urls:
                links.append({"ref": "%s%d" % (hr._column(url_col), row_number), "url": urls[0]})
    widths = [_WIDTHS.get(name, hr._COLUMN_WIDTHS.get(name, hr._DEFAULT_WIDTH)) for name in header]
    frozen = 2 if page["name"] in (IMPACT_SHEET, PARAGRAPH_SHEET) else 0
    return {"freeze_header": True, "freeze_columns": frozen, "auto_filter": True,
            "row_styles": {}, "hidden_rows": list(page.get("hidden_rows") or ()), "links": links, "column_widths": widths}


def build(output, state):
    """報告的兩頁（依段落彙整、段次總表）。v1.28.0 起法規影響報告、法規適用總表、來源查詢狀態在 build_detail。"""
    apply_by, impact_rows = _answers(output, state)
    pages = [_paragraph_page(state, apply_by, impact_rows), _segment_page(state)]
    segment_map = hr._segment_map_from_page(pages[-1])
    sheets = [(page["name"], page["header"], page["rows"]) for page in pages]
    options = [_options(page, segment_map) for page in pages]
    # v1.27.0：不再另開「AI報告審查」頁（查到直接改 AI 表，紀錄留在 2_Log檔案/AI審查/AI報告審查.csv）
    return sheets, options


def build_detail(output, state):
    """過程明細（v1.28.0）：法規影響報告、法規適用總表、來源查詢狀態，放 2_Log檔案/法規分析/。
    段次點下去要能跳，所以明細檔自己也帶一份段次總表。"""
    apply_by, impact_rows = _answers(output, state)
    pages = [_impact_page(state, apply_by, impact_rows), _apply_page(state, apply_by), _source_page(output, state),
             _segment_page(state)]
    segment_map = hr._segment_map_from_page(pages[-1])
    return ([(page["name"], page["header"], page["rows"]) for page in pages],
            [_options(page, segment_map) for page in pages])


def render(output, state):
    """寫 1_結果彙整/法規追蹤報告_YYYYMMDDNNN.xlsx（寫不出來退 csv）。回傳路徑。"""
    folder = os.path.join(output, "1_結果彙整")
    os.makedirs(folder, exist_ok=True)
    sheets, options = build(output, state)
    import precedents as pc
    from _common import report_base_name
    base = os.path.join(folder, report_base_name(output, "法規追蹤"))
    pc.keep_opinions(sheets, options, base)
    written = xw.write_tables_or_csv(base, sheets, source="法規報告", sheet_options=options)
    detail_sheets, detail_options = build_detail(output, state)
    detail_base = os.path.join(li.law_dir(output), report_base_name(output, "法規追蹤").replace(REPORT_NAME, DETAIL_NAME))
    xw.write_tables_or_csv(detail_base, detail_sheets, source="法規報告明細", sheet_options=detail_options)
    # 報告開在 Excel 裡時這一次存成「法規追蹤報告_YYYYMMDDNNN_HHMMSS.xlsx」：回傳實際寫的那一份（AI 報告審查要讀它，不是舊的）
    return written[0] if written else base + ".xlsx"
