# -*- coding: utf-8 -*-
"""新版人用檢視報告的純資料建構。

本模組只讀取既有產出，回傳給 ``xlsx_writer`` 的工作表資料與選項，
不建立資料夾、不寫入檔案，也不改動決定表。``review_report`` 可直接把
``build_book`` 或 ``build_batch`` 的回傳值交給 ``write_tables_or_csv``。

回傳格式一律是 ``(sheets, sheet_options)``：

* ``sheets``：``[(工作表名, 表頭, 列), ...]``
* ``sheet_options``：與 ``sheets`` 同順序的 xlsx_writer 選項

段次連結使用 xlsx_writer 的內部連結格式。段次總表的列號在組表時建立，
其他頁只有在能確定目標段落時才會加上連結。
"""

import sys, io
try:
    sys.stdout.reconfigure(encoding="utf-8")
except Exception:
    # stdout 被接管時（BookLog、測試的 redirect_stdout 是 StringIO）沒有 buffer：以前這裡再炸一次，
    # 整個模組 import 失敗，review_report 從此拿到 hr=None、整輪都不出檢視報告
    if getattr(sys.stdout, "buffer", None) is not None:
        sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8")

import csv
import difflib
import glob
import importlib
import json
import os
import re

HERE = os.path.dirname(os.path.abspath(__file__))
REGDIFF = os.path.join(HERE, "regdiff")
for _path in (HERE, REGDIFF):
    if _path not in sys.path:
        sys.path.insert(0, _path)

import decision_table as dt
import review_pack as rp
import xlsx_writer as xw
from _common import (FILL_DIR, REVIEW_DIR, SYSTEM_DIR, locate, open_csv, read_xlsx_rows,
                     xlsx_sheet_names)

try:
    import plain_words as plain_words
except ImportError:
    # plain_words 由整合工作提供。單獨測試此模組時保留可讀的安全退路。
    plain_words = None


SHEET_ORDER = (
    "條文比對報告",
    "條文檢查報告",
    "引用檢查報告",
    "段次總表",
)

# 修改前原文讓人不用翻別的檔就看得出改了什麼。
# 不放程式內部的異動編號（C1、C2…）：人手上沒有編號對照，看到「C15」也不知道是哪一段；
# AI 理由裡寫到的 C 編號，報告上一律換成段次（見 _resolve_change_refs）。
COMPARISON_HEADER = [
    "序號", "AI判定", "判定分數(0-10)", "判定理由", "修改規章", "修改段次",
    "修改前原文", "修改段落原文", "候選規章", "候選段次", "候選段落原文", "檢查類型", "建議處理",
]
# COMPARISON_HEADER 各欄的位置（連結、排序要用）
_CMP_MODIFIED_BOOK, _CMP_MODIFIED_LINE = 4, 5
_CMP_CANDIDATE_BOOK, _CMP_CANDIDATE_LINE = 8, 9
RULECHECK_HEADER = [
    "序號", "AI判定", "判定理由", "檢查項目", "規章", "段次",
    "原文", "說明", "相關原文", "建議處理",
]
CITATION_HEADER = [
    "序號", "AI判定", "判定理由", "規章", "段次",
    "原文", "引用", "建議處理", "查證來源",
]
SEGMENT_HEADER = ["規章", "版本", "段次", "位置", "全文"]
# 體檢那一輪多一頁：重複／矛盾（兩段對照），放在段次總表前面
CONSISTENCY_SHEET = "重複矛盾報告"
CONSISTENCY_HEADER = ["序號", "AI判定", "判定理由", "規章A", "段次A", "位置A", "原文A",
                      "規章B", "段次B", "位置B", "原文B", "建議處理"]
_CONSISTENCY_ORDER = {"矛盾": 0, "錯漏字": 1, "重複": 2, "一致": 3, "無關": 4}
TYPO_VERDICT = "錯漏字"           # v1.7.2：錯漏字（逐段讀、兩段比對發現的）的 AI判定都寫這個，不再寫「內文要改」
# v1.7.0 起體檢報告沒有「重複矛盾報告」頁：重複／矛盾、錯漏字、查引用時發現的內文錯字都放「條文比對報告」，
# 一列是一段（錯漏字）或兩段對照（重複／矛盾）
HEALTH_COMPARE_HEADER = ["序號", "AI判定", "判定理由", "檢查類型", "規章A", "段次A", "位置A", "原文A",
                         "規章B", "段次B", "位置B", "原文B", "建議處理"]
_HEALTH_COMPARE_ORDER = {"矛盾": 0, "錯漏字": 1, "內文要改": 1, "需再檢查": 2, "需人工確認": 2, "建議修改": 1, "重複": 3,
                         "無法判斷": 4, "一致": 5, "無關": 5, "不用改": 5, "沒問題": 5}
_CONSISTENCY_DEFAULT_ACTION = {"矛盾": "請確認哪一邊才對，兩處統一改法",
                               "錯漏字": "照理由補正錯漏字",
                               "重複": "可考慮保留一處、另一處改為引用，或確認是否刻意分寫",
                               "一致": "不用改", "無關": "不用改"}

# 欄寬照「這一欄裝的是什麼」固定（Excel 欄寬單位約半個中文字）。以前只有 30／60 兩種，
# 所有欄位都自動換行：條文原文塞在 30 寬的欄裡，一列被撐得又細又長，每次打開都要自己拉。
# 編號、段次、判定這類短欄窄；原文、理由這類長文欄寬，列高才不會被撐爆。
_DEFAULT_WIDTH = 20
_COLUMN_WIDTHS = {
    "序號": 6, "AI判定": 11, "判定分數(0-10)": 9,
    "段次": 8, "修改段次": 9, "候選段次": 9, "版本": 8,
    # 規章名常有二十幾個字（05.保險代理業務手冊_伍-消費者保護篇202511），太窄會折成四五行把整列撐高
    "規章": 26, "修改規章": 26, "候選規章": 26, "規章A": 26, "規章B": 26,
    "段次A": 8, "段次B": 8, "位置A": 16, "位置B": 16, "原文A": 60, "原文B": 60,
    "檢查類型": 14, "檢查項目": 16, "位置": 24, "引用": 24,
    # AI 理由中位數約 180 字：70 寬約 6 行就看完
    "判定理由": 70, "建議處理": 40, "說明": 36,
    "修改前原文": 45, "修改段落原文": 45, "候選段落原文": 45,
    "原文": 55, "相關原文": 40, "全文": 100,
    # AI 實際打開的官方網址（全國法規資料庫等），第一個可以直接點
    "查證來源": 40,
}
# 往右捲看長文時固定在左邊的欄數：序號＋AI判定（段次總表不用）
_FROZEN_COLUMNS = {"條文比對報告": 2, "條文檢查報告": 2, "引用檢查報告": 2}

# 這些文字不該出現在人用頁面。原文欄位例外，必須逐字保留。
_MACHINE_WORDS = (
    "SHA", "sha", "指紋", "列ID", "異動ID", "引用ID", "檢查ID",
    "AI分數", "相似分數", "審查內容", "異動SHA", "LLM",
    "review-pack", "review-import", "finalize", "apply", "compare",
    "Step ", "step ",
)
_PATH_RE = re.compile(r"(?:[A-Za-z]:[\\/][^\s，。；；（）()]*|(?:^|\s)/(?:[^\s，。；；（）()]+))")
_SCORE_RE = re.compile(r"(?:AI\s*)?(?:分數|score)\s*[:：]?\s*\d+(?:\.\d+)?", re.I)
_IDENTIFIER_RE = re.compile(r"(?<![\w-])(?:[RCEK]\d+|[A-Za-z]+-[A-Za-z0-9_-]+)(?![\w-])")
_LABEL_RE = re.compile(r"〔[^〕]{0,80}〕")


# ---------------------------------------------------------------------------
# 文字與安全讀取
# ---------------------------------------------------------------------------

def _original(value):
    """原文不改字：完整條文只能走這一支。"""
    return "" if value is None else str(value)


def _call_plain_words(text, kind):
    """相容 plain_words 的常見純文字介面；沒有介面時回原字串。

    plain_words 是人用措辭的唯一優先來源。此處容忍不同版本的函式名稱，
    讓新版報表可先獨立測試，之後再和正式 plain_words 模組接上。
    """
    module = plain_words
    if module is None:
        return text
    for name in ("to_human", "humanize", "plain", "to_plain_words", "clean"):
        func = getattr(module, name, None)
        if not callable(func):
            continue
        try:
            value = func(text, kind)
        except TypeError:
            try:
                value = func(text)
            except Exception:
                continue
        except Exception:
            continue
        if value is not None:
            return str(value)
    return text


def _plain(value, kind="內容"):
    """非原文欄位的人用文字。"""
    text = "" if value is None else str(value)
    text = _call_plain_words(text, kind)
    # 網址先收起來：底下砍識別字的規則會把 law.lia-roc.org.tw 砍成 law..org.tw（審查 C12）
    urls = _URL_RE.findall(text)
    for index, url in enumerate(urls):
        text = text.replace(url, "\x01%d\x02" % index)
    text = _PATH_RE.sub("相關檔案", text)
    text = _LABEL_RE.sub("", text)
    text = _SCORE_RE.sub("", text)
    text = _IDENTIFIER_RE.sub("", text)
    text = re.sub(r"(?<![A-Za-z0-9_])ID(?![A-Za-z0-9_])", "", text, flags=re.I)
    text = re.sub(r"(?<![A-Za-z0-9_])(?:step|batch-[A-Za-z_-]*)(?![A-Za-z0-9_])", "", text, flags=re.I)
    for word in _MACHINE_WORDS:
        text = text.replace(word, "")
    text = re.sub(r"\s{2,}", " ", text)
    text = re.sub(r"[；、，,:：]\s*(?=[；、，,:：]|$)", "", text)
    for index, url in enumerate(urls):
        text = text.replace("\x01%d\x02" % index, url)
    return text.strip(" \t\r\n；、，,:：")


def _plain_words_call(name, *args):
    """呼叫 plain_words 的公開函式；模組尚未到位時保留可讀退路。"""
    func = getattr(plain_words, name, None) if plain_words is not None else None
    if not callable(func):
        return ""
    try:
        value = func(*args)
    except Exception:
        return ""
    return "" if value is None else str(value)


def _reason_label(reason):
    match = re.match(r"\s*〔\s*([^〕]+?)\s*〕", str(reason or ""))
    return match.group(1).strip() if match else ""


# AI 理由開頭的標籤是給 AI 對評分標準用的術語，人看不懂（「套語命中」「各半」）。
# 報告上換成白話；AI 表、決定表裡的原標籤不動（匯入驗證要用）。
_FRIENDLY_LABELS = {
    "套語命中": "只是用字相同",
    "各半": "可能漏改，要確認",
    "平行規定": "同類規定也要一起改",
    "同義務舊值": "還留著舊寫法",
    "傾向要改": "可能要跟著改",
    "事項不同": "講的是別件事",
    "對象不同": "適用對象不同",
    "實質無疑": "內容沒問題",
    "刪除控管": "刪掉了控管",
    "牴觸規定": "可能牴觸規定",
    "可能的影響": "可能影響別處，要確認",
    "純形式": "只改格式",
    "需查依據": "要查依據",
}
# 〔可能的影響〕是 3 分（SKILL.md 定的）、判斷字只能是「沒問題」，但它要人去確認表單、系統、流程：
# 不能像其他 0–3 分的列一樣藏起來、也不能寫「不用改」（審查 C3）
_KEEP_VISIBLE_LABELS = ("可能的影響",)


def _keeps_visible(reason):
    return _reason_label(reason) in _KEEP_VISIBLE_LABELS or any(
        str(reason or "").lstrip().startswith("〔%s〕" % _FRIENDLY_LABELS.get(label, label))
        for label in _KEEP_VISIBLE_LABELS)


def _friendly_reason(reason):
    """AI 理由開頭的術語標籤換成白話，其餘一字不改。"""
    text = _original(reason)
    label = _reason_label(text)
    if label in _FRIENDLY_LABELS:
        text = re.sub(r"^\s*〔[^〕]*〕", "〔%s〕" % _FRIENDLY_LABELS[label], text, count=1)
    return text


# AI 理由裡「要人做什麼」的那幾句：建議處理欄直接放這幾句，人不用從一大段說明裡找。
# 「改成」在句子中間多半是在描述這次怎麼改（「被改成五章」），要有「建議／請」才算要人做的事；
# 句子一開頭就是「改成…」是評分標準要 AI 寫的改法（「改成「應將整份契約變更申請文件…」」），也算。
# 「建議與第一節一致改成…」這種「建議」跟「改成」中間隔幾個字的也算。
_ACTION_SENTENCE_RE = re.compile(
    r"請承辦|請確認|請問|請把|請補|請改|請一併|請另|建議改成|建議改為|建議保留|建議刪|建議一併|建議一起|建議統一|建議補"
    r"|^\s*(?:改成|改為)|建議[^。，；「]{0,20}(?:改成|改為)")
_SENTENCE_RE = re.compile(r"[^。！？]+[。！？]?")
_OPEN_QUOTES, _CLOSE_QUOTES = "「『“", "」』”"


def _split_outside_quotes(text, marks, keep=True):
    """照 marks 裡的字切句，但引號（「」『』“”）裡的不切（v1.27.2：「建議改成「…各種不利因素。」」
    以前在引號裡的句號切開，改法少了右引號）。換行一律切。引號沒配對好（AI 漏打右引號）就退回照字切，
    不讓一個漏掉的引號把後面整段吞成一句。keep＝True 句尾標點留在句子上。"""
    parts, buf, depth = [], [], 0
    for ch in text or "":
        if ch == "\n":
            depth = 0
        elif ch in _OPEN_QUOTES:
            depth += 1
        elif ch in _CLOSE_QUOTES and depth:
            depth -= 1
        if (ch in marks or ch == "\n") and depth == 0:
            if keep and ch != "\n":
                buf.append(ch)
            parts.append("".join(buf))
            buf = []
            continue
        buf.append(ch)
    if buf:
        parts.append("".join(buf))
    if depth:                                  # 引號沒關：照舊照字切
        pattern = "[%s\n]" % re.escape(marks)
        return [p + "" for p in re.split("(?<=%s)" % pattern if keep else pattern, text or "")]
    return parts


# AI 沿用前一輪查證時寫在理由開頭的說明（「沿用前一輪（2026-10-22）對這一段的上網查證：」）：
# 是理由的出處，不是要承辦做的事，變成建議處理時拿掉（v1.25.0）
_CARRY_NOTE_RE = re.compile(r"(^|[。；\n])\s*沿用前一輪（[^）]*）[^：:。\n]{0,24}[：:]\s*")


def _drop_carry_note(text):
    return _CARRY_NOTE_RE.sub(r"\1", text or "")


def _action_sentences(reason, limit=3):
    text = _drop_carry_note(re.sub(r"^\s*〔[^〕]*〕\s*", "", _original(reason)))
    picked = [s.strip() for s in _split_outside_quotes(text, "。！？")
              if s.strip() and _ACTION_SENTENCE_RE.search(s)]
    return "".join(picked[:limit])


def _plain_change(change):
    text = _plain_words_call("plain_change", change)
    if text:
        return _plain(text, "變更")
    if isinstance(change, dict):
        kind = _change_kind(change)
        return _plain(kind or "文字有調整，請確認", "變更")
    return _plain(change, "變更")


def _plain_source(row):
    relation = row.get("關係／分數") or row.get("關係") or ""
    text = _plain_words_call("plain_source", row.get("來源") or "", relation)
    return _plain(text or "這段可能和本次修訂有關，請確認。", "原因")


def _plain_reason(kind, reason, verdict=""):
    text = _plain_words_call("plain_reason", kind, reason, verdict)
    return _plain(text or reason or "請查看相關內容。", "說明")


def _book_label(value, fallback=""):
    """規章名稱可顯示檔名，但不可把完整路徑帶進人用表。
    規章名不過 _plain：它會把名字裡的「ID」「Step 」砍掉（「數位ID作業要點」→「數位作業要點」），
    報告用改過的名字當鍵去查決定表，跨本列的修改規章、原文就整格空白（審查 C12）。"""
    text = "" if value is None else str(value).strip()
    if os.path.isabs(text) or ":\\" in text or ":/" in text:
        text = os.path.basename(text)
    return text or fallback


def _existing(outdir, filename):
    try:
        path = locate(outdir, filename)[0]
    except Exception:
        return ""
    return path if os.path.isfile(path) else ""


def _read_text(path):
    if not path or not os.path.isfile(path):
        return ""
    try:
        with open(path, "rb") as source:
            raw = source.read()
    except OSError:
        return ""
    try:
        from _common import _decode_text
        return _decode_text(raw, path)
    except BaseException:
        for encoding in ("utf-8-sig", "utf-8", "cp950", "big5hkscs"):
            try:
                return raw.decode(encoding)
            except UnicodeDecodeError:
                continue
    return raw.decode("utf-8", errors="replace")


def _read_csv_rows(path):
    if not path or not os.path.isfile(path):
        return [], []
    try:
        with open_csv(path) as source:
            reader = csv.DictReader(source)
            return list(reader.fieldnames or []), [dict(row) for row in reader]
    except (OSError, UnicodeDecodeError, csv.Error, ValueError) as exc:
        from _common import warn_read_failure
        warn_read_failure(path, exc, "來源表讀不到，這一輪報告少了此表的列", "人用報告")
        return [], []


def _read_xlsx_tables(path):
    """讀來源 xlsx；來源壞掉時當作沒有資料，不能讓人用報告失敗。"""
    if not path or not os.path.isfile(path):
        return []
    try:
        names = xlsx_sheet_names(path)
    except Exception as exc:
        from _common import warn_read_failure
        warn_read_failure(path, exc, "來源活頁簿讀不到，這一輪報告少了此檔的表格", "人用報告")
        return []
    tables = []
    for name in names:
        try:
            cells = read_xlsx_rows(path, name)
        except Exception as exc:
            from _common import warn_read_failure
            warn_read_failure(path, exc, "工作表讀不到，這一輪報告少了此工作表的列", "人用報告", sheet=name)
            continue
        if not cells:
            continue
        tables.append((name, list(cells[0]), [list(row) for row in cells[1:]]))
    return tables


def _table_dict_rows(header, rows):
    return [{name: (row[index] if index < len(row) else "")
             for index, name in enumerate(header)} for row in rows]


def _source_dirs(outdir):
    return [
        os.path.join(outdir, REVIEW_DIR),
        os.path.join(outdir, FILL_DIR),
        os.path.join(outdir, SYSTEM_DIR),
        outdir,
    ]


def _find_csv_sources(outdir, patterns):
    found = []
    seen = set()
    for folder in _source_dirs(outdir):
        if not os.path.isdir(folder):
            continue
        for pattern in patterns:
            for path in sorted(glob.glob(os.path.join(folder, pattern))):
                normalized = os.path.abspath(path)
                if normalized not in seen and os.path.isfile(path):
                    found.append(path)
                    seen.add(normalized)
    return found


def _load_report_tables(outdir, xlsx_name, csv_patterns=()):
    """優先讀 xlsx；只有不存在或讀不到時才讀 CSV 退路。"""
    xlsx_path = _existing(outdir, xlsx_name)
    tables = _read_xlsx_tables(xlsx_path)
    if tables:
        return tables
    tables = []
    for path in _find_csv_sources(outdir, csv_patterns):
        header, rows = _read_csv_rows(path)
        if header:
            tables.append((os.path.splitext(os.path.basename(path))[0], header,
                           [[row.get(column, "") for column in header] for row in rows]))
    return tables


def _line(value):
    text = str(value or "").strip()
    if text.isdigit() and int(text) > 0:
        return int(text)
    match = re.search(r"(?<!\d)(\d+)(?!\d)", text)
    return int(match.group(1)) if match else 0


def _column(index):
    text = ""
    index += 1
    while index:
        index, remainder = divmod(index - 1, 26)
        text = chr(65 + remainder) + text
    return text


def _page(name, header):
    return {"name": name, "header": list(header), "rows": [], "link_specs": [],
            "row_styles": {}}


def _append(page, row, links=(), style=""):
    page["rows"].append(list(row))
    excel_row = len(page["rows"]) + 1
    if style:
        page["row_styles"][excel_row] = style
    for column_index, version, paragraph in links:
        page["link_specs"].append((excel_row, column_index, version, _line(paragraph)))


# ---------------------------------------------------------------------------
# 來源資料
# ---------------------------------------------------------------------------

def _safe_book(outdir):
    try:
        return rp.load_book(outdir)
    except (rp.ReviewPackError, dt.DecisionTableError, OSError, ValueError, UnicodeDecodeError, SystemExit) as exc:
        from _common import warn_read_failure
        warn_read_failure(outdir, exc, "產出資料夾讀不完整，這次報告缺少候選與段次總表", "人用報告")
        return {}


def _load_changes_direct(outdir):
    """review_pack 不能完整讀取時，仍可安全讀異動清單。"""
    path = _existing(outdir, "異動清單.json")
    if not path:
        return []
    try:
        with open(path, encoding="utf-8") as source:
            data = json.load(source)
    except (OSError, ValueError, TypeError):
        return []
    return [dict(row) for row in data if isinstance(row, dict)] if isinstance(data, list) else []


def _decision_rows(decisions, book):
    """決定表可由呼叫端指定路徑、列資料，或使用 review_pack 已讀的列。"""
    if isinstance(decisions, (list, tuple)):
        return [dict(row) for row in decisions if isinstance(row, dict)]
    if isinstance(decisions, dict):
        rows = decisions.get("rows", decisions.get("列", []))
        return [dict(row) for row in rows if isinstance(row, dict)]
    if isinstance(decisions, str) and os.path.isfile(decisions):
        try:
            return [dict(row) for row in dt.read_table(decisions)]
        except (dt.DecisionTableError, OSError, UnicodeDecodeError, ValueError):
            return []
    return [dict(row) for row in (book.get("rows") or [])]


def _change_kind(change):
    raw = (change.get("修改類型") or change.get("type") or "").strip()
    values = {
        "added": "新增", "deleted": "刪除", "modified": "修改",
        "renumbered": "編號調整", "cosmetic": "格式調整",
    }
    return _plain(values.get(raw, raw) or "變更", "變更類型")


def _changes(book, outdir=""):
    rows = [dict(change) for change in (book.get("changes") or []) if isinstance(change, dict)]
    return rows or _load_changes_direct(outdir)


def _decision_action(row):
    raw = row.get("要改嗎") or ""
    try:
        value = dt.normalize_action(raw)
    except Exception:
        value = None
    if value == "改":
        return "一起改", value
    if value == "刪除":
        return "刪除這段", value
    if value == "不改":
        return "不用改", value
    if str(raw).strip():
        return "請確認填寫內容", None
    return "尚未決定", ""


def _changed_indexes(changes, new=True):
    name = "new_index" if new else "old_index"
    out = set()
    for change in changes:
        kind = (change.get("type") or change.get("修改類型") or "").strip()
        if kind in ("unchanged", "未變更", ""):
            continue
        line = _line(change.get(name))
        if line:
            out.add(line)
    return out


def _context_text(context):
    if not isinstance(context, dict):
        return ""
    return _plain(context.get("ref") or "", "位置")


# ---------------------------------------------------------------------------
# 段次總表與連結
# ---------------------------------------------------------------------------

def _shown_or_raw(book, side):
    raw = list(book.get("%s_paragraphs" % side) or [])
    shown = list(book.get("%s_shown" % side) or [])
    return shown if shown and len(shown) == len(raw) else raw


def _segment_rows(book, book_key, changes=None):
    """回傳段次總表列與 ``(規章, 版本, 段次) -> Excel 列號``。

    修訂版是人工比對的主座標，因此完整列出。現行版只保留本輪刪除或移列相關
    段落。所有原文均完整保留。
    """
    changes = list(changes if changes is not None else _changes(book))
    new_changed = _changed_indexes(changes, new=True)
    old_changed = _changed_indexes(changes, new=False)
    # 給人看的全文用「補回 Word 自動編號」的那一份（v1.7.1）：以前段次總表只有原文，自動編號的
    # 「（二）」不見了，跟 Word 對不起來。段數一樣才換（不一樣就是舊產出，照舊用原文）
    revised = _shown_or_raw(book, "new")
    current = _shown_or_raw(book, "old")
    revised_contexts = list(book.get("new_contexts") or [])
    current_contexts = list(book.get("old_contexts") or [])

    # 「現行版」只要給刪除或移列的舊位置。單純修改的舊文已在「這次改了什麼」顯示，
    # 不再把整本現行全文複製一份，避免人工誤以為兩版都要逐段重看。
    current_needed = set()
    for change in changes:
        kind = (change.get("type") or change.get("修改類型") or "").strip()
        if kind in ("deleted", "刪除") or change.get("moved_to") or change.get("moved_from") or change.get("移列"):
            line = _line(change.get("old_index") or change.get("現行段次"))
            if line:
                current_needed.add(line)

    rows = []
    row_map = {}

    def add(version, paragraphs, contexts, changed, include=None):
        for number, text in enumerate(paragraphs, 1):
            if include is not None and number not in include:
                continue
            context = contexts[number - 1] if number - 1 < len(contexts) else {}
            rows.append([
                _plain(version, "版本"), str(number), _context_text(context),
                _original(text), "有" if number in changed else "沒有",
            ])
            row_map[(book_key, version, number)] = len(rows) + 1

    add("修訂版", revised, revised_contexts, new_changed)
    add("現行版", current, current_contexts, old_changed, current_needed)
    return rows, row_map


def _lookup_segment(row_map, book_key, version, paragraph):
    line = _line(paragraph)
    if not line:
        return 0
    candidates = [version]
    if version == "修訂版":
        candidates += ["現行版"]
    elif version == "現行版":
        candidates += ["修訂版"]
    for candidate in candidates:
        target = row_map.get((book_key, candidate, line))
        if target:
            return target
    return 0


def _options(page, row_map, book_key):
    links = []
    for row, column, version, paragraph in page["link_specs"]:
        target = _lookup_segment(row_map, book_key, version, paragraph)
        if not target:
            continue
        links.append({
            "ref": "%s%d" % (_column(column), row),
            "target_sheet": "段次總表",
            "target_ref": "A%d" % target,
        })
    return {
        "freeze_header": True,
        "auto_filter": True,
        "row_styles": dict(page["row_styles"]),
        "links": links,
    }


# ---------------------------------------------------------------------------
# AI 狀態與文字解析
# ---------------------------------------------------------------------------

def _ai_table_rows(outdir, filename):
    """讀單本 AI 表；尚未拆回的批次合一表也可作為讀取退路。"""
    _header, rows = _read_csv_rows(_existing(outdir, filename))
    if rows:
        return rows
    try:
        from _common import batch_root_of
        root = batch_root_of(outdir)
    except Exception:
        root = None
    if not root:
        return []
    path = os.path.join(root, SYSTEM_DIR, "AI審查", filename)
    _header, rows = _read_csv_rows(path)
    book = os.path.basename(os.path.abspath(outdir))
    return [row for row in rows if row.get("規章") == book]


def _ai_rows_by_id(rows, id_column):
    return {str(row.get(id_column) or "").strip(): row for row in rows if row.get(id_column)}


# ---------------------------------------------------------------------------
# 個別頁面
# ---------------------------------------------------------------------------

# ---------------------------------------------------------------------------
# 公開建構函式
# ---------------------------------------------------------------------------

def _report_book_label(book_name, outdir):
    fallback = os.path.basename(os.path.normpath(outdir or ''))
    return _book_label(book_name, _book_label(fallback))


def _score_or_blank(value):
    text = str(value or '').strip()
    return int(text) if re.fullmatch(r'(?:10|[0-9])', text) else ''


def _raw_verdict(value):
    """人用報告不顯示「尚未審查」；沒有足夠資料時如實標示無法判斷。"""
    verdict = str(value or '').strip()
    return '無法判斷' if verdict in ('', '尚未審查', '不適用') else verdict


def _join_unique(values, separator='\n\n'):
    output = []
    for value in values:
        text = str(value or '').strip()
        if text and text not in output:
            output.append(text)
    return separator.join(output)


def _external_only(row):
    sources = [part.strip() for part in str(row.get('來源') or '').split('；') if part.strip()]
    return bool(sources) and all(part == '外部引用' for part in sources)


def _change_display_line(change):
    new_line = _line(change.get('new_index') or change.get('新版段次'))
    if new_line:
        return str(new_line), '修訂版', new_line
    old_line = _line(change.get('old_index') or change.get('現行段次'))
    if old_line:
        return '現行版 %d' % old_line, '現行版', old_line
    return '', '修訂版', 0


def _change_ai_rows_verified(outdir, changes, book=None):
    """只接受指紋對得上本輪異動的 AI 結果（指紋含前後文，要跟打包時一樣傳 book）。"""
    by_id = _ai_rows_by_id(_ai_table_rows(outdir, 'AI異動審查.csv'), '異動ID')
    result = []
    for number, change in enumerate(changes, 1):
        row = dict(by_id.get('C%d' % number, {}))
        expected = rp.change_sha256(change, book)
        if not row or str(row.get(rp.CHANGE_SHA_COLUMN) or '').strip() != expected:
            result.append({})
        else:
            result.append(row)
    return result


def _comparison_reason(ai_row, kind):
    """條文比對列無法判斷時，必須說明缺的是哪一種 AI 資料。"""
    row = ai_row if isinstance(ai_row, dict) else {}
    verdict = _original(row.get("AI判斷")).strip()
    reason = _original(row.get("AI理由")).strip()
    if not verdict:
        label = "異動" if kind == "異動" else "候選"
        return "AI 審查尚未完成：這筆%s尚未填 AI 判定。" % label
    if not reason:
        return "AI 已給出判定，但未提供理由。"
    return reason


def _change_suggestion(verdict, reason=''):
    """本次異動列的建議處理：跟著 AI 判定走，要人做的事直接取 AI 理由裡那幾句。"""
    value = str(verdict or '').strip()
    if value == '沒問題':
        if _reason_label(reason) in _KEEP_VISIBLE_LABELS:
            return _action_sentences(reason) or '請確認可能受影響的表單、系統、作業流程或其他規章'
        return '不用改'
    actions = _action_sentences(reason)
    if value == '建議修改':
        return actions or '請依 AI 判定修正'
    if value == '需再檢查':
        return actions or '請確認後處理'
    return '無法判斷，請補 AI 判定'


def _candidate_suggestion(row, verdict):
    """候選列的建議處理。

    以前程式自動拼的「建議改法」一律優先：AI 判「不用改」的列也掛著改法，而且那是照異動的字
    機械替換出來的，常常是錯的（「第五章」刪「第」字，候選「第十章 商品售後管理」被拼成
    「第十章 五章 商品售後管理」）。現在：人已經決定的照人；AI 說不用改就是不用改；
    要改時先用 AI 理由裡寫的改法，AI 沒寫才退回程式的建議改法。"""
    action = _decision_action(row)[1]
    if action:
        return '人工決定：%s' % action
    value = str(verdict or '').strip()
    if value == '不用改':
        return '不用改'
    actions = _action_sentences(row.get('AI理由'))
    suggested = _original(row.get('建議改法') or '')
    if value == '建議修改':
        return actions or ('改成：%s' % suggested if suggested else '請依 AI 判定確認修改')
    if value == '需再檢查':
        return actions or '請確認後決定是否修改'
    if suggested:
        return '程式建議（AI 尚未判定，請先確認）：改成 %s' % suggested
    return '無法判斷，請補 AI 判定'


def _changes_for_candidate(row, book, books):
    try:
        return list(rp.changes_for_row(row, book, books) or [])
    except Exception:
        return []


def _make_rich_text(text, ranges=()):
    """有 rich text 寫檔器時標示局部差異；舊替身則安全退成純文字。"""
    value = _original(text)
    factory = getattr(xw, 'rich_text', None)
    if callable(factory) and ranges:
        try:
            return factory(value, ranges)
        except Exception:
            pass
    return value


def _new_difference_ranges(old_text, new_text):
    """回傳新版裡真正新增或替換的字元範圍。"""
    old, new = _original(old_text), _original(new_text)
    ranges = []
    for tag, _i1, _i2, j1, j2 in difflib.SequenceMatcher(
            None, old, new, autojunk=False).get_opcodes():
        if tag in ('insert', 'replace') and j2 > j1:
            ranges.append((j1, j2))
    return ranges


def _old_difference_parts(old_text, new_text):
    """回傳由舊版拿掉或替換的片段，供候選原文標出舊名稱或舊數值。"""
    old, new = _original(old_text), _original(new_text)
    parts = []
    for tag, i1, i2, _j1, _j2 in difflib.SequenceMatcher(
            None, old, new, autojunk=False).get_opcodes():
        piece = old[i1:i2]
        if tag in ('delete', 'replace') and piece.strip() and piece not in parts:
            parts.append(piece)
    return parts


def _ranges_for_old_values(text, changes):
    """在候選原文中找出與異動來源相同的舊寫法。"""
    source = _original(text)
    ranges = []
    for _name, change in changes:
        for piece in _old_difference_parts(change.get('old_text'), change.get('new_text')):
            offset = 0
            while True:
                found = source.find(piece, offset)
                if found < 0:
                    break
                ranges.append((found, found + len(piece)))
                offset = found + len(piece)
    return ranges


def _revised_text_and_ranges(change):
    """修改段落原文固定顯示修訂後文字；刪除項目明確標示無新版原文（刪除前的字在修改前原文欄）。"""
    kind = _change_kind(change)
    new_text = _original(change.get('new_text'))
    old_text = _original(change.get('old_text'))
    if kind == '刪除':
        return '（本段已刪除）', []
    if new_text:
        return new_text, _new_difference_ranges(old_text, new_text)
    return '（缺少修訂後原文）', []


def _old_text_and_ranges(change):
    """修改前原文：標出這次拿掉或換掉的字；新增的段落沒有修改前原文。"""
    old_text = _original(change.get('old_text'))
    new_text = _original(change.get('new_text'))
    if not old_text:
        return '（新增段落，沒有修改前原文）', []
    if _change_kind(change) == '刪除':
        return old_text, []
    ranges = []
    for tag, i1, i2, _j1, _j2 in difflib.SequenceMatcher(
            None, old_text, new_text, autojunk=False).get_opcodes():
        if tag in ('delete', 'replace') and i2 > i1:
            ranges.append((i1, i2))
    return old_text, ranges


def _join_rich_parts(parts, separator='\n\n'):
    """把多個文字與差異範圍合併成一格 rich text。"""
    texts, ranges, offset = [], [], 0
    for text, part_ranges in parts:
        if texts:
            texts.append(separator)
            offset += len(separator)
        text = _original(text)
        texts.append(text)
        ranges.extend((offset + start, offset + end) for start, end in part_ranges)
        offset += len(text)
    return _make_rich_text(''.join(texts), ranges)


_EXCERPT_FULL = 120      # 修改前原文不超過這麼多字就整段放
_EXCERPT_MARGIN = 20     # 摘錄時改動處前後各留幾個字
_EXCERPT_CHANGES = 3     # 候選列一格最多放幾處異動的摘錄


def _short_book(name):
    """跨本異動位置前面的規章簡稱：「05.保險代理業務手冊_伍-消費者保護篇202511」→「伍-消費者保護篇」。
    全名二十幾個字放在每一段摘錄前面太長；全名在修改規章欄。取不出簡稱就用全名。"""
    text = str(name or '')
    short = re.sub(r'\d{6,8}$', '', text.split('_')[-1]).strip(' -_')
    return short or text


def _change_location(change):
    """一處異動在人看得到的位置：新版段次「段749」；整段刪掉的是「現行版段436」。"""
    shown = _change_display_line(change)[0]
    if shown.startswith('現行版'):
        return '現行版段%s' % shown[len('現行版'):].strip()
    return ('段%s' % shown) if shown else ''


_CHANGE_REF_RE = re.compile(r'(?<![A-Za-z0-9])C(\d+)(?![0-9])')


_DOUBLE_PLACE_RE = re.compile(r'((?:現行版)?段\d+)\s*[（(]\s*\1\s*[)）]')


def _resolve_change_refs(reason, changes, allowed=None):
    """AI 理由裡的異動編號（C15）換成段次（段749）。

    C 編號是程式給 AI 的內部代號，人手上沒有對照表；段次在報告的段次欄、段次總表都查得到。
    只換這一本異動清單裡有的編號（C 編號是各本自己編的），對不到的照原樣留著。

    allowed：只換這幾個編號（候選列給它掛的那幾處異動）。舊版候選審查包沒有標 C 編號，
    AI 在候選理由裡寫的編號是自己猜的（實測「C1 保單遞送」其實是段749 而不是段180）；
    把猜錯的編號換成一個看起來很確定的段次，比留著看不懂的代號更會誤導人。"""
    text = _original(reason)
    if not changes or 'C' not in text:
        return text

    def place(match):
        number = int(match.group(1))
        if 1 <= number <= len(changes) and (allowed is None or number in allowed):
            return _change_location(changes[number - 1]) or match.group(0)
        return match.group(0)
    # AI 自己已經寫了段次的（「C40（段1234）」）換完會變成「段1234（段1234）」，收成一個
    return _DOUBLE_PLACE_RE.sub(r'\1', _CHANGE_REF_RE.sub(place, text))


def _old_excerpt(change, label):
    """候選列的修改前原文：每處異動只摘改動那一截（前後各留幾個字），前面標這處異動的段次。

    一個候選常掛好幾處異動（實測一列掛 7 處），整段舊文全部疊進一格有一千多字，超過 Excel
    列高上限，後半截直接看不到。完整舊文在那一處異動自己的「本次異動」列，這裡只要看得出改了哪裡。"""
    return _excerpt(*_old_text_and_ranges(change), label=label)


def _new_excerpt(change, label):
    """候選列的修改段落原文：同 _old_excerpt，摘修訂後那一截（完整全文點修改段次連到段次總表）。"""
    return _excerpt(*_revised_text_and_ranges(change), label=label)


def _excerpt(text, ranges, label=''):
    prefix = '%s：' % label if label else ''
    if len(text) <= _EXCERPT_FULL or not ranges:
        if len(text) > _EXCERPT_FULL:
            text = text[:_EXCERPT_FULL] + '…'
        return prefix + text, [(start + len(prefix), end + len(prefix)) for start, end in ranges]
    windows = []
    for start, end in ranges:
        low, high = max(0, start - _EXCERPT_MARGIN), min(len(text), end + _EXCERPT_MARGIN)
        if windows and low <= windows[-1][1]:
            windows[-1][1] = max(windows[-1][1], high)
        else:
            windows.append([low, high])
    pieces, marks, offset = [prefix], [], len(prefix)
    for low, high in windows:
        lead = '…' if low > 0 else ''
        pieces.append(lead)
        offset += len(lead)
        for start, end in ranges:
            if low <= start and end <= high:
                marks.append((offset + start - low, offset + end - low))
        pieces.append(text[low:high])
        offset += high - low
    if windows[-1][1] < len(text):
        pieces.append('…')
    return ''.join(pieces), marks


def _candidate_change_fields(row, book, book_name, books):
    """一筆候選保持一列；多處異動以第一處作定位，其餘修訂後原文仍完整併列。

    回傳 (主要修改規章, 主要修改段次, 各處異動的位置, 修改前原文, 修改段落原文)。
    位置是段次（段749）；跨本的前面加來源規章簡稱，才分得出是哪一本的段次。"""
    matches = _changes_for_candidate(row, book, books)
    texts, olds, ids = [], [], []
    primary_book, primary_line = '', ''
    for source_name, change in matches:
        source_book = _book_label(source_name, book_name) if source_name else book_name
        shown_line, _version, _line_number = _change_display_line(change)
        label = _change_location(change)
        if label and source_book != book_name:
            label = '%s %s' % (_short_book(source_book), label)
        if label and label not in ids:
            ids.append(label)
        olds.append(_old_excerpt(change, label))
        texts.append(_new_excerpt(change, label))
        # 只把可定位到同一本段次總表的來源選為主連結；跨本來源仍保留在修改段落原文。
        if not primary_line and source_book == book_name:
            primary_book, primary_line = source_book, shown_line
    if not primary_line and matches:
        source_name, change = matches[0]
        primary_book = _book_label(source_name, book_name) if source_name else book_name
        primary_line = _change_display_line(change)[0]
    if len(olds) > _EXCERPT_CHANGES:
        # 掛七處異動時，摘錄疊起來仍超過 Excel 列高上限：只放前幾處，其餘只列位置
        rest = ids[_EXCERPT_CHANGES:]
        more = ('（另有 %d 處異動%s）' % (len(olds) - _EXCERPT_CHANGES,
                                     '：' + '、'.join(rest) if rest else ''), [])
        olds = olds[:_EXCERPT_CHANGES] + [more]
        texts = texts[:_EXCERPT_CHANGES] + [more]
    return (primary_book, primary_line, '\n'.join(ids),
            _join_rich_parts(olds), _join_rich_parts(texts))


def _is_empty_candidate(row):
    return not _original(row.get('候選全文')).strip()


def _candidate_original(row, book, books):
    text = _original(row.get('候選全文'))
    return _make_rich_text(text, _ranges_for_old_values(text, _changes_for_candidate(row, book, books)))


_CANDIDATE_REPLACEMENT_RE = re.compile(r"改成\s*([^。；;]+)")
# 決定表「異動內容」的「舊→新」：「三日→五日、五年→七年」「投保新契約→（無）」
_CHANGE_PAIR_RE = re.compile(r"([^→、；;]+)→([^→、；;]+)")


def _candidate_already_uses_ai_replacement(row):
    """AI 說候選仍是舊值，但候選已含全部指定新值、舊值也都不在了，不列入人用報告。

    此檢查只處理「同義務舊值」且 AI 建議修改的矛盾判斷。原始候選與 AI
    判斷仍保留在決定表，供稽核追查；人用報告不再把已是新值的候選說成要改。

    只看新值有沒有出現不夠：「主管覆核三日；申訴回覆五日。覆核紀錄保存五年；錄音保存七年。」
    AI 要把覆核期限改五日、紀錄改七年，五日、七年卻早就在別的義務裡，整列 9 分的建議會不見。
    所以還要確認異動內容的舊值（「三日→五日」的三日）扣掉新值之後已經不在候選段；
    取不到舊值就無法確定，照樣列出來給人看。"""
    if _raw_verdict(row.get('AI判斷')) != '建議修改':
        return False
    reason = _original(row.get('AI理由'))
    if not reason.startswith('〔同義務舊值〕'):
        return False
    match = _CANDIDATE_REPLACEMENT_RE.search(reason)
    terms = re.findall(r'「([^」]+)」', match.group(1)) if match else []
    candidate = _original(row.get('候選全文'))
    if len(terms) < 2 or not all(_whole_term(term).search(candidate) for term in terms):
        return False
    olds = [old.strip() for old, _new in _CHANGE_PAIR_RE.findall(_original(row.get('異動內容')))]
    olds = [old for old in olds if old and old != '（無）']
    if not olds:
        return False
    rest = candidate
    for term in sorted(terms, key=len, reverse=True):
        rest = _whole_term(term).sub('\x00', rest)
    return not any(_whole_term(old).search(rest) for old in olds)


# v1.22.0：數字、期限要整個比——「十五日」裡面的「五日」不算出現了「五日」。以前直接找子字串，
# 「十五日→五日」的候選段被當成已經改好，整列從報告拿掉（審查 比對#3）
_NUMERAL_CHARS = '0-9０-９零〇一二三四五六七八九十百千萬兩廿卅'


def _whole_term(term):
    head = '(?<![%s])' % _NUMERAL_CHARS if re.match('[%s]' % _NUMERAL_CHARS, term) else ''
    tail = '(?![%s])' % _NUMERAL_CHARS if re.search('[%s]$' % _NUMERAL_CHARS, term) else ''
    return re.compile(head + re.escape(term) + tail)


def _comparison_score(value):
    try:
        score = int(str(value).strip())
    except (TypeError, ValueError):
        return None
    return score if 0 <= score <= 10 else None


def _move_low_score_rows_to_bottom(page):
    """分數 0 到 3 的列移到末尾並隱藏，保留其他列的原有順序。
    理由是〔可能的影響〕的列例外：分數 3 但要人確認，留在原位、不藏（見 _KEEP_VISIBLE_LABELS）。"""
    rows = list(page['rows'])

    def low_score(row):
        score = _comparison_score(row[2] if len(row) > 2 else None)
        return score in range(0, 4) and not _keeps_visible(row[3] if len(row) > 3 else "")
    high = [(row, _comparison_score(row[2] if len(row) > 2 else None)) for row in rows if not low_score(row)]
    low = [(row, _comparison_score(row[2] if len(row) > 2 else None)) for row in rows if low_score(row)]
    page['rows'] = [row for row, _score in high + low]
    page['hidden_rows'] = [number + 2 for number, (row, _score) in enumerate(high + low) if low_score(row)]
    for number, row in enumerate(page['rows'], 1):
        row[0] = str(number)


def _move_rows_to_bottom(page, hide):
    """hide(row) 為真的列移到末尾並隱藏，保留其餘列的原有順序。"""
    rows = list(page['rows'])
    shown = [row for row in rows if not hide(row)]
    hidden = [row for row in rows if hide(row)]
    page['rows'] = shown + hidden
    page['hidden_rows'] = list(range(len(shown) + 2, len(shown) + len(hidden) + 2))
    for number, row in enumerate(page['rows'], 1):
        row[0] = str(number)


def _citation_needs_nothing(row):
    """引用檢查頁不用人做事的列：沒問題、程式誤判，以及 AI 已核對、手冊不用改的程式漏抓。
    程式推測（手冊的「前項」「本節第一條」用字跟層級對不上、程式猜一個）也收起來：
    多半只是寫法習慣，要看再打開篩選。"""
    if len(row) < 2:
        return False
    action = str(row[7] if len(row) > 7 else row[-1] or '')
    return (row[1] in ('沒問題', CITATION_PROGRAM_WRONG) and not action.startswith('不用改；另請注意')) \
        or (row[1] == CITATION_PROGRAM_MISSED and action.startswith('手冊不用改')) \
        or row[1] == CITATION_GUESS


def _sort_rulecheck_page(page):
    """條文檢查頁：要人確認的在前；「參考（程式統計）」接在後面、照樣看得到（全篇統計，有空可以看）；
    AI 判「沒問題」的移到最後並隱藏。"""
    def verdict(row):
        return row[1] if len(row) >= 2 else ''
    rows = list(page['rows'])
    act = [row for row in rows if verdict(row) not in ('沒問題', RULECHECK_REFERENCE)]
    reference = [row for row in rows if verdict(row) == RULECHECK_REFERENCE]
    fine = [row for row in rows if verdict(row) == '沒問題']
    page['rows'] = act + reference + fine
    shown = len(act) + len(reference)
    page['hidden_rows'] = list(range(shown + 2, shown + len(fine) + 2))
    for number, row in enumerate(page['rows'], 1):
        row[0] = str(number)


def _sort_pages(pages):
    """各頁要人做事的列在前，不用做事的列移到最後並隱藏（篩選打開就看得到）。"""
    _move_low_score_rows_to_bottom(pages[0])
    _sort_rulecheck_page(pages[1])
    _move_rows_to_bottom(pages[2], _citation_needs_nothing)


def _build_comparison_report(book, outdir, book_name, books):
    page = _page('條文比對報告', COMPARISON_HEADER)
    changes = _changes(book, outdir)
    ai_changes = _change_ai_rows_verified(outdir, changes, book)
    serial = 0

    # 本本異動段落的段次，與其中 AI 判要人看的那幾段：候選段就是異動段本身時用來去重
    change_lines, flagged_change_lines = set(), set()
    for number, change in enumerate(changes, 1):
        serial += 1
        ai_row = ai_changes[number - 1] if number <= len(ai_changes) else {}
        verdict = _raw_verdict(ai_row.get('AI判斷'))
        shown_line, version, line = _change_display_line(change)
        if change.get('new_index'):
            change_lines.add(_line(change.get('new_index')))
            if verdict in ('建議修改', '需再檢查'):
                flagged_change_lines.add(_line(change.get('new_index')))
        revised_text, revised_ranges = _revised_text_and_ranges(change)
        old_text, old_ranges = _old_text_and_ranges(change)
        _append(
            page,
            [str(serial), verdict, _score_or_blank(ai_row.get('AI分數')),
             _friendly_reason(_resolve_change_refs(_comparison_reason(ai_row, '異動'), changes)),
             book_name, shown_line,
             _make_rich_text(old_text, old_ranges), _make_rich_text(revised_text, revised_ranges), '', '', '',
             '本次異動／%s' % _change_kind(change),
             _resolve_change_refs(_change_suggestion(ai_row.get('AI判斷'), ai_row.get('AI理由')), changes)],
            links=((_CMP_MODIFIED_LINE, version, line),))

    for row in book.get('rows') or []:
        # 純引用找不到目標的列改由引用檢查報告呈現；混合來源仍保留在條文比對。
        if (_external_only(row) or _internal_citation_only(row) or _is_empty_candidate(row)
                or _candidate_already_uses_ai_replacement(row)):
            continue
        verdict = _raw_verdict(row.get('AI判斷'))
        candidate_line = row.get('候選段次') or ''
        # 候選段就是本本的異動段本身（舊寫法還留在同一段）：同一件事上面那一列已經要人看了，
        # 或 AI 說這一段不用跟著改，就不再列第二次（以前同一個括號錯誤在報告上出現兩列）
        if _line(candidate_line) in change_lines and (
                verdict == '不用改' or _line(candidate_line) in flagged_change_lines):
            continue
        serial += 1
        modified_book, modified_line, _places, old_text, modified_text = _candidate_change_fields(
            row, book, book_name, books)
        if not str(modified_text).strip():
            # 「引用的章節這次內容有改」這類列沒有單一一段異動可以對（以前三欄空白，看不出為什麼列出來）
            why = _plain(row.get('關係／分數') or row.get('異動摘要') or '', '原因')
            modified_text = '（沒有對應的單一異動段落：%s）' % (why or '引用指到的地方這次有改')
        check_type = '連帶候選'
        sources = str(row.get('來源') or '').strip()
        if sources:
            check_type += '／' + sources
        links = []
        modified_version = '修訂版'
        modified_number = _line(modified_line)
        if str(modified_line).startswith('現行版'):
            modified_version = '現行版'
        if modified_book and modified_number:
            links.append((_CMP_MODIFIED_LINE, modified_version, modified_number))
        if candidate_line:
            links.append((_CMP_CANDIDATE_LINE, '修訂版', candidate_line))
        # 候選理由裡的 C 編號只換這一列真的掛著的那幾處（見 _resolve_change_refs 的 allowed）
        own = book.get('changes') or []
        linked = set(number for number, item in enumerate(own, 1)
                     for source, change in _changes_for_candidate(row, book, books)
                     if not source and change is item)
        _append(
            page,
            [str(serial), verdict, _score_or_blank(row.get('AI分數')),
             _friendly_reason(_resolve_change_refs(_comparison_reason(row, '候選'), changes, linked)),
             modified_book, modified_line,
             old_text, modified_text, book_name, str(candidate_line), _candidate_original(row, book, books),
             check_type, _resolve_change_refs(_candidate_suggestion(row, row.get('AI判斷')), changes, linked)],
            links=tuple(links))
    return page


def _rule_item_key(check, line, detail, quote):
    return (str(check or ''), str(line or ''), str(detail or ''), str(quote or ''))


_SEVERITY_PREFIX_RE = re.compile(r'^\s*嚴重程度\s*[:：]\s*[^；;]*[；;]?\s*')


def _plain_rule_item(value):
    text = _plain_words_call('plain_rule_item', value)
    return _plain(text or value or '條文內容是否需要確認', '檢查項目')


# 舊產出的用詞混用說明後面帶「（建議統一為「X」）」：報告上不再印（只顯示時拿掉，比對用的原文不動）
_PREFERRED_TERM_RE = re.compile(r'（建議統一為「[^」]*」）')


def _plain_rule_detail(value):
    text = _PREFERRED_TERM_RE.sub('', _SEVERITY_PREFIX_RE.sub('', _original(value)))
    return _plain(text or '程式沒有提供額外說明。', '說明')


def _is_citation_check(check):
    text = _original(check).replace(' ', '')
    return '引用' in text or '外部法規' in text or '外部規章' in text


def _is_external_citation_check(check):
    text = _original(check).replace(' ', '')
    return '外部' in text and '引用' in text


_INTERNAL_CITATION_SOURCES = frozenset(("條文引用", "章節引用", "跨本引用"))
_INTERNAL_CITATION_PROBLEM_RE = re.compile(
    r"【(?:危險|無法判定|推測)】|新版中不存在|舊版找不到|指到的(?:地方|章節|條文).*?(?:刪|不存在)|引用.*?(?:找不到|不存在)")
_INTERNAL_CITATION_QUOTE_RE = re.compile(r"「([^」]+)」")


def _citation_sources(row):
    return tuple(part.strip() for part in _original(row.get("來源")).split("；") if part.strip())


def _is_unresolved_internal_citation_row(row):
    sources = _citation_sources(row)
    if not set(sources) & _INTERNAL_CITATION_SOURCES:
        return False
    text = "；".join(_original(row.get(key)) for key in ("異動內容", "異動摘要", "關係／分數"))
    return bool(_INTERNAL_CITATION_PROBLEM_RE.search(text))


def _internal_citation_only(row):
    sources = _citation_sources(row)
    return bool(sources) and set(sources).issubset(_INTERNAL_CITATION_SOURCES) \
        and _is_unresolved_internal_citation_row(row)


def _citation_quote(value):
    match = _INTERNAL_CITATION_QUOTE_RE.search(_original(value))
    return match.group(1).strip() if match else ""


def _internal_citation_reason(value):
    # 決定表上合併過的列，「異動內容」是這一段所有來源的說明接在一起（別處的「114→115、07.→04.」
    # 也在裡面）。這一頁只講引用找不到目標，只留講引用的那幾段，不然理由欄是一大串看不懂的改動。
    parts = [part for part in _original(value).split("；")
             if _INTERNAL_CITATION_PROBLEM_RE.search(part)]
    text = _plain("；".join(parts) if parts else value, "引用說明")
    return text or "程式找不到這個引用在新版的目標。"


def _notice_internal_citations(outdir):
    """從提醒檔補入找不到目標的內部引用；未進決定表的無法判定項也不能消失。"""
    items, seen = [], set()
    for filename in ("提醒.txt",):
        path = _existing(outdir, filename)
        if not path:
            continue
        for raw in _read_text(path).splitlines():
            parts = raw.split("｜", 2)
            if len(parts) != 3 or parts[1] != "Step 0.5":
                continue
            text = _original(parts[2])
            if not ("條文引用" in text or "章節重編後的引用" in text or "章節引用" in text):
                continue
            if not _INTERNAL_CITATION_PROBLEM_RE.search(text):
                continue
            line_match = re.search(r"第\s*(\d+)\s*段", text)
            line = line_match.group(1) if line_match else ""
            quote = _citation_quote(text)
            key = (line, quote, text)
            if key in seen:
                continue
            seen.add(key)
            items.append({"段次": line, "引用": quote, "說明": text})
    return items


def _score_or_label(value, fallback='不評分'):
    text = _original(value).strip()
    if re.fullmatch(r'(?:10|[0-9])', text):
        return int(text)
    return text or fallback


def _present_reason(kind, verdict, reason, fallback):
    raw = _original(reason).strip()
    if not raw:
        return fallback
    plain = _plain_reason(kind, raw, verdict)
    return plain or fallback


def _rulecheck_ai_data(outdir):
    items = list(rp.rulecheck_items(outdir) or [])
    expected = {str(item.get('sha') or ''): item for item in items if item.get('sha')}
    valid = {}
    for row in _ai_table_rows(outdir, 'AI條文檢查.csv'):
        sha = str(row.get(rp.RULECHECK_SHA_COLUMN) or '').strip()
        if sha in expected:
            valid[sha] = row
    by_key = {}
    by_simple = {}
    for item in items:
        key = _rule_item_key(item.get('check'), item.get('段次'), item.get('detail'), item.get('quote'))
        by_key.setdefault(key, item)
        by_simple.setdefault((key[0], key[1], key[2]), item)
    return items, valid, by_key, by_simple


def _paragraph(paragraphs, line):
    number = _line(line)
    return _original(paragraphs[number - 1]) if 1 <= number <= len(paragraphs or []) else ''


RULECHECK_REFERENCE = '參考（程式統計）'


def _rulecheck_state_for(item, ai_rows):
    if item is None:
        # 全篇用詞、括號全半形這類統計沒有送 AI 審：不是 AI「判斷不了」，
        # 標成無法判斷會讓人以為 AI 看過、卡住了
        return RULECHECK_REFERENCE, '不評分', \
            '程式統計全篇的結果，沒有送 AI 審，跟這次修改不一定有關；有空再看。', ''
    ai_row = ai_rows.get(str(item.get('sha') or ''), {})
    if not ai_row:
        return '無法判斷', '不評分', '找不到對應的條文檢查資料，無法判斷。', ''
    raw_verdict = _original(ai_row.get('AI判斷')).strip()
    if not raw_verdict:
        return '無法判斷', _score_or_label(ai_row.get('AI分數'), '不評分'), \
            '已有資料列，但沒有判定結果，無法判斷。', _original(ai_row.get('查證來源') or '')
    verdict = _raw_verdict(raw_verdict)
    reason = _present_reason(
        '條文檢查', verdict, ai_row.get('AI理由'),
        'AI 已給出判定，但未提供理由。')
    return verdict, _score_or_label(ai_row.get('AI分數'), '不評分'), reason, _original(ai_row.get('查證來源') or '')


def _rulecheck_source_rows(outdir):
    rows = []
    for _table_name, header, table_rows in _load_report_tables(
            outdir, '條文檢查報告.xlsx', ('條文檢查報告.csv',)):
        rows.extend(_table_dict_rows(header, table_rows))
    return rows


RULECHECK_EXCLUDED_ITEMS = frozenset(('環境', '讀檔', '條文內容是否需要確認'))


def _exclude_rulecheck_item(check):
    return _plain_rule_item(check) in RULECHECK_EXCLUDED_ITEMS


def _rulecheck_display_verdict(verdict):
    # AI 的「需人確認」是查過了、要人拍板（例如業務決定），不是「無法判斷」
    if verdict == '需人確認':
        return '需人工確認'
    return '無法判斷' if verdict in ('不適用', '尚未審查') else verdict


_TODO_CLAUSE = re.compile(r"建議|請確認|請問|請承辦|承辦|改成|改為|補上|補成|補正|統一|刪除|刪掉|應更新|需更新|已過時|過時")


def _todo_clauses(reason):
    """理由裡要人做事的那幾個子句（v1.7.7）：以句號、分號、換行切開，留有「建議、請確認、改成…」的。
    以前 _action_sentences 只認整句，一整段只有一個句號時，建議處理就把整段理由再抄一次。"""
    text = _drop_carry_note(re.sub(r"^\s*〔[^〕]*〕\s*", "", _original(reason)))
    text = re.sub(r"\n?（程式依位置與文字改判[^）]*）", "", text)
    parts = [p.strip(" ，") for p in _split_outside_quotes(text, "。；", keep=False) if p.strip(" ，")]
    # 標籤換成的白話開頭（「這裡需要補正」「這件事要由業務單位決定」）不是要做的事本身，不收
    picked = [p for p in parts if _TODO_CLAUSE.search(p) and not p.startswith("已查過")
              and not re.fullmatch(r"(?:這裡|這處修改)(?:需要補正|可能有問題)|這件事要由業務單位決定", p)]
    return "；".join(dict.fromkeys(picked)) + "。" if picked else ""


def _rule_lines(reason):
    """理由裡提到的段次（「段96、97、102」「段199–210」）：條文檢查的全篇統計沒有單一段次，用 AI 寫的段次。"""
    numbers = []
    for hit in re.finditer(r"段((?:\d+\s*[、，,及與和至–\-~]?\s*)+)", _original(reason)):
        numbers += re.findall(r"\d+", hit.group(1))
    return list(dict.fromkeys(numbers))


def _rulecheck_action(verdict, reason, program_action):
    """建議處理跟著 AI 判定走：AI 說沒問題就不用改（以前照樣叫人「確認是否補施行條文」）；
    要人處理時先放 AI 理由裡寫的那幾句，沒有才用程式的通用建議。"""
    if verdict == '沒問題':
        return '不用改'
    return _action_sentences(reason) or _plain(program_action or '請確認後處理')


def _append_rulecheck_row(page, serial, verdict, reason, check, book_name,
                          line, original, detail, quote, action, health=False):
    _append(
        page,
        [str(serial), _rulecheck_display_verdict(verdict), reason, _plain_rule_item(check), book_name, str(line or ''),
         _original(original), _plain_rule_detail(detail), _original(quote),
         ('不用改' if verdict == '沒問題' else _plain(action or '請確認後處理')) if health
         else _rulecheck_action(verdict, reason, action)],
        links=((5, '修訂版', line),))


def _health_book(outdir):
    """這一本是不是體檢那一輪的（各本在 產出/2_Log檔案/<規章>/，體檢標記在 產出/2_Log檔案/輸入/體檢.json）。"""
    try:
        import batch as bt
    except ImportError:
        return False
    here = os.path.abspath(outdir or "")
    for root in (here, os.path.dirname(os.path.dirname(here))):
        if root and bt.is_health_round(root):
            return True
    return False


def _build_rulecheck_report(book, outdir, book_name, books=None):
    page = _page('條文檢查報告', RULECHECK_HEADER)
    items, ai_rows, by_key, by_simple = _rulecheck_ai_data(outdir)
    seen = set()
    source_rows = _rulecheck_source_rows(outdir)
    # 這次沒修改的本：全篇統計跟這一輪無關，不列（以前沒改的參、柒、陸篇也各列一串用詞統計）。
    # 體檢例外：沒有修訂版，每一本都「沒修改」，全篇檢查正是要看的東西（v1.6.0 以前整頁空白）
    changes = _changes(book, outdir)
    health = _health_book(outdir)
    unchanged = not changes and not health
    serial = 0
    for source in source_rows:
        check = source.get('檢查項目') or source.get('check') or ''
        if _is_citation_check(check) or _exclude_rulecheck_item(check):
            continue
        line = source.get('段次') or source.get('index') or ''
        detail = source.get('說明') or source.get('程式發現') or source.get('detail') or ''
        quote = source.get('相關原文') or source.get('quote') or ''
        item = by_key.get(_rule_item_key(check, line, detail, quote))
        if item is None:
            item = by_simple.get((str(check), str(line), str(detail)))
        if item is None and unchanged:
            continue
        if item is not None:
            seen.add(str(item.get('sha') or ''))
        verdict, score, reason, _source = _rulecheck_state_for(item, ai_rows)
        reason = _resolve_change_refs(reason, changes)
        program_action = source.get('建議處理') or source.get('action') or (item or {}).get('action') or ''
        if health:
            # 體檢沒有修改：「這處修改需要補正」說法不對；建議處理用 AI 理由裡的改法（以前是程式通用句，
            # 還跟 AI 建議打架：AI 說改半形、程式說「通常內規慣用全形」）；全篇統計沒有段次，用理由裡的段次
            reason = reason.replace("這處修改需要補正。", "這裡需要補正。").replace("這處修改", "這裡")
            if verdict != '沒問題':
                program_action = _todo_clauses(reason) or program_action
            if not str(line).strip():
                lines = _rule_lines(reason)
                line = "、".join(lines[:15]) + ("等" if len(lines) > 15 else "")
        serial += 1
        _append_rulecheck_row(
            page, serial, verdict, reason, check, book_name, line,
            _paragraph(_shown_or_raw(book, "new"), _line(line)) if health else
            _paragraph(book.get('new_paragraphs') or [], line), detail, quote, program_action,
            health=health)

    # 正式檢查報告缺列時，仍保留交給 AI 的非引用高風險項，不能靜默漏掉。
    for item in items:
        sha = str(item.get('sha') or '')
        if (sha in seen or _is_citation_check(item.get('check'))
                or _exclude_rulecheck_item(item.get('check'))):
            continue
        verdict, score, reason, _source = _rulecheck_state_for(item, ai_rows)
        reason = _resolve_change_refs(reason, changes)
        serial += 1
        line = item.get('段次') or ''
        _append_rulecheck_row(
            page, serial, verdict, reason, item.get('check'), book_name, line,
            _paragraph(book.get('new_paragraphs') or [], line), item.get('detail') or '',
            item.get('quote') or '', item.get('action') or '')

    # 沒有候選原文的資料無法做條文比對；改放這裡，避免把空白列偽裝成候選條文。
    for row in book.get('rows') or []:
        if not _is_empty_candidate(row):
            continue
        line = row.get('候選段次') or ''
        related = _candidate_change_fields(row, book, book_name, books or {book_name: book})[4]
        serial += 1
        _append_rulecheck_row(
            page, serial, '無法判斷',
            '候選資料沒有原文，無法判斷是否需要修改。', '未指定候選段落',
            book_name, line, _paragraph(book.get('new_paragraphs') or [], line),
            _plain_source(row), related,
            '確認候選段次或重新執行比對。')
    return page


CITATION_PROGRAM_WRONG = '程式誤判'
CITATION_PROGRAM_MISSED = '程式漏抓'
# 外部引用的 AI 標籤，哪些是「程式抓錯」（手冊原文沒錯，匯入時自動修登錄表／排除表，見 scoring_rubric.EXTERNAL）
_PROGRAM_SIDE_LABELS = ('名稱錯誤', '非外部法規')


def _citation_view(verdict, ai_row, reason):
    """(報告上的判定, 建議處理)。

    AI 判「有誤」有兩種完全不同的事：〔名稱錯誤〕〔非外部法規〕是程式把名稱剪錯、把手冊自己
    當成外部法規——手冊原文是對的；〔引用過時〕〔條號錯誤〕才是手冊要改。以前兩種都顯示「有誤」、
    建議處理「改成：保險業務員管理規則第6條」，看起來像要人改手冊，照做反而把對的簡稱改掉。
    「漏抓」也是程式的事：程式沒抓到，AI 補查了；AI 理由裡有要人做的事（引用已過時）就放進建議處理。"""
    value = str(verdict or '').strip()
    label = _reason_label((ai_row or {}).get('AI理由'))
    correction = _original((ai_row or {}).get('AI更正') or '').strip()
    actions = _action_sentences((ai_row or {}).get('AI理由') or reason)
    if value == '有誤' and label in _PROGRAM_SIDE_LABELS:
        return CITATION_PROGRAM_WRONG, actions or '手冊不用改（程式抓錯，匯入時已自動修正）'
    if value == '漏抓':
        # 漏抓列的標籤是 AI 查證的結果：引用過時、條號錯誤的是手冊要改，其餘手冊不用改
        if label in ('引用過時', '條號錯誤'):
            return CITATION_PROGRAM_MISSED, actions or '請依判定理由更新引用'
        if label in ('本行內規', '查無資料'):
            return CITATION_PROGRAM_MISSED, actions or '請承辦確認引用內容'
        return CITATION_PROGRAM_MISSED, actions or '手冊不用改（AI 已核對；下一輪程式會抓到）'
    if value == '有誤':
        fix = ('改成：%s' % correction) if correction else ''
        # AI 那幾句裡常常連改法一起寫（「改成「X」，並請承辦把…一併改成…」）：放 AI 的句子，
        # 前面再補一次乾淨的「改成：X」，不能因為怕重複就把後半句要人做的事丟掉
        return value, '；'.join(part for part in (fix, actions) if part) or '請依 AI 判定處理'
    if value == '沒問題':
        return value, ('不用改；另請注意：%s' % actions) if actions else '不用改'
    if value == '無法查證':
        return value, actions or '請承辦確認引用內容'
    return value, '無法判斷，請補查證資料'


def _imported_external_by_sha(outdir):
    """讀本輪匯入快照；重打包後 AI 表空白時仍可顯示已匯入的外部引用結果。"""
    path = _existing(outdir, 'AI審查匯入狀態.json')
    if not path:
        return {}
    try:
        with open(path, encoding='utf-8') as source:
            status = json.load(source)
    except (OSError, ValueError, TypeError):
        return {}
    rows = status.get('外部引用結果') if isinstance(status, dict) else []
    out = {}
    for row in rows or []:
        if not isinstance(row, dict):
            continue
        sha = _original(row.get(rp.EXTERNAL_SHA_COLUMN)).strip()
        verdict = _original(row.get('AI判斷')).strip()
        if sha and verdict:
            out[sha] = row
    return out


def _citation_state_for(item, by_id, confirmations=None):
    citation_id = str(item.get('引用ID') or '').strip()
    ai_row = dict(by_id.get(citation_id, {}))
    expected_sha = str(item.get('sha') or '')
    raw_verdict = _original(ai_row.get('AI判斷')).strip()
    valid_current = bool(ai_row) and str(ai_row.get(rp.EXTERNAL_SHA_COLUMN) or '').strip() == expected_sha
    if valid_current and raw_verdict:
        verdict = _raw_verdict(raw_verdict)
        reason = _present_reason('外部引用', verdict, ai_row.get('AI理由'),
                                 'AI 已給出判定，但未提供理由。')
        return verdict, _score_or_label(ai_row.get('AI分數'), '不評分'), reason, ai_row

    # review-pack 會重開「無法查證」列，避免跨輪直接沿用；但本輪已匯入的結果留在匯入狀態檔
    # （AI審查匯入狀態.json 的「外部引用結果」）。人用報告優先顯示這份同指紋的已匯入結果，不應退回成「無法判斷」。
    confirmed = dict((confirmations or {}).get(expected_sha, {}))
    if confirmed:
        verdict = _raw_verdict(confirmed.get('AI判斷'))
        reason = _present_reason('外部引用', verdict, confirmed.get('AI理由'),
                                 '已匯入，但未保留 AI 理由。')
        return verdict, '不評分', reason, confirmed
    if not ai_row:
        return '無法判斷', '不評分', '找不到這筆引用資料，無法判斷。', {}
    if not valid_current:
        return '無法判斷', '不評分', 'AI 結果與目前段落文字不符，無法判斷，請重新審查。', {}
    return '無法判斷', _score_or_label(ai_row.get('AI分數'), '不評分'), \
        '已有資料列，但沒有判定結果，無法判斷。', ai_row


def _citation_display_verdict(verdict):
    return '無法判斷' if verdict == '尚未審查' else verdict


CITATION_NEEDS_CHECK = '需人工確認'
CITATION_GUESS = '程式推測'
CITATION_TEXT_FIX = '內文要改'
# 同一段好幾個引用合成一列時，判定取最需要處理的那一個（排越前面越要緊）
_CITATION_ORDER = ('有誤', CITATION_NEEDS_CHECK, CITATION_TEXT_FIX, '無法查證', CITATION_GUESS,
                   '無法判斷', '沒問題', CITATION_PROGRAM_WRONG)
_CITATION_QUIET = ('沒問題', CITATION_PROGRAM_WRONG)
# 網址不收 < >：AI 偶爾把網址包在 <…> 裡或貼了壞網址，xlsx_writer 會拒收整份連結、檢視報告寫不出來（審查 C15）
_URL_RE = re.compile(r"https?://[^\s；;，,、）)」\"'<>]+")
# AI 理由裡給程式看的話（「加進登錄表後下一輪可判」）：人看了不知道要做什麼
_CITATION_JARGON_RE = re.compile(r"（[^（）]*(?:登錄表|下一輪)[^（）]*）|[，；]?[^，；。]*下一輪程式會抓到[^，；。]*")
_EXTERNAL_INTROS = tuple(sorted(
    set(((getattr(plain_words, '_LABEL_INTROS', None) or {}).get('外部引用') or {}).values()),
    key=len, reverse=True)) if plain_words else ()


def _citation_reason_text(reason):
    """判定欄已經講了結論，理由開頭那句套話（「引用看起來沒有問題。」）拿掉，給程式看的話也拿掉。"""
    text = _original(reason).strip()
    for intro in _EXTERNAL_INTROS:
        if text.startswith(intro) and text[len(intro):].strip():
            text = text[len(intro):].strip()
            break
    return re.sub(r"\s{2,}", " ", _CITATION_JARGON_RE.sub("", text)).strip()


def _citation_action_text(action):
    """「改成：X；改成「X」（名稱補全），並請…」：同一個改法講了兩次，留講得完整的那一句。"""
    parts = [p.strip() for p in _original(action).split("；") if p.strip()]
    kept = []
    for part in parts:
        value = part[len("改成："):] if part.startswith("改成：") else ""
        if value and any(value in other for other in parts if other is not part):
            continue
        if part not in kept:
            kept.append(part)
    return _CITATION_JARGON_RE.sub("", "；".join(kept)).strip("；，。 ") or _original(action)


def _citation_item(line, citation, verdict, reason, action, sources=(), rule=""):
    return {"line": str(line or ""), "citation": _original(citation), "verdict": verdict,
            "reason": reason, "action": action, "sources": list(sources), "rule": rule}


def _external_citation_item(line, citation, verdict, reason, ai_row):
    """一筆外部引用（含 AI 補的漏抓）→ 報告上的一項。判定照「人要做什麼」講：
    程式漏抓但 AI 說要更新的是「有誤」；沒問題但 AI 另外發現內文要改的是「內文要改」。"""
    shown, action = _citation_view(verdict, ai_row, reason)
    label = _reason_label((ai_row or {}).get('AI理由'))
    text = _citation_reason_text(reason)
    if shown == CITATION_PROGRAM_MISSED:
        if action.startswith('手冊不用改'):
            shown = '沒問題'
        elif label in ('引用過時', '條號錯誤') or '改成' in action:
            shown = '有誤'            # AI 補查後給了改法：手冊要改
        elif label in ('本行內規', '查無資料'):
            shown = '無法查證'
        else:
            shown = CITATION_NEEDS_CHECK
        text = "程式原本沒抓到這個引用，AI 補查：" + text
    elif shown == '沒問題' and action.startswith('不用改；另請注意：'):
        shown, action = CITATION_TEXT_FIX, action[len('不用改；另請注意：'):]
        action = re.sub(r"^(?:另提醒|另請注意|但請承辦注意|請承辦注意|附帶發現|另)[：:，,]?\s*", "", action)
    rule = ""
    category = _original((ai_row or {}).get('類別')).strip()
    if shown == '無法查證' and (category == '本行內規' or label == '本行內規'):
        rule = re.sub(r"（未指明條號）$", "", _original(citation)).strip()
    raw_source = _original((ai_row or {}).get('查證來源'))
    # v1.9.0：查證來源也可以是規範資料庫裡的一份（「資料庫：外部規範/檔名.pdf」）
    sources = _URL_RE.findall(raw_source) + _LIBRARY_SOURCE_RE.findall(raw_source)
    return _citation_item(line, citation, shown, text or reason, _citation_action_text(action), sources, rule)


_LIBRARY_SOURCE_RE = re.compile(r"資料庫：(?:外部規範|內部規範)/.+?\.(?:pdf|docx|txt|md)", re.I)


# AI候選判斷 的判斷字 → 引用檢查報告的判定（內部引用那幾列）
_INTERNAL_AI_VIEW = {'建議修改': CITATION_TEXT_FIX, '需再檢查': CITATION_NEEDS_CHECK, '不用改': '沒問題'}


_CITE_FINE_RE = re.compile(r"未換號|沒有換號|沒換號|指得到|指對了|仍正確|沒有錯|無誤|指的沒錯")
_CITE_FIX_RE = re.compile(r"但|請確認|改成|改為|建議|應改|要改|錯")


def _citation_fine_clause(reason, citation):
    """v1.25.0：決定表那一列判「建議修改」，AI 理由裡講這個內部引用本身的那一句卻說沒問題
    （肆732：要改的是「整份要保文件」，「「前款」指(四)…，未換號」）：回那一句，引用那一列照那一句判沒問題。
    那一句也有「但、請確認、改成」的不算（肆996：指得到，但層級用語錯）。"""
    if not citation:
        return ""
    for clause in re.split(r"[。\n]", _original(reason)):          # 整句看：「指得到；但層級用語錯」不算
        clause = clause.strip(" ，")
        if "「%s」" % citation in clause and _CITE_FINE_RE.search(clause):
            rest = clause.replace("「%s」" % citation, "")
            if not _CITE_FIX_RE.search(re.sub(_CITE_FINE_RE, "", rest)):
                return clause + "。"
    return ""


def _internal_citation_item(line, citation, raw_reason, row=None):
    """手冊、規章自己的條款引用（決定表上的條文引用、提醒檔裡的無法判定）。
    【推測】是手冊的相對引用用字跟層級對不上、程式只找到一種可能（renumber.outline_reference_findings）。
    row（決定表那一列）有 AI 判斷時照 AI 寫：判定、AI 理由在前，程式的猜測接在後面（v1.6.0）。"""
    text = _internal_citation_reason(raw_reason)
    # 「【危險】「第三十三條」：引用的…」「條文引用　第76段引用「X」（危險）：…」：判定欄、引用欄
    # 已經講了，理由只留後面那句
    text = re.sub(r"^(?:條文引用\s*)?(?:第\d+段引用「[^」]*」（[^）]*）：|【[^】]*】(?:「[^」]*」：)?)", "",
                  text).strip() or text
    verdict = _original((row or {}).get('AI判斷')).strip()
    if verdict in _INTERNAL_AI_VIEW:
        reason = _friendly_reason(_original(row.get('AI理由')).strip()) or 'AI 已判定，但未提供理由。'
        shown = _INTERNAL_AI_VIEW[verdict]
        fine = _citation_fine_clause(_original(row.get('AI理由')), citation) if shown != '沒問題' else ""
        if fine:
            # 這一列要改的是別的事（條文比對報告那一列已經寫了）：引用本身沒問題
            return _citation_item(line, citation, '沒問題', "%s\n（程式：%s）" % (fine, text), '不用改')
        if shown == '沒問題':
            action = '不用改'
        else:
            action = _action_sentences(reason) or (
                '確認是不是指這裡；是的話可把用字改成跟本手冊的層級一致' if "【推測】" in _original(raw_reason)
                else '確認這個引用應改指哪裡，或刪除／重寫引用。')
        return _citation_item(line, citation or '內部引用', shown, "%s\n（程式：%s）" % (reason, text), action)
    if "【推測】" in _original(raw_reason):
        return _citation_item(line, citation or '內部引用', CITATION_GUESS, text,
                              '確認是不是指這裡；是的話可把用字改成跟本手冊的層級一致')
    return _citation_item(line, citation or '內部條文引用', CITATION_NEEDS_CHECK, text,
                          '確認這個引用應改指哪裡，或刪除／重寫引用。')


# 判沒問題（或程式誤判）的理由裡，要承辦做的事（補全銜、版本過時、請確認）：不能藏（v1.7.7）
_OFFICER_TODO_RE = re.compile(r"承辦|請確認|過時|已修正|已非最新|建議")


def _asks_officer(reason):
    """理由裡有要承辦做的事嗎（「程式誤判…改成「X」」是程式自己修登錄表，不算）。"""
    todo = _todo_clauses(reason)
    return bool(todo and _OFFICER_TODO_RE.search(todo))


def _merged_citation_row(items, book_name, paragraphs):
    """同一段的幾個引用合成一列：判定取最要緊的；理由、建議處理一個引用一行。"""
    rank = dict((name, i) for i, name in enumerate(_CITATION_ORDER))
    unique = {}
    for item in items:                   # 同一個引用、同一個結論寫了兩次（同段出現兩次）：留一個
        unique.setdefault((item["citation"], item["verdict"], item["reason"]), item)
    items = sorted(unique.values(), key=lambda item: rank.get(item["verdict"], len(rank)))
    verdict = items[0]["verdict"]
    line = items[0]["line"]
    citations = list(dict.fromkeys(item["citation"] for item in items if item["citation"]))
    if len(items) == 1:
        reason, action = items[0]["reason"], items[0]["action"]
    else:
        # 要處理的一個引用一行；不用處理的同一種結論合成一句（不然一長串「程式誤判」蓋過要看的那幾行）
        # v1.25.0：不用處理的那幾個，理由裡有要承辦做的事（伍281「多一個頓號，改成全銜」）也一行一行寫，
        # 不合成「程式誤判（手冊不用改）：「…」」——以前合起來就看不到那句，單獨一列時反而看得到
        loud = [item for item in items if item["verdict"] not in _CITATION_QUIET
                or _asks_officer("%s\n%s" % (item["reason"], item["action"]))]
        lines = ["「%s」：%s" % (item["citation"], item["reason"] or item["action"]) for item in loud]
        for quiet in _CITATION_QUIET:
            names = list(dict.fromkeys(item["citation"] for item in items
                                       if item["verdict"] == quiet and item not in loud))
            if names:
                lines.append("%s：%s" % ("沒問題" if quiet == "沒問題" else "程式誤判（手冊不用改）",
                                        "、".join("「%s」" % name for name in names)))
        reason = "\n".join(lines)
        todo = [item for item in loud if item["action"] and item["action"] != "不用改"]
        if len(set(item["action"] for item in todo)) == 1:
            action = todo[0]["action"]          # 每個引用要做的事都一樣：講一次就好
        else:
            action = "\n".join("「%s」：%s" % (item["citation"], item["action"]) for item in todo) or "不用改"
    sources = list(dict.fromkeys(url for item in items for url in item["sources"]))
    return [ "", verdict, reason, book_name, line, _paragraph(paragraphs, line),
             "\n".join(citations), _plain(action or '請確認後處理'), "\n".join(sources)]


def _citation_rule_rows(rules, book_name):
    """本行自訂的規章（網路查不到）：同一個名稱只列一列，寫出它出現在哪幾段。"""
    rows = []
    for name, lines in rules.items():
        lines = sorted(set(lines), key=_line)
        rows.append(["", '無法查證',
                     "本行自訂的規章，網路查不到。這一份手冊有 %d 段引用它。" % len(lines),
                     book_name, "、".join(lines), "出現在第%s段" % "、".join(lines), name,
                     "確認這個規章仍然有效、名稱沒有改；名稱改了，這幾段要一起改。", ""])
    return rows


def _build_citation_report(book, outdir, book_name):
    """引用檢查報告：同一段的引用放同一列；本行自訂規章另外合併成一列一個規章。"""
    page = _page('引用檢查報告', CITATION_HEADER)
    paragraphs = book.get('new_paragraphs') or []
    items = []
    by_id = _ai_rows_by_id(_ai_table_rows(outdir, 'AI外部引用.csv'), '引用ID')
    confirmations = _imported_external_by_sha(outdir)
    health = _health_book(outdir)
    text_fixes = []
    for item in rp.external_items(book):
        verdict, _score, reason, ai_row = _citation_state_for(item, by_id, confirmations)
        shown = _external_citation_item(item.get('段次'), item.get('引用') or '', verdict, reason, ai_row)
        if health and shown["verdict"] == CITATION_TEXT_FIX:
            text_fixes.append(shown)
            continue
        items.append(shown)

    # 目標找不到、無法判定或程式推測的內部引用：決定表上的列，加上只在提醒檔裡的
    internal_keys = set()
    for row in book.get('rows') or []:
        if not _is_unresolved_internal_citation_row(row):
            continue
        line = _original(row.get('候選段次') or '')
        raw = row.get('異動內容') or row.get('異動摘要') or ''
        for part in [p for p in _original(raw).split("；") if _INTERNAL_CITATION_PROBLEM_RE.search(p)] or [raw]:
            citation = _citation_quote(part)
            key = (_line(line), citation)
            if key in internal_keys:
                continue
            internal_keys.add(key)
            items.append(_internal_citation_item(line, citation, part, row))
    for notice in _notice_internal_citations(outdir):
        key = (_line(notice.get('段次')), notice.get('引用') or '')
        if key in internal_keys:
            continue
        internal_keys.add(key)
        items.append(_internal_citation_item(notice.get('段次'), notice.get('引用'), notice.get('說明') or ''))

    # 條文檢查裡的引用類（附表引用）：沒有 AI 外部引用審查，要人看
    for source in _rulecheck_source_rows(outdir):
        check = source.get('檢查項目') or source.get('check') or ''
        if not _is_citation_check(check) or _is_external_citation_check(check):
            continue
        quote = source.get('相關原文') or source.get('quote') or ''
        items.append(_citation_item(
            source.get('段次') or source.get('index') or '', quote or _plain_rule_item(check),
            CITATION_NEEDS_CHECK, '內文提到附表或附件，程式在全文找不到對應的表、或名稱對不上；這一項由承辦確認。',
            source.get('建議處理') or source.get('action') or '確認附表、附件的編號與名稱對得上。'))

    # AI 補列的程式漏抓
    for ai_row in _ai_table_rows(outdir, 'AI外部引用.csv'):
        if str(ai_row.get('引用ID') or '').strip() != '新增' or str(ai_row.get('AI判斷') or '').strip() != '漏抓':
            continue
        line = _line(ai_row.get('段次'))
        citation = _original(ai_row.get('AI更正') or ai_row.get('程式抓到') or '')
        if not line or not citation:
            continue
        reason = _present_reason('外部引用', '漏抓', ai_row.get('AI理由'),
                                 'AI 判定有一筆引用可能漏抓，但未提供理由。')
        items.append(_external_citation_item(line, citation, '漏抓', reason, ai_row))

    rules = {}
    groups = {}
    for item in items:
        if item["rule"]:
            rules.setdefault(item["rule"], []).append(item["line"])
            continue
        groups.setdefault(_line(item["line"]) or item["line"], []).append(item)
    shown, quiet = [], []
    for key in sorted(groups, key=lambda k: (k if isinstance(k, int) else 10 ** 9, str(k))):
        row = _merged_citation_row(groups[key], book_name, paragraphs)
        (quiet if row[1] in _CITATION_QUIET else shown).append(row)
    # 順序：要人處理的（照段次）→ 本行自訂規章清單 → 不用處理的（排序時移到最後並隱藏）
    for row in shown + _citation_rule_rows(rules, book_name) + quiet:
        _append(page, row, links=((4, '修訂版', row[4]),))
    for number, row in enumerate(page['rows'], 1):
        row[0] = str(number)
    page['text_fixes'] = text_fixes          # 體檢：build_batch 把它們放進條文比對報告
    return page


def _build_segment_report(segment_rows, book_name):
    page = _page('段次總表', SEGMENT_HEADER)
    for row in segment_rows:
        _append(page, [book_name, _original(row[0]), _original(row[1]), _original(row[2]), _original(row[3])])
    return page


def _parse_segment_value(value, default_version='修訂版'):
    text = str(value or '').strip()
    for version in ('現行版', '修訂版'):
        if text.startswith(version):
            return version, _line(text)
    return default_version, _line(text)


def _lines_from_value(value):
    """一格可能列出多個段次；每個段次都建立可點的連結。"""
    out = []
    for piece in str(value or '').splitlines():
        version, line = _parse_segment_value(piece)
        if line:
            pair = (version, line)
            if pair not in out:
                out.append(pair)
    if not out:
        version, line = _parse_segment_value(value)
        if line:
            out.append((version, line))
    return out


def _four_sheet_options(page, segment_map):
    links = []
    if page['header'] == HEALTH_COMPARE_HEADER:
        for row_number, row in enumerate(page['rows'], 2):
            for book_col, line_col in ((4, 5), (8, 9)):
                target = segment_map.get((str(row[book_col]), '修訂版', _line(row[line_col])))
                if target:
                    links.append({'ref': '%s%d' % (_column(line_col), row_number),
                                  'target_sheet': '段次總表', 'target_ref': 'A%d' % target})
    elif page['name'] == '條文比對報告':
        for row_number, row in enumerate(page['rows'], 2):
            modified_book, modified_value = row[_CMP_MODIFIED_BOOK], row[_CMP_MODIFIED_LINE]
            for version, line in _lines_from_value(modified_value):
                target = segment_map.get((str(modified_book), version, line))
                if target:
                    links.append({'ref': '%s%d' % (_column(_CMP_MODIFIED_LINE), row_number),
                                  'target_sheet': '段次總表', 'target_ref': 'A%d' % target})
                    break  # 同一格只能放一個 Excel 超連結
            candidate_book, candidate_line = row[_CMP_CANDIDATE_BOOK], row[_CMP_CANDIDATE_LINE]
            target = segment_map.get((str(candidate_book), '修訂版', _line(candidate_line)))
            if target:
                links.append({'ref': '%s%d' % (_column(_CMP_CANDIDATE_LINE), row_number),
                              'target_sheet': '段次總表', 'target_ref': 'A%d' % target})
    elif page['name'] == '條文檢查報告':
        for row_number, row in enumerate(page['rows'], 2):
            book_name, line = row[4], row[5]
            target = segment_map.get((str(book_name), '修訂版', _line(line)))
            if target:
                links.append({'ref': '%s%d' % (_column(5), row_number),
                              'target_sheet': '段次總表', 'target_ref': 'A%d' % target})
    elif page['name'] == '引用檢查報告':
        for row_number, row in enumerate(page['rows'], 2):
            book_name, line = row[3], row[4]
            target = segment_map.get((str(book_name), '修訂版', _line(line)))
            if target:
                links.append({'ref': '%s%d' % (_column(4), row_number),
                              'target_sheet': '段次總表', 'target_ref': 'A%d' % target})
            # 查證來源：第一個網址可以直接點開（一格只能放一個連結，其餘照樣列在格子裡）
            urls = _URL_RE.findall(str(row[8] if len(row) > 8 else ''))
            if urls:
                links.append({'ref': '%s%d' % (_column(8), row_number), 'url': urls[0]})
    columns = max(len(page['header']), max((len(row) for row in page['rows']), default=0))
    header = list(page['header'])
    widths = [_COLUMN_WIDTHS.get(header[column] if column < len(header) else '', _DEFAULT_WIDTH)
              for column in range(columns)]
    return {'freeze_header': True, 'freeze_columns': _FROZEN_COLUMNS.get(page['name'], 0),
            'auto_filter': True,
            'row_styles': {}, 'hidden_rows': list(page.get('hidden_rows') or ()),
            'links': links, 'column_widths': widths}


def _book_pages(outdir, book_name, book, books):
    rows = _decision_rows(None, book)
    changes = _changes(book, outdir)
    segments, _ignored = _segment_rows(book, book_name, changes)
    return [
        _build_comparison_report(book, outdir, book_name, books),
        _build_rulecheck_report(book, outdir, book_name, books),
        _build_citation_report(book, outdir, book_name),
        _build_segment_report(segments, book_name),
    ]


def _segment_map_from_page(page):
    mapping = {}
    for row_number, row in enumerate(page['rows'], 2):
        if len(row) < 3:
            continue
        line = _line(row[2])
        if line:
            mapping[(str(row[0]), str(row[1]), line)] = row_number
    return mapping


def build_book(outdir, book_name='', decisions=None, book=None, books=None):
    """建立四頁人用報告；不寫入檔案。"""
    data = book if isinstance(book, dict) else _safe_book(outdir)
    title = _report_book_label(book_name, outdir)
    # 指定 decisions 只供相容呼叫端覆蓋候選列；其他資料仍以已讀取的本次產出為準。
    if decisions is not None:
        data = dict(data)
        data['rows'] = _decision_rows(decisions, data)
    sources = dict(books or {})
    sources.setdefault(title, data)
    pages = _book_pages(outdir, title, data, sources)
    _sort_pages(pages)
    segment_map = _segment_map_from_page(pages[-1])
    sheets = [(page['name'], page['header'], page['rows']) for page in pages]
    options = [_four_sheet_options(page, segment_map) for page in pages]
    return sheets, options


def _book_entries(books):
    entries = list(books.items()) if isinstance(books, dict) else list(books or [])
    output = []
    for item in entries:
        if isinstance(item, dict):
            name = item.get('規章') or item.get('規章名') or item.get('name') or ''
            folder = item.get('outdir') or item.get('資料夾') or item.get('path') or ''
        elif isinstance(item, (list, tuple)) and len(item) >= 2:
            name, folder = item[0], item[1]
        else:
            continue
        if folder:
            output.append((_report_book_label(name, str(folder)), str(folder)))
    return output


def _build_consistency_report(root):
    """體檢的重複／矛盾頁：AI 判過、匯入過的每一對一列（health_check.import_results 寫的結果檔）。
    矛盾排最前、重複其次；一致、無關移到最後並隱藏（篩選打開就看得到）。"""
    import health_check as hc
    page = _page(CONSISTENCY_SHEET, CONSISTENCY_HEADER)
    rows = sorted(hc.results(root), key=lambda r: (_CONSISTENCY_ORDER.get(r.get("AI判斷"), 9),
                                                   _line(str(r.get("配對ID") or "")[1:])))
    for serial, item in enumerate(rows, 1):
        verdict = str(item.get("AI判斷") or "")
        reason = item.get("AI理由") or ""
        action = _action_sentences(reason) or _CONSISTENCY_DEFAULT_ACTION.get(verdict, "請確認後處理")
        family = "\n" + item["家族說明"] if item.get("家族說明") else ""      # v1.31.0：家族的列講同一家族還有哪幾段
        _append(page, [str(serial), verdict, _friendly_reason(reason) + family,
                       item.get("規章A", ""), str(item.get("段次A", "")), item.get("位置A", ""), item.get("全文A", ""),
                       item.get("規章B", ""), str(item.get("段次B", "")), item.get("位置B", ""), item.get("全文B", ""),
                       action])
    page["hidden_rows"] = [number + 2 for number, item in enumerate(rows) if item.get("AI判斷") in ("一致", "無關")]
    return page


CHECKED_FINE = "已查過、不用改"
_QUIET_LINE = re.compile(r"^(?:沒問題|已查過、不用改)：(.*)$")


def _merge_citation_rows_by_paragraph(page, quiet_limit=12):
    """引用檢查報告同一本、同一段的列合成一列（v1.7.5）：判定取最要緊的；要處理的一條一行理由，
    不用處理的合成一行「已查過、不用改：「…」、「…」」（v1.7.6 以前寫「沒問題」，而且外部引用、法規更新各一行）；
    建議處理相同的只寫一次。段次不是單一數字的列（（全部）、本行自訂規章清單）不合併。"""
    rank = dict((name, i) for i, name in enumerate(_CITATION_ORDER))
    groups, order = {}, []
    for row in page['rows']:
        line = str(row[4] or "").strip()
        key = (str(row[3]), line) if line.isdigit() else ("", id(row))
        if key not in groups:
            groups[key] = []
            order.append(key)
        groups[key].append(row)
    # v1.7.7：照規章、段次排（以前法規更新的列全部排在最後，同一本的段落被拆到兩處）；（全部）的列放最後
    def where(key):
        row = groups[key][0]
        book, numbers = str(row[3]), re.findall(r"\d+", str(row[4] or ""))
        return (1 if book.startswith("（") else 0, book, int(numbers[0]) if numbers else 10 ** 9)
    order.sort(key=where)
    merged = _page(page['name'], page['header'])
    for key in order:
        rows = sorted(groups[key], key=lambda r: rank.get(r[1], len(rank)))
        # v1.27.0：不用處理的列，建議處理裡有要承辦做的事（伍281「多一個頓號，建議承辦一併改成全銜」）也當要看的列，
        # 不合成「程式誤判（手冊不用改）：「…」」——體檢報告同一段還有法規更新列時，以前在這裡被藏掉
        loud = [r for r in rows if r[1] not in _CITATION_QUIET
                or _asks_officer("%s\n%s" % (r[2] or "", r[7] if str(r[7] or "") != "不用改" else ""))]
        quiet = [r for r in rows if not any(r is x for x in loud)]
        lines, fine_chunks = [], []
        for r in loud:
            cites = [c for c in str(r[6] or "").splitlines() if c]
            kept = []
            for text in str(r[2] or "").splitlines():
                hit = _QUIET_LINE.match(text)
                if hit:
                    fine_chunks.append(hit.group(1))      # 各本合過的「沒問題：「…」、「…」」：整段搬到合併的那一行
                else:
                    kept.append(text)
            body = "\n".join(kept) or (str(r[7] or "") if r[1] in _CITATION_QUIET else "")
            # 一列只有一個引用、又跟別列合在一起，才在理由前面標是哪一條
            lines.append("「%s」：%s" % (cites[0], body) if len(cites) == 1 and len(rows) > 1 else body)
        if len(rows) == 1 and not loud:
            # 單獨一列、本身就不用處理：理由照原樣（只把「沒問題：」那一行改說法）
            lines = [re.sub(r"^沒問題：", CHECKED_FINE + "：", t) for t in str(rows[0][2] or "").splitlines()]
        else:
            for verdict, title in (("沒問題", CHECKED_FINE), (CITATION_PROGRAM_WRONG, "程式誤判（手冊不用改）")):
                names = list(dict.fromkeys(c for r in quiet if r[1] == verdict
                                           for c in str(r[6] or "").splitlines() if c))
                parts = (fine_chunks if verdict == "沒問題" else []) + ["「%s」" % c for c in names[:quiet_limit]]
                if not parts:
                    continue
                text = "、".join(parts)
                if len(names) > quiet_limit:
                    text += "等 %d 條" % len(names)
                lines.append("%s：%s" % (title, text))
        actions = list(dict.fromkeys(str(r[7]) for r in loud if r[7])) or [str(rows[0][7] or "不用改")]
        # v1.29.0：有要改的做法，就不再列另一個引用的「不用改」（以前同一格寫「改成：…\n不用改」）
        actions = [a for a in actions if a != "不用改"] or actions
        citations = list(dict.fromkeys(c for r in rows for c in str(r[6] or "").splitlines() if c))
        sources = list(dict.fromkeys(u for r in rows for u in str(r[8] or "").splitlines() if u))
        text = next((r[5] for r in rows if r[5]), "")
        row = ["", rows[0][1], "\n".join(l for l in lines if l), rows[0][3], rows[0][4], text, "\n".join(citations),
               "\n".join(actions), "\n".join(sources)]
        if row[1] in _CITATION_QUIET:
            # 判沒問題（或程式誤判），理由裡卻有要承辦做的事（補全銜、版本過時、請確認）：不能藏（v1.7.7）
            todo = _todo_clauses("\n".join(t for t in str(row[2]).splitlines() if not t.startswith(CHECKED_FINE)))
            # 「程式誤判…改成「X」」是程式自己修登錄表，不算；要承辦做的才算（補全銜、括註版次已非最新、請確認）
            if todo and _OFFICER_TODO_RE.search(todo):
                row[1], row[7] = CITATION_NEEDS_CHECK, todo
        _append(merged, row, links=((4, '修訂版', row[4]),))
    for number, row in enumerate(merged['rows'], 1):
        row[0] = str(number)
    return merged


def _fold_text_fixes_into_law_rows(page, text_fixes):
    """查引用時發現的內文錯字，那一段在引用檢查報告已經有要處理的法規更新列：併進那一列，不在條文比對報告再列一次。"""
    loud = {}
    for row in page['rows']:
        if row[1] not in _CITATION_QUIET and any(c.startswith("【法規更新】") for c in str(row[6] or "").splitlines()):
            loud[(str(row[3]), str(row[4]))] = row
    kept = []
    for item in text_fixes:
        row = loud.get((str(item.get("book", "")), str(item.get("line", ""))))
        if row is None:
            kept.append(item)
            continue
        row[2] = "%s\n查證「%s」時發現：%s" % (row[2], item.get("citation", ""), item.get("reason", ""))
        action = _plain(item.get("action") or "")
        if action and action not in str(row[7]):
            row[7] = "%s\n%s" % (row[7], action)
    return kept


# 理由或改法已經講到版本過時（AI 寫「括註版次已非最新」「改為最新版」）：不再補一句
_VERSION_SAID_RE = re.compile(r"版[本次][^。；\n]{0,12}(?:過時|非最新|不是最新|較舊|已修正)|最新版")


def _version_said(text, latest):
    """理由或改法已經講到版本過時，或已經寫了最新版的日期（「改成…(115.09.30…修正)」「最新修正日為114.11.11」）。"""
    if _VERSION_SAID_RE.search(text):
        return True
    numbers = re.findall(r"\d+", latest or "")
    if len(numbers) != 3:
        return False
    year, month, day = int(numbers[0]), int(numbers[1]), int(numbers[2])
    for y in (year, year - 1911):
        if re.search(r"(?<!\d)%d\s*[./\-年]\s*0?%d\s*[./\-月]\s*0?%d(?!\d)" % (y, month, day), text):
            return True
    return False


def _insert_by_paragraph(page, row):
    """新列插在同一本、段次最接近的要處理列後面（同一本沒有要處理的列：接在要處理的列最後）。"""
    rows = page['rows']
    shown = [i for i, r in enumerate(rows) if not _citation_needs_nothing(r)]
    line = _line(row[4]) or 0
    same = [i for i in shown if str(rows[i][3]) == str(row[3])]
    before = [i for i in same if (_line(rows[i][4]) or 0) <= line]
    if before:
        at = before[-1] + 1
    elif same:
        at = same[0]
    else:
        at = shown[-1] + 1 if shown else 0
    rows.insert(at, row)


def _merge_version_lag(page, paragraphs):
    """引用版本檢查併進引用檢查報告（v1.29.0；以前另開一頁「引用版本檢查」）：手冊括註的法規版本已不是最新的段。
    那一段本來就在表上：引用、理由、建議處理、查證來源補上版本那一句，判定至少「內文要改」；
    不在表上：多一列「內文要改」。改過、新增的列照段次插回要處理的列裡，其餘照舊收到最後。"""
    import law_memory as lm
    rank = dict((name, i) for i, name in enumerate(_CITATION_ORDER))
    by_paragraph = {}
    for row in page['rows']:
        line = str(row[4] or "").strip()
        if line.isdigit():
            by_paragraph.setdefault((str(row[3]), line), row)
    moved = []
    for hit in lm.version_lag(paragraphs):
        key = (str(hit["規章"]), str(hit["段次"]).strip())
        action = "版本註記改成最新版（%s 修正），並確認摘錄的條文是否跟著改" % hit["已知最新版"]
        reason = "〔版本過時〕手冊寫的「%s」是 %s 的版本，已知最新是 %s 修正（依據：%s）" % (
            hit["法規名稱"], hit["手冊寫的版本"], hit["已知最新版"], hit["依據"])
        source = hit.get("來源") or ""
        row = by_paragraph.get(key)
        if row is None:
            row = ["", CITATION_TEXT_FIX, reason, hit["規章"], key[1], hit["全文"], hit["法規名稱"], action, source]
            by_paragraph[key] = row
            moved.append(row)
            continue
        if hit["法規名稱"] not in str(row[6] or ""):
            row[6] = "\n".join(x for x in (str(row[6] or ""), hit["法規名稱"]) if x)
        if source and source not in str(row[8] or ""):
            row[8] = "\n".join(x for x in (str(row[8] or ""), source) if x)
        if _version_said("%s\n%s" % (row[2] or "", row[7] or ""), hit["已知最新版"]):
            continue
        row[2] = "\n".join(x for x in (str(row[2] or ""), reason) if x)
        quiet = str(row[7] or "").startswith("不用改") or str(row[7] or "").startswith("手冊不用改")
        row[7] = action if quiet or not row[7] else "%s\n%s" % (row[7], action)
        if rank.get(row[1], len(rank)) > rank[CITATION_TEXT_FIX]:
            row[1] = CITATION_TEXT_FIX
        if not any(row is r for r in moved):
            moved.append(row)
    if not moved:
        return
    page['rows'] = [r for r in page['rows'] if not any(r is m for m in moved)]
    for row in moved:
        _insert_by_paragraph(page, row)
    _move_rows_to_bottom(page, _citation_needs_nothing)


def _health_ref(loaded, name, line):
    contexts = (loaded.get(name) or {}).get("new_contexts") or []
    index = _line(line) - 1 if _line(line) else -1
    if 0 <= index < len(contexts):
        return (contexts[index] or {}).get("ref") or ""
    return ""


def _dedupe_fixes(actions):
    """同一段好幾個來源的改法（逐段讀的錯漏字、兩段比對、查引用）：改成的字一樣的只留一個（v1.25.0）。
    一個改法「改成「…」」的字全都在另一個改法裡：留字多的那一個；一模一樣的留先來的。"""
    actions = list(dict.fromkeys(a for a in actions if a))
    targets = [set(re.findall(r"改成「([^」]+)」", a)) for a in actions]

    def covered(mine, other):
        # 「應於該指派執行之人員變更」跟「指派執行之人員」是同一個改法（一個多帶前後幾個字）
        return all(any(t in u or u in t for u in other) for t in mine)
    keep = []
    for i, action in enumerate(actions):
        mine = targets[i]
        if mine and any(j != i and other and covered(mine, other)
                        and (len(other) > len(mine) or (len(other) == len(mine) and j < i))
                        for j, other in enumerate(targets)):
            continue
        keep.append(action)
    return keep


def _build_health_compare_report(root, loaded, text_fixes, old_page=None):
    """體檢報告的條文比對報告（v1.7.7 重寫）。
    同一段的錯漏字、兩段比對發現的錯漏字、查引用時發現的內文錯字合成一列（以前同一個錯字列兩三次）；
    兩段比對的錯漏字，A 欄放寫錯的那一段、B 欄放寫對的那一段當對照；矛盾的建議處理只放要做的事（以前整段理由再抄一次）；
    一致、無關但理由裡有要承辦處理的事，不藏。順序：矛盾 → 錯漏字／內文要改 → 重複 → 有事要看的一致 → 藏起來的。"""
    import health_check as hc
    import health_typo
    page = _page('條文比對報告', HEALTH_COMPARE_HEADER)
    singles, single_order, pairs = {}, [], []

    def paragraph(name, line):
        return _paragraph(_shown_or_raw(loaded.get(name) or {}, "new"), line)

    def add_single(name, line, verdict, reason, kind, action, other=None, ref="", text=""):
        key = (name, str(line))
        if key not in singles:
            singles[key] = {"verdicts": [], "reasons": [], "kinds": [], "actions": [], "other": None,
                            "ref": ref or _health_ref(loaded, name, line), "text": text or paragraph(name, line)}
            single_order.append(key)
        entry = singles[key]
        entry["verdicts"].append(verdict)
        entry["reasons"].append(reason)
        entry["kinds"].append(kind)
        if action:
            entry["actions"].append(action)
        if other and not entry["other"]:
            entry["other"] = other

    for item in health_typo.results(root):
        add_single(item.get("規章", ""), item.get("段次", ""), TYPO_VERDICT, _friendly_reason(item.get("AI理由") or ""),
                   "錯漏字", "「%s」改成「%s」" % (item.get("原文", ""), item.get("改成", "")),
                   ref=item.get("位置", ""), text=item.get("全文", ""))
    for item in text_fixes:
        add_single(item.get("book", ""), item.get("line", ""), CITATION_TEXT_FIX,
                   "查證「%s」時發現：%s" % (item.get("citation", ""), item.get("reason", "")),
                   "引用查證時發現", _plain(item.get("action") or ""))
    squash = lambda t: re.sub(r"\s", "", t or "")
    for item in hc.results(root):
        verdict = str(item.get("AI判斷") or "")
        reason = item.get("AI理由") or ""
        shown_reason = _friendly_reason(reason)
        if item.get("家族說明"):
            shown_reason += "\n" + item["家族說明"]          # v1.31.0：同一家族還有哪幾段
        if item.get("程式改判"):
            shown_reason += "\n（%s；AI 原判「%s」）" % (item["程式改判"], item.get("AI原判", ""))
        side_a = (item.get("規章A", ""), str(item.get("段次A", "")), item.get("位置A", ""), item.get("全文A", ""))
        side_b = (item.get("規章B", ""), str(item.get("段次B", "")), item.get("位置B", ""), item.get("全文B", ""))
        if verdict == TYPO_VERDICT:
            # 哪一段寫錯：理由「改成「X」」的 X 在哪一段原文裡找得到，那一段是對的，另一段是錯的
            target = re.findall(r"改成「([^」]+)」", reason)
            wrong, right = side_a, side_b
            # 家族的列 AI 已經在「有問題的段」指明 A 是寫錯的那段（v1.31.0），不用猜
            if not item.get("家族說明") and target and squash(target[0]) in squash(side_a[3]) \
                    and squash(target[0]) not in squash(side_b[3]):
                wrong, right = side_b, side_a
            add_single(wrong[0], wrong[1], TYPO_VERDICT, shown_reason, "錯漏字（兩段比對）",
                       _todo_clauses(reason) or "照理由補正錯漏字", other=right, ref=wrong[2], text=wrong[3])
            continue
        todo = _todo_clauses(reason)
        if verdict == "矛盾":
            action = todo or _CONSISTENCY_DEFAULT_ACTION["矛盾"]
        elif verdict in ("一致", "無關") and todo:
            action = todo
        else:
            action = _CONSISTENCY_DEFAULT_ACTION.get(verdict, "請確認後處理")
        pairs.append([verdict, shown_reason, "重複／矛盾"] + list(side_a) + list(side_b) + [action])

    rows = []
    for key in single_order:
        entry = singles[key]
        verdict = TYPO_VERDICT if TYPO_VERDICT in entry["verdicts"] else CITATION_TEXT_FIX
        other = entry["other"] or ("", "", "", "")
        rows.append([verdict, "\n".join(dict.fromkeys(entry["reasons"])), "／".join(dict.fromkeys(entry["kinds"])),
                     key[0], key[1], entry["ref"], entry["text"]] + list(other) +
                    ["\n".join(_dedupe_fixes(entry["actions"])) or "請確認後處理"])
    rows += pairs
    # 比對時的列（體檢很少有：例如跨本引用指到別本的異動）照樣留著，換成這一頁的欄位
    for row in (old_page or {}).get('rows') or []:
        rows.append([row[1], row[3], row[11] or "連帶候選", row[8], row[9], "", row[10],
                     row[4], row[5], "", row[7], row[12]])

    def needs_look(row):
        # 一致、無關的列，理由裡真的寫了要處理的事才不藏（「不衝突」「改為通報權責單位」這種描述不算）
        return (row[0] in ("一致", "無關") and row[11] not in (_CONSISTENCY_DEFAULT_ACTION.get(row[0]), "", None)
                and bool(re.search(r"建議|請確認|請問|改成|補「|補上|補成|漏「|漏了|錯字|刪一|誤植", str(row[11]))))
    order = dict(_HEALTH_COMPARE_ORDER)
    rows.sort(key=lambda r: (4.5 if needs_look(r) else order.get(r[0], 4), str(r[3]), _line(r[4]) or 0))
    for row in rows:
        _append(page, [""] + row)
    for number, row in enumerate(page['rows'], 1):
        row[0] = str(number)
    page['hidden_rows'] = [number + 2 for number, row in enumerate(page['rows'])
                           if row[1] in ("一致", "無關", "不用改", "沒問題") and not needs_look(row[1:])]
    return page


def build_batch(root, books):
    """合併多本規章為同一套固定四頁報告（體檢那一輪多一頁「重複矛盾報告」，排在段次總表前面）。"""
    import batch as bt
    entries = _book_entries(books)
    loaded = {name: _safe_book(outdir) for name, outdir in entries}
    pages_by_name = {name: _page(name, header) for name, header in (
        ('條文比對報告', COMPARISON_HEADER),
        ('條文檢查報告', RULECHECK_HEADER),
        ('引用檢查報告', CITATION_HEADER),
        ('段次總表', SEGMENT_HEADER),
    )}
    text_fixes = []
    for name, outdir in entries:
        for local in _book_pages(outdir, name, loaded.get(name) or {}, loaded):
            for item in local.get('text_fixes') or []:
                text_fixes.append(dict(item, book=name))
            combined = pages_by_name[local['name']]
            offset = len(combined['rows'])
            combined['rows'].extend(local['rows'])
            for row_number, style in local['row_styles'].items():
                combined['row_styles'][offset + row_number] = style
    health = bt.is_health_round(root)
    if health:
        import health_law
        citation_page = pages_by_name['引用檢查報告']
        for row in health_law.report_rows(root, loaded):
            _append(citation_page, row, links=((4, '修訂版', row[4]),))
        pages_by_name['引用檢查報告'] = _merge_citation_rows_by_paragraph(citation_page)
        text_fixes = _fold_text_fixes_into_law_rows(pages_by_name['引用檢查報告'], text_fixes)
    pages = [pages_by_name[name] for name in SHEET_ORDER]
    _sort_pages(pages)
    # 批次序號必須跨規章連續，段次總表沒有序號。
    for page in pages[:3]:
        for number, row in enumerate(page['rows'], 1):
            row[0] = str(number)
    if health:
        # 體檢沒有修訂版：條文比對報告改成「內文本身的問題」——重複／矛盾（兩段對照）、錯漏字、
        # 查引用時順便發現的內文錯字（v1.7.0；以前重複／矛盾另一頁、條文比對報告空白）
        pages[0] = _build_health_compare_report(root, loaded, text_fixes, pages[0])
    segment_map = _segment_map_from_page(pages[-1])
    if health:
        # 體檢只有現行版：段次總表的「版本」寫現行版（以前寫修訂版；連結對照表已經建好，改字不影響連結）
        for row in pages[-1]['rows']:
            if row[1] == "修訂版":
                row[1] = "現行版"
    # v1.19.0：引用版本檢查——手冊寫的「法規名稱(113.07.22…修正)」比法規版本表舊的（比對看修訂版、體檢看現行版）。
    # v1.29.0 起併進引用檢查報告（同一段只一列），不再另開一頁
    want = "現行版" if health else "修訂版"
    paragraphs = [(row[0], row[2], row[4]) for row in pages[-1]['rows'] if row[1] == want and str(row[2]).isdigit()]
    for page in pages:
        if page['name'] == '引用檢查報告':
            _merge_version_lag(page, paragraphs)
    sheets = [(page['name'], page['header'], page['rows']) for page in pages]
    options = [_four_sheet_options(page, segment_map) for page in pages]
    # v1.27.0：AI 報告審查的發現不再另開最後一頁「AI報告審查」：查到就直接改 AI 表、重出報告，
    # 改好的內容在原本那一列；審查紀錄只留在 2_Log檔案/AI審查/AI報告審查.csv
    return sheets, options
