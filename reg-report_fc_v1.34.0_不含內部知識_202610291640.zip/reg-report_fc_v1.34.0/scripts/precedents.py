# -*- coding: utf-8 -*-
"""
承辦意見與本單位判例（v1.20.0；v1.22.0 依深度審查重寫對列、判例、白名單）。

檢視報告的主要幾頁最後多一欄「承辦意見」：承辦看報告時直接打（同意、不同意：理由、不是錯字……）。
- 報告重出前，先把舊報告（這一輪的，加上前一輪的）裡的承辦意見讀回來、填回新報告的同一列。
  對列只用每一頁固定幾個不會變的欄（規章、段落原文、法規名稱……，不用段次：前面插一段也對得到）；
  兩列這幾欄完全一樣時照出現順序對，不會互相蓋掉。
- 有意見的列存成「本單位判例」（memoization/內部知識/判例.json）：一列一則，承辦改了意見就換成新的。
  評分標準附最近 30 則（承辦不同意的排前面），AI 慢慢學會本單位的判斷標準。
  承辦不同意的那一段，下一輪不沿用舊答案（見 disputed），一定重判。
- 錯漏字的列寫「不是錯字」：那一列「建議處理」裡「X」改成「Y」的 X（原文片段）記進錯漏字白名單，
  以後同一個原文片段不再列（比對原文片段要完全一樣，不用子字串）。

判例、白名單都是本單位資料：放 memoization/內部知識/，打包分享時照使用者選擇決定要不要包。
"""

import datetime
import glob
import hashlib
import os
import re

OPINION = "承辦意見"
# 加「承辦意見」欄的頁
OPINION_SHEETS = ("依段落彙整", "法規影響報告", "條文比對報告", "條文檢查報告", "引用檢查報告", "重複矛盾報告")
# 對同一列用的欄（有哪幾欄用哪幾欄）：都是程式列的、AI 重判也不會變的。段次不用：前面插一段，段次全部移位
KEY_COLUMNS = ("法規名稱", "條號", "公布或修正日", "修改規章", "修改段落原文", "候選規章", "候選段落原文",
               "規章A", "原文A", "規章B", "原文B", "檢查項目", "規章", "段落原文", "原文", "引用")
# 舊報告沒有上面任何一欄時，退回用「這些以外的欄」
_VOLATILE = ("序號", "AI判定", "判定", "最高判定", "判定分數(0-10)", "最高分數", "判定理由", "建議處理", OPINION,
             "官方來源", "事件ID", "列ID", "查證來源", "相關法規", "檢查類型", "法規原文")
# 判例裡記「這一段原文」的欄（承辦不同意的段落，下一輪不沿用舊答案）
_TEXT_COLUMNS = ("段落原文", "候選段落原文", "修改段落原文", "原文A", "原文B", "原文")
JUDGEMENTS = "判例.json"
WHITELIST = "錯漏字白名單.json"
LIMIT = 30
TYPO_VERDICT = "錯漏字"
_FIX_RE = re.compile(r"「([^」]{2,40})」改成「")
_SQUASH = re.compile(r"[\s\x00-\x1f￾￿]+")


def folder():
    import batch
    return os.path.join(batch.cache_dir(), "內部知識")


def read_json(path, default):
    """讀累積資料的 JSON（v1.22.0）：記事本存的 BOM 也收；讀不出來（壞檔）把它改名留著，回 default——
    以前讀不出來當成空的，下一次存檔就把整份判例、答案庫蓋掉。"""
    from _common import tw_now, tw_today
    import json
    if not os.path.isfile(path):
        return default
    try:
        with open(path, encoding="utf-8-sig") as f:
            value = json.load(f)
    except ValueError:
        stamp = tw_now().strftime("%Y%m%d%H%M%S")
        try:
            os.replace(path, "%s.壞檔-%s" % (path, stamp))
            print("提醒：%s 讀不出來，已改名成 .壞檔-%s 留著（裡面的資料沒刪，可以自己修好再改回來）"
                  % (os.path.basename(path), stamp), flush=True)
        except OSError:
            pass
        return default
    except OSError:
        return default
    return value if isinstance(value, type(default)) else default


def _read(name, default):
    return read_json(os.path.join(folder(), name), default)


def _write(name, value):
    import json
    os.makedirs(folder(), exist_ok=True)
    path = os.path.join(folder(), name)
    with open(path + ".tmp", "w", encoding="utf-8") as f:
        json.dump(value, f, ensure_ascii=False, indent=1)
    os.replace(path + ".tmp", path)


def _squash(value):
    return _SQUASH.sub("", "" if value is None else str(value))[:200]   # 寫進 xlsx 會被清掉的字不算


def _base_key(sheet, header, row):
    columns = [i for i, name in enumerate(header) if name in KEY_COLUMNS]
    if not columns:
        columns = [i for i, name in enumerate(header) if name and name not in _VOLATILE]
    parts = [sheet] + [_squash(row[i] if i < len(row) else "") for i in columns]
    return hashlib.sha256("\x00".join(parts).encode("utf-8")).hexdigest()[:24]


def row_keys(sheet, header, rows):
    """一頁每一列的鍵：頁名＋不會變的欄；這幾欄完全一樣的列加「第幾個」，不會互相蓋掉。"""
    seen = {}
    keys = []
    for row in rows:
        base = _base_key(sheet, header, row)
        seen[base] = seen.get(base, 0) + 1
        keys.append(base if seen[base] == 1 else "%s#%d" % (base, seen[base]))
    return keys


def row_key(sheet, header, row):
    """單獨一列的鍵（不管同頁有沒有重複的列）。"""
    return _base_key(sheet, header, row)


def _read_report(path):
    import report_review as rv
    try:
        return rv._sheets_with_hidden(path)
    except Exception as exc:
        from _common import warn_read_failure
        warn_read_failure(path, exc, "無法取得承辦意見；若是本資料夾最新報告，不改用更舊報告回填，請修復後重跑", "承辦意見")
        raise


def old_reports(base):
    """base（不帶副檔名）旁邊這一輪寫過的報告：檢視報告.xlsx、檢視報告_HHMMSS.xlsx……，新的在前。"""
    found = [p for p in glob.glob(glob.escape(base) + "*.xlsx") if not os.path.basename(p).startswith("~$")]
    # v1.26.0：報告改名之前寫的那一份（同一個資料夾的 檢視報告.xlsx）也讀，承辦寫的意見才帶得過來
    folder = os.path.dirname(os.path.abspath(base))
    for pattern in REPORT_PATTERNS:
        found += [p for p in glob.glob(os.path.join(glob.escape(folder), pattern))
                  if not os.path.basename(p).startswith("~$") and p not in found]
    return sorted(found, key=os.path.getmtime, reverse=True)


def _previous_reports(base):
    """前一輪的報告（重新比對、內規改過重跑法規追蹤會開新一輪：上一輪報告寫的意見要帶到新報告）。"""
    try:
        from _common import previous_output
        output = os.path.dirname(os.path.dirname(os.path.abspath(base)))
        prior = previous_output(output)
    except Exception:
        return []
    return report_files(prior) if prior and os.path.isdir(prior) else []


def harvest(paths, unreadable=None, reports=None):
    """舊報告裡的承辦意見：{列鍵: (意見, 那一列 dict)}。新的報告優先（paths 新的在前）：
    新的那份同一列是空的（承辦清掉了），就不拿更舊那份的意見回來。"""
    found = {}
    blocked = set()
    visited = set()
    for path in paths:
        folder = os.path.normcase(os.path.abspath(os.path.dirname(path)))
        if folder in blocked and unreadable is None and reports is None:
            continue
        latest = folder not in visited
        visited.add(folder)
        try:
            sheets = _read_report(path)
        except Exception:
            if unreadable is not None:
                unreadable.append(path)
            if latest:
                blocked.add(folder)
            continue
        if reports is not None:
            reports.append(path)
        if folder in blocked:
            continue
        for sheet, rows, _hidden in sheets:
            if sheet not in OPINION_SHEETS or not rows or OPINION not in rows[0]:
                continue
            header = rows[0]
            col = header.index(OPINION)
            body = rows[1:]
            for key, row in zip(row_keys(sheet, header, body), body):
                if key in found:
                    continue
                text = str((row[col] if col < len(row) else "") or "").strip()
                found[key] = (text, dict(zip(header, row), 頁=sheet, 鍵=key)) if text else None
    return dict((k, v) for k, v in found.items() if v)


def keep_opinions(sheets, options, base):
    """報告寫出前呼叫：加「承辦意見」欄、填回舊意見、存判例。出錯只印一行，不擋報告。"""
    try:
        filled = add_opinion_column(sheets, options, base)
    except Exception as exc:                  # 舊報告壞掉、讀不到：報告照出，只是沒填回
        print("提醒：讀舊報告的承辦意見失敗（%s），這次報告的承辦意見欄是空的" % exc, flush=True)
        return 0
    if filled:
        print("承辦意見：從上一份報告填回 %d 格（判例已存進 memoization/內部知識/）" % filled, flush=True)
    return filled


def add_opinion_column(sheets, options, base):
    """報告寫出前：主要幾頁最後加「承辦意見」欄，填回舊報告的意見；有意見的列存成判例。
    sheets＝[(頁名, 表頭, 列)]、options 跟它同順序（就地改）。回傳填回幾格。"""
    opinions = harvest(old_reports(base) + _previous_reports(base)) if base else {}
    if opinions:
        remember(opinions.values())
    filled = 0
    for index, (name, header, rows) in enumerate(sheets):
        if name not in OPINION_SHEETS or OPINION in header:
            continue
        new_header = list(header) + [OPINION]
        width = len(header)
        padded = [list(row) + [""] * max(0, width - len(row)) for row in rows]
        new_rows = []
        for key, row in zip(row_keys(name, header, padded), padded):
            text = opinions.get(key, ("", None))[0]
            filled += bool(text)
            new_rows.append(row[:width] + [text])
        sheets[index] = (name, new_header, new_rows)
        if index < len(options) and isinstance(options[index], dict):
            widths = list(options[index].get("column_widths") or [])
            if widths:
                options[index]["column_widths"] = widths[:width] + [20] * max(0, width - len(widths)) + [30]
    return filled


# ---------------------------------------------------------------------------
# 判例與白名單
# ---------------------------------------------------------------------------

def _clip(text, n):
    text = str(text or "").strip()
    return text[:n] + ("…" if len(text) > n else "")


def _summary(row):
    keep = []
    for name in ("法規名稱", "相關法規", "條號", "檢查項目", "修改規章", "修改段次", "候選規章", "候選段次",
                 "規章", "規章A", "段次", "段次A", "規章B", "段次B", "檢查類型"):
        value = str(row.get(name) or "").strip()
        if value:
            keep.append("%s %s" % (name, value[:40]))
    if row.get("修改段落原文"):
        keep.append("修改後「%s」" % _clip(row["修改段落原文"], 50))
    text = row.get("候選段落原文") or row.get("段落原文") or row.get("原文A") or row.get("原文")
    if text:
        keep.append("段落「%s」" % _clip(text, 60))
    return "；".join(keep)


def _texts(row):
    return sorted(set(_squash(row.get(c))[:80] for c in _TEXT_COLUMNS if _squash(row.get(c))))


def _typo_snippets(row):
    """錯漏字那一列的原文片段（建議處理裡「X」改成「Y」的 X）。不是錯漏字的列回 []。"""
    verdict = str(row.get("AI判定") or "")
    kind = str(row.get("檢查類型") or "")
    if verdict != TYPO_VERDICT and TYPO_VERDICT not in kind:
        return []
    return [s.strip() for s in _FIX_RE.findall(str(row.get("建議處理") or "")) if len(s.strip()) >= 2]


def remember(items):
    """[(意見, 列 dict)] → 判例（一列一則：承辦改了意見就換成新的）；錯漏字列寫「不是錯字」，原文片段進白名單。
    回傳 (新記或改了幾則, 新記的白名單片段)。"""
    from _common import tw_now, tw_today
    table = dict((r["鍵"], r) for r in _read(JUDGEMENTS, []) if isinstance(r, dict) and r.get("鍵"))
    words = dict((w["詞"], w) for w in _read(WHITELIST, []) if isinstance(w, dict) and w.get("詞"))
    now = tw_now().strftime("%Y-%m-%d %H:%M:%S")
    changed, new_words = 0, []
    for opinion, row in items:
        sheet = row.get("頁", "")
        key = row.get("鍵") or row_key(sheet, list(row), list(row.values()))
        old = table.get(key)
        if old and old.get("承辦意見") == opinion:
            continue
        changed += 1
        table[key] = {"鍵": key, "頁": sheet, "內容": _summary(row),
                      "AI判定": str(row.get("AI判定") or row.get("最高判定") or row.get("判定") or ""),
                      "AI理由": str(row.get("判定理由") or "")[:200], "承辦意見": opinion,
                      "不同意": disagrees(opinion), "原文": _texts(row), "記錄時間": now,
                      "記錄日": now[:10]}
        if "不是錯字" in opinion or "非錯字" in opinion:
            for snippet in _typo_snippets(row):
                if snippet not in words:
                    new_words.append(snippet)
                    words[snippet] = {"詞": snippet, "說明": opinion[:80], "記錄日": now[:10]}
    if changed:
        _write(JUDGEMENTS, sorted(table.values(), key=lambda r: r.get("記錄時間") or r.get("記錄日", ""), reverse=True))
    if new_words:
        _write(WHITELIST, sorted(words.values(), key=lambda r: r["詞"]))
    return changed, new_words


_AGREE_HEAD = re.compile(r"^[\s「『（(]*(同意|沒問題|OK|ok|贊成|可以)")
_DISAGREE = re.compile(r"不同意|不對|錯了|判錯|有誤|不正確|不認同|應改為|應該是|不應|不適用|不是這樣|不是錯字|非錯字")


def disagrees(opinion):
    """承辦是不是不同意 AI（v1.22.0：「同意，不用改」「同意，改成五日」不算不同意）。"""
    text = str(opinion or "").strip()
    if not text:
        return False
    if _AGREE_HEAD.match(text) and not text.lstrip("「『（( ").startswith("同意不"):
        return "不同意" in text
    return bool(_DISAGREE.search(text))


_disagrees = disagrees                         # 舊名字（v1.20／v1.21 的呼叫端）


_auto_done = set()


def _auto_collect():
    """附判例給 AI 之前，先把目前工作區各輪報告裡新寫的承辦意見收進來（v1.22.0）：
    承辦寫完沒說「收回饋」就直接重新比對、重跑法規追蹤，新寫的意見也會先存成判例再打包。"""
    if os.environ.get("REG_NO_ANSWER_BANK") == "1":
        return
    try:
        import unit_facts as uf
        root = uf.current_workspace()
    except Exception:
        root = ""
    if not root or root in _auto_done or not os.path.isdir(root):
        return
    _auto_done.add(root)
    outputs = [d for d in glob.glob(os.path.join(glob.escape(root), "產出*")) if os.path.isdir(d)]
    try:
        collect(sorted(outputs, key=os.path.getmtime, reverse=True))
    except Exception as exc:
        print("提醒：收承辦意見失敗（%s）" % exc, flush=True)


def lines(limit=LIMIT):
    """附給 AI 的「本單位判例」：最近 limit 則，承辦不同意的排前面。沒有判例回 []。"""
    _auto_collect()
    rows = [r for r in _read(JUDGEMENTS, []) if isinstance(r, dict)]
    if not rows:
        return []
    rows.sort(key=lambda r: r.get("記錄時間") or r.get("記錄日", ""), reverse=True)     # 新的在前
    rows = sorted(rows[:limit], key=lambda r: not disagrees(r.get("承辦意見")))           # 穩定排序：不同意的排前面
    out = ["**本單位判例**（承辦看報告後寫的意見，最近 %d 則；承辦不同意的排前面）："
           "同類的情況照承辦的意思判；承辦不同意的那一段，這一輪一定重判，不要照舊答案寫。" % len(rows)]
    for r in rows:
        out.append("- 〔%s〕%s｜AI 判：%s｜承辦：%s" % (r.get("頁", ""), r.get("內容", ""), r.get("AI判定", ""),
                                                  r.get("承辦意見", "")))
    return out


_dispute_cache = {}


def _disputes():
    """承辦不同意的判例：{原文前 80 字: 意見}（檔案沒變就不重讀：沿用答案時每一列都要問一次）。"""
    path = os.path.join(folder(), JUDGEMENTS)
    try:
        stamp = os.stat(path).st_mtime_ns
    except OSError:
        return {}
    hit = _dispute_cache.get(path)
    if not hit or hit[0] != stamp:
        table = {}
        for r in _read(JUDGEMENTS, []):
            if isinstance(r, dict) and r.get("不同意"):
                for text in r.get("原文") or []:
                    table.setdefault(text, r.get("承辦意見", ""))
        hit = _dispute_cache[path] = (stamp, table)
    return hit[1]


def has_disputes():
    return bool(_disputes())


def disputed(*texts):
    """這幾段原文（任一段）承辦寫過「不同意」嗎：有就回那一句意見，沒有回 ""。沿用舊答案之前先問這一支。"""
    table = _disputes()
    if not table:
        return ""
    for text in texts:
        key = _squash(text)[:80]
        if key and key in table:
            return table[key]
    return ""


def whitelist():
    return [w["詞"] for w in _read(WHITELIST, []) if isinstance(w, dict) and w.get("詞")]


def is_whitelisted(snippet, words=None):
    """錯字的原文片段承辦說過不是錯字（片段要完全一樣，只差空白）。"""
    words = whitelist() if words is None else words
    target = _squash(snippet)
    return bool(target) and any(_squash(w) == target for w in words)


def whitelist_lines():
    words = whitelist()
    if not words:
        return []
    return ["**本單位確認不是錯字的寫法**：承辦看過，下面這些原文片段不是錯字，「原文」一模一樣的不要再列："
            + "、".join("「%s」" % w for w in words)]


# ---------------------------------------------------------------------------
# 收回饋（v1.21.0）：承辦寫完意見跟 AI 說「收回饋」，不用重出報告就存成判例
# ---------------------------------------------------------------------------

COMMAND = "收回饋"
# v1.26.0：比對報告／體檢報告／法規追蹤報告，加上舊的 檢視報告（跟 _common.REPORT_PATTERNS 一樣）
REPORT_PATTERNS = ("比對報告*.xlsx", "體檢報告*.xlsx", "法規追蹤報告*.xlsx", "檢視報告*.xlsx")


PAGES = {"比對": "條文比對報告、條文檢查報告、引用檢查報告", "體檢": "條文比對報告、條文檢查報告、引用檢查報告",
         "法規追蹤": "依段落彙整"}
SHORT_FEEDBACK = "寫回饋：報告最後一欄「承辦意見」可以直接打字（只寫幾列也行），存檔後跟 AI 說「%s」，以後 AI 就照你的判法判。" % COMMAND
_SHOWN = "回饋提示.json"


def feedback_lines(command=COMMAND, kind=""):
    """報告產出後印給人看的那一段：寫回饋有什麼好處、怎麼寫、寫完跟 AI 說什麼。
    kind（比對／體檢／法規追蹤）：只列那份報告真的有的頁（v1.24.0）。"""
    pages = PAGES.get(kind, "條文比對、條文檢查、引用檢查、依段落彙整、法規影響報告")
    return [
        "【寫回饋，AI 會越判越準】報告的%s這幾頁，" % pages +
        "最後一欄是「承辦意見」，覺得 AI 判錯或想補充的列，直接打字就好：",
        "  例：「不同意：這段講外匯業務，不受這條影響」「同意，下次修訂一起改」「不是錯字，本行慣用」。"
        "只寫幾列也可以，空白的列不影響。",
        "  寫了有什麼好處：",
        "  - 你的意見會存成「本單位判例」，以後比對、體檢、法規追蹤三條流程的 AI 都先照你的判法判，"
        "同樣的情況不會再判錯，用越久越懂本單位、越判越準；你寫「不同意」的 AI 最優先參考。",
        "  - 寫「不是錯字」的詞記進本單位慣用語，以後不會再被當成錯字列出來。",
        "  - 報告之後重出，你寫的字會留在原本那一列，不會被蓋掉。",
        "  寫完在 Excel 按存檔，然後跟 AI 說「%s」（或「回饋寫完了」）就好；不用管是哪一條流程。" % command,
    ]


def _content_tag(path):
    import hashlib
    try:
        with open(path, "rb") as f:
            return hashlib.sha256(f.read()).hexdigest()[:16]
    except OSError:
        return int(os.path.getmtime(path))


def screen_feedback(output, kind, report=""):
    """畫面上要印的回饋提示：同一份報告第一次印整段，之後只印一行（v1.24.0：做完之後每說一次「繼續」都重印八行，太長）。"""
    import json
    report = report or (report_files(output) or [""])[0]
    # v1.32.1：用報告內容的指紋，不用修改時間：做完的那一輪每說一次「法規繼續」報告都重寫一次（內容一樣、時間變了），
    # 以前每次都當成新報告、重印整段，回饋提示.json 也每次都變（同步工具以為有改動）
    stamp = "%s|%s" % (os.path.basename(report), _content_tag(report) if report and os.path.isfile(report) else 0)
    path = os.path.join(output, "2_Log檔案", _SHOWN)
    try:
        with open(path, encoding="utf-8") as f:
            seen = json.load(f).get("報告") == stamp
    except (OSError, ValueError, AttributeError):
        seen = False
    if seen:
        return [SHORT_FEEDBACK]
    try:
        os.makedirs(os.path.dirname(path), exist_ok=True)
        with open(path, "w", encoding="utf-8") as f:
            json.dump({"報告": stamp}, f, ensure_ascii=False)
    except OSError:
        pass
    return feedback_lines(kind=kind)


def report_files(output):
    """一個產出資料夾 1_結果彙整/ 裡的報告（含 Excel 開著時另存的 _HHMMSS），新的在前。"""
    folder = os.path.join(output, "1_結果彙整")
    found = []
    for pattern in REPORT_PATTERNS:
        found += [p for p in glob.glob(os.path.join(glob.escape(folder), pattern))
                  if not os.path.basename(p).startswith("~$")]
    return sorted(found, key=os.path.getmtime, reverse=True)


def collect(outputs):
    """收回饋：outputs（產出資料夾，目前那一輪放最前面）每一份報告的承辦意見存成判例。
    回傳 {"報告": 讀了哪幾份, "讀不到": [...], "意見": 幾格, "不同意": 幾格, "新判例": 幾則, "新慣用語": [詞]}。"""
    result = {"報告": [], "讀不到": [], "意見": 0, "不同意": 0, "新判例": 0, "新慣用語": []}
    opinions = {}
    for output in outputs:
        paths = report_files(output)
        for key, value in harvest(paths, result["讀不到"], result["報告"]).items():
            opinions.setdefault(key, value)
    result["意見"] = len(opinions)
    result["不同意"] = sum(1 for text, _row in opinions.values() if _disagrees(text))
    if opinions:
        result["新判例"], result["新慣用語"] = remember(opinions.values())
    return result


def collect_lines(result):
    """收回饋的結果，用人看得懂的話講。"""
    lines = []
    if not result["報告"] and not result["讀不到"]:
        return ["收回饋：這個工作區還沒有報告（1_結果彙整/ 裡沒有比對報告、體檢報告或法規追蹤報告）。"]
    if result["讀不到"]:
        lines.append("收回饋：有 %d 份報告讀不到（%s）：多半是 Excel 還在存檔或檔案壞了，存好再說一次「%s」。"
                     % (len(result["讀不到"]), "、".join(os.path.basename(p) for p in result["讀不到"]), COMMAND))
    if not result["意見"]:
        lines.append("收回饋：讀了 %d 份報告，「承辦意見」欄都還是空的。寫了卻沒收到的話，"
                     "多半是還沒在 Excel 按存檔：存檔後再說一次「%s」。" % (len(result["報告"]), COMMAND))
        return lines
    lines.append("收回饋：讀了 %d 份報告，收到 %d 格承辦意見（其中不同意 %d 格），新存了 %d 則本單位判例。"
                 % (len(result["報告"]), result["意見"], result["不同意"], result["新判例"]))
    if result["新慣用語"]:
        lines.append("  記進本單位慣用語（以後不再當錯字）：%s" % "、".join(result["新慣用語"]))
    lines.append("  從下一輪起，比對、體檢、法規追蹤的 AI 都會先看這些判例再判（存在 skill 的 memoization/內部知識/）。")
    # v1.24.0：講清楚現在這份報告不會變、不同意的段什麼時候重判
    lines.append("  現在這份報告不會跟著改；你寫「不同意」的那幾段，下一輪（重新比對、再體檢或法規追蹤開新一輪）AI 一定重判。")
    if result["新判例"] < result["意見"]:
        lines.append("  有 %d 格以前就收過了，不重複記。" % (result["意見"] - result["新判例"]))
    return lines
