# -*- coding: utf-8 -*-
"""
人工待辦清單：每跑完一個批次指令，列出這一輪走到哪、接下來是誰的事。

人不用記得流程走到哪：打開 目前產出/2_Log檔案/人工待辦.txt（畫面最後也印一份）就知道；
程式能接著做的站一律寫「跑 繼續」（next_step 用同一套判斷決定 繼續 要跑哪一個指令）。
各本走到哪一站用檔案狀態判斷，不另外記狀態，一共三站：
    開始之後現行版或修訂版被換過、改過   → 重新比對（使用者說「重新比對」，底下跑 繼續）
    語意比對、AI 審查還沒做完            → AI 審查（AI 自動完成，不用人填表）
    AI 審查做完、檢視報告產出            → 報告完成（這一輪的最後一站）
"""

import csv
import io
import json
import os
import sys
import datetime

HERE = os.path.dirname(os.path.abspath(__file__))
REGDIFF = os.path.join(HERE, "regdiff")
for _path in (HERE, REGDIFF):
    if _path not in sys.path:
        sys.path.insert(0, _path)

from _common import book_dir, from_record, locate, place

FILE = "人工待辦.txt"
# 批次指令畫面最後印的這一段，是那個指令唯一的「下一步」（各指令自己不再另外印一組，見第四批 26）
SCREEN_HEADER = "下一步（人工待辦，完整清單在 目前產出/2_Log檔案/人工待辦.txt）："
SCREEN_DONE_HEADER = "這一輪的結果（完整清單在 目前產出/2_Log檔案/人工待辦.txt）："
# 「報告完成」：AI 審查做完、檢視報告產出，這一輪的最後一站（不填決定表、不套用、不驗收）
STAGES = ("重新比對", "AI審查", "報告完成")
AI_REVIEW_SKIP = "AI審查略過.txt"        # batch-review-pack --略過 寫在 產出/2_Log檔案/
SEMANTIC_SKIP = "略過.txt"                # batch-semantic --略過 寫在 產出/2_Log檔案/語意候選/


def _mtime(path):
    return os.path.getmtime(path) if path and os.path.isfile(path) else 0


def _warnings(folder):
    count = 0
    for name in ("提醒.txt",):
        path = locate(folder, name)[0]
        if os.path.isfile(path):
            with io.open(path, encoding="utf-8-sig") as f:
                count += sum(1 for line in f if line.startswith("警告｜"))
    return count


def _sources_from_workspace(folder):
    """沒有 輸入來源.json（這個功能之前跑的「開始」）：從工作區的 匯入/規章清單.csv 找這一本的檔。
    folder 是 <工作區>/產出/2_Log檔案/<規章名>。找不到就回 None（不判斷）。"""
    import batch as bt
    name = os.path.basename(os.path.normpath(folder))
    workspace = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(folder))))
    manifest = os.path.join(workspace, "匯入", "規章清單.csv")
    if not os.path.isfile(manifest):
        return None
    try:
        docs = bt.read_manifest(manifest)
    except bt.BatchError:
        return None
    for doc in docs:
        if doc["規章名"] == name:
            return {"舊版": doc["舊版"], "草稿": doc["草稿"]}
    return None


def semantic_pending(root):
    """這台電腦算不了語意、要到別台算，還沒帶回來併入的本（語意候選資料夾裡有輸入、沒有結果）。
    設定.html 關了「使用 BGE-M3」就一本都不算（開始之後才關的，留下來的語意輸入也不再提醒）。"""
    from _common import SYSTEM_DIR, config_section
    if config_section("設定").get("使用BGE-M3", True) is False:
        return []
    folder = os.path.join(root, SYSTEM_DIR, "語意候選")
    if not os.path.isdir(folder) or os.path.isfile(os.path.join(folder, SEMANTIC_SKIP)):
        return []
    suffix = "_語意輸入.json"
    return sorted(n[:-len(suffix)] for n in os.listdir(folder)
                  if n.endswith(suffix) and not os.path.isfile(os.path.join(folder, n[:-len(suffix)] + ".csv")))


def _ai_review_state(root, folder, table, rows):
    """"done"：這一輪的列都審過了（或這一輪說好不做）；"packed"：審查包已經產生、等 AI 填表匯入；
    "todo"：還沒打包，或上一次匯入有 AI 答案過期（判的不是這一輪的字），要重新打包讓 AI 重判；
    "mismatch"：上一次匯入發現決定表的候選全文被手改過，重新打包也沒用，要人還原決定表或重新比對。
    審過沒有看 AI審查紀錄.json 記的列與異動跟現在一不一樣（補了語意就要再審新列）；
    有過期、原文不符時匯入不寫這份紀錄（review_import.import_review）。"""
    import decision_table as dt
    import review_import as ri
    from _common import SYSTEM_DIR
    if os.path.isfile(os.path.join(root, SYSTEM_DIR, AI_REVIEW_SKIP)):
        return "done"
    changes = []
    changes_path = locate(folder, "異動清單.json")[0]
    if os.path.isfile(changes_path):
        with io.open(changes_path, encoding="utf-8") as f:
            changes = json.load(f)
    record = locate(folder, ri.AI_REVIEW_RECORD)[0]
    if os.path.isfile(record):
        try:
            with io.open(record, encoding="utf-8") as f:
                if json.load(f) == ri.ai_review_signature(rows, changes):
                    return "done"
        except (OSError, ValueError):
            pass
    ai_csv = locate(folder, "AI候選判斷.csv")[0]
    # 上一次匯入在最後一次打包之後（打包會重寫 AI 表）：照它講的結果走
    status_path = locate(folder, ri.AI_IMPORT_STATUS)[0]
    status = ri.read_import_status(folder)
    if status and _import_status_current(status, folder, status_path, ai_csv):
        if status.get("原文不符"):
            return "mismatch"
        if status.get("需重新打包") or status.get("AI過期"):
            return "todo"
    side = dt.sidecar_path_for(table)
    if os.path.isfile(ai_csv) and os.path.isfile(side) and _mtime(ai_csv) >= _mtime(side):
        return "packed"
    return "todo"


def _import_status_current(status, folder, status_path, ai_csv):
    """上一次匯入的狀態還算不算數（審查打包會重寫 AI 表，表變了狀態就不算數）。
    先比匯入時記的 AI 表指紋（review_import.ai_table_prints）：內容不一樣一定是重新打包過了，
    不管檔案時間怎麼說——FAT／exFAT 隨身碟時間粒度 2 秒，匯入、打包落在同一秒時以前會判錯（審查 A7）。
    內容一樣再看時間（重新打包也可能寫出一模一樣的表）：表比狀態檔新就不算數。"""
    prints = status.get("AI表指紋")
    if isinstance(prints, dict) and prints:
        import decision_table as dt
        for filename, want in prints.items():
            path = locate(folder, filename)[0]
            if not os.path.isfile(path) or dt.file_sha256(path) != want:
                return False
    return not os.path.isfile(ai_csv) or _mtime(status_path) >= _mtime(ai_csv)


def _inputs_moved(folder, table):
    """這一本的現行規章或修訂版，在「開始」之後被改過、換過或拿走了嗎？回傳說明，沒有回 ""。
    決定表的指紋檔記著「開始」當時兩份檔的 SHA-256，輸入來源.json 記著檔在哪裡。"""
    import decision_table as dt
    path = locate(folder, "輸入來源.json")[0]
    try:
        if os.path.isfile(path):
            with io.open(path, encoding="utf-8") as f:
                sources = json.load(f)
            # v1.15.0 起存相對這個檔的位置；舊的完整路徑照用
            base = os.path.dirname(os.path.abspath(path))
            sources = dict((k, from_record(base, v) if isinstance(v, str) else v) for k, v in sources.items())
        else:
            sources = _sources_from_workspace(folder)
        side = dt.read_sidecar(dt.sidecar_path_for(table))
    except (OSError, ValueError, dt.DecisionTableError):
        return ""
    if not sources:
        return ""
    for key, label in (("草稿", "修訂版"), ("舊版", "現行規章")):
        file_path, want = sources.get(key), (side.get(key) or {}).get("SHA256")
        if not file_path or not want:
            continue
        if not os.path.isfile(file_path):
            return "%s不見了（%s）" % (label, os.path.basename(file_path))
        if dt.file_sha256(file_path) != want:
            return "%s在「開始」之後改過了（%s）" % (label, os.path.basename(file_path))
    return ""


def book_status(root, name):
    """一本走到哪一站。沒有決定表（還沒比對）回 None。
    必要檔缺了（決定表、異動清單、輸入指紋任一個）算「重新比對」：多半是「開始」跑到一半被中斷，
    或檔被刪掉；以前回 None 被濾掉，其他本在 AI 審查站，繼續就派去審查打包、打包又說不完整請跑繼續，卡死。"""
    import batch as bt
    import decision_table as dt
    import review_import as ri
    folder = book_dir(root, name)
    missing = bt.missing_book_files(folder)
    if missing:
        return {"規章": name, "警告": 0, "階段": "重新比對",
                "問題": "產出不完整（缺 %s），多半是「開始」跑到一半被中斷或檔被刪掉" % "、".join(missing)}
    table = locate(folder, "連帶決定表.csv")[0]
    if not os.path.isfile(table):
        return None
    info = {"規章": name, "警告": _warnings(folder), "問題": ""}
    moved = _inputs_moved(folder, table)
    if moved:
        info.update(階段="重新比對", 問題=moved)
        return info
    try:
        rows = dt.read_table(table)
    except dt.DecisionTableError as exc:
        info.update(階段="重新比對", 問題="連帶決定表讀不出來（%s）" % exc)
        return info
    info["AI審查"] = _ai_review_state(root, folder, table, rows)
    if info["AI審查"] == "mismatch":
        bad = (ri.read_import_status(folder) or {}).get("原文不符") or []
        info["問題"] = ("決定表有 %d 列候選全文跟「開始」時不一樣（列ID %s），AI 判斷沒有匯入；"
                      "還原決定表上這幾列，或重新比對" % (len(bad), "、".join(bad)))
    # AI 審查做完，檢視報告就是完整版：到此結束
    info["階段"] = "AI審查" if info["AI審查"] != "done" else "報告完成"
    return info


def _plain_cmd(name, *parts):
    return " ".join(["python scripts/run_all.py", name] + [p for p in parts if p])


def unaffected_moved(root):
    """沒進流程的本（只讀過全文當別本的被查對象）：它的現行規章在「開始」之後被換過、改過或拿走了嗎。
    回傳 [(規章名, 說明)]。這些本沒有決定表、沒有指紋檔，靠 未受影響規章.json 記的 SHA-256 比；
    這個功能之前跑的「開始」沒記指紋，那幾本就不判斷。"""
    import batch as bt
    import decision_table as dt
    out = []
    for name, doc in sorted(bt.unaffected_docs(root).items()):
        path, want = doc.get("舊版"), doc.get("舊版SHA256")
        if not path or not want:
            continue
        if not os.path.isfile(path):
            out.append((name, "現行規章不見了（%s）" % os.path.basename(path)))
        elif dt.file_sha256(path) != want:
            out.append((name, "現行規章在「開始」之後改過了（%s）" % os.path.basename(path)))
    return out


def statuses_of(root):
    import batch as bt
    statuses = [s for s in (book_status(root, n) for n in bt.book_names(root)) if s]
    # 沒進流程的本換了現行規章也要重新比對：別本的跨本連帶、引用都是拿它的舊文找的
    statuses += [{"規章": name, "警告": 0, "階段": "重新比對", "問題": reason}
                 for name, reason in unaffected_moved(root)]
    return statuses


def workspace_of(root):
    """從舊產出或日期序號作業目錄回推工作區根目錄。"""
    parent = os.path.dirname(os.path.abspath(root))
    try:
        import workspace as wsm
        if os.path.isdir(os.path.join(parent, "匯入")) and wsm.is_output_dir(parent, root):
            return parent
    except Exception:
        pass
    return None


def _semantic_back(root):
    """語意交換包帶回來了嗎：(算好的規章 list, 錯誤訊息)。"""
    import semantic_exchange as se
    from _common import SYSTEM_DIR
    try:
        found = se.returned(os.path.join(root, SYSTEM_DIR, "語意候選"), workspace_of(root))
    except se.ExchangeError as exc:
        return [], str(exc)
    return (found[1] if found else []), ""


IDLE = ("匯入/2_修訂文件 裡沒有修訂版：這一輪沒有要比對的。"
        "要比對時把現行版放進 匯入/1_現行文件、修訂版放進 匯入/2_修訂文件，再跑 繼續；"
        "只想檢查現有文件（不比對）就說「體檢」")
REPORT_DONE = ("比對報告完成，這一輪到此結束：打開 產出/1_結果彙整/比對報告.xlsx，先看「條文比對報告」。"
               "需要核對全文時，點段次到「段次總表」。")
# 體檢那一輪的最後一站（next_step 回的仍是 REPORT_DONE，呼叫端用它判「做完了」；只有印給人看的字不同）
HEALTH_DONE = ("體檢報告完成，這一輪到此結束：打開 產出/1_結果彙整/體檢報告.xlsx，"
               "先看「條文比對報告」（重複／矛盾、錯漏字）「條文檢查報告」「引用檢查報告」。需要核對全文時，點段次到「段次總表」。")
def done_text(root, health=False):
    """「報告完成」那一句，寫實際寫出的那一份報告（Excel 開著時另存的 _HHMMSS）和產出資料夾名稱（v1.24.0）。"""
    import precedents as pc
    want = "體檢報告" if health else "比對報告"
    # v1.26.0：報告叫 比對報告_20261026003.xlsx；改名前的舊資料夾是 檢視報告.xlsx：寫最新的那一份
    found = pc.report_files(root)
    name = os.path.basename(found[0]) if found else want + ".xlsx"
    text = HEALTH_DONE if health else REPORT_DONE
    return text.replace("產出/1_結果彙整/%s.xlsx" % want, "%s/1_結果彙整/%s" % (os.path.basename(os.path.normpath(root)), name))


CONSISTENCY_TODO = ("AI 一致性審查（由 AI 自動完成，不用人填表）：AI 照 產出/2_Log檔案/AI審查/先讀我.md 填好 "
                    "AI一致性.csv（有家族的還有 AI一致性家族.csv；全文在同資料夾的 LLM一致性審查.md）後跑 %s")
TYPO_TODO = ("AI 錯漏字檢查（由 AI 自動完成，不用人填表）：AI 照 產出/2_Log檔案/AI審查/先讀我.md 的「錯漏字檢查」"
             "逐段讀 LLM錯漏字審查_T*.md，填好 AI錯漏字.csv 後跑 %s")
LAW_TODO = ("AI 法規更新檢視（由 AI 自動完成，不用人填表）：AI 照 產出/2_Log檔案/AI審查/先讀我.md 的「法規更新檢視」"
            "先填 AI法規適用.csv（讀 LLM法規適用審查_*.md），跑一次繼續，程式再把適用的法規打包成 LLM法規審查包_*.md，"
            "填好 AI法規影響.csv 後跑 %s")


TABLES_EDITED = "AI 表在報告出來之後改過：重新匯入，再重出報告"


def tables_edited_after_report(root):
    """v1.25.0：產出/2_Log檔案/AI審查/ 的四張 AI 表，有沒有一張比這一輪最新的報告（和最近一次匯入）還新。
    以前只有法規追蹤會發現；比對、體檢在報告審查那一站改了表，繼續 只說「做完了」，改的東西進不了報告。
    也比各本的 AI審查匯入狀態.json：同一次 繼續 裡剛匯入完、報告整串跑完才重建，不能再判一次「改過」。"""
    import glob
    import ai_tables as at
    import precedents as pc
    from _common import SYSTEM_DIR
    reports = pc.report_files(root)
    if not reports:
        return False
    stamps = reports + glob.glob(os.path.join(glob.escape(os.path.join(root, SYSTEM_DIR)), "*", SYSTEM_DIR,
                                              "AI審查匯入狀態.json"))
    newest = max(os.path.getmtime(p) for p in stamps)
    for filename, _id, _columns in at.SPECS:
        path = os.path.join(at.folder(root), filename)
        if os.path.isfile(path) and os.path.getmtime(path) > newest + 1:
            return True
    return False


def _health(root):
    import batch as bt
    return bt.is_health_round(root)


def _consistency_pending(root):
    """體檢的整批表那一站還沒收：重複／矛盾（AI一致性.csv）或法規更新檢視（v1.6.0 的兩張表）還沒匯入，
    或匯入之後 AI 又改了表。"""
    if not _health(root):
        return False
    import health_check as hc
    import health_law
    import health_typo
    return hc.pending(root) or health_law.pending(root) or health_typo.pending(root)


def _batch_table_todo(root, go):
    """體檢整批表那一站要印的幾行（重複／矛盾、法規更新檢視，哪個還沒收印哪個）。"""
    import health_check as hc
    import health_law
    lines = []
    if hc.pending(root):
        lines.append(CONSISTENCY_TODO % go)
    import health_typo
    if health_typo.pending(root):
        lines.append(TYPO_TODO % go)
    if health_law.pending(root):
        lines.append(LAW_TODO % go)
    return lines
# AI 審查是 AI 的事（SKILL.md：不可要求使用者填 AI 審查表）：人工待辦講清楚不用人動手
AI_REVIEW_TODO = ("AI 審查（由 AI 自動完成，不用人填表）：跑 %s 產審查包；"
                  "AI 照 產出/2_Log檔案/AI審查/先讀我.md 把列出的 AI 表填好，再跑 %s")
AI_REVIEW_PACKED = ("AI 審查（由 AI 自動完成，不用人填表）：審查包已經產生（%s），"
                    "AI 照 產出/2_Log檔案/AI審查/先讀我.md 把列出的 AI 表填好，再跑 %s")


def build(root, ws="", cmd=None, statuses=None):
    """回傳 (清單全文, 畫面要印的幾行)。ws：印出來的指令要不要帶 --workspace。
    cmd：印指令的那一支（run_all._cmd，由呼叫端傳進來——這裡 import run_all 會拿到
    regdiff 底下同名的那一支）。"""
    from _common import tw_now, tw_today
    _cmd = cmd or _plain_cmd
    if statuses is None:
        statuses = statuses_of(root)
    workspace = workspace_of(root)
    health = _health(root)
    if workspace and not health:
        import workspace as wsm
        if not wsm.list_role_inputs(workspace, wsm.ROLE_DRAFT):
            lines = ["人工待辦（%s）" % tw_now().strftime("%Y-%m-%d %H:%M"), "", IDLE, "",
                     "所有產出都是輔助，最終仍需人工複核後才能送出。"]
            return "\n".join(lines) + "\n", ["", SCREEN_HEADER, "  1. " + IDLE]
    if not statuses:
        return "", []
    go = _cmd("繼續", ws)
    now = []
    moved = [s for s in statuses if s["階段"] == "重新比對"]
    for s in moved:
        now.append("%s：%s：要重新比對（跑 %s：開新一輪重新比對，AI 判過的答案會依內容帶回來）"
                   % (s["規章"], s["問題"], go))
    semantic = [] if moved else semantic_pending(root)
    if semantic:
        # 語意比對要在 AI 審查之前：語意找到的新列也要 AI 判
        back, _problem = _semantic_back(root)
        if back:
            now.append("語意交換包已經算好帶回來了（%s）：跑 %s 併入" % ("、".join(back), go))
        else:
            # 只問使用者執行／不執行，不把別台電腦當預設解法（見 SKILL.md）
            now.append("語意比對還沒做（這台電腦沒有設定 BGE-M3 模型，%d 本）：請使用者選「執行」或「不執行」；"
                       "不執行就跑 %s，要執行先檢查這台電腦能不能跑（見 SKILL.md）"
                       % (len(semantic), _cmd("語意併入", ws, "--略過")))
    reviewing = [] if (moved or semantic) else [s for s in statuses if s["階段"] == "AI審查"]
    # 原文不符的本：重新打包也沒用，要人還原決定表或重新比對（問題寫在 book_status）
    for s in reviewing:
        if s["AI審查"] == "mismatch":
            now.append("%s：%s" % (s["規章"], s["問題"]))
    waiting = [s for s in reviewing if s["AI審查"] != "mismatch"]
    if any(s["AI審查"] == "todo" for s in waiting):
        now.append(AI_REVIEW_TODO % (go, go))
    elif waiting:
        now.append(AI_REVIEW_PACKED % ("、".join(s["規章"] for s in waiting), go))
    consistency = not (moved or semantic or reviewing) and _consistency_pending(root)
    if consistency:
        now += _batch_table_todo(root, go)
    done = not (moved or semantic or reviewing or consistency)
    import report_review as rv
    if done and rv.pending(root):
        # v1.18.0：表都匯入了、報告出了，最後一站 AI 報告審查
        done = False
        now.append(rv.todo_line(go, "體檢報告" if health else "比對報告"))
        if rv.read_rows(root):
            now += ["  " + line for line in rv.errors(root)[:10]]
    elif done:
        now.append(done_text(root, health))
    later = []
    if health:
        import health_law
        law_state = health_law.load(root)
        if law_state is not None:
            later += ["法規來源「%s」%s：%s（不等於沒有修法；體檢報告的引用檢查報告有一列）"
                      % (c.get("name"), c.get("status"), health_law._short_detail(c.get("detail") or ""))  # v1.24.1：不列幾十個附件網址
                      for c in law_state.get("coverage") or [] if c.get("status") != "完成"]
            if not law_state.get("events"):
                later.append("法規更新檢視這一輪沒抓到任何法規異動：不代表沒有修法")
    import unit_facts as uf
    waiting = uf.todo_line(workspace_of(root))
    if waiting:
        later.append(waiting)
    warned = sum(s["警告"] for s in statuses)
    if warned:
        later.append("警告 %d 則（%s）：內容在 產出/2_Log檔案/批次摘要.txt 最後的「提醒彙整」"
                     % (warned, "、".join("%s %d" % (s["規章"], s["警告"]) for s in statuses if s["警告"])))
    lines = ["人工待辦（%s）" % tw_now().strftime("%Y-%m-%d %H:%M"), ""]

    def where(s):
        # 語意比對是整批一站、排在 AI 審查前面：還沒做時各本也寫「語意比對」，跟「現在要做」對得上
        return "語意比對" if semantic and s["階段"] == "AI審查" else s["階段"]
    lines.append("各本走到哪：" + "、".join("%s（%s）" % (s["規章"], where(s)) for s in statuses))
    lines.append("")
    if now:
        lines.append(("這一輪的結果" if done else "現在要做") + "：")
        lines += ["  %d. %s" % (i, x) for i, x in enumerate(now, 1)]
        lines.append("")
    if later:
        lines.append("看報告時留意：")
        lines += ["  - " + x for x in later]
    import precedents as pc
    kind = "體檢" if health else "比對"
    feedback = pc.feedback_lines(kind=kind) if done else []       # v1.21.0：報告出來了，請承辦寫回饋
    if feedback:
        lines += [""] + feedback
    lines += ["", "所有產出都是輔助，最終仍需人工複核後才能送出。"]
    screen = ["", SCREEN_DONE_HEADER if done else SCREEN_HEADER]
    screen += ["  %d. %s" % (i, x) for i, x in enumerate(now or later[:1], 1)]
    if done and later:
        # v1.24.0：報告完成時「看報告時留意」也印在畫面上（以前只寫在人工待辦.txt：來源失敗、0 條法規、警告幾則，人和 AI 都看不到）
        screen += ["", "看報告時留意："] + ["  - " + x for x in later]
    if feedback:
        screen += [""] + pc.screen_feedback(root, kind)
    return "\n".join(lines) + "\n", screen


def refresh(root, ws="", cmd=None):
    """重寫 目前產出/2_Log檔案/人工待辦.txt，回傳畫面要印的幾行。"""
    statuses = statuses_of(root)
    text, screen = build(root, ws, cmd, statuses)
    if not text:
        return []
    from _common import write_generated
    write_generated(place(root, FILE), text, first_line=True, encoding="utf-8-sig")
    return screen


def _manifest_key(path):
    """清單的內容（規章名、舊版、新版草稿、發布根目錄；配對方式、備註不算）：比「人改過清單沒有」用。"""
    from _common import open_csv
    try:
        with open_csv(path) as f:
            return sorted(tuple((r.get(k) or "").strip() for k in ("規章名", "舊版", "新版草稿", "發布根目錄"))
                          for r in csv.DictReader(f))
    except (OSError, UnicodeDecodeError, csv.Error, ValueError):
        return None


def order_problem(root, command):
    """這個批次指令現在跑，是不是跑錯站：回傳 (擋不擋, 一句話) 或 None。
    會出錯、會誤導的才擋（還沒打包就匯入）；只是順序不理想的講一聲照跑（語意還沒併入就打包）。"""
    statuses = statuses_of(root)
    if not statuses:
        return True, "還沒有這一輪的比對結果：先跑 繼續（或 開始）"
    moved = [s for s in statuses if s["階段"] == "重新比對"]
    if moved:
        return True, "%s：%s，這一輪的結果已經過期：先重新比對（跑 繼續）" % (moved[0]["規章"], moved[0]["問題"])
    stage = STAGES[min(STAGES.index(s["階段"]) for s in statuses)]
    semantic = semantic_pending(root)
    if command == "batch-review-pack" and semantic:
        return False, "語意比對還沒併入（%d 本）：語意找到的列這次不會進審查包，併入之後要再打包一次" % len(semantic)
    if command == "batch-review-import" and stage == "AI審查" and all(
            s.get("AI審查") == "todo" for s in statuses if s["階段"] == "AI審查"):
        return True, "還沒產審查包：先跑 繼續（會產審查包），AI 填好 產出/2_Log檔案/AI審查/ 的表再匯入"
    return None


def next_step(root, workspace_root=None):
    """「繼續」下一步跑什麼（跟人工待辦同一套判斷）：{"指令": 子命令名或 None, "說明": 一句話}。
    指令是 None＝這一站要人（或 AI）動手；說明講停在哪一站，細節照人工待辦。
    batch-review-import 那一站多帶 "先看AI"：呼叫端要先確認 AI 把表填完了才匯入。"""
    import batch as bt
    # 體檢那一輪（沒有修訂版）：要重跑的站是「體檢」不是「開始」，修訂版空的也不算閒置
    health = _health(root)
    restart = "體檢" if health else "開始"
    if workspace_root:
        import workspace as wsm
        p = wsm.paths(workspace_root)
        if not wsm.list_role_inputs(workspace_root, wsm.ROLE_DRAFT) and not health:
            # 沒有發布這一站之後，「這一輪結束了」就看修訂規章是不是空的（簽核回來、修訂版拿掉了）。
            # 以前這裡會回「開始」，開始跑完還是沒有比對結果，繼續就一直重跑開始、一直歸檔
            return {"指令": None, "說明": IDLE}
        if not os.path.isfile(p["清單"]):
            if (wsm.list_role_inputs(workspace_root, wsm.ROLE_CURRENT)
                    or wsm.list_role_inputs(workspace_root, wsm.ROLE_DRAFT)):
                return {"指令": restart, "說明": "第一次跑：配對、初比對"}
            return {"指令": None, "說明": "匯入/1_現行文件、匯入/2_修訂文件 還沒有規章檔：先把檔放進去"}
        try:
            reasons = wsm.stale_reasons(wsm.read_manifest_rows(p["清單"]), workspace_root)
        except wsm.WorkspaceError as exc:
            reasons = [str(exc)]
        if reasons:
            return {"指令": restart, "說明": "匯入/ 的檔跟清單不一樣（%s）：重新配對、初比對" % reasons[0]}
        # 人改了清單（修正配對、補發布根目錄）但檔沒動：跟上一次開始用的那一份比
        from _common import SYSTEM_DIR
        staged = os.path.join(root, SYSTEM_DIR, "輸入", "規章清單.csv")
        if os.path.isfile(staged) and _manifest_key(p["清單"]) != _manifest_key(staged):
            return {"指令": restart, "說明": "匯入/規章清單.csv 改過了：照新的清單重新%s" % ("體檢" if health else "比對")}
    statuses = statuses_of(root) if bt.is_batch_root(root) else []
    if not statuses:
        return {"指令": restart if workspace_root else None, "說明": "還沒有這一輪的比對結果"}
    moved = [s for s in statuses if s["階段"] == "重新比對"]
    if moved:
        return {"指令": restart, "說明": "%s：%s：重新%s" % (moved[0]["規章"], moved[0]["問題"], "體檢" if health else "比對")}
    if semantic_pending(root):
        back, problem = _semantic_back(root)
        if back:
            return {"指令": "batch-semantic", "說明": "語意交換包帶回來了：併入"}
        # 只問使用者執行／不執行，不把別台電腦當預設解法（SKILL.md）；怎麼檢查、怎麼略過寫在人工待辦
        return {"指令": None, "說明": problem or "語意比對還沒做（這台電腦沒有設定 BGE-M3 模型）："
                                              "請使用者選「執行」或「不執行」（見人工待辦）"}
    stage = STAGES[min(STAGES.index(s["階段"]) for s in statuses)]
    if stage == "AI審查":
        blocked = [s for s in statuses if s["階段"] == "AI審查" and s["AI審查"] == "mismatch"]
        if blocked:
            return {"指令": None, "說明": "%s：%s" % (blocked[0]["規章"], blocked[0]["問題"])}
        if any(s["AI審查"] == "todo" for s in statuses if s["階段"] == "AI審查"):
            return {"指令": "batch-review-pack", "說明": "AI 審查：產審查包"}
        return {"指令": "batch-review-import", "說明": "AI 審查：匯入 AI 填好的表", "先看AI": True}
    if _consistency_pending(root):
        # 體檢：各本都審完了，重複／矛盾那一張（整批一張）還沒匯入：匯入會連它一起收（先看 AI 填完沒）
        return {"指令": "batch-review-import", "說明": "AI 一致性審查／法規更新檢視：匯入 AI 填好的表", "先看AI": True}
    if tables_edited_after_report(root):
        # v1.25.0：報告出了之後 AI 又改了四張 AI 表（報告審查發現資料錯了、直接改表）：重新匯入再出報告
        return {"指令": "batch-review-import", "說明": TABLES_EDITED, "先看AI": True}
    import report_review as rv
    if rv.pending(root):
        # v1.18.0 最後一站：AI 把整份報告看一遍（設定.html「AI報告審查」可以關）
        return {"指令": None, "說明": rv.todo_line("繼續", "體檢報告" if health else "比對報告"), "報告審查": True}
    return {"指令": None, "說明": REPORT_DONE}
