# -*- coding: utf-8 -*-
"""
檢視報告：把一個產出資料夾裡散在各格的報告，彙整成一份 1_結果彙整/檢視報告.xlsx。

最終使用者要的只有三類：標註版全文、修正對照表、檢視報告。前兩類本身就是一份檔
（place() 直接寫進 1_結果彙整/）；檢視報告則是好幾步各自產生的報告拼起來的——
條文檢查、連帶決定、規格包連帶複核、LLM 審查、套用、終比對驗收、提醒——
原本那幾份照舊留在 2_Log檔案/ 當稽核紀錄，這裡只讀、不搬、不改。

每一步（compare／apply／review-import／finalize 與批次版本）跑完都呼叫 refresh()，
依資料夾裡「現在有什麼」整份重建：缺的那一段就不出那一張工作表，總覽上寫「尚未產生」。
所以不管跑到第幾步，1_結果彙整/ 裡的檢視報告都是當下最新、最完整的那一份。
"""

import csv
import glob
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
REGDIFF = os.path.join(HERE, "regdiff")
for _path in (HERE, REGDIFF):
    if _path not in sys.path:
        sys.path.insert(0, _path)

import xlsx_writer as xw
import precedents as pc
try:
    import human_report as hr
except Exception:
    hr = None
from _common import REVIEW_DIR, locate, place

REPORT_NAME = "比對報告.xlsx"            # 單本比對（不在 產出YYYYMMDDNNN 裡）用的名字
HEALTH_REPORT_NAME = "體檢報告.xlsx"


def report_name(root):
    """這一輪的人用報告叫什麼（v1.26.0）：比對報告_20261026003.xlsx、體檢報告_20261026002.xlsx。
    以前比對叫 檢視報告.xlsx（跟法規追蹤同名，分不出來）。"""
    import batch as bt
    from _common import report_base_name
    return report_base_name(root, "體檢" if bt.is_health_round(root) else "比對") + ".xlsx"
FINAL_PREFIX = "最終版"
# 舊版 build()/build_batch() 僅保留給外部舊呼叫端相容；refresh 一律改走 human_report。
# 從連帶決定表帶進報告的欄（有哪欄帶哪欄，順序照這裡）
DECISION_COLUMNS = ["候選段次", "候選全文", "異動內容", "建議改法", "要改嗎", "改成什麼", "沿用上一輪",
                    "相似分數", "AI判斷", "AI分數", "AI理由", "修改類型", "異動摘要", "異動條文ID", "候選條文ID",
                    "來源", "關係／分數"]


def _existing(outdir, filename, prefix=""):
    path = locate(outdir, filename, prefix)[0]
    return path if os.path.isfile(path) else None


def _decision_rows(outdir, decisions=None):
    """回傳 (欄, 列, 讀不出來的原因)。表不在回 (None, [], "")。

    以前寫死 utf-8-sig：人在 Excel 用「CSV（逗號分隔）」另存（Big5），每一步收尾重建
    檢視報告時就噴 UnicodeDecodeError 的 traceback，那一步明明已經做完了（第三批）。
    改用 _common.open_csv（自動認 UTF-8／Big5）；真的認不出來，檢視報告照出，
    總覽上寫明讀不出來、怎麼修。"""
    from _common import InputError, open_csv
    path = decisions if decisions and os.path.isfile(decisions) else _existing(outdir, "連帶決定表.csv")
    if not path:
        return None, [], ""
    import decision_table as dt
    try:
        with open_csv(path) as f:
            reader = csv.DictReader(f)
            rows = list(reader)
            # 欄序跟決定表本身一樣（dt.DISPLAY_ORDER），人在兩邊看到的是同一個順序
            present = [c for c in (reader.fieldnames or []) if c in DECISION_COLUMNS]
            fields = dt.ordered_fields(present)
    except (InputError, OSError, csv.Error) as exc:
        return None, [], str(exc)
    return fields, rows, ""


def batch_books(root):
    """批次產出根目錄底下有哪幾本：[(規章名, 那一本的產出資料夾)]，照規章清單的順序。"""
    from _common import BATCH_RESERVED, FILL_DIR, SYSTEM_DIR, book_dir
    names = []
    manifest = os.path.join(root, SYSTEM_DIR, "輸入", "規章清單.csv")
    if os.path.isfile(manifest):
        # 規章清單是人會拿 Excel 開、存的表，Big5 也要讀得動（第三批）；
        # 真的讀不出來就只靠下面的資料夾清單，檢視報告照出
        from _common import InputError, open_csv
        try:
            with open_csv(manifest) as f:
                names = [(r.get("規章名") or "").strip() for r in csv.DictReader(f)]
        except (InputError, OSError, csv.Error) as exc:
            print("提醒：報告讀不了規章清單（%s），改照資料夾列各本" % exc, flush=True)
    # 清單以外、但資料夾還在的本（清單被改過）：各本在 2_Log檔案/<規章名>/，上一版在根目錄
    for folder in (os.path.join(root, SYSTEM_DIR), root):
        for name in sorted(os.listdir(folder)) if os.path.isdir(folder) else []:
            if name not in names:
                names.append(name)
    import batch as bt
    skip = bt.unaffected_books(root)
    books = []
    for name in names:
        if not name or name in BATCH_RESERVED or name in skip:
            continue
        path = book_dir(root, name)
        if not os.path.isdir(path):
            continue
        if any(os.path.isdir(os.path.join(path, d)) for d in (REVIEW_DIR, FILL_DIR, SYSTEM_DIR)):
            books.append((name, path))
    return books


def _remove_stale_report_csv(base, written):
    """清除舊版 CSV 退路，但保留本次因 Excel 字數上限產生的完整 CSV。"""
    kept = {os.path.abspath(path) for path in (written or [])}
    for stale in glob.glob(base + "_*.csv"):
        try:
            if os.path.abspath(stale) not in kept:
                os.remove(stale)
        except OSError:
            pass


def refresh_batch(root):
    """重建 <產出根>/1_結果彙整/檢視報告.xlsx（多本合一）。沒有任何一本就回 None。"""
    books = batch_books(root)
    if not books:
        return None
    name = report_name(root)
    base = os.path.splitext(place(root, name))[0]
    if hr is None:
        print("提醒：新版報告模組讀取失敗，這次不產生舊格式報告", flush=True)
        return None
    try:
        sheets, sheet_options = hr.build_batch(root, books)
        pc.keep_opinions(sheets, sheet_options, base)
        written = xw.write_tables_or_csv(base, sheets, source=os.path.splitext(name)[0], sheet_options=sheet_options)
    except OSError as exc:
        print("提醒：報告寫不出來（%s）；關掉開著的報告（Excel）後重跑這一步即可" % exc,
              flush=True)
        return None
    if written and written[0].endswith(".xlsx"):
        _remove_stale_report_csv(base, written)
    return written[0] if written else None


def refresh(outdir, decisions=None):
    """重建 <outdir>/1_結果彙整/檢視報告.xlsx。回傳寫出的第一個檔；資料夾裡什麼都還沒有就回 None。

    檢視報告是「附帶」的產物：寫不出來（檔案開在 Excel 裡）只印一行，不讓那一步失敗——
    那一步真正的產出（對照表、定稿、驗收報告）已經寫好了。
    """
    if not os.path.isdir(outdir):
        return None
    from _common import batch_root_of
    root = batch_root_of(outdir)
    if root:
        # 批次裡的一本：不另外出這一本的報告，重建整批合一的那一份
        return refresh_batch(root)
    base = os.path.splitext(place(outdir, report_name(outdir)))[0]
    if hr is None:
        print("提醒：新版報告模組讀取失敗，這次不產生舊格式報告", flush=True)
        return None
    try:
        sheets, sheet_options = hr.build_book(outdir, decisions=decisions)
        pc.keep_opinions(sheets, sheet_options, base)
        written = xw.write_tables_or_csv(base, sheets, source="比對報告", sheet_options=sheet_options)
    except OSError as exc:
        print("提醒：報告寫不出來（%s）；關掉開著的報告（Excel）後重跑這一步即可" % exc,
              flush=True)
        return None
    if written and written[0].endswith(".xlsx"):
        # 上一輪 xlsx 寫不出來時留下的 csv 退路要清掉，但保留本次完整內容備份。
        _remove_stale_report_csv(base, written)
    return written[0] if written else None


def main(argv=None):
    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass
    args = sys.argv[1:] if argv is None else argv
    if not args:
        print("用法：py review_report.py <產出資料夾> [連帶決定表.csv]")
        return 1
    path = refresh(args[0], args[1] if len(args) > 1 else None)
    print("報告：%s" % path if path else "沒有可以彙整的報告")
    return 0 if path else 1


if __name__ == "__main__":
    sys.exit(main())
