# -*- coding: utf-8 -*-
"""打開設定（v1.13.0）：在這台電腦開一個只有自己連得到的小網頁服務（127.0.0.1），用瀏覽器打開 設定.html。

為什麼：直接雙擊 設定.html（file://）時，瀏覽器為了安全不讓網頁改硬碟上的檔——第一次存檔要選檔、
之後每次重開瀏覽器還要按「允許編輯」，而且記住的檔可能是舊版資料夾那一份（換新版之後存錯地方）。
從這裡打開的設定頁，存檔交給程式寫回「這一個版本」的 設定.html：不跳視窗、改了自動存。

安全：只聽 127.0.0.1（別台電腦連不到）；網址帶一次性的通行碼，存檔要帶同一個碼（別的網頁偷存不了）；
存檔只換掉 設定.html 裡的設定資料那一塊（reg-data），網頁本身一個字不動。
存檔時設定資料要跟打開時同一份：中途程式改過（例如寫了 AI 建議、電腦資訊），回 409，不會拿舊的蓋掉新的；
v1.14.1 起頁面撞到 409 會跟 /data 拿最新的設定資料，把使用者改過的格子疊上去再存一次。

結束（v1.13.2 改成心跳）：設定頁開著時每 20 秒跟程式說一聲「我還在」；關掉頁面時送「我關了」，幾秒後就停。
「我關了」沒送到（直接關整個瀏覽器、分頁被休眠、內嵌瀏覽器關分頁）也不會一直開著：超過 3 分鐘沒聽到心跳就停。
打開後 3 分鐘內瀏覽器一直沒連上來也停。Ctrl+C 也可以。

規範資料（v1.16.0）：設定頁的「規範資料」頁籤經這裡看 skill 的 資料庫/ 目錄（GET /library）、
存檔進去（POST /library/save?folder=&name=，內容是檔案本身）、整理目錄（POST /library/organize，跟「資料庫」指令一樣）。
只存得進 資料庫/外部規範、資料庫/內部規範，檔名不能帶路徑。

AI 沙盒打不開（v1.14.2）：AI 的沙盒可能不准開連接埠、沒有瀏覽器，或開得起來但使用者的瀏覽器連不到沙盒裡的服務。
這時印出一行指令，讓使用者在自己電腦的 CMD 貼上執行（跟雙擊 打開設定.cmd 一樣）：開服務失敗、瀏覽器沒自動打開、
3 分鐘內瀏覽器都沒連上時都會印；一開始也先印一次備用。
"""
import hashlib
import http.server
import io
import json
import os
import re
import secrets
import sys
import threading
import time
import urllib.parse
import webbrowser

HERE = os.path.dirname(os.path.abspath(__file__))
for path in (HERE, os.path.join(HERE, "regdiff")):
    if path not in sys.path:
        sys.path.insert(0, path)

HOST = "127.0.0.1"
HEARTBEAT_SECONDS = 20           # 設定頁多久送一次心跳（設定.html 的 setInterval 跟這裡一樣）
HEARTBEAT_TIMEOUT = 180          # 超過這麼久沒聽到心跳就當頁面關了（背景分頁的計時器最慢一分鐘跑一次，留足空間）
FIRST_CONTACT = 180              # 打開後瀏覽器多久沒連上來就停
CLOSE_GRACE = 8                  # 關掉頁面之後等幾秒（重新整理會再連上，就不停）
LIBRARY_LIMIT = 200 * 1024 * 1024  # 規範資料頁籤一次存一份檔，最大 200 MB（跟 rule_library.UPLOAD_LIMIT 一樣）
_DATA_RE = re.compile(r'(<script\b[^>]*\bid="reg-data"[^>]*>)(.*?)(</script>)', re.S)


def manual_command(path):
    """在使用者自己電腦的 CMD 打開這一版設定頁的指令（v1.14.2）。path：設定.html；skill 資料夾就是它所在的資料夾。
    用英文別名 open-settings：CMD 貼中文指令名稱在舊的字碼頁可能變亂碼。"""
    folder = os.path.dirname(os.path.abspath(path))
    return 'cd /d "%s" && python scripts\\run_all.py open-settings' % folder


def manual_lines(path, why):
    """沙盒打不開時給使用者的說明（AI 原樣轉給使用者，指令放在程式碼區塊）。"""
    lines = ["[自己開] %s：請在自己電腦的 CMD 打開設定頁——按 Win+R、輸入 cmd、按 Enter，"
             "在黑色視窗貼上下面這一行再按 Enter（或直接雙擊 skill 資料夾裡的 打開設定.cmd）：" % why,
             manual_command(path)]
    if os.name != "nt":
        lines.append("（這個路徑是 AI 沙盒裡看到的位置：請換成這個 skill 資料夾在你電腦上的位置）")
    return lines


def _read(path):
    with io.open(path, encoding="utf-8-sig") as f:
        return f.read()


def data_version(text):
    """設定資料那一塊的指紋：打開時一份、存檔時比對，中途被程式改過就擋下來。"""
    match = _DATA_RE.search(text)
    return hashlib.sha256((match.group(2) if match else "").encode("utf-8")).hexdigest()[:16]


def write_data(path, data):
    """把整份設定資料寫回 設定.html 的 reg-data 那一塊（網頁其他部分不動）。回傳新的指紋。"""
    if not isinstance(data, dict) or not isinstance(data.get("設定", {}), dict):
        raise ValueError("設定資料要是一組對照表，「設定」也要是對照表")
    text = _read(path)
    match = _DATA_RE.search(text)
    if not match:
        raise ValueError('設定.html 找不到設定資料（<script id="reg-data">）')
    block = "\n" + json.dumps(data, ensure_ascii=False, indent=1).replace("</", "<\\/") + "\n"
    text = text[:match.start(2)] + block + text[match.end(2):]
    with io.open(path + ".tmp", "w", encoding="utf-8") as f:
        f.write(text)
    os.replace(path + ".tmp", path)
    try:
        import _common
        _common._CONFIG_CACHE.pop(path, None)
    except (ImportError, AttributeError):
        pass
    return data_version(text)


class SettingsServer(object):
    """一次「打開設定」的服務。path：要改的 設定.html；token：通行碼。"""

    def __init__(self, path, token=None, port=0):
        self.path = os.path.abspath(path)
        self.token = token or secrets.token_urlsafe(16)
        self.started = self.last_seen = time.time()
        self.contacted = False           # 瀏覽器連上來過沒（程式自己的連線檢查不算）
        self.closed_at = None
        self.lock = threading.Lock()     # 6：「比對版本＋寫檔」一次只做一個（兩個分頁同時存不會互相蓋掉）
        self.library_lock = threading.Lock()   # 資料庫存檔、整理一次只做一個
        owner = self

        class Handler(http.server.BaseHTTPRequestHandler):
            def log_message(self, *args):
                pass

            def _send(self, code, body, kind="application/json; charset=utf-8"):
                raw = body.encode("utf-8") if isinstance(body, str) else body
                self.send_response(code)
                self.send_header("Content-Type", kind)
                self.send_header("Content-Length", str(len(raw)))
                self.send_header("Cache-Control", "no-store")
                # 13：多一層保護——不給別的網頁內嵌、不把網址（含通行碼）送給別處、不讓瀏覽器猜檔案種類
                self.send_header("X-Content-Type-Options", "nosniff")
                self.send_header("Referrer-Policy", "no-referrer")
                self.send_header("X-Frame-Options", "DENY")
                self.send_header("Content-Security-Policy",
                                 "default-src 'none'; script-src 'unsafe-inline'; style-src 'unsafe-inline'; "
                                 "img-src data: blob:; connect-src 'self'; frame-ancestors 'none'; base-uri 'none'; "
                                 "form-action 'none'")
                self.end_headers()
                self.wfile.write(raw)

            def _json(self, code, value):
                self._send(code, json.dumps(value, ensure_ascii=False))

            def _token_ok(self, query):
                # v1.23.0：通行碼先轉成 bytes 再比（網址帶中文通行碼時 compare_digest 會丟 TypeError、整條連線斷掉）；
                # Host 只收本機（多一層擋 DNS rebinding：別的網站把自己的網域指到 127.0.0.1）
                host = (self.headers.get("Host") or "").lower()
                if host not in ("127.0.0.1:%d" % owner.port, "localhost:%d" % owner.port):
                    return False
                given = self.headers.get("X-Reg-Token") or (query.get("t") or [""])[0]
                return secrets.compare_digest(str(given).encode("utf-8"), owner.token.encode("utf-8"))

            def _library(self, url, raw):
                """規範資料頁籤：存檔、整理目錄。"""
                import rule_library as lib
                query = urllib.parse.parse_qs(url.query)
                try:
                    with owner.library_lock:
                        if url.path == "/library/save":
                            result = lib.store((query.get("folder") or [""])[0], (query.get("name") or [""])[0], raw,
                                               replace=(query.get("replace") or [""])[0] == "1")
                            if result.get("exists"):
                                return self._json(409, dict(result, ok=False, message="已經有同名的檔"))
                            return self._json(200, dict(result, ok=True))
                        if url.path == "/library/organize":
                            library = lib.load(refresh=True)
                            return self._json(200, dict(lib.quick_list(), ok=True, warnings=list(library.warnings)))
                except ValueError as exc:
                    return self._json(400, {"ok": False, "message": str(exc)})
                except OSError as exc:
                    return self._json(500, {"ok": False, "message": "存不進去：%s" % exc})
                return self._json(404, {"ok": False, "message": "沒有這個動作"})

            def do_GET(self):
                url = urllib.parse.urlsplit(self.path)
                query = urllib.parse.parse_qs(url.query)
                if not self._token_ok(query):
                    return self._send(403, "通行碼不對：請用「打開設定」重新打開", "text/plain; charset=utf-8")
                if not (query.get("self") or [""])[0]:
                    owner.touch()
                if url.path == "/alive":
                    return self._json(200, {"ok": True})
                if url.path in ("/", "/設定.html", "/%E8%A8%AD%E5%AE%9A.html"):
                    return self._send(200, _read(owner.path), "text/html; charset=utf-8")
                if url.path == "/version":
                    return self._json(200, {"version": data_version(_read(owner.path))})
                if url.path == "/library":
                    import rule_library as lib
                    try:
                        return self._json(200, dict(lib.quick_list(), ok=True))
                    except OSError as exc:
                        return self._json(500, {"ok": False, "message": "讀不到資料庫：%s" % exc})
                if url.path == "/data":
                    # 3：存檔撞到「程式改過」時，頁面拿最新的設定資料來合併（你的修改疊上去，不用重新整理重改）
                    text = _read(owner.path)
                    match = _DATA_RE.search(text)
                    try:
                        data = json.loads(match.group(2)) if match else {}
                    except ValueError:
                        data = {}
                    return self._json(200, {"version": data_version(text), "data": data})
                return self._send(404, "沒有這一頁", "text/plain; charset=utf-8")

            def do_POST(self):
                url = urllib.parse.urlsplit(self.path)
                # 先把送來的內容讀完再回話：不讀完就回「拒絕」，Windows 會把連線切掉（WinError 10053），
                # 瀏覽器那邊看到的是連線錯誤、不是拒絕的原因
                try:
                    length = int(self.headers.get("Content-Length") or 0)
                except ValueError:
                    length = 0
                limit = LIBRARY_LIMIT if url.path == "/library/save" else 16 * 1024 * 1024
                raw = self.rfile.read(min(length, limit)) if length > 0 else b""
                left = length - len(raw)
                while left > 0:                  # 太大的：剩下的讀完丟掉再回話
                    chunk = self.rfile.read(min(left, 1 << 20))
                    if not chunk:
                        break
                    left -= len(chunk)
                if not self._token_ok(urllib.parse.parse_qs(url.query)):
                    return self._json(403, {"ok": False, "message": "通行碼不對：請用「打開設定」重新打開"})
                owner.touch()
                if length > limit:
                    return self._json(413, {"ok": False, "message": "檔案太大（最大 %d MB）" % (limit // 1024 // 1024)})
                if url.path.startswith("/library/"):
                    return self._library(url, raw)
                if url.path == "/bye":
                    owner.closed_at = time.time()
                    return self._json(200, {"ok": True})
                if url.path != "/save":
                    return self._json(404, {"ok": False, "message": "沒有這個動作"})
                try:
                    body = json.loads(raw.decode("utf-8"))
                    with owner.lock:
                        current = data_version(_read(owner.path))
                        if body.get("version") != current:
                            return self._json(409, {"ok": False, "version": current,
                                                    "message": "設定.html 在你打開之後被程式改過（例如寫了 AI 建議）：重新整理這一頁再改"})
                        version = write_data(owner.path, body.get("data"))
                except (ValueError, TypeError, OSError, AttributeError) as exc:
                    return self._json(400, {"ok": False, "message": "存不進去：%s" % exc})
                return self._json(200, {"ok": True, "version": version})

        # 連接埠交給 Windows 挑一個沒人用的（port=0）。以前固定從 8765 開始：那台電腦別的程式已經聽 8765，
        # Windows 照樣讓我們綁上去，瀏覽器卻連到別人的程式（實測打開的是另一個 App 的頁面）
        self.httpd = http.server.ThreadingHTTPServer((HOST, port or 0), Handler)
        self.port = self.httpd.server_address[1]

    @property
    def url(self):
        return "http://%s:%d/?t=%s" % (HOST, self.port, self.token)

    def touch(self):
        self.last_seen = time.time()
        self.contacted = True
        self.closed_at = None

    def should_stop(self, now=None):
        now = now or time.time()
        if self.closed_at and now - self.closed_at > CLOSE_GRACE:
            return True
        if not self.contacted:
            return now - self.started > FIRST_CONTACT
        return now - self.last_seen > HEARTBEAT_TIMEOUT

    def start(self):
        thread = threading.Thread(target=self.httpd.serve_forever, daemon=True)
        thread.start()
        return thread

    def reachable(self):
        """連得到的是不是自己：拿通行碼問 /version，回得出來才算（防連到別的程式）。"""
        import urllib.request
        try:
            request = urllib.request.Request("http://%s:%d/version?self=1" % (HOST, self.port),
                                             headers={"X-Reg-Token": self.token})
            with urllib.request.urlopen(request, timeout=5) as response:
                return "version" in json.loads(response.read().decode("utf-8"))
        except Exception:
            return False

    def stop(self):
        self.httpd.shutdown()
        self.httpd.server_close()


def run(path=None, open_browser=True, say=print):
    """打開設定：開服務、開瀏覽器，等到頁面關掉（或 30 分鐘沒動）才結束。"""
    import _common
    path = path or _common.CONFIG_HTML
    if not os.path.isfile(path):
        say("[中止] 找不到 %s" % path)
        return 1
    server = None
    error = None
    for _attempt in range(3):
        try:
            candidate = SettingsServer(path)
        except OSError as exc:              # 沙盒不准開連接埠
            error = exc
            continue
        candidate.start()
        if candidate.reachable():
            server = candidate
            break
        candidate.stop()
    if server is None:
        say("[中止] 開不起設定頁的本機服務（%s）" % (error or "連不到自己"))
        for line in manual_lines(path, "AI 這邊開不起來"):
            say(line)
        return 1
    say("設定頁：%s" % server.url)
    say("（只有這台電腦連得到。改了會自動存回 %s；關掉設定頁後這個視窗自己結束，通常幾秒、最多約 3 分鐘）" % path)
    say("改完關掉設定頁，回來跟 AI 說「好了」，AI 就照新的設定接著做。")      # v1.24.0
    say("（備用：瀏覽器打不開這個網址時，在自己電腦的 CMD 貼上 %s）" % manual_command(path))
    if open_browser:
        try:
            opened = webbrowser.open(server.url)
        except Exception:
            opened = False
        if not opened:                       # 沙盒裡沒有瀏覽器
            say("瀏覽器沒有自動打開：把上面的網址貼到瀏覽器；打不開的話照下面做。")
            for line in manual_lines(path, "瀏覽器沒有自動打開"):
                say(line)
    try:
        while not server.should_stop():
            time.sleep(1)
    except KeyboardInterrupt:
        pass
    finally:
        server.stop()
    if not server.contacted:
        # 3 分鐘內瀏覽器都沒連上：多半是 AI 的沙盒跟使用者的瀏覽器不在同一台電腦／同一個網路
        say("[中止] 瀏覽器 %d 秒內都沒連上設定頁，服務已結束（設定沒改）。" % FIRST_CONTACT)
        for line in manual_lines(path, "AI 開的設定頁你的瀏覽器連不到"):
            say(line)
        return 1
    say("設定頁已關閉，設定已存在 %s" % path)
    return 0
