# -*- coding: utf-8 -*-
"""體檢（檢查現有文件）：沒有修訂版也能做的那一半檢查，加上「重複／矛盾條文」。

條文檢查、內部引用、跨本引用、外部法規查證、結構提醒都是 reg-report 本來就有的零件
（規章的草稿欄空白時拿現行版當草稿跑 compare，異動是 0，單本的檢查照樣全部跑）；
這支只負責新的那一塊——重複／矛盾候選：

    找候選   同一批規章裡（同本不同處、或不同本）講同一件事的兩段：字面相似（rapidfuzz）
             或語意相近（BGE-M3 dense 向量，有模型才做）。
    給 AI 判  AI審查/AI一致性.csv（一對一列）＋ LLM一致性審查.md（兩段全文與前後文）。
             判斷字：矛盾／錯漏字／重複／一致／無關；理由開頭一個標籤（見 scoring_rubric.CONSISTENCY）。
    匯入     驗格式、指紋對得上才收，寫 AI審查/一致性結果.json；體檢報告.xlsx 的「條文比對報告」頁讀它（v1.7.0 起，
             以前是另一頁「重複矛盾報告」）。

指紋＝兩段全文的 SHA-256：重新體檢時兩段都沒變的，AI 上一輪的答案直接沿用。

v1.31.0 家族：配對把段落連成群組，3 段以上（而且不是全部一字不差）的叫「家族」——同一個範本改出來的好幾段
（7 本手冊開頭都有的「本篇為…」）。以前一段最多配 3 對、照排序挑，家族裡同分的很多，挑到哪幾對看走訪順序
（字串 hash 每次啟動都不同），重跑結果不一樣、也漏對。現在家族整個一項交給 AI（AI一致性家族.csv），
AI 一次看完全部成員，挑出跟大家不一樣、寫錯的那幾段；群組只看配對關係，每次都一樣。
"""

import csv
import hashlib
import io
import json
import os
import re
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
for _path in (HERE, os.path.join(HERE, "regdiff")):
    if _path not in sys.path:
        sys.path.insert(0, _path)

from _common import SYSTEM_DIR, locate, normalize_for_compare, strip_article_no  # noqa: E402

FOLDER = "體檢"                              # 產出/2_Log檔案/體檢/
CANDIDATES_FILE = "一致性候選.json"
TABLE_FILE = "AI一致性.csv"                   # 放在 AI審查/（跟另外四張表同一個資料夾，AI 一次看完）
PACK_FILE = "LLM一致性審查.md"
RESULT_FILE = "一致性結果.json"
SHA_COLUMN = "審查內容SHA256"
HEADER = ["配對ID", "規章A", "段次A", "規章B", "段次B", "AI判斷", "AI理由", SHA_COLUMN]
ANSWER_COLUMNS = ("AI判斷", "AI理由")
FAMILY_TABLE_FILE = "AI一致性家族.csv"        # v1.31.0：3 段以上的家族，一個家族一列
FAMILY_HEADER = ["家族ID", "成員", "AI判斷", "有問題的段", "對照段", "AI理由", SHA_COLUMN]
FAMILY_ANSWER_COLUMNS = ("AI判斷", "有問題的段", "對照段", "AI理由")
FAMILY_MIN = 3            # 群組幾段以上算家族
FAMILY_CONTEXT = 1        # 家族審查包每段前後各印幾段（成員多，印 3 段太長）
MEMBER_SEP = "｜"          # 成員、有問題的段、對照段的寫法：「規章｜段次」，一行一段
FAMILY_MAX = 12           # 家族最多幾段：A 像 B、B 像 C 一路串下去的群組太大，不當家族，裡面的配對照舊一對一對列
VALIDATE_GROUP = "重複／矛盾（AI一致性.csv、AI一致性家族.csv）"     # 審查匯入的分組名（驗證、匯入兩處共用）

MIN_CHARS = 15            # 太短的段（標題、「（刪除）」）不比
FUZZY_THRESHOLD = 85.0    # 字面相似：rapidfuzz ratio
SEMANTIC_THRESHOLD = 0.88 # 語意相近：dense cosine（只有 dense，門檻要比三分數合併高）
PER_PARAGRAPH = 3         # 語意那一路每段先找幾個最近的（只是找候選；v1.31.0 起配對不再有「一段最多 3 對」）
MAX_PAIRS = 400           # 整批最多幾項（一對或一個家族算一項；有差異的先留、一模一樣的最後；設定.html「體檢最多幾對」可改）
BOILERPLATE_COPIES = 4    # 同一句出現這麼多次以上＝套語（「本辦法自發布日施行」），不比
CONTEXT = 3               # 審查包每段前後各印幾段


class HealthCheckError(ValueError):
    pass


def _s(value):
    return "" if value is None else str(value).strip()


def folder(root):
    return os.path.join(root, SYSTEM_DIR, FOLDER)


def review_folder(root):
    import ai_tables as at
    return at.folder(root)


def _norm(text):
    return normalize_for_compare(strip_article_no(text or ""))


# ---------------------------------------------------------------------------
# 找候選
# ---------------------------------------------------------------------------

def _grams(text, n=3):
    return set(text[i:i + n] for i in range(len(text) - n + 1)) if len(text) >= n else {text}


def _units(books):
    """每一段一個單位：(規章名, 段次 1 起算, 正規化文字)。太短的、套語不算。"""
    units = []
    for name, paragraphs in books.items():
        for index, text in enumerate(paragraphs, 1):
            norm = _norm(text)
            if len(norm) >= MIN_CHARS:
                units.append((name, index, norm))
    counts = {}
    for _, _, norm in units:
        counts[norm] = counts.get(norm, 0) + 1
    return [u for u in units if counts[u[2]] < BOILERPLATE_COPIES]


def _fuzzy_pairs(units, threshold=FUZZY_THRESHOLD):
    """字面相似的配對：先用 3-gram 倒排索引粗篩（共有的 3-gram 要佔短的那一段六成以上），
    再算 rapidfuzz ratio。純 Python 逐對算 1 萬段要 5 千萬次，粗篩後只剩幾千對。"""
    import fuzzy_duplicate_finder as fuzzy
    grams = [_grams(u[2]) for u in units]
    index = {}
    for i, g in enumerate(grams):
        for gram in g:
            index.setdefault(gram, []).append(i)
    # 太常見的 3-gram（「規定，」「應依本」）幾乎每一段都有：留著的話每一段都跟幾千段「有共同字」，
    # 粗篩等於沒篩（五千段要算幾億次）。超過 2%（至少 50 段）的段落都有的 gram 不拿來配對
    cap = max(50, int(len(units) * 0.02))
    common = set(gram for gram, posting in index.items() if len(posting) > cap)
    if common:
        grams = [g - common for g in grams]
        for gram in common:
            del index[gram]
    pairs = {}
    for i, g in enumerate(grams):
        shared = {}
        for gram in g:
            for j in index[gram]:
                if j > i:
                    shared[j] = shared.get(j, 0) + 1
        for j, common in shared.items():
            if common < 0.6 * min(len(g), len(grams[j])):
                continue
            if units[i][0] == units[j][0] and abs(units[i][1] - units[j][1]) <= 1:
                continue              # 同本相鄰兩段（同一條的兩款）不算
            score = fuzzy.calc_similarity(units[i][2], units[j][2])
            if score >= threshold:
                pairs[(i, j)] = {"字面分數": round(score, 1)}
    return pairs


def _dense_vectors(scorer, texts):
    """拿語意模型算每段的 dense 向量（有快取就沿用）；拿不到回 None。"""
    try:
        if hasattr(scorer, "_lite") and getattr(scorer, "cache", None) is not None:
            return [part["dense"] for part in scorer._lite(texts)]
        if hasattr(scorer, "_vectors"):
            return scorer._vectors(texts)
        model = getattr(scorer, "model", None)
        if model is not None and hasattr(model, "encode_dense"):
            return model.encode_dense(texts)
    except Exception as exc:          # 模型壞掉不能讓體檢整個停：語意這一路跳過就好
        print("  重複／矛盾的語意配對跳過（%s）" % str(exc)[:160], flush=True)
    return None


def _semantic_pairs(units, scorer, threshold=SEMANTIC_THRESHOLD):
    """語意相近的配對：dense cosine ≥ threshold。分批算矩陣，一段只留前 PER_PARAGRAPH 名。
    v1.27.2：前幾名先給文字有差異的；跟這一段一字不差（只差空白）的排在後面——那種整段複製的，
    字面相似那一路本來就會抓到，佔掉語意的名額，「幾乎一樣但名稱、數字不同」的就擠不進來。"""
    import semantic_candidates as sc
    texts = [u[2] for u in units]
    vectors = _dense_vectors(scorer, texts) if scorer is not None and texts else None
    if not vectors:
        return {}
    pairs = {}
    step = 512
    for start in range(0, len(texts), step):
        block = sc._cosine_matrix(vectors[start:start + step], vectors)
        if block is None:
            break                    # 沒有 numpy：純 Python 算 1 萬段的矩陣要幾小時，語意這一路跳過
        for offset, row in enumerate(block):
            i = start + offset
            near = [(score, j) for j, score in enumerate(row) if j > i and score >= threshold]
            mine = "".join(texts[i].split())
            # 同分時照舊（段次大的先），只多一條：一字不差的排後面
            ranked = sorted(near, key=lambda sj: ("".join(texts[sj[1]].split()) == mine, -sj[0], -sj[1]))[:PER_PARAGRAPH]
            for score, j in ranked:
                if units[i][0] == units[j][0] and abs(units[i][1] - units[j][1]) <= 1:
                    continue
                pairs[(i, j)] = {"語意分數": round(float(score), 3)}
    return pairs


SHORT_EXACT_CHARS = 60    # 同本裡一模一樣、又這麼短的段：多半是不同章節重複的清單項目（「三、需求分析評估報告書。」），不配


def _rank(info):
    """排序鍵：有差異的（改了幾個字）排前面、一模一樣的排最後——上限只留 300 對時，
    有價值的是「幾乎一樣但數字或主體不同」那種，不是整段複製貼上的。真資料第一次跑：300 對裡 130 對是一模一樣的。"""
    fuzzy = info.get("字面分數") or 0
    semantic = info.get("語意分數") or 0
    return (1 if fuzzy >= 99.5 else 0, -(semantic + fuzzy / 100.0))


def _how(info):
    return "＋".join(k for k in ("字面", "語意") if info.get("%s分數" % k) not in ("", None))


def _groups(pairs):
    """配對連成的群組（連通）：只看誰跟誰配，跟走訪順序無關。回傳每群的段落編號（由小到大），群照最小編號排。"""
    parent = {}

    def root(x):
        parent.setdefault(x, x)
        while parent[x] != x:
            parent[x] = parent[parent[x]]
            x = parent[x]
        return x
    for i, j in pairs:
        a, b = root(i), root(j)
        if a != b:
            parent[max(a, b)] = min(a, b)
    groups = {}
    for x in list(parent):
        groups.setdefault(root(x), []).append(x)
    return sorted((sorted(g) for g in groups.values()), key=lambda g: g[0])


def find_items(books, scorer=None, fuzzy_threshold=FUZZY_THRESHOLD, semantic_threshold=SEMANTIC_THRESHOLD,
               max_pairs=MAX_PAIRS, stats=None):
    """books：{規章名: 段落 list}。回傳 (配對 list, 家族 list)。
    配對：{"規章A", "段次A", "規章B", "段次B", "字面分數", "語意分數", "找法"}（2 段的群組，或全部一字不差的群組拆成的對）。
    家族（v1.31.0）：{"成員": [{"規章", "段次"}…], "字面分數", "語意分數", "找法"}（3 段以上、不是全部一字不差）。
    順序：有差異的先、一模一樣的後，分數高的先；同分照段落在批次裡的先後（規章清單的順序、段次）。
    整批最多 max_pairs 項（一對或一個家族算一項）。stats 回填 {"找到", "沒列", "每段上限沒列"(0), "總上限沒列", "家族", "家族段數"}。"""
    units = _units(books)
    found = _fuzzy_pairs(units, fuzzy_threshold)
    for key, info in _semantic_pairs(units, scorer, semantic_threshold).items():
        found.setdefault(key, {}).update(info)
    kept = {}
    for (i, j), info in found.items():
        a, b = units[i], units[j]
        if a[0] == b[0] and (info.get("字面分數") or 0) >= 99.5 and len(a[2]) < SHORT_EXACT_CHARS:
            continue              # 同本短句重複：清單項目，不算重複條文
        kept[(i, j)] = info
    items = []                    # (排序鍵, 種類, 內容)
    for members in _groups(kept):
        member_set = set(members)
        inside = sorted((key, info) for key, info in kept.items() if key[0] in member_set)
        identical = all(same_text(units[m][2], units[members[0]][2]) for m in members)
        if FAMILY_MIN <= len(members) <= FAMILY_MAX and not identical:
            best = min(_rank(info) for _key, info in inside)
            scores = dict((k, max([info.get("%s分數" % k) for _key, info in inside
                                   if info.get("%s分數" % k) not in ("", None)] or [""]))
                          for k in ("字面", "語意"))
            items.append(((best, members[0], members[1]), "家族", {
                "成員": [{"規章": units[m][0], "段次": units[m][1]} for m in members],
                "字面分數": scores["字面"], "語意分數": scores["語意"],
                "找法": _how({"字面分數": scores["字面"], "語意分數": scores["語意"]})}))
            continue
        for (i, j), info in inside:
            items.append(((_rank(info), i, j), "配對", {
                "規章A": units[i][0], "段次A": units[i][1], "規章B": units[j][0], "段次B": units[j][1],
                "字面分數": info.get("字面分數", ""), "語意分數": info.get("語意分數", ""), "找法": _how(info)}))
    items.sort(key=lambda item: item[0])
    shown = items[:max_pairs]
    pairs = [body for _key, kind, body in shown if kind == "配對"]
    families = [body for _key, kind, body in shown if kind == "家族"]
    if stats is not None:
        stats["找到"] = len(items)
        stats["沒列"] = len(items) - len(shown)
        stats["每段上限沒列"], stats["總上限沒列"] = 0, len(items) - len(shown)
        stats["家族"], stats["家族段數"] = len(families), sum(len(f["成員"]) for f in families)
    return pairs, families


def find_pairs(books, scorer=None, fuzzy_threshold=FUZZY_THRESHOLD, semantic_threshold=SEMANTIC_THRESHOLD,
               max_pairs=MAX_PAIRS, stats=None):
    """只要配對的舊介面（家族不回）；體檢流程用 find_items。"""
    return find_items(books, scorer, fuzzy_threshold, semantic_threshold, max_pairs, stats)[0]


def write_candidates(root, pairs, dropped=0, families=None):
    os.makedirs(folder(root), exist_ok=True)
    path = os.path.join(folder(root), CANDIDATES_FILE)
    with io.open(path + ".tmp", "w", encoding="utf-8") as f:
        json.dump({"格式版本": 1, "配對": pairs, "家族": list(families or []), "上限未列": dropped},
                  f, ensure_ascii=False, indent=1)
    os.replace(path + ".tmp", path)
    return path


def _read_candidates_file(root):
    path = os.path.join(folder(root), CANDIDATES_FILE)
    if not os.path.isfile(path):
        return {}
    try:
        with io.open(path, encoding="utf-8") as f:
            return json.load(f)
    except (OSError, ValueError) as exc:
        raise HealthCheckError("%s 讀不出來（%s）：請重新體檢" % (CANDIDATES_FILE, exc))


def read_candidates(root):
    return list(_read_candidates_file(root).get("配對") or [])


def read_families(root):
    """v1.31.0 的家族候選；v1.31.0 以前的產出沒有，回 []。"""
    return list(_read_candidates_file(root).get("家族") or [])


# ---------------------------------------------------------------------------
# 審查包與 AI 表
# ---------------------------------------------------------------------------

def pair_sha256(text_a, text_b):
    return hashlib.sha256(("%s\n\x00\n%s" % (text_a or "", text_b or "")).encode("utf-8")).hexdigest()


def _book_text(loaded, name, line):
    book = loaded.get(name) or {}
    paragraphs = book.get("new_paragraphs") or []
    shown = book.get("new_shown") or paragraphs
    index = int(line or 0) - 1
    if 0 <= index < len(paragraphs):
        return paragraphs[index], shown
    return "", shown


def shown_text(loaded, name, line):
    """給人和 AI 看的那一段：補回 Word 自動編號（「（二）」）。v1.7.1 以前審查包、報告用的是原文，
    自動編號的項次不見了，AI 因此誤判「段664少項次（二）」。"""
    text, shown = _book_text(loaded, name, line)
    index = int(line or 0) - 1
    paragraphs = (loaded.get(name) or {}).get("new_paragraphs") or []
    if shown is not paragraphs and len(shown) == len(paragraphs) and 0 <= index < len(shown):
        return shown[index]
    return text


_REF_TOKEN = re.compile(r"第[^第]+?[章節款目點條項]|[（(][^）)]+[）)]")
_SAME_TEXT_DROP = re.compile(r"[\s，。、；：:,.;（）()「」『』\-－~～‧·．]")
# v1.22.0：項次後面緊接數字的不算項次——「3.5%以上…」的「3.」是小數，以前被當項次拿掉，
# 「3.5%」「4.5%」兩段變成一字不差，數值矛盾被程式判成一致藏起來（審查 體檢#6）
_LEADING_NUMBER = re.compile(r"^\s*(?:第[^第\s]{1,6}[章節款目點條項]|[（(]?[一二三四五六七八九十百0-9]+[)）、.．](?![0-9０-９]))\s*")


def parent_ref(ref):
    """位置去掉最後一層：「第十一章第一節第七款第四目」→「第十一章第一節第七款」。"""
    tokens = _REF_TOKEN.findall(ref or "")
    return "".join(tokens[:-1]) if len(tokens) > 1 else (ref or "")


def same_text(a, b):
    """兩段文字一字不差：只差標點、空白、開頭項次、相容字元（NFKC）都算一樣。"""
    import unicodedata
    norm = lambda t: _SAME_TEXT_DROP.sub("", _LEADING_NUMBER.sub("", unicodedata.normalize("NFKC", t or "")))
    return bool(norm(a)) and norm(a) == norm(b)


_CONTRADICT_DUP = re.compile(r"刻意|沒有衝突|不衝突|無衝突|並無衝突")


def _duplicate_reason(body):
    """判「重複」的理由不能同時寫「刻意分列、沒有衝突」（那是一致的說法，v1.7.5 使用者指出）：含這些字的子句拿掉。"""
    parts = re.split(r"(?<=[，；。])", body or "")
    kept = [p for p in parts if p.strip() and not _CONTRADICT_DUP.search(p)]
    text = "".join(kept).rstrip("，；、 ")
    if text and not text.endswith("。"):
        text += "。"
    return text or "同一個上層位置的兩段文字一字不差。"


def auto_answer(loaded, pair):
    """一字不差的兩段：程式照位置判重複或一致，理由註明「程式判」。"""
    row = {"AI判斷": "重複", "AI理由": "〔完全重複〕兩段文字一字不差。",
           "規章A": pair["規章A"], "段次A": str(pair["段次A"]), "規章B": pair["規章B"], "段次B": str(pair["段次B"])}
    verdict, reason, note = program_verdict(loaded, row)
    if verdict == "重複":
        return {"AI判斷": "重複", "AI理由": "〔完全重複〕兩段文字一字不差，在同一個上層位置（程式判）。"}
    why = note.split("：", 1)[-1].replace("，不算重複", "") if note else "位置不同"
    return {"AI判斷": "一致", "AI理由": "〔一致〕兩段文字一字不差，但%s，不算重複（程式判）。" % why}


def _table(loaded, name, line):
    """這一段在第幾張 Word 表格（不在表格裡、或舊產出沒有這個資訊回 None）。"""
    tables = (loaded.get(name) or {}).get("new_tables") or []
    index = int(line or 0) - 1
    return tables[index] if 0 <= index < len(tables) else None


def program_verdict(loaded, row):
    """「重複」由程式照使用者的定義再核一次（v1.7.3）：同一本、同一個上層位置（只差最後一層）、文字相同才是重複；
    不符合的「重複」改判一致，符合的「一致」改判重複。回傳 (判斷, 理由, 程式說明)；沒改回 (原判斷, 原理由, "")。"""
    import scoring_rubric as sr
    verdict, reason = _s(row.get("AI判斷")), _s(row.get("AI理由"))
    if verdict not in ("重複", "一致"):
        return verdict, reason, ""
    name_a, line_a, name_b, line_b = (_s(row.get(k)) for k in ("規章A", "段次A", "規章B", "段次B"))
    text_a, _ = _book_text(loaded, name_a, line_a)
    text_b, _ = _book_text(loaded, name_b, line_b)
    ref_a, ref_b = _ref(loaded, name_a, line_a), _ref(loaded, name_b, line_b)
    # v1.23.0：兩段位置都算不出來（沒有條號、款次）時不當成同一個上層位置——以前空字串等於空字串，判成重複
    same_place = (name_a == name_b and bool(ref_a) and bool(ref_b) and parent_ref(ref_a) == parent_ref(ref_b)
                  and _table(loaded, name_a, line_a) == _table(loaded, name_b, line_b))
    identical = same_text(text_a, text_b)
    body = re.sub(r"^\s*〔[^〕]*〕", "", reason).strip()
    if verdict == "重複" and not (same_place and identical):
        why = ("不在同一本規章" if name_a != name_b
               else "在不同的表格裡" if _table(loaded, name_a, line_a) != _table(loaded, name_b, line_b)
               else "位置不明（沒有條號、款次）" if not (ref_a and ref_b)
               else "不在同一個上層位置" if not same_place else "文字不完全相同")
        return "一致", "〔一致〕" + body, "程式依位置與文字改判：%s，不算重複" % why
    if verdict == "一致" and same_place and identical:
        return ("重複", "〔完全重複〕" + _duplicate_reason(body),
                "程式依位置與文字改判：同一本、同一個上層位置、文字相同，算重複")
    if verdict == "重複":
        return "重複", "〔完全重複〕" + _duplicate_reason(body), ""
    return verdict, reason, ""


def _ref(loaded, name, line):
    contexts = (loaded.get(name) or {}).get("new_contexts") or []
    index = int(line or 0) - 1
    if 0 <= index < len(contexts):
        ctx = contexts[index]
        return ctx.get("ref") or ""
    return ""


def _context_lines(shown, line):
    index = int(line or 0) - 1
    lines = []
    for i in range(max(0, index - CONTEXT), min(len(shown), index + CONTEXT + 1)):
        lines.append("  %d　%s" % (i + 1, "※本段" if i == index else shown[i]))
    return lines


def _block(number, pair, loaded):
    text_a, shown_a = _book_text(loaded, pair["規章A"], pair["段次A"])
    text_b, shown_b = _book_text(loaded, pair["規章B"], pair["段次B"])
    how = "、".join("%s %s" % (k, pair[v]) for k, v in (("字面", "字面分數"), ("語意", "語意分數")) if pair.get(v) != "")
    lines = ["## P%d　重複／矛盾候選　找法：%s" % (number, how or pair.get("找法", ""))]
    for side, name, line, text, shown in (("A", pair["規章A"], pair["段次A"], text_a, shown_a),
                                           ("B", pair["規章B"], pair["段次B"], text_b, shown_b)):
        ref = _ref(loaded, name, line)
        lines.append("### %s：%s　段次 %s%s" % (side, name, line, ("（%s）" % ref) if ref else ""))
        lines.append("- 全文：%s" % shown_text(loaded, name, line))
        lines.append("- 前後文：")
        lines += _context_lines(shown, line)
    lines.append("### 要判的事\n兩段是不是在規範同一件事？規定一致、矛盾（數值、主體、程序、用詞不同），還是只是重複？"
                 "只是用字相近、講的不是同一件事就是「無關」。")
    return "\n".join(lines)


# ---------------------------------------------------------------------------
# 家族（v1.31.0）
# ---------------------------------------------------------------------------

def member_label(name, line):
    return "%s%s%s" % (name, MEMBER_SEP, line)


def parse_members(text):
    """「規章｜段次」一行一段 → [(規章, 段次字串)]；空白行略過。"""
    out = []
    for line in str(text or "").splitlines():
        line = line.strip()
        if line:
            name, _sep, number = line.rpartition(MEMBER_SEP)
            out.append((name.strip(), number.strip()))
    return out


def family_members(family):
    return [(m["規章"], str(m["段次"])) for m in family.get("成員") or []]


def family_sha256(loaded, members):
    """家族的指紋：每個成員的規章、段次、全文。段次也算進去——理由、有問題的段寫的是段次，移位了不能沿用。"""
    h = hashlib.sha256()
    for name, line in members:
        text, _ = _book_text(loaded, name, line)
        h.update(("%s\x00%s\x00%s\n\x00\n" % (name, line, text)).encode("utf-8"))
    return h.hexdigest()


def _family_disputed(loaded, members):
    """承辦在報告上不同意過其中任兩段的判斷：不沿用、不從答案庫帶。"""
    import precedents as pc
    texts = [_book_text(loaded, name, line)[0] for name, line in members]
    return any(pc.disputed(texts[a], texts[b]) for a in range(len(texts)) for b in range(a + 1, len(texts)))


def _family_block(fid, family, loaded):
    members = family_members(family)
    how = "、".join("%s %s" % (k, family[v]) for k, v in (("字面", "字面分數"), ("語意", "語意分數"))
                   if family.get(v) not in ("", None))
    lines = ["## %s　重複／矛盾候選・家族（%d 段）　找法：%s" % (fid, len(members), how or family.get("找法", ""))]
    for number, (name, line) in enumerate(members, 1):
        text, shown = _book_text(loaded, name, line)
        ref = _ref(loaded, name, line)
        lines.append("### 成員 %d：`%s`%s" % (number, member_label(name, line), ("（%s）" % ref) if ref else ""))
        lines.append("- 全文：%s" % shown_text(loaded, name, line))
        lines.append("- 前後文：")
        index = int(line or 0) - 1
        for i in range(max(0, index - FAMILY_CONTEXT), min(len(shown), index + FAMILY_CONTEXT + 1)):
            lines.append("  %d　%s" % (i + 1, "※本段" if i == index else shown[i]))
    lines.append("### 要判的事\n這幾段文字很像，多半是同一個範本改出來的。一段一段比：該一樣的地方（數值、主體、程序、用詞）"
                 "有沒有哪一段跟大家不一樣、哪一段寫錯？只差範本本來就要換的字（篇名、職稱、章名）是一致。\n"
                 "- 全部沒有衝突 → 一致；其實講的是不同的事 → 無關（「有問題的段」「對照段」都留空）\n"
                 "- 有段跟其他段規定不一樣 → 矛盾：「有問題的段」寫不一樣的那幾段，「對照段」寫一段代表多數說法的\n"
                 "- 有段打錯、漏字 → 錯漏字：「有問題的段」寫錯的那段，「對照段」寫寫對的那段，理由寫「改成…」\n"
                 "- 同一本、同一個上層位置重複寫了一樣的字 → 重複：「有問題的段」寫多出來的那幾段\n"
                 "「有問題的段」「對照段」照上面成員的寫法抄（`規章%s段次`），一行一段。" % MEMBER_SEP)
    return "\n".join(lines)


def _previous_family_table(root):
    from _common import previous_output
    prior = previous_output(root)
    return os.path.join(review_folder(prior), FAMILY_TABLE_FILE) if prior else ""


def _family_pack(root, loaded, families):
    """家族那一張表的列與審查包區塊。回傳 (表的列, 區塊, 沿用幾列)。"""
    carried = {}
    for position, path in enumerate((os.path.join(review_folder(root), FAMILY_TABLE_FILE),
                                     _previous_family_table(root))):
        if not path:
            continue
        _fields, rows = _read_table(path)
        for row in rows:
            key = _s(row.get(SHA_COLUMN))
            if key and _s(row.get("AI判斷")) and key not in carried:
                carried[key] = (position, dict((c, _s(row.get(c))) for c in FAMILY_ANSWER_COLUMNS))
    rows, blocks, kept = [], [], 0
    for number, family in enumerate(families, 1):
        fid = "F%d" % number
        members = family_members(family)
        sha = family_sha256(loaded, members)
        disputed = _family_disputed(loaded, members)
        position, answers = carried.get(sha, (0, {}))
        if answers and position and disputed:
            answers = {}              # 承辦不同意過：上一輪的答案不帶，重判
        if not answers and not disputed:
            import answer_bank as ab
            answers = ab.get(FAMILY_TABLE_FILE, sha, "\n".join(member_label(n, l) for n, l in members)) or {}
        kept += 1 if answers else 0
        rows.append([fid, "\n".join(member_label(n, l) for n, l in members)]
                    + [answers.get(c, "") for c in FAMILY_ANSWER_COLUMNS[:3]]
                    + [answers.get("AI理由", ""), sha])
        if not answers:
            blocks.append(_family_block(fid, family, loaded))
    return rows, blocks, kept


def _read_table(path):
    from _common import open_csv
    if not os.path.isfile(path):
        return [], []
    try:
        with open_csv(path) as f:
            reader = csv.DictReader(f)
            rows = list(reader)
            return list(reader.fieldnames or []), rows
    except (OSError, UnicodeDecodeError, csv.Error, ValueError):
        return [], []


def _previous_table(root):
    """上一輪（重新體檢之前）的 AI一致性.csv：兩段都沒變的答案帶回來。"""
    from _common import previous_output
    prior = previous_output(root)
    if prior:
        return os.path.join(review_folder(prior), TABLE_FILE)
    return ""


def write_pack(root, loaded, say=None):
    """寫 AI審查/LLM一致性審查.md、AI審查/AI一致性.csv（配對）、AI審查/AI一致性家族.csv（v1.31.0 家族）。
    回傳 (對數＋家族數, 沿用幾列)；沒有候選回 (0, 0) 並清掉舊檔。"""
    import scoring_rubric as sr
    say = say or (lambda text: print(text, flush=True))
    pairs = read_candidates(root)
    families = read_families(root)
    out = review_folder(root)
    os.makedirs(out, exist_ok=True)
    table_path = os.path.join(out, TABLE_FILE)
    family_path = os.path.join(out, FAMILY_TABLE_FILE)
    pack_path = os.path.join(out, PACK_FILE)
    if not pairs and not families:
        for path in (table_path, family_path, pack_path):
            if os.path.isfile(path):
                os.remove(path)
        return 0, 0
    # v1.25.0：同一個指紋可能有好幾對（兩對的文字一模一樣、位置不同）：每一對都記，
    # 沿用時先挑規章、段次也一樣的那一對。以前只記第一對，第二對拿到的理由寫的是第一對的段次，
    # 被當成「指到別段」丟掉、整對重判
    carried = {}
    for position, path in enumerate((table_path, _previous_table(root))):
        _fields, rows = _read_table(path)
        for row in rows:
            key = _s(row.get(SHA_COLUMN))
            if key and any(_s(row.get(c)) for c in ANSWER_COLUMNS):
                if position and _s(row.get("AI理由")).endswith("（程式判）"):
                    continue          # v1.22.0：程式判的每一輪重算（位置變了結論會變），不沿用
                entry = dict((c, _s(row.get(c))) for c in ANSWER_COLUMNS)
                entry["_段次"] = "%s|%s" % (_s(row.get("段次A")), _s(row.get("段次B"))) if position else None
                entry["_位置"] = (_s(row.get("規章A")), _s(row.get("段次A")), _s(row.get("規章B")), _s(row.get("段次B")))
                carried.setdefault(key, []).append(entry)
    blocks, table, kept = [], [], 0
    for number, pair in enumerate(pairs, 1):
        text_a, _ = _book_text(loaded, pair["規章A"], pair["段次A"])
        text_b, _ = _book_text(loaded, pair["規章B"], pair["段次B"])
        sha = pair_sha256(text_a, text_b)
        here = (pair["規章A"], str(pair["段次A"]), pair["規章B"], str(pair["段次B"]))
        found = carried.get(sha) or []
        # 先挑位置一樣的（這個資料夾的優先），再挑這個資料夾的，最後才是別的位置
        answers = dict(next((e for e in found if e["_位置"] == here),
                            next((e for e in found if e["_段次"] is None), found[0] if found else {})))
        previous = answers.get("_段次") is not None
        if answers.get("_段次") is not None:
            # 上一輪的答案：理由寫了段次（而兩段移位了）或 P3 這種會重編的編號，帶回去會指錯（審查 體檢#8）
            import answer_bank as ab
            if ab.points_elsewhere(answers, "%s|%s" % (pair["段次A"], pair["段次B"]), answers["_段次"]):
                answers = {}
        answers = dict((c, v) for c, v in answers.items() if c in ANSWER_COLUMNS)
        import precedents as pc
        if answers and previous and pc.disputed(text_a, text_b):
            answers = {}              # v1.22.0：承辦在報告寫了不同意：上一輪的答案不帶，重判
        if not answers and not pc.disputed(text_a, text_b):
            # v1.20.0：別的工作區審過一模一樣的兩段（AI答案庫）
            import answer_bank as ab
            answers = ab.get(TABLE_FILE, sha, "%s|%s" % (pair["段次A"], pair["段次B"])) or {}
        if not answers and same_text(text_a, text_b):
            # v1.8.0：兩段一字不差，重複與否照位置就判得出來（program_verdict），不必交給 AI
            answers = auto_answer(loaded, pair)
        kept += 1 if answers else 0
        table.append(["P%d" % number, pair["規章A"], str(pair["段次A"]), pair["規章B"], str(pair["段次B"]),
                      answers.get("AI判斷", ""), answers.get("AI理由", ""), sha])
        if not answers:
            blocks.append(_block(number, pair, loaded))   # v1.23.1：只放還沒有答案的（以前全部放，32 萬字裡要判的是 0 對）
    family_rows, family_blocks, family_kept = _family_pack(root, loaded, families)
    blocks += family_blocks
    with io.open(pack_path, "w", encoding="utf-8") as f:
        f.write(sr.pointer("一致性") + "\n---\n\n" + ("\n\n".join(blocks) if blocks else
                "（這一輪每一項都已經有答案（沿用、程式判），不用再判；%s 裡已經填好）"
                % "、".join(name for name, rows in ((TABLE_FILE, table), (FAMILY_TABLE_FILE, family_rows)) if rows))
                + "\n")
    for path, header, rows in ((table_path, HEADER, table), (family_path, FAMILY_HEADER, family_rows)):
        if not rows:
            if os.path.isfile(path):
                os.remove(path)
            continue
        with io.open(path + ".tmp", "w", encoding="utf-8-sig", newline="") as f:
            writer = csv.writer(f, quoting=csv.QUOTE_ALL)
            writer.writerow(header)
            writer.writerows(rows)
        os.replace(path + ".tmp", path)
    return len(pairs) + len(families), kept + family_kept


def unanswered(root, table=TABLE_FILE):
    """AI一致性.csv（或 table 指定的 AI一致性家族.csv）還有幾列沒填「AI判斷」；沒有這張表回 0。"""
    _fields, rows = _read_table(os.path.join(review_folder(root), table))
    return sum(1 for r in rows if not _s(r.get("AI判斷")))


# ---------------------------------------------------------------------------
# 匯入
# ---------------------------------------------------------------------------

def validate(root):
    """驗 AI一致性.csv 與 AI一致性家族.csv：每一項都要判、判斷字與標籤要對得上、理由不能空。回傳錯誤字串 list。"""
    return _validate_pairs(root) + _validate_families(root)


def _reason_errors(tag, verdict, reason):
    """配對、家族共用：判斷字、標籤、錯漏字要寫改成、矛盾要寫建議。"""
    import scoring_rubric as sr
    if not verdict:
        return ["%s：還沒填 AI判斷（%s）" % (tag, "／".join(sr.CONSISTENCY_VERDICTS))]
    if verdict not in sr.CONSISTENCY_VERDICTS:
        return ["%s：AI判斷不是允許的字：「%s」（可用：%s）" % (tag, verdict, "／".join(sr.CONSISTENCY_VERDICTS))]
    errors = []
    label = sr.label_in(reason)
    if verdict == "錯漏字" and reason and "改成" not in reason:
        errors.append("%s：判「錯漏字」的理由要寫哪一段錯、「改成…」" % tag)
    if not reason:
        errors.append("%s：AI理由是空的" % tag)
    elif not label:
        errors.append("%s：AI理由要用標籤開頭（可用：%s）" % (tag, sr.consistency_labels()))
    elif not sr.consistency_label_ok(verdict, label):
        errors.append("%s：「〔%s〕」配不上判斷「%s」（%s 可用：%s）"
                      % (tag, label, verdict, verdict, sr.consistency_labels(verdict)))
    if verdict == "矛盾" and reason and not _SUGGEST_RE.search(reason):
        errors.append("%s：判「矛盾」的理由要寫建議怎麼處理（「建議…」或「請確認…」）" % tag)
    return errors


def _validate_families(root):
    path = os.path.join(review_folder(root), FAMILY_TABLE_FILE)
    try:
        families = read_families(root)
    except HealthCheckError as exc:
        families = None
        if os.path.isfile(path):
            return ["%s（「%s」要對照它驗）" % (exc, FAMILY_TABLE_FILE)]
    if not os.path.isfile(path):
        # v1.31.0 審查：候選裡有家族、表卻不見了（被刪掉）：不能當作沒事，匯入會把家族整批丟掉
        return (["「%s」不見了（這一輪有 %d 個家族要判）：重跑審查打包會重新產生" % (FAMILY_TABLE_FILE, len(families))]
                if families else [])
    if families is None or not families:
        return ["這一輪的候選檔沒有家族，「%s」對不上：請重新體檢" % FAMILY_TABLE_FILE]
    fields, rows = _read_table(path)
    if not fields:
        return ["「%s」是空檔或讀不出來" % FAMILY_TABLE_FILE]
    missing = [c for c in FAMILY_HEADER if c not in [f.strip() for f in fields]]
    if missing:
        return ["「%s」缺欄位：%s" % (FAMILY_TABLE_FILE, "、".join(missing))]
    expected = dict(("F%d" % i, family) for i, family in enumerate(families, 1))
    errors, seen = [], set()
    for row in rows:
        fid = _s(row.get("家族ID"))
        tag = "%s %s" % (FAMILY_TABLE_FILE, fid or "（沒有家族ID）")
        if fid in seen:
            errors.append("%s：同一列出現兩次" % tag)
            continue
        seen.add(fid)
        family = expected.get(fid)
        if family is None:
            errors.append("%s：這一輪沒有這個家族（家族ID 不要改）" % tag)
            continue
        members = family_members(family)
        if parse_members(row.get("成員")) != members:
            errors.append("%s：「成員」是程式列的，不要改" % tag)
            continue
        verdict, reason = _s(row.get("AI判斷")), _s(row.get("AI理由"))
        problems = _reason_errors(tag, verdict, reason)
        errors += problems
        if verdict not in ("矛盾", "錯漏字", "重複", "一致", "無關"):
            continue
        flagged, other = parse_members(row.get("有問題的段")), parse_members(row.get("對照段"))
        if len(set(flagged)) != len(flagged) or len(set(other)) != len(other):
            errors.append("%s：「有問題的段」「對照段」同一段不要寫兩次" % tag)
            continue
        strangers = [member_label(*m) for m in flagged + other if m not in members]
        if strangers:
            errors.append("%s：「有問題的段」「對照段」要照「成員」的寫法抄（`規章%s段次`，一行一段），這幾段不是成員：%s"
                          % (tag, MEMBER_SEP, "、".join(strangers)))
            continue
        if verdict in ("一致", "無關"):
            if flagged or other:
                errors.append("%s：判「%s」時「有問題的段」「對照段」留空" % (tag, verdict))
            continue
        if not flagged:
            errors.append("%s：判「%s」要在「有問題的段」寫是哪幾段" % (tag, verdict))
        # 重複也要對照段（v1.31.0 審查）：以前程式自己挑第一個沒標的成員當 B，挑到別段就被改判一致、真正的重複藏起來
        if len(other) != 1:
            errors.append("%s：判「%s」要在「對照段」寫一段（%s）" % (tag, verdict, "跟它重複的那段" if verdict == "重複"
                                                                else "寫對的、或代表多數說法的那段"))
        elif other[0] in flagged:
            errors.append("%s：「對照段」不能也寫在「有問題的段」" % tag)
    for fid in sorted(set(expected) - seen, key=lambda f: int(f[1:])):
        errors.append("%s 少了 %s（每個家族都要判，不要刪列）" % (FAMILY_TABLE_FILE, fid))
    return errors


def _validate_pairs(root):
    import scoring_rubric as sr
    path = os.path.join(review_folder(root), TABLE_FILE)
    try:
        candidates = read_candidates(root)
    except HealthCheckError as exc:
        return ["%s（「%s」要對照它驗，無法確認配對是否完整）" % (exc, TABLE_FILE)]
    if not os.path.isfile(path):
        return (["「%s」不見了（這一輪有 %d 個配對要判）：重跑審查打包會重新產生" % (TABLE_FILE, len(candidates))]
                if candidates else [])
    fields, rows = _read_table(path)
    if not fields:
        return ["「%s」是空檔或讀不出來" % TABLE_FILE]
    missing = [c for c in HEADER if c not in [f.strip() for f in fields]]
    if missing:
        return ["「%s」缺欄位：%s" % (TABLE_FILE, "、".join(missing))]
    errors = []
    seen = set()
    # v1.23.0：對照候選清單——AI 刪掉的列、改了規章段次的列，以前匯入時默默丟掉（報告少了那幾對，還說「文字變了」）
    expected = dict(("P%d" % i, pair) for i, pair in enumerate(candidates, 1))
    for row in rows:
        tag = "%s %s" % (TABLE_FILE, _s(row.get("配對ID")) or "（沒有配對ID）")
        pid = _s(row.get("配對ID"))
        if pid in seen:
            errors.append("%s：同一列出現兩次" % tag)
            continue
        seen.add(pid)
        pair = expected.get(pid)
        if expected and pair is None:
            errors.append("%s：這一輪沒有這一對（配對ID 不要改）" % tag)
            continue
        places = ("規章A", "段次A", "規章B", "段次B")
        if pair and [_s(row.get(k)) for k in places] != [_s(pair.get(k)) for k in places]:
            errors.append("%s：規章、段次是程式列的，不要改（原本是 %s 段%s ／ %s 段%s）"
                          % (tag, pair["規章A"], pair["段次A"], pair["規章B"], pair["段次B"]))
            continue
        verdict = _s(row.get("AI判斷"))
        reason = _s(row.get("AI理由"))
        if not verdict:
            errors.append("%s：還沒填 AI判斷（%s）" % (tag, "／".join(sr.CONSISTENCY_VERDICTS)))
            continue
        if verdict not in sr.CONSISTENCY_VERDICTS:
            errors.append("%s：AI判斷不是允許的字：「%s」（可用：%s）" % (tag, verdict, "／".join(sr.CONSISTENCY_VERDICTS)))
            continue
        label = sr.label_in(reason)
        if verdict == "錯漏字" and reason and "改成" not in reason:
            errors.append("%s：判「錯漏字」的理由要寫哪一段錯、「改成…」" % tag)
        if not reason:
            errors.append("%s：AI理由是空的" % tag)
        elif not label:
            errors.append("%s：AI理由要用標籤開頭（可用：%s）" % (tag, sr.consistency_labels()))
        elif not sr.consistency_label_ok(verdict, label):
            errors.append("%s：「〔%s〕」配不上判斷「%s」（%s 可用：%s）"
                          % (tag, label, verdict, verdict, sr.consistency_labels(verdict)))
        if verdict == "矛盾" and reason and not _SUGGEST_RE.search(reason):
            errors.append("%s：判「矛盾」的理由要寫建議怎麼處理（「建議…」或「請確認…」）" % tag)
    for pid in sorted(set(expected) - seen, key=lambda p: int(p[1:])):
        errors.append("%s 少了 %s（每一對都要判，不要刪列；判不出來寫「無關」並說明）" % (TABLE_FILE, pid))
    return errors


# 判「矛盾」要寫建議：以前只找「請」字，「要保人申請」也算有寫
_SUGGEST_RE = re.compile(r"建議|請確認|請問|請改|請統一|請釐清|請承辦|請依|應改|改為|改成|統一為|擇一")


def _judged(loaded, row):
    verdict, reason, note = program_verdict(loaded, row)
    out = {"AI判斷": verdict, "AI理由": reason}
    if note:
        out.update({"AI原判": _s(row.get("AI判斷")), "程式改判": note})
    return out


def _result_row(loaded, pid, side_a, side_b, answers, family_note=""):
    row = {"配對ID": pid, "規章A": side_a[0], "段次A": side_a[1], "規章B": side_b[0], "段次B": side_b[1],
           "AI判斷": answers.get("AI判斷", ""), "AI理由": answers.get("AI理由", "")}
    out = {"配對ID": pid,
           "規章A": side_a[0], "段次A": side_a[1], "位置A": _ref(loaded, *side_a), "全文A": shown_text(loaded, *side_a),
           "規章B": side_b[0], "段次B": side_b[1], "位置B": _ref(loaded, *side_b), "全文B": shown_text(loaded, *side_b),
           **_judged(loaded, row)}
    if family_note:
        out["家族說明"] = family_note
    return out


def _import_families(root, loaded):
    """家族（v1.31.0）攤成報告用的列（跟配對同一個樣子，多「家族說明」）：
    矛盾、錯漏字、重複：每個有問題的段一列（A＝那一段、B＝對照段；重複沒寫對照段就拿第一個沒問題的成員）；
    一致、無關：一列（A、B＝前兩個成員）。指紋對不上的不收。回傳 (列, 過期幾個家族, 表的列)。"""
    path = os.path.join(review_folder(root), FAMILY_TABLE_FILE)
    if not os.path.isfile(path):
        return [], 0, []
    _fields, rows = _read_table(path)
    results, stale = [], 0
    for row in rows:
        members = parse_members(row.get("成員"))
        if len(members) < 2 or not all(line.isdigit() for _name, line in members)                 or family_sha256(loaded, members) != _s(row.get(SHA_COLUMN)):
            stale += 1
            continue
        fid = _s(row.get("家族ID"))
        answers = dict((c, _s(row.get(c))) for c in ("AI判斷", "AI理由"))
        flagged, other = parse_members(row.get("有問題的段")), parse_members(row.get("對照段"))
        note = "（同一家族 %s 共 %d 段：%s）" % (fid, len(members), "、".join(
            "%s 段%s" % (name, line) for name, line in members))
        if answers["AI判斷"] in ("一致", "無關") or not flagged:
            results.append(_result_row(loaded, fid, members[0], members[1], answers, note))
            continue
        rest = [m for m in members if m not in flagged]
        reference = other[0] if other else (rest[0] if rest else members[0])   # 驗證過的表一定有對照段；這裡只是保險
        for number, side in enumerate(flagged, 1):
            if side == reference:
                continue
            results.append(_result_row(loaded, "%s-%d" % (fid, number), side, reference, answers, note))
    return results, stale, rows


def import_results(root, loaded):
    """驗過之後：把每一對的判斷、理由、兩段全文與位置寫進 AI審查/一致性結果.json（體檢報告讀它）。
    指紋跟現在的兩段對不上的列不收（重新體檢後文字變了）。v1.31.0 起家族攤成同樣的列一起寫。回傳 (收了幾列, 過期幾列)。"""
    path = os.path.join(review_folder(root), TABLE_FILE)
    family_path = os.path.join(review_folder(root), FAMILY_TABLE_FILE)
    if not os.path.isfile(path) and not os.path.isfile(family_path):
        return 0, 0
    _fields, rows = _read_table(path)
    results, stale = [], 0
    for row in rows:
        text_a, _ = _book_text(loaded, _s(row.get("規章A")), _s(row.get("段次A")))
        text_b, _ = _book_text(loaded, _s(row.get("規章B")), _s(row.get("段次B")))
        if pair_sha256(text_a, text_b) != _s(row.get(SHA_COLUMN)):
            stale += 1
            continue
        results.append({"配對ID": _s(row.get("配對ID")),
                        "規章A": _s(row.get("規章A")), "段次A": _s(row.get("段次A")),
                        "位置A": _ref(loaded, _s(row.get("規章A")), _s(row.get("段次A"))),
                        "全文A": shown_text(loaded, _s(row.get("規章A")), _s(row.get("段次A"))),
                        "規章B": _s(row.get("規章B")), "段次B": _s(row.get("段次B")),
                        "位置B": _ref(loaded, _s(row.get("規章B")), _s(row.get("段次B"))),
                        "全文B": shown_text(loaded, _s(row.get("規章B")), _s(row.get("段次B"))),
                        **_judged(loaded, row)})
    family_results, family_stale, family_rows = _import_families(root, loaded)
    results += family_results
    out = os.path.join(review_folder(root), RESULT_FILE)
    with io.open(out + ".tmp", "w", encoding="utf-8") as f:
        json.dump(dict({"格式版本": 1, "列": results}, **_table_marks(root)), f, ensure_ascii=False, indent=1)
    os.replace(out + ".tmp", out)
    import answer_bank as ab
    if not stale:
        ab.save(TABLE_FILE, [(_s(r.get(SHA_COLUMN)), "%s|%s" % (_s(r.get("段次A")), _s(r.get("段次B"))),
                              dict((c, _s(r.get(c))) for c in ANSWER_COLUMNS))
                             for r in rows if _s(r.get("AI判斷")) and not _s(r.get("AI理由")).endswith("（程式判）")])
    if not family_stale:
        ab.save(FAMILY_TABLE_FILE, [(_s(r.get(SHA_COLUMN)), _s(r.get("成員")),
                                     dict((c, _s(r.get(c))) for c in FAMILY_ANSWER_COLUMNS))
                                    for r in family_rows if _s(r.get("AI判斷"))])
    return len(results), stale + family_stale


def _table_marks(root):
    """結果檔記下匯入時兩張表的指紋：AI 之後又改了表，pending 才知道要重新匯入。"""
    import decision_table as dt
    marks = {}
    for key, name in (("表指紋", TABLE_FILE), ("家族表指紋", FAMILY_TABLE_FILE)):
        path = os.path.join(review_folder(root), name)
        marks[key] = dt.file_sha256(path) if os.path.isfile(path) else ""
    return marks


def results(root):
    """匯入過的一致性結果（list）；沒有回 []。"""
    path = os.path.join(review_folder(root), RESULT_FILE)
    if not os.path.isfile(path):
        return []
    try:
        with io.open(path, encoding="utf-8") as f:
            return list(json.load(f).get("列") or [])
    except (OSError, ValueError, TypeError, AttributeError) as exc:
        from _common import warn_read_failure
        warn_read_failure(path, exc, "結果檔讀不到，這一輪報告少了一致性的列", "一致性檢查")
        return []


def pending(root):
    """一致性這一站還沒完：有表（配對或家族）、而且結果檔不存在或不是對這一版表寫的。"""
    try:
        wanted = bool(read_candidates(root)) or bool(read_families(root))
    except HealthCheckError:
        wanted = True
    have = any(os.path.isfile(os.path.join(review_folder(root), name)) for name in (TABLE_FILE, FAMILY_TABLE_FILE))
    if not have:
        return wanted and os.path.isfile(os.path.join(review_folder(root), RESULT_FILE))   # 有候選、表被刪掉：舊結果不能當完成
    result_path = os.path.join(review_folder(root), RESULT_FILE)
    if not os.path.isfile(result_path):
        return True
    try:
        with io.open(result_path, encoding="utf-8") as f:
            data = json.load(f)
    except (OSError, ValueError):
        return True
    # v1.31.0 以前的結果檔沒有「家族表指紋」：當作空的（那時沒有家族表）
    return any(data.get(key, "") != value for key, value in _table_marks(root).items())
