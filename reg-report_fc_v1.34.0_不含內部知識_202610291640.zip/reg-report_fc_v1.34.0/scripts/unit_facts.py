# -*- coding: utf-8 -*-
"""
單位事實表（v1.19.0）：工作區 匯入/單位事實.csv。

AI 判不了、要承辦回答的事（本行跟關係企業的證券公司算不算共同行銷、有沒有辦保費融資、要不要用 MID＋OTP……）：
AI 報告審查判「請人確認」的，程式自動加一列等回答；承辦把「回答」填上，下一輪三條流程（比對、體檢、法規追蹤）
的評分標準都附這幾條給 AI 照著判，不用每一輪重問。

放工作區、不放 skill 的 memoization：這是本單位的內部安排，skill 給別人用時不能帶出去。
"""

import csv
import datetime
import io
import os

from _common import open_csv, warn_read_failure


class FactsReadError(ValueError):
    pass

FILE = "單位事實.csv"
HEADER = ["序號", "問題", "回答", "誰確認", "確認日期", "來源"]
_WORKSPACE = [""]            # 這一次執行用的工作區（run_all 開頭設；沒設＝不附單位事實）


def set_workspace(root):
    _WORKSPACE[0] = root or ""


def current_workspace():
    return _WORKSPACE[0]


def path(workspace):
    return os.path.join(workspace, "匯入", FILE)


def read(workspace):
    """單位事實的列（問題空白的略過）。沒有這個檔回 []。"""
    if not workspace:
        return []
    target = path(workspace)
    if not os.path.isfile(target):
        return []
    try:
        with open_csv(target) as f:
            rows = list(csv.DictReader(f))
    except (OSError, ValueError, csv.Error) as exc:
        warn_read_failure(target, exc, "單位事實讀不出來，無法取得承辦回答；本次不新增問題、不覆寫原檔", "單位事實")
        raise FactsReadError("%s 讀不出來，請關閉 Excel 或另存成 CSV UTF-8 後重跑" % target) from exc
    return [r for r in rows if (r.get("問題") or "").strip()]


def _write(workspace, rows):
    target = path(workspace)
    os.makedirs(os.path.dirname(target), exist_ok=True)
    with io.open(target, "w", encoding="utf-8-sig", newline="") as f:
        writer = csv.writer(f, quoting=csv.QUOTE_ALL)
        writer.writerow(HEADER)
        for number, row in enumerate(rows, 1):
            writer.writerow([str(number)] + [(row.get(c) or "").strip() for c in HEADER[1:]])


def add_questions(workspace, questions):
    """questions＝[(問題, 來源)]；同一個問題已經有就不再加。回傳加了幾列。"""
    if not workspace or not os.path.isdir(os.path.join(workspace, "匯入")):
        return 0
    try:
        rows = read(workspace)
    except FactsReadError:
        return 0
    known = set((r.get("問題") or "").strip() for r in rows)
    added = 0
    for question, source in questions:
        question = (question or "").strip()
        if question and question not in known:
            rows.append({"問題": question, "回答": "", "誰確認": "", "確認日期": "", "來源": source})
            known.add(question)
            added += 1
    if added:
        _write(workspace, rows)
    return added


def answered(workspace):
    return [r for r in read(workspace) if (r.get("回答") or "").strip()]


def pending(workspace):
    return [r for r in read(workspace) if not (r.get("回答") or "").strip()]


def lines(workspace=None):
    """附給 AI 的那一段（評分標準、先讀我）。沒有回答過的事實回 []。"""
    workspace = workspace if workspace is not None else current_workspace()
    try:
        facts = answered(workspace)
    except FactsReadError:
        return ["**單位事實.csv 這一輪讀不出來**：沒有可用的承辦回答事實；要看單位事實才能判的，"
                "照「待確認」處理，不要自己假設。"]
    if not facts:
        return []
    out = ["**本單位已確認的事實**（工作區 匯入/%s，承辦回答過的；照這些判，不要再列成「請確認」）：" % FILE]
    for row in facts:
        who = "、".join(filter(None, [(row.get("誰確認") or "").strip(), (row.get("確認日期") or "").strip()]))
        out.append("- %s → %s%s" % (row["問題"].strip(), row["回答"].strip(), "（%s）" % who if who else ""))
    return out


def todo_line(workspace):
    """人工待辦「看報告時留意」那一行：有幾題等承辦回答。沒有回 ""。"""
    try:
        waiting = pending(workspace)
    except FactsReadError:
        return "匯入/單位事實.csv 讀不出來：請關閉 Excel，或另存成 CSV UTF-8 後重跑"
    if not waiting:
        return ""
    return ("有 %d 個問題要承辦回答（AI 判不了的本行業務事實）：打開 工作區/匯入/%s 填「回答」，"
            "下一輪 AI 就照著判，不再重問" % (len(waiting), FILE))


def today():
    from _common import tw_now, tw_today
    return tw_today().isoformat()
