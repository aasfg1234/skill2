# -*- coding: utf-8 -*-
"""
AI 上網查證結果的快取：同一段文字裡的同一處外部規章引用，查過、而且還在有效期內，就沿用。

每一輪 AI 都要重新上網查「保險法第一百七十七條」這種同一條引用；沒改的規章被拉進流程時，
它的每一處引用又要再查一次。查證結果（判斷、理由、更正、查證網址、類別、日期）存在
skill 資料夾的 memoization/AI查證紀錄.json（batch.cache_dir），下一次 review-pack 直接填進 AI外部引用.csv，
「沿用查證」欄寫當初查證的日期，AI 只要查沒填的那幾列。

超過 VALID_DAYS 天一定重查：法規會修。「無法查證」裡的〔查無資料〕（上網查遍都找不到）存 NOT_FOUND_DAYS 天
（v1.25.0：以前不存，每一輪都要 AI 再查一次一樣的結果）；〔無法連網〕不存（下次再試）。
刪掉這個檔不會出錯，只是下次全部重查。
"""

import datetime
import hashlib
import io
import json
import os
import re

FILE = "AI查證紀錄.json"
VALID_DAYS = 90
SETTING_DAYS = "查證沿用天數"          # 設定.html 的欄：留空用 VALID_DAYS
CACHE_COLUMN = "沿用查證"
FIELDS = ("AI判斷", "AI理由", "AI更正", "查證來源", "類別")
KEEP_VERDICTS = ("有誤", "沒問題")
# 〔查無資料〕沿用幾天（比一般的短：之後可能就查得到）
NOT_FOUND_DAYS = 30
# 查詢失敗不能當成法規不存在；匯入驗證與快取共用這一份判斷。
CONNECTION_ERROR_RE = re.compile(
    r"憑證(?:錯誤|驗證|失敗|缺少|無效|過期|問題|不受信任)|Subject\s+Key\s+Identifier|"
    r"SSL\s*(?:錯誤|error)|TLS\s*(?:錯誤|error)|CERTIFICATE_VERIFY_FAILED|certificate\s+verify|"
    r"逾時|timeout|timed\s+out|"
    r"連不上|無法連線|拒絕連線|連線錯誤|被擋|HTTP\s*(?:403|5\d{2})(?!\d)", re.IGNORECASE)


def _connection_not_found(row):
    return ((row.get("AI理由") or "").strip().startswith("〔查無資料〕")
            and bool(CONNECTION_ERROR_RE.search("\n".join(row.get(c) or "" for c in ("AI理由", "查證來源")))))


def valid_days(settings=None):
    """沿用幾天：設定.html「查證沿用天數」，留空（或填壞）用 VALID_DAYS。settings 沒給就自己讀設定檔。"""
    if settings is None:
        try:
            from _common import config_section
            settings = config_section("設定")
        except Exception:
            settings = {}
    value = (settings or {}).get(SETTING_DAYS)
    if value in (None, "", 0, "0"):
        return VALID_DAYS
    try:
        return max(1, int(value))
    except (TypeError, ValueError):
        return VALID_DAYS


def key(citation, paragraph):
    return hashlib.sha256(("%s\n\x00\n%s" % (citation or "", "".join((paragraph or "").split())))
                          .encode("utf-8")).hexdigest()


def _path(folder):
    return os.path.join(folder, FILE)


def load(folder):
    if not folder or not os.path.isfile(_path(folder)):
        return {}
    try:
        with io.open(_path(folder), encoding="utf-8") as f:
            entries = json.load(f)
        return ({k: row for k, row in entries.items() if isinstance(row, dict) and not _connection_not_found(row)}
                if isinstance(entries, dict) else {})
    except (OSError, ValueError):
        return {}


def lookup(entries, k, today=None, days=VALID_DAYS):
    """有效期內的那一筆（dict，含「日期」）；沒有或過期回 None。"""
    from _common import tw_now, tw_today
    entry = entries.get(k)
    if not entry or _connection_not_found(entry):
        return None
    try:
        when = datetime.date.fromisoformat(entry.get("日期") or "")
    except ValueError:
        return None
    today = today or tw_today()
    if _not_found(entry):
        days = min(days, NOT_FOUND_DAYS)
    return entry if (today - when).days <= days else None


def _not_found(row):
    """「無法查證」〔查無資料〕：上網查過、哪裡都找不到（不是本行內規、不是連不上網）。"""
    return ((row.get("AI判斷") or "").strip() == "無法查證"
            and (row.get("AI理由") or "").strip().startswith("〔查無資料〕")
            and not _connection_not_found(row))


def _save(folder, entries):
    os.makedirs(folder, exist_ok=True)
    tmp = _path(folder) + ".tmp"
    with io.open(tmp, "w", encoding="utf-8") as f:
        json.dump(entries, f, ensure_ascii=False, indent=1)
    os.replace(tmp, _path(folder))


def _internal_rule(row):
    """「無法查證」裡的〔本行內規〕：本行自己的規章，網路本來就查不到，名稱不會因為上網再查一次而變（v1.8.0 起存）。
    〔查無資料〕〔無法連網〕照舊不存：下次可能就查得到。"""
    reason = (row.get("AI理由") or "").strip()
    return ((row.get("AI判斷") or "").strip() == "無法查證"
            and (reason.startswith("〔本行內規〕") or (row.get("類別") or "").strip() == "本行內規"
                 and not reason.startswith(("〔查無資料〕", "〔無法連網〕"))))


def record(folder, rows, today=None):
    """rows：[(鑰匙, AI 那一列)] 或 [(鑰匙, AI 那一列, 引用文字)]；只存「有誤」「沒問題」（加上本行內規、
    〔查無資料〕的無法查證），而且不是沿用來的。
    引用文字（「保險法第146條」）一起存：鑰匙是指紋、看不出是哪部法，「法規更動」要靠它找出要作廢的那幾筆。
    回傳存了幾筆。"""
    from _common import tw_now, tw_today
    if not folder:
        return 0
    entries = load(folder)
    stamp = (today or tw_today()).isoformat()
    count = 0
    for item in rows:
        k, row = item[0], item[1]
        citation = (item[2] if len(item) > 2 else "") or ""
        verdict = (row.get("AI判斷") or "").strip()
        if (row.get(CACHE_COLUMN) or "").strip():
            continue
        if _connection_not_found(row):
            continue
        if verdict not in KEEP_VERDICTS and not _internal_rule(row) and not _not_found(row):
            continue
        entry = dict(((f, (row.get(f) or "").strip()) for f in FIELDS), 日期=stamp)
        if citation.strip():
            entry["引用"] = citation.strip()
        entries[k] = entry
        count += 1
    if count:
        _save(folder, entries)
    return count


def invalidate(folder, names=None, everything=False):
    """外部法規改了：把跟 names（法規名稱，可好幾個）有關的紀錄拿掉，下一次審查打包就會重新上網查。
    看「引用」欄（新存的紀錄有）；舊紀錄沒有引用欄，退回看 AI理由、AI更正 裡有沒有那個名字。
    everything＝True 全部拿掉。回傳 (拿掉幾筆, 原本幾筆)。"""
    entries = load(folder) if folder else {}
    total = len(entries)
    if not entries:
        return 0, 0
    wanted = [re.sub(r"\s+", "", n) for n in (names or []) if n and n.strip()]
    if everything:
        kept = {}
    else:
        if not wanted:
            return 0, total
        kept = {}
        for k, entry in entries.items():
            haystack = re.sub(r"\s+", "", "\n".join(str(entry.get(f) or "")
                                                   for f in ("引用", "AI理由", "AI更正")))
            if not any(name in haystack for name in wanted):
                kept[k] = entry
    removed = total - len(kept)
    if removed:
        _save(folder, kept)
    return removed, total
