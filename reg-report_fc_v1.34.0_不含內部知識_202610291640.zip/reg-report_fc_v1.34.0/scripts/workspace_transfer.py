"""工作區搬移：串流指紋、增量清單與安全解包。"""
import datetime
import contextlib
import fnmatch
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import re
import shutil
import tempfile
import zipfile
import zlib
import uuid

import workspace

MANIFEST = "搬移清單.json"
BASELINE = ".搬移基準.json"
CONFLICT = "_衝突/"
MEMO = "_skill累積/memoization/"
MARKERS = (workspace.LAYOUT_FILE, workspace.ACTIVE_OUTPUT_FILE, "法規作業.json")
SENSITIVE_PATTERNS = (".env*", "*.secret*", "*.pem", "*.key", "auth.json", "sinopac*", "shioaji*",
                      "credentials*", "*.pfx", "*.p12", "id_rsa*", "*token*.txt", "*token*.json")


def _suspicious(name):
    lower = name.lower()
    return (any(fnmatch.fnmatchcase(lower, pattern) for pattern in SENSITIVE_PATTERNS)
            or bool(re.search(r"(?:^|[^a-z0-9])keys(?:[^a-z0-9]|$)", lower)) and lower.endswith(".json"))


def _excluded(name):
    return (name.startswith("~$") or name.lower().endswith(".tmp")
            or name in (".執行中.json", "__pycache__", BASELINE) or name.startswith(".搬移暫存_") or _suspicious(name))


def _keyed(items):
    if not isinstance(items, dict):
        raise ValueError("清單檔案欄位不正確")
    result = {}
    for name, meta in items.items():
        if not isinstance(name, str) or not _safe(name):
            raise ValueError("清單含不安全的路徑")
        if not isinstance(meta, dict) or type(meta.get("大小")) is not int or meta["大小"] < 0 or not isinstance(meta.get("sha256"), str) or not re.fullmatch(r"[0-9a-f]{64}", meta["sha256"]):
            raise ValueError("清單指紋格式不正確：%s" % name)
        key = name.casefold()
        if key in result:
            raise ValueError("清單含大小寫重複的路徑：%s" % name)
        result[key] = (name, meta)
    return result


def _baseline_record(root):
    path = root / BASELINE
    if not path.exists():
        return None
    value = _read_manifest(path)
    if value.get("格式版本") != 1 or not isinstance(value.get("檔案"), dict):
        raise ValueError("同步基準格式不正確")
    _keyed(value["檔案"])
    before = value.get("打包前基準")
    if before is not None:
        _keyed(before)
    return value


def _baseline(root):
    value = _baseline_record(root)
    return value["檔案"] if value is not None else None


def _write_baseline(root, files, extra=None):
    temp = root / (BASELINE + "." + uuid.uuid4().hex + ".tmp")
    try:
        record = {"格式版本": 1, "檔案": files}
        record.update(extra or {})
        temp.write_text(json.dumps(record, ensure_ascii=False, indent=2), encoding="utf-8")
        os.replace(temp, root / BASELINE)
    finally:
        if temp.exists():
            temp.unlink()


def _in_scope(name, output_only, prefix, include_memo):
    folded = name.casefold()
    if folded.startswith("_skill累積/".casefold()):
        return include_memo
    if not output_only:
        return True
    return folded in {marker.casefold() for marker in MARKERS} or folded.startswith(prefix.casefold())


def _merge_baseline(old, current, output_only, prefix, include_memo):
    preserved = {name: meta for name, meta in (old or {}).items()
                 if not _in_scope(name, output_only, prefix, include_memo)}
    updated = {name: meta for name, meta in current.items()
               if _in_scope(name, output_only, prefix, include_memo)}
    preserved.update(updated)
    return preserved


def _files(root, scope=None):
    result = {}
    skipped = 0
    skipped_dirs = 0
    for folder, dirs, files in os.walk(root, followlinks=False):
        skipped_dirs += sum(1 for d in dirs if _suspicious(d))
        dirs[:] = sorted(d for d in dirs if not _excluded(d) and not (Path(folder) / d).is_symlink())
        for name in sorted(files):
            path = Path(folder) / name
            rel = path.relative_to(root).as_posix()
            if scope and not scope(rel):
                continue
            if _suspicious(name):
                skipped += 1
            if not _excluded(name) and not path.is_symlink():
                result[rel] = path
    return result, skipped, skipped_dirs


def _digest(stream):
    h = hashlib.sha256()
    size = 0
    while True:
        block = stream.read(1024 * 1024)
        if not block:
            return {"大小": size, "sha256": h.hexdigest()}
        size += len(block)
        h.update(block)


def _metadata(path):
    with open(path, "rb") as stream:
        return _digest(stream)


def _read_manifest(path):
    with open(path, encoding="utf-8") as f:
        return json.load(f)


def _memo_dir():
    from batch import cache_dir
    return Path(cache_dir())


@contextlib.contextmanager
def _transfer_lock(root):
    path = root / ".執行中.json"
    try:
        fd = os.open(path, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
    except FileExistsError:
        try:
            held = _read_manifest(path)
            command = str(held.get("指令") or "不明").replace("\n", " ").replace("\r", " ")
            started = str(held.get("開始") or "不明").replace("\n", " ").replace("\r", " ")
        except (OSError, ValueError, AttributeError):
            command, started = "不明", "不明"
        raise ValueError("這個工作區正在跑別的指令（%s，%s），等它跑完再搬；確定沒有在跑才刪掉 .執行中.json" % (command, started)) from None
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            json.dump({"pid": os.getpid(), "指令": "工作區搬移", "開始": datetime.datetime.now().isoformat(timespec="seconds")}, f, ensure_ascii=False)
        yield
    finally:
        path.unlink(missing_ok=True)


def execute_locked(args, settings):
    created = []
    root = None
    try:
        if args.func is pack:
            root = Path(workspace.resolve_root(getattr(args, "workspace", ""), settings)).resolve()
        elif args.func is unpack:
            root = Path(os.path.abspath(args.destination))
            _reject_links(root)
            if not root.exists():
                path = root
                while not path.exists():
                    created.append(path)
                    path = path.parent
                for path in reversed(created):
                    path.mkdir()
        else:
            target = Path(os.path.abspath(args.target))
            root = target if target.is_dir() else target.parent
        with _transfer_lock(root):
            return args.func(args, settings)
    except (OSError, ValueError, TypeError) as exc:
        message = str(exc).replace("\n", " ")
        print(message if message.startswith("這個工作區正在跑別的指令") else "工作區搬移失敗：%s" % message)
        return 1
    finally:
        for path in created:
            try:
                path.rmdir()
            except OSError:
                pass


def pack(args, settings):
    try:
        root = Path(workspace.resolve_root(getattr(args, "workspace", ""), settings)).resolve()
        if not root.is_dir():
            raise ValueError("找不到工作區：%s" % root)
        suffix = "_清單_" if args.list_only else "_搬移_"
        extension = ".json" if args.list_only else ".zip"
        output = Path(args.output).resolve() if args.output else root.parent / (root.name + suffix + datetime.datetime.now().strftime("%Y%m%d_%H%M%S") + extension)
        if output == root or root in output.parents:
            raise ValueError("ZIP 必須放在工作區外")
        scope = None
        prefix = ""
        if args.output_only:
            active = workspace.current_output(str(root))
            if not active:
                raise ValueError("目前作業沒有有效的產出資料夾")
            prefix = Path(active).name + "/"
            scope = lambda k: _in_scope(k, True, prefix, False)
        files, skipped, skipped_dirs = _files(root, scope)
        if any(k.startswith("_skill累積/") or k == "_skill累積" for k in files) or (root / "_skill累積").exists():
            raise ValueError("工作區含搬移保留名稱 _skill累積")
        if (root / "_衝突").exists():
            raise ValueError("工作區含搬移保留名稱 _衝突")
        memo_root = _memo_dir().resolve()
        if memo_root == root or root in memo_root.parents:
            raise ValueError("累積資料目錄不能在工作區內")
        if args.include_memo and _memo_dir().is_dir():
            memo_files, memo_skipped, memo_dirs = _files(_memo_dir())
            skipped += memo_skipped
            skipped_dirs += memo_dirs
            files.update({MEMO + k: v for k, v in memo_files.items()})
        if MANIFEST in files or any(k.startswith("_skill累積/") and not k.startswith(MEMO) for k in files):
            raise ValueError("工作區含搬移保留名稱")
        all_files = {k: _metadata(v) for k, v in files.items()}
        peer = _read_manifest(args.previous) if args.previous else {}
        previous = peer.get("全部檔案", {})
        if scope:
            previous = {k: v for k, v in previous.items() if scope(k) or (args.include_memo and k.casefold().startswith(MEMO.casefold()))}
        elif not args.include_memo:
            previous = {k: v for k, v in previous.items() if not k.casefold().startswith(MEMO.casefold())}
        previous = {k: v for k, v in previous.items() if not any(_excluded(part) for part in k.split("/"))}
        own_record = _baseline_record(root)
        own_base = own_record["檔案"] if own_record is not None else None
        effective_base = own_base
        if own_record and own_record.get("最後打包ID") and peer.get("最後套用ID") != own_record["最後打包ID"]:
            effective_base = own_record.get("打包前基準")
        other_base = peer.get("基準")
        mine, theirs = _keyed(all_files), _keyed(previous)
        force_keys = set()
        for name in args.force_paths:
            if not _safe(name) or name.casefold() not in mine:
                raise ValueError("以我為準的檔案不存在或不在本次範圍：%s" % name)
            force_keys.add(name.casefold())
        own_b, peer_b = _keyed(effective_base or {}), _keyed(other_base or {})
        common = {k: v[1] for k, v in own_b.items() if k in peer_b and v[1] == peer_b[k][1]}
        selected, deleted, conflicts, blocked = {}, {}, {}, []
        after = {k: v[1] for k, v in theirs.items()}
        for key in sorted(mine.keys() | theirs.keys()):
            mine_value = mine.get(key, (None, None))[1]
            their_value = theirs.get(key, (None, None))[1]
            if key in force_keys:
                selected[mine[key][0]] = mine_value
                after[key] = mine_value
                continue
            if mine_value == their_value:
                continue
            base = common.get(key)
            if key in common and mine_value == base:
                continue
            if (key in common and their_value == base) or (key not in common and their_value is None):
                if mine_value is None:
                    deleted[theirs[key][0]] = their_value
                    after.pop(key, None)
                else:
                    selected[mine[key][0]] = mine_value
                    after[key] = mine_value
            elif key not in common and mine_value is None:
                continue
            elif mine_value is None:
                blocked.append(theirs[key][0])
            else:
                conflicts[CONFLICT + mine[key][0]] = mine_value
        new_base = {name: value for key, (name, value) in mine.items() if after.get(key) == value}
        transfer_id = uuid.uuid4().hex if not args.list_only else None
        manifest = {"格式版本": 1, "工作區資料夾名": root.name, "建立時間": datetime.datetime.now().isoformat(timespec="seconds"),
                    "模式": "只要產出" if args.output_only else ("變動" if args.previous else "全部"), "連同累積資料": args.include_memo,
                    "產出前綴": prefix,
                    "檔案": dict(selected, **conflicts), "全部檔案": all_files, "已刪除": deleted, "基準": own_base, "對方檔案": previous, "衝突": list(conflicts), "刪除衝突": blocked,
                    "搬移ID": transfer_id, "最後套用ID": (own_record or {}).get("最後套用ID"), "以我為準": [mine[key][0] for key in sorted(force_keys)]}
        data = json.dumps(manifest, ensure_ascii=False, indent=2).encode("utf-8")
        output.parent.mkdir(parents=True, exist_ok=True)
        if args.list_only:
            output.write_bytes(data)
            print("打包工作區：清單 %d 個檔；略過疑似帳密檔 %d 個、資料夾 %d 個（不搬）；清單：%s" % (len(all_files), skipped, skipped_dirs, output))
            return 0
        with zipfile.ZipFile(output, "w", compression=zipfile.ZIP_DEFLATED, allowZip64=True) as z:
            for name, meta in manifest["檔案"].items():
                source_name = name[len(CONFLICT):] if name.startswith(CONFLICT) else name
                h = hashlib.sha256()
                size = 0
                with open(files[source_name], "rb") as source, z.open(name, "w", force_zip64=True) as target:
                    for block in iter(lambda: source.read(1024 * 1024), b""):
                        target.write(block)
                        size += len(block)
                        h.update(block)
                if {"大小": size, "sha256": h.hexdigest()} != meta:
                    raise ValueError("打包期間檔案被改，請重跑")
            z.writestr(MANIFEST, data)
        side = Path(str(output) + ".清單.json")
        side.write_bytes(data)
        extra = {"最後打包ID": transfer_id, "打包前基準": effective_base}
        if own_record and "最後套用ID" in own_record:
            extra["最後套用ID"] = own_record["最後套用ID"]
        _write_baseline(root, _merge_baseline(own_base, new_base, args.output_only, prefix, args.include_memo), extra)
        same_note = "；兩邊一樣，不用搬" if args.previous and not selected and not deleted and not conflicts and not blocked and mine == theirs else ""
        same_note += "；衝突 %d 個，刪除衝突 %d 個" % (len(conflicts), len(blocked))
        if args.previous and not common:
            same_note += "；沒有同步基準，這次不刪、不蓋，衝突 %d 個請人看" % (len(conflicts) + len(blocked))
        print("打包工作區：放了 %d 個檔（%.1f MB），沒變的 %d 個沒放，已刪除 %d 個；略過疑似帳密檔 %d 個、資料夾 %d 個（不搬）%s；ZIP：%s；清單：%s" %
              (len(selected), sum(v["大小"] for v in selected.values()) / 1048576, len(all_files)-len(selected), len(deleted), skipped, skipped_dirs, same_note, output, side))
        return 0
    except (OSError, ValueError, KeyError, TypeError, AttributeError, RuntimeError, zipfile.BadZipFile, zlib.error) as exc:
        print("打包工作區失敗：%s" % str(exc).replace("\n", " "))
        return 1


def _safe(name):
    if not name or "\\" in name or name.startswith("/") or re.match(r"^[A-Za-z]:", name):
        return False
    parts = name.rstrip("/").split("/")
    return all(p not in ("", ".", "..") and not re.search(r'[<>:"|?*\x00-\x1f]', p)
               and not p.endswith((".", " ")) and not re.match(r"(?i)^(con|prn|aux|nul|com[1-9]|lpt[1-9])(?:\.|$)", p) for p in parts)


def _reject_links(path):
    for part in (path, *path.parents):
        if part.is_symlink() or (hasattr(part, "is_junction") and part.is_junction()):
            raise ValueError("目的地含連結或接合點：%s" % part)


def _validate(z):
    infos = z.infolist()
    names = [i.filename for i in infos]
    if any(not _safe(n) for n in names) or len(set(n.casefold() for n in names)) != len(names):
        raise ValueError("ZIP 含不安全或重複的路徑")
    if any(any(_suspicious(p) for p in n.split("/")) for n in names):
        raise ValueError("ZIP 含疑似帳密檔")
    if any((i.external_attr >> 16) & 0o170000 == 0o120000 for i in infos):
        raise ValueError("ZIP 含符號連結")
    bad = z.testzip()
    if bad:
        raise ValueError("ZIP 損壞：%s" % bad)
    manifest = json.loads(z.read(MANIFEST).decode("utf-8"))
    if not isinstance(manifest, dict) or not isinstance(manifest.get("檔案"), dict) or not isinstance(manifest.get("全部檔案"), dict):
        raise ValueError("清單欄位不正確")
    _keyed(manifest["檔案"])
    _keyed(manifest["全部檔案"])
    deleted = manifest.get("已刪除", {})
    if not isinstance(deleted, (dict, list)) or any(not isinstance(n, str) or not _safe(n) for n in deleted):
        raise ValueError("清單含不安全的刪除路徑")
    expected = manifest["檔案"]
    for name, meta in expected.items():
        if not isinstance(name, str) or not isinstance(meta, dict) or not isinstance(meta.get("大小"), int) or not isinstance(meta.get("sha256"), str):
            raise ValueError("清單檔案欄位不正確")
    actual = {i.filename for i in infos if not i.is_dir()} - {MANIFEST}
    if set(expected) != actual:
        raise ValueError("ZIP 檔案與清單不一致：%s" % "、".join(sorted(set(expected) ^ actual)[:20]))
    bad = []
    for name, meta in expected.items():
        with z.open(name) as f:
            if _digest(f) != meta:
                bad.append(name)
    if bad:
        raise ValueError("指紋不符：%s" % "、".join(bad[:20]))
    return manifest


def unpack(args, settings):
    dest = Path(os.path.abspath(args.destination))
    stage = None
    backups, placed, created_dirs = [], [], []
    dest_created = False
    committed = False
    try:
        _reject_links(dest)
        memo = Path(os.path.abspath(_memo_dir()))
        _reject_links(memo)
        if memo == dest or dest in memo.parents:
            raise ValueError("累積資料目錄不能在目的地內")
        if os.path.splitdrive(str(memo))[0].casefold() != os.path.splitdrive(str(dest))[0].casefold() and args.apply_memo:
            raise ValueError("累積資料與目的地必須在同一磁碟才能回滾")
        if dest.exists() and any(p.name != ".執行中.json" for p in dest.iterdir()) and not (dest / workspace.LAYOUT_FILE).is_file():
            raise ValueError("目的地不是空資料夾，也沒有工作區標記檔")
        with zipfile.ZipFile(args.zip_path) as z:
            manifest = _validate(z)
            output_only = manifest.get("模式") == "只要產出"
            prefix = manifest.get("產出前綴", "")
            if output_only and (not isinstance(prefix, str) or not prefix.endswith("/") or not _safe(prefix[:-1]) or "/" in prefix[:-1]):
                raise ValueError("只要產出的清單缺少有效產出前綴")
            baseline_path = dest / BASELINE
            baseline_before = _metadata(baseline_path) if baseline_path.is_file() else None
            old_record = _baseline_record(dest)
            old_base = old_record["檔案"] if old_record is not None else None
            if baseline_before != (_metadata(baseline_path) if baseline_path.is_file() else None):
                raise ValueError("%s 在搬移期間被改過，請重跑" % baseline_path)
            if (dest / BASELINE).resolve() == Path(args.zip_path).resolve():
                raise ValueError("ZIP 位置與同步基準重疊")
            sender = manifest["全部檔案"]
            peer = _keyed(manifest.get("對方檔案", {}))
            timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
            source_name = manifest.get("工作區資料夾名", "來源")
            if not isinstance(source_name, str) or not _safe(source_name) or "/" in source_name:
                raise ValueError("來源工作區名稱不正確")
            operations, warnings = [], list(manifest.get("刪除衝突", []))
            forced = manifest.get("以我為準", [])
            if not isinstance(forced, list) or any(not isinstance(name, str) or not _safe(name) for name in forced):
                raise ValueError("以我為準清單格式不正確")
            force_keys = {name.casefold() for name in forced}
            if not force_keys.issubset({name.casefold() for name in manifest["檔案"] if not name.startswith(CONFLICT)}):
                raise ValueError("以我為準的檔案不在封包中")
            planned_state = {}
            sent_keys = set()
            for name in manifest["檔案"]:
                conflict = name.startswith(CONFLICT)
                rel = name[len(CONFLICT):] if conflict else name
                if rel.startswith(MEMO):
                    if not args.apply_memo:
                        continue
                    base, sub = memo, rel[len(MEMO):]
                else:
                    base, sub = dest, rel
                if not _safe(sub) or any(_excluded(x) for x in sub.split("/")):
                    raise ValueError("檔案路徑不安全：%s" % rel)
                target = base.joinpath(*PurePosixPath(sub).parts)
                _reject_links(target)
                source_state = _metadata(target) if target.is_file() else None
                if not conflict and rel.casefold() not in force_keys and target.is_file() and rel.casefold() not in peer:
                    if source_state == manifest["檔案"][name]:
                        continue
                    conflict = True
                if conflict:
                    target = target.with_name(target.stem + ".衝突-" + source_name + "-" + timestamp + target.suffix)
                    if target.exists():
                        raise ValueError("衝突副本已存在：%s" % target)
                    warnings.append(rel)
                else:
                    sent_keys.add(rel.casefold())
                    if rel.casefold() in peer:
                        if source_state != peer[rel.casefold()][1]:
                            raise ValueError("目的地在清單產生後改變：%s" % rel)
                _reject_links(target)
                if target.resolve() == Path(args.zip_path).resolve():
                    raise ValueError("ZIP 位置與目的地檔案重疊")
                if target.exists() and not target.is_file():
                    raise ValueError("目的地檔案被資料夾佔用：%s" % target)
                if any(p.exists() and not p.is_dir() for p in target.parents):
                    raise ValueError("目的地資料夾被檔案佔用：%s" % target)
                planned_state[target] = None if conflict else source_state
                operations.append((name, target, conflict, rel))
            planned = {}
            for _, target, _, _ in operations:
                key = str(target).casefold()
                if key in planned:
                    raise ValueError("多個檔案指向同一目的地：%s" % target)
                planned[key] = target
            for target in planned.values():
                if any(str(parent).casefold() in planned for parent in target.parents):
                    raise ValueError("同一目的地同時是檔案和資料夾：%s" % target)
            removed = []
            deleted = manifest.get("已刪除", {})
            if args.apply_deletions:
                for name in deleted:
                    if name.casefold() in sent_keys or name.startswith("_skill累積/") or any(_excluded(p) for p in name.split("/")):
                        warnings.append(name)
                        continue
                    target = dest.joinpath(*PurePosixPath(name).parts)
                    _reject_links(target)
                    meta = deleted.get(name) if isinstance(deleted, dict) else None
                    if target.exists() and target.is_file() and isinstance(meta, dict) and _metadata(target) == meta:
                        if target.resolve() == Path(args.zip_path).resolve():
                            raise ValueError("ZIP 位置與刪除路徑重疊")
                        planned_state[target] = meta
                        removed.append(target)
                    elif target.exists():
                        warnings.append(name)
            # 指標最後套用。
            pending = []
            for item in operations:
                name, target, conflict, rel = item
                if not conflict and rel in ("目前作業.json", "法規作業.json"):
                    value = json.loads(z.read(name).decode("utf-8"))
                    field = "目前作業" if rel == "目前作業.json" else "目前法規作業"
                    folder = value.get(field, "")
                    if not isinstance(folder, str) or not _safe(folder) or "/" in folder:
                        warnings.append(rel)
                        continue
                    output = dest / folder
                    if not output.is_dir() and not any(t.is_relative_to(output) for _, t, _, _ in operations):
                        warnings.append(rel)
                        continue
                pending.append(item)
            operations = sorted(pending, key=lambda x: x[3] in MARKERS)
            if not dest.exists():
                dest.mkdir(parents=True)
                dest_created = True
            stage = Path(tempfile.mkdtemp(prefix=".搬移暫存_" + timestamp + "_", dir=dest))
            staged = []
            for index, (name, target, conflict, rel) in enumerate(operations):
                file = stage / ("new_%d" % index)
                with z.open(name) as source, open(file, "wb") as output:
                    shutil.copyfileobj(source, output, 1024 * 1024)
                staged.append((file, target, conflict, rel))
            def make_dirs(folder):
                missing = []
                while not folder.exists():
                    missing.append(folder)
                    folder = folder.parent
                for item in reversed(missing):
                    item.mkdir()
                    created_dirs.append(item)
            def backup(target):
                _reject_links(target)
                expected = planned_state[target]
                actual = _metadata(target) if target.is_file() else None
                if actual != expected or (target.exists() and not target.is_file()):
                    raise ValueError("%s 在搬移期間被改過，請重跑" % target)
                if target.exists():
                    saved = stage / ("old_%d" % len(backups))
                    os.replace(target, saved)
                    backups.append((saved, target))
            for target in removed:
                backup(target)
            for file, target, conflict, rel in staged:
                make_dirs(target.parent)
                backup(target)
                os.replace(file, target)
                placed.append(target)
            # 基準同樣納入回滾。
            paths, _, _ = _files(dest)
            current = {k: _metadata(v) for k, v in paths.items()}
            if manifest.get("連同累積資料") or any(k.startswith(MEMO) for k in sender):
                paths, _, _ = _files(memo)
                current.update({MEMO + k: _metadata(v) for k, v in paths.items()})
            now, sent = _keyed(current), _keyed(sender)
            conflicts = {rel.casefold() for _, _, conflict, rel in operations if conflict}
            newbase = {name: meta for key, (name, meta) in now.items() if key in sent and sent[key][1] == meta and key not in conflicts}
            newbase = _merge_baseline(old_base, newbase, output_only, prefix, bool(manifest.get("連同累積資料")))
            baseline = dest / BASELINE
            planned_state[baseline] = baseline_before
            backup(baseline)
            file = stage / "new_baseline"
            record = {"格式版本": 1, "檔案": newbase, "最後套用ID": manifest.get("搬移ID")}
            for key in ("最後打包ID", "打包前基準"):
                if old_record and key in old_record:
                    record[key] = old_record[key]
            file.write_text(json.dumps(record, ensure_ascii=False, indent=2), encoding="utf-8")
            os.replace(file, baseline)
            placed.append(baseline)
            if deleted and not args.apply_deletions:
                report = dest / ("搬移_來源已刪除_%s_%s.json" % (timestamp, uuid.uuid4().hex[:8]))
                file = stage / "new_report"
                file.write_text(json.dumps(deleted, ensure_ascii=False, indent=2), encoding="utf-8")
                os.replace(file, report)
                placed.append(report)
            for target in removed:
                parent = target.parent
                while parent != dest and parent.is_relative_to(dest):
                    try:
                        parent.rmdir()
                    except OSError:
                        break
                    parent = parent.parent
            committed = True
            cleanup_note = ""
            try:
                shutil.rmtree(stage)
                stage = None
            except OSError:
                cleanup_note = "；警告：暫存資料夾 %s 沒清乾淨，可以手動刪" % stage
            note = "；警告：%s" % "、".join(warnings[:20]) if warnings else ""
            if deleted and not args.apply_deletions:
                note += "；來源刪了 %d 個檔，這裡沒刪；清單：%s" % (len(deleted), report)
            if not args.apply_memo and any(n.startswith(MEMO) for n in manifest["檔案"]):
                note += "；累積資料未套用"
            note += cleanup_note
            print("解開工作區：套用 %d 個檔，刪除 %d 個；目的地：%s%s" % (len(operations), len(removed), dest, note))
            return 0
    except (OSError, ValueError, KeyError, TypeError, RuntimeError, zipfile.BadZipFile, zlib.error, AttributeError) as exc:
        if committed:
            print("解開工作區：已套用；警告：暫存資料夾 %s 沒清乾淨，可以手動刪" % stage)
            return 0
        rollback_errors = []
        for target in reversed(placed):
            try:
                target.unlink(missing_ok=True)
            except OSError as error:
                rollback_errors.append(str(error))
        for saved, target in reversed(backups):
            try:
                target.parent.mkdir(parents=True, exist_ok=True)
                os.replace(saved, target)
            except OSError as error:
                rollback_errors.append(str(error))
        for folder in reversed(created_dirs):
            try:
                folder.rmdir()
            except OSError:
                pass
        if stage and not rollback_errors:
            shutil.rmtree(stage, ignore_errors=True)
        if dest_created:
            try:
                dest.rmdir()
            except OSError:
                pass
        print("解開工作區失敗：%s%s" % (str(exc).replace("\n", " "), "；回滾失敗，備份保留：%s" % stage if rollback_errors else ""))
        return 1


def verify(args, settings):
    try:
        target = Path(args.target)
        if target.is_dir():
            if not args.manifest:
                raise ValueError("資料夾核對需要 --清單")
            manifest = _read_manifest(args.manifest)
            scope = None
            if manifest.get("模式") == "只要產出":
                prefixes = {k.split("/", 1)[0] + "/" for k in manifest["全部檔案"] if "/" in k and not k.startswith(MEMO)}
                scope = lambda k: k in MARKERS or any(k.startswith(p) for p in prefixes)
            paths, skipped, skipped_dirs = _files(target, scope)
            actual = {k: _metadata(v) for k, v in paths.items()}
            expected = manifest["全部檔案"]
            if manifest.get("連同累積資料") or any(k.startswith(MEMO) for k in expected):
                paths, memo_skipped, memo_dirs = _files(_memo_dir())
                skipped += memo_skipped
                skipped_dirs += memo_dirs
                actual.update({MEMO + k: _metadata(v) for k, v in paths.items()})
        else:
            skipped = 0
            skipped_dirs = 0
            with zipfile.ZipFile(target) as z:
                embedded = _validate(z)
                manifest = _read_manifest(args.manifest) if args.manifest else embedded
                actual = embedded["檔案"]
                expected = manifest["檔案"]
        actual, expected = _keyed(actual), _keyed(expected)
        same = [k for k in expected.keys() & actual.keys() if expected[k][1] == actual[k][1]]
        different = sorted(expected[k][0] for k in expected.keys() & actual.keys() if expected[k][1] != actual[k][1])
        missing = sorted(expected[k][0] for k in expected.keys() - actual.keys())
        extra = sorted(actual[k][0] for k in actual.keys() - expected.keys())
        print("核對工作區：相符 %d，內容不同 %d，少了 %d，多出 %d；不同：%s；少了：%s；略過疑似帳密檔 %d 個、資料夾 %d 個（不搬）" %
              (len(same), len(different), len(missing), len(extra), "、".join(different[:20]) or "無", "、".join(missing[:20]) or "無", skipped, skipped_dirs))
        return int(bool(different or missing or extra))
    except (OSError, ValueError, KeyError, TypeError, RuntimeError, zipfile.BadZipFile, AttributeError, zlib.error) as exc:
        print("核對工作區失敗：%s" % exc)
        return 1
