# -*- coding: utf-8 -*-
"""分析單位基本資料（v1.12.0）：單位類型、業務範圍、追蹤主題的選項，以及「單位建議」——AI 讀現行規章提建議值。

設定.html「分析單位基本資料」三格：
    單位類型   下拉選單（以銀行單位為主），選不到就選「其他」自己填      → 設定鍵「法規機構類型」
    業務範圍   分組勾選，可以再自己加                                   → 設定鍵「法規業務範圍」（頓號、逗號分隔的字串）
    追蹤主題   分組勾選，可以再自己加；勾了某些業務會提示相關主題       → 設定鍵「法規追蹤主題」
存的仍是字串，法規更新檢視（law_impact.default_config）照舊讀；勾選照選項順序存，同一組勾法字串不變，
法規判斷的指紋就不會因為勾的先後不同而變。

「單位建議」（run_all.py 單位建議）：
    第一次跑    在工作區 單位資料建議/ 寫 先讀我.md、內規全文索引、AI單位資料建議.json（空白範本）
    AI 填好再跑  驗：值要在選項裡（或寫「其他：…」），每一項至少一個依據（規章、段次、原文），原文要真的在那一段
                過了寫進 設定.html 的「單位資料建議」，人打開設定頁按「採用」再存檔才生效（不自動改設定）
"""
import datetime
import io
import json
import os
import re
import sys
import unicodedata

HERE = os.path.dirname(os.path.abspath(__file__))
for path in (HERE, os.path.join(HERE, "regdiff")):
    if path not in sys.path:
        sys.path.insert(0, path)

UNIT_KEY, SCOPE_KEY, THEME_KEY = "法規機構類型", "法規業務範圍", "法規追蹤主題"
OTHER = "其他"
FOLDER = "單位資料建議"
TABLE = "AI單位資料建議.json"
README = "先讀我.md"
SUGGESTION_KEY = "單位資料建議"          # 設定.html 資料區塊最上層的鍵（不放在「設定」裡）

# 選項（設定.html 的 PROFILE_OPTIONS 跟這裡一字不差，test_v1120 會比）
OPTIONS = {
    "單位類型": [
        ["機構", ["銀行（全行）", "金控", "本國銀行兼營保險代理人"]],
        ["業務單位", ["個人金融", "企業金融", "財富管理", "信託", "數位金融"]],
        ["管理單位", ["風險管理", "法務法遵", "人資", "資安", "內部稽核"]],
    ],
    "業務範圍": [
        ["存款與授信", ["存款", "消費金融", "信用卡", "房屋貸款", "企業授信", "貿易融資"]],
        ["財富管理與保險", ["基金", "海外債券與結構型商品", "人身保險代理", "財產保險代理", "投資型保險",
                       "保險金信託與安養信託"]],
        ["通路與服務", ["分行臨櫃", "電話行銷", "網路銀行與行動銀行", "網路投保與行動投保", "銷售予高齡客戶"]],
        ["其他業務", ["外匯", "電子支付", "合作推廣與共同行銷", "客戶資料共享", "作業委外"]],
    ],
    "追蹤主題": [
        ["常用", ["保險", "洗錢", "個人資料", "資訊安全"]],
        ["消費者與業務", ["金融消費者保護與公平待客", "廣告與招攬", "高齡及弱勢客戶", "信託", "外匯"]],
        ["管理", ["公司治理與內部控制", "勞動法規", "作業委外", "永續（ESG）"]],
    ],
}
# 勾了這項業務，提示可以加的主題（設定頁「依業務範圍建議加」）
THEME_LINKS = {
    "人身保險代理": ["保險"], "財產保險代理": ["保險"], "投資型保險": ["保險"],
    "電話行銷": ["廣告與招攬"], "網路投保與行動投保": ["廣告與招攬", "資訊安全"],
    "網路銀行與行動銀行": ["資訊安全"], "電子支付": ["資訊安全", "洗錢"],
    "銷售予高齡客戶": ["高齡及弱勢客戶"], "保險金信託與安養信託": ["信託"], "外匯": ["外匯", "洗錢"],
    "作業委外": ["作業委外"], "客戶資料共享": ["個人資料"], "合作推廣與共同行銷": ["個人資料"],
    "存款": ["洗錢"], "基金": ["金融消費者保護與公平待客"], "海外債券與結構型商品": ["金融消費者保護與公平待客"],
}
FIELDS = (("單位類型", UNIT_KEY, False), ("業務範圍", SCOPE_KEY, True), ("追蹤主題", THEME_KEY, True))


class ProfileError(Exception):
    pass


def choices(field):
    return [item for _group, items in OPTIONS[field] for item in items]


def split_values(text):
    return [x.strip() for x in re.split(r"[,，、;；\n]", text or "") if x.strip()]


def join_values(field, values):
    """勾選的值照選項順序排，自己加的（不在選項裡）照原順序放後面：同一組勾法存成同一個字串。"""
    order = choices(field)
    values = list(dict.fromkeys(v.strip() for v in values if v and v.strip()))
    known = [v for v in order if v in values]
    return ",".join(known + [v for v in values if v not in order])


def _norm(text):
    return re.sub(r"\s+", "", unicodedata.normalize("NFKC", str(text or "")))


# ---------------------------------------------------------------------------
# 打包
# ---------------------------------------------------------------------------

def folder(root):
    return os.path.join(root, FOLDER)


def _books(root):
    import law_impact as li
    try:
        return li.books(root)
    except li.ImpactError as exc:
        raise ProfileError(str(exc))


def _template():
    return {"單位類型": {"值": "", "依據": []},
            "業務範圍": [{"值": "", "依據": []}],
            "追蹤主題": [{"值": "", "依據": []}],
            "說明": ""}


def pack(root, settings=None):
    """寫 單位資料建議/ 的 先讀我.md、內規全文、AI單位資料建議.json（空白範本；已經有就不動）。回傳資料夾。"""
    settings = settings or {}
    out = folder(root)
    os.makedirs(out, exist_ok=True)
    books = _books(root)
    if not books:
        raise ProfileError("匯入/1_現行文件/ 還沒有規章檔：AI 要讀現行規章才能提建議")
    for name in os.listdir(out):
        if name.startswith("內規全文_") and name.endswith(".md"):
            os.remove(os.path.join(out, name))
    for book in books:
        lines = ["# " + book["title"], "（段次是程式讀出來的段落序號，不是 Word 頁碼）", ""]
        lines += ["[段%d] %s %s" % (i + 1, book["labels"][i], text) for i, text in enumerate(book["paragraphs"])]
        with io.open(os.path.join(out, "內規全文_%s.md" % book["title"]), "w", encoding="utf-8") as f:
            f.write("\n".join(lines) + "\n")
    table = os.path.join(out, TABLE)
    if not os.path.isfile(table):
        with io.open(table, "w", encoding="utf-8") as f:
            json.dump(_template(), f, ensure_ascii=False, indent=2)
    lines = ["# 單位資料建議：讀現行規章，替設定頁「分析單位基本資料」三格提建議值", "",
             "這一步由 AI 做，不用人填。結果只是建議：寫進設定.html 後，要人按「採用」再存檔才生效。", "",
             "讀同一個資料夾的 `內規全文_*.md`（%s），判斷這一批規章是哪一種單位在用、辦哪些業務、"
             "法規更新要追哪些主題，填 `%s`：" % ("、".join("`內規全文_%s.md`" % b["title"] for b in books), TABLE), "",
             "- `單位類型`：一個值。`業務範圍`、`追蹤主題`：可以好幾個，一個值一筆。",
             "- 值要從下面的選項挑；選項真的沒有，寫「其他：…」（例：其他：證券業務）。",
             "- 每一個值至少一個「依據」：`{\"規章\": \"規章名（內規全文檔名去掉 內規全文_）\", \"段次\": 12, "
             "\"原文\": \"從那一段逐字抄的一小句\"}`。原文要真的在那一段裡，程式會核對。",
             "- **不要只看手冊名稱就推測**（手冊名寫「保險代理業務」不代表單位類型就是保代）；看不出來就不要填那一項，"
             "在「說明」寫缺什麼資料。寧可少填，不要猜。",
             "- 「說明」一句話講整體判斷（選填）。", "",
             "目前設定頁的值（空白＝還沒填）：",
             "- 單位類型：%s" % (settings.get(UNIT_KEY) or "（空白）"),
             "- 業務範圍：%s" % (settings.get(SCOPE_KEY) or "（空白）"),
             "- 追蹤主題：%s" % (settings.get(THEME_KEY) or "（空白）"), "", "## 選項", ""]
    for field, _key, _many in FIELDS:
        lines.append("### " + field)
        for group, items in OPTIONS[field]:
            lines.append("- %s：%s" % (group, "、".join(items)))
        lines.append("")
    lines += ["## 填好之後", "", "回到 skill 資料夾跑：", "",
              "    python scripts/run_all.py 單位建議 --workspace \"%s\"" % root, "",
              "程式核對過就寫進設定.html；有錯會列出來，改好再跑一次。"]
    with io.open(os.path.join(out, README), "w", encoding="utf-8") as f:
        f.write("\n".join(lines) + "\n")
    return out


# ---------------------------------------------------------------------------
# 驗證與寫進設定頁
# ---------------------------------------------------------------------------

def read_table(root):
    path = os.path.join(folder(root), TABLE)
    if not os.path.isfile(path):
        return None
    try:
        with io.open(path, encoding="utf-8-sig") as f:
            value = json.load(f)
    except (OSError, ValueError) as exc:
        raise ProfileError("%s 讀不出來（%s）：要是 JSON 格式" % (TABLE, exc))
    if not isinstance(value, dict):
        raise ProfileError("%s 要是一個物件（{…}）" % TABLE)
    return value


def filled(value):
    """AI 填了沒：三項裡至少一個值。"""
    if not isinstance(value, dict):
        return False
    unit = value.get("單位類型") or {}
    many = [x for f in ("業務範圍", "追蹤主題") for x in (value.get(f) or []) if isinstance(x, dict)]
    return bool((isinstance(unit, dict) and (unit.get("值") or "").strip())
                or any((x.get("值") or "").strip() for x in many))


def _check_item(field, item, titles, errors):
    """一個建議值：值合法、依據對得上。回傳整理好的 {值, 依據}；不合格回 None（錯誤加進 errors）。"""
    if not isinstance(item, dict):
        errors.append("%s：每一筆要是 {\"值\": …, \"依據\": […]}" % field)
        return None
    value = (item.get("值") or "").strip()
    if not value:
        return None
    tag = "%s「%s」" % (field, value)
    if value not in choices(field):
        if not value.startswith(OTHER + "：") or not value[len(OTHER) + 1:].strip():
            errors.append("%s：不在選項裡；選項沒有就寫「其他：…」" % tag)
            return None
        value = value[len(OTHER) + 1:].strip()
    basis = item.get("依據")
    if not isinstance(basis, list) or not basis:
        errors.append("%s：至少要一個依據（規章、段次、原文）" % tag)
        return None
    good = []
    for b in basis:
        if not isinstance(b, dict):
            errors.append("%s：依據要是 {\"規章\", \"段次\", \"原文\"}" % tag)
            continue
        title, line, quote = str(b.get("規章") or "").strip(), str(b.get("段次") or "").strip(), str(b.get("原文") or "").strip()
        book = titles.get(title)
        if not book:
            errors.append("%s：依據的規章「%s」不在這一批（寫 內規全文_ 後面那個名稱）" % (tag, title))
            continue
        if not line.isdigit() or not 1 <= int(line) <= len(book["paragraphs"]):
            errors.append("%s：%s 沒有段次「%s」" % (tag, title, line))
            continue
        if not quote or _norm(quote) not in _norm(book["paragraphs"][int(line) - 1]):
            errors.append("%s：原文「%s」不在 %s 段%s 裡（要逐字抄）" % (tag, quote[:30], title, line))
            continue
        good.append({"規章": title, "段次": int(line), "原文": quote})
    if not good:
        return None
    return {"值": value, "依據": good}


def validate(root, value):
    """回傳 (錯誤 list, 整理好的建議 dict)。"""
    titles = dict((b["title"], b) for b in _books(root))
    errors = []
    unit = value.get("單位類型")
    if isinstance(unit, list):
        errors.append("單位類型只能一個值")
        unit = unit[0] if unit else {}
    out = {"單位類型": _check_item("單位類型", unit or {}, titles, errors)}
    for field in ("業務範圍", "追蹤主題"):
        items = value.get(field) or []
        if not isinstance(items, list):
            errors.append("%s 要是一串 [{…}, {…}]" % field)
            items = []
        checked = [x for x in (_check_item(field, item, titles, errors) for item in items) if x]
        seen, uniq = set(), []
        for x in checked:
            if x["值"] not in seen:
                seen.add(x["值"])
                uniq.append(x)
        out[field] = uniq
    if not out["單位類型"] and not out["業務範圍"] and not out["追蹤主題"]:
        errors.append("三項都沒有可以採用的建議值")
    out["說明"] = str(value.get("說明") or "").strip()
    return errors, out


_DATA_RE = re.compile(r'(<script\b[^>]*\bid="reg-data"[^>]*>)(.*?)(</script>)', re.S)


def write_suggestion(suggestion, root, html_path=None):
    """寫進 設定.html 資料區塊的「單位資料建議」（不動「設定」本身）。回傳設定頁路徑。"""
    from _common import tw_now, tw_today
    import _common
    path = html_path or _common.CONFIG_HTML
    value = dict(suggestion, 產生時間=tw_now().strftime("%Y-%m-%d %H:%M"),
                 工作區=os.path.basename(os.path.normpath(root)))
    try:
        _common.write_config_key(SUGGESTION_KEY, value, path, time_fields=("產生時間",))
    except ValueError as exc:
        raise ProfileError("設定.html 的設定資料讀不出來（%s）：用瀏覽器打開重新存檔" % exc)
    return path


def summary_lines(suggestion):
    lines = []
    unit = suggestion.get("單位類型")
    lines.append("單位類型：%s" % (unit["值"] if unit else "（沒有建議）"))
    for field in ("業務範圍", "追蹤主題"):
        lines.append("%s：%s" % (field, "、".join(x["值"] for x in suggestion.get(field) or []) or "（沒有建議）"))
    return lines


def run(root, settings, redo=False, say=print):
    """單位建議：沒填就打包、停下來等 AI；填好就驗、寫進設定頁。回傳 0／1。"""
    table = os.path.join(folder(root), TABLE)
    if redo and os.path.isfile(table):
        os.remove(table)
    value = read_table(root)
    if value is None or not filled(value):
        out = pack(root, settings)
        say("單位建議：資料已打包在 %s" % out)
        say("下一步（AI 做，不用人填）：AI 讀 %s 的 %s，填好 %s 再跑一次「單位建議」" % (FOLDER, README, TABLE))
        return 0
    errors, suggestion = validate(root, value)
    if errors:
        say("[中止] %s 有 %d 個問題（改好再跑「單位建議」）：" % (TABLE, len(errors)))
        for line in errors:
            say("  " + line)
        return 1
    path = write_suggestion(suggestion, root)
    say("單位建議：已寫進 %s" % path)
    for line in summary_lines(suggestion):
        say("  " + line)
    say("下一步（人做）：跟 AI 說「打開設定」→「分析單位基本資料」，看 AI 建議與依據，"
        "按「採用」再存檔才生效（設定頁改了會自動存）。採用後下一次法規更新檢視會重判一次法規適用。")
    return 0
