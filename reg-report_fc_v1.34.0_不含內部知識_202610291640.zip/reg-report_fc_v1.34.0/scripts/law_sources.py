# -*- coding: utf-8 -*-
"""法規證據介面：MCP、官方網頁、官方資料檔、本機文件使用相同事件格式。

只蒐集證據，不把查不到、解析失敗或匯入文件推論成「沒有修法」。
"""
import datetime as dt
import hashlib
from html.parser import HTMLParser
import json
from pathlib import Path
import re
import subprocess
import sys
import urllib.parse
import urllib.request
import urllib.error
import xml.etree.ElementTree as ET
import zipfile
import io
import queue
import threading
import ssl
import socket
import http.client
import importlib.util
import os

MAX_BYTES = 40 * 1024 * 1024
STATUSES = {"現行", "草案", "已公布未施行", "廢止", "待確認"}


class SourceError(ValueError):
    pass


def stamp():
    from _common import tw_now
    return tw_now().isoformat(timespec="seconds")


def digest(value):
    raw = value if isinstance(value, bytes) else json.dumps(value, ensure_ascii=False, sort_keys=True).encode("utf-8")
    return hashlib.sha256(raw).hexdigest()


def date(value, optional=True):
    text = re.sub(r"\s+", "", str(value or ""))
    if not text and optional:
        return ""
    match = re.fullmatch(r"(?:(?:中華)?民國)?\s*(\d{2,4})[-/.年]\s*(\d{1,2})[-/.月]\s*(\d{1,2})日?", text)
    if not match:
        # 官方資料也使用 YYYYMMDD / 民國 YYYMMDD。
        match = re.fullmatch(r"(\d{3,4})(\d{2})(\d{2})", text)
    if not match:
        raise SourceError("日期必須是 YYYY-MM-DD 或民國年月日：%s" % text)
    year, month, day = map(int, match.groups())
    if year < 1911:
        year += 1911
    try:
        return dt.date(year, month, day).isoformat()
    except ValueError as exc:
        raise SourceError("無效日期：%s" % text) from exc


def official(url):
    parsed = urllib.parse.urlsplit(str(url or ""))
    host = (parsed.hostname or "").lower()
    # v1.23.0：加銀行公會、壽險公會、產險公會（references/法規來源地圖.md 列的來源）。以前不認，公會自律規範
    # 判適用也給不了 7 分，錯誤訊息叫 AI 改給〔待確認適用〕，又被「適用不能用待確認適用」擋，兩條互卡
    return parsed.scheme in ("https", "http") and (host.endswith(".gov.tw") or host in
            {"law.lia-roc.org.tw", "www.lia-roc.org.tw", "lia-roc.org.tw", "www.ciaa.org.tw", "ciaa.org.tw",
             "www.ba.org.tw", "ba.org.tw", "www.nlia.org.tw", "nlia.org.tw"})


_DRAFT_DONE_RE = re.compile(r"同意備查|准予備查|准予核備|核定|核准|洽悉")


def draft_status(title):
    """公告標題的效力：有「草案」而且沒有「同意備查」「核定」這類已經定案的字，才是草案（v1.23.0）。
    「所報…修正草案一案，請依說明二辦理後同意備查」已經備查，以前被當草案：最高只能 5 分，也不記進版本表。"""
    title = title or ""
    return "草案" if "草案" in title and not _DRAFT_DONE_RE.search(title) else "待確認"


def _ipv4_first(address, timeout=None, source_address=None, *args, **kwargs):
    """連線先試 IPv4，IPv6 排後面而且只等幾秒（v1.11.0）。

    有些電腦的 IPv6 連不出去（實測連 law.fsc.gov.tw 的 IPv6 要等 21 秒才逾時），Python 預設先試 IPv6、
    等到逾時才換 IPv4，每抓一頁白等 20 秒、一輪體檢多等約 150 秒。台灣官方網站都有 IPv4。
    抓到的內容跟以前一模一樣，只是換連線順序。"""
    host, port = address
    infos = socket.getaddrinfo(host, port, 0, socket.SOCK_STREAM)
    infos.sort(key=lambda info: 0 if info[0] == socket.AF_INET else 1)
    real_timeout = timeout if isinstance(timeout, (int, float)) else None
    last = None
    for number, (family, kind, proto, _name, target) in enumerate(infos):
        sock = socket.socket(family, kind, proto)
        try:
            is_last = number == len(infos) - 1
            # 不是最後一個位址：最多等 5 秒就換下一個（IPv6 不通不要卡 20 秒）
            sock.settimeout(real_timeout if is_last or real_timeout is None else min(real_timeout, 5))
            if source_address:
                sock.bind(source_address)
            sock.connect(target)
            sock.settimeout(real_timeout)
            return sock
        except OSError as exc:
            last = exc
            sock.close()
    raise last or OSError("連不上 %s" % host)


class _HTTPConnection(http.client.HTTPConnection):
    def __init__(self, *args, **kwargs):
        http.client.HTTPConnection.__init__(self, *args, **kwargs)
        self._create_connection = _ipv4_first


class _HTTPSConnection(http.client.HTTPSConnection):
    def __init__(self, *args, **kwargs):
        http.client.HTTPSConnection.__init__(self, *args, **kwargs)
        self._create_connection = _ipv4_first


class _HTTPHandler(urllib.request.HTTPHandler):
    def http_open(self, req):
        return self.do_open(_HTTPConnection, req)


class _HTTPSHandler(urllib.request.HTTPSHandler):
    def https_open(self, req):
        return self.do_open(_HTTPSConnection, req, context=self._context)


def _ssl_context():
    try:
        import truststore
        context = truststore.SSLContext(ssl.PROTOCOL_TLS_CLIENT)
    except ImportError:
        context = ssl.create_default_context()
    # 只放寬 RFC 5280 嚴格格式檢查：部分政府憑證缺 Subject Key Identifier。
    # 憑證鏈、到期與主機名稱仍照常驗證；不改其他驗證旗標。
    try:
        context.verify_flags &= ~getattr(ssl, "VERIFY_X509_STRICT", 0)
    except Exception:
        # 系統信任庫的 context 可能不支援讀寫 verify_flags。
        pass
    return context


def fetch(url):
    # 測試、離線環境：REG_NO_NETWORK=1 時不連網，來源記成失敗（不等於沒有修法）
    if os.environ.get("REG_NO_NETWORK") == "1":
        raise SourceError("這個環境設定不連網（REG_NO_NETWORK=1），沒有自動讀取：%s" % url)
    if not official(url):
        raise SourceError("自動讀取只接受政府及已列入的公會來源：%s" % url)
    # 附件網址常帶中文檔名（…/使用手冊20171020.pdf）：urllib 只收 ASCII，以前直接 'ascii' codec 錯誤、附件讀不到
    url = urllib.parse.quote(url, safe=":/?&=%#+;,@!$'()*~[]")

    class OfficialRedirect(urllib.request.HTTPRedirectHandler):
        def redirect_request(self, req, fp, code, msg, headers, newurl):
            if not official(newurl):
                raise SourceError("來源轉址到未支援網域：%s" % newurl)
            return super().redirect_request(req, fp, code, msg, headers, newurl)

    request = urllib.request.Request(url, headers={"User-Agent": "reg-report/1.3.0 (legal-source-reader)"})
    context = _ssl_context()
    opener = urllib.request.build_opener(OfficialRedirect(), _HTTPHandler(), _HTTPSHandler(context=context))
    try:
        with opener.open(request, timeout=20) as response:
            raw = response.read(MAX_BYTES + 1)
    except (ssl.SSLCertVerificationError, urllib.error.URLError) as exc:
        reason = exc.reason if isinstance(exc, urllib.error.URLError) else exc
        if isinstance(reason, ssl.SSLCertVerificationError):
            raise SourceError("官網憑證驗證失敗：%s；這不是法規查不到，請改用瀏覽器開官網核對，或把官方下載檔放進規範資料庫再查"
                              % (getattr(reason, "verify_message", None) or str(reason))) from exc
        raise SourceError("官網讀取失敗：%s" % reason) from exc
    if len(raw) > MAX_BYTES:
        raise SourceError("來源超過 40 MB，請下載後分檔匯入")
    return raw


_SITE_LINK_WORDS = ("使用手冊", "操作手冊", "網站導覽", "隱私權", "資訊安全政策", "政府網站資料開放", "無障礙", "常見問題")
_SITE_LINK_PATHS = ("/usemanual/", "/manual/", "/sitemap", "/privacy", "/accessibility")


def site_link(url, label=""):
    """公告頁上的網站共用連結（頁首頁尾的使用手冊、網站導覽、隱私權政策…），不是這一則公告的附件。"""
    path = urllib.parse.unquote(urllib.parse.urlsplit(url).path).lower()
    text = (label or "") + path
    return any(word in text for word in _SITE_LINK_WORDS) or any(part in path for part in _SITE_LINK_PATHS)


class Page(HTMLParser):
    """保留段落、表格列、連結；不把 script/style 當法規原文。"""
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.parts, self.links, self.rows = [], [], []
        self.ignore = 0
        self.anchor = None
        self.row = None

    def handle_starttag(self, tag, attrs):
        attrs = dict(attrs)
        if tag in ("script", "style"):
            self.ignore += 1
        if self.ignore:
            return
        if tag in ("p", "div", "br", "tr", "li", "h1", "h2", "h3"):
            self.parts.append("\n")
        if tag == "tr":
            self.row = {"parts": [], "links": []}
        if tag == "a":
            self.anchor = [attrs.get("href", ""), []]

    def handle_endtag(self, tag):
        if tag in ("script", "style"):
            self.ignore = max(0, self.ignore - 1)
            return
        if self.ignore:
            return
        if tag == "a" and self.anchor:
            link = (self.anchor[0], "".join(self.anchor[1]).strip())
            self.links.append(link)
            if self.row is not None:
                self.row["links"].append(link)
            self.anchor = None
        if tag == "tr" and self.row is not None:
            self.rows.append(self.row)
            self.row = None
        if tag in ("p", "div", "tr", "li"):
            self.parts.append("\n")

    def handle_data(self, text):
        if not self.ignore:
            self.parts.append(text)
            if self.anchor:
                self.anchor[1].append(text)
            if self.row is not None:
                self.row["parts"].append(text)

    @property
    def text(self):
        return "\n".join(line.strip() for line in "".join(self.parts).splitlines() if line.strip())


class MojPage(HTMLParser):
    """全國法規資料庫的 col-no／col-data 結構，不把選單與熱門詞當條文。"""
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.depth, self.active, self.parts = 0, {}, {}
        self.number, self.articles, self.name, self.in_name = "", [], "", False

    def handle_starttag(self, tag, attrs):
        attrs = dict(attrs)
        if tag == "a" and attrs.get("id") == "hlLawName":
            self.in_name = True
        if tag == "div":
            self.depth += 1
            classes = attrs.get("class", "").split()
            field = "number" if "col-no" in classes else "content" if "col-data" in classes else ""
            if field:
                self.active[field] = self.depth
                self.parts[field] = []
        if tag in ("br", "p", "li") and "content" in self.active:
            self.parts["content"].append("\n")

    def handle_endtag(self, tag):
        if tag == "a":
            self.in_name = False
        if tag == "div":
            for field in list(self.active):
                if self.active[field] == self.depth:
                    value = "".join(self.parts[field]).strip()
                    if field == "number":
                        self.number = value
                    elif self.number and "條" in self.number and value:
                        self.articles.append({"article_no": self.number, "new_text": value})
                    del self.active[field]
            self.depth = max(0, self.depth - 1)

    def handle_data(self, text):
        if self.in_name:
            self.name += text.strip()
        for field in self.active:
            self.parts[field].append(text)


def decode(raw):
    for encoding in ("utf-8-sig", "cp950"):
        try:
            return raw.decode(encoding)
        except UnicodeDecodeError:
            pass
    raise SourceError("資料不是 UTF-8 或 Big5，請轉碼後匯入")


def detect_format(raw, url, configured=""):
    if configured:
        return configured.lower()
    suffix = Path(urllib.parse.urlsplit(url).path).suffix.lower()
    if suffix == ".docx":
        return suffix
    if raw.startswith(b"PK\x03\x04"):
        return ".zip"
    if raw.startswith(b"%PDF"):
        return ".pdf"
    head = raw.lstrip(b"\xef\xbb\xbf \r\n\t")
    if head.startswith((b"{", b"[")):
        return ".json"
    if suffix in (".json", ".xml", ".zip", ".pdf"):
        return suffix
    if head.startswith(b"<?xml"):
        return ".xml"
    return ".html"


# 公告網頁上會一直變、跟法規內容無關的字（v1.8.1）：行政院公報資訊網「分享至：」前那一行純數字是瀏覽次數
# （昨天 119100、今天 120300），一變法規的指紋就跟著變、判過的答案全部對不上
_VOLATILE = [
    re.compile(r"\n\s*\d+\s*\n(?=\s*分享至)"),
    re.compile(r"(?:瀏覽人次|瀏覽次數|點閱次數|點閱人次|點閱數|瀏覽數|人氣)\s*[:：]?\s*[\d,，]+"),
]


def strip_volatile(text):
    """拿掉公告網頁上會一直變的數字（瀏覽、點閱次數）；其餘一字不動。"""
    for pattern in _VOLATILE:
        text = pattern.sub("\n" if pattern.pattern.startswith("\\n") else "", text)
    return text


def normalize(record, source, evidence):
    if not isinstance(record, dict):
        raise SourceError("每個法規事件必須是物件")
    name = str(record.get("law_name") or record.get("LawName") or "").strip()
    text = strip_volatile(str(record.get("new_text") or record.get("LawContent") or "")).strip()
    if not name or not text:
        raise SourceError("法規事件缺 law_name 或 new_text")
    out = {k: str(record.get(k) or "").strip() for k in
           ("article_no", "old_text", "source_url", "old_source_url", "effective_note", "version", "notes", "change_type")}
    out.update(law_name=name, new_text=text, event_date=date(record.get("event_date") or record.get("LawModifiedDate")),
               effective_date=date(record.get("effective_date") or record.get("LawEffectiveDate")),
               status=record.get("status") or "待確認", source_kind=source.get("kind", "檔案"),
               source_name=source.get("name", ""), retrieved_at=stamp(), evidence_path=evidence)
    if out["status"] not in STATUSES:
        raise SourceError("不支援的生效狀態：%s" % out["status"])
    if not out["source_url"]:
        out["source_url"] = source.get("official_url") or source.get("url") or ""
    # 不根據網址就宣稱文件的日期或現行效力已獲驗證。
    out["notes"] = "；".join(filter(None, [out["notes"],
        "舊版缺少來源，差異待補" if out["old_text"] and not out["old_source_url"] else "",
        "缺少公布／修正日期" if not out["event_date"] else ""]))
    identity = {k: out[k] for k in ("law_name", "article_no", "event_date", "version", "old_text", "new_text", "source_url")}
    out["id"] = "L" + digest(identity)[:20]
    return out


def _official_law(record):
    articles = record.get("LawArticles") or record.get("法規內容") or []
    if isinstance(articles, dict):
        articles = articles.get("條文") or articles.get("Articles") or []
    if isinstance(articles, dict):
        articles = [articles]
    for article in articles:
        if not isinstance(article, dict):
            continue
        content = article.get("ArticleContent") or article.get("條文內容")
        if content:
            yield {"law_name": record.get("LawName") or record.get("法規名稱"),
                   "article_no": article.get("ArticleNo") or article.get("條號", ""),
                   "new_text": content, "event_date": record.get("LawModifiedDate") or record.get("最新異動日期"),
                   "effective_date": record.get("LawEffectiveDate") or record.get("生效日期"),
                   "effective_note": record.get("LawEffectiveNote") or record.get("生效內容", ""),
                   "source_url": record.get("LawURL") or record.get("法規網址", ""),
                   "status": "廢止" if str(record.get("LawAbandonNote") or record.get("廢止註記") or "").strip() not in
                       ("", "False", "false", "0", "否") else "待確認",
                   "notes": "官方整編資料；整部法規修正日不代表本條有修正，須比對舊版確認"}


# 證據檔的中文欄名（v1.5.0 起 AI 寫證據檔用這一套，跟 AI 表一樣是中文）→ 程式內部用的鍵。英文鍵照樣收
_CHINESE_KEYS = {"法規名稱": "law_name", "條號": "article_no", "公布或修正日": "event_date", "施行日": "effective_date",
                 "施行說明": "effective_note", "效力": "status", "版本": "version", "舊條文": "old_text",
                 "新條文": "new_text", "官方來源": "source_url", "舊版來源": "old_source_url", "註記": "notes",
                 "異動性質": "change_type"}


def _english_keys(record):
    if not isinstance(record, dict):
        return record
    out = dict(record)
    for chinese, english in _CHINESE_KEYS.items():
        if chinese in out and english not in out:
            out[english] = out.pop(chinese)
    return out


def records_from_json(value):
    if isinstance(value, dict) and ("events" in value or "法規異動" in value):
        return [_english_keys(r) for r in value.get("events", value.get("法規異動")) or []]
    laws = value.get("Laws", value.get("法規", [])) if isinstance(value, dict) else value
    if isinstance(laws, dict):
        laws = [laws]
    if isinstance(laws, list):
        result = []
        for law in laws:
            if isinstance(law, dict) and ("LawArticles" in law or "法規內容" in law):
                result.extend(_official_law(law))
            else:
                result.append(law)
        return result
    raise SourceError("JSON 須有 events 或 Laws 陣列")


def _pdf_text_cache(raw):
    import batch
    return os.path.join(batch.cache_dir(), "法規追蹤", "PDF文字", digest(raw) + ".txt")


def _pdf_text(raw):
    """PDF 轉文字（v1.11.0 起照檔案指紋存在 memoization/法規追蹤/PDF文字/，同一個檔只轉一次：
    公告附件以前每一輪重轉 374 頁、約 40 秒）。"""
    path = _pdf_text_cache(raw)
    try:
        with io.open(path, encoding="utf-8") as f:
            return f.read()
    except OSError:
        pass
    try:
        from pypdf import PdfReader
    except ImportError as exc:
        raise SourceError("PDF 需 pypdf；可改匯入已擷取文字及來源的 JSON／Word") from exc
    text = "\n".join(p.extract_text() or "" for p in PdfReader(io.BytesIO(raw)).pages)
    try:
        os.makedirs(os.path.dirname(path), exist_ok=True)
        with io.open(path + ".tmp", "w", encoding="utf-8") as f:
            f.write(text)
        os.replace(path + ".tmp", path)
    except OSError:
        pass
    return text


def records_from_bytes(raw, suffix, source):
    suffix = suffix.lower()
    if suffix == ".zip":
        result = []
        with zipfile.ZipFile(io.BytesIO(raw)) as archive:
            total = 0
            for entry in archive.infolist():
                if Path(entry.filename).suffix.lower() not in (".xml", ".json"):
                    continue
                total += entry.file_size
                if total > MAX_BYTES * 5:
                    raise SourceError("ZIP 解壓資料過大，請分檔匯入")
                result.extend(records_from_bytes(archive.read(entry), Path(entry.filename).suffix, source))
        return result
    if suffix == ".json":
        return records_from_json(json.loads(decode(raw)))
    if suffix == ".xml":
        if b"<!DOCTYPE" in raw.upper() or b"<!ENTITY" in raw.upper():
            raise SourceError("不接受含外部實體的 XML")
        root = ET.fromstring(raw)
        result = []
        for law in root.iter():
            fields = {c.tag.split("}")[-1]: "".join(c.itertext()).strip() for c in law}
            if not (fields.get("LawName") or fields.get("法規名稱")):
                continue
            articles = []
            for item in law.iter():
                bits = {c.tag.split("}")[-1]: "".join(c.itertext()).strip() for c in item}
                if "ArticleContent" in bits or "條文內容" in bits:
                    articles.append(bits)
            fields["LawArticles"] = articles
            result.extend(_official_law(fields))
        return result
    if suffix in (".html", ".htm"):
        content = decode(raw)
        page = Page()
        page.feed(content)
        text = page.text
        # 只擷取有明確欄位標籤的日期；不把頁尾更新時間當修法日期。
        if not source.get("event_date"):
            found = re.search(r"(?:公發布|發布|修正|公布|廢止)日期[：:\s|]*((?:(?:中華)?民國)?\s*\d{2,4}\s*[./年-]\s*\d{1,2}\s*[./月-]\s*\d{1,2}\s*日?)", text)
            if found:
                source = dict(source, event_date=date(found.group(1)))
        moj = MojPage()
        moj.feed(content)
        if moj.name and moj.articles:
            if source.get("law_name") and source["law_name"] != moj.name:
                raise SourceError("指定法規名稱與官網不符：%s／%s" % (source["law_name"], moj.name))
            abolished = bool(re.search(r"廢止日期[：:]", text))
            return [dict(article, law_name=moj.name, event_date=source.get("event_date", ""),
                         status="廢止" if abolished else source.get("status", "待確認"),
                         source_url=source.get("official_url") or source.get("url", ""),
                         notes="官網條文結構擷取；整部修正日不代表本條修正，施行與歷史版本須核對") for article in moj.articles]
    elif suffix == ".pdf":
        text = _pdf_text(raw)
        if len(text.strip()) < 20:
            raise SourceError("PDF 無可擷取文字，請由 AI／OCR 讀取後匯入證據 JSON；不可視為空法規")
    elif suffix == ".docx":
        # 使用暫存檔，既有讀檔器處理追蹤修訂與表格。
        import tempfile
        from _common import read_paragraphs
        with tempfile.TemporaryDirectory(prefix="law-document-") as temp:
            path = Path(temp) / "法規.docx"
            path.write_bytes(raw)
            text = "\n".join(read_paragraphs(str(path)))
    elif suffix in (".txt", ".md"):
        text = decode(raw)
    else:
        raise SourceError("不支援的法規資料格式：%s" % suffix)
    return [{"law_name": source.get("law_name") or source.get("name"), "new_text": text,
             "event_date": source.get("event_date", ""), "status": source.get("status", "待確認"),
             "effective_date": source.get("effective_date", ""), "effective_note": source.get("effective_note", ""),
             "source_url": source.get("official_url") or source.get("url", ""),
             "notes": "整份來源文件，需 AI 核對正文、附件與適用條件；未自動推定修正日期"}]


def mcp_call(config, tool, arguments):
    """獨立 Python 環境跑 MCP SDK，主程式不依賴 MCP。沒有 shell 字串拼接。"""
    python = config.get("python") or sys.executable
    command = config.get("command")
    if not command or not isinstance(command, list) or not all(isinstance(x, str) for x in command):
        raise SourceError("未設定 MCP command 陣列，改用其他來源")
    payload = {"command": command, "tool": tool, "arguments": arguments}
    worker = str(Path(__file__).with_name("law_mcp_worker.py"))
    result = subprocess.run([python, "-B", "-X", "utf8", worker], input=json.dumps(payload, ensure_ascii=False),
                            text=True, encoding="utf-8", capture_output=True, timeout=90)
    if result.returncode:
        raise SourceError("MCP 無法執行：" + result.stderr[-800:])
    value = json.loads(result.stdout)
    if not isinstance(value, dict) or value.get("error") or value.get("isError") or value.get("success") is False:
        raise SourceError("MCP 查詢失敗：%s" % str(value)[:800])
    return value


class MCPBridge:
    """同一來源沿用一個 MCP session，避免每查一條就重啟伺服器。"""
    def __init__(self, config):
        self.config, self.process, self.lines = config, None, queue.Queue()

    def call(self, config, tool, arguments):
        if self.process is None:
            command = self.config.get("command")
            if not isinstance(command, list) or not command or not all(isinstance(x, str) for x in command):
                raise SourceError("未設定 MCP command 陣列，改用其他來源")
            python = self.config.get("python") or sys.executable
            if os.path.normcase(os.path.abspath(python)) == os.path.normcase(os.path.abspath(sys.executable)):
                if importlib.util.find_spec("mcp") is None:
                    raise SourceError("目前 Python 未安裝 MCP SDK，直接改用其他來源；不自動安裝")
            self.process = subprocess.Popen([python, "-B", "-X", "utf8",
                str(Path(__file__).with_name("law_mcp_worker.py")), "--session"], stdin=subprocess.PIPE,
                stdout=subprocess.PIPE, stderr=subprocess.DEVNULL, text=True, encoding="utf-8")
            process = self.process
            def read():
                try:
                    for line in process.stdout:
                        self.lines.put(line)
                except (OSError, ValueError):
                    pass
                finally:
                    self.lines.put(None)
            threading.Thread(target=read, daemon=True).start()
            process.stdin.write(json.dumps({"command": command}) + "\n")
            process.stdin.flush()
        self.process.stdin.write(json.dumps({"tool": tool, "arguments": arguments}, ensure_ascii=False) + "\n")
        self.process.stdin.flush()
        try:
            line = self.lines.get(timeout=90)
        except queue.Empty as exc:
            raise SourceError("MCP 查詢逾時，改用其他來源") from exc
        if line is None:
            raise SourceError("MCP 程序已結束（請檢查 SDK、環境與啟動參數），改用其他來源")
        value = json.loads(line)
        if not isinstance(value, dict) or value.get("error") or value.get("isError") or value.get("success") is False:
            raise SourceError("MCP 查詢失敗：%s" % str(value)[:800])
        return value

    def close(self):
        if self.process is not None:
            try:
                self.process.stdin.close()
                self.process.wait(timeout=10)
            except (OSError, subprocess.TimeoutExpired):
                self.process.terminate()
                try:
                    self.process.wait(timeout=5)
                except subprocess.TimeoutExpired:
                    self.process.kill()
                    self.process.wait(timeout=5)
            finally:
                self.process.stdout.close()


def cached_fetcher(fetch_fn, folder):
    """照網址把抓到的內容存起來，下次同一個網址直接讀檔（v1.8.0）。只給公告內文與附件用：
    官方公告發布後內容不會變；清單頁會有新公告，不能用。抓失敗的不存（下次再試）。"""
    import json as _json
    index_path = os.path.join(folder, "索引.json")

    def load_index():
        try:
            with open(index_path, encoding="utf-8") as f:
                return _json.load(f)
        except (OSError, ValueError):
            return {}

    def fetch_cached(url):
        index = load_index()
        name = index.get(url)
        if name and os.path.isfile(os.path.join(folder, name)):
            with open(os.path.join(folder, name), "rb") as f:
                return f.read()
        raw = fetch_fn(url)
        os.makedirs(folder, exist_ok=True)
        name = digest(url.encode("utf-8"))[:32] + ".bin"
        with open(os.path.join(folder, name), "wb") as f:
            f.write(raw)
        index[url] = name
        with open(index_path + ".tmp", "w", encoding="utf-8") as f:
            _json.dump(index, f, ensure_ascii=False)
        os.replace(index_path + ".tmp", index_path)
        return raw
    return fetch_cached


def collect(source, base, evidence_dir, since, until, fetcher=None, caller=None, item_fetcher=None):
    """回傳 events、coverage；每個來源獨立失敗。缺漏一律記錄，不回假成功。
    item_fetcher：公告清單裡每一則公告內文與附件用的抓法（v1.8.0 給快取用；清單頁照樣用 fetcher 每次重抓）。"""
    bridge = MCPBridge(source.get("mcp", {})) if source.get("kind") == "MCP" and caller is None else None
    fetcher, caller = fetcher or fetch, caller or (bridge.call if bridge else mcp_call)
    item_fetcher = item_fetcher or fetcher
    name, kind = source.get("name", "未命名來源"), source.get("kind", "檔案")
    coverage = {"name": name, "kind": kind, "status": "待查", "detail": "", "since": since, "until": until,
                "checked_at": stamp(), "count": 0, "evidence": []}
    events = []

    def save(raw, suffix):
        path = Path(evidence_dir) / (digest(raw) + suffix)
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(raw)
        rel = "證據/" + path.name
        coverage["evidence"].append({"path": rel, "sha256": digest(raw)})
        return rel

    def accept(records, evidence):
        for record in records:
            item = normalize(record, source, evidence)
            names = source.get("law_names", [])
            keywords = source.get("keywords", [])
            if (names and item["law_name"] not in names) or (keywords and not any(k in item["law_name"] for k in keywords)):
                coverage["filtered_count"] = coverage.get("filtered_count", 0) + 1
                continue
            if not item["event_date"] or since <= item["event_date"] <= until or source.get("baseline"):
                events.append(item)

    try:
        for key in ("keywords", "law_names"):
            if key in source and (not isinstance(source[key], list) or not all(isinstance(x, str) for x in source[key])):
                raise SourceError("來源的 %s 須為字串陣列" % key)
        if kind == "MCP":
            config = source.get("mcp", {})
            listed = []
            max_pages = max(1, int(source.get("max_pages", 20)))
            for offset in range(0, max_pages * 50, 50):
                response = caller(config, "search_regulations", {"keyword": source.get("keyword", ""),
                                  "amended_since": "" if source.get("baseline") else since,
                                  "category": source.get("category", ""), "offset": offset})
                save(json.dumps(response, ensure_ascii=False).encode("utf-8"), ".json")
                rows = response.get("results", response.get("regulations", []))
                if not isinstance(rows, list):
                    raise SourceError("MCP 法規清單格式不相容")
                listed.extend(rows)
                if not response.get("has_more") and len(rows) < 50:
                    break
            else:
                raise SourceError("MCP 清單超過頁數上限；請縮小期間，已取得資料保留於證據")
            law_errors = []
            for row in listed:
                try:
                    law_name = row.get("name") or row.get("law_name") or row.get("LawName")
                    pcode = row.get("pcode", "")
                    if not law_name and not pcode:
                        raise SourceError("MCP 清單缺法規名稱／代碼")
                    outline = caller(config, "query_regulation", {"law_name": law_name or "", "pcode": pcode})
                    save(json.dumps(outline, ensure_ascii=False).encode("utf-8"), ".json")
                    end = str(outline.get("last_article") or "10000")
                    start = str(outline.get("first_article") or "1")
                    visited = set()
                    while True:
                        if start in visited:
                            raise SourceError("MCP 條文分頁沒有前進；請補查")
                        visited.add(start)
                        block = caller(config, "query_regulation", {"law_name": law_name or "", "pcode": pcode,
                                                                   "article_no": "%s~%s" % (start, end)})
                        evidence = save(json.dumps(block, ensure_ascii=False).encode("utf-8"), ".json")
                        law = block.get("law") or {}
                        articles = block.get("articles") or []
                        if not articles:
                            raise SourceError("MCP 未回傳條文，不能視為沒有異動")
                        for article in articles:
                            number = str(article.get("article_no") or article.get("number") or article.get("no", ""))
                            record = {"law_name": law_name or law.get("name"), "article_no": number,
                                     "new_text": article.get("content") or article.get("text"),
                                     "event_date": law.get("last_amended") or row.get("last_amended"),
                                     "effective_date": law.get("effective_date", ""), "effective_note": law.get("effective_note", ""),
                                     "source_url": block.get("source_url") or law.get("url") or
                                         ("https://law.moj.gov.tw/LawClass/LawAll.aspx?pcode=" + pcode if pcode else ""),
                                     "notes": "整部修正日不代表本條修正；施行狀態須 AI 核對"}
                            # 上游僅在查單條時回 article_history，不能把區間查詢誤當有完整歷史。
                            try:
                                history_result = caller(config, "query_regulation", {"law_name": law_name or "", "pcode": pcode,
                                                                                    "article_no": number, "include_history": True})
                            except (OSError, ValueError, subprocess.SubprocessError) as exc:
                                record["notes"] += "；歷史查詢失敗：%s" % exc
                                accept([record], evidence)
                                law_errors.append("%s 第%s條歷史待補" % (law_name, number))
                                continue
                            history_evidence = save(json.dumps(history_result, ensure_ascii=False).encode("utf-8"), ".json")
                            history = history_result.get("article_history") or {}
                            revisions = history.get("revisions", []) if history.get("available") else []
                            if history.get("partial") or history.get("failed_versions") or not history.get("available"):
                                record["notes"] += "；歷史版本缺漏，已取得內容仍保留，不能宣稱差異完整"
                            if source.get("baseline") or not revisions:
                                accept([record], evidence)
                            previous = None
                            for revision in revisions:
                                day = date(revision.get("lnndate") or revision.get("date"))
                                if day and since <= day <= until:
                                    item = dict(record, new_text=revision.get("content") or "（刪除）", event_date=day,
                                                change_type=revision.get("action", ""),
                                                version=day, source_url=history.get("source_url") or record["source_url"],
                                                old_text=(previous or {}).get("content") or "",
                                                old_source_url=history.get("source_url", "") if previous else "")
                                    accept([item], history_evidence)
                                previous = revision
                        if not block.get("has_more"):
                            break
                        next_no = re.search(r"其餘從第\s*([0-9-]+)\s*條", block.get("note", ""))
                        if not next_no:
                            raise SourceError("MCP 有下一批但缺少續查條號，請補查；不可直接加50以免漏掉之條")
                        start = next_no.group(1)
                except (OSError, ValueError, KeyError, TypeError, subprocess.SubprocessError) as exc:
                    law_errors.append("%s：%s" % (row.get("law_name") or row.get("name") or row.get("pcode"), exc))
            coverage.update(status="部分完成", detail="已查 MCP 清單及條文；日期資料可能有更新延遲，歷史與公告須交叉核對。" + "；".join(law_errors))
        elif kind == "公告清單":
            url = source["url"]
            matched, pages, seen_links, failures = 0, set(), set(), []
            limit = max(1, int(source.get("max_pages", 30)))
            while url:
                if url in pages or len(pages) >= limit:
                    failures.append("清單分頁重複或達上限，須補查")
                    break
                pages.add(url)
                raw = fetcher(url)
                save(raw, ".html")
                page = Page()
                page.feed(decode(raw))
                for row in page.rows:
                    text = " ".join(row["parts"])
                    found = re.search(r"\b\d{2,4}[./-]\d{1,2}[./-]\d{1,2}\b", text)
                    if not found:
                        continue
                    day = date(found.group())
                    if not since <= day <= until:
                        continue
                    for href, title in row["links"]:
                        if not title or href.startswith(("#", "javascript:")):
                            continue
                        link = urllib.parse.urljoin(url, href)
                        if link in seen_links:
                            continue
                        seen_links.add(link)
                        try:
                            item_raw = item_fetcher(link)
                            suffix = Path(urllib.parse.urlsplit(link).path).suffix.lower()
                            suffix = suffix if suffix in (".pdf", ".docx", ".xml", ".json") else ".html"
                            evidence = save(item_raw, suffix)
                            subsource = dict(source, name=title, law_name=title, url=link, event_date=day,
                                             status=draft_status(title))
                            accept(records_from_bytes(item_raw, suffix, subsource), evidence)
                            matched += 1
                            if suffix == ".html":
                                details = Page()
                                details.feed(decode(item_raw))
                                for attachment, label in details.links:
                                    attachment = urllib.parse.urljoin(link, attachment)
                                    ext = Path(urllib.parse.urlsplit(attachment).path).suffix.lower()
                                    if (ext not in (".pdf", ".docx", ".xml", ".json", ".zip") or attachment in seen_links
                                            or site_link(attachment, label)):
                                        continue
                                    seen_links.add(attachment)
                                    try:
                                        blob = item_fetcher(attachment)
                                        evidence = save(blob, ext)
                                        sub = dict(subsource, name=title + "：" + label, url=attachment)
                                        accept(records_from_bytes(blob, ext, sub), evidence)
                                    except (OSError, ValueError) as exc:
                                        failures.append("附件 %s：%s" % (attachment, exc))
                        except (OSError, ValueError) as exc:
                            failures.append("公告 %s：%s" % (link, exc))
                next_links = [href for href, title in page.links if re.sub(r"\s", "", title) in ("下一頁", "下頁", "Next")
                              and not href.startswith(("#", "javascript:"))]
                url = urllib.parse.urljoin(url, next_links[0]) if next_links else ""
            coverage.update(status="部分完成", detail="已讀取 %d 頁、%d 筆公告及可辨識附件；網站未涵蓋的歷史期間、動態附件仍須 AI 補查。%s" %
                            (len(pages), matched, "；".join(failures)))
        else:
            if kind in ("官方網頁", "開放資料"):
                raw = fetcher(source["url"])
                suffix = detect_format(raw, source["url"], source.get("format", ""))
            else:
                path = (Path(base) / source["path"]).resolve()
                if not path.is_file():
                    raise SourceError("找不到匯入檔案：%s" % path)
                if path.stat().st_size > MAX_BYTES:
                    raise SourceError("匯入檔案超過 40 MB，請分檔")
                raw, suffix = path.read_bytes(), path.suffix
            evidence = save(raw, suffix)
            accept(records_from_bytes(raw, suffix, source), evidence)
            coverage.update(status="部分完成", detail="已讀取指定來源；只涵蓋檔案／網頁內容，日期與期間完整性需核對")
        coverage["count"] = len(events)
    except (OSError, ValueError, KeyError, TypeError, subprocess.SubprocessError, ET.ParseError, zipfile.BadZipFile) as exc:
        coverage.update(status="失敗" if not events else "部分完成", detail="%s：%s" % (type(exc).__name__, exc), count=len(events))
    finally:
        if bridge:
            bridge.close()
    if source.get("law_names") or source.get("keywords"):
        coverage["detail"] += "；名稱範圍 %s，另有 %d 筆未納入（不代表不適用）" % (
            json.dumps({"law_names": source.get("law_names", []), "keywords": source.get("keywords", [])}, ensure_ascii=False),
            coverage.get("filtered_count", 0))
    return events, coverage
