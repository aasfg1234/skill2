# -*- coding: utf-8 -*-
r"""
reg-report 總入口：比對現行與修訂規章，產出標註版全文、修正對照表、檢視報告（不改 Word 檔）。

    py run_all.py 建工作區 / 配對 / 開始
    py run_all.py 語意併入        （別台電腦算好的語意候選帶回來時）
    py run_all.py 審查打包 / 審查匯入
    py run_all.py 繼續           （照人工待辦一站一站接著跑，報告產出就停）

設計守則：
- 每本的輸入檔先複製進 <outdir>/<規章>/2_Log檔案/輸入/。
- 完整報告寫檔，摘要印在最後。
- 沒有鍵盤輸入；失敗一律 exit 1。
- 不寫死磁碟路徑，不碰家目錄。
"""

import argparse
import contextlib
import datetime
import hashlib
import importlib.util
import io
import json
import os
import shutil
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
REG = os.path.dirname(HERE)
REGDIFF = os.path.join(HERE, "regdiff")
for _path in (HERE, REGDIFF):
    if _path not in sys.path:
        sys.path.insert(0, _path)

# 產出檔的去向只有一張表（_common.FILE_HOMES）：寫檔走 place、讀檔走 locate。
# 不要在這支自己 os.path.join(outdir, "連帶決定表.csv")——那樣去向表改了這裡不會跟著動。
from _common import place, locate, warn_legacy_layout, book_dir  # noqa: E402


def setup_stdout():
    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
        sys.stderr.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass


def say(text=""):
    print(text, flush=True)


def file_sha256(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def load_settings():
    """設定.html 的「設定」一段（工作區根目錄、語意模型路徑……）。讀不出來的提醒由 _common.load_config 發。"""
    from _common import config_section
    return dict(config_section("設定"))


def resolve_outdir(args, settings):
    """--outdir 優先；其次 --workspace 或設定檔的工作區根目錄；都沒有就用目前目錄。"""
    from _common import tw_now, tw_today
    if getattr(args, "outdir", ""):
        return os.path.abspath(args.outdir)
    from _common import skill_path
    root = getattr(args, "workspace", "") or skill_path(settings.get("工作區根目錄", ""))
    if not root:
        return os.path.abspath("reg_產出")
    stamp = tw_now().strftime("%Y%m%d_%H%M%S")
    return os.path.join(os.path.abspath(root), "reg_產出_" + stamp)


ROLE_PREFIXES = ("舊版", "新版")
ROLE_KEY = "角色"


PROBE_NAME = ".reg_寫入測試"


def check_outdir_writable(outdir):
    """產出資料夾前置檢查：不是既有檔案、建得起來、而且真的寫得進去。

    為什麼要「真的寫一個檔再刪掉」而不是看權限位元：Windows 的唯讀屬性、
    網路磁碟機（UNC）掉線、OneDrive 的「僅線上」資料夾，用 os.access 全都
    看起來沒問題，真的寫下去才會噴 OSError——而那時候 輸入/ 已經建好、
    原始檔也複製進去了（no 10）。

    失敗一律丟 _common.InputError，由呼叫端統一印「[中止]」。
    """
    from _common import InputError
    if os.path.isfile(outdir):
        raise InputError("產出資料夾指到一個既有檔案：%s；請把 --outdir 改成資料夾路徑" % outdir)
    try:
        os.makedirs(outdir, exist_ok=True)
    except OSError as exc:
        raise InputError("產出資料夾建不起來：%s（%s）" % (outdir, exc))
    probe = os.path.join(outdir, PROBE_NAME)
    try:
        with io.open(probe, "w", encoding="utf-8") as f:
            f.write("x")
    except OSError as exc:
        raise InputError("產出資料夾不能寫入：%s（%s）；請改用別的 --outdir 或關掉開著的檔案"
                         % (outdir, exc))
    finally:
        try:
            os.remove(probe)
        except OSError:
            pass


# 「這個產出資料夾是舊排法嗎」看哪幾個檔：compare 一定會寫這兩個，
# 而且一個在 2_Log檔案/、一個在 2_Log檔案/，兩格都驗到。
_LAYOUT_PROBES = ("連帶決定表.csv", "異動清單.json")


def warn_if_legacy_outdir(outdir):
    """產出資料夾是舊排法（檔案平鋪、沒分三格）就提醒一次；回傳有沒有提醒。

    讀端照舊讀得到（locate 會退回平鋪），**寫端仍然寫進新格**——把新檔寫回平鋪
    等於把舊排法一直養下去，而且同一個資料夾會半新半舊，人更分不出哪個是這一輪的。

    單本子命令（review-pack／review-import／apply／finalize／semantic）直接接這一支；
    批次那幾支接下面的 warn_if_legacy_books（批次的產出是一本一個子資料夾，
    要驗的是每一本，不是產出根目錄——根目錄底下只有批次自己那幾個檔，
    沒有 _LAYOUT_PROBES 這兩個探針）。
    """
    if not outdir or not os.path.isdir(outdir):
        return False
    if any(locate(outdir, name)[1] for name in _LAYOUT_PROBES):
        warn_legacy_layout(outdir)
        return True
    return False


def warn_if_legacy_books(outdir, names):
    """批次版：逐本驗一次舊排法，回傳有幾本是舊排法。

    每本各發一則（warn_legacy_layout 自己用 outdir 去重），因為一批裡很可能只有
    幾本是上一個版本跑的；只講「這個產出根目錄是舊排法」的話，人不知道要回頭
    重跑哪幾本。
    """
    from _common import book_dir
    return sum(1 for name in names if warn_if_legacy_outdir(book_dir(outdir, name)))


def outdir_of_table(table_path):
    """從一張表的路徑回推它的產出資料夾：在三格裡就是上一層，平鋪就是同一層。

    多剝一層 2_Log檔案/輸入/：留底資料夾裡也會有一份決定表（stage_inputs 複製的），
    人拿那一份去跑 semantic／finalize 時，只剝一層會停在「2_Log檔案/輸入」，
    接著 locate 在那裡找到平鋪的表，於是提醒會說「…2_Log檔案/輸入 是舊排法的產出
    資料夾」——那是留底資料夾，本來就該平鋪，這句是假警報。
    """
    folder = os.path.dirname(os.path.abspath(table_path))
    from _common import OUTPUT_DIRS, SYSTEM_DIR
    parent = os.path.dirname(folder)
    if os.path.basename(folder) == "輸入" and os.path.basename(parent) == SYSTEM_DIR:
        return os.path.dirname(parent)
    if os.path.basename(folder) in OUTPUT_DIRS:
        return parent
    return folder


def precheck(outdir, doc_paths=(), other_paths=(), docx_only=()):
    """動任何檔案之前先驗一輪：輸入檔存在＋格式白名單，再驗產出資料夾可寫。

    回傳 None 代表過關；否則回傳要印在「[中止]」後面的那句話。

    順序不能反（no 10）：輸入檔先驗，過了才 makedirs——不然「草稿路徑打錯」
    這種最常見的手誤會留下一個空的產出資料夾，下一輪的過期檢查、歸檔都要
    跟這些殘骸打架。同理，docx_only 也要排在 check_outdir_writable 之前。

    doc_paths   要當內規全文讀的檔（走 SUPPORTED_EXTS 白名單）
    other_paths 只要求存在的檔（決定表 .csv、sidecar .json 這類）
    docx_only   除了白名單以外還必須是 .docx 的檔（M5：apply 的草稿）
    """
    from _common import InputError, check_input_file
    for path in doc_paths:
        if not path:
            continue
        try:
            check_input_file(path)
        except InputError as exc:
            return str(exc)
    for path in docx_only:
        # M5：apply 是把決定表的修改寫成 Word 追蹤修訂再存回 .docx——.txt／.md
        # 根本沒有修訂記號這種東西，硬跑只會產出一份「看起來成功但沒有任何
        # 修訂痕跡」的檔。compare 吃得下不代表 apply 吃得下，這一步要講清楚。
        if path and os.path.splitext(path)[1].lower() != ".docx":
            return ("apply 的草稿必須是 .docx（目前：%s）；.txt/.md 只能用來 compare"
                    % os.path.basename(path))
    for path in other_paths:
        if path and not os.path.isfile(path):
            return ("錯誤：找不到檔案 %s\n"
                    "請確認路徑有沒有打錯，含空白的路徑要用雙引號括起來。" % path)
    try:
        check_outdir_writable(outdir)
    except InputError as exc:
        return str(exc)
    return None


def stage_inputs(outdir, paths, roles=None, overwrite_level=None):
    """輸入檔複製進 <outdir>/輸入/ 並記 SHA-256，作為輸入留底。
    同一個產出資料夾可能被多個子命令接力使用，所以指紋檔採合併寫入，不覆蓋既有項目。

    overwrite_level（選填）：同一角色留底被不同內容覆寫時要用的提醒等級。預設「警告」；
    compare 會整套重算下游產出，換草稿重跑是正常流程，所以 compare 傳「提醒」就好。
    roles（選填）：跟 paths 等長的角色清單，或 {路徑: 角色} 對照表。角色是「舊版」
    或「新版」時，留底檔名變成 `舊版_<原檔名>`／`新版_<原檔名>`，指紋鍵同名，並在
    指紋檔多記一個「角色」對照。

    為什麼要分：法遵手上的舊版與新版常常就是同一個檔名（放在「匯入/現行規章」「匯入/修訂規章」
    兩個資料夾裡）。照原檔名留底的話，後複製的新版會直接蓋掉舊版，指紋檔也只剩一筆——
    留底看起來有兩個檔其實只有一個，而 review-pack 會把草稿當成舊版讀，刪除段的前後文
    整段對錯人。角色清單不能用單純的 dict 由呼叫端組（沒有草稿的那一本，舊版與新版
    是同一個路徑，當鍵會撞在一起），所以這裡也接受跟 paths 等長的清單。
    """
    import notices as nt
    # 留底是「程式接力用」的東西，進 2_Log檔案/輸入/（見 _common.FILE_HOMES）。
    # 舊排法的資料夾已經有平鋪的 輸入/（裡面有 舊版_／新版_ 與帶「角色」的指紋）時
    # 沿用它：另開 2_Log檔案/輸入/ 會把舊的那份遮掉，review-pack 從此找不到舊版檔，
    # 只能用檔名猜、把草稿當舊版（全波審查發現）。
    target, is_legacy = locate(outdir, "輸入")
    if not is_legacy:
        target = place(outdir, "輸入")
    os.makedirs(target, exist_ok=True)
    record_path = os.path.join(target, "輸入指紋.json")
    record = {}
    if os.path.isfile(record_path):
        try:
            with io.open(record_path, encoding="utf-8-sig") as f:
                record = json.load(f)
        except (OSError, ValueError) as exc:
            # 靜默清空是最糟的處理：檔案壞掉（磁碟滿了寫到一半、被人手動編輯過）
            # 之後，前面幾個子命令留下的指紋全部消失，而「輸入指紋.json 存在且
            # 看起來完整」正是之後回答「這份產出是拿哪幾個檔跑的」的唯一依據。
            # 重建可以，但一定要有人知道舊紀錄不見了。
            nt.notice(nt.WARNING,
                      "輸入指紋.json 讀不出來（%s），已重建；"
                      "之前的留底紀錄遺失，這個產出資料夾先前留底過哪些檔要另外查" % exc,
                      "留底")
            record = {}
    role_map = dict(record.get(ROLE_KEY) or {})
    for index, path in enumerate(paths):
        if not path or not os.path.isfile(path):
            continue
        if isinstance(roles, dict):
            role = roles.get(path) or ""
        elif roles is not None and index < len(roles):
            role = roles[index] or ""
        else:
            role = ""
        name = os.path.basename(path)
        if role in ROLE_PREFIXES:
            name = "%s_%s" % (role, name)
            role_map[role] = name
        dest = os.path.join(target, name)
        digest = file_sha256(path)
        previous = record.get(name)
        if previous and previous != digest:
            # 同一個產出資料夾被多個子命令接力使用，留底檔名一樣但內容不一樣，
            # 代表「同一個角色的檔案中途換過」（草稿又改了一版、舊版拿錯檔）。
            # 直接覆寫的話，留底剩下最後那一份，而決定表、指紋、段次全是前一份
            # 算出來的——回頭稽核時對不起來，卻沒有任何一行講過這件事。
            nt.notice(overwrite_level or nt.WARNING,
                      "留底 %s 被不同內容覆寫（SHA %s → %s）："
                      "同一個產出資料夾這個角色前後拿到兩個不同的檔，"
                      "先前步驟的產出是用舊的那一份算的，請確認是不是拿錯檔"
                      % (name, previous[:8], digest[:8]), "留底")
        if os.path.abspath(path) != os.path.abspath(dest):
            shutil.copy2(path, dest)
        record[name] = digest
    if role_map:
        record[ROLE_KEY] = role_map
    with io.open(record_path, "w", encoding="utf-8") as f:
        json.dump(record, f, ensure_ascii=False, indent=2)
        f.write("\n")
    return record


def load_regdiff_runner():
    """regdiff/run_all.py 跟這支同名，不能直接 import，改用檔案路徑載入。"""
    path = os.path.join(REGDIFF, "run_all.py")
    spec = importlib.util.spec_from_file_location("regdiff_run_all", path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


# ---------------------------------------------------------------------------
# check
# ---------------------------------------------------------------------------

# ---------------------------------------------------------------------------
# apply
# ---------------------------------------------------------------------------

# ---------------------------------------------------------------------------
# compare / finalize 共用
# ---------------------------------------------------------------------------

# Step 2 四個門檻旗標：終比對（finalize／batch-finalize）沒有在命令列另外指定時，
# 要沿用初比對指紋檔記的「比對參數」，不是悄悄退回這裡的硬預設。
_COMPARE_PARAM_KEYS = ("threshold", "top", "changed_top", "sentence_threshold")


def _compare_param_fallbacks(runner):
    """真的什麼都沒有時（指紋檔是這個功能之前產生的、或根本沒有 recorded）才用的
    最後一層預設值，跟 regdiff 自己的常數一致。"""
    return {"threshold": runner.fuzzy.DEFAULT_THRESHOLD, "top": runner.fuzzy.DEFAULT_TOP,
           "changed_top": 8, "sentence_threshold": runner.fuzzy.DEFAULT_SENTENCE_THRESHOLD}


def _compare_params_with_fallback(runner, recorded=None):
    """recorded（通常是某本指紋檔的「比對參數」）有記的鍵就用它，沒記的鍵（或整個
    沒給）退回 _compare_param_fallbacks。回傳四個鍵都有值的完整 dict。"""
    out = _compare_param_fallbacks(runner)
    if recorded:
        for key in _COMPARE_PARAM_KEYS:
            if key in recorded:
                out[key] = recorded[key]
    return out


def _compare_params_from_args(args):
    return dict((key, getattr(args, key)) for key in _COMPARE_PARAM_KEYS)


DEFAULT_TABLE_TITLE = "修正對照表"


def table_title(name):
    """修正對照表 Word 版的標題：「<規章名>修正對照表」（規章名見 workspace.display_name）。
    以前每一本都只寫「修正對照表」，一批十本印出來分不出哪張是哪一本。"""
    import workspace as wsm
    text = wsm.display_name(name)
    return (text + DEFAULT_TABLE_TITLE) if text else DEFAULT_TABLE_TITLE


def _abort_notices(outdir, args, reason):
    """比對中止也要寫 提醒.txt（B9）：中止前已經印過的提醒（追蹤修訂、自動編號…）加上中止原因，
    一句都不能只留在畫面上。"""
    import notices as nt
    nt.notice(nt.WARNING, "比對中止：%s" % reason, "比對")
    try:
        nt.write_notices(outdir, getattr(args, "prefix", "") or "", title="比對（中止）")
    except OSError:
        pass


def _compare_core(args, settings):
    """跑 regdiff 的 Step 0.5→1→1.2→1.6→2，再合成連帶決定表的列。回傳 (rc, outcome, rows, outdir)。

    只算不寫表：batch 要等所有本的第 0、1 步都過了才寫（_write_batch_table），
    中途中止才不會在產出資料夾留下前幾本的決定表。"""
    import decision_table as dt
    runner = load_regdiff_runner()
    if (getattr(args, "title", "") or DEFAULT_TABLE_TITLE) == DEFAULT_TABLE_TITLE:
        # 沒給 --title：用舊版檔名當規章名（批次的規章名就是舊版檔名去掉副檔名）
        args.title = table_title(os.path.splitext(os.path.basename(args.old_file or ""))[0])
    outdir = resolve_outdir(args, settings)
    # no 10／11：舊版、新版的存在與格式，還有產出資料夾能不能寫，全部在
    # makedirs／stage_inputs 之前驗完。以前這幾件事要等 read_paragraphs
    # （比對跑到一半）才發現，那時候殘骸已經留在硬碟上了。
    problem = precheck(outdir, doc_paths=[args.old_file, args.new_file])
    if problem:
        say("[中止] %s" % problem)
        return 1, None, [], outdir
    # 舊版與新版常常同檔名，一定要帶角色留底，不然後複製的會蓋掉先複製的
    # compare 換檔重跑會整套重算，覆寫留底是正常流程，只用「提醒」不用「警告」。
    import notices as nt
    stage_inputs(outdir, [args.old_file, args.new_file], roles=["舊版", "新版"],
                 overwrite_level=nt.REMINDER)
    nt.carry_over()          # run_compare 開頭的 reset() 不能把留底的提醒清掉（B9）
    args.outdir = outdir
    try:
        outcome = runner.run_compare(args)
    except runner.BaselineReleaseError as exc:
        say("[中止] 正式基準驗證失敗：%s" % exc)
        if "SHA-256" in str(exc) or "原始檔" in str(exc):
            say("        多半是現行規章換過了（例如放回簽核回來的核定版），規格包還是舊的：先用 reg-baseline 跑 建基準 重建；"
                "急著先比對，可以暫時把 匯入/規章清單.csv 那一列的「發布根目錄」清空（少了規格包連帶）")
        _abort_notices(outdir, args, "正式基準驗證失敗：%s" % exc)
        return 1, None, [], outdir
    except runner.CompareAbort as exc:
        # 讀檔防呆沒過（例如任一邊 0 段）。這裡就收掉，不能讓後面的步驟
        # 拿著空的一邊產出一份「整本條文全部刪除」的正式對照表還 exit 0。
        say("[中止] %s" % exc)
        _abort_notices(outdir, args, str(exc))
        return 1, None, [], outdir

    _settle_unchanged_book(outdir, outcome, health=bool(getattr(args, "health", False)))
    results = outcome["results"]
    baseline = outcome["baseline"]
    new_line_ids = baseline.annotate_results(results) if baseline else {}
    semantic_rows = []
    if getattr(args, "semantic", None):
        import semantic_candidates as sc
        try:
            semantic_rows = sc.read_results(args.semantic, expected_sha=file_sha256(args.new_file))
        except sc.SemanticError as exc:
            say("[中止] 語意候選檔不能用：%s" % exc)
            return 1, None, [], outdir
    rows = dt.build_rows(outcome["csv_rows"], outcome["changed_rows"],
                         outcome["review_rows"], new_line_ids,
                         outcome["new_paragraphs"], semantic_rows,
                         sentence_rows=outcome.get("sentence_rows"),
                         change_types=dt.change_type_map(results, baseline),
                         change_positions=dt.change_position_map(results, baseline))
    # 章節重編後指錯的引用（Step 0.5）也是要人決定改不改的一段：進決定表，
    # 「建議改法」由 row_assist.annotate 照位置改寫好，填「改」就能 apply
    rows = dt.add_outline(rows, outcome.get("章節引用"))
    # 條、款、項引用（需改寫／危險／無法判定）、「編號沒變、內容變了」與定義變更連動也進決定表
    # （以前只印在畫面或條文檢查報告）；需改寫的建議改法同樣照位置只換那個號碼，其餘留空給人決定
    refs = outcome.get("條文引用") or {}
    rows = dt.add_refs(rows, refs.get("references"), refs.get("drift"), outcome["new_paragraphs"])
    rows = dt.add_definitions(rows, outcome.get("定義連動"), outcome["new_paragraphs"],
                              results=results, baseline=baseline)
    return 0, outcome, rows, outdir


def _assist_rows(rows, outdir, items, books=None):
    """寫決定表之前：補「異動內容／建議改法」，並沿用上一輪的決定。
    回傳 (沿用了幾列, 有沒有上一輪的表)。沒有上一輪（第一次跑）時不必講「沿用 0 列」。
    沿用幾列由呼叫端印在畫面與批次摘要上（這時候各本的 提醒.txt 已經寫完了）。"""
    import row_assist as ra
    ra.annotate(rows, items, books)
    previous = ra.previous_round(outdir)
    return ra.carry_over(rows, items, previous), previous is not None


def source_distribution(rows):
    """{來源組合: 列數}。**一列只算一次**（小瑕疵 13）。

    以前是把每一列的「來源」用「；」拆開、每個標籤各記一次，於是同時被相似度與
    語意抓到的那一列會在兩個桶子裡各算一遍，括號裡的數字加起來大於「候選 N 列」。
    人看到「候選 12 列（相似 9、語意 6）」會以為自己數錯，或以為表上少了幾列。
    改成一列只進一個桶子，桶名就是它的來源組合（相似＋語意），加起來剛好是列數。
    """
    dist = {}
    for row in rows:
        labels = [s for s in (row.get("來源") or "").split("；") if s]
        key = "＋".join(labels) if labels else "無來源"
        dist[key] = dist.get(key, 0) + 1
    return dist


# 工作區模式時，畫面上的路徑印成「工作區/」底下的相對路徑（工作區根目錄在開頭印一次）。
# 以前每個路徑都印完整絕對路徑，一行歸檔訊息就占四行，要看的字被擠到畫面外。
_DISPLAY_ROOT = [None]


def _set_display_root(root):
    if root and _DISPLAY_ROOT[0] != os.path.abspath(root):
        _DISPLAY_ROOT[0] = os.path.abspath(root)
        say("工作區：%s" % _DISPLAY_ROOT[0])


def show_path(path):
    """工作區底下的路徑印相對路徑（例：產出/2_Log檔案/批次摘要.txt），其餘照印完整路徑。"""
    root = _DISPLAY_ROOT[0]
    if root and path:
        try:
            rel = os.path.relpath(os.path.abspath(path), root)
        except ValueError:          # Windows 跨磁碟機
            return path
        if not rel.startswith(".."):
            return rel.replace(os.sep, "/")
    return path


def archive_line(moved):
    """「已歸檔上一輪」那一行：不再逐一列出每個目的地的完整路徑（位置都是固定的）。"""
    stamp = os.path.basename(moved[0])
    return "已歸檔上一輪：%s（%d 處，都在各自的 2_Log檔案/歷次/%s/）" % (stamp, len(moved), stamp)


def workspace_flag(args):
    """印給人複製的指令帶的 --workspace（v1.24.0：一律帶——以前是預設那一個就省略，之後再建一個新工作區，
    照抄舊指令就跑到別的工作區去；SKILL.md 也規定每一步都帶）。沒指定工作區的就帶這一次實際用的那一個。"""
    given = getattr(args, "workspace", "") or ""
    if not given:
        try:
            import workspace as wsm
            given = wsm.resolve_root("", load_settings())
        except Exception:
            return ""
    return '--workspace "%s"' % given


def _cmd(name, *parts):
    """印給人複製貼上的指令：含空白的路徑加雙引號，不然會被拆成兩段。"""
    return _script_cmd("run_all.py", name, *parts)


def _script_cmd(script, *parts):
    """scripts/ 底下任一支的指令，寫法跟 _cmd 一樣（一律 python scripts/…，從 reg 根目錄照抄就能跑）。"""
    out = ["python scripts/%s" % script]
    for part in parts:
        if not part:
            continue
        out.append('"%s"' % part if (" " in part and not part.startswith("--")) else part)
    return " ".join(out)


def _semantic_recall_top(settings):
    """設定檔的「語意粗篩」：留空（null／""）就全排名；填數字 N 就只對純語意前 N 名算三種分數。"""
    value = settings.get("語意粗篩")
    if value in (None, "", 0, "0"):
        return None
    return int(value)


def setting_int(settings, key, default):
    """設定.html 的整數欄：留空（null／""）用預設值。0 照填的意思（跨本上限的 0＝不限）。"""
    value = settings.get(key)
    if value in (None, ""):
        return int(default)
    return int(value)


def _semantic_rerank_top(settings):
    """設定的「語意取前幾名」：每一句異動，先用快取裡的意思向量＋關鍵詞權重排名，取前幾名再算逐字分數。
    越大越不會漏、越慢；留空用 50（以前固定 200，幾十句的前 200 名合起來幾乎是整本，等於快取沒用）。"""
    import semantic_candidates as sc
    value = settings.get("語意取前幾名")
    if value in (None, "", 0, "0"):
        return sc.RERANK_TOP
    return max(1, int(value))


def _semantic_threshold(settings):
    """設定檔的「語意門檻」：留空（null／""）就交給分數器用自己的預設
    （三分數合併 0.70、只有 dense 0.75，見 semantic_candidates）。"""
    value = settings.get("語意門檻")
    if value in (None, ""):
        return None
    return float(value)


def _semantic_deleted(results, book=""):
    """整條刪除的異動也送語意比對：這條刪了，別處講同一件事的段落可能也該刪或改。
    拿舊文去比（新版沒有這一段，段次給 0＝不排除任何一段）；條文ID 寫法跟決定表那一列一樣
    （條號，沒有就「舊版段次 N」），併回表時才連得到同一處異動。"""
    out = []
    for r in results:
        if r["type"] == "deleted" and (r.get("old_text") or "").strip():
            label = ("、".join(r.get("spec_ids") or []) or r.get("ref")
                     or ("舊版段次 %d" % r["old_index"] if r.get("old_index") else ""))
            item = {"段次": 0, "全文": r["old_text"], "舊全文": "", "條文ID": label}
            if book:
                item["規章"] = book
            out.append(item)
    return out


UNCHANGED_NOTE = "本次未修改.txt"
_CHANGE_TYPES = ("added", "deleted", "modified", "renumbered", "cosmetic")


def _source_counts_line(distribution):
    """候選的找法分佈：「相似＋關鍵詞（文脈）」這種組合拆開來各算一次，依多寡排。
    以前照組合列，一本手冊就印三十幾種組合（「相似＋關鍵詞（文脈）＋關鍵詞（舊值）＋相似（句）…」），沒人看得懂。"""
    totals = {}
    for combo, count in (distribution or {}).items():
        for part in str(combo).split("＋"):
            part = part.strip()
            if part:
                totals[part] = totals.get(part, 0) + count
    if not totals:
        return "無"
    ranked = sorted(totals.items(), key=lambda kv: (-kv[1], kv[0]))
    return "依找法：%s；一列可能有好幾種" % "、".join("%s %d" % kv for kv in ranked)


HEALTH_NOTE = "體檢.txt"


def _settle_unchanged_book(outdir, outcome, health=False):
    """批次裡這一本新舊版一處都沒變（多半是清單裡沒放新版草稿、別本的連帶也決定不改）：
    這一本內部的 1_結果彙整/ 只放一張「本次未修改」說明（產出/1_結果彙整/本次未修改.txt 由 result_publish 列出是哪幾本）。

    以前照樣產一整套：沒有任何一列的修正對照表、沒有任何標註的標註版全文、內容跟舊版
    一模一樣的兩份新版定稿。人打開1_結果彙整看到齊全的一套，會以為這一本也要送核。
    那幾份空的不留。單本 compare 不走這裡：只比一本時
    0 異動多半是拿錯檔，那一份寫著「本次無實質異動」的對照表本身就是證據（小瑕疵 3）。
    後來又有改動（重跑之後不再是 0）就把說明拿掉。"""
    from _common import batch_root_of, result_home
    if not batch_root_of(outdir):
        return
    folder = result_home(outdir)
    note = os.path.join(folder, HEALTH_NOTE if health else UNCHANGED_NOTE)
    if any(r["type"] in _CHANGE_TYPES for r in outcome["results"]):
        if os.path.isfile(note):
            os.remove(note)
        return
    # 那幾份空的直接刪掉：以前改名「無異動_」留在 2_Log檔案/，每本沒改的規章多三個檔（標註版全文
    # 就是整本手冊再存一份），沒有人會打開
    removed = set()
    if os.path.isdir(folder):
        for name in sorted(os.listdir(folder)):
            if name != UNCHANGED_NOTE:
                path = os.path.join(folder, name)
                os.remove(path)
                removed.add(os.path.normcase(os.path.abspath(path)))
    name = os.path.basename(os.path.abspath(outdir))
    os.makedirs(folder, exist_ok=True)
    with io.open(note, "w", encoding="utf-8-sig") as f:
        if health:
            f.write("%s：體檢（檢查現有文件）\n\n"
                    "這一輪沒有修訂版、不比對差異，所以這裡沒有修正對照表與標註版全文。\n"
                    "條文檢查、引用檢查、外部法規查證、重複／矛盾的結果看 產出/1_結果彙整/體檢報告.xlsx（規章欄篩這一本）。\n"
                    % name)
        else:
            f.write("%s：本次沒有修改\n\n"
                    "新版與舊版內容完全相同，這一本不需要送核，所以這裡沒有修正對照表、標註版全文與新版定稿。\n"
                    "這一本仍有比對過：別本的改動有沒有影響它，看 產出/1_結果彙整/比對報告_<日期序號>.xlsx（規章欄篩這一本）。\n"
                    % name)
    outcome["produced"] = [path for path in outcome.get("produced") or []
                           if os.path.normcase(os.path.abspath(path)) not in removed] + [note]


def _external_counts_text(counts):
    """「有誤 1 處、漏抓 0 處、需查證 2 處、沒問題 5 處」"""
    import scoring_rubric as sr
    return "、".join("%s %d 處" % (v, counts.get(v, 0)) for v in sr.EXTERNAL_VERDICTS)


def _rulecheck_counts_text(counts):
    import review_import as ri
    import scoring_rubric as sr
    return "、".join("%s %d 項" % (v, counts.get(v, 0))
                     for v in sr.RULECHECK_VERDICTS + (ri.NOT_REVIEWED,) if counts.get(v) or v != ri.NOT_REVIEWED)


UNLISTED_FILE = "跨本未列.json"


def _merge_semantic(decisions, semantic_path):
    """把算好的語意候選檔併進一張決定表；已填的決定不動。回傳 (原列數, 併入後列數, 語意筆數)。
    讀不了表或檔（指紋不符）丟 DecisionTableError／SemanticError，由呼叫端印「[中止]」。"""
    import decision_table as dt
    import semantic_candidates as sc
    rows = dt.read_table(decisions)
    sidecar = dt.read_sidecar(dt.sidecar_path_for(decisions))
    semantic_rows = sc.read_results(semantic_path, expected_sha=sidecar["草稿"]["SHA256"])
    import review_import as ri
    before = len(rows)
    # 指紋檔的「列」只增不減：既有的每一筆原封不動留著（連表上已經被刪掉的列也留著），
    # 只替這次 add_semantic 新增的列補一筆。
    # 不能拿表上現在的樣子重建：候選全文被手改過的列，重算一次指紋就跟著被改過的字走，
    # review-import 從此驗不出來；被刪掉的列，指紋一消失，finalize 第二問就再也看不到它
    # （跑一次 semantic、就算零筆語意候選，竄改與刪列都被洗白了）。
    bad_idx, _ = ri.check_row_texts(rows, sidecar)
    if bad_idx:
        say("[警告] 有 %d 列候選全文跟初比對指紋不符（段次 %s）：指紋照舊，"
            "review-import 仍會擋下它們；請還原決定表或重跑 compare"
            % (len(bad_idx), "、".join(rows[i].get("候選段次") or "-" for i in sorted(bad_idx))))
    entries = list(sidecar.get("列") or [])
    _, unused = dt.match_sidecar(rows, entries)
    free = [(entries[k].get("候選段次") or 0, entries[k].get("候選全文SHA256")) for k in unused]
    existing = set(id(r) for r in rows)
    rows = dt.add_semantic(rows, semantic_rows)
    # 語意新加的列也要有「異動內容／建議改法」（compare 時那幾列還不存在）。只補新列：
    # 既有列的建議改法在 compare 時算好了，人可能已經照著填，不重算
    added = [r for r in rows if id(r) not in existing]
    change_list = locate(outdir_of_table(decisions), "異動清單.json")[0]
    if added and os.path.isfile(change_list):
        import row_assist as ra
        with io.open(change_list, encoding="utf-8") as f:
            ra.annotate(added, json.load(f), ra.sibling_books(outdir_of_table(decisions)))
    # 重寫表與指紋檔；草稿指紋與異動段落指紋沿用原值。
    # 先寫 .tmp 再 os.replace：中途被中斷也不會把人填了一半的表洗掉。
    dt.write_rows_csv(decisions, rows)
    for r in rows:
        if id(r) in existing:
            continue
        key = (dt.line_of(r["候選段次"]), dt.text_sha256(r["候選全文"]))
        if key in free:
            free.remove(key)      # 人刪掉的那一列被語意又帶回表上：沿用那一筆，不重複記
        else:
            entries.append({"候選段次": key[0], "候選全文SHA256": key[1]})
    sidecar["列"] = entries
    side_path = dt.sidecar_path_for(decisions)
    tmp = side_path + ".tmp"
    with io.open(tmp, "w", encoding="utf-8") as f:
        json.dump(sidecar, f, ensure_ascii=False, indent=2)
        f.write("\n")
    os.replace(tmp, side_path)
    return before, len(rows), len(semantic_rows)


def _pull_in_by_semantic(args, settings, folder):
    """batch-semantic 用：這一輪只讀過全文的本，語意交回檔裡有候選的，整套初比對拉進流程。
    回傳拉進來的規章名 list；中止回 None（已印原因）。"""
    import batch as bt
    import semantic_candidates as sc
    docs = bt.unaffected_docs(args.outdir)
    skip = set(docs)
    hits = []
    for name in sorted(skip):
        path = os.path.join(folder, "%s.csv" % name)
        if not os.path.isfile(path):
            continue
        try:
            if sc.read_results(path):
                hits.append(name)
        except sc.SemanticError as exc:
            say("[中止] %s：%s" % (name, exc))
            return None
    if not hits:
        return []
    runner = load_regdiff_runner()
    # 門檻沿用這一輪其他本的初比對（指紋檔的「比對參數」），找不到才退回預設
    params = _compare_params_with_fallback(runner, _batch_params(args.outdir))
    pulled = []
    for name in hits:
        doc = docs[name]
        if not os.path.isfile(doc["舊版"]):
            say("[中止] %s 語意有候選，但它的舊版不見了：%s" % (name, doc["舊版"]))
            return None
        t = _batch_full_compare(doc, args.outdir, args, settings, runner, params)
        if t is None:
            return None
        _write_batch_table(t, name, params)
        pulled.append(name)
        say("%s：本次沒放修訂版，但語意比對找到可能受影響的段落，已拉進流程（決定表裡看這幾列）" % name)
    bt.write_unaffected(args.outdir, [docs[n] for n in sorted(skip - set(pulled))])
    return pulled


def _batch_params(root):
    """這一輪批次初比對用的門檻（從任何一本決定表的指紋檔讀「比對參數」）。"""
    import batch as bt
    import decision_table as dt
    try:
        books = bt.list_books(root)
    except bt.BatchError:
        return None
    for _, outdir_doc in books:
        try:
            side = dt.read_sidecar(dt.sidecar_path_for(locate(outdir_doc, "連帶決定表.csv")[0]))
        except dt.DecisionTableError:
            continue
        params = side.get("比對參數") or {}
        if all(k in params for k in ("threshold", "top", "changed_top", "sentence_threshold")):
            return dict((k, params[k]) for k in ("threshold", "top", "changed_top", "sentence_threshold"))
    return None


SEMANTIC_SKIP = "略過.txt"


def cmd_batch_semantic(args, settings):
    """批次：把在別台電腦算好的語意候選一次併回各本（產出/2_Log檔案/語意候選/<規章名>.csv）。

    以前要逐本跑 semantic，而且要先跑一次批次指令把合一表上的決定寫回各本、併完再跑一次
    合回合一表。這一支本身就是批次指令：開始前、結束後會自動同步 產出/2_Log檔案/（見 main）。"""
    import batch as bt
    import decision_table as dt
    import semantic_candidates as sc
    _apply_workspace_defaults(args, settings)
    if not _require_output(args):
        return 1
    if not semantic_enabled(settings) and not getattr(args, "skip", False):
        say("語意比對（BGE-M3）：設定.html 關閉了，這一輪不做；要做就到 設定.html 打開「使用 BGE-M3」再跑 開始")
        return 0
    folder = os.path.abspath(args.semantic_dir) if args.semantic_dir else semantic_folder(args.outdir)
    skip_marker = os.path.join(semantic_folder(args.outdir), SEMANTIC_SKIP)
    if getattr(args, "skip", False):
        os.makedirs(os.path.dirname(skip_marker), exist_ok=True)
        with io.open(skip_marker, "w", encoding="utf-8") as f:
            f.write("這一輪不做語意比對（batch-semantic --略過）\n")
        say("這一輪不做語意比對：人工待辦不會再提醒；之後算好了照樣可以跑 %s 併入"
            % _cmd("語意併入", workspace_flag(args)))
        return 0
    if os.path.isfile(skip_marker):
        os.remove(skip_marker)
    import semantic_exchange as se
    import todo
    if not args.semantic_dir:
        # 帶回來的語意交換包（原位或 匯入/）：先把算好的 <規章名>.csv 取出來，底下照原本的做法併入
        try:
            back = se.returned(folder, todo.workspace_of(args.outdir))
        except se.ExchangeError as exc:
            say("[中止] %s" % exc)
            return 1
        if back:
            se.unpack(back[0], folder, back[1])
            say("從語意交換包取出 %d 本的結果：%s" % (len(back[1]), "、".join(back[1])))
    # 沒放修訂版、跨本也沒找到的本（這一輪只讀過全文）：語意在別台算出有候選的話，它就受影響了，
    # 先整套初比對、寫好決定表，拉進流程，下面再照常併入
    pulled = _pull_in_by_semantic(args, settings, folder)
    if pulled is None:
        return 1
    try:
        books = bt.list_books(args.outdir)
    except bt.BatchError as exc:
        say("[中止] %s" % exc)
        return 1
    done, missing = [], []
    for name, outdir_doc in books:
        path = os.path.join(folder, "%s.csv" % name)
        if not os.path.isfile(path):
            missing.append(name)
            continue
        table = locate(outdir_doc, "連帶決定表.csv")[0]
        try:
            before, after, count = _merge_semantic(table, path)
        except (dt.DecisionTableError, sc.SemanticError) as exc:
            say("[中止] %s：%s（前面 %d 本已併入）" % (name, exc, len(done)))
            return 1
        say("%s：語意候選 %d 筆，決定表 %d 列 → %d 列" % (name, count, before, after))
        done.append(name)
    if missing:
        say("沒有找到算好的檔，略過：%s（要的檔名是 %s/<規章名>.csv）"
            % ("、".join(missing), show_path(folder)))
        if done:
            # 交換包只帶回一部分：併進來的照用，剩下的本語意還是「還沒做」，繼續會停在這一站。
            # 講清楚兩條路，不然人只看到「下一站還是它」（審查 A8）
            say("這幾本的語意還沒算：把它們算完再帶回來跑 %s，或這一輪不等了跑 %s（併進來的照樣算數）"
                % (_cmd("語意併入", workspace_flag(args)), _cmd("語意併入", workspace_flag(args), "--略過")))
    if not done:
        say("[中止] 一本都沒有併入")
        # 不把別台電腦當預設解法（SKILL.md），只講兩個選擇
        say("語意候選還沒算：請使用者選「執行」（先檢查這台電腦能不能跑 BGE-M3）或「不執行」（跑 %s）"
            % _cmd("語意併入", workspace_flag(args), "--略過"))
        return 1
    say("語意找到的新候選已經併進各本，審查打包時一起交給 AI 判。")
    return 0


# ---------------------------------------------------------------------------
# batch：多本一起改
# ---------------------------------------------------------------------------

def _apply_workspace_defaults(args, settings):
    """batch、batch-apply、batch-finalize、batch-review-pack、batch-review-import
    共用：manifest／outdir（review 類是 outdir 那個位置參數）沒給時，退回工作區的
    固定路徑（匯入/規章清單.csv、產出/，見 workspace.paths）；有給就照給的，只補成
    絕對路徑。回傳這次解出來的 workspace.paths() 字典，呼叫端通常用不到，但「開始」
    要沿用同一份 p 印下一步指令，就不用自己再算一次。"""
    import workspace as ws
    root = ws.resolve_root(getattr(args, "workspace", ""), settings)
    p = ws.paths(root)
    _set_display_root(root)
    if not getattr(args, "manifest", None):
        args.manifest = p["清單"]
    if not getattr(args, "outdir", None):
        args.outdir = p["產出"]
    else:
        args.outdir = os.path.abspath(args.outdir)
    return p


def _require_output(args):
    """批次的後續站（語意併入、審查打包、審查匯入）要有這一輪的產出才能跑：沒有就印一句、回 False。
    以前沒有目前作業時 outdir 是 ""，`--略過` 的標記檔就寫進 cwd（skill 資料夾）還回報成功，
    之後真正的產出沒被標記、下一輪照樣問。"""
    outdir = getattr(args, "outdir", "") or ""
    if outdir and os.path.isdir(outdir):
        return True
    say("[中止] 還沒有這一輪的產出資料夾：先跑 開始（或直接跑 繼續，它會先開始）")
    return False


def _add_workspace_flag(p):
    """讓 --workspace 也能接在子命令名稱後面，不是只能放在最前面（配對／開始／批次類
    子命令印出的下一步指令都是「子命令 --workspace 根」這種順序）。預設用
    argparse.SUPPRESS：子命令自己的解析器如果沒吃到 --workspace，就不要去蓋掉最前面
    （頂層 parser）已經解出來的值——頂層與子解析器共用同一個 Namespace，子解析器
    自己的一般預設值（例如 ""）原本會在沒給的時候覆蓋掉頂層已經設好的值。"""
    p.add_argument("--workspace", default=argparse.SUPPRESS,
                   help="工作區根目錄；沒給就看設定.html（可放在子命令名稱前或後）")


def _add_max_chars_flag(p):
    """review-pack／batch-review-pack 的 --max-chars：一份審查包的字元數上限。

    只數區塊數（--per-file）切不住檔案大小：一個候選掛十幾處異動時，單一區塊就
    好幾萬字（實測單檔 13.7 萬字），貼進 AI 直接爆脈絡長度。0 表示不看字數。"""
    import review_pack as rp
    p.add_argument("--max-chars", dest="max_chars", type=int, default=rp.DEFAULT_MAX_CHARS,
                   help="一份 LLM審查包_NN.md 的字元數上限，預設 %d（0＝不限）"
                        % rp.DEFAULT_MAX_CHARS)


def _add_verbose_flag(p):
    p.add_argument("--詳細", "--verbose", dest="verbose", action="store_true",
                   help="每一本的比對過程照舊全部印在畫面上（預設只印每本一行，細節寫進 "
                        "各本的 產出/2_Log檔案/<規章名>/2_Log檔案/執行紀錄.txt）")


class BookLog(object):
    """批次裡一本的詳細輸出：預設收進 <本>/2_Log檔案/執行紀錄.txt，畫面只印一行進度。

    兩本各幾段的小規章，「開始」以前就印兩百多行，真正要看的彙總被淹在最後；
    十本就是上千行。每本的過程（Step 0.5～2 的報告、候選清單）改寫進各本自己的
    執行紀錄，畫面只留進度與最後的彙總。失敗時把那一本的最後幾行印出來，
    不用人去翻檔也看得到為什麼停。--詳細 照舊全部印在畫面上。
    """

    def __init__(self, outdir_doc, title, verbose=False):
        self.outdir_doc, self.title, self.verbose = outdir_doc, title, verbose
        self.buffer = io.StringIO()
        self._redirect = None

    def __enter__(self):
        if self.verbose:
            say("=" * 60)
            say(self.title)
            say("=" * 60)
        else:
            say("%s……" % self.title)
            self._redirect = contextlib.redirect_stdout(self.buffer)
            self._redirect.__enter__()
        return self

    def __exit__(self, *exc):
        from _common import tw_now, tw_today
        if self._redirect is not None:
            self._redirect.__exit__(*exc)
            text = self.buffer.getvalue()
            try:
                path = place(self.outdir_doc, "執行紀錄.txt")
                with io.open(path, "a", encoding="utf-8-sig") as f:
                    f.write("%s\n%s　%s\n%s\n%s\n" % ("=" * 60, self.title,
                                                      tw_now().strftime("%Y-%m-%d %H:%M"),
                                                      "=" * 60, text))
            except OSError:
                pass      # 紀錄寫不進去不能讓這一本失敗；失敗時照樣會印最後幾行
        return False

    def show_tail(self, n=15):
        """失敗時把這一本最後幾行印到畫面上（--詳細 時本來就印過了）。"""
        if self.verbose:
            return
        for line in self.buffer.getvalue().rstrip().splitlines()[-n:]:
            say("    " + line)
        say("    （完整過程見 2_Log檔案/%s/2_Log檔案/執行紀錄.txt）" % os.path.basename(self.outdir_doc))


def _add_batch_flags(p, runner):
    """batch、開始 共用的旗標（跨本連帶門檻）；同一份定義兩邊都掛，避免以後改一邊
    漏改另一邊。"""
    p.add_argument("--semantic-dir", dest="semantic_dir", default=None,
                   help="放 <規章名>.csv 的資料夾（手動算好的語意候選）")
    p.add_argument("--threshold", type=float, default=None)
    p.add_argument("--top", type=int, default=None)
    p.add_argument("--changed-top", dest="changed_top", type=int, default=8)
    p.add_argument("--sentence-threshold", dest="sentence_threshold", type=float,
                   default=runner.fuzzy.DEFAULT_SENTENCE_THRESHOLD)


def _doc_args(runner, doc, outdir_doc, extra_argv=(), **overrides):
    """用 regdiff 的參數定義做一個 Namespace，跟單本 compare／finalize 同一套預設值。"""
    parser = argparse.ArgumentParser()
    runner.add_compare_arguments(parser)
    argv = [doc["舊版"], doc["草稿"], "--outdir", outdir_doc]
    if doc["發布根目錄"]:
        argv += ["--baseline-release", doc["發布根目錄"]]
    ns = parser.parse_args(argv + list(extra_argv))
    ns.semantic = None
    ns.workspace = ""
    for key, value in overrides.items():
        setattr(ns, key, value)
    return ns


SEMANTIC_FOLDER = "語意候選"


def semantic_folder(root):
    """批次手動語意的交換資料夾：產出/2_Log檔案/語意候選/（<規章名>_語意輸入.json 與算好的 <規章名>.csv）。"""
    from _common import SYSTEM_DIR
    return os.path.join(root, SYSTEM_DIR, SEMANTIC_FOLDER)


def _semantic_manual_lines(root, names, ws):
    """這台電腦算不了語意候選時要印的步驟。SKILL.md 的規則：沒有模型時只問使用者「執行／不執行」，
    不把別台電腦當預設解法。"""
    import todo
    workspace = todo.workspace_of(root)
    skip = _cmd("語意併入", ws if workspace else root, "--略過")
    # 檢查指令只看套件與模型在不在、不載模型；它說能跑時會自己印出算語意的那一行（semantic_candidates.check_environment）。
    # 以前這裡只寫「先檢查」，沒印指令，AI 只能用猜的
    check = 'python scripts/semantic_candidates.py --檢查 %s' % (
        '--workspace "%s"' % workspace if workspace else '--folder "%s"' % semantic_folder(root))
    after = _cmd("繼續", ws) if workspace else _cmd("語意併入", root)
    return ["語意候選（BGE-M3）：這台電腦沒有設定模型（%d 本還沒做語意比對），請使用者選「執行」或「不執行」：" % len(names),
            "  不執行：跑 " + skip,
            "  執行：先跑 " + check + "（只檢查套件與模型、不跑模型），把結果貼回來；",
            "        它說能跑時會印出算語意的那一行，算完再跑 " + after + " 併入"]


def _batch_semantic(target, all_changes, tname, settings, args, exchange_folder):
    """一本的語意候選（異動＝所有本）；依序試 --semantic-dir 交回檔、本機模型。

    回傳 (rows, needs_manual)。needs_manual 只有在「沒用到 --semantic-dir 的檔，
    而且這台電腦沒設模型路徑或模型載不起來」時才是真；模型跑過但一筆都沒中不算。
    算出來的列直接併進決定表，不另外落檔。這台算不了的才寫一份語意輸入進交換資料夾
    （exchange_folder＝產出/2_Log檔案/語意候選/）帶去別台算——以前每本自己的 2_Log檔案/ 一份、
    交換資料夾又一份，兩份一模一樣；這台算得了的那一份根本沒人讀。"""
    import semantic_candidates as sc
    if not semantic_enabled(settings):
        _say_semantic_off()
        return [], False             # 設定關了：不算、不寫語意輸入，人工待辦也就不會停下來問
    draft = target["doc"]["草稿"]
    draft_sha = file_sha256(draft)
    if getattr(args, "semantic_dir", None):
        path = os.path.join(args.semantic_dir, tname + ".csv")
        if os.path.isfile(path):
            try:
                rows = sc.read_results(path, expected_sha=draft_sha)
                say("  語意候選：讀入 %s（%d 筆）" % (path, len(rows)))
                return rows, False
            except sc.SemanticError as exc:
                say("  [中止] 語意候選檔不能用：%s" % exc)
                raise
    embed = _semantic_scorer(settings, getattr(args, "cache_dir", "") or None)
    _warn_dense_only_threshold(embed, settings)
    if embed is None:
        os.makedirs(exchange_folder, exist_ok=True)
        sc.write_input(os.path.join(exchange_folder, "%s_語意輸入.json" % tname), draft, draft_sha,
                       all_changes, target["outcome"]["new_paragraphs"], target_name=tname)
        return [], True
    rows = sc.find_candidates(embed, all_changes, target["outcome"]["new_paragraphs"],
                              _semantic_threshold(settings),
                              setting_int(settings, "語意最多幾筆", sc.DEFAULT_TOP), target_name=tname,
                              reranker=_semantic_reranker(settings, getattr(args, "cache_dir", "") or None),
                              rerank_threshold=_rerank_threshold(settings))
    return rows, False


_SCORERS = {}
_RERANKERS = {}
_SEMANTIC_OFF_SAID = []
_DENSE_WARNED = []


def _warn_dense_only_threshold(scorer, settings):
    """設定.html 的「語意門檻」是給三分數合併用的（0.70 左右）；FlagEmbedding 載不起、退回只有 dense 的
    sentence-transformers 時，無關句也有 0.70～0.72，照填的門檻會抓一堆無關的。退回時講一聲（審查 B4）。"""
    import semantic_candidates as sc
    if _DENSE_WARNED or scorer is None or not isinstance(scorer, sc.DenseScorer):
        return
    _DENSE_WARNED.append(True)
    threshold = _semantic_threshold(settings)
    if threshold is None:
        say("語意比對：這台只載得起 sentence-transformers（只有 dense），門檻用 dense 的預設 %.2f" % sc.DENSE_ONLY_THRESHOLD)
        return
    import notices as nt
    nt.notice(nt.WARNING, "設定.html 的「語意門檻」%.2f 是給 BGE-M3 三分數合併用的；這台只載得起 sentence-transformers"
                          "（只有 dense），同樣的門檻會多抓很多無關的段落。要用 dense 建議門檻 %.2f 以上，或把門檻留空"
              % (threshold, sc.DENSE_ONLY_THRESHOLD), "語意比對")


def semantic_enabled(settings):
    """設定.html「使用 BGE-M3」：預設開（沒有這一格、或留空都算開）；明確關掉才不做語意比對。"""
    return settings.get("使用BGE-M3", True) is not False


def _say_semantic_off():
    if not _SEMANTIC_OFF_SAID:
        _SEMANTIC_OFF_SAID.append(True)
        say("語意比對（BGE-M3）：設定.html 關閉了，這一輪不做（重排序也跟著不做）")


def _semantic_reranker(settings, cache_dir=None):
    """設定.html「語意重排序」打勾才載 bge-reranker-v2-m3（同一支程式只載一次）；沒開回 None。
    開了但這台找不到或載不起：發一則警告、這一輪不重排（BGE-M3 的候選照樣用），不擋整批。"""
    import notices as nt
    import semantic_candidates as sc
    if not semantic_enabled(settings) or not settings.get("語意重排序"):
        return None                  # BGE-M3 關了，重排序一定也關（它是排 BGE-M3 找到的候選）
    from _common import skill_path
    configured = skill_path(settings.get("重排序模型路徑"))        # v1.15.0：相對位置從 skill 資料夾算起
    path = sc.find_local_model(configured, sc.RERANKER_NAME)
    batch = setting_int(settings, "重排序批次", sc.RERANKER_BATCH)
    key = (path, cache_dir, batch)
    if key not in _RERANKERS:
        if path:
            say("語意重排序（%s）：%s" % (sc.RERANKER_NAME, path))
        reranker = sc.load_reranker(path, cache_dir, batch_size=batch) if path else None
        if reranker is None:
            nt.notice(nt.WARNING, "設定.html 開了「語意重排序」，但這台電腦%s %s：這一輪語意候選沒有重排序"
                      % ("載不起" if path else "找不到", sc.RERANKER_NAME), "語意比對")
        _RERANKERS[key] = reranker
    return _RERANKERS[key]


def _rerank_threshold(settings):
    """「重排序門檻」：重排序補進來的候選，重排分數至少要多少；留空＝排進前幾名就補。從來不刪 BGE-M3 找到的。"""
    value = settings.get("重排序門檻")
    if value in (None, ""):
        return None
    return float(value)


def _semantic_scorer(settings, cache_dir=None):
    """載好的語意模型（同一支程式只載一次）。以前每一本各載一次：七本就是七次、一次十秒。
    沒有模型或載不起來回 None。"""
    import semantic_candidates as sc
    model_path = _semantic_model_path(settings)
    if not model_path:
        return None
    batch = setting_int(settings, "語意批次", sc.DEFAULT_BATCH)
    key = (model_path, _semantic_recall_top(settings), _semantic_rerank_top(settings), cache_dir, batch)
    if key not in _SCORERS:
        _SCORERS[key] = sc.load_model(model_path, recall_top=key[1], cache_dir=cache_dir, rerank_top=key[2],
                                      batch_size=batch)
    return _SCORERS[key]


_MODEL_ANNOUNCED = []


def _semantic_model_path(settings):
    """語意模型路徑：設定.html 有填用它，沒填（或填的不在）就自動找這台電腦常見的位置（見
    semantic_candidates.find_local_model）。自動找到時講一次用的是哪一份。"""
    import semantic_candidates as sc
    from _common import skill_path
    configured = skill_path(settings.get("語意模型路徑"))          # v1.15.0：相對位置從 skill 資料夾算起
    path = sc.find_local_model(configured)
    if path and path != configured and not _MODEL_ANNOUNCED:
        _MODEL_ANNOUNCED.append(path)
        say("語意模型（BGE-M3）：設定.html 沒填%s，自動找到 %s"
            % ("（或填的路徑不在）" if configured else "", path))
    if path and not _SLOW_ANNOUNCED:
        # v1.24.0：第一次算語意要很久（實測 7 本、CPU 約 45 分鐘），以前只有進度條，看起來像當掉
        _SLOW_ANNOUNCED.append(path)
        say("語意比對要算一陣子：沒有顯示卡的電腦，幾本手冊第一次大約 30–60 分鐘（算過的段落會記住，下一次快很多）；"
            "算完會自己往下做，中間不用動它。")
    return path


_SLOW_ANNOUNCED = []


def _batch_full_compare(doc, outdir, args, settings, runner, params, verbose=False, health=False):
    """批次裡整套初比對一本（寫這一本自己的過程檔，還不寫決定表）。回傳這一本的狀態；
    失敗回 None（已印「[中止]」）。cmd_batch 與 batch-semantic（語意找到沒改的本受影響時）共用。
    health＝體檢：沒有修訂版，拿現行版當草稿跑（異動 0），單本的檢查（條文檢查、引用、外部法規）照樣全部做。"""
    import notices as nt
    name = doc["規章名"]
    outdir_doc = book_dir(outdir, name, legacy=False)
    log = BookLog(outdir_doc, ("體檢　%s" % name) if health else
                  "批次　%s" % name + ("" if doc["有草稿"] else "（本次不修改，只看別本的改動）"),
                  verbose)
    ns = _doc_args(runner, doc, outdir_doc, ["--threshold", str(params["threshold"]), "--top", str(params["top"]),
                                             "--changed-top", str(params["changed_top"]),
                                             "--sentence-threshold", str(params["sentence_threshold"])],
                   title=table_title(name), health=health)
    # 裁定 7：批次裡沒改的本用「提醒」不用「警告」——十本裡有兩本這次沒動很正常，
    # 用警告會讓整批的結論被一件正常的事翻掉。沒有草稿的本另外講清楚原因，
    # 不然那則提醒會寫成「可能拿錯檔」，但它其實是照設計拿舊版當草稿在跑。
    ns.zero_change_level = nt.REMINDER
    if not doc["有草稿"]:
        # 清單裡沒放新版草稿＝這一本本次不修改（配對時標「沒改」），0 異動是預期的，
        # 不發提醒。以前發「草稿出來之後要再跑一次」，跟配對講的「沒改」互相矛盾，
        # 人會以為自己漏放了檔。這件事改由批次摘要的「本次不修改 N 本」講。
        ns.zero_change_level = None
    # 這裡先不寫表：整批任何一本的第 0、1 步沒過就中止，不留半套決定表。
    # 本次不修改的本（被別本的改動拉進來）：讀檔提醒跟這一輪無關，不印
    import _common as cm
    # 體檢的本沒有草稿，但讀檔提醒（文字方塊、自動編號算不出來）正是體檢要看的東西，不收音
    quiet = cm.quiet_read_notices(cm._QUIET_READ[0] or (not doc["有草稿"] and not health))
    try:
        with log:
            rc, outcome, rows, _ = _compare_core(ns, settings)
    finally:
        cm.quiet_read_notices(quiet)
    if rc:
        log.show_tail()
        say("[中止] %s 初比對失敗，整批停止。" % name)
        return None
    baseline = outcome["baseline"]
    results = outcome["results"]
    new_line_ids = baseline.annotate_results(results) if baseline else {}
    changes = []
    for r in results:
        if r["type"] in ("added", "modified") and r.get("new_text"):
            ids = r.get("spec_ids") or []
            changes.append({"條文ID": "、".join(ids), "ref": r.get("ref") or "",
                            "old_text": r.get("old_text") or "", "new_text": r["new_text"],
                            "focus_new_text": r.get("focus_new_text") or "",
                            "focus_old_text": r.get("focus_old_text") or "",
                            "段次": r.get("new_index") or 0,
                            "positions": [baseline._position(i) for i in ids] if baseline else []})
    # 跨本找候選用：新增、修改之外再加整段刪除（拿舊文去別本找同一件義務）。
    # changes 本身只收新增、修改，語意與統計照舊；兩份清單共用前段的同一批異動，
    # select_cross 用（來源本, 第幾處）找回異動時要拿 cross_sources。
    deleted = [{"條文ID": "、".join(r.get("spec_ids") or []), "ref": r.get("ref") or "",
                "old_text": r["old_text"], "new_text": "", "deleted": True, "段次": 0,
                "old_index": r.get("old_index") or 0}
               for r in results if r["type"] == "deleted" and (r.get("old_text") or "").strip()]
    # 這一本的提醒收走（各本的 提醒.txt 已經由 run_compare 寫進各自的子資料夾）。
    # 不收走的話下一本的提醒會連著前一本一起算，批次摘要的數字就對不上。
    return {"doc": doc, "outdir": outdir_doc, "outcome": outcome, "rows": rows,
            "baseline": baseline, "new_line_ids": new_line_ids, "changes": changes,
            "cross_sources": changes + deleted, "跨本來自": set(), "提醒": nt.drain()}


def _write_batch_table(t, name, params, changed_texts=None):
    """寫一本的連帶決定表（與指紋檔）和異動清單。各本的產出跟單本 compare 走同一套去向：
    決定表 → 2_Log檔案/，指紋與異動清單 → 2_Log檔案/。"""
    import decision_table as dt
    if changed_texts is None:
        changed_texts = [r["new_text"] for r in t["outcome"]["results"] if r["type"] in ("added", "modified")]
    csv_path = place(t["outdir"], "連帶決定表.csv")
    dt.write_table(t["rows"], csv_path, dt.sidecar_path_for(csv_path), t["doc"]["草稿"],
                   changed_texts, extra={"規章": name}, params=params, old_path=t["doc"]["舊版"])
    dt.write_change_list(t["outcome"]["results"], place(t["outdir"], "異動清單.json"))
    # 這一本的現行規章、修訂版在哪裡：人工待辦拿它跟決定表指紋比，發現「開始」之後被改過就叫人重跑開始
    # （以前改了修訂版，套用會失敗，人工待辦卻一直叫人重跑套用）
    # v1.15.0 起寫成相對這個檔所在資料夾的位置：工作區整個搬家、給別人用都還找得到
    from _common import to_record
    target = place(t["outdir"], "輸入來源.json")
    base = os.path.dirname(os.path.abspath(target))
    with io.open(target, "w", encoding="utf-8") as f:
        json.dump({"舊版": to_record(t["doc"]["舊版"], base), "草稿": to_record(t["doc"]["草稿"], base)},
                  f, ensure_ascii=False)
    return csv_path


def cmd_batch(args, settings):
    import batch as bt
    import decision_table as dt
    import fuzzy_duplicate_finder as fuzzy
    import notices as nt
    import semantic_candidates as sc
    import workspace as ws
    from _common import load_synonyms, read_paragraphs_with_kinds
    # item3：outdir 是不是「呼叫端明給的」，要在 _apply_workspace_defaults 把它補成
    # 工作區預設值*之前*判斷——判斷完才能補。cmd_start 呼叫這裡之前已經自己歸檔過
    # 一次（archive_previous），且會把 ns.outdir 明確設成 p["產出"]（見 cmd_start），
    # 所以從 cmd_start 進來時 outdir_was_explicit 一定是 True，不會落進下面「省略
    # outdir」的分支、不會歸檔第二次；只有使用者直接跑 `batch`（不給 --outdir）
    # 才會落到這裡幫忙歸檔上一輪，不然直接跑 batch 會把上一輪的產出整個蓋掉。
    outdir_was_explicit = bool(getattr(args, "outdir", ""))
    p = _apply_workspace_defaults(args, settings)
    try:
        docs = bt.read_manifest(args.manifest)
    except bt.BatchError as exc:
        say("[中止] %s" % exc)
        return 1
    if not outdir_was_explicit and not ws.uses_legacy_layout(p["根"]):
        try:
            args.outdir = ws.begin_output(p["根"])
            outdir_was_explicit = True
            p = ws.paths(p["根"], args.outdir)
        except ws.WorkspaceError as exc:
            say("[中止] %s" % exc)
            return 1
    outdir = args.outdir
    # no 10：批次的每一本輸入檔由 bt.read_manifest 驗過了，產出根目錄這裡驗一次
    # 就夠——不然歸檔完、第一本跑到一半才發現整個產出根目錄寫不進去。
    problem = precheck(outdir)
    if problem:
        say("[中止] %s" % problem)
        return 1
    if not outdir_was_explicit:
        names = [doc["規章名"] for doc in docs]
        try:
            moved = ws.archive_previous(p["根"], names)
        except ws.WorkspaceError as exc:
            say("[中止] %s" % exc)
            return 1
        if moved:
            say(archive_line(moved))
    # batch.list_books、review_pack、review_report 固定讀
    # <outdir>/2_Log檔案/輸入/規章清單.csv：只放這一份（固定檔名）。以前還照原檔名再留一份、
    # 外加一個沒人讀的 輸入指紋.json——每本自己的 輸入/ 才有指紋要核對。
    staged = place(outdir, "輸入")
    os.makedirs(staged, exist_ok=True)
    if os.path.abspath(args.manifest) != os.path.abspath(os.path.join(staged, "規章清單.csv")):
        shutil.copy2(args.manifest, os.path.join(staged, "規章清單.csv"))
    runner = load_regdiff_runner()
    synonyms = load_synonyms()
    threshold = args.threshold if args.threshold is not None else fuzzy.DEFAULT_THRESHOLD
    top = args.top if args.top is not None else fuzzy.DEFAULT_TOP

    state = {}
    # 體檢（cmd_health）：這一輪沒有修訂版，每一本都整套跑（拿現行版當草稿，異動 0），
    # 單本的條文檢查、引用、外部法規、結構提醒才會做；跨本引用也靠每一本都當「來源」才查得到
    health = bool(getattr(args, "health", False)) or bt.is_health_round(outdir)
    args.health = health
    if health:
        # 體檢只看現行版：工作區裡就算已經放了修訂版（之後要比對用的），這一輪也不比，每一本都拿現行版當草稿
        docs = [dict(doc, 草稿=doc["舊版"], 有草稿=False) for doc in docs]
    # 沒放修訂版（也沒有規格包）的本：只讀全文，當別本改動的「被查對象」。
    # 以前每一本都整套跑（自己比自己、條文檢查、對照表……），五十本只改三本時大部分時間都在白跑；
    # 它們唯一要做的事是讓別本的改動找得到它（連帶、引用）。找到了才整套拉進流程，見下面。
    light = {}
    verbose = getattr(args, "verbose", False)
    params = {"threshold": threshold, "top": top, "changed_top": args.changed_top,
              "sentence_threshold": args.sentence_threshold}
    # 快取（語意向量、AI 查證結果）放在 skill 資料夾的 memoization/（見 batch.cache_dir）
    args.cache_dir = bt.cache_dir()
    # 要整套比對的本同時跑（見 batch_parallel）：一次全部送出去，下面照清單順序一本一本收，
    # 畫面輸出、提醒、中途失敗都跟一本一本跑一樣。只有一本或開不了行程時照舊一本一本跑。
    import batch_parallel as bp
    parallel = bp.ParallelCompare(docs, outdir, args, settings, params, verbose, _DISPLAY_ROOT[0], book_dir,
                                  all_books=health)
    parallel.start()
    try:
        for doc in docs:
            name = doc["規章名"]
            if not doc["有草稿"] and not doc["發布根目錄"] and not health:
                # 這次沒修改的本只當別本改動的被查對象：它的讀檔提醒（文字方塊、自動編號）跟這一輪無關
                import _common as cm
                quiet = cm.quiet_read_notices(True)
                try:
                    paragraphs, kinds = read_paragraphs_with_kinds(doc["舊版"])
                except (ValueError, OSError, UnicodeDecodeError) as exc:
                    say("[中止] %s 舊版讀不出來：%s，整批停止。" % (name, exc))
                    return 1
                finally:
                    cm.quiet_read_notices(quiet)
                nt.drain()
                if not paragraphs:
                    say("[中止] %s 舊版一段文字都讀不到（%s），整批停止。" % (name, doc["舊版"]))
                    return 1
                light[name] = {"doc": doc, "outcome": {"new_paragraphs": paragraphs, "new_kinds": kinds,
                                                       "results": []},
                               "baseline": None, "new_line_ids": {}, "changes": [], "跨本來自": set()}
                continue
            serial = lambda: _batch_full_compare(doc, outdir, args, settings, runner, params, verbose,
                                                 health=health)
            t = parallel.take(name, serial) if name in parallel.futures else serial()
            if t is None:
                return 1
            state[name] = t
    finally:
        parallel.abandon()           # 正常跑完只是收掉行程；中途停下來時把還沒收的本當成沒跑過

    source_indexes = {}
    cross_found = {}
    # 引用比對用的名稱：規章名是檔名（常帶「(現行)」「_1130501」），另外收去掉版本字的名稱與舊版標題；
    # 本批所有規章的名稱一起比，「北區保險業務員招攬作業要點」才不會被當成「保險業務員招攬作業要點」
    cite_names = bt.CitationNames(dict(
        (name, x["outcome"].get("old_paragraphs") or x["outcome"]["new_paragraphs"])
        for name, x in list(state.items()) + list(light.items())))
    # 被查對象＝每一本（含只讀全文的）；來源＝有整套跑的本（只讀全文的本沒有改動，當來源找不到東西）
    for tname, t in list(state.items()) + list(light.items()):
        cross = []
        for sname, s in state.items():
            if sname == tname:
                continue
            found = []
            if s["cross_sources"]:
                found = bt.cross_candidates(sname, s["cross_sources"], t["outcome"]["new_paragraphs"],
                                            synonyms, threshold, top, args.changed_top,
                                            sentence_threshold=args.sentence_threshold,
                                            target_kinds=t["outcome"].get("new_kinds"))
            # 明確引用：直接讀 B 本的字找「A 本名稱＋第X條／第X點／章節」（連只刪不改的 A 本也要看）。
            # B 本有規格包也一樣讀字——以前有規格包就只對引用.csv，刪除、改號進不來，30 本只抓到 1/27；
            # 引用.csv 只補讀字沒認出來的段。B 本草稿已經照 A 本新號改好的引用不報（見 batch.cross_citations）
            found += bt.cross_citations(sname, s["outcome"], t["outcome"], cite_names, t["baseline"],
                                        t["new_line_ids"], source_indexes)
            if found:
                t["跨本來自"].add(sname)
            cross += found
        cross_found[tname] = cross
    # 跨本候選分層＋全域上限（見 batch.select_cross）：規章本數再多，列數只跟改了幾處有關
    unlisted = {}
    cross_found, cross_dropped = bt.select_cross(
        cross_found, dict((name, s["cross_sources"]) for name, s in state.items()),
        setting_int(settings, "跨本每處上限", bt.CROSS_TOP), unlisted=unlisted,
        strong_cap=setting_int(settings, "跨本舊值上限", bt.CROSS_STRONG_TOP))
    for name in list(light):
        light[name]["跨本來自"] = set(r["異動條文ID"].split("：")[0] for r in cross_found[name]
                                  if r.get("異動條文ID"))
    for tname, t in state.items():
        t["跨本來自"] = set(r["異動條文ID"].split("：")[0] for r in cross_found[tname] if r.get("異動條文ID")) \
            if cross_found[tname] else set()
        t["rows"] = dt.add_cross(t["rows"], cross_found[tname])

    all_changes = [{"段次": c["段次"], "全文": c["new_text"], "舊全文": c.get("old_text") or "",
                    "條文ID": c["條文ID"] or c.get("ref") or "", "規章": name}
                   for name, s in state.items() for c in s["changes"]]
    for name, s in state.items():
        all_changes += _semantic_deleted(s["outcome"]["results"], name)
    manual = []
    # 只讀全文的本也要給語意比對找：沒有自己的資料夾，語意輸入直接寫進語意候選交換資料夾
    for lname, t in light.items():
        t["語意"] = []
        if not all_changes:
            continue
        try:
            t["語意"], needs_manual = _batch_semantic(
                t, all_changes, lname, settings, args, semantic_folder(outdir))
        except sc.SemanticError:
            return 1
        if needs_manual:
            manual.append(lname)
    # 被別本的改動找到（跨本連帶、引用、語意）的才整套拉進流程：它這次也可能要跟著改
    for lname, t in light.items():
        if not (cross_found[lname] or t["語意"]):
            continue
        full = _batch_full_compare(t["doc"], outdir, args, settings, runner, params, verbose)
        if full is None:
            return 1
        full["rows"] = dt.add_cross(full["rows"], cross_found[lname])
        full["跨本來自"] = t["跨本來自"]
        full["語意"] = t["語意"]
        state[lname] = full
    # 這台已經算完語意的本，交換資料夾裡不能留上一輪的語意輸入：留著就被當成「要帶去別台算、
    # 還沒帶回來」，繼續永遠停在「語意比對還沒做」（B20）。要人工算的（manual）才留著
    for lname in light:
        staged_input = os.path.join(semantic_folder(outdir), "%s_語意輸入.json" % lname)
        if lname not in manual and os.path.isfile(staged_input):
            os.remove(staged_input)
    untouched = [name for name in light if name not in state]
    # 有候選、但全部因為上限沒列的本（unlisted）：決定表沒有它的列，也不能說成「一處都沒找到」。
    # 段數記進 未受影響規章.json（1_結果彙整的 本次未修改.txt 照它分開講）
    capped = dict((name, len(entries)) for name, entries in unlisted.items() if entries)
    bt.write_unaffected(outdir, [dict(light[name]["doc"], 上限未列段數=capped.get(name, 0)) for name in untouched])
    state = dict((doc["規章名"], state[doc["規章名"]]) for doc in docs if doc["規章名"] in state)
    stats = []
    # 跨本列的「異動內容」要到來源本查那一處異動
    change_books = dict((name, {"changes": dt.change_items(s["outcome"]["results"])})
                        for name, s in state.items())
    for tname, t in state.items():
        if "語意" in t:
            sem_rows, needs_manual = t["語意"], False      # 拉進流程之前已經算過（手動的也已登記）
        else:
            try:
                sem_rows, needs_manual = _batch_semantic(t, all_changes, tname, settings, args,
                                                         semantic_folder(outdir))
            except sc.SemanticError:
                return 1
        if sem_rows:
            t["rows"] = dt.add_semantic(t["rows"], sem_rows)
        if needs_manual and all_changes:
            # 語意輸入已經寫在 產出/2_Log檔案/語意候選/（只有這一份）：換到有模型的電腦算時帶過去，
            # 算好的 <規章名>.csv 放回同一個資料夾，batch-semantic 一行併入
            manual.append(tname)
        carried, had_previous = _assist_rows(t["rows"], t["outdir"],
                                             change_books[tname]["changes"], change_books)
        changed_texts = [r["new_text"] for r in t["outcome"]["results"] if r["type"] in ("added", "modified")]
        # 各本的產出跟單本 compare 走同一套去向：決定表 → 2_Log檔案/，
        # 指紋與異動清單 → 2_Log檔案/。（批次自己那幾個根層級的檔留給 Task 4。）
        _write_batch_table(t, tname, params, changed_texts)
        # 一列只算一次（小瑕疵 13）：跟單本 compare 共用 source_distribution，
        # 批次摘要與畫面上那一行括號內的數字加起來才等於候選列數。
        # 以前這裡是「每列的來源逐個標籤各記一次」，同時被相似度與語意抓到的列
        # 會被算兩遍，總和大於候選數，人會以為表上少了幾列。
        dist = source_distribution(t["rows"])
        # 實質異動要連刪除一起算（t["changes"] 只收 added／modified，見下面那段註解）：
        # 以前整本只刪了一點的那一本，摘要寫「實質異動 0」
        substantive = sum(1 for r in t["outcome"]["results"]
                          if r["type"] in ("added", "deleted", "modified"))
        results = t["outcome"]["results"]
        stats.append({"規章名": tname, "有草稿": t["doc"]["有草稿"], "體檢": health, "實質異動": substantive,
                      "編號調整": sum(1 for r in results if r["type"] == "renumbered"),
                      "僅字形": sum(1 for r in results if r["type"] == "cosmetic"),
                      "候選": len(t["rows"]), "來源分佈": dist, "跨本來自": sorted(t["跨本來自"]),
                      # t["changes"] 只收 added／modified（跨本比對要新文），刪除型不在裡面，
                      # 拿它判「這本有沒有改」會把「整本只刪了幾條」誤報成沒改。
                      # 零異動一律用 run_compare 自己算的那一個旗標。
                      "零異動": bool(t["outcome"].get("零異動")),
                      "沿用": carried if had_previous else None,
                      "提醒": t["提醒"]})

    pairs_line = law_line = ""
    if health:
        # 體檢多做一件事：同一批規章裡講同一件事的兩段（同本不同處、或不同本）找出來，審查打包交給 AI 判
        # 一致／矛盾／重複／無關（見 health_check）。字面相似一定做；語意相近要有 BGE-M3 才做
        import health_check as hc
        scorer = _semantic_scorer(settings, args.cache_dir) if semantic_enabled(settings) else None
        pair_stats = {}
        try:
            pairs, families = hc.find_items(dict((name, s["outcome"]["new_paragraphs"]) for name, s in state.items()),
                                            scorer=scorer, max_pairs=setting_int(settings, "體檢最多幾對", hc.MAX_PAIRS),
                                            stats=pair_stats)
        except Exception as exc:          # 找候選失敗不能讓整輪體檢作廢：講一聲、這一輪沒有這一頁
            nt.notice(nt.WARNING, "重複／矛盾候選沒有算出來（%s：%s）；這一輪的體檢報告「條文比對報告」沒有重複／矛盾的列"
                      % (type(exc).__name__, exc), "體檢")
            pairs, families = [], []
        hc.write_candidates(outdir, pairs, dropped=pair_stats.get("沒列", 0), families=families)
        law_line = _health_law_step(outdir, args, settings, scorer)
        exact = sum(1 for p in pairs if p["字面分數"] != "" and p["字面分數"] >= 99.5)
        pairs_line = "重複／矛盾候選 %d 對%s（有差異的 %d、一模一樣的 %d；字面找到 %d、語意找到 %d%s%s）：審查打包時交給 AI 判一致／矛盾／重複" % (
            len(pairs), ("＋%d 個家族（共 %d 段，同一個範本改出來的好幾段，整個家族一起判）"
                         % (len(families), sum(len(f["成員"]) for f in families)) if families else ""),
            len(pairs) - exact, exact,
            sum(1 for p in pairs if "字面" in p["找法"]), sum(1 for p in pairs if "語意" in p["找法"]),
            _pair_cut_text(pair_stats),
            "" if scorer is not None else "；這台沒有 BGE-M3，只做字面")
    # 批次摘要是「人要看」的那一份 → 產出根目錄的 2_Log檔案/（見 _common.FILE_HOMES）。
    # write_batch_summary 的簽名不變（呼叫端給路徑），去向一律由 place 決定。
    summary_path = bt.write_batch_summary(place(outdir, "批次摘要.txt"), stats)
    if pairs_line:
        with io.open(summary_path, "a", encoding="utf-8-sig") as f:
            f.write("\n" + pairs_line + "\n")
    if law_line:
        with io.open(summary_path, "a", encoding="utf-8-sig") as f:
            f.write("\n" + law_line + "\n")
    dropped_total = sum(cross_dropped.values())
    dropped_line = ""
    if dropped_total:
        dropped_line = ("跨本分數較低的候選另有 %d 段沒列（只是文字相似的：每一處異動、每一種找法，全部規章合計只列前 %d 段；"
                        "舊值原樣還在的：%d 分以上一律列，其餘每處合計最多 %d 段；明確引用一律列）"
                        % (dropped_total, setting_int(settings, "跨本每處上限", bt.CROSS_TOP),
                           int(bt.CROSS_STRONG_SURE), setting_int(settings, "跨本舊值上限", bt.CROSS_STRONG_TOP)))
        with io.open(summary_path, "a", encoding="utf-8-sig") as f:
            f.write("\n" + dropped_line + "\n")
    untouched_clean = [name for name in untouched if not capped.get(name)]
    untouched_line = ""
    if untouched_clean:
        untouched_line = ("沒放修訂版、也沒有被別本的改動影響到 %d 本：%s（只讀過全文找連帶與引用，"
                          "一處都沒找到，後面的步驟不處理）" % (len(untouched_clean), "、".join(untouched_clean)))
        with io.open(summary_path, "a", encoding="utf-8-sig") as f:
            f.write("\n" + untouched_line + "\n")
    # 沒放修訂版、決定表一列都沒有，但有候選是被上限擠掉的：單獨講，不跟「一處都沒找到」「核對過」混在一起
    capped_books = [name for name in untouched if capped.get(name)] + [
        s["規章名"] for s in stats if not s.get("有草稿", True) and not s["候選"] and capped.get(s["規章名"])]
    capped_line = ""
    if capped_books:
        capped_line = ("沒放修訂版、決定表沒有它們的列，但有跨本候選因為上限沒列 %d 本：%s（都是分數較低、只是文字相似的；"
                       "要看就把設定.html「跨本每處上限」「跨本舊值上限」調高或設 0 再跑一次）"
                       % (len(capped_books), "、".join("%s（%d 段）" % (name, capped[name]) for name in capped_books)))
        with io.open(summary_path, "a", encoding="utf-8-sig") as f:
            f.write("\n" + capped_line + "\n")
    if manual:
        # 這台算不了：每一本的語意輸入打成一個交換包（使用者選「執行」時拿它算，見 semantic_exchange）
        import semantic_exchange as se
        se.pack(semantic_folder(outdir), {"門檻": _semantic_threshold(settings),
                                                     "最多幾筆": setting_int(settings, "語意最多幾筆", sc.DEFAULT_TOP),
                                                     "粗篩": _semantic_recall_top(settings),
                                                     "取前幾名": _semantic_rerank_top(settings),
                                                     "重排序": bool(settings.get("語意重排序")),
                                                     "重排序門檻": _rerank_threshold(settings),
                                                     "批次": setting_int(settings, "語意批次", sc.DEFAULT_BATCH),
                                                     "重排序批次": setting_int(settings, "重排序批次",
                                                                              sc.RERANKER_BATCH)})
    manual_lines = _semantic_manual_lines(outdir, manual, workspace_flag(args)) if manual else []
    if manual_lines:
        # 每一本一行、路徑都填好，照抄就能跑；畫面與批次摘要印同一份
        with io.open(summary_path, "a", encoding="utf-8-sig") as f:
            f.write("\n" + "\n".join(manual_lines) + "\n")
    say("")
    say("=" * 60)
    say("體檢讀檔完成" if health else "批次初比對完成")
    say("=" * 60)
    for s in stats:
        # 警告（例如章節重編後指錯的引用）要在這一行就看得到，不能跟一般提醒混成一個數字
        warned = len(nt.warnings(s.get("提醒") or []))
        if health:
            # v1.24.0：體檢沒有修訂版，「實質異動 0、候選 0」這種比對用語只會讓人以為出錯了
            say("%s：讀好了，提醒 %d 則%s" % (s["規章名"], len(s.get("提醒") or []),
                                         "（其中警告 %d 則，要處理）" % warned if warned else ""))
            continue
        say("%s：實質異動 %d（另有編號調整 %d、僅字形／空白差異 %d，不算實質異動）、候選 %d（%s）%s%s，提醒 %d 則%s" % (
            s["規章名"], s["實質異動"], s.get("編號調整", 0), s.get("僅字形", 0), s["候選"],
            _source_counts_line(s["來源分佈"]),
            "，跨本來自 " + "、".join(s["跨本來自"]) if s["跨本來自"] else "",
            "，沿用上一輪決定 %d 列" % s["沿用"] if s.get("沿用") is not None else "",
            len(s.get("提醒") or []),
            "（其中警告 %d 則，要處理）" % warned if warned else ""))
    kept = [s["規章名"] for s in stats if not s.get("有草稿", True) and not health]
    zero_books = [s["規章名"] for s in stats if s.get("零異動") and s.get("有草稿", True)]
    hit = [s["規章名"] for s in stats if not s.get("有草稿", True) and s["候選"] and not health]
    if pairs_line:
        say(pairs_line)
    if law_line:
        say(law_line)
    # 「照規格包核對過、沒有要跟著改的列」只講真的一段候選都沒有的（被上限擠掉的另外講，見 capped_line）
    checked = [name for name in kept if name not in hit and not capped.get(name)]
    if hit:
        say("本次不修改、但被別本的改動影響到 %d 本：%s（沒放修訂版；比對報告的條文比對報告有它們的列，要不要跟著改看那幾列）"
            % (len(hit), "、".join(hit)))
    if checked:
        # 有規格包的本都會整本拿來核對；核對完一列都沒有，就不能說成「被影響」
        say("沒放修訂版、照規格包核對過、沒有要跟著改的列 %d 本：%s" % (len(checked), "、".join(checked)))
    if untouched_line:
        say(untouched_line)
    if capped_line:
        say(capped_line)
    if dropped_line:
        say(dropped_line)
    if zero_books:
        say("有新版草稿卻一處都沒改 %d 本：%s——請確認草稿有沒有放對" % (len(zero_books), "、".join(zero_books)))
    for line in manual_lines:
        say(line)
    say("摘要：%s（含各本提醒彙整）" % show_path(summary_path))
    if not getattr(args, "verbose", False):
        say("各本的比對過程在 產出/2_Log檔案/<規章名>/2_Log檔案/執行紀錄.txt（要印在畫面上就加 --詳細）")
    # 批次的下一步只有一個來源：最後印的「下一步（人工待辦）」那一段（見 todo.SCREEN_HEADER）
    say("")
    say("最終仍需人工複核。")
    return 0


AI_REVIEW_SKIP = "AI審查略過.txt"


def cmd_batch_review_pack(args, settings):
    """批次第 1.5 步：逐本把候選與異動打包成審查包；loaded 讓跨本候選（異動條文ID
    是「A名：ref」那種）能到來源本查到異動全文，不用只看自己這本。

    兩階段：先逐本 rp.load_book 收集錯誤，任何一本讀不出來就整批「[中止]」、
    一個字都不寫；全部讀成功才逐本 write_pack。這樣「某本半路才發現壞掉」不會
    連累前面已經成功寫出的審查包（write_pack 是覆寫，半路中止會留下新舊混雜的
    產出）。loaded_books 傳給 write_pack 後，每本只在這裡 load_book 一次
    （不管是當自己還是被別本拿去跨本引用），不再是 N 本 N² 次讀檔。"""
    import batch as bt
    import notices as nt
    import review_pack as rp
    import law_fetch
    _apply_workspace_defaults(args, settings)
    if not _require_output(args):
        return 1
    nt.reset()
    outdir = args.outdir
    marker = os.path.join(outdir, "2_Log檔案", AI_REVIEW_SKIP)
    if getattr(args, "skip", False):
        os.makedirs(os.path.dirname(marker), exist_ok=True)
        with io.open(marker, "w", encoding="utf-8") as f:
            f.write("這一輪不做 AI 審查（batch-review-pack --略過）；要做就直接跑 batch-review-pack\n")
        say("這一輪不做 AI 審查：人工待辦不會再提醒；之後想做，直接跑 %s 就好" % _cmd("審查打包", workspace_flag(args)))
        return 0
    if os.path.isfile(marker):
        os.remove(marker)
    if _order_problem(args, "batch-review-pack"):     # 語意還沒併入只提醒；「[順序]」才擋（第三批）
        return 1
    try:
        book_list = bt.list_books(outdir)
    except bt.BatchError as exc:
        say("[中止] %s" % exc)
        return 1
    warn_if_legacy_books(outdir, [name for name, _ in book_list])
    # AI 填在合一表（產出/2_Log檔案/AI審查/）上的答案先寫回各本，重新打包才沿用得到
    if not _split_ai_tables(outdir, book_list):
        return 1

    all_errors = []
    loaded = {}
    for name, outdir_doc in book_list:
        try:
            loaded[name] = rp.load_book(outdir_doc)
        except rp.ReviewPackError as exc:
            all_errors.append("%s：%s" % (name, exc))
    if all_errors:
        say("[中止] 有本讀不到，整批沒寫：")
        for line in all_errors:
            say("  " + line)
        return 1

    # load_book 那一輪與底下 write_pack 那一輪都可能發提醒（某本是舊式留底、
    # 舊版是用檔名猜的、AI CSV 已有填答沒覆寫……）。畫面上印過了，但批次的畫面
    # 特別長，一定要同時留一份在產出根目錄——所以留底要等 write_pack 跑完才寫，
    # 中途中止也要先寫再走。
    def keep_notices():
        say("提醒留底：%s（%d 則）"
            % (show_path(nt.write_notices(outdir, "批次審查包",
                                          title="batch-review-pack（批次第 1.5 步）")),
               len(nt.collected())))

    # 第二階段一本失敗就整批停在那裡：前面幾本的審查包已經是新的、後面幾本還沒動，
    # 一定要講清楚是哪幾本更新了（實測 no 25：舊寫法沒有 try，直接噴 traceback，
    # 人看不出前面幾本到底寫了沒）。
    law_fetch.begin_round()
    done = []
    for name, outdir_doc in book_list:
        try:
            info = rp.write_pack(outdir_doc, args.per_file, loaded_books=loaded, quiet=True,
                                 max_chars=getattr(args, "max_chars", rp.DEFAULT_MAX_CHARS))
        except (rp.ReviewPackError, OSError) as exc:
            say("[中止] %s 寫審查包失敗：%s；已完成 %d 本（%s），"
                "這幾本的審查包已更新，其餘 %d 本沒動"
                % (name, exc, len(done), "、".join(done),
                   len(book_list) - len(done) - 1))
            law_fetch.finish_round()
            keep_notices()
            return 1
        done.append(name)
        line = ("%s：候選 %d 筆、異動 %d 處、審查包 %d 份"
                % (name, info["候選數"], info["異動數"], len(info["包"])))
        if info.get("保留填答"):
            line += "（沿用 AI 已判過的：%s）" % "、".join(info["保留填答"])
        say(line)
    law_fetch.finish_round()
    keep_notices()
    import ai_tables as at
    if bt.is_health_round(outdir):
        # 體檢多一張整批一張的表：重複／矛盾候選（兩段全文與前後文另寫一份 md）
        import health_check as hc
        try:
            pair_count, pair_kept = hc.write_pack(outdir, loaded)
        except hc.HealthCheckError as exc:
            say("[中止] %s" % exc)
            return 1
        if pair_count:
            family_count = len(hc.read_families(outdir))
            say("重複／矛盾：%s交給 AI 判（%s）%s" % (
                "%d 對" % (pair_count - family_count) + ("、%d 個家族" % family_count if family_count else ""),
                "、".join([hc.TABLE_FILE] + ([hc.FAMILY_TABLE_FILE] if family_count else [])),
                "，沿用上一輪 %d 項" % pair_kept if pair_kept else ""))
        # 體檢的錯漏字檢查（v1.7.0）：AI 逐段讀全文挑錯漏字
        import health_typo
        typo_count, typo_kept = health_typo.write_pack(
            outdir, loaded, setting_int(settings, "錯漏字每份字數", health_typo.CHUNK_CHARS))
        if typo_count:
            say("錯漏字：%d 份交給 AI 逐段讀（%s）%s" % (typo_count, health_typo.TABLE_FILE,
                                                 "，沿用讀過的 %d 份" % typo_kept if typo_kept else ""))
        # 體檢的法規更新檢視（v1.6.0）：兩張表要在 at.merge 之前寫，先讀我.md 才算得到列數
        import health_law
        import law_impact as li
        try:
            law_state = health_law.pack(outdir)
        except li.ImpactError as exc:
            say("[中止] 法規更新檢視打包失敗：%s" % exc)
            return 1
        if law_state is not None:
            say("法規更新檢視：%d 條法規交給 AI 判（%s、%s）%s" % (
                len(law_state["events"]), health_law.APPLY_FILE, health_law.IMPACT_FILE,
                "，沿用判過的 %d 列" % law_state.get("carried", 0) if law_state.get("carried") else ""))
    counts = at.merge(outdir, book_list)
    waiting = sum(w for _, w in counts.values())
    say("AI 表：產出/2_Log檔案/%s/（全部規章合一，第一欄是規章），規章那幾張要填 %d 列%s；要填哪幾張、讀哪幾份，"
        "列在 產出/2_Log檔案/%s/%s" % (at.FOLDER, waiting, "（其餘沿用 AI 已判過的）" if any(t - w for t, w in counts.values())
                                  else "", at.FOLDER, at.INDEX))
    return 0


def _split_ai_tables(outdir, book_list):
    """合一的 AI 表（產出/2_Log檔案/AI審查/）上 AI 改過的格寫回各本；有錯印「[中止]」回 False。"""
    import ai_tables as at
    errors, written, notes = at.split(outdir, book_list)
    for line in notes:
        say("[提醒] " + line)
    if errors:
        say("[中止] 產出/2_Log檔案/%s/ 的 AI 表有問題（改好再跑）：" % at.FOLDER)
        for line in errors:
            say("  " + line)
        return False
    if written:
        say("已把 產出/2_Log檔案/%s/ 上 AI 填的答案寫回各本：%s"
            % (at.FOLDER, "、".join("%s %d 格" % kv for kv in sorted(written.items()))))
    return True


def cmd_batch_review_import(args, settings):
    """批次第 1.5 步：先逐本只驗證兩張 AI CSV，任何一本有錯就整批中止、什麼都不寫；
    全部過了才逐本把三欄寫回連帶決定表。人看的結果在 1_結果彙整/檢視報告.xlsx。"""
    import batch as bt
    import notices as nt
    import review_import as ri
    import review_pack as rp
    _apply_workspace_defaults(args, settings)
    if not _require_output(args):
        return 1
    nt.reset()
    outdir = args.outdir
    if _order_problem(args, "batch-review-import"):
        return 1

    def keep_notices():
        # 驗原文的警告（哪幾本的哪幾列候選全文被手改過）一定要留底：批次的畫面
        # 特別長，這幾則最容易被後面的逐本統計洗掉。
        say("提醒留底：%s（%d 則）"
            % (show_path(nt.write_notices(outdir, "批次審查匯入",
                                          title="batch-review-import（批次第 1.5 步）")),
               len(nt.collected())))

    try:
        book_list = bt.list_books(outdir)
    except bt.BatchError as exc:
        say("[中止] %s" % exc)
        return 1
    warn_if_legacy_books(outdir, [name for name, _ in book_list])
    if not _split_ai_tables(outdir, book_list):
        return 1

    all_errors = []
    loaded = {}
    for name, outdir_doc in book_list:
        try:
            book = rp.load_book(outdir_doc)
            ai_cand, ai_change, ai_meta = ri.load_ai_files(outdir_doc)
        except (rp.ReviewPackError, ri.ReviewError) as exc:
            all_errors.append("%s：%s" % (name, exc))
            continue
        loaded[name] = book
        errors = ri.validate(book["rows"], book["changes"], ai_cand, ai_change, ai_meta)
        errors += ri.check_external(book, ri.load_external(outdir_doc),
                                    required=ri.external_required(outdir_doc))[0]
        # AI條文檢查 也在這一關驗：以前要到第二階段才擋，前面幾本已經寫進去了
        errors += ri.check_rulecheck(rp.rulecheck_items(outdir_doc), ri.load_rulecheck(outdir_doc),
                                     required=ri.rulecheck_required(outdir_doc))[0]
        all_errors += ["%s：%s" % (name, e) for e in errors]
    health = bt.is_health_round(outdir)
    # v1.11.0：各組表分開收。以前一列錯、八張表全部退件；現在每一組照樣整組驗過才收，
    # 驗過的組先寫進去，有錯的組列出來、這一組不寫（品質不變：每一列照樣驗）
    group_errors = {}
    if health:
        import health_check as hc
        import health_law
        import health_typo
        group_errors[hc.VALIDATE_GROUP] = hc.validate(outdir)
        group_errors["錯漏字（AI錯漏字.csv）"] = health_typo.validate(outdir, loaded)
        group_errors["法規更新檢視（AI法規適用.csv、AI法規影響.csv）"] = health_law.validate(outdir)
    bad_groups = [name for name, errors in group_errors.items() if errors]
    if all_errors or bad_groups:
        import ai_tables as at
        if all_errors:
            say("[中止] 各本的 AI 表（候選、異動、條文檢查、外部引用）有問題，這幾張沒寫：")
            for line in all_errors:
                say("  " + line)
        for group in bad_groups:
            say("[中止] %s有問題，這一組沒寫：" % group)
            for line in group_errors[group]:
                say("  " + line)
        if os.path.isdir(at.folder(outdir)):
            say("（AI 表在 產出/2_Log檔案/%s/，第一欄是規章：照上面的規章與編號找那一列改）" % at.FOLDER)
        ok_groups = [name for name, errors in group_errors.items() if not errors]
        if ok_groups or not all_errors:
            say("驗過的照樣寫入：%s" % "、".join((["各本的 AI 表"] if not all_errors else []) + ok_groups))

    mismatch_total = 0
    done_count = 0
    name = None
    # 外部引用學到的名稱等整批寫完才進登錄表、排除表：中途寫，後面幾本的 E 編號會照新表重抓而錯位
    ri.discard_learned()
    try:
        for name, outdir_doc in (book_list if not all_errors else []):
            # book=loaded[name]：這本第一階段（驗證）已經 load_book 過一次，
            # 這裡不用再重讀一次連帶決定表／異動清單／docx。
            result = ri.import_review(outdir_doc, book_name=name, books=loaded, book=loaded[name],
                                      defer_learning=True)
            cand, change = result["候選"], result["異動"]
            line = ("%s：候選 %s；異動 %s" % (
                name, "、".join("%s %d 筆" % (v, cand[v]) for v in ri.CAND_VERDICTS),
                "、".join("%s %d 筆" % (v, change[v]) for v in ri.CHANGE_VERDICTS)))
            if result.get("外部引用"):
                line += "；外部引用 %s" % _external_counts_text(result["外部引用"])
            if result.get("條文檢查"):
                line += "；條文檢查高風險 %s" % _rulecheck_counts_text(result["條文檢查"])
            if result.get("原文不符"):
                line += "；原文不符 %d 列未匯入（列ID %s）" % (
                    len(result["原文不符"]), "、".join(result["原文不符"]))
                mismatch_total += len(result["原文不符"])
            if result.get("AI過期"):
                line += "；AI 判斷不是這一輪的 %d 列未匯入（列ID %s）" % (
                    len(result["AI過期"]), "、".join(result["AI過期"]))
                mismatch_total += len(result["AI過期"])
            say(line)
            done_count += 1
    except (ri.ReviewError, rp.ReviewPackError, OSError, bt.BatchError) as exc:
        # 這本已經在第一階段驗證過，理論上不會再失敗；防禦式地照樣中止，別讓
        # traceback 洩出去。前面成功匯入的本，決定表已經真的寫了
        # （import_review 一本一本各自獨立寫）；下次重跑會照寫回邏輯整批重寫。
        ri.discard_learned()
        say("[中止] %s 寫入失敗：%s" % (name, exc))
        say("前面 %d 本已寫入 AI 判斷；修正後重跑審查匯入會整批重寫。" % done_count)
        keep_notices()
        return 1
    try:
        ri.flush_learned()
    except OSError as exc:
        # 登錄表、排除表寫不進去（被 Excel 開著、資料夾唯讀）：各本的決定表、匯入狀態都已經寫好了，
        # 不能回報成「中止」——以前 PermissionError 一路上到 main，檢視報告不重建、下一次繼續又說做完了，
        # 報告永遠停在打包那版（審查 C7）。這裡只警告，學到的名稱這一輪不寫，下次匯入會再學
        nt.notice(nt.WARNING, "登錄表／排除表寫不進去（%s）：這一輪學到的外部規章名稱沒存，"
                              "請把 memoization/ 底下的表關掉再跑一次審查匯入就會補上" % exc, "review-import")
    try:
        import learned
        synonyms = learned.import_synonyms(outdir)
        if synonyms:
            say("AI 建議了 %d 組同義詞：打開設定頁「同義詞表」按「採用」才會生效" % synonyms)
    except Exception as exc:                  # 建議沒寫進設定頁不擋匯入
        say("提醒：AI 同義詞建議沒寫進設定頁（%s）" % exc)

    if mismatch_total:
        say("原文不符或 AI 判斷不是這一輪的共 %d 列未匯入（跨 %d 本合計）；重跑審查打包讓 AI 重判這幾列"
            % (mismatch_total, done_count))
    if health:
        import health_check as hc
        if not group_errors.get(hc.VALIDATE_GROUP):         # v1.31.0：跟上面驗證用同一個名字（以前名字對不上，驗證有錯也匯入）
            taken, stale = hc.import_results(outdir, loaded)
            if taken or stale:
                say("重複／矛盾：收了 %d 對%s" % (taken, "，%d 對的文字已經變了沒收（重新體檢會再判）" % stale if stale else ""))
        import health_typo
        if not group_errors.get("錯漏字（AI錯漏字.csv）"):
            typos = health_typo.import_results(outdir, loaded)
            if os.path.isfile(os.path.join(health_typo.folder(outdir), health_typo.TABLE_FILE)):
                say("錯漏字：收了 %d 處" % typos)
        import health_law
        law_errors, law_counts = ([], {}) if group_errors.get("法規更新檢視（AI法規適用.csv、AI法規影響.csv）") \
            else health_law.import_results(outdir)
        if law_errors:          # 前面驗過了，理論上不會到這裡；防禦式地講清楚
            say("[中止] 法規更新檢視匯入失敗：")
            for line in law_errors:
                say("  " + line)
            keep_notices()
            return 1
        if law_counts:
            say("法規更新檢視：%d 條法規；%s" % (law_counts.pop("法規", 0), "、".join(
                "%s %d 列" % kv for kv in sorted(law_counts.items())) or "沒有內規候選段"))
    keep_notices()
    if all_errors or bad_groups:
        say("有問題的那幾張改好再跑 繼續（或 審查匯入）：驗過的已經寫了，重跑會整批再驗一次、結果一樣")
        return 1
    if health:
        say("人用報告：產出/1_結果彙整/體檢報告_<日期序號>.xlsx（先看「條文比對報告」「條文檢查報告」「引用檢查報告」）")
    else:
        say("人用報告：產出/1_結果彙整/比對報告_<日期序號>.xlsx（先看「條文比對報告」）")
    say("AI 只是建議，要不要改由人決定；最終仍需人工複核。")
    return 0


# ---------------------------------------------------------------------------
# 工作區：配對／開始
# ---------------------------------------------------------------------------

def _add_settings_ok_flag(p):
    p.add_argument("--設定已確認", "--settings-ok", dest="settings_ok", action="store_true",
                   help="第一次比對／體檢／法規追蹤之前，已經問過使用者要不要更新設定（第二輪起不用帶）")


def _first_round_ask(root, health, args):
    """v1.13.0：這個工作區第一次做比對（或體檢）之前，先停下來讓 AI 問使用者要不要更新設定；第二輪起不問。
    第一次＝工作區裡還沒有同一種的產出資料夾（體檢看體檢那幾輪、比對看比對那幾輪）。回傳要不要停。"""
    import batch as bt
    import workspace as ws
    if getattr(args, "settings_ok", False) or os.environ.get("REG_SKIP_FIRST_SETTINGS_ASK") == "1":
        return False
    try:
        names = os.listdir(root)
    except OSError:
        return False
    for name in names:
        path = os.path.join(root, name)
        if os.path.isdir(path) and ws.is_output_dir(root, path) and bt.is_health_round(path) == health:
            return False
    _say_first_round_ask("體檢" if health else "比對",
                         "一般設定的分析單位基本資料（單位類型、業務範圍、追蹤主題）、語意比對，體檢設定的份量……")
    return True


def _say_first_round_ask(kind, what):
    say("[先問設定] 這個工作區還沒做過%s：開始之前，先問使用者要不要更新設定（%s）。" % (kind, what))
    say("  要改：跑「%s」（改了自動存，改完關掉設定頁），再跑一次這個指令並加 --設定已確認" % "打開設定")
    say("  不用改：直接加 --設定已確認 再跑一次")
    say("  （第二輪起不會再問）")


def _first_law_ask(args, settings):
    """v1.17.0：這個工作區第一次做法規追蹤之前也先停下來問設定（跟第一次比對、體檢一樣）；第二輪起不問。
    第一次＝工作區還沒有 法規作業.json（體檢那一輪附帶的法規更新檢視不算）。回傳要不要停。"""
    import law_impact as li
    if getattr(args, "settings_ok", False) or os.environ.get("REG_SKIP_FIRST_SETTINGS_ASK") == "1":
        return False
    try:
        root = li.resolve_workspace(args, settings)
    except li.ImpactError:
        return False                     # 工作區不對：交給 law_impact.run 講清楚
    if os.path.isfile(os.path.join(root, li.POINTER)):
        return False
    _say_first_round_ask("法規追蹤", "一般設定的分析單位基本資料（單位類型、業務範圍、追蹤主題）、"
                                    "外部法規查證的法規資料庫，規範資料頁籤的資料庫……")
    return True


def cmd_law_start(args, settings):
    """法規追蹤：第一次先問設定，再交給 law_impact.run。"""
    import law_impact
    if _first_law_ask(args, settings):
        return 0
    return law_impact.run(args, settings)


def cmd_open_settings(args, settings):
    """v1.13.0 打開設定：本機小服務打開設定頁，存檔不跳視窗、改了自動存。"""
    import settings_server
    return settings_server.run(open_browser=not getattr(args, "no_browser", False), say=say)


def cmd_share(args, settings):
    """v1.20.0 打包分享：一定要先問使用者含不含內部知識（沒指定就只列出內部知識、不打包）。"""
    import share
    choice = getattr(args, "internal", "") or ""
    if choice not in ("含", "不含"):
        for line in share.ask_lines():
            say(line)
        return 0
    share.pack(choice == "含", say=say)
    return 0


def _pair_cut_text(stats):
    """體檢配對沒列的原因（v1.23.1：分開講「一段最多 3 對」和「體檢最多幾對」，照實際原因提示）。"""
    if not stats.get("沒列"):
        return ""
    per, total = stats.get("每段上限沒列"), stats.get("總上限沒列")
    if per is None and total is None:
        return "；另有 %d 對超過上限沒列（設定.html 可加「體檢最多幾對」）" % stats["沒列"]
    parts = []
    if total:
        parts.append("%d 對超過整批上限沒列（設定.html 可加「體檢最多幾對」）" % total)
    if per:
        parts.append("%d 對因為「一段最多配 3 對」沒列（同一段已經有分數更高的 3 對，這個上限不能調）" % per)
    return "；另有 " + "、".join(parts)


def _say_law_unfinished(root):
    """「繼續」是比對、體檢的指令：法規追蹤還沒做完時多講一句要說「法規繼續」（v1.24.0）。"""
    try:
        import law_impact as li
        text = li.unfinished(root)
    except Exception:
        text = ""
    if text:
        say("另外：" + text)


def cmd_feedback(args, settings):
    """v1.21.0 收回饋：承辦在報告「承辦意見」欄寫完、存檔後，跟 AI 說「收回饋」「回饋寫完了」。
    不管是比對、體檢還是法規追蹤：工作區每一輪產出的報告都讀（目前這一輪先），意見存成本單位判例，不用重出報告。"""
    import glob
    import precedents as pc
    import workspace as ws
    root = ws.resolve_root(getattr(args, "workspace", ""), settings)
    say("工作區：%s" % root)
    outputs = []
    try:
        current = ws.paths(root)["產出"]
        if current and os.path.isdir(current):
            outputs.append(current)
    except Exception:
        pass
    others = [d for d in glob.glob(os.path.join(glob.escape(root), "產出*")) if os.path.isdir(d)]
    outputs += [d for d in sorted(others, key=os.path.getmtime, reverse=True)
                if os.path.normcase(d) not in set(os.path.normcase(o) for o in outputs)]
    for line in pc.collect_lines(pc.collect(outputs)):
        say(line)
    return 0


def cmd_unit_profile(args, settings):
    """v1.12.0 單位建議：沒填就打包給 AI；AI 填好就核對依據、寫進設定.html（人按採用才生效）。"""
    import unit_profile as up
    import workspace as ws
    root = ws.dated_if_missing(ws.resolve_root(getattr(args, "workspace", ""), settings))
    say("工作區：%s" % root)
    try:
        return up.run(root, settings, redo=getattr(args, "redo", False), say=say)
    except up.ProfileError as exc:
        say("[中止] %s" % exc)
        return 1


def cmd_library(args, settings):
    """v1.9.0 規範資料庫：放好檔案之後跑一次，看程式認出來的名稱、版本、日期對不對（目錄.csv 可以直接改）。"""
    import rule_library as lib
    root = lib.ensure_dirs()
    library = lib.load(refresh=True)
    say("規範資料庫：%s" % show_path(root))
    if not library.docs:
        say("（還是空的。網路上找不到的外部規範放 外部規範/，本行自己的規章放 內部規範/；說明見 %s）" % lib.README)
        return 0
    for folder in lib.FOLDERS:
        docs = [d for d in library.docs if d["資料夾"] == folder]
        say("%s：%d 份" % (folder, len(docs)))
        for doc in docs:
            bits = [b for b in ("版本 %s" % doc["版本"] if doc["版本"] else "", doc["日期"],
                                "編號 %s" % doc["編號"] if doc["編號"] else "") if b]
            articles = len(lib.doc_articles(doc)) if doc["readable"] else 0
            say("  %s → 「%s」%s｜%s%s" % (doc["檔名"], doc["規範名稱"], "（%s）" % "、".join(bits) if bits else "",
                                        doc["狀態"], "｜%d 條（點）" % articles if articles else ""))
    for warning in library.warnings:
        say("[提醒] %s" % warning)
    say("目錄：%s（名稱、版本、日期猜錯就直接改；改過的程式不再動，清空的下次重猜）"
        % show_path(os.path.join(root, lib.CATALOG)))
    return 0


def cmd_law_changed(args, settings):
    """外部法規改了（使用者說「保險法改了」「法規更動」）：那部法規的查證紀錄作廢，下一次審查打包
    會重新交給 AI 上網查；目前這一輪有在進行就叫它回到審查打包。
    查證紀錄本來 90 天內同一處引用直接沿用，法規在中間改了程式不會知道（只有段落改了或過期才重查）。"""
    import batch as bt
    import review_import as ri
    import verify_cache as vc
    import workspace as ws
    names = [n.strip() for n in (getattr(args, "names", None) or []) if n and n.strip()]
    everything = bool(getattr(args, "everything", False))
    if not names and not everything:
        say("[中止] 要給法規名稱（例：法規更動 保險法），或加 --全部 讓所有查證紀錄作廢")
        return 1
    folder = bt.cache_dir()
    removed, total = vc.invalidate(folder, names, everything=everything)
    import law_fetch
    law_fetch.invalidate(folder, names, everything=everything)
    if everything:
        say("查證紀錄 %d 筆全部作廢，下一次審查打包全部重新上網查" % removed)
    else:
        say("查證紀錄 %d 筆裡，跟「%s」有關的 %d 筆作廢" % (total, "、".join(names), removed))
        if total and not removed:
            say("（一筆都沒對到：舊版存的紀錄沒記引用文字，只能從理由裡找名字；確定要全部重查就加 --全部）")
    root = ws.resolve_root(getattr(args, "workspace", ""), settings)
    outdir = ws.paths(root)["產出"] if os.path.isdir(root) else ""
    if not outdir or not os.path.isdir(outdir) or not bt.is_batch_root(outdir):
        say("目前沒有進行中的一輪；下一輪的審查打包就會重查")
        return 0
    _set_display_root(root)
    try:
        books = bt.list_books(outdir)
    except bt.BatchError as exc:
        say("這一輪的產出不完整（%s），沒有標記；重新比對時就會重查" % exc)
        return 0
    reason = "法規更動：%s" % ("、".join(names) if names else "全部")
    for _name, outdir_doc in books:
        ri.mark_repack(outdir_doc, reason)
    say("這一輪 %d 本已標記要重新打包：跑 %s，審查打包會把這部法規的引用重新交給 AI 上網查、再匯入"
        % (len(books), _cmd("繼續", workspace_flag(args))))
    return 0


def cmd_init_workspace(args, settings):
    """主線第一站：每次開一個新的工作區 <名稱>yyyymmddnn（一個新案子一個工作區，舊的留著不動）。

    指定的是已經有的某一個 <名稱>yyyymmddnn：只補缺的資料夾與說明，不另開。
    指定的資料夾是人自己建好、放好檔案的（還不是工作區）：改名加上日期序號再補齊，檔案不動——
    另開一個空的，人放好的檔就留在舊資料夾裡了。舊版工作區照舊安全複製、遷移。"""
    import workspace as ws
    from _common import skill_path
    given = (getattr(args, "workspace", "") or skill_path((settings or {}).get("工作區根目錄", ""))
             or os.path.join(os.path.dirname(REG), ws.SHARED_WORKSPACE))
    target = os.path.abspath(given)
    try:
        if os.path.isdir(target) and ws.workspace_base(target) != target:
            root = target
        elif os.path.isdir(target) and not ws.is_workspace(target):
            root = ws.new_workspace_root(target)
            os.replace(target, root)
            say("已把 %s 改名成 %s（裡面的檔案都沒動）" % (os.path.basename(target), os.path.basename(root)))
        else:
            root = ws.new_workspace_root(target)
        notes = ws.initialize(root)
    except (ws.WorkspaceError, OSError) as exc:
        say("[中止] %s" % exc)
        return 1
    _set_display_root(root)          # 會印一次「工作區：…」，不用再印
    for note in notes:
        say(note)
    say("現行版放 匯入/%s/，修訂版放 匯入/%s/；同一本兩邊檔名大致一樣就配得起來（檔名前後的冊次、日期不同也可以）。"
        % (ws.CURRENT_DIR, ws.DRAFT_DIR))
    # v1.24.0：講清楚放好檔之後要跟 AI 說什麼（以前只講了內部指令「開始」）
    say("下一步（人做）：檔案放好後跟 AI 說——有新舊兩版要比：「開始比對」；只有現行版、想檢查現有文件：「體檢」；"
        "外部法規改了要看影響：「法規追蹤」。這個工作區是 %s，之後每一步都用它。" % os.path.basename(root))
    return 0


def cmd_pair(args, settings):
    """配對 匯入/1_現行文件 與 匯入/2_修訂文件 的檔案，寫規章清單供確認。"""
    import workspace as ws
    root = ws.dated_if_missing(ws.resolve_root(args.workspace, settings))
    return _pair(root)


def _pair(root, from_start=False):
    """配對本體（配對、開始 共用）。回傳 0＝清單可以用；1＝有要人處理的列、或清單寫不出來。
    from_start：「開始」自己叫的（還沒有清單、或清單過期）——配得乾淨就直接往下跑，
    最後那一句不叫人「對了就跑開始」。"""
    import batch as bt
    import notices as nt
    import workspace as ws
    from _common import SUPPORTED_EXTS
    if ws.uses_prefix_layout(root):
        say("[中止] 這是用檔名前綴（現行_／修訂_）的舊工作區：先跑 %s，程式會把檔搬進 匯入/%s、匯入/%s"
            % (_cmd("建工作區", "--workspace", root), ws.CURRENT_DIR, ws.DRAFT_DIR))
        return 1
    created = ws.ensure_layout(root)
    if created:
        say("已建立工作區：%s" % root)
    p = ws.paths(root)
    old_dir, new_dir = ws.role_dirs(root)
    if ws.uses_legacy_layout(root):
        old_names, old_skipped = ws.list_inputs(p["舊版"])
        new_names, new_skipped = ws.list_inputs(p["新版"])
        skipped = (["%s/%s" % (old_dir, n) for n in old_skipped]
                   + ["%s/%s" % (new_dir, n) for n in new_skipped])
    else:
        old_names, new_names, skipped = ws.list_import_files(root)
    # 同一角色去掉副檔名後只能有一份，否則後續配對會覆蓋其中一份。
    duplicates = []
    for role, names in (("現行", old_names), ("修訂", new_names)):
        grouped = {}
        for name in names:
            grouped.setdefault(ws._exact_key(ws._stem(name)), []).append(name)
        duplicates += ["%s：%s" % (role, "、".join(values))
                       for values in grouped.values() if len(values) > 1]
    if duplicates:
        say("[中止] 同一角色有重複規章檔：%s；每本只保留一份" % "；".join(duplicates))
        return 1
    # no 14：不支援的副檔名、放錯層的規章檔都要明確列出，不能安靜跳過。
    if skipped:
        nt.notice(nt.REMINDER,
                  "略過或尚未分類 %d 個檔：%s（規章只認 %s；現行版放 匯入/%s/、修訂版放 匯入/%s/）"
                  % (len(skipped), "、".join(skipped), "/".join(SUPPORTED_EXTS), old_dir, new_dir), "配對")
        if any(value.endswith(ws.UNSORTED_NOTE) for value in skipped):
            say("[中止] 匯入/ 最上層有規章檔沒放進 %s 或 %s；搬進對的資料夾後再跑 配對" % (old_dir, new_dir))
            return 1
    # M3：白名單放寬之後，匯入夾裡的 .txt／.md 會變成一本規章——這對「草稿就是
    # 純文字」的人是對的，對「放了一張備忘或說明檔」的人是驚嚇（清單突然多一本、
    # 過期檢查還會要求把它列進去）。所以只要真的收了 .txt／.md 就講一聲。
    texts = (["%s/%s" % (old_dir, n) for n in old_names if not n.lower().endswith(".docx")]
             + ["%s/%s" % (new_dir, n) for n in new_names if not n.lower().endswith(".docx")])
    if texts:
        nt.notice(nt.REMINDER,
                  "匯入/ 有 %d 個 .txt/.md 檔已當成規章：%s；若是備忘或說明檔請移走"
                  % (len(texts), "、".join(texts)), "配對")
    spec_names = ws.list_spec_names(p["規格包"])
    auto_rows = ws.match(old_names, new_names, spec_names, old_dir, new_dir)
    try:
        old_rows = ws.read_manifest_rows(p["清單"]) if os.path.isfile(p["清單"]) else []
    except ws.WorkspaceError as exc:
        # item5：既有清單本身壞掉（缺欄位、配對方式亂填）不該噴 traceback——跟其他
        # 子命令一致，印「[中止]」、exit 1，讓人去看清單哪裡壞了。
        say("[中止] %s" % exc)
        return 1
    rows, kept_names, dropped_names, draft_missing = ws.merge_manual(auto_rows, old_rows, root)
    try:
        ws.write_manifest(rows, p["清單"])
    except OSError as exc:
        # item5：清單常見的失敗是檔案開在 Excel 裡（Windows 鎖檔）——這是 OSError，
        # 沒接住會直接噴 traceback。寫檔失敗這裡就中止，不要再往下印「請確認
        # 匯入/規章清單.csv」之類的下一步提示，因為這次根本沒寫成。
        say("[中止] 規章清單寫入失敗：%s（可能開在 Excel）；請關掉後重跑 配對" % exc)
        return 1
    ws.print_table(rows)
    if kept_names:
        say("沿用手動列 %d 筆：%s" % (len(kept_names), "、".join(kept_names)))
    if dropped_names:
        say("手動列 %s 的檔不存在，已改回自動配對" % "、".join(dropped_names))
    if draft_missing:
        # no 16：手動列的草稿被刪掉時，以前整列原樣寫回去，要跑到「開始」的過期檢查
        # 才被擋；欄位已經清空了，這裡得講一聲，不然人只會看到草稿欄莫名其妙變空。
        nt.notice(nt.WARNING,
                  "%d 個手動列的新版草稿不存在，已清空草稿欄並標「%s」：%s"
                  % (len(draft_missing), ws.DRAFT_MISSING_NOTE,
                     "、".join("%s（%s）" % (name, rel) for name, rel in draft_missing)),
                  "配對")
    need_human = [r for r in rows if not r["舊版"]]
    # 修正回合 1（I1）：草稿不存在的手動列跟「未配對／多個候選」是同一級的「還沒配好」。
    # 只發警告不擋的話，使用者照畫面跑「開始」，那一列草稿欄是空的，整條流程會把它
    # 當成「這本沒改」安靜跳過——人明明改過這本，對照表卻一個字都沒有。判斷看的是
    # 清單裡留下來的備註（不是這一輪才偵測到的 draft_missing），所以重跑配對還是會擋，
    # 直到人真的去補檔或把那一列改回一般的「沒改」列。
    draft_rows = [r for r in rows
                  if r["舊版"] and r.get("備註") == ws.DRAFT_MISSING_NOTE]
    if not need_human:
        # no 15：清單寫出去了，但「開始」還會再跑一次 batch.read_manifest——規章名重複、
        # 同一份舊版／草稿被兩列引用，這三件事以前要等使用者照畫面指示跑「開始」才會
        # 被擋（畫面上剛剛還寫著「對了就跑 開始」）。同一套驗證在這裡先跑一次，錯就
        # 中止並把列號原樣印出來。未配對／多個候選走原本那條路（read_manifest 也會擋，
        # 但它的訊息沒有下面那句「請改檔名或補舊版」的指引）。
        try:
            bt.read_manifest(p["清單"])
        except bt.BatchError as exc:
            say("[中止] 清單有問題：%s" % exc)
            return 1
    if from_start:
        say(ws.summarize(rows, skipped=len(skipped))
            + "。配錯了就改 匯入/規章清單.csv（那一列「配對方式」寫「手動」）再跑一次剛才的指令")
    else:
        say(ws.summarize(rows, skipped=len(skipped)) + "。")
        # v1.24.0：「沒改的本」講清楚是什麼；配錯了才要動清單，不是每次都要人去看
        if any(r.get("備註") == "沒改" for r in rows):
            say("「沒改的本」＝沒放修訂版的規章：不比對新舊，只檢查別本的改動有沒有影響到它們（體檢時每一本都是這樣，正常）。")
        say("配錯了（同一本沒配在一起、配到別本）才需要改 匯入/規章清單.csv；沒問題就照下一步繼續")
    todo = need_human + draft_rows
    if todo:
        text = ("有 %d 本要人處理：未配對的請改檔名或補舊版；多個候選的請在清單填「舊版」"
                "並把「配對方式」寫「手動」" % len(todo))
        if draft_rows:
            text += ("；草稿不存在的（%s）請補檔或清掉草稿欄並把「配對方式」改回空白"
                     % "、".join(r["規章名"] for r in draft_rows))
        say(text)
    return 1 if todo else 0


def cmd_start(args, settings):
    """開始新一輪：先驗匯入與清單，再建立一個日期序號產出資料夾。"""
    import batch as bt
    import workspace as ws
    root = ws.dated_if_missing(ws.resolve_root(args.workspace, settings))
    ws.ensure_layout(root)
    p = ws.paths(root)
    _set_display_root(root)
    if not os.path.isfile(p["清單"]):
        say("還沒有 匯入/規章清單.csv：先配對")
        if _pair(root, from_start=True):
            return 1
    try:
        rows = ws.read_manifest_rows(p["清單"])
    except ws.WorkspaceError as exc:
        say("[中止] %s" % exc)
        return 1
    reasons = ws.stale_reasons(rows, root)
    if reasons:
        say("清單過期（匯入/ 的檔跟清單不一樣），重新配對：")
        for reason in reasons:
            say("  " + reason)
        if _pair(root, from_start=True):
            return 1
        try:
            rows = ws.read_manifest_rows(p["清單"])
        except ws.WorkspaceError as exc:
            say("[中止] %s" % exc)
            return 1
    try:
        bt.read_manifest(p["清單"])         # 清單寫錯（找不到檔、欄位缺）在這裡就停，不要比到一半才炸
    except bt.BatchError as exc:
        say("[中止] %s" % exc)
        return 1

    names = [row["規章名"] for row in rows if row["舊版"]]
    previous = ""
    if _first_round_ask(root, False, args):
        return 0
    if ws.uses_legacy_layout(root):
        # 舊工作區保留原本「歸檔到歷次」行為，讓現有案件可無縫續跑。
        try:
            moved = ws.archive_previous(root, names)
        except ws.WorkspaceError as exc:
            say("[中止] %s" % exc)
            return 1
        if moved:
            say(archive_line(moved))
        outdir = p["產出"]
    else:
        previous = ws.current_output(root)
        try:
            outdir = ws.begin_output(root)
        except ws.WorkspaceError as exc:
            say("[中止] %s" % exc)
            return 1
        say("本輪產出：%s" % outdir)

    ns = argparse.Namespace(**vars(args))
    ns.manifest = p["清單"]
    ns.outdir = outdir
    args.outdir = outdir
    rc = cmd_batch(ns, settings)
    if rc and not ws.uses_legacy_layout(root) and ws.abandon_output(root, outdir, previous):
        # 沒跑完的一輪不能當「目前作業」、也不能當下一輪的「前一輪」（沿用鏈會斷，見 workspace.abandon_output）
        say("這一輪沒跑完：目前作業退回%s；%s 留著給你看紀錄。修好之後再跑 開始（或 繼續）會開新的一輪"
            % ("上一輪（%s）" % os.path.basename(previous) if previous else "「還沒有作業」",
               os.path.basename(outdir)))
    return rc


def _health_law_step(outdir, args, settings, scorer=None):
    """體檢的「法規更新檢視」（v1.6.0，health_law）：外部法規最近改了，現行內規哪幾段要跟著改。
    抓法規異動、找候選段，回傳批次摘要那一行。失敗（網路、設定檔壞掉）不讓整輪體檢作廢：警告一則，
    這一輪的報告沒有法規更新那幾列。加 --不查法規 就不做。"""
    import health_law
    import law_impact as li
    import law_sources as ls
    import notices as nt
    if getattr(args, "skip_law", False):
        return "法規更新檢視：這一輪沒做（加了 --不查法規）"
    workspace = os.path.dirname(os.path.abspath(outdir))
    try:
        state = health_law.prepare(outdir, workspace, settings, getattr(args, "law_since", "") or "",
                                   getattr(args, "law_until", "") or "", getattr(args, "law_mode", "") or "異動",
                                   scorer=scorer, days=setting_int(settings, "體檢法規天數", health_law.DEFAULT_DAYS))
    except (li.ImpactError, ls.SourceError, ValueError, OSError) as exc:
        nt.notice(nt.WARNING, "法規更新檢視沒有做成（%s）：這一輪的體檢報告沒有法規更新那幾列；"
                              "修好之後重新體檢" % exc, "體檢")
        return "法規更新檢視：沒有做成（%s）" % exc
    return health_law.summary_line(state)


def cmd_health(args, settings):
    """體檢（檢查現有文件）：只放現行版、不用修訂版也能做的檢查——條文檢查、內部／跨本／外部引用、
    結構提醒、重複／矛盾候選。工作區、產出輪次、後面的審查打包→AI 審查→審查匯入→報告都跟「開始」同一套，
    差別只在：每一本拿現行版當草稿跑（異動 0）、這一輪標成體檢（batch.write_health_marker）、
    報告叫 體檢報告.xlsx、多一張 AI一致性.csv。"""
    import batch as bt
    import workspace as ws
    root = ws.dated_if_missing(ws.resolve_root(args.workspace, settings))
    ws.ensure_layout(root)
    p = ws.paths(root)
    _set_display_root(root)
    if ws.uses_legacy_layout(root) or ws.uses_prefix_layout(root):
        say("[中止] 這是舊版工作區，體檢只支援新版：先跑 %s" % _cmd("建工作區", "--workspace", root))
        return 1
    if not ws.list_role_inputs(root, ws.ROLE_CURRENT):
        say("[中止] 匯入/%s 還沒有規章檔：把要檢查的現行版放進去再說「體檢」" % ws.CURRENT_DIR)
        return 1
    if not os.path.isfile(p["清單"]):
        say("還沒有 匯入/規章清單.csv：先配對")
        if _pair(root, from_start=True):
            return 1
    try:
        rows = ws.read_manifest_rows(p["清單"])
    except ws.WorkspaceError as exc:
        say("[中止] %s" % exc)
        return 1
    reasons = ws.stale_reasons(rows, root)
    if reasons:
        say("清單過期（匯入/ 的檔跟清單不一樣），重新配對：")
        for reason in reasons:
            say("  " + reason)
        if _pair(root, from_start=True):
            return 1
    try:
        bt.read_manifest(p["清單"])
    except bt.BatchError as exc:
        say("[中止] %s" % exc)
        return 1
    if _first_round_ask(root, True, args):
        return 0
    previous = ws.current_output(root)
    try:
        outdir = ws.begin_output(root, kind="體檢")
    except ws.WorkspaceError as exc:
        say("[中止] %s" % exc)
        return 1
    bt.write_health_marker(outdir)
    say("本輪產出：%s（體檢：不比對差異，只檢查現有文件）" % outdir)
    ns = argparse.Namespace(**vars(args))
    ns.manifest = p["清單"]
    ns.outdir = outdir
    ns.health = True
    args.outdir = outdir
    rc = cmd_batch(ns, settings)
    if rc and ws.abandon_output(root, outdir, previous):
        say("這一輪沒跑完：目前作業退回%s；%s 留著給你看紀錄。修好之後再說「體檢」會開新的一輪"
            % ("上一輪（%s）" % os.path.basename(previous) if previous else "「還沒有作業」",
               os.path.basename(outdir)))
    _remind_profile(settings)
    if rc == 0 and not getattr(args, "in_continue", False) and not getattr(args, "no_pack", False):
        # v1.11.0：體檢跑完直接把 AI 審查資料打包好（以前要再跑一次「繼續」，那一站只要兩秒）
        say("")
        say("── 接著打包 AI 審查資料 ──")
        rc = _continue_steps(args, settings, root, ws.paths(root))
        path = _refresh_batch_report(ws.paths(root)["產出"] or "")
        if path:
            say("報告：%s" % show_path(path))
    return rc


def _remind_profile(settings):
    """v1.11.0：設定頁的「機構類型」「實際業務範圍」空白時提醒一次：AI 判法規適不適用只能寫待確認。"""
    if settings.get("法規機構類型") or settings.get("法規業務範圍"):
        return
    say("[提醒] 設定.html 的「分析單位基本資料」→「單位類型」「業務範圍」還是空白：AI 判新法規適不適用時，"
        "拿不準的只能寫「待確認」留給人。可以說「單位建議」讓 AI 先讀規章提建議值，你在設定頁按「採用」再存檔"
        "（填完第一次會重判一次法規適用）")


# ---------------------------------------------------------------------------
# 繼續：照人工待辦同一套判斷，程式能做的站一站接一站跑
# ---------------------------------------------------------------------------

CONTINUE_MAX_STEPS = 8
# 批次指令的中文名（第四批 28；英文名照樣能用）。繼續、人工待辦印給人看的一律用中文名
CHINESE_NAMES = {"batch-semantic": "語意併入", "batch-review-pack": "審查打包",
                 "batch-review-import": "審查匯入"}


def cmd_continue(args, settings):
    """繼續：看各本走到哪（todo.next_step，跟人工待辦同一套判斷），程式能做的站接著做——
    重跑開始、併入帶回來的語意交換包、產審查包、匯入 AI 填好的表——做到要人
    （或 AI）動手的那一站、或報告做完就停。語意要不要略過不替人決定。
    AI 審查那一站要四張 AI 表都填完才匯入（沒填完就停，講還差幾列）。"""
    import workspace as wsm
    root = wsm.dated_if_missing(wsm.resolve_root(getattr(args, "workspace", ""), settings))
    if wsm.ensure_layout(root):
        say("已建立工作區：%s（現行版放 匯入/%s/，修訂版放 匯入/%s/）" % (root, wsm.CURRENT_DIR, wsm.DRAFT_DIR))
    p = wsm.paths(root)
    _set_display_root(root)
    if not p["產出"] or not os.path.isdir(p["產出"]):
        say("目前沒有作業資料夾，先開始新一輪")
        # 「繼續」的 argparse 沒有開始所需的比對參數，不能直接把 args 傳進 cmd_start。
        argv = ["開始", "--workspace", root]
        start_args = build_parser().parse_args(argv)
        start_args.in_continue = True
        start_args.settings_ok = getattr(args, "settings_ok", False)
        rc = cmd_start(start_args, settings)
        if rc:
            args.start_failed = True
            return rc
        # 開始跑完接著往下站，跟中途的「繼續」一樣做到要人動手或報告完成才停：
        # 以前這裡直接回傳，人工待辦叫人再跑一次 繼續 才會審查打包
        p = wsm.paths(root)
        if not p["產出"] or not os.path.isdir(p["產出"]):
            return 0
    args.outdir = p["產出"]
    legacy = os.path.join(os.path.dirname(REG), "reg", "工作區")
    if (not getattr(args, "workspace", "") and not settings.get("工作區根目錄") and os.path.isdir(legacy)
            and os.path.normcase(os.path.abspath(legacy)) != os.path.normcase(os.path.abspath(root))):
        say("[提醒] 旁邊有舊版留下的工作區 %s：要接著用，把 設定.html 的「工作區根目錄」填成它" % legacy)
    return _continue_steps(args, settings, root, p)


def _continue_steps(args, settings, root, p):
    import ai_tables as at
    import batch as bt
    import todo
    import workspace as wsm
    last = None
    for _ in range(CONTINUE_MAX_STEPS):
        # 每一站重讀目前作業：「開始」會開新的 產出YYYYMMDDNNN（例如看完報告改了修訂版、重跑開始），
        # 還看舊的那一個，舊資料夾永遠是「修訂版改過了」，繼續就卡在「下一站還是它」；
        # 最後的人工待辦也照 args.outdir 寫，要跟著換成新的
        p = wsm.paths(root)
        args.outdir = p["產出"]
        step = todo.next_step(p["產出"], root)
        command = step["指令"]
        if not command:
            say("")
            import report_review as rv
            if step["說明"] == todo.REPORT_DONE:
                say("繼續：這一輪已經做完了")      # 細節（報告在哪、先看哪一頁）在後面「這一輪的結果」那一段
                _say_law_unfinished(root)
                added = rv.export_questions(p["產出"], root)
                try:
                    import batch as bt
                    rv.remember_findings(p["產出"], "體檢" if bt.is_health_round(p["產出"]) else "比對")
                except Exception as exc:          # 經驗沒記到不擋「做完了」
                    say("提醒：報告審查經驗沒記到（%s）" % exc)
                if added:
                    say("AI 報告審查有 %d 個問題要承辦回答，記在 工作區/匯入/單位事實.csv" % added)
                import precedents as pc
                got = pc.collect([p["產出"]])         # v1.21.0：做完之後說「繼續」也收承辦意見
                if got["意見"]:
                    for line in pc.collect_lines(got):
                        say(line)
            elif step.get("報告審查") and rv.read_rows(p["產出"]):
                problems = rv.errors(p["產出"])
                say("[中止] %s 有 %d 個地方要改（改好再跑 繼續）：" % (rv.FILE, len(problems)))
                for line in problems[:30]:
                    say("  " + line)
                return 1
            else:
                say("繼續：停在這一站——%s" % step["說明"])
                _say_law_unfinished(root)
            return 0
        if step.get("先看AI"):
            try:
                books = bt.list_books(p["產出"])
            except bt.BatchError as exc:
                say("[中止] %s" % exc)
                return 1
            errors, _, notes = at.split(p["產出"], books)
            for line in notes:
                say("[提醒] " + line)
            if errors:
                say("[中止] 產出/2_Log檔案/%s/ 的 AI 表有問題（改好再跑 繼續）：" % at.FOLDER)
                for line in errors:
                    say("  " + line)
                return 1
            # v1.11.0 法規兩階段：AI 判好適不適用 → 只把適用／待確認的法規連候選段打包，先讀我.md 重寫
            import health_law
            import law_impact as li
            try:
                repacked = health_law.repack_if_needed(p["產出"])
            except li.ImpactError as exc:
                say("[中止] 法規更新檢視重新打包失敗：%s" % exc)
                return 1
            if repacked is not None:
                at.merge(p["產出"], books)
                if health_law.LAST_CARRY[0]:
                    say("法規更新檢視：" + health_law.LAST_CARRY[0])
                else:
                    say("法規更新檢視：適不適用判好了，%s" % (
                        "%d 份影響審查包已打好（只放判適用／待確認的法規）" % repacked if repacked
                        else "沒有要再判的候選段（判不適用，或影響那一張已經填好）"))
            missing = at.unanswered(books, p["產出"])
            if missing:
                say("")
                # AI 審查是 AI 的事（SKILL.md）：講清楚不用人填
                say("繼續：停在 AI 審查（由 AI 自動完成，不用人填表）——還有 %s 沒填「AI判斷」："
                    "AI 讀 產出/2_Log檔案/%s/%s，填好那裡的表再跑 繼續"
                    % ("、".join("%s %d 列" % kv for kv in sorted(missing.items())), at.FOLDER, at.INDEX))
                return 0
        if command == last:
            say("繼續：%s 跑完了，下一站還是它（原因見上面），先停下來" % command)
            return 1
        say("")
        if command in ("開始", "體檢") and not step["說明"].startswith(("第一次跑", "還沒有")):
            # 檔案改過、清單改過：對使用者來說是「重新比對」（開新一輪），不是中途接著做；
            # 第一次跑（還沒有比對結果）照舊。體檢那一輪就是「重新體檢」
            say("── 重新%s：%s ──" % ("體檢" if command == "體檢" else "比對", step["說明"]))
        else:
            say("── 繼續：%s（%s）──" % (step["說明"], CHINESE_NAMES.get(command, command)))
        argv = [command] + (["--workspace", root] if getattr(args, "workspace", "") else [])
        sub = build_parser().parse_args(argv)
        sub.in_continue = True
        sub.skip_report = True           # 檢視報告整串跑完再重建一次（見 _refresh_review_reports）
        rc = _run_command(sub, settings, show_todo=False)
        label = _command_label(sub)
        if getattr(sub, "report_done", False):
            args.report_pending = False
        elif label in _BATCH_REPORT_COMMANDS:
            args.report_pending = True
        if rc:
            args.start_failed = command in ("開始", "體檢")
            return rc
        last = command
    say("繼續：已經連跑 %d 站，先停下來" % CONTINUE_MAX_STEPS)
    return 0


# ---------------------------------------------------------------------------
# 入口
# ---------------------------------------------------------------------------

def cmd_fetch_law(args, settings):
    """用法規來源介面讀官方原文，供引用查證使用。"""
    import law_sources as ls
    if args.max_chars < 1:
        say("!! 讀不到：--最多字 必須大於 0")
        return 1
    lines, failed = [], False
    for url in args.urls:
        lines.append("=== %s ===" % url)
        try:
            if not ls.official(url):
                raise ls.SourceError("自動讀取只接受政府及已列入的公會來源：%s" % url)
            raw = ls.fetch(url)
            suffix = ls.detect_format(raw, url)
            if suffix == ".html":
                # 無法辨識的二進位不可當成網頁文字印出。
                if b"\x00" in raw or raw.startswith((b"PK", b"\xd0\xcf\x11\xe0", b"\x89PNG", b"\xff\xd8")):
                    raise ls.SourceError("這是二進位附件，請下載後放進規範資料庫")
                page = ls.Page()
                page.feed(ls.decode(raw))
                text = page.text
            else:
                records = ls.records_from_bytes(raw, suffix, {"url": url})
                text = "\n\n".join(str(row.get("new_text") or "") for row in records)
            if len(text) > args.max_chars:
                text = text[:args.max_chars] + "\n（超過 %d 字，已截斷）" % args.max_chars
            lines.append(text)
        except (ls.SourceError, OSError, ValueError) as exc:
            failed = True
            lines.append("!! 讀不到：%s" % exc)
    output = "\n".join(lines) + "\n"
    if args.output:
        with io.open(args.output, "w", encoding="utf-8") as f:
            f.write(output)
    else:
        say(output.rstrip("\n"))
    return 1 if failed else 0


def build_parser():
    parser = argparse.ArgumentParser(description="reg 總入口")
    parser.add_argument("--workspace", default="",
                        help="工作區根目錄；沒給就看設定.html。可放在子命令前或後")
    sub = parser.add_subparsers(dest="command")

    import workspace_transfer as transfer
    p = sub.add_parser("打包工作區", aliases=["pack-workspace"])
    p.add_argument("--workspace", default=argparse.SUPPRESS)
    p.add_argument("--輸出", dest="output", default="")
    p.add_argument("--上次清單", dest="previous", default="")
    p.add_argument("--以我為準", dest="force_paths", nargs="+", action="extend", default=[])
    p.add_argument("--只要產出", dest="output_only", action="store_true")
    p.add_argument("--只要清單", dest="list_only", action="store_true")
    p.add_argument("--連同累積資料", dest="include_memo", action="store_true")
    p.set_defaults(func=transfer.pack)
    p = sub.add_parser("解開工作區", aliases=["unpack-workspace"])
    p.add_argument("zip_path")
    p.add_argument("--到", dest="destination", required=True)
    p.add_argument("--套用累積資料", dest="apply_memo", action="store_true")
    p.add_argument("--套用刪除", dest="apply_deletions", action="store_true")
    p.set_defaults(func=transfer.unpack)
    p = sub.add_parser("核對工作區", aliases=["verify-workspace"])
    p.add_argument("target")
    p.add_argument("--清單", dest="manifest", default="")
    p.set_defaults(func=transfer.verify)

    p = sub.add_parser("查法條", aliases=["讀官方頁", "fetch-law"], help="讀官方頁並輸出純文字供引用查證")
    p.add_argument("urls", nargs="+", help="一個或多個官方網址")
    p.add_argument("--輸出", dest="output", default="", help="UTF-8 文字檔路徑；省略印到畫面")
    p.add_argument("--最多字", dest="max_chars", type=int, default=20000, help="每個網址最多字數（預設 20000）")
    p.set_defaults(func=cmd_fetch_law)

    # 法規異動影響分析（law_impact）：用自己的 法規作業.json，不動正在進行的比對／體檢。
    # 使用者平常只說「法規追蹤」，之後說「繼續」就是「法規繼續」（程式自己判斷下一站）；其餘是給 AI 用的
    import law_impact
    for name, aliases, action, help_text in (
        ("法規設定", ["law-config"], "config", "建 匯入/法規追蹤.json（來源、適用資料；已經有的不動）"),
        ("法規追蹤", ["law-impact", "追蹤法規"], "start",
         "法規異動影響分析：抓法規異動 → 在現行內規找候選段 → 審查打包給 AI（預設最近 180 天）"),
        ("法規補入", ["law-supplement"], "supplement", "把 AI 上網查到的官方條文（證據檔）補進這一輪，重新打包"),
        ("法規審查匯入", ["law-review-import"], "import", "驗證兩張 AI 表並出法規追蹤報告（法規繼續會自己做這一步）"),
        ("法規繼續", ["law-continue"], "continue",
         "法規分析接著做：表沒填完就停、填完就匯入出報告；現行內規改過就開新一輪"),
        ("法規報告", ["law-report"], "report", "重出這一輪的法規追蹤報告與人工待辦"),
    ):
        p = sub.add_parser(name, aliases=aliases, help=help_text)
        _add_workspace_flag(p)
        p.set_defaults(func=cmd_law_start if action == "start" else law_impact.run, law_action=action)
        if action == "start":
            _add_settings_ok_flag(p)
            p.add_argument("--since", "--起日", default="", help="YYYY-MM-DD；省略為最近180日")
            p.add_argument("--until", "--迄日", default="", help="YYYY-MM-DD；省略為台灣今天")
            p.add_argument("--mode", "--模式", choices=["異動", "盤點"], default="異動")
        if action not in ("start", "config"):
            p.add_argument("--outdir", default="", help="指定法規作業；省略讀取 法規作業.json")
        if action == "supplement":
            p.add_argument("evidence", help="法規證據檔（JSON/XML/PDF/Word/文字）")

    runner = load_regdiff_runner()
    p = sub.add_parser("batch-review-pack", aliases=["審查打包"], help="批次第 1.5 步：逐本打包審查包給 AI 看")
    p.add_argument("outdir", nargs="?", default=None, help="省略時用工作區的 產出/")
    p.add_argument("--略過", "--skip", dest="skip", action="store_true",
                   help="這一輪不做 AI 審查（人工待辦不再提醒；之後想做直接再跑一次不加這個旗標）")
    p.add_argument("--per-file", dest="per_file", type=int, default=40)
    _add_max_chars_flag(p)
    _add_workspace_flag(p)
    p.set_defaults(func=cmd_batch_review_pack)

    p = sub.add_parser("batch-review-import", aliases=["審查匯入"],
                       help="批次第 1.5 步：逐本驗證匯入、彙整 LLM 審查總表")
    p.add_argument("outdir", nargs="?", default=None, help="省略時用工作區的 產出/")
    _add_workspace_flag(p)
    p.set_defaults(func=cmd_batch_review_import)

    p = sub.add_parser("batch-semantic", aliases=["語意併入"],
                       help="批次：把別台電腦算好的語意候選（產出/2_Log檔案/語意候選/<規章名>.csv）一次併回各本")
    p.add_argument("outdir", nargs="?", default=None, help="省略時用工作區的 產出/")
    p.add_argument("--dir", dest="semantic_dir", default=None,
                   help="算好的 <規章名>.csv 放在哪；省略時用 產出/2_Log檔案/語意候選/")
    p.add_argument("--略過", "--skip", dest="skip", action="store_true",
                   help="這一輪不做語意比對（人工待辦不再提醒）")
    _add_workspace_flag(p)
    p.set_defaults(func=cmd_batch_semantic)

    p = sub.add_parser("建工作區", aliases=["init-workspace"],
                       help="建立工作區：匯入/1_現行文件、匯入/2_修訂文件（舊版工作區順便遷移）")
    _add_workspace_flag(p)
    p.set_defaults(func=cmd_init_workspace)

    p = sub.add_parser("法規更動", aliases=["law-changed", "重查法規"],
                       help="外部法規改了：那部法規的查證紀錄作廢（下一次審查打包重新上網查），目前這一輪回到審查打包")
    p.add_argument("names", nargs="*", help="法規名稱，可以好幾個（例：保險法 洗錢防制法）")
    p.add_argument("--全部", "--all", dest="everything", action="store_true", help="所有查證紀錄都作廢、全部重查")
    _add_workspace_flag(p)
    p.set_defaults(func=cmd_law_changed)

    p = sub.add_parser("打開設定", aliases=["設定頁", "open-settings"],
                       help="用瀏覽器打開設定頁（本機小服務）：改了自動存回這個版本的 設定.html，不跳視窗；關掉設定頁就結束")
    p.add_argument("--不開瀏覽器", "--no-browser", dest="no_browser", action="store_true",
                   help="只開服務、印網址（自己貼到瀏覽器）")
    p.set_defaults(func=cmd_open_settings)

    p = sub.add_parser("打包分享", aliases=["分享", "share"],
                       help="把 skill 打成 zip 給別人用；一定要指定含不含內部知識（沒指定就只列出內部知識、不打包）")
    p.add_argument("--內部知識", "--internal", dest="internal", choices=["含", "不含"], default="",
                   help="含：本單位累積的知識一起包；不含：只包程式與公開資料")
    p.set_defaults(func=cmd_share)

    p = sub.add_parser("收回饋", aliases=["回饋寫完了", "回饋", "feedback"],
                       help="承辦在報告「承辦意見」欄寫完、存檔後：讀回來存成本單位判例，以後三條流程的 AI 都照著判")
    _add_workspace_flag(p)
    p.set_defaults(func=cmd_feedback)

    p = sub.add_parser("單位建議", aliases=["單位資料建議", "unit-profile"],
                       help="AI 讀現行規章，替設定頁「分析單位基本資料」三格提建議值（人在設定頁按採用才生效）")
    p.add_argument("--重做", "--redo", dest="redo", action="store_true", help="AI 填過的建議作廢、重新打包")
    _add_workspace_flag(p)
    p.set_defaults(func=cmd_unit_profile)

    p = sub.add_parser("資料庫", aliases=["整理資料庫", "rule-library"],
                       help="整理 skill 的 資料庫/（外部規範、內部規範）：從檔名認規範名稱、版本、日期，寫 目錄.csv")
    _add_workspace_flag(p)
    p.set_defaults(func=cmd_library)

    p = sub.add_parser("配對", help="配對 匯入/1_現行文件 與 匯入/2_修訂文件 的檔名，寫 規章清單.csv")
    _add_workspace_flag(p)
    p.set_defaults(func=cmd_pair)

    # 「重新比對」（新說法）、「重跑開始」（舊說法）：看完報告改了檔案再比一次，做的事就是 繼續
    # （程式發現檔案改過，自己開新一輪）；新舊說法都認得，對使用者講的時候一律用「重新比對」
    p = sub.add_parser("繼續", aliases=["continue", "重新比對", "重跑開始"],
                       help="照人工待辦接著跑：程式能做的站一站接一站做，做到要人（或 AI）動手的那一站停；"
                            "改了檔案再比一次（重新比對）也是這個")
    # 舊旗標：以前要帶才會停在報告；現在報告就是最後一站，帶不帶都一樣（照收，免得舊指令報錯）
    p.add_argument("--到報告", "--report-only", dest="report_only", action="store_true",
                   help="舊旗標，可以省略：報告產出就是最後一站")
    _add_settings_ok_flag(p)
    _add_workspace_flag(p)
    p.set_defaults(func=cmd_continue)

    p = sub.add_parser("開始", help="讀 規章清單.csv → 過期檢查 → 歸檔上一輪 → 批次初比對")
    _add_settings_ok_flag(p)
    _add_batch_flags(p, runner)
    _add_verbose_flag(p)
    _add_workspace_flag(p)
    p.set_defaults(func=cmd_start)

    p = sub.add_parser("體檢", aliases=["檢查現有文件", "health-check"],
                       help="檢查現有文件（不用修訂版）：條文檢查、內部／跨本／外部引用、結構提醒、重複／矛盾候選、"
                            "法規更新檢視（外部法規最近改了哪些、內規哪幾段要跟著改）；"
                            "之後照樣 審查打包 → AI 審查 → 審查匯入 → 體檢報告.xlsx")
    _add_settings_ok_flag(p)
    p.add_argument("--since", "--起日", dest="law_since", default="",
                   help="法規更新檢視的起日 YYYY-MM-DD；省略為最近 180 天")
    p.add_argument("--until", "--迄日", dest="law_until", default="", help="法規更新檢視的迄日；省略為今天")
    p.add_argument("--mode", "--模式", dest="law_mode", choices=["異動", "盤點"], default="異動",
                   help="盤點＝不看修正日，拿手上有的法規版本檢查內規")
    p.add_argument("--不查法規", "--skip-law", dest="skip_law", action="store_true",
                   help="這一輪不做法規更新檢視")
    _add_batch_flags(p, runner)
    _add_verbose_flag(p)
    _add_workspace_flag(p)
    p.set_defaults(func=cmd_health)

    return parser


DEBUG_ENV = "REG_DEBUG"


def debug_mode():
    """REG_DEBUG=1 時 main() 不收例外，直接讓 traceback 噴出來。

    「[中止] 一行字」對使用者是對的，對要修 bug 的人是災難——堆疊、哪一行、
    哪個檔全部被吃掉。留一個環境變數當逃生門，請使用者回報問題時重跑一次。
    """
    return (os.environ.get(DEBUG_ENV, "") or "").strip() not in ("", "0", "false", "False")


def _command_label(args):
    """從 args.func 反推子命令名（cmd_apply → apply），純粹是為了提醒文字好讀。"""
    name = getattr(getattr(args, "func", None), "__name__", "") or ""
    if name.startswith("cmd_"):
        name = name[4:]
    return name.replace("_", "-") or "執行"


def _abort_notice(args, text):
    """中止時把「為什麼中止」留下來：畫面那一行留不住（no 11）。

    只在產出資料夾*已經存在*的時候才接寫 提醒.txt——前置驗證擋下來的中止本來
    就沒建任何東西，為了寫一則提醒反而生出一個空資料夾，等於把剛擋掉的殘骸
    自己補回去。資料夾還不存在時就只有畫面那一行，跟以前一樣。
    """
    label = _command_label(args)
    try:
        import notices as nt
        nt.notice(nt.WARNING, "%s 中止：%s" % (label, text), label)
        outdir = getattr(args, "outdir", "") or ""
        if outdir and os.path.isdir(outdir):
            say("提醒留底：%s" % nt.write_notices(outdir, append=True,
                                                title="%s（中止）" % label))
    except Exception:
        # 留底失敗不能蓋掉「[中止]」那一行——那是使用者唯一看得到的線索。
        pass


# 跑完要更新 1_結果彙整/檢視報告.xlsx 的子命令：單本的直接看 outdir，批次的看產出根目錄底下每一本。
# finalize／batch-finalize 不在這裡：它們的結論要是畫面最後一行，自己在印結論之前更新。
# 開始、語意併入也不在這裡：它們後面一定還有審查打包、審查匯入，報告在那兩站才有東西可看，
# 十本每重建一次要十幾秒，前面建的馬上就被蓋掉。
_BATCH_REPORT_COMMANDS = ("batch-review-pack", "batch-review-import")


def _refresh_one_report(outdir, decisions=None, announce=False):
    """重建一本的 1_結果彙整/檢視報告.xlsx。檢視報告是附帶產物：出錯只印一行，
    不能讓這一步真正的產出（對照表、定稿、驗收報告）跟著失敗。"""
    import review_report as rr
    try:
        if outdir and os.path.isdir(outdir):
            path = rr.refresh(outdir, decisions)
            if path and announce:
                say("報告：%s" % path)
            return path
    except Exception as exc:
        say("提醒：報告沒有更新（%s：%s）" % (type(exc).__name__, exc))
    return None


def _refresh_batch_report(root):
    """重建 <產出根>/1_結果彙整/檢視報告.xlsx（多本合一）。出錯只印一行，理由同 _refresh_one_report。"""
    import review_report as rr
    try:
        if root and os.path.isdir(root):
            return rr.refresh_batch(root)
    except Exception as exc:
        say("提醒：報告沒有更新（%s：%s）" % (type(exc).__name__, exc))
    return None


def _remember_workspace(args, settings):
    """v1.19.0：這一次執行用哪個工作區（評分標準要附那個工作區的 匯入/單位事實.csv）。算不出來就不附。"""
    import unit_facts as uf
    try:
        import workspace as ws
        root = ws.resolve_root(getattr(args, "workspace", ""), settings)
        uf.set_workspace(root if ws.is_workspace(root) else "")
    except Exception:
        uf.set_workspace("")


def _pack_report_review(args, settings):
    """v1.18.0：比對、體檢這一輪的表都匯入了、報告也出了，AI 報告審查還沒做：照最新的報告打包審查包。
    法規追蹤自己在 law_impact 打包。出錯只印一行，不擋這一步的結果。"""
    if _command_label(args) not in _BATCH_COMMANDS:
        return
    root = _batch_root_for(args, settings)
    try:
        import batch as bt
        import report_review as rv
        import review_report as rr
        import todo
        from _common import place
        if not root or not bt.is_batch_root(root) or not rv.pending(root, settings):
            return
        if not todo.next_step(root, todo.workspace_of(root)).get("報告審查"):
            return
        # 報告開在 Excel 裡時這一次存成「檢視報告_HHMMSS.xlsx」：審查最新寫出的那一份
        import glob
        base = os.path.splitext(place(root, rr.report_name(root)))[0]
        found = [p for p in glob.glob(glob.escape(base) + "*.xlsx") if not os.path.basename(p).startswith("~$")]
        if found:
            rv.pack(root, max(found, key=os.path.getmtime), "體檢" if bt.is_health_round(root) else "比對")
    except Exception as exc:
        say("提醒：AI 報告審查包沒有打好（%s：%s）" % (type(exc).__name__, exc))


def _refresh_review_reports(args):
    """每一步跑完就重建一次檢視報告：它是彙整各步驟報告的那一份，永遠要是當下最新的。
    不管這一步成功或中止都重建（中止也可能留下新的提醒）。"""
    if getattr(args, "report_done", False) or getattr(args, "skip_report", False):
        return                           # 這一步自己已經更新過（batch-apply 接著驗收）；或是「繼續」裡的一站
    label = _command_label(args)
    if label == "continue":
        # 「繼續」連跑好幾站：各站不重建，整串跑完最後重建一次（最後一站自己更新過就不用）
        if getattr(args, "report_pending", False):
            path = _refresh_batch_report(getattr(args, "outdir", "") or "")
            if path:
                say("報告：%s（各本合一，第一欄是規章名）" % show_path(path))
        return
    if label in _BATCH_REPORT_COMMANDS:
        path = _refresh_batch_report(getattr(args, "outdir", "") or "")
        if path:
            say("報告：%s（各本合一，第一欄是規章名）" % show_path(path))


# 批次子命令：跑完把各本的成品排到 產出/1_結果彙整/（見 result_publish）、重寫人工待辦。
_BATCH_COMMANDS = ("start", "health", "batch-review-pack", "batch-review-import", "batch-semantic", "continue")


def _batch_root_for(args, settings):
    """這個批次子命令要動的產出根目錄（還沒補工作區預設值時也算得出來）；算不出來回空字串。"""
    outdir = getattr(args, "outdir", "") or ""
    if outdir:
        return os.path.abspath(outdir)
    try:
        import workspace as ws
        return ws.paths(ws.resolve_root(getattr(args, "workspace", ""), settings))["產出"]
    except Exception:
        return ""


def _publish_results(args, settings):
    """各本的成品排到 產出/1_結果彙整/（先分種類、同種類各規章放一起），見 result_publish。
    出錯只印一行，不擋這一步的結果。"""
    if _command_label(args) not in _BATCH_COMMANDS:
        return
    root = _batch_root_for(args, settings)
    if not root or not os.path.isdir(root):
        return
    import result_publish as rpub
    try:
        rpub.publish(root, say=say)
    except Exception as exc:
        say("提醒：1_結果彙整/ 沒有更新（%s：%s）" % (type(exc).__name__, exc))


def _refresh_todo(args, settings, rc=0):
    """批次指令跑完，重寫 產出/2_Log檔案/人工待辦.txt，畫面最後印「現在要做」（見 todo.py）。
    待辦清單是附帶產物：出錯只印一行，不擋這一步。
    「開始」中止（清單過期、上一輪的檔沒換……）時不印：那時候清單講的還是上一輪的事
    （以前開始中止了，最後一行還叫人去跑套用）。"""
    label = _command_label(args)
    if label not in _BATCH_COMMANDS:
        return
    if rc and (label in ("start", "health") or getattr(args, "start_failed", False)):
        say("")
        say("人工待辦：這一步沒有跑完（原因見上面），處理好再跑一次 %s"
            % ({"start": "開始", "health": "體檢"}.get(label, "繼續")))
        return
    root = _batch_root_for(args, settings)
    import batch as bt
    if not bt.is_batch_root(root):
        return
    import todo
    try:
        for line in todo.refresh(root, workspace_flag(args), _cmd):
            say(line)
    except Exception as exc:
        say("提醒：人工待辦清單沒有更新（%s：%s）" % (type(exc).__name__, exc))


def _order_problem(args, command):
    """批次指令跑錯站（見 todo.order_problem）：印一句話；該擋的回 True，呼叫端 return 1。"""
    if getattr(args, "in_continue", False) or getattr(args, "report_done", False):
        return False                       # 繼續／套用後接著驗收：本來就照順序
    import batch as bt
    import todo
    root = getattr(args, "outdir", "") or ""
    if not root or not bt.is_batch_root(root):
        return False
    try:
        found = todo.order_problem(root, command)
    except Exception:
        return False                       # 判斷不了（產出壞了）：交給指令自己講清楚錯在哪
    if not found:
        return False
    stop, sentence = found
    say(("[順序] %s" if stop else "[提醒] %s") % sentence)
    return stop


_QUIET_READ_COMMANDS = ("batch-review-pack", "batch-review-import", "batch-semantic")


# v1.24.0：不碰工作區（或自己會建工作區）的指令；其他指令要先有工作區、同一時間一個工作區只跑一個
_NO_WORKSPACE_COMMANDS = ("init-workspace", "open-settings", "share", "library")
LOCK_FILE = ".執行中.json"
LOCK_HOURS = 12                 # 鎖超過這麼久當成殘留（電腦當過、強制關掉）
_lock_depth = [0]


def _pid_alive(pid):
    """這個 pid 的程式還在跑嗎（Windows 用 OpenProcess，其他系統用 kill 0）。"""
    try:
        pid = int(pid)
    except (TypeError, ValueError):
        return False
    if pid == os.getpid():
        return True
    if os.name == "nt":
        import ctypes
        handle = ctypes.windll.kernel32.OpenProcess(0x1000, False, pid)      # PROCESS_QUERY_LIMITED_INFORMATION
        if not handle:
            return False
        code = ctypes.c_ulong()
        try:
            ok = ctypes.windll.kernel32.GetExitCodeProcess(handle, ctypes.byref(code))
        finally:
            ctypes.windll.kernel32.CloseHandle(handle)
        return bool(ok) and code.value == 259                               # STILL_ACTIVE
    try:
        os.kill(pid, 0)
    except OSError:
        return False
    return True


def _workspace_guard(args, settings):
    """指令開始前：工作區要存在（打錯名字不再自己開一個空的）、沒有別的指令正在跑同一個工作區。
    回傳 (可以跑嗎, 鎖檔路徑或 "")。"""
    from _common import tw_now, tw_today
    import datetime
    import json
    if _command_label(args) in _NO_WORKSPACE_COMMANDS or _lock_depth[0]:
        return True, ""
    try:
        import workspace as wsm
        given = getattr(args, "workspace", "") or ""
        root = wsm.resolve_root(given, settings)
    except Exception:
        return True, ""
    if not os.path.isdir(root):
        base = wsm.workspace_base(root)
        others = [os.path.basename(p) for p in wsm.dated_workspaces(base)]
        if os.path.isdir(base):
            others.insert(0, os.path.basename(base))
        say("[中止] 找不到工作區：%s" % root)
        say("  現有的工作區：%s" % ("、".join(others) if others else "（這裡還沒有任何工作區）"))
        say("  名字打錯了就用上面其中一個；要開新案子才說「建工作區」（只有建工作區會開新的資料夾）")
        return False, ""
    path = os.path.join(root, LOCK_FILE)
    try:
        with open(path, encoding="utf-8") as f:
            held = json.load(f)
    except (OSError, ValueError):
        held = None
    if held and _pid_alive(held.get("pid")):
        try:
            started = datetime.datetime.fromisoformat(held.get("開始", ""))
            started = started if started.tzinfo else started.replace(tzinfo=tw_now().tzinfo)
            minutes = int((tw_now() - started).total_seconds() // 60)
        except ValueError:
            minutes = 0
        if minutes < LOCK_HOURS * 60:
            say("[中止] 這個工作區正在跑「%s」（%d 分鐘前開始）：等它跑完再跑這一個，免得兩邊同時改同一批檔案"
                % (held.get("指令", "另一個指令"), minutes))
            say("  確定沒有在跑（例如電腦當過、視窗被強制關掉）：刪掉 %s 再跑一次" % path)
            return False, ""
    try:
        with open(path, "w", encoding="utf-8") as f:
            json.dump({"pid": os.getpid(), "指令": _command_label(args),
                       "開始": tw_now().isoformat(timespec="seconds")}, f, ensure_ascii=False)
    except OSError:
        return True, ""
    _say_migrated(wsm.migrate_output_names(root))
    return True, path


def _say_migrated(done):
    """v1.26.0：舊的產出資料夾改名（加上是哪一條流程）之後講一句；什麼都沒改就不講。"""
    folders = done.get("資料夾") or []
    if folders:
        sample = "、".join("%s → %s" % pair for pair in folders[:3])
        say("整理產出資料夾名稱：%d 個加上流程名（%s%s），裡面的報告也改成「流程報告_日期序號」"
            % (len(folders), sample, "…" if len(folders) > 3 else ""))
    elif done.get("報告"):
        say("整理報告檔名：%d 份改成「流程報告_日期序號」" % done["報告"])
    for line in (done.get("沒改") or [])[:5]:
        say("  沒改名：%s" % line)


def _run_command(args, settings, show_todo=True):
    """跑一個子命令，跑完把成品排到 1_結果彙整/、更新檢視報告與人工待辦。
    main 與「繼續」（一次接著跑好幾個子命令，只在最後印一次人工待辦）共用。"""
    ok, lock = _workspace_guard(args, settings)
    if not ok:
        return 1
    _lock_depth[0] += 1
    try:
        return _run_command_locked(args, settings, show_todo)
    finally:
        _lock_depth[0] -= 1
        if lock:
            try:
                os.remove(lock)
            except OSError:
                pass


def _run_command_locked(args, settings, show_todo=True):
    import _common as cm
    _remember_workspace(args, settings)
    # 開始之後的站重讀同一批檔：讀檔提醒開始已經印過、留過底，不再印
    quiet = cm.quiet_read_notices(_command_label(args) in _QUIET_READ_COMMANDS)
    try:
        rc = args.func(args, settings)
    finally:
        cm.quiet_read_notices(quiet)
    _publish_results(args, settings)
    # 重建檢視報告會把每一本再讀一次：讀檔提醒在比對那一步就講過了，這裡一律不印
    quiet = cm.quiet_read_notices(True)
    try:
        _refresh_review_reports(args)
    finally:
        cm.quiet_read_notices(quiet)
    _pack_report_review(args, settings)
    if show_todo:
        _refresh_todo(args, settings, rc)
    return rc


def main(argv=None):
    setup_stdout()
    parser = build_parser()
    args = parser.parse_args(argv)
    if not getattr(args, "func", None):
        parser.print_help()
        return 1
    from _common import InputError
    try:
        import workspace_transfer as transfer
        if args.func in (transfer.pack, transfer.unpack, transfer.verify):
            return transfer.execute_locked(args, load_settings() if args.func is transfer.pack else {})
        if args.func is cmd_fetch_law:
            return args.func(args, {})
        settings = load_settings()
        if os.environ.get("REG_NO_HW_RECORD") != "1":
            from _common import record_hardware
            record_hardware()             # v1.12.1：記憶體、CPU 記進設定.html（設定頁看不到記憶體）
        return _run_command(args, settings)
    except KeyboardInterrupt:
        # Ctrl+C 不是程式壞了，照原樣往上丟，不要偽裝成「[中止]」。
        raise
    except (OSError, UnicodeDecodeError, InputError) as exc:
        # no 11：以前這裡只有 return args.func(...)。檔案開在 Word 裡（Windows 鎖檔）、
        # outdir 指到檔案、UNC 掉線、唯讀磁碟、編碼猜錯——使用者看到的一律是
        # 一坨 Python traceback，跟專案其他地方的「[中止] …」完全不同調，
        # 根本分不出是自己弄錯還是程式有 bug。
        if debug_mode():
            # I2：要修 bug 的人自己開的逃生門，原樣噴 traceback。
            raise
        # I2：例外類別名一定要印出來。「[中止] [Errno 13] 拒絕存取」看不出是權限
        # 問題還是檔案被鎖，寫成「PermissionError：…」回報的人不用附 traceback
        # 就講得清楚是哪一類。
        say("[中止] %s：%s（要看完整錯誤請設 %s=1 重跑）"
            % (type(exc).__name__, exc, DEBUG_ENV))
        _abort_notice(args, "%s：%s" % (type(exc).__name__, exc))
        return 1


if __name__ == "__main__":
    sys.exit(main())
