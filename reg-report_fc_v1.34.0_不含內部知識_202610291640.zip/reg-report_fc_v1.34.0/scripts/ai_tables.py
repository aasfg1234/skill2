# -*- coding: utf-8 -*-
"""
批次的 AI 表：每一種一張、全部規章合在一起（第一欄是規章），放 產出/2_Log檔案/AI審查/。

以前 AI 要到 產出/2_Log檔案/<規章名>/2_Log檔案/ 逐本填四張表：二十本就是八十個檔，漏一本整批退件。
現在 batch-review-pack 逐本寫完之後合成四張，另寫一份 先讀我.md（這一批還要讀哪幾份審查資料、
四張表各有幾列要填）與整批共用的 評分標準.md。AI 只填這四張。

程式內部照舊一本一份（review-import 的驗證、指紋、報告都靠各本那一份）。合一表寫回各本時
只寫 AI 這次改過的格：打包當時每一列的答案記在 合一表紀錄.json，跟那時候不一樣的格才算 AI 填的。
所以 AI 照舊直接填各本那一份也照樣算——合一表沒動，就不會去蓋各本。
"""

import csv
import glob
import io
import json
import os
import re
import sys
import unicodedata

HERE = os.path.dirname(os.path.abspath(__file__))
REGDIFF = os.path.join(HERE, "regdiff")
for _path in (HERE, REGDIFF):
    if _path not in sys.path:
        sys.path.insert(0, _path)

from _common import SYSTEM_DIR, locate, open_csv

FOLDER = "AI審查"
BOOK = "規章"
INDEX = "先讀我.md"
RECORD = "合一表紀錄.json"
NEW_ID = "新增"
REUSED = "沿用查證"
# (檔名, 編號欄, AI 填的欄)
SPECS = (
    ("AI候選判斷.csv", "列ID", ("AI判斷", "AI分數", "AI理由")),
    ("AI異動審查.csv", "異動ID", ("AI判斷", "AI分數", "AI理由", "查證來源")),
    ("AI條文檢查.csv", "檢查ID", ("AI判斷", "AI理由", "查證來源")),
    ("AI外部引用.csv", "引用ID", ("AI判斷", "AI理由", "AI更正", "查證來源", "類別")),
)


def folder(root):
    return os.path.join(root, SYSTEM_DIR, FOLDER)


def _s(value):
    return "" if value is None else str(value).strip()


def _read(path):
    with open_csv(path) as f:
        reader = csv.DictReader(f)
        return list(reader.fieldnames or []), list(reader)


def _write(path, fields, rows):
    tmp = path + ".tmp"
    with io.open(tmp, "w", encoding="utf-8-sig", newline="") as f:
        writer = csv.writer(f, quoting=csv.QUOTE_ALL)
        writer.writerow(fields)
        for row in rows:
            writer.writerow([row.get(c, "") for c in fields])
    os.replace(tmp, path)


def _key(book, rid):
    return "%s\x00%s" % (book, rid)


def _answers(row, columns):
    return dict((c, _s(row.get(c))) for c in columns)


_FLOAT_INT_RE = re.compile(r"^-?\d+\.0+$")


def _cell_key(value):
    """指紋用的格子值：去頭尾空白、全形轉半形、「12.0」當成「12」。
    AI 用 pandas 或 Excel 轉存 CSV，數字欄常變成 12.0、罕用字變成全形／半形的另一種寫法，
    以前每一列都退件還說「AI 不該動的欄被改過了」（審查 C10）。"""
    text = unicodedata.normalize("NFKC", _s(value))
    if _FLOAT_INT_RE.match(text):
        text = text.split(".")[0]
    return text


def _fingerprint(row, columns):
    """一列「AI 不填的欄」的指紋：寫回時拿來確認各本那一列還是打包時的同一列（A11）。"""
    import hashlib
    skip = set(columns) | {BOOK}
    # 空欄不算：合一表的欄是各本欄位的聯集，某一本沒有的欄讀回來是空字串
    text = "\x1f".join("%s=%s" % (k, _cell_key(v)) for k, v in sorted(row.items())
                       if k and k not in skip and _cell_key(v))
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def merge(root, books):
    """batch-review-pack 逐本寫完之後呼叫：各本的四張 AI 表合成四張放 AI審查/，
    記下打包當時的答案（合一表紀錄.json），寫 先讀我.md。回傳 {檔名: (列數, 還沒填的列數)}。"""
    out = folder(root)
    os.makedirs(out, exist_ok=True)
    record, counts, waiting = {}, {}, {}
    for filename, id_col, columns in SPECS:
        fields, merged, answers, new_rows, prints = [], [], {}, {}, {}
        for name, outdir_doc in books:
            path = locate(outdir_doc, filename)[0]
            if not os.path.isfile(path):
                continue
            book_fields, rows = _read(path)
            for c in book_fields:
                if c not in fields:
                    fields.append(c)
            for row in rows:
                rid = _s(row.get(id_col))
                merged.append(dict(row, **{BOOK: name}))
                if rid == NEW_ID:
                    new_rows.setdefault(name, []).append(dict(row))
                elif rid:
                    answers[_key(name, rid)] = _answers(row, columns)
                    prints[_key(name, rid)] = _fingerprint(row, columns)
        path = os.path.join(out, filename)
        if not fields:
            if os.path.isfile(path):
                os.remove(path)          # 這一批沒有這種表：不留上一次的
            continue
        _write(path, [BOOK] + fields, merged)
        record[filename] = {"列": answers, "新增": new_rows, "指紋": prints}
        open_rows = [r for r in merged if not _s(r.get(REUSED)) and not _s(r.get("AI判斷"))]
        counts[filename] = (len(merged), len(open_rows))
        for r in open_rows:
            waiting.setdefault(filename, {}).setdefault(_s(r.get(BOOK)), set()).add(_s(r.get(id_col)))
    # 先寫 .tmp 再換名：寫到一半被中斷（Ctrl+C、磁碟滿）留下半個 json，之後每一站 split 都 traceback（審查 C6）
    record_path = os.path.join(out, RECORD)
    with io.open(record_path + ".tmp", "w", encoding="utf-8") as f:
        json.dump(record, f, ensure_ascii=False)
    os.replace(record_path + ".tmp", record_path)
    import scoring_rubric as sr
    import health_law
    import health_typo
    law_lines = health_law.readme_lines(root)
    typo_lines = health_typo.readme_lines(root)
    with io.open(os.path.join(out, sr.RUBRIC_FILE), "w", encoding="utf-8") as f:
        f.write(sr.render_all(law=bool(law_lines), typo=bool(typo_lines)))
    lines = ["# AI 審查：這一批要做的事", "",
             "只填這個資料夾裡下面列的表（第一欄是規章；「沿用查證」有值的列程式已經填好，不用管）。",
             "先讀同一個資料夾的 `%s`（每一種表怎麼判、怎麼打分，整批只有這一份）；" % sr.RUBRIC_FILE
             + "外部引用先看各本清單第零節的官方原文；未附原文及條文檢查仍要上網查證。",
             "審查包裡的候選只寫異動編號（C3），那一處的新舊文與前後文在該本的 LLM異動清單.md：先讀異動清單再讀審查包。",
             "填完回到 reg-report 的 skill 資料夾（有 scripts/ 的那一層）跑 `python scripts/run_all.py 繼續`"
             "（或 審查匯入）。", "",
             "## 這一輪要填的表（只列還有空格的）", ""]
    done = []
    for filename, _, _ in SPECS:
        if filename in counts:
            total, left = counts[filename]
            if left:
                lines.append("- `%s`：%d 列，要填 %d 列" % (filename, total, left))
                if filename == "AI外部引用.csv":
                    import review_pack as rp
                    attached = 0
                    for book_name, outdir_doc in books:
                        path = rp.place(outdir_doc, "LLM外部引用清單.md")
                        if os.path.isfile(path):
                            with io.open(path, encoding="utf-8") as source:
                                text = source.read()
                            for rid in waiting.get(filename, {}).get(book_name, set()):
                                start = text.find("## " + rid + "　段次")
                                end = text.find("\n## ", start + 1) if start >= 0 else -1
                                if start >= 0 and "官方原文：見〈零〉" in text[start:end if end >= 0 else None]:
                                    attached += 1
                    lines.append("  其中 %d 列程式已附官方原文（見 LLM外部引用清單.md 第零節）。" % attached)
            elif total:
                done.append(filename)
    import health_check as hc
    if os.path.isfile(os.path.join(out, hc.TABLE_FILE)):
        # 體檢：重複／矛盾候選整批一張表，放在同一個資料夾
        _, pair_rows = _read(os.path.join(out, hc.TABLE_FILE))
        left = hc.unanswered(root)
        if left:
            lines.append("- `%s`：%d 對，要填 %d 對（兩段全文與前後文在同資料夾的 `%s`；判法見評分標準「一致性」）"
                         % (hc.TABLE_FILE, len(pair_rows), left, hc.PACK_FILE))
        elif pair_rows:
            done.append(hc.TABLE_FILE)
    if os.path.isfile(os.path.join(out, hc.FAMILY_TABLE_FILE)):
        # v1.31.0：3 段以上、同一個範本改出來的好幾段，一個家族一列
        _, family_rows = _read(os.path.join(out, hc.FAMILY_TABLE_FILE))
        left = hc.unanswered(root, hc.FAMILY_TABLE_FILE)
        if left:
            lines.append("- `%s`：%d 個家族，要填 %d 個（各段全文與前後文在同資料夾的 `%s`；"
                         "矛盾、錯漏字、重複要填「有問題的段」，矛盾、錯漏字還要填「對照段」）"
                         % (hc.FAMILY_TABLE_FILE, len(family_rows), left, hc.PACK_FILE))
        elif family_rows:
            done.append(hc.FAMILY_TABLE_FILE)
    for name, left in sorted(health_law.unanswered(root).items()):
        lines.append("- `%s`：要填 %d 列（見下面「法規更新檢視」）" % (name, left))
    typo_left = health_typo.unanswered(root)
    if typo_left:
        lines.append("- `%s`：要讀 %d 份（見下面「錯漏字檢查」）" % (health_typo.TABLE_FILE, typo_left))
    if done:
        lines.append("- 已經全部填好（沿用判過的答案），不用動：%s" % "、".join("`%s`" % n for n in done))
    lines += typo_lines + law_lines
    import learned
    learned.ensure_synonym_template(root)      # v1.20.0：AI 順手提的同義詞（選填）
    lines += learned.synonym_readme_lines()
    import rule_library
    lines += rule_library.readme_lines()       # v1.9.0：資料庫有圖片電腦轉不出字，請 AI 看圖打字
    lines += ["", "## 要讀的審查資料（已經全部填好的不列）", ""]
    listed = _files_to_read(books, waiting)
    for name, outdir_doc in books:
        if not listed.get(name):
            continue
        rel = "%s/%s/%s/%s/" % (os.path.basename(os.path.normpath(root)), SYSTEM_DIR, name, SYSTEM_DIR)
        lines.append("- %s：%s" % (name, "、".join("`%s%s`" % (rel, f) for f in listed[name])))
    if not any(listed.values()):
        lines.append("（沒有要 AI 判的列：直接跑 繼續）")
    with io.open(os.path.join(out, INDEX), "w", encoding="utf-8") as f:
        f.write("\n".join(lines) + "\n")
    return counts


# 每種清單對哪一張 AI 表：那一本在那張表還有列要填，才叫 AI 讀那份清單
_LIST_FOR_TABLE = (("LLM條文檢查清單.md", "AI條文檢查.csv"), ("LLM外部引用清單.md", "AI外部引用.csv"))


def _files_to_read(books, waiting):
    """{規章: [要讀的檔名...]}。以前每一本的每一份都列，AI 已經判過、內容沒變而沿用答案的也照讀一次。
    審查包：裡面有還沒填的候選列才列。異動清單：這本還有異動要審，或是要讀的審查包裡有候選掛它的異動。
    條文檢查、外部引用清單：那張表這本還有列要填才列。"""
    import review_pack as rp
    listed, change_lists = {}, set()
    for name, outdir_doc in books:
        open_cands = waiting.get("AI候選判斷.csv", {}).get(name, set())
        try:
            with io.open(locate(outdir_doc, rp.PACK_INDEX)[0], encoding="utf-8") as f:
                index = json.load(f)
        except (OSError, ValueError):
            index = None
        packs = []
        if index is None:
            # 沒有索引（舊產出）：有列要填就整本的審查包都列
            if open_cands:
                system = os.path.join(outdir_doc, SYSTEM_DIR)
                packs = sorted(os.path.basename(p) for p in glob.glob(os.path.join(system, "LLM審查包_*.md")))
                change_lists.add(name)
        else:
            for pack, ids in sorted(index.get("審查包", {}).items()):
                hit = [rid for rid in ids if rid in open_cands]
                if hit:
                    packs.append(pack)
                    change_lists.add(name)
                    for rid in hit:
                        change_lists.update(index.get("跨本異動清單", {}).get(rid) or [])
        if waiting.get("AI異動審查.csv", {}).get(name):
            change_lists.add(name)
        listed[name] = packs
    for name, outdir_doc in books:
        files = (["LLM異動清單.md"] if name in change_lists else []) + listed[name]
        for list_file, table in _LIST_FOR_TABLE:
            if waiting.get(table, {}).get(name):
                files.append(list_file)
        listed[name] = files
    return listed


def _plain(row):
    return dict((k, _s(v)) for k, v in row.items() if k != BOOK)


def split(root, books):
    """合一表上 AI 改過的格寫回各本（batch-review-pack 重新打包前、batch-review-import 驗證前呼叫）。
    回傳 (錯誤 list, {規章: 寫回的格數}, 提醒 list)；有錯誤就一格都不寫。
    沒有合一表（還沒打包、或不是這一版打包的）回 ([], {}, [])。
    打包時有、這次不在 books 裡的本（產出不完整被略過）：AI 沒動的列不管；AI 填過的列講一聲、先不寫回。"""
    out = folder(root)
    record_path = os.path.join(out, RECORD)
    if not os.path.isfile(record_path):
        return [], {}, []
    try:
        with io.open(record_path, encoding="utf-8") as f:
            record = json.load(f)
        if not isinstance(record, dict):
            raise ValueError("內容不是一組對照表")
    except (OSError, ValueError) as exc:
        # 壞檔不要 traceback：講清楚怎麼修（重新打包會重寫這個檔）
        return ["%s 讀不出來（%s）：請重跑審查打包（會重寫它）" % (RECORD, exc)], {}, []
    known = dict(books)
    errors, plans, notes = [], [], []
    for filename, id_col, columns in SPECS:
        path = os.path.join(out, filename)
        if filename not in record or not os.path.isfile(path):
            continue
        before = record[filename]
        try:
            _, rows = _read(path)
        except (OSError, UnicodeDecodeError, csv.Error, ValueError) as exc:
            errors.append("%s/%s 讀不出來：%s" % (FOLDER, filename, exc))
            continue
        changes, new_rows, seen = {}, {}, set()
        recorded = set(k.split("\x00")[0] for k in before["列"]) | set(before["新增"])
        for line, row in enumerate(rows, 2):
            book, rid = _s(row.get(BOOK)), _s(row.get(id_col))
            if not book and not rid:
                continue
            tag = "%s/%s 第 %d 列（%s %s）" % (FOLDER, filename, line, book or "沒寫規章", rid or "沒有編號")
            if book not in known:
                if book not in recorded:
                    errors.append("%s：規章「%s」不在這一批" % (tag, book))
                    continue
                old = before["列"].get(_key(book, rid))
                touched = (_plain(row) not in [_plain(r) for r in before["新增"].get(book, [])] if rid == NEW_ID
                           else old is None or any(_s(row.get(c)) != old.get(c, "") for c in columns))
                if touched:
                    notes.append("%s：%s 這次沒有進批次（產出不完整？），AI 填的這一列先沒寫回" % (tag, book))
                continue
            if rid == NEW_ID:
                new_rows.setdefault(book, []).append(dict((k, v) for k, v in row.items() if k != BOOK))
                continue
            old = before["列"].get(_key(book, rid))
            if old is None:
                errors.append("%s：這一本打包時沒有這一列（編號不要改）" % tag)
                continue
            if (book, rid) in seen:
                errors.append("%s：同一列出現兩次" % tag)
                continue
            seen.add((book, rid))
            fingerprint = before.get("指紋", {}).get(_key(book, rid))
            if fingerprint and _fingerprint(row, columns) != fingerprint:
                errors.append("%s：AI 不該動的欄（全文、段次、編號…）被改過了；只填 %s"
                              % (tag, "、".join(columns)))
                continue
            cells = dict((c, _s(row.get(c))) for c in columns if _s(row.get(c)) != old.get(c, ""))
            if cells:
                changes.setdefault(book, {})[rid] = cells
        for book in sorted((set(changes) | set(new_rows) | set(before["新增"])) & set(known)):
            merged_new = new_rows.get(book, [])
            new_changed = ([dict((k, _s(v)) for k, v in r.items()) for r in merged_new]
                           != [dict((k, _s(v)) for k, v in r.items()) for r in before["新增"].get(book, [])])
            if not changes.get(book) and not new_changed:
                continue
            book_path = locate(known[book], filename)[0]
            if not os.path.isfile(book_path):
                errors.append("%s：找不到 %s 的 %s" % (FOLDER, book, filename))
                continue
            # 各本那一張在打包之後變過（例如語意併入後重寫，列ID 位移）：照列ID 寫回會把答案
            # 掛到別的候選上，review-import 也驗不出來（A11）。這時候不寫，請重新打包
            prints = before.get("指紋", {})
            if prints and changes.get(book):
                try:
                    _, current = _read(book_path)
                except (OSError, UnicodeDecodeError, csv.Error, ValueError) as exc:
                    errors.append("%s 的 %s 讀不出來：%s" % (book, filename, exc))
                    continue
                now = dict((_s(r.get(id_col)), _fingerprint(r, columns)) for r in current)
                moved = [rid for rid in changes[book] if prints.get(_key(book, rid)) not in (None, now.get(rid))]
                if moved:
                    errors.append("%s 的 %s 在打包之後變過（%s 已經不是打包時的那一列）：AI 的答案不能照編號寫回，"
                                  "請重跑 審查打包（batch-review-pack），AI 照新的表再填"
                                  % (book, filename, "、".join(moved[:5])))
                    continue
            plans.append((book, book_path, id_col, changes.get(book, {}), merged_new if new_changed else None))
    if errors:
        return errors, {}, notes          # 有錯就一格都不寫：不留一半寫回、一半沒寫的各本
    written = {}
    for book, book_path, id_col, cells_by_id, merged_new in plans:
        fields, book_rows = _read(book_path)
        count = 0
        for row in book_rows:
            cells = cells_by_id.get(_s(row.get(id_col)))
            if cells:
                row.update(cells)
                count += len(cells)
        if merged_new is not None:
            book_rows = [r for r in book_rows if _s(r.get(id_col)) != NEW_ID] + merged_new
            count += len(merged_new)
        _write(book_path, fields, book_rows)
        written[book] = written.get(book, 0) + count
    return errors, written, notes


def unanswered(books, root=None):
    """各本的四張 AI 表還有幾列沒填「AI判斷」（程式先填好的「沿用查證」列不算）：{檔名: 列數}，只列有缺的。
    root（產出根目錄）有給就連體檢的 AI一致性.csv（整批一張、放 AI審查/）一起算。"""
    missing = {}
    if root:
        import health_check as hc
        import health_law
        count = hc.unanswered(root)
        if count:
            missing[hc.TABLE_FILE] = count
        count = hc.unanswered(root, hc.FAMILY_TABLE_FILE)
        if count:
            missing[hc.FAMILY_TABLE_FILE] = count
        missing.update(health_law.unanswered(root))     # 體檢的法規更新檢視（v1.6.0）
        import health_typo
        count = health_typo.unanswered(root)                # 體檢的錯漏字檢查（v1.7.0）：還沒讀完的份數
        if count:
            missing[health_typo.TABLE_FILE] = count
    for filename, _, _ in SPECS:
        for _, outdir_doc in books:
            path = locate(outdir_doc, filename)[0]
            if not os.path.isfile(path):
                continue
            try:
                _, rows = _read(path)
            except (OSError, UnicodeDecodeError, csv.Error, ValueError):
                continue
            count = sum(1 for r in rows if not _s(r.get(REUSED)) and not _s(r.get("AI判斷")))
            if count:
                missing[filename] = missing.get(filename, 0) + count
    return missing
