# -*- coding: utf-8 -*-
"""一段文字裡的款目怎麼切：切條（S4 二次切分）與比對（regdiff 算段內款目的條號）共用這一份。

切點規則原封不動搬自 S4（scripts/diffcut/S4_二次切分.py），改規則只改這裡：
  - 全文沒有換行，絕對不靠「行開頭」判斷
  - 只排除「前面是第」與「後面是條款項目章節點」等引用寫法（candidates 的排除一～六）
  - 第一個切點之前的文字獨立成母文，不跟第一項合併
  - 每層都繼續辨識 B / C / D / E，不以字數決定是否停止
cut() 一律無損：切出來接回去不等於原文就當作切不開。
"""

import re

from reg_structure import ARTICLE_RE, ITEM_CN, cited_mark, item_num


def cn2int(s):
    # 認到九百九十九（「一百零一、」）。以前只認到九十九：一百以後的點在 S3 黏成一筆，
    # 這裡再從「一百零一、」中間認出「一、」切下去，QA 擋「切在句子中間」
    return item_num(s)


STOP_AFTER = "條款項目章節點"


# ------------------------------------------------------------------
# 候選符號。括號類要先找，才不會被 A、C 搶走
# ------------------------------------------------------------------
FINDERS = [
    ("B", re.compile(r"[（(]\s*(%s)\s*[）)]" % ITEM_CN)),
    ("D", re.compile(r"[（(]\s*(\d{1,3})\s*[）)]")),
    ("A", re.compile(r"(%s)\s*[、，,]" % ITEM_CN)),
    # 「1.5%」「2.5 倍」的點是小數點，不是編號（B24）
    ("C", re.compile(r"(\d{1,3})\s*(?:、|[.．](?![0-9０-９]))")),
    ("E", re.compile(r"([A-Za-z])\s*[.．]")),
]


PAIRS = [("《", "》"), ("「", "」"), ("『", "』"), ("【", "】"), ("〈", "〉")]


def quoted_spans(text):
    """找出被書名號、引號括起來的區段。

    那裡面的「一、」是在引用別的文件的條次，不是本條的編號。
    例如：依《…一、財產保險商品一般進件作業程序》之(二)至(八)辦理
    """
    spans = []
    for op, cl in PAIRS:
        start = 0
        while True:
            i = text.find(op, start)
            if i < 0:
                break
            j = text.find(cl, i + 1)
            if j < 0:
                break
            spans.append((i, j + 1))
            start = j + 1
    return spans


def candidates(text, starts=None):
    """回傳 {符號類型: [(位置, 數值, 符號原文), ...]}，已排除引用。

    starts：text 裡哪些位置是原檔段落的開頭（expand 從起訖序號算）。不知道就只有 0。
    段首的編號一律是結構；段落中間的才要看是不是在引用（排除六）。"""
    starts = starts or {0}
    found = {}
    taken = []          # 被括號類佔走的區段，避免 A、C 重複認
    quoted = quoted_spans(text)

    for kind, pat in FINDERS:
        hits = []
        for m in pat.finditer(text):
            a, b = m.span()

            if kind in ("A", "C") and any(x <= a < y for x, y in taken):
                continue

            # 排除一：符號前面緊鄰的字是「第」，那是引用
            if a > 0 and text[a - 1] == "第":
                continue
            # 排除一之二：前面是「分之」，那是百分之／千分之，是數量詞
            #   A 型收逗號之後才會撞到「百分之二十五，」，真檔實測兩處。
            #   只擋「分之」，不能擋整個「之」——「方式為之1、 使用憑證…」
            #   那個 1、 是真的編號，擋掉會讓整串 1、2、3、 都切不出來。
            if a >= 2 and text[a - 2:a] == "分之":
                continue
            # 排除一之三：「有下列情形之一，」「二者之一，」——前面是「之」的國字是數量，
            # A 型收逗號之後才會撞到（B24）
            if kind == "A" and a > 0 and text[a - 1] == "之":
                continue
            # 排除三：前面緊鄰的是英文字母或數字，那是代號不是編號
            #         例如「IR1、IR2、IR3」是三個風險等級的名字，不是三條規定
            if a > 0 and (text[a - 1].isascii() and text[a - 1].isalnum()):
                continue
            # 排除四：在書名號或引號裡面，那是在引用別份文件的條次
            if any(x <= a < y for x, y in quoted):
                continue
            # 排除二：符號後面緊鄰的字是 條款項目章節點
            if b < len(text) and text[b] in STOP_AFTER:
                continue
            # 排除五：前面是「百」「零」，那是一個更大的號碼的尾巴（一百零一、的「一、」）
            if a > 0 and text[a - 1] in "百零〇":
                continue
            # 排除六：段落中間的編號在引用或列數字——「依…手冊第二章第一節一、規定」
            #   「依第三點（二）辦理」「如附表一、二」「一、二、三級」。以前只擋「前面是第」，
            #   「節一、」被當成新的一點從句子中間切開，QA 擋下、整本建不出規格包
            if kind != "E" and a not in starts and cited_mark(text, a, b, kind):
                continue

            raw = m.group(1)
            val = int(raw) if raw.isdigit() else (
                1 if kind == "E" else cn2int(raw))
            if kind == "E":
                val = ord(raw.upper()) - 64
            if val is None:
                continue
            hits.append((a, val, m.group(0)))

        if kind in ("B", "D"):
            taken.extend((m.span() for m in pat.finditer(text)))
        found[kind] = hits
    return found


def longest_run(hits, starts=(1,)):
    """沿著位置往後走，串出最長的一條編號序列。

    收的條件有兩種：
      一、數值剛好是上一個加 1
      二、數值是 1，代表換一段重新編號（同一條底下有兩組 1.2.3.）

    起點預設要是 1。如果這一段本身從「2.」開頭（母條文被切開留下的
    下半段），就額外允許從它自己的號碼起頭。
    """
    best = []
    for i, (pos0, val0, raw0) in enumerate(hits):
        if val0 not in starts:
            continue
        chain = [(pos0, val0, raw0)]
        want = val0 + 1
        for pos2, val2, raw2 in hits[i + 1:]:
            if pos2 <= chain[-1][0]:
                continue
            if val2 == want:
                chain.append((pos2, val2, raw2))
                want += 1
            elif val2 == 1:
                # 換一段，重新從 1 編
                chain.append((pos2, val2, raw2))
                want = 2
        if len(chain) > len(best):
            best = chain
    return best


def outer_between(cands, win_kind, run):
    """勝出的那一串中途重新從 1 編，中間夾著的另一類才是真正的外層。

    「同一條底下有兩組 1.2.3.」這種形狀，多半不是真的重新編號，
    而是中間有一個更外層的編號沒被認出來。

    實例：006-001-008
        2. 檢核人員：…  3. 檢核方式：…  4. 檢核結果…。
        (四) 保險代理部針對異常減額繳清…          <- 夾在這裡
        1. 執行時間：…  2. 檢視標準：…  …5.
    C 類串成 2,3,4,1,2,3,4,5，中間重新從 1 編。那個 1 之前夾著 (四)，
    所以 B 才是外層。原本的規則會選 C，(四) 就被併進上一條。

    找不到夾在中間的就回 None，維持原本的選法。
    """
    reset = None
    for i in range(1, len(run)):
        if run[i][1] == 1:
            reset = (run[i - 1][0], run[i][0])
            break

    # 勝出串有時因起點規則只收到重編後的 1,2,3；重編前的 2,3,4
    # 仍在候選裡，但不在 run 裡。不要放寬 pick() 的 starts（會造成其他
    # 誤切），改從同類型完整候選找「非 1 → 1」的邊界。
    if reset is None:
        all_hits = cands.get(win_kind, [])
        for i in range(1, len(all_hits)):
            if all_hits[i][1] == 1 and all_hits[i - 1][1] > 1:
                reset = (all_hits[i - 1][0], all_hits[i][0])
                break
    if reset is None:
        return None

    pp, rp = reset
    for kind, hits in cands.items():
        if kind == win_kind:
            continue
        inside = [h for h in hits if pp < h[0] < rp]
        if not inside:
            continue
        r2 = longest_run(hits, (1, inside[0][1]))
        if len(r2) >= 2 and any(pp < p < rp for p, _, _ in r2):
            return kind, r2
    return None


def pick(text, starts=None):
    """選出這一筆要用哪一種符號切。回傳 (符號類型, 切點串)。"""
    head_k, head_raw = head_sym(text)
    head_v = None
    if head_raw:
        m = re.search(r"(%s|\d{1,3}|[A-Za-z])" % ITEM_CN, head_raw)
        if m:
            t = m.group(1)
            head_v = (int(t) if t.isdigit()
                      else (ord(t.upper()) - 64 if re.match(r"^[A-Za-z]$", t)
                            else cn2int(t)))
    cands = candidates(text, starts)
    runs = []
    for kind, hits in cands.items():
        starts = (1,)
        if kind == head_k and head_v and head_v != 1:
            starts = (1, head_v)
        run = longest_run(hits, starts)
        if len(run) >= 2:
            runs.append((run[0][0], -len(run), kind, run))
    if not runs:
        return None, []

    # 選「最先出現」的那一種，不是「串最長」的那一種。
    # 最外層一定先出現。串最長的常常是最內層，例如
    #   三、商品篩選(一) 保險商品1、…(1)…(2)…(二)…(1)…(2)…
    # 這裡 (1)(2) 出現 21 次最長，但正確的切點是 (一)(二)(三)(四)。
    # 位置一樣才比長度。
    runs.sort(key=lambda x: (x[0], x[1]))

    # 勝出的那一串中途重新從 1 編的話，中間可能夾著沒被認出來的外層
    alt = outer_between(cands, runs[0][2], runs[0][3])
    if alt:
        return alt

    return runs[0][2], runs[0][3]


def cut(text, starts=None):
    """切一輪。回傳 (符號類型, [(子序號, 符號原文, 文字), ...])。"""
    kind, run = pick(text, starts)
    if not kind:
        return None, []

    parts = []
    head = text[:run[0][0]]
    if head.strip():
        parts.append(("00", "", head))

    for i, (pos, val, raw) in enumerate(run):
        end = run[i + 1][0] if i + 1 < len(run) else len(text)
        parts.append(("%02d" % (i + 1), raw, text[pos:end]))

    # 這一筆自己的無損驗證
    if "".join(p[2] for p in parts) != text:
        return None, []
    return kind, parts


HEAD_PATS = [
    ("F", ARTICLE_RE),               # 第一條（S3 已經在條號切過，這裡只用來認出母條文本文）
    ("B", re.compile(r"^[（(]\s*%s\s*[）)]" % ITEM_CN)),
    ("D", re.compile(r"^[（(]\s*\d{1,3}\s*[）)]")),
    ("A", re.compile(r"^%s\s*[、，,]" % ITEM_CN)),
    ("C", re.compile(r"^\d{1,3}\s*(?:、|[.．](?![0-9０-９]))")),
    ("E", re.compile(r"^[A-Za-z]\s*[.．]")),
]


def head_sym(text):
    """認出一段文字開頭的編號。00 子項常常帶著母條文自己的編號。"""
    t = re.sub(r"^(?:\s*\[\[(?:TABLE|SHAPE):\d{3}\]\])+", "", text or "").lstrip()
    for kind, pat in HEAD_PATS:
        m = pat.match(t)
        if m:
            return kind, m.group(0).strip()
    return None, ""


MAX_DEPTH = 4        # 最多切四層：跟 S4 的 MAX_ROUND 一樣


def split_items(text, max_depth=MAX_DEPTH):
    """把一段文字照段內款目切成一塊一塊：[(起, 訖), ...]，照原文順序、接起來就是原文。

    跟 S4 同一套切點：先用 cut() 切最外層，每一塊（母文以外）再往下切，最多 max_depth 層，
    回傳最細的那一層。「第二條 應檢附下列文件：一、申請書（一）正本（二）影本。二、身分證明。」
    切成「第二條 應檢附下列文件：」「一、申請書」「（一）正本」「（二）影本。」「二、身分證明。」，
    每一塊單獨看就跟一段一段打出來的條文一樣，build_hierarchy 照樣認得層級。
    切不開（沒有段內款目、或切了不無損）回 [(0, len(text))]。
    """
    text = text or ""

    def walk(start, piece, depth):
        if depth >= max_depth:
            return [(start, start + len(piece))]
        kind, parts = cut(piece)
        if not kind:
            return [(start, start + len(piece))]
        spans = []
        offset = start
        for sub, _raw, part in parts:
            if sub == "00":
                spans.append((offset, offset + len(part)))      # 母文（第一個切點之前）不再往下切
            else:
                spans.extend(walk(offset, part, depth + 1))
            offset += len(part)
        return spans

    return walk(0, text, 0) if text else [(0, 0)]
