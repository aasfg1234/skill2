# -*- coding: utf-8 -*-
"""Word 自動編號：照 numbering.xml、styles.xml 算出畫面上看到的「一、」「(二)」「3、」。

切條（S1P）與比對（regdiff 讀檔）共用這一份，兩邊算出來的編號才會一樣。
規則是拿 Word 自己報的答案（Range.ListFormat.ListString）一條一條對出來的，
對答案的工具在 tests/check_word_numbering.py：

    一、同一個 abstractNum 底下的幾個 numId 共用同一串計數（Word 會接著編，不是各自從一起算）。
    二、numId 帶 startOverride 時，只在「這個 numId 第一次被用到的那一層」照 override 重來；
        其他層照樣接著編（以前每一層都重來，04 保險代理業務手冊有 11 段因此差一號）。
    三、lvlRestart：w:val＝0 永不重算；w:val＝n 是用到第 n 層以上（ilvl < n）才重算；
        沒寫就是預設：比它上面任何一層前進就重算。
    四、numStyleLink（清單樣式）：abstractNum 只寫「照某個清單樣式」，要經由那個樣式的
        numId 找到真正定義層級的 abstractNum。
    五、先用到下層、上層還沒出現過：上層當成已經用過它的起始號。先寫「(一)(二)」再寫第一層，
        第一層是「二、」不是「一、」（04 手冊有一串第一、二層都從四起算，Word 顯示「五、」）。
    六、段落 numId＝0 是把樣式帶來的編號關掉，不佔號；空白的編號段落照樣佔一號。
    七、文字方塊是另一個故事，Word 在裡面另外起算，不影響本文的計數——呼叫端不要把
        文字方塊裡的段落丟進來。

算不出來（不支援的編號格式、清單樣式找不到定義）丟 NumberingError，不要猜：
猜錯的條號會寫進正式修正對照表，比留白更糟。
"""

_W = "{http://schemas.openxmlformats.org/wordprocessingml/2006/main}"


class NumberingError(ValueError):
    pass


def _q(tag):
    return _W + tag


def _val(el):
    return el.get(_q("val")) if el is not None else None


# ---------------------------------------------------------------------------
# 編號格式
# ---------------------------------------------------------------------------

_CN = "〇一二三四五六七八九"
_TIANGAN = "甲乙丙丁戊己庚辛壬癸"
_DIZHI = "子丑寅卯辰巳午未申酉戌亥"
# 大寫數字（壹、貳、參）：zh-TW Word 編號庫的「壹、貳、參」是 ideographLegalTraditional，
# 要點、手冊很常拿它當章次。以前不認，整份自動編號放棄、條號欄全空（審查 D5）。
_CN_UPPER_TRAD = dict(zip("〇一二三四五六七八九十百", "零壹貳參肆伍陸柒捌玖拾佰"))
_CN_UPPER_SIMP = dict(zip("〇一二三四五六七八九十百", "零壹贰叁肆伍陆柒捌玖拾佰"))


def _cn_legal(n, table):
    """壹、貳……玖、壹拾、壹拾壹……貳拾、壹佰零壹：大寫數字的十位一律寫出「壹拾」（小寫是「十一」）。"""
    text = _cn_count(n)
    if text.startswith("十"):
        text = "一" + text
    return "".join(table.get(ch, ch) for ch in text)


def _cn_count(n):
    """一、二……十、十一……二十、二十一……九十九（taiwaneseCounting／chineseCounting）。"""
    if n <= 0 or n >= 1000:
        raise NumberingError("編號 %d 超出能換成中文數字的範圍" % n)
    hundreds, rest = divmod(n, 100)
    tens, ones = divmod(rest, 10)
    out = ""
    if hundreds:
        out += _CN[hundreds] + "百"
        if rest and tens == 0:
            out += "〇"
    if tens:
        out += ("" if tens == 1 and not hundreds else _CN[tens]) + "十"
    if ones:
        out += _CN[ones]
    return out


def _roman(n):
    pairs = [(1000, "M"), (900, "CM"), (500, "D"), (400, "CD"), (100, "C"), (90, "XC"),
             (50, "L"), (40, "XL"), (10, "X"), (9, "IX"), (5, "V"), (4, "IV"), (1, "I")]
    out = ""
    for value, sym in pairs:
        while n >= value:
            out += sym
            n -= value
    return out


def _letter(n):
    return chr(ord("A") + (n - 1) % 26) * ((n - 1) // 26 + 1)


def format_number(n, fmt):
    if fmt in ("decimal", "decimalZero"):
        return ("%02d" % n) if fmt == "decimalZero" else str(n)
    if fmt == "decimalFullWidth":
        return "".join(chr(ord(c) - ord("0") + 0xFF10) for c in str(n))
    if fmt in ("taiwaneseCounting", "taiwaneseCountingThousand", "chineseCounting",
               "chineseCountingThousand"):
        return _cn_count(n)
    if fmt in ("ideographDigital", "taiwaneseDigital"):
        return "".join(_CN[int(c)] for c in str(n))      # 逐位：10 → 一〇
    if fmt == "ideographLegalTraditional":
        return _cn_legal(n, _CN_UPPER_TRAD)              # 壹、貳、參
    if fmt == "chineseLegalSimplified":
        return _cn_legal(n, _CN_UPPER_SIMP)              # 壹、贰、叁
    if fmt in ("ideographTraditional",):
        return _TIANGAN[(n - 1) % 10]
    if fmt in ("ideographZodiac",):
        return _DIZHI[(n - 1) % 12]
    if fmt == "upperRoman":
        return _roman(n)
    if fmt == "lowerRoman":
        return _roman(n).lower()
    if fmt == "upperLetter":
        return _letter(n)
    if fmt == "lowerLetter":
        return _letter(n).lower()
    if fmt == "decimalEnclosedCircle" and 1 <= n <= 20:
        return chr(0x2460 + n - 1)
    if fmt == "decimalEnclosedCircleChinese" and 1 <= n <= 10:
        return chr(0x3280 + n - 1)
    if fmt == "none":
        return ""
    raise NumberingError("有 Word 自動編號用了這裡算不出來的格式「%s」" % fmt)


# ---------------------------------------------------------------------------
# 計數
# ---------------------------------------------------------------------------

class WordNumbering(object):
    """照文件順序把每一段（本文與表格儲存格，不含文字方塊）丟給 label()，拿回那一段的編號字串。

    label() 會推進計數，所以每一段只能丟一次、而且要照順序；沒有編號的段落也可以丟，回空字串。
    """

    def __init__(self, numbering_root=None, styles_root=None):
        self.abstract = {}       # abstractNumId → {ilvl: {start, fmt, text, legal, restart}}
        self.style_link = {}     # abstractNumId → 它指向的清單樣式（numStyleLink）
        self.nums = {}           # numId → (abstractNumId, {ilvl: startOverride})
        self.style_numpr = {}    # 段落樣式 styleId → (numId, ilvl)，各自可能是 None
        self.style_based = {}
        self.default_style = None
        self.counters = {}       # 真正定義層級的 abstractNumId → {ilvl: 目前號碼}
        self.seen_nums = set()   # 已經用過的 numId（startOverride 只在第一次用到時生效）
        if numbering_root is not None:
            self._read_numbering(numbering_root)
        if styles_root is not None:
            self._read_styles(styles_root)

    @classmethod
    def from_zip(cls, archive):
        """從已開啟的 docx（zipfile.ZipFile）讀 numbering.xml 與 styles.xml。"""
        import xml.etree.ElementTree as ET
        names = set(archive.namelist())

        def part(name):
            return ET.fromstring(archive.read(name)) if name in names else None
        return cls(part("word/numbering.xml"), part("word/styles.xml"))

    # -- 讀定義 -------------------------------------------------------------

    def _read_numbering(self, root):
        for an in root.findall(_q("abstractNum")):
            aid = an.get(_q("abstractNumId"))
            link = an.find(_q("numStyleLink"))
            if link is not None:
                self.style_link[aid] = _val(link)
            levels = {}
            for lvl in an.findall(_q("lvl")):
                ilvl = int(lvl.get(_q("ilvl")) or 0)
                restart = _val(lvl.find(_q("lvlRestart")))
                levels[ilvl] = {
                    "start": int(_val(lvl.find(_q("start"))) or 1),
                    "fmt": _val(lvl.find(_q("numFmt"))) or "decimal",
                    "text": _val(lvl.find(_q("lvlText"))) or "",
                    "legal": lvl.find(_q("isLgl")) is not None,
                    "restart": int(restart) if restart is not None else None,
                }
            self.abstract[aid] = levels
        for num in root.findall(_q("num")):
            overrides = {}
            for ov in num.findall(_q("lvlOverride")):
                start = ov.find(_q("startOverride"))
                if start is not None:
                    overrides[int(ov.get(_q("ilvl")) or 0)] = int(_val(start) or 1)
            self.nums[num.get(_q("numId"))] = (_val(num.find(_q("abstractNumId"))), overrides)

    def _read_styles(self, root):
        for st in root.findall(_q("style")):
            sid = st.get(_q("styleId"))
            self.style_based[sid] = _val(st.find(_q("basedOn")))
            numpr = st.find(_q("pPr") + "/" + _q("numPr"))
            if numpr is not None:
                ilvl = _val(numpr.find(_q("ilvl")))
                self.style_numpr[sid] = (_val(numpr.find(_q("numId"))),
                                         int(ilvl) if ilvl is not None else None)
            if st.get(_q("type")) == "paragraph" and st.get(_q("default")) in ("1", "true"):
                self.default_style = sid

    # -- 查 -----------------------------------------------------------------

    def _style_numpr(self, sid):
        """段落樣式（沿 basedOn 往上找）帶的 (numId, ilvl)。"""
        seen = set()
        while sid and sid not in seen:
            seen.add(sid)
            if sid in self.style_numpr:
                return self.style_numpr[sid]
            sid = self.style_based.get(sid)
        return (None, None)

    def numbering_of(self, paragraph):
        """這一段的 (numId, ilvl)：段落自己寫的優先，缺的那一半從樣式補。沒有編號回 None。"""
        ppr = paragraph.find(_q("pPr"))
        sid = _val(ppr.find(_q("pStyle"))) if ppr is not None else None
        style_num, style_ilvl = self._style_numpr(sid or self.default_style)
        own = ppr.find(_q("numPr")) if ppr is not None else None
        num_id = _val(own.find(_q("numId"))) if own is not None else None
        ilvl = _val(own.find(_q("ilvl"))) if own is not None else None
        num_id = num_id if num_id is not None else style_num
        ilvl = int(ilvl) if ilvl is not None else (style_ilvl or 0)
        if not num_id or num_id == "0":
            return None
        return num_id, ilvl

    def _definition(self, num_id):
        """numId → (真正定義層級的 abstractNumId, 層級表, startOverride)。"""
        if num_id not in self.nums:
            return None, {}, {}
        aid, overrides = self.nums[num_id]
        seen = set()
        while aid in self.style_link:
            if aid in seen:
                raise NumberingError("清單樣式「%s」互相指來指去，算不出編號" % self.style_link[aid])
            seen.add(aid)
            linked = self.style_link[aid]
            target_num, _ = self._style_numpr(linked)
            if not target_num or target_num not in self.nums:
                raise NumberingError("自動編號用了清單樣式「%s」，但找不到它的編號定義" % linked)
            aid = self.nums[target_num][0]
        return aid, self.abstract.get(aid) or {}, overrides

    # -- 算 -----------------------------------------------------------------

    def label(self, paragraph, bullets=True):
        """這一段畫面上的編號（未清理空白，例如「一、」「(二)」「1.1」）；沒有編號回空字串。

        bullets=False：項目符號（●、■ 這種 bullet 格式）回空字串——那不是條號，
        比對端拿它組結構文字只會多出雜訊。只是不回字，計數照算（下層照樣重算）。"""
        found = self.numbering_of(paragraph)
        if not found:
            return ""
        num_id, ilvl = found
        aid, levels, overrides = self._definition(num_id)
        if ilvl not in levels:
            return ""
        counts = self.counters.setdefault(aid, {})

        def start_of(k):
            return overrides.get(k, (levels.get(k) or {}).get("start", 1))

        if num_id not in self.seen_nums:
            self.seen_nums.add(num_id)
            if ilvl in overrides:
                counts[ilvl] = overrides[ilvl] - 1
        for upper in range(ilvl):
            if upper in levels and upper not in counts:
                counts[upper] = start_of(upper)   # 先用到下層：上層當成已經用過起始號，之後從下一號接
        counts[ilvl] = counts.get(ilvl, start_of(ilvl) - 1) + 1
        for deeper in [k for k in counts if k > ilvl]:
            restart = (levels.get(deeper) or {}).get("restart")
            if restart is None or ilvl < restart:
                del counts[deeper]            # 上面這一層前進了，下層從頭算

        level = levels[ilvl]
        if level["fmt"] == "bullet":
            return level["text"] if bullets else ""
        text = level["text"]
        for k in range(9):
            token = "%%%d" % (k + 1)
            if token not in text:
                continue
            value = counts.get(k, start_of(k))
            fmt = "decimal" if level["legal"] else (levels.get(k) or {}).get("fmt", "decimal")
            text = text.replace(token, format_number(value, fmt))
        return text
