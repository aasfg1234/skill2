@echo off
REM reg-report: open the settings page (auto-save, no file dialogs). Close the page to finish.
cd /d "%~dp0"
python scripts\run_all.py open-settings
if errorlevel 1 pause
