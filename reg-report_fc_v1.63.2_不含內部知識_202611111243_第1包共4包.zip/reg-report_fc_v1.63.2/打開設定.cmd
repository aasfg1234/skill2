@echo off
set NoDefaultCurrentDirectoryInExePath=1
if defined REG_UTF8 goto start
set REG_UTF8=1
chcp 65001 >nul
"%ComSpec%" /c ^""%~f0"^"
exit /b %errorlevel%
:start
REM reg-report: open the settings page (auto-save, no file dialogs). Close the page to finish.
set REG_REGISTER_SKILL=1
cd /d "%~dp0"
call python --version >nul 2>nul || goto nopython
python scripts\run_all.py open-settings
if errorlevel 1 pause
exit /b
:nopython
call py -3 --version >nul 2>nul || goto nothing
py -3 scripts\run_all.py open-settings
if errorlevel 1 pause
exit /b
:nothing
echo 這台電腦找不到 Python，這一步還沒開始。請安裝 Python 3.13（安裝時勾 Add python.exe to PATH）或請資訊單位協助，裝好再雙擊一次。
pause
exit /b 1
