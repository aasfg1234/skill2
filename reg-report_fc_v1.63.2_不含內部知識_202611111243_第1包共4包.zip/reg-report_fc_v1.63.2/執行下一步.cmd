@echo off
set NoDefaultCurrentDirectoryInExePath=1
if defined REG_UTF8 goto start
set REG_UTF8=1
chcp 65001 >nul
"%ComSpec%" /c ^""%~f0"^"
exit /b %errorlevel%
:start
cd /d "%~dp0"
call python --version >nul 2>nul || goto nopython
python -B scripts\run_all.py run-request
goto done
:nopython
call py -3 --version >nul 2>nul || goto nothing
py -3 -B scripts\run_all.py run-request
goto done
:nothing
echo 這台電腦找不到 Python，這一步還沒開始。請安裝 Python 3.13（安裝時勾 Add python.exe to PATH）或請資訊單位協助，裝好再雙擊一次。
for %%f in ("_請求\請求_*.json") do (echo 這台電腦找不到 Python，這一步還沒開始。請安裝 Python 3.13（安裝時勾 Add python.exe to PATH）或請資訊單位協助，裝好再雙擊一次。 & echo [結束碼] 1)> "%%~f.結果.txt"
:done
pause
