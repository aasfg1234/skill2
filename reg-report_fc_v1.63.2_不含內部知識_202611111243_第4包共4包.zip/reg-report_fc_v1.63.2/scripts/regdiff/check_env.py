# -*- coding: utf-8 -*-
"""
Step 0：環境檢查工具

檢查這個環境裝了哪些套件，缺的可以自動安裝，並講實話：它說能用的都真的試過
（套件 import 得起來、模型檔完整、Python 版本夠）。
建議每次開始比對之前先跑一次。

使用方式：
    python check_env.py              檢查並安裝 python-docx、rapidfuzz（需要能連外裝套件的環境）
    python check_env.py --no-install 只檢查不安裝，列出目前能做什麼

結束代碼：缺必要的東西（python-docx、Python 版本不對）回 1，其他回 0。少裝加分、選用套件不是失敗。

--------------------------------------------------------------------------
不安裝套件時請用 --no-install
--------------------------------------------------------------------------
若目前環境不適合安裝套件，直接使用 --no-install。


比對核心（精確比對、跨章節重複條文、品質檢查、款目重編、同義詞正規化）只用標準函式庫；
但 python-docx 不是可有可無：Word 修正對照表、標註版全文要用它，雙擊捷徑的本機請求沒有它不會開始。
套件清單與離線安裝見 references/環境與套件.md。
"""

import argparse
import importlib
import os
import subprocess
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from _common import setup_console


# key 是 import 時的名字，value 是 pip 安裝時的名字。
# 這兩個常常不一樣(import docx / pip install python-docx)，很容易搞混，這裡對應好。
# 必要套件：缺它時本機請求一律不開始（local_request.python_problem），Word 產出也沒有。
REQUIRED_PACKAGES = {
    "docx": "python-docx",
}

# 加分套件：rapidfuzz 裝了比較快，沒裝結果一樣。
ENHANCING_PACKAGES = {
    "rapidfuzz": "rapidfuzz",
}

# Python 版本：3.13、3.14 實測過；3.9～3.12 語法上可以但沒實測；比 3.9 舊的跑不起來（用到 Path.is_relative_to）。
PYTHON_MIN = (3, 9)
PYTHON_TESTED = (3, 13)

# 選用套件：語意比對（BGE-M3，見 semantic_candidates.py）要用。體積大，還要另外有模型資料夾，
# 所以只列狀態、不自動安裝；沒裝時語意這一步略過，其他比對照跑。
# sentence-transformers 是 FlagEmbedding 裝不起來時的備援（只有 dense）。
OPTIONAL_PACKAGES = {
    "torch": "torch",
    "FlagEmbedding": "FlagEmbedding",
    "sentence_transformers": "sentence-transformers",
}


def is_installed(import_name):
    """檢查套件是不是已經裝好了。"""
    # 不是只接 ImportError：套件裝壞時 import 可能丟出各種例外，
    # 環境檢查本身掛掉是最沒道理的失敗方式。
    try:
        importlib.import_module(import_name)
        return True
    except Exception:
        return False


def pip_supports_break_system_packages():
    """
    這台電腦的 pip 認不認得 --break-system-packages 這個參數。

    這個參數是 pip 23.0 才加的，用來繞過某些 Linux 發行版「不准動系統 Python」的
    保護。舊版 pip 看到會直接報 usage error 整個失敗。舊版本的程式無條件加這個參數，
    在 pip < 23 的機器上第一次安裝一定失敗（雖然有 fallback 接住，但白跑一趟、
    而且註解宣稱「加了也不會有問題」是錯的）。這裡先問過 pip 版本再決定。
    """
    try:
        import pip
        parts = pip.__version__.split(".")
        return int(parts[0]) >= 23
    except Exception:
        return False


def install_package(pip_name):
    """安裝套件。回傳 True/False。"""
    print("  正在安裝 %s ..." % pip_name)
    command = [sys.executable, "-m", "pip", "install", pip_name, "-q"]
    if pip_supports_break_system_packages():
        command.insert(-1, "--break-system-packages")

    try:
        subprocess.check_call(command)
        print("  ✓ %s 安裝完成" % pip_name)
        return True
    except subprocess.CalledProcessError as exc:
        print("  ✗ %s 安裝失敗（結束代碼 %s）" % (pip_name, exc.returncode))
        print("    請手動執行：pip install %s" % pip_name)
        print("    若公司網路需要走 proxy，請洽資訊單位取得 pip 的 proxy 設定方式。")
        return False
    except Exception as exc:
        print("  ✗ %s 安裝失敗：%s" % (pip_name, exc))
        return False


def check_and_install(package_dict, auto_install=True, required=True):
    """檢查一組套件；auto_install=True 的話缺的就裝。回傳是否全部就緒。"""
    all_ok = True
    for import_name, pip_name in package_dict.items():
        if is_installed(import_name):
            print("  ✓ %s 已安裝" % pip_name)
            continue

        if not auto_install:
            print("  － %s 尚未安裝（預設不自動安裝）" % pip_name)
            all_ok = False
            continue

        print("  ✗ %s 尚未安裝，開始自動安裝..." % pip_name)
        if not install_package(pip_name):
            all_ok = False
            if required:
                print("    ⚠ 工具沒有安裝完成，可能影響 Word 輸出或候選比對；請確認產出與提醒。")
    return all_ok


# 各功能需要哪些套件。用來在裝不了套件的環境裡，明確告訴使用者「現在能做什麼」，
# 而不是讓他跑到一半才發現某一步不能用。
CAPABILITIES = [
    ("讀 .txt / .md 內規", [], "標準函式庫即可"),
    ("讀 .docx 內規（含追蹤修訂）", [],
     "一律用內建 XML 解析，不經過 python-docx，裝不裝結果都一樣"),
    ("Step 1 精確比對與 CSV 對照表", [], "標準函式庫即可"),
    ("Step 0.5 款目重編與交叉引用", [], "標準函式庫即可"),
    ("Step 1.6 條文品質檢查（十項）", [], "標準函式庫即可"),
    ("Step 2 跨章節重複條文", [], "這台電腦少一個工具時會改用另一種比對方式，可能少抓幾段"),
    ("Step 2 同義詞正規化", [], "用 設定.html 的同義詞表，純文字比對，不需要任何模型"),
    ("輸出 Word 對照表與標註版全文", ["docx"], "需要 python-docx，沒有就只產 CSV 與純文字"),
    ("雙擊捷徑的本機請求", ["docx"], "需要 python-docx，沒有就不會開始"),
]


def python_status(version=None, free_threaded=None, executable=None):
    """(能不能用, 說明)。"""
    version = tuple((version or sys.version_info)[:2])
    if free_threaded is None:
        free_threaded = hasattr(sys, "_is_gil_enabled") and not sys._is_gil_enabled()
    text = "Python %d.%d" % version
    if version < PYTHON_MIN:
        return False, "%s 太舊：至少要 %d.%d，建議 %d.%d" % ((text,) + PYTHON_MIN + PYTHON_TESTED)
    if free_threaded:
        return False, "%s 是自由執行緒版（3.13t）：本機請求不會開始，請裝一般版" % text
    if "WindowsApps" in (executable or sys.executable):
        return True, ("%s 是 Microsoft Store 版：程式位置的登記檔可能讀不到（捷徑一直說還沒登記時就是這個），"
                      "建議改裝 python.org 的一般版" % text)
    if version < PYTHON_TESTED:
        return True, "%s 可以跑但沒有實測過；實測過的是 3.13、3.14" % text
    return True, text


def semantic_status():
    """語意比對真的算得起來嗎：(能不能, 說明)。import 真的試、模型檔看完不完整，但不載模型（一次十幾分鐘）。"""
    sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    import semantic_candidates as sc
    from _common import config_section, skill_path
    if not is_installed("torch"):
        return False, "缺 torch（或裝壞了）"
    if not (is_installed("FlagEmbedding") or is_installed("sentence_transformers")):
        return False, "缺 FlagEmbedding（或 sentence-transformers）"
    model = sc.find_local_model(skill_path(config_section("設定").get("語意模型路徑")))
    if not model:
        return False, "找不到 BGE-M3 模型資料夾"
    broken = sc.weights_problem(model)
    if broken:
        return False, broken
    return True, "模型在 %s" % model


def report_capabilities():
    """
    只檢查不安裝，列出目前環境下哪些功能可用。

    給不適合安裝套件的環境使用。在那種環境裡嘗試 pip install 只會失敗，
    甚至可能因為連不到外網而卡住；使用者真正需要知道的是「現在能做什麼」。
    """
    print("=" * 62)
    print("環境能力檢查（只檢查、不安裝）")
    print("Python %s" % sys.version.split()[0])
    print("=" * 62)

    python_ok, python_text = python_status()
    print("\n【Python】")
    print("  %s %s" % ("✓" if python_ok else "✗", python_text))

    print("\n【套件狀態】（✓ 表示真的 import 得起來）")
    groups = (("必要", REQUIRED_PACKAGES), ("加分", ENHANCING_PACKAGES), ("選用", OPTIONAL_PACKAGES))
    for label, packages in groups:
        for import_name, pip_name in packages.items():
            print("  %s %s（%s）" % ("✓ 有" if is_installed(import_name) else "－ 無", pip_name, label))

    print("\n【目前可用的功能】")
    unavailable = []
    for name, needs, note in CAPABILITIES:
        missing = [n for n in needs if not is_installed(n)]
        if missing:
            unavailable.append((name, note))
        else:
            print("  ✓ %s" % name)
            if note and not needs:
                print("      %s" % note)

    if unavailable:
        print("\n【目前不可用的功能】")
        for name, note in unavailable:
            print("  ✗ %s" % name)
            print("      %s" % note)

    semantic_ok, semantic_text = semantic_status()
    print("\n【語意比對（BGE-M3，選用）】")
    print("  %s %s" % ("✓ 可以算" if semantic_ok else "✗ 算不了", semantic_text))
    if not semantic_ok:
        print("      沒有就略過語意，其他比對照跑。")
    import semantic_memory
    known = semantic_memory.blocked()
    if known:
        print("      這台電腦記住了不能算（%s）：模型裝好會自動恢復，要馬上重試在 開始／繼續／體檢 加 --重試語意。"
              % semantic_memory.reason_text(known))
    print("      詳細（含重排序模型、要跑的指令）：python scripts/semantic_candidates.py --檢查")

    docx_ok = is_installed("docx")
    print("\n" + "=" * 62)
    print("比對核心（精確比對、跨章節重複條文、品質檢查、款目重編）只用標準函式庫，%s"
          % ("可以跑。" if python_ok else "但這個 Python 不能用：" + python_text))
    if not docx_ok:
        print("缺 python-docx：雙擊捷徑的本機請求不會開始，也沒有 Word 修正對照表。"
              "安裝：python -m pip install python-docx")
    print("=" * 62)
    return python_ok and docx_ok


def main():
    setup_console()
    parser = argparse.ArgumentParser(description="Step 0：環境檢查")
    parser.add_argument("--no-install", action="store_true",
                        help="只檢查不安裝，並列出在目前套件狀態下哪些功能可用、哪些不可用。"
                             "不安裝套件時請用這個模式")
    args = parser.parse_args()

    if args.no_install:
        return report_capabilities()

    print("=" * 60)
    print("環境檢查開始")
    print("Python %s" % sys.version.split()[0])
    print("=" * 60)

    print("\n【必要套件】雙擊捷徑的本機請求、Word 對照表要用")
    required_ok = check_and_install(REQUIRED_PACKAGES, auto_install=True, required=True)
    print("\n【加分套件】裝了比較快，沒裝結果一樣")
    enhancing_ok = check_and_install(ENHANCING_PACKAGES, auto_install=True, required=False)

    print("\n" + "=" * 60)
    if required_ok and enhancing_ok:
        print("✓ 套件都裝好了：Word 對照表會有紅字格式，Step 2 也會跑比較快")
    elif required_ok:
        print("－ rapidfuzz 沒裝成功：比對照跑，只是慢一點，結果一樣。")
    else:
        print("✗ python-docx 沒裝成功：比對核心可以跑，但雙擊捷徑的本機請求不會開始，也沒有 Word 修正對照表。")
        print("  請手動裝：python -m pip install python-docx（離線安裝見 references/環境與套件.md）")

    print("=" * 60)

    # 少裝加速套件回 0：回 1 會讓外層包裝誤判成「這個 skill 掛了」。必要的沒裝起來才回 1。
    return required_ok


if __name__ == "__main__":
    sys.exit(0 if main() else 1)
