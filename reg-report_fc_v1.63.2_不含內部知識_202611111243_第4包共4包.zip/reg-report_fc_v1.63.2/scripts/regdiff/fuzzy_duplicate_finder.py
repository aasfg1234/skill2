# -*- coding: utf-8 -*-
"""
Step 2：跨章節重複條文抓取工具（模糊字串比對）── 整個流程最重要的一步

目的：
你修改了某一條規定，但同一個規定因為內規結構的關係，可能在別的章節
(壽險、產險、網路投保……)也各寫了一次，用詞因為實務作業需求略有調整。
只改一處就會漏改。這支程式把你改過的段落拿去跟全文其他段落比相似度，
把有嫌疑的都列出來，交給人工判斷。

原則：寧可多列、不要漏列。法規漏改的代價遠高於多花時間看候選清單。

--------------------------------------------------------------------------
重要：要傳「新版全文」，不是舊版
--------------------------------------------------------------------------
regulation_file 請傳「你已經改好的新版內規全文」。
傳舊版的話，你剛改掉的那一條的舊文字會以極高相似度霸佔候選第一名，
每一筆都被同一個假陽性佔位，等於白跑。

--------------------------------------------------------------------------
關於中文的相似度計算（跟舊版本的差別）
--------------------------------------------------------------------------
跟舊版有三個地方不一樣：

1) 不再用 token_sort_ratio。舊版用它並宣稱「即使詞語順序不一樣也能抓出相似度」，
   這對中文是錯的：token_sort 是靠空白切詞的，中文整句沒有空白會被當成單一 token，
   分數退化成跟 ratio 一模一樣（實測 token_sort / token_set / ratio 三者同分）。
   現在直接用 ratio，不再宣稱做不到的事。

2) 比對前先把條號拿掉。條號不是條文內容，卻會干擾分數——「第三條」對上
   「第二十二條」光這幾個字就先扣一截。實測拿掉條號後，真正相關的條文分數幾乎
   不動(53.1 -> 51.3)，不相干的卻從 22~32 掉到 11~18，訊號雜訊比明顯拉開。

3) 門檻從 70 下修到 45。實測資料：
     「逾期未繳超過三十日者，契約停止效力」
     vs「逾期未繳者，契約停止效力」              同一條漏改  83.9 分
     vs「保險費未於到期日後未繳納者，契約效力停止」 換句話說   51.3 分
     vs 同一份內規裡其他不相干條文                          11~18 分
   舊門檻 70 會漏掉「換句話說」那一類，正好就是本步驟要抓的東西；而 45 距離
   雜訊帶(18)還有很大的空間。原則是寧可多列、不要漏列。

代價是法規慣用語(「本公司應於……」「要保人應……」)會讓不相干的條文分數偏高。
所以輸出多附一欄「最長共同片段」：
  - 分數高、共同片段也長  → 很可能是真的重複條文
  - 分數高、共同片段很短  → 多半只是公文套語像，可以快速跳過
這一欄是給人看的分流線索，不參與門檻判斷。

（這支不再單獨跑：由 regdiff/run_all.step_duplicates 呼叫。）
"""

import functools
import re
import difflib
import os
import sys
import unicodedata

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from _common import (cn_to_int, extract_article_no, format_scope, lcs_length, lcs_masks,
                     normalize_terms, strip_article_no, synonym_evidence,
                     normalize_for_compare,
                     diff_runs as _diff_runs)

try:
    from rapidfuzz import fuzz
    HAS_RAPIDFUZZ = True
except ImportError:
    HAS_RAPIDFUZZ = False

DEFAULT_THRESHOLD = 45.0
DEFAULT_TOP = 15

# 候選條文要附帶前後各幾段。1 段通常就夠看出它在那一章裡的位置。
DEFAULT_CONTEXT = 1

# 句子層級比對的門檻。整段對整段時，改到的那一句會被沒改的部分稀釋
# （真資料 36.6 分），拿「改到的那一句」去比才對得上（90.3 分）；
# 句子本身短，門檻要比整段比對（45）高，60 分能濾掉不相干的句子。
DEFAULT_SENTENCE_THRESHOLD = 60.0


_lcs_masks, _lcs_length = lcs_masks, lcs_length


def _indel_ratio(text_a, text_b):
    """跟 rapidfuzz.fuzz.ratio 一模一樣的分數（v1.40.0；公司隔離區沒有 rapidfuzz）。公式照 rapidfuzz 的寫法，門檻剛好卡在邊上的才會落在同一邊。"""
    total = len(text_a) + len(text_b)
    return (100.0 if not total else
            100.0 * (1.0 - (total - 2 * _lcs_length(text_a, text_b)) / total))


def calc_similarity(text_a, text_b):
    """
    兩段文字的相似度，0~100，越高越像。傳進來的應該是已經去掉條號的條文本體。

    用 ratio(單純比字元重疊)。理由見檔頭說明：對中文而言 rapidfuzz 的
    token_sort_ratio / token_set_ratio 會退化成 ratio，用它們只是自欺欺人。
    沒裝 rapidfuzz 就用純 Python 計算相同的分數，只是慢一點。
    """
    if HAS_RAPIDFUZZ:
        return float(fuzz.ratio(text_a, text_b))
    return _indel_ratio(text_a, text_b)


# 相似度高到這個程度時，「片段不是從句首開始」就不再是套語的訊號。
# 實測 152 筆候選：80 分以上的 107 筆片段全部從句首開始，套語假陽性最高只到 79.4 分。
# 但真實案例會出現高分卻非句首的情形——「以書面通知」對上「以電子方式通知」，
# 差異落在句子前段，最長片段就被推到句中，分數卻有 94.4，而且是真的重複條文。
HIGH_CONFIDENCE = 80.0

# 兩段一樣的字（所有相同片段加起來）占較長那段的這個比例以上，片段位置就標「整段」。
# 一字之差的孿生條（「應於三日內」對「應於五日內」）最長片段被那個數字切成兩半，
# 只看最長片段起點會標成「句中」——實測 96.9 分的孿生條就這樣被標成句中，照
# 「句首起才列表」的講法會被講成數量。套語假陽性只共用句尾那一截，涵蓋率到不了這裡
# （它們的分數最高 79.4，而分數就是兩邊相同字數占總字數的比例）。
WHOLE_COVERAGE = 0.8


def longest_common_fragment(text_a, text_b):
    """
    兩段文字最長的一段完全相同的連續文字，以及這段文字從哪裡開始。

    回傳 (片段, 位置)，位置是「句首」「整段」「句中」或「句尾」。
    「整段」＝最長片段不是從句首開始，但兩段一樣的字加起來占了大部分（WHOLE_COVERAGE）：
    差在一兩個字的孿生條，不是套語。

    為什麼要標位置：
    片段長度單獨看會騙人。實測一份 50 頁的內規：真正被抄到別章的重複條文，
    共同片段 21 字；而一堆毫不相干的條文因為都用同一個句尾套語（「，作為內部
    控制制度有效運作之依據；但金額未達新臺幣十萬元者，得由單位主管逕行核定」），
    共同片段有 40 字，比真的重複還長。只看長度會把套語排在真貨前面。

    改看「片段從哪裡開始」就分得開了。同一份實測資料的 77 筆候選中：
        片段不是從句首開始的 44 筆 —— 全部是套語假陽性，沒有一筆是真的
        片段從句首開始的 33 筆 —— 包含全部 2 筆真的重複，其餘仍需人工判斷
    也就是說，這是個可靠的「排除」訊號，不是「確認」訊號：非句首幾乎可以直接
    跳過，句首則還是要看內容。

    但這個結論有分數上限。同一份資料裡非句首的候選最高只到 79.4 分，
    80 分以上的 107 筆全部是句首。實際案例出現過 94.4 分的非句首候選
    （「以書面通知」對「以電子方式通知」，差異在句子前段），那是真的重複條文。
    所以「非句首＝套語」只在 HIGH_CONFIDENCE 以下成立，高分時不能拿它叫人跳過。
    """
    matcher = difflib.SequenceMatcher(None, text_a, text_b, autojunk=False)
    match = matcher.find_longest_match(0, len(text_a), 0, len(text_b))
    fragment = text_a[match.a:match.a + match.size]
    if not fragment:
        return "", ""

    # 容許兩個字的誤差，開頭的主詞用字差異不影響判斷
    if match.a <= 2 and match.b <= 2:
        return fragment, "句首"
    # 最長片段被一兩處差異切開、起點落在句中，但一樣的字加起來涵蓋大部分內容：
    # 這是孿生條（「以書面通知」對「以電子方式通知」、「三日」對「五日」），不能標成
    # 句中讓人當套語跳過。只看最長那一段的起點會漏掉這種情況。
    common = sum(block.size for block in matcher.get_matching_blocks())
    if common >= max(len(text_a), len(text_b)) * WHOLE_COVERAGE:
        return fragment, "整段"
    # 落在候選條文後 40% 才開始的，通常就是但書、目的語那一段
    if match.b >= len(text_b) * 0.6:
        return fragment, "句尾"
    return fragment, "句中"


def neighbours(all_paragraphs, index, span):
    """
    候選條文的前後文。index 是 0 起算的位置。

    為什麼需要：
    實測真實內規時發現，「並陳報主管覆核」這類句子在整份文件裡到處都是，
    光看分數與片段位置分不出「這是漏改」還是「這兩個作業的核准層級本來就不同」。

        第六條　分行辦理房屋貸款……並陳報分行經理覆核。
        第七條　分行辦理車輛貸款……並陳報分行經理覆核。
        第十三條　區域中心辦理房屋貸款……並陳報區域中心主管覆核。

    改了第六條，上面兩條都會被列成候選，但只有第十三條該一起看
    （同樣是房貸），第七條是不同業務，不該動。

    前後文看得出這一條在它那一章裡的位置：第十三條前面是個人信用貸款、
    後面是車輛貸款，跟第六條所在的第一章結構平行——這個訊號程式判斷不了，
    但 LLM 看得懂。
    """
    if span <= 0:
        return "", ""
    before = [p.strip() for p in all_paragraphs[max(0, index - span):index]]
    after = [p.strip() for p in all_paragraphs[index + 1:index + 1 + span]]
    return " ／ ".join(x for x in before if x), " ／ ".join(x for x in after if x)


def changed_fragments(old_text, new_text, diff_runs, min_len=2):
    """
    這次修改「加了哪幾段字」。回傳片段清單。

    只取新增的部分。刪除的部分沒辦法拿去別條找——那些字本來就不該存在了。

    片段一律過 _HAS_CONTENT（同檔的 context_fragments 早就這樣做，這裡漏了）：
    只插入「！？」「（）」這種標點也會通過長度檢查變成搜尋詞，拿去搜全文撈回
    一整批毫無關聯的條文，看表的人還得一條一條讀完才知道全部是雜訊。
    """
    if not old_text or not new_text:
        return []
    out = []
    for kind, text in diff_runs(old_text, new_text):
        if kind != "insert":
            continue
        piece = text.strip("，、。；：（）()　 ")
        if len(piece) >= min_len and _HAS_CONTENT(piece):
            out.append(piece)
    return out


# 舊值搜尋（old_value_fragments／find_by_old_value）用：一串連在一起的這些字算一個數，
# 「三日內」不能命中「十三日內」、「五百萬元」不能命中「一千五百萬元」
_NUMERAL_CHARS = set("零〇一二三四五六七八九十百千萬億兩壹貳參肆伍陸柒捌玖拾佰仟0123456789０１２３４５６７８９")
# 「本準則所稱業務人員，指……」「一、業務人員：指……」：被定義的那個詞。
# 跟條文檢查的定義用語共用同一份樣式（_common.DEFINED_TERM_RES）：以前這裡一份、那裡一份，
# 同一個定義這裡認得、條文檢查認不得，定義改了一邊列候選、一邊不報連動
from _common import DEFINED_TERM_RES as _DEFINED_TERM_RES  # noqa: E402
_OLD_VALUE_CONTEXT = 2


def _independent(term, text):
    """term 在 text 裡有沒有「獨立」出現：頭尾是數字的，旁邊不能再接數字。"""
    start = 0
    while True:
        pos = text.find(term, start)
        if pos < 0:
            return False
        start = pos + 1
        if term[0] in _NUMERAL_CHARS and pos > 0 and text[pos - 1] in _NUMERAL_CHARS:
            continue
        end = pos + len(term)
        if term[-1] in _NUMERAL_CHARS and end < len(text) and text[end] in _NUMERAL_CHARS:
            continue
        return True


def old_value_fragments(old_text, new_text, diff_runs):
    """
    這次被換掉的舊字，拿去找「別處還留著舊寫法」的段落。回 [(搜尋詞, 種類)]。

    changed_fragments 只拿新加的字去搜；可是一處改了，別處最常見的漏改正是**舊字原樣還在**：
    定義的用詞改名（「業務人員」→「招攬人員」，用到舊名的八條一條都搜不到）、
    表格裡的「三日內」（一格只有三個字，整條相似度跟條文比不上）。
        種類 "定義"：被換掉的字落在被定義的詞裡——整個舊詞都要搜，用到它的段落全都得跟著改
        種類 "舊值"：其他被換掉的字，前後帶最多兩個字（不跨句）讓它有辨識力
    """
    old_body, new_body = strip_article_no(old_text or ""), strip_article_no(new_text or "")
    if not old_body or not new_body or old_body == new_body:
        return []
    defined = []
    for pattern in _DEFINED_TERM_RES:
        for m in pattern.finditer(old_body):
            defined.append((m.start(1), m.end(1), m.group(1)))
    out = []

    def add(term, kind):
        term = term.strip("，、。；：（）()　 ")
        if len(term) >= 2 and _HAS_CONTENT(term) and term not in _TOO_COMMON \
                and (term, kind) not in out and term not in new_body:
            out.append((term, kind))

    pos = 0
    for kind, text in diff_runs(old_body, new_body):
        if kind == "insert":
            continue
        start, end = pos, pos + len(text)
        pos = end
        if kind != "delete" or not _HAS_CONTENT(text):
            continue
        hit_def = [d for d in defined if d[0] < end and start < d[1]]
        if hit_def:
            for _, _, term in hit_def:
                add(term, "定義")
            continue
        left = old_body[max(0, start - _OLD_VALUE_CONTEXT):start]
        right = old_body[end:end + _OLD_VALUE_CONTEXT]
        left = re.split(r"[，、。；：（）()　 ]", left)[-1]
        right = re.split(r"[，、。；：（）()　 ]", right)[0]
        if right:
            add(text + right, "舊值")
        if left:
            add(left + text, "舊值")
        if len(text.strip()) >= 3:
            add(text, "舊值")
    return out


def _row_label(all_paragraphs, kinds, index):
    """表格格子所在那一列的名稱：前一格（表格一列通常第一格寫作業項目）。不是格子回空。"""
    if not kinds or index >= len(kinds) or kinds[index] != "cell":
        return None
    if index > 0 and kinds[index - 1] == "cell":
        return all_paragraphs[index - 1] or ""
    return ""


def _shares_phrase(a, b, size=4):
    """a、b 有沒有一段至少 size 個字一樣（不含標點空白）。"""
    a = re.sub(r"[\s，、。；：（）()]", "", a or "")
    b = re.sub(r"[\s，、。；：（）()]", "", b or "")
    return any(a[i:i + size] in b for i in range(0, max(0, len(a) - size + 1)))


def _unit_containing(text, pos):
    """text 第 pos 個字所在的那一句（sentence_units 的切法：但書跟前一句算同一句）。"""
    for start, end in _sentence_spans(text):
        if start <= pos <= end:
            return text[start:end].strip()
    return text


def _old_value_context(old_body, body, term, label=None):
    """舊字在候選段的那一句，跟它在舊文的那一句像不像（0～100）。

    同樣寫「三日內」，「業務人員受理客戶申訴時，應於三日內陳報」跟舊文是同一件事，
    「保險費逾期未繳者，本公司應於三日內以書面通知」是別件事。表格格子一格只有幾個字，
    那一列的名稱（「客戶申訴陳報單位主管」）就是它的上下文，接在前面一起比。
    """
    i, j = old_body.find(term), body.find(term)
    if i < 0 or j < 0:
        return 0.0
    mine = _unit_containing(body, j)
    if label:
        mine = label + mine
    return calc_similarity(_unit_containing(old_body, i), mine)


_OLD_VALUE_CN_RUN = re.compile(r"[零〇一二三四五六七八九十百千兩]+")


def _old_value_form(text):
    """比對舊值用的寫法：NFKC、去空白、中文數字轉阿拉伯數字（跟 batch.value_form 同規則；讀不出來的照原字）。"""
    plain = re.sub(r"\s+", "", unicodedata.normalize("NFKC", text or ""))
    def digits(match):
        value = cn_to_int(match.group(0))
        return match.group(0) if value is None else str(value)
    return _OLD_VALUE_CN_RUN.sub(digits, plain)


def find_by_old_value(fragments, old_text, all_paragraphs, exclude_index=None, kinds=None,
                      contexts=None, top=10, max_ratio=0.05, counts=None):
    """
    拿 old_value_fragments 的舊字搜新版全文（每段只記最長的那個命中）。

    「定義」的舊詞不設辨識力門檻：用到舊名的段落一段都不能漏，出現在幾段就是幾段要改。
    「舊值」照 find_by_changed_text 的辨識力門檻（全文超過 5% 的段落都有就不搜）；
    表格格子例外——一格只有「三日內」，到處都有，要看那一列的名稱跟這次改的條文
    有沒有一段四個字一樣（「客戶申訴陳報單位主管」對「受理客戶申訴時」），
    對得上才列，「網路投保身分驗證」那一列的「三日內」是別件事。
    比對一律用 _old_value_form（全形半形、空白、中文數字不計：「六十五歲」＝「65歲」），
    數字邊界照舊（「3個月」不算在「13個月」裡）；回傳的 matched 照原來的詞。

    排序（top 從前面截）：舊字所在那一句跟舊文那一句多像（_old_value_context）→ 命中的詞多長
    → 段次。以前只看詞長、同長照段次，「同數字、別件事」的段只要排在前面就先佔名額。
    counts：同 find_by_changed_text（定義的命中一律列，不算在內）。
    """
    if not fragments:
        return []
    bodies = [_old_value_form(strip_article_no(p or "")) for p in all_paragraphs]
    limit = max(3, int(len(all_paragraphs) * max_ratio))
    old_body = _old_value_form(strip_article_no(old_text or ""))
    forms = {term: _old_value_form(term) for term, _ in fragments}
    common = set()
    for term, kind in fragments:
        if kind == "舊值" and forms[term] and sum(1 for b in bodies if _independent(forms[term], b)) > limit:
            common.add(term)
    hits = []
    for idx, paragraph in enumerate(all_paragraphs):
        line_no = idx + 1
        if exclude_index is not None and line_no == exclude_index:
            continue
        body = bodies[idx]
        label = _row_label(all_paragraphs, kinds, idx)
        matched = []
        for term, kind in fragments:
            if not forms[term] or not _independent(forms[term], body):
                continue
            if kind == "舊值" and label is not None and len(body) <= 20:
                if not _shares_phrase(_old_value_form(label), old_body):
                    continue
            elif kind == "舊值" and term in common:
                continue
            matched.append((kind, term))
        if not matched:
            continue
        context = contexts[idx] if contexts else None
        hits.append({
            "line_number": line_no,
            "article_no": (context["ref"] if context else "") or extract_article_no(paragraph),
            "scope": format_scope(context),
            "text": paragraph,
            "matched": matched,
            "definition": any(kind == "定義" for kind, _ in matched),
            "strength": max(len(term) for _, term in matched),
            "context_score": _old_value_context(old_body, body, forms[max((t for _, t in matched), key=len)],
                                                _old_value_form(label)),
        })
    # 定義的命中一律保留；其他舊值照上下文像不像、詞長取前 top 段（同分照段次）
    defs = [h for h in hits if h["definition"]]
    rest = sorted((h for h in hits if not h["definition"]),
                  key=lambda h: (-h["context_score"], -h["strength"], h["line_number"]))
    if counts is not None:
        counts["total"] = len(defs) + len(rest)
        counts["unlisted"] = max(0, len(rest) - top) if top and top > 0 else 0
    if top and top > 0:
        rest = rest[:top]
    return sorted(defs + rest, key=lambda h: h["line_number"])


# 長句子超過 MAX_FRAGMENT 抽不出詞時，用這幾個標點切成子句再抽（見 deleted_fragments）。
_CLAUSE_SPLIT = re.compile(r"[，、；：]")


def deleted_fragments(old_text, min_len=2, max_terms=6):
    """
    整段被刪掉時沒有新文可比對「這次加了什麼」——changed_fragments(old, old)
    永遠是空的，因為跟自己比對沒有 insert。但這條被刪了，別的章節可能還留著
    同一句沒刪，一樣是漏改，一樣要能搜。

    拿舊文（去條號）切句，每句用既有的 search_terms() 抽詞，取每句前兩個、
    整體去重，湊到 max_terms 個就停。不像 changed_fragments／context_fragments
    那樣有「找不到再退文脈」的退路——沒有新文，文脈搜尋沒有意義。
    """
    body = strip_article_no(old_text or "")
    out = []
    for sentence in split_sentences(body):
        if len(sentence) <= MAX_FRAGMENT:
            clauses = [sentence]
        else:
            # 句子超過 MAX_FRAGMENT 時 search_terms() 本身會直接回 []（見它的長度
            # 篩選），整句一個詞都抽不出來——法規條文常常一句話 50 字以上，這樣
            # 會白跑。先用「，、；：」切成子句，每個子句照樣抽詞；子句本身還是
            # 太長就讓 search_terms() 自然回空，不勉強再往下切，其餘子句仍能貢獻詞。
            clauses = [c for c in _CLAUSE_SPLIT.split(sentence) if c.strip()]
        for clause in clauses:
            for term in search_terms(clause, min_len=min_len)[:2]:
                if term not in out:
                    out.append(term)
                    if len(out) >= max_terms:
                        return out
    return out


def coverage_note(fragments, candidate_body, normalize, synonyms):
    """
    這次新增的那幾段字，候選條文裡有沒有。

    --------------------------------------------------------------------
    為什麼這一項比「業務相不相同」重要
    --------------------------------------------------------------------
    實測過一個會漏判的情境：某條加了「至少五年」的保存期限，
    其他三條分別講信貸、車貸、信用卡——**業務全都不同**，
    但那三條也都寫「並留存電子紀錄」，也都該加保存期限。

    如果照「業務不同就不用改」去篩，這三條會全部被漏掉。

    真正該問的不是「業務同不同」，是「**你這次加的東西，那一條有沒有**」。
    這件事程式量得出來，不必交給判斷。

    回傳四種結果：
        ""              沒有可比的新增內容（例如整條新增、整條刪除）
        "候選也有：…"    候選條文**字面上**已經有這些內容，多半不用動
        "只有同義詞：…"  字面沒有，只是同義詞表把兩邊收成同一個詞（「終止≈解除」），要人確認
        "候選缺少：…"    候選缺這些內容，**這是最該看的一種**

    只靠同義詞才對上的不算「候選也有」：同義詞表收了幾組法律上不是同一件事的詞
    （終止／解除、通知／告知、繳納／給付……），異動加了「終止契約」、候選寫「解除契約」，
    說成「候選也有」人就跳過了——那正是要改的地方。要不要當成同一件事由人決定，
    所以另列一類，結論也不會是「候選也有」。
    """
    if not fragments:
        return ""

    body = candidate_body or ""
    body_norm, body_applied = normalize(body, synonyms) if synonyms else (body, set())

    missing, present, by_synonym = [], [], []
    for piece in fragments:
        if piece in body:
            present.append(piece)
            continue
        piece_norm, piece_applied = normalize(piece, synonyms) if synonyms else (piece, set())
        if synonyms and piece_norm in body_norm:
            pairs = synonym_evidence(set(piece_applied), set(body_applied), piece, body, synonyms)
            by_synonym.append("、".join(p.replace("＝", "≈") for p in pairs) or piece)
        else:
            missing.append(piece)

    synonym_part = "只有同義詞：%s" % "、".join(by_synonym[:5]) if by_synonym else ""
    if missing:
        note = "候選缺少：" + "、".join(missing[:5])
        if present:
            note += "（已有：%s）" % "、".join(present[:3])
        if synonym_part:
            note += "（%s，請確認是否同一件事）" % synonym_part
        return note
    if synonym_part:
        return (synonym_part + "（請確認是否同一件事）"
                + ("（已有：%s）" % "、".join(present[:3]) if present else ""))
    return "候選也有：" + "、".join(present[:5])


# 改動片段開頭常見的連接詞與虛字。這些不是要找的概念，要先剝掉，
# 否則「及火險保單」會拿「及」去搜，全文到處都是。
_LEADING = "及並或暨與且的之其該此本前後另應得須不亦仍即"
_TRAILING = "的之者等"

# 短到沒有辨識力的詞，拿去搜只會製造雜訊。
_TOO_COMMON = set((
    "規定 辦理 作業 事項 相關 有關 應予 予以 得予 本行 本公司 本要點 各款 前項 "
    "前條 該等 情形 方式 內容 資料 文件 紀錄 人員 單位 主管 機關 業務"
).split())


# 條號與款目編號。它們是編號不是概念，留著會讓「一、受託人授權書」
# 拿「一、」去搜，全文到處都是。
_NUMBERING = re.compile(
    r"^\s*(第\s*[零〇一二三四五六七八九十百千兩\d]+\s*[條點項款目章節]"
    r"(\s*之\s*[零〇一二三四五六七八九十百千兩\d]+)?"
    r"|[零〇一二三四五六七八九十百千兩\d]+\s*[、.]"
    r"|[（(]\s*[零〇一二三四五六七八九十百千兩\d]+\s*[）)])\s*")

# 改動片段長到這個程度，就不是「加了一個概念」而是整條改寫或整條新增，
# 那種情況相似度比對本來就抓得到，再用關鍵詞搜只會製造雜訊。
MAX_FRAGMENT = 20


def search_terms(fragment, min_len=2, max_terms=6):
    """
    從一段「這次改動的文字」抽出可以拿去搜的詞。

    只取**前綴與後綴**，不取中間的滑動窗。原因是中文沒有斷詞套件可用，
    中間的窗會切出「險保」這種跨詞碎片。實測用整句抽 n-gram，974 段的內規
    有 319 段命中（33%），完全不能用；只取前後綴就沒有這個問題，
    因為改動片段本身很短，而且是人寫出來的完整概念。

        「及火險保單」→ 剝掉「及」→「火險保單」
          前綴：火險、火險保、火險保單
          後綴：保單、險保單
          （不會產生「險保」這種碎片）

    **原始片段本身排在最前面**（只去編號、去頭尾標點，不剝 _LEADING／_TRAILING）。
    原因：同義詞表（設定.html 的「同義詞表」、normalize_terms）是
    整詞比對，剝過頭的詞永遠配不上同義詞。SKILL／reference/02 拿
    「保險費 → 應繳金額」當示範，但

        「應繳金額」→ 剝掉開頭的「應」→「繳金額」

    「繳金額」不在同義詞表裡，於是那個示範反而搜不到「保險費」那幾條。
    先放整詞「應繳金額」就配得上，剝後的前後綴照舊排在它後面當備援。
    """
    stripped = _NUMBERING.sub("", (fragment or "").strip())
    # 原始片段（不剝頭尾虛字），給同義詞整詞比對用
    whole = stripped.strip("，、。；：（）()　 ")
    text = stripped
    while text and text[0] in _LEADING:
        text = text[1:]
    while text and text[-1] in _TRAILING:
        text = text[:-1]
    text = text.strip("，、。；：（）()　 ")

    terms = []
    if min_len <= len(whole) <= MAX_FRAGMENT and whole not in _TOO_COMMON:
        terms.append(whole)
    if not (min_len <= len(text) <= MAX_FRAGMENT):
        return terms[:max_terms]

    for n in range(len(text), min_len - 1, -1):
        for candidate in (text[:n], text[-n:]):
            if candidate not in terms and candidate not in _TOO_COMMON:
                terms.append(candidate)
    return terms[:max_terms]


_SENTENCE_SPLIT = re.compile(r"[。；]")
# 排除純標點片段：原本用列舉標點字元的 _ONLY_PUNCT 反過來擋，但那份列舉不完整
# （像「！？／％」就不在裡面），標點片段照樣會混進去。改成正向判斷——片段裡
# 至少要有一個中文字、數字或英文字母，不然不算「內容」。
_CONTENT_CHAR_RE = re.compile(r"[一-鿿0-9A-Za-z]")


def _HAS_CONTENT(piece):
    """這個片段裡有沒有「內容」（至少一個漢字、數字或英文字母）。

    先過 normalize_for_compare 再判，全形的 Ａ-Ｚ／ａ-ｚ／０-９ 才算得上內容。
    以前直接拿字面比，全形英數條文（「ＡＢＣ級客戶……」）改一個字時抽出來的
    文脈片段會被整批丟掉，find_by_changed_text 回空、連帶條文搜尋整段靜默跳過——
    是漏抓加上沉默，比假陽性危險。
    """
    return bool(_CONTENT_CHAR_RE.search(normalize_for_compare(piece)))


def whole_terms(fragment, min_len=2):
    """whole_only（文脈）模式的搜尋詞：只拿整段片段本身，但一樣過兩道濾網。

    文脈模式以前直接 `[fragment]`，繞過 search_terms 的 _NUMBERING 與
    _TOO_COMMON——程式自己列成「沒有辨識力」的「規定」「辦理」，以及款目編號
    「一、」「(1)」照樣被當搜尋詞拿去撈全文，撈回來的是滿滿的公文套語段落。
    同一支程式對「這個詞有沒有辨識力」不能有兩套標準。
    """
    whole = _NUMBERING.sub("", (fragment or "").strip()).strip("，、。；：（）()　 ")
    if len(whole) < min_len or whole in _TOO_COMMON:
        return []
    return [whole]


# 純數字的片段（全形半形都算）。中文數字不在內：「十五」在「一百十五年」裡是
# 另一個數，但中文數字的邊界要連「百」「千」一起看，規則複雜且誤殺風險高，
# 這裡只處理阿拉伯數字這種一眼看得出邊界的。
_ALL_DIGITS_RE = re.compile(r"^[0-9０-９]+$")
_DIGIT_CLASS = "0-9０-９"


def term_hits(term, text):
    """這個搜尋詞有沒有出現在這一段裡。純數字的詞要看前後邊界。

    子字串比對會讓「15」命中「115年」「150人」——撈回來的條文跟這次改的數字
    毫無關係，而數字正是最需要精準的那一種片段（期限、比率、金額）。
    """
    if not term or not text:
        return False
    if _ALL_DIGITS_RE.match(term):
        pattern = r"(?<![%s])%s(?![%s])" % (_DIGIT_CLASS, re.escape(term), _DIGIT_CLASS)
        return re.search(pattern, text) is not None
    return term in text


_SENTENCE_BOUNDARY = "。；"


@functools.lru_cache(maxsize=20000)
def _split_sentences_cached(text, min_len):
    # 回傳 tuple 不是 list：lru_cache 的快取內容一定要是不可變的，
    # 不然呼叫端改到回傳值會連著改到快取本身。
    return tuple(s.strip() for s in _SENTENCE_SPLIT.split(text or "") if len(s.strip()) >= min_len)


def split_sentences(text, min_len=6):
    """以「。」「；」切句，去頭尾空白，太短的片段不算句子（「其他事項」這種對不出什麼）。

    句子層級比對每個異動段落都要把全文 1,347 段重新切句一次，同一段落在不同
    異動之間會被重算很多次；用 lru_cache 記住結果。公開介面型別不變，仍回傳 list。
    """
    return list(_split_sentences_cached(text, min_len))


def _sentence_spans(text):
    """以「。」「；」切句的 [(起, 迄)]（迄＝句界標點的位置）；「但」開頭的那一句併回前一句。

    但書不是獨立的一句規定，是前一句的例外（「應依內部控制制度辦理覆核；但金額未達
    新臺幣十萬元者，得由單位主管逕行核定」）。拆開來單獨比，全文帶著同一句但書的條文會
    全部被當成「同一句」：50 頁測資在條文尾巴加「，並副知法令遵循單位」，改動所在句變成
    整句但書，拿去比全文命中一堆只是但書一樣、規定本身毫不相干的條文，而且都有 82 分
    （80 分以上 77 列裡 45 列是這種）。跟前一句合起來，比的才是「同一個規定」。
    """
    text = text or ""
    spans = []
    start = 0
    for m in _SENTENCE_SPLIT.finditer(text):
        spans.append((start, m.start()))
        start = m.end()
    spans.append((start, len(text)))
    merged = []
    for start, end in spans:
        if merged and text[start:end].strip().startswith("但"):
            merged[-1] = (merged[-1][0], end)
        else:
            merged.append((start, end))
    return merged


@functools.lru_cache(maxsize=20000)
def _sentence_units_cached(text, min_len):
    return tuple(u for u in (text[s:e].strip() for s, e in _sentence_spans(text)) if len(u) >= min_len)


def sentence_units(text, min_len=6):
    """句子層級比對的單位：split_sentences 的切法，但但書併回前一句（見 _sentence_spans）。"""
    return list(_sentence_units_cached(text or "", min_len))


def changed_sentences(old_text, new_text, diff_runs, limit=5):
    """
    這次改動落在哪幾句。整段對整段時，改到的那一句會被沒改的 200 字稀釋到門檻以下；
    拿「改到的那一句」去比，長段落裡的同一句才抓得到（真資料 36.6 分 → 90.3 分）。

    新增段：新文的句子（最長前 limit 句）。刪除段：舊文的句子。修改：新文中含插入片段的句子，
    加上刪除片段所在位置對應的新文句子。句子的切法見 sentence_units：但書跟前一句算同一句。
    """
    if not new_text:
        return sorted(sentence_units(old_text), key=len, reverse=True)[:limit]
    if not old_text:
        return sorted(sentence_units(new_text), key=len, reverse=True)[:limit]
    positions = []          # 新文裡「有改動」的字元位置
    pos = 0
    for kind, text in diff_runs(old_text, new_text):
        if kind == "insert":
            positions.extend(range(pos, pos + len(text)))
        elif kind == "delete":
            positions.append(min(pos, max(len(new_text) - 1, 0)))
        if kind != "delete":
            pos += len(text)
    if not positions:
        return []
    out = []
    for start, end in _sentence_spans(new_text):
        sentence = new_text[start:end].strip()
        if len(sentence) >= 6 and any(start <= p <= end for p in positions) and sentence not in out:
            out.append(sentence)
    return out[:limit]


def context_fragments(old_text, new_text, diff_runs, width=4, min_len=2):
    """
    改動處左右各 width 字。一字之差（五→七）沒有片段可搜，「約期滿後」「定之日起」才搜得到別處的同一句。

    左右視窗都不跨句界（「。」「；」）：跨過去的片段（例如「項作業。」）在別的段落
    幾乎不可能整段再出現一次，尤其 whole_only 模式下等於永遠比不到，不如乾脆不取。
    片段被句界削到比 min_len 短就整段丟棄，不會留下沒有意義的殘片。

    delete 後面緊接 insert 時（一般的「取代」），delete 那一步的右視窗會從 pos
    開始算，但 pos 還沒跳過緊接在後的新字——算出來的右視窗會混進剛插入的字，
    不是真正的「原本的下文」。這種情況下略過 delete 的右視窗，交給後面那步
    insert（它的右視窗會正確地從插入文字之後算起）去取。
    """
    out = []
    pos = 0
    runs = list(diff_runs(old_text or "", new_text or ""))
    for idx, (kind, text) in enumerate(runs):
        if kind in ("insert", "delete"):
            left = (new_text or "")[max(0, pos - width):pos]
            # 左視窗只留最後一個句界之後的部分，不跨到前一句
            boundary = max(left.rfind(ch) for ch in _SENTENCE_BOUNDARY)
            if boundary != -1:
                left = left[boundary + 1:]
            pieces = [left]
            skip_right = (kind == "delete" and idx + 1 < len(runs)
                         and runs[idx + 1][0] == "insert")
            if not skip_right:
                right_start = pos + (len(text) if kind == "insert" else 0)
                right = (new_text or "")[right_start:right_start + width]
                # 右視窗只留第一個句界之前的部分，不跨到下一句
                cuts = [i for i in (right.find(ch) for ch in _SENTENCE_BOUNDARY) if i != -1]
                if cuts:
                    right = right[:min(cuts)]
                pieces.append(right)
            for piece in pieces:
                piece = piece.strip()
                if len(piece) >= min_len and _HAS_CONTENT(piece) and piece not in out:
                    out.append(piece)
        if kind != "delete":
            pos += len(text)
    return out


def _bare(text):
    """去條號、去頭尾空白與句尾標點：拿來判斷「這一句就是整段」。"""
    return strip_article_no(text or "").strip().rstrip("。；").strip()


# 句子層級「整段對整段」的那一對（改動所在句就是整段、候選段也只有一句），共同片段不在句首、
# 又有這麼長，就是共用目的語＋但書的套語（「，作為內部控制制度有效運作之依據；但金額未達…」
# 50 頁測資 24～55 字），不在句子層級再列一次（整段相似那一路已經列了、還標了句中）。
# 換句話說的真候選（「業務員受理保戶申訴案件…」對「業務人員受理客戶申訴時…」）共同片段只有
# 「單位主管」四個字，不受影響，照舊靠句分數升到列表那一層。
SHARED_TAIL = 10


_ANCHOR_SPLIT = re.compile(r"[，；。：:]+")


def _anchor_units(text):
    return [part.strip() for part in _ANCHOR_SPLIT.split(text or "") if part.strip()]


def anchor_clauses(old_text, new_text):
    """改過的子句旁邊，舊文也有且至少十字的未改子句。"""
    if not (old_text or "").strip() or not (new_text or "").strip():
        return []
    old = _anchor_units(old_text)
    new = _anchor_units(new_text)
    # 子句序列對齊：改寫、新增、整個子句刪掉的位置，兩旁沒改的子句都是錨
    # （以前只看「新文裡不在舊文的子句」，整個子句刪掉時兩旁的子句找不到錨）
    ops = difflib.SequenceMatcher(None, old, new, autojunk=False).get_opcodes()
    same = set()
    for tag, _, _, j1, j2 in ops:
        if tag == "equal":
            same.update(range(j1, j2))
    near = set()
    for tag, _, _, j1, j2 in ops:
        if tag != "equal":
            near.update((j1 - 1, j2))
    return list(dict.fromkeys(new[i] for i in sorted(near & same)
                              if len(re.sub(r"\s+", "", new[i])) >= 10))


def find_by_anchor(anchors, all_paragraphs, exclude_index=None, contexts=None, threshold=75, top=5):
    """每段取最高分的錨與子句；超過全文 5% 段落命中的錨不列。"""
    anchors = list(dict.fromkeys(a for a in (anchors or []) if a and a.strip()))
    if not anchors or not all_paragraphs:
        return []
    units = [_anchor_units(p) for p in all_paragraphs]
    matched = []
    for anchor in anchors:
        length = len(re.sub(r"\s+", "", anchor))
        if not length:
            continue
        per_anchor = {}
        for idx, clauses in enumerate(units):
            best = None
            for clause in clauses:
                if 2 * abs(len(re.sub(r"\s+", "", clause)) - length) >= length:
                    continue
                score = calc_similarity(anchor, clause)
                if score >= threshold and (best is None or score > best[0]):
                    best = (score, clause)
            if best is not None:
                per_anchor[idx] = best
        # 套語門檻跟 find_by_old_value 一樣至少 3 段（短文件 5% 不到一段，以前命中一段就被當成套語）；
        # 自己那段不算進去
        hits_elsewhere = sum(1 for idx in per_anchor if exclude_index is None or idx + 1 != exclude_index)
        if hits_elsewhere <= max(3, int(len(all_paragraphs) * 0.05)):
            matched.append((anchor, per_anchor))
    hits = []
    for idx, paragraph in enumerate(all_paragraphs):
        if exclude_index is not None and idx + 1 == exclude_index:
            continue
        best = None
        for anchor, per_anchor in matched:
            found = per_anchor.get(idx)
            if found is not None and (best is None or found[0] > best[0]):
                best = (found[0], anchor, found[1])
        if best is None:
            continue
        score, anchor, clause = best
        context = contexts[idx] if contexts else None
        hits.append({"line_number": idx + 1,
                     "article_no": (context["ref"] if context else "") or extract_article_no(paragraph),
                     "scope": format_scope(context), "text": paragraph,
                     "changed_sentence": anchor, "matched_sentence": clause,
                     "sentence_score": round(score, 1), "synonym_evidence": []})
    hits.sort(key=lambda hit: (-hit["sentence_score"], hit["line_number"]))
    return hits[:top] if top and top > 0 else hits


def find_by_sentence(changed, all_paragraphs, threshold=DEFAULT_SENTENCE_THRESHOLD, top=DEFAULT_TOP,
                     exclude_index=None, contexts=None, synonyms=None, changed_text=None):
    """
    拿改到的那幾句，去跟全文每一段的每一句比，取每段最高分。回傳 dict 列，依分數排序。

    分數用去掉條號後的句子算（同 find_duplicates 的整段比對）。句子本身可能是段落
    第一句、帶著開頭的條號（「第三百二十七條 ……」），三個內文一模一樣、只有條號不同
    的候選不去掉條號會各自扣掉不一樣的分數（84.6／83.6／92.9），變成看條號長得像不像，
    不是看內容像不像。顯示用的 matched_sentence／changed_sentence 仍保留原文（含條號）。

    changed_text：這處異動的整段。改動所在句就是整段、候選段也只有一句時，這一對就是
    整段對整段（整段相似那一路已經比過、標了片段位置）；分數不到 HIGH_CONFIDENCE、共同片段
    不在句首又有 SHARED_TAIL 字以上的（共用的套語尾巴）這裡不再列——再列一次只會用比較低的門檻、
    沒有片段位置，把只是共用目的語與但書的條文抬成「句 60～79 分」。其餘照舊列：換句話說的
    孿生條整段分數常常被標成句尾，要靠句分數才升得到列表那一層。
    """
    changed = [s for s in (changed or []) if s]
    if not changed:
        return []
    syn_key = tuple(synonyms or [])
    changed_norm = [(_normalize_cached(strip_article_no(s), syn_key), s) for s in changed]
    whole = _bare(changed_text) if changed_text else None
    whole_changed = {s for s in changed if whole is not None and _bare(s) == whole}
    hits = []
    for idx, paragraph in enumerate(all_paragraphs):
        line_no = idx + 1
        if exclude_index is not None and line_no == exclude_index:
            continue
        best = None
        units = sentence_units(paragraph)
        single = len(units) == 1 and _bare(units[0]) == _bare(paragraph)
        for sentence in units:
            sentence_norm, sentence_applied = _normalize_cached(strip_article_no(sentence), syn_key)
            for (c_norm, c_applied), c_raw in changed_norm:
                score = calc_similarity(c_norm, sentence_norm)
                if score < threshold or (best is not None and score <= best[0]):
                    continue
                if single and c_raw in whole_changed and score < HIGH_CONFIDENCE:
                    fragment, position = longest_common_fragment(strip_article_no(c_raw),
                                                                 strip_article_no(sentence))
                    if position in ("句中", "句尾") and len(fragment) >= SHARED_TAIL:
                        continue
                best = (score, sentence, c_raw, c_applied, sentence_applied)
        if best is None:
            continue
        score, sentence, c_raw, c_applied, sentence_applied = best
        context = contexts[idx] if contexts else None
        hits.append({
            "line_number": line_no,
            "article_no": (context["ref"] if context else "") or extract_article_no(paragraph),
            "scope": format_scope(context),
            "text": paragraph,
            "sentence_score": round(score, 1),
            "matched_sentence": sentence,
            "changed_sentence": c_raw,
            "synonym_evidence": synonym_evidence(set(c_applied), set(sentence_applied),
                                                 c_raw, sentence, synonyms or []),
        })
    hits.sort(key=lambda h: h["sentence_score"], reverse=True)
    return hits[:top] if top and top > 0 else hits




def find_by_changed_text(fragments, all_paragraphs, exclude_index=None,
                         contexts=None, synonyms=None, normalize=None,
                         extract_article_no=None, format_scope=None,
                         top=10, max_ratio=0.05, whole_only=False,
                         reference_text=None, counts=None):
    """
    拿「這次改動的那幾個字」去搜全文，而不是拿整條去比相似度。

    --------------------------------------------------------------------
    為什麼整條比對不夠
    --------------------------------------------------------------------
    整條對整條時，分數被「沒改到的部分」主導，而那部分往往就是公文套語。
    真正該找的是改動涉及的概念在哪裡還有出現。

    實測：第六條加了「及火險保單」。同一份內規裡有

        第四十條　本行辦理擔保放款，應確認擔保品已投保火險……
        第四十一條　擔保品之保險單正本應由本行收執……

    這兩條講的就是火險與保單，直接相關。但整條比對只有 26.5 分與 16.7 分，
    在 45 分門檻下**一條都抓不到**。改用改動文字去搜就找得到。

    回傳依「命中的詞多長」排序——命中越長的詞，關聯越明確。

    whole_only：True 時每個片段只拿整段本身當詞，不拆 search_terms() 的前後綴子詞
    （一樣經過 distinctive() 篩選）。改動處左右文脈通常只有 4 個字，拆出來的
    2 字子詞（如「定之」）辨識力低，命中的多半是不相干的套語段落。

    排序（top 從前面截）：命中的字加起來多長 → 最長的那個詞多長 → 整段跟 reference_text
    （這處異動的全文）多像 → 段次。以前只看最長的詞、同長照段次：文脈模式每個詞都是 4 個字，
    前 8 名等於「全文最前面的 8 段」，同一句話寫在第 300 段的真候選被截掉，畫面也不講。
    counts：給一個 dict 就填 {"total": 命中幾段, "unlisted": 因 top 沒列幾段}，
    呼叫端要把「另有 N 段因上限沒列」講出來。
    """
    if not fragments:
        return []

    # 在全文命中太多段的詞，本身就沒有辨識力（「受託」「三十」這種），
    # 留著只會把整份文件都撈出來。用資料自己算，不用手工黑名單。
    limit = max(3, int(len(all_paragraphs) * max_ratio))

    # 分母要跟 search_terms 對齊：search_terms 一開頭就把條號剝掉，這裡卻拿含條號的
    # 原文去數，於是「三十」被第三十條、第三十一條、第三十二條……的條號灌爆，
    # 判成「沒有辨識力」而整組搜尋詞被丟掉——中文數字的片段幾乎一定活不下來，
    # 而期限、比率這類最該追的異動，片段正好就是數字。
    bodies = [strip_article_no(p) for p in all_paragraphs]

    def distinctive(term):
        hits = 0
        for body in bodies:
            if term_hits(term, body):
                hits += 1
                if hits > limit:
                    return False
        return True

    term_sets = []
    for fragment in fragments:
        terms = whole_terms(fragment) if whole_only else search_terms(fragment)
        terms = [t for t in terms if distinctive(t)]
        if terms:
            # v1.59.1：詞的正規化結果跟段落無關，先算好（以前每一段重算一次）
            term_sets.append((fragment, [(t, normalize(t, synonyms)[0] if (normalize and synonyms) else t)
                                         for t in terms]))
    if not term_sets:
        return []

    reference_body = strip_article_no(reference_text) if reference_text else ""
    hits = []
    syn_key = tuple(synonyms or [])
    for idx, paragraph in enumerate(all_paragraphs):
        line_no = idx + 1
        if exclude_index is not None and line_no == exclude_index:
            continue
        # 比對也用剝掉條號的本文，跟 distinctive() 的分母同一把尺（B6）：
        # 用整段比，「三十」會命中第三十～三十七條的條號，真正的候選被擠出前幾名
        body = bodies[idx]
        if normalize and synonyms:
            body_norm = (_normalize_cached(body, syn_key)[0]
                         if normalize is normalize_terms else normalize(body, synonyms)[0])
        else:
            body_norm = body

        matched = []
        for fragment, terms in term_sets:
            for term, term_norm in terms:
                if term_hits(term, body) or term_hits(term_norm, body_norm):
                    matched.append((fragment, term))
                    break        # 每個改動片段只記最長的那一個命中
        if not matched:
            continue

        context = contexts[idx] if contexts else None
        hits.append({
            "line_number": line_no,
            "article_no": ((context["ref"] if context else "")
                           or (extract_article_no(paragraph)
                               if extract_article_no else "")),
            "scope": format_scope(context) if format_scope else "",
            "text": paragraph,
            "matched": matched,
            "strength": max(len(term) for _, term in matched),
            "total_length": sum(len(term) for _, term in matched),
            # 只在命中的那幾段算（不是全文），拿來分同樣命中幾個字的段誰比較像這處異動
            "reference_score": calc_similarity(reference_body, body) if reference_text else 0.0,
        })

    hits.sort(key=lambda h: (-h["total_length"], -h["strength"], -h["reference_score"],
                             h["line_number"]))
    if counts is not None:
        counts["total"] = len(hits)
        counts["unlisted"] = max(0, len(hits) - top) if top and top > 0 else 0
    return hits[:top] if top and top > 0 else hits

def hit_label(article_no, line_number):
    """畫面上的定位標籤：有條號寫「第五條（第16段）」，沒有條號只寫「第16段」。

    條號欄空的時候 label 本來就退回「第N段」，格式字串再固定補一次括號，
    無條號的作業手冊型文件整份印成「第16段（第16段）」——同一個座標印兩次，
    看的人會先以為那是兩個不同的數字，再花時間確認它們是同一個。
    """
    if article_no:
        return "%s（第%d段）" % (article_no, line_number)
    return "第%d段" % line_number


def scoped_label(scope, article_no, line_number):
    """章節＋定位標籤。條號本身已經帶著章節（「第二章第三款」）時不再前面補一次章節，
    不然畫面印成「第二章 第二章第三款」，看起來像程式把章節算錯了。"""
    label = hit_label(article_no, line_number)
    if not scope:
        return label
    if article_no and re.sub(r"\s+", "", article_no).startswith(re.sub(r"\s+", "", scope)):
        return label
    return "%s %s" % (scope, label)


def print_changed_text_hits(fragments, hits, unlisted=0):
    """把「拿改動文字去搜」的結果印出來，跟相似度候選分開列。

    unlisted：因為每處上限沒列出來的段數（find_by_changed_text 的 counts）。不講的話，
    人看到 8 筆會以為全文就只有這 8 段提到。
    """
    if not fragments:
        return
    print("")
    print("── 以這次改動的文字搜尋全文 ──")
    # 這幾段是「改動處前後的字」拿去搜的搜尋詞，不是完整的詞，所以一段一段框起來，
    # 不要用頓號連成一串（以前印「改動片段：人員應於、日內將招」，看起來像一句壞掉的話）
    print("   用改動處前後的字去搜：%s" % "".join("「%s」" % f for f in fragments))
    if not hits:
        print("   全文沒有其他條文提到這些內容。")
        return
    print("   %d 條提到相同內容（整條相似度可能很低，但概念直接相關）：" % len(hits))
    for hit in hits:
        label = scoped_label(hit["scope"], hit["article_no"], hit["line_number"])
        terms = "".join("「%s」" % term for _, term in hit["matched"])
        print("   [%s] 命中%s" % (label, terms))
        print("      %s" % hit["text"])
    if unlisted:
        print("   另有 %d 段也命中，因每處上限沒列（列的是命中字最多、跟這處異動最像的那幾段）"
              % unlisted)

def describe_difference(changed_body, candidate_body, diff_runs,
                        limit=8, pad=4):
    """
    兩條相似條文「差在哪」，逐處列出，格式是 `……〔異動→候選〕……`。

    這一項直接回答「這是漏改，還是兩個作業的層級本來就不同」：

        受理後〔三→五〕日內　　　　　　異動寫三日，候選寫五日
        〔分行經理→區域中心主管〕覆核　核准層級不同
        鑑價報告〔及火險保單→無〕，並　異動有、候選沒有

    看到只有層級用詞在變，人一眼就知道那是刻意分級；看到業務名稱也在變，
    就知道那兩條本來講的就不是同一件事。

    --------------------------------------------------------------------
    為什麼要帶前後幾個字
    --------------------------------------------------------------------
    早期版本只把兩邊各自獨有的文字列出來，而且「少於兩個字就跳過」——
    本意是去掉標點雜訊，結果把訊號一起丟了。實測這幾種差異全部顯示成空白：

        三日 vs 五日　　　　　　（期間）
        不得 vs 得　　　　　　　（責任用語）
        一百萬元 vs 三百萬元　　（金額）

    差異欄空白會讓人以為兩條一模一樣，那比不顯示更糟。
    現在一個字的差異也照列，靠前後各借幾個字讓它讀得懂。

    limit：最多列幾處差異；超過會明講還有幾處，不會安靜截斷。
    pad：每處差異前後各借幾個相同的字當脈絡。
    """
    # 方向固定是「異動條文 → 候選條文」。反過來寫的話，〔區域中心→分行〕
    # 會被讀成「變成」，但候選條文不是舊版、是另一條條文，那樣讀是錯的。
    parts = diff_runs(changed_body or "", candidate_body or "")

    # 先整理成交錯的「相同／差異」兩種塊
    items = []
    for kind, text in parts:
        if kind == "equal":
            items.append(("equal", text))
            continue
        if not items or items[-1][0] != "diff":
            items.append(("diff", [], []))
        # 只有異動條文有的字進左邊，只有候選條文有的字進右邊
        (items[-1][1] if kind == "delete" else items[-1][2]).append(text)
    diffs = [k for k, item in enumerate(items) if item[0] == "diff"]
    if not diffs:
        return ""

    def body(item):
        chg, cand = "".join(item[1]), "".join(item[2])
        # 一律寫成〔異動→候選〕。缺的那一邊寫「無」，不用 ＋／－ 符號，
        # 那兩個符號在這裡容易被讀反。
        return "〔%s→%s〕" % (chg or "無", cand or "無")

    def equal_at(k):
        return items[k][1] if 0 <= k < len(items) and items[k][0] == "equal" else ""

    # 兩處差異中間隔的字不多時照原文接起來，不各自帶前後字再用空白隔開：
    # 以前寫成「〔無→財產保險〕業務人員　人員應於〔五→三〕日內將招」，
    # 「業務人員」「人員應於」其實是同一串字被印了兩次，看起來像條文有錯。
    # 隔得遠的才切開，中間用「…」表示省略。
    shown = diffs[:limit]
    out = [equal_at(shown[0] - 1)[-pad:]]
    for n, k in enumerate(shown):
        if n:
            gap = equal_at(k - 1)
            out.append(gap if len(gap) <= 2 * pad else gap[:pad] + "…" + gap[-pad:])
        out.append(body(items[k]))
    out.append(equal_at(shown[-1] + 1)[:pad])
    text = "".join(out)
    if len(diffs) > limit:
        # 截斷要講出來。安靜截斷會讓人以為只有這幾處不同。
        text += "　（另有 %d 處差異未列出）" % (len(diffs) - limit)
    return text


@functools.lru_cache(maxsize=50000)
def _normalize_cached(text, syn_key):
    """normalize_terms 的快取版。目標段落的正規化只跟段落與詞表有關，卻在每個異動、
    每個來源本都重算一次（10 個異動 × 1,350 段 × 94 組詞 ≈ 127 萬次子字串比對）。
    syn_key 是 tuple(synonyms)，同一份詞表在整個 process 裡是同一個 key。
    回傳 (正規化文字, frozenset(代表詞))；frozenset 是為了不讓呼叫端改到快取內容。"""
    text_norm, applied = normalize_terms(text, list(syn_key))
    return text_norm, frozenset(applied)


def find_duplicates(changed_text, all_paragraphs, threshold=DEFAULT_THRESHOLD,
                    top=DEFAULT_TOP, exclude_index=None, contexts=None,
                    synonyms=None, context_span=DEFAULT_CONTEXT,
                    changed_old_text=None, is_deleted=False):
    """
    拿修改過的文字去跟全文每一段比，回傳超過門檻的候選清單。

    exclude_index：要跳過的段次(從 1 起算)，通常就是被修改的那一段自己。
    沒指定的話，退而求其次跳過「文字完全相同」的段落。

    is_deleted：這一處異動是「整條刪除」。刪掉的那一段在新版全文裡已經不存在，
    自然也就沒有 exclude_index 可以給——於是上面那條「沒指定就跳過文字完全相同
    的段落」的退路會反過來咬人：整條刪除最該抓的就是別章那個一字不差的孿生條
    （壽險章刪了、產險章忘了刪），它偏偏就是唯一一個「文字完全相同」的段落，
    被當成「那是它自己」跳掉，這個功能對刪除型異動等於整個失效。
    所以刪除型一律不跳文字相同的段落——孿生條就是要找的東西本身。

    contexts：build_hierarchy() 算出的層級脈絡。有給的話，候選的條號會寫成
    「第三十三條第二款第二目」而不是只有「(二)」——候選清單是要拿去人工核對的，
    寫「(二)」等於叫人在 50 頁裡自己找。

    synonyms：同義詞表。有給的話，比對前先把「應繳金額」這類變體收斂成
    「保險費」，才抓得到用詞完全換掉的重複條文（實測 34 分拉到 56 分）。
    每一筆候選會一併記錄是哪一組詞讓它配對上的——不能只給分數不給理由。
    """
    changed_body = strip_article_no(changed_text)
    # 這次「加了哪幾段字」。拿去每個候選裡找，找不到的就是最該看的那幾條。
    added = changed_fragments(strip_article_no(changed_old_text or ""),
                              changed_body, _diff_runs)
    changed_norm, changed_applied = normalize_terms(changed_body, synonyms)
    syn_key = tuple(synonyms or [])

    candidates = []
    for idx, paragraph in enumerate(all_paragraphs):
        line_no = idx + 1
        if exclude_index is not None and line_no == exclude_index:
            continue
        if exclude_index is None and not is_deleted and paragraph == changed_text:
            continue

        paragraph_body = strip_article_no(paragraph)
        paragraph_norm, paragraph_applied = _normalize_cached(paragraph_body, syn_key)

        # 分數一律用正規化後的文字算。沒有同義詞命中時，正規化後就等於原文，
        # 分數也就等於純字面比對，不會憑空灌水。
        score = calc_similarity(changed_norm, paragraph_norm)
        if score >= threshold:
            # 分數用正規化後的文字算，但「共同片段」一定要用原文算。
            # 正規化會把「停止效力」換成代表詞「終止」，拿正規化後的片段去顯示，
            # 人工複核時把那段字複製到文件裡搜尋會完全找不到——
            # 一個叫人去核對的工具，給的線索必須是文件裡真的有的字。
            fragment, position = longest_common_fragment(changed_body, paragraph_body)
            context = contexts[idx] if contexts else None
            evidence = synonym_evidence(changed_applied, paragraph_applied,
                                        changed_body, paragraph_body,
                                        synonyms or [])
            candidates.append({
                "line_number": line_no,
                "article_no": ((context["ref"] if context else "")
                               or extract_article_no(paragraph)),
                "scope": format_scope(context),
                "text": paragraph,
                "similarity": round(score, 1),
                "common_fragment": fragment,
                "fragment_len": len(fragment),
                "fragment_position": position,
                "synonym_evidence": evidence,
                # 前後文與「差在哪」：光看分數分不出「漏改」與「層級本來就不同」，
                # 這兩項是給 LLM 判斷用的材料，不是給程式判斷的。
                "context_before": neighbours(all_paragraphs, idx, context_span)[0],
                "context_after": neighbours(all_paragraphs, idx, context_span)[1],
                "difference": describe_difference(changed_body, paragraph_body,
                                                  _diff_runs),
                # 比「業務同不同」更關鍵：這次加的字，這一條有沒有
                "coverage": coverage_note(added, paragraph_body,
                                          normalize_terms, synonyms),
            })

    # 排序以相似度為主。同分時，共同片段從句首開始的排前面——實測顯示真正的
    # 重複條文都在這一類，非句首的則全是套語假陽性。
    candidates.sort(
        key=lambda c: (c["similarity"],
                       1 if c.get("fragment_position") in ("句首", "整段") else 0,
                       c["fragment_len"]),
        reverse=True)
    return candidates[:top] if top and top > 0 else candidates


def print_candidates(changed_text, candidates, threshold):
    """把候選清單印出來。"""
    head = changed_text if len(changed_text) <= 40 else changed_text[:40] + "…"
    print("\n" + "=" * 60)
    print("修改段落：%s" % head)
    print("=" * 60)

    if not candidates:
        print("沒有找到相似度超過 %.0f%% 的候選條文。" % threshold)
        print("若你認為別的章節應該有對應條文，可以試著 --threshold 35 再跑一次。")
        return

    print("共 %d 筆候選（依相似度排序）：\n" % len(candidates))
    for i, c in enumerate(candidates, 1):
        label = scoped_label(c.get("scope"), c["article_no"], c["line_number"])
        position = c.get("fragment_position", "")
        # 「多半是公文套語」這句話會叫人跳過這一筆。分數已經很高時這樣講是錯的，
        # 而且錯在整份報告最重要的那一筆上。分數低時它才是有效的排除訊號。
        if position in ("句首", "整段"):
            hint = ""
        elif c["similarity"] >= HIGH_CONFIDENCE:
            hint = "（%s起，但整段相似度高，要細看）" % position
        else:
            hint = "（%s起，多半是公文套語）" % position
        print("[候選%d] 相似度 %.1f%% ｜ %s｜ 共同片段 %d 字%s：%s"
              % (i, c["similarity"], label, c["fragment_len"], hint, c["common_fragment"]))
        print("  內容：%s" % c["text"])
        if c.get("coverage"):
            print("  這次加的字：%s" % c["coverage"])
        if c.get("context_before"):
            print("  前一段：%s" % c["context_before"][:60])
        if c.get("context_after"):
            print("  後一段：%s" % c["context_after"][:60])
        if c.get("difference"):
            # 「差在哪」直接回答「這是漏改，還是兩個作業的層級本來就不同」
            print("  兩條的差異：%s" % c["difference"])
        if c.get("synonym_evidence"):
            # 一定要說明是哪一組詞讓它配對上的。法遵場合要能回答
            # 「為什麼系統認為這兩條相關」，只給分數不給理由沒有用。
            print("  經同義詞比對：%s" % "、".join(c["synonym_evidence"]))
        print()






