# -*- coding: utf-8 -*-
"""
Step 1.5：款目編號重編與交叉引用檢查

什麼時候要用：
你在內規裡刪掉或插入了某一款、某一目之後，跑這支程式。

刪掉「二、」之後會發生三件事，一件比一件嚴重：

1. 編號斷掉        剩下 一、三、四、  ── 肉眼容易漏看，尤其 50 頁的內規
2. 對照表被灌爆    手動把 三、改成二、、四、改成三、之後，對照表會多出一堆
                   「修改」，但那些條文一個字都沒動，只是編號位移
3. 交叉引用失效    別的條文寫「依前條第二款規定」，原本的第二款已經不存在，
                   這句話現在指到完全不同的內容 ── 這是真正會出事的地方

這支程式處理前兩件，第三件明確列出來給人工判斷。

--------------------------------------------------------------------------
為什麼「條」預設不重編
--------------------------------------------------------------------------
法制作業慣例上，刪除某一條時，後面的條號不跟著往前遞補；被刪的條保留條號並
註記「第○條　（刪除）」。這樣做的理由很實際：全文與其他規章裡引用「第五十條」
的地方，不會因為前面刪了一條就全部指錯。新增條文也是同樣道理，才會有
「第五條之一」這種寫法。

所以本程式預設只重編「款」與「目」（它們是條的內部結構，重編不影響外部引用），
條號一律不動，只在發現斷號時提醒你要不要補「（刪除）」註記。
條號一律不重編，也沒有旗標可以打開；要遞補請人工處理並自行複核引用。

--------------------------------------------------------------------------
使用方式
--------------------------------------------------------------------------
    python renumber.py 新版內規.docx
        檢查模式：只報告問題，不動檔案

    python renumber.py 新版內規.docx --apply
        重編款目編號，輸出「重編後_新版內規.docx」

    python renumber.py 新版內規.docx --apply --rewrite-refs
        連同交叉引用一起改寫（只改「被引用的條款目還在、只是換號」那種；
        引用到已刪除款目的一律不動，強制人工處理；
        「個人資料保護法第五條」這種外部法規的條號一律不動）

    python renumber.py 新版內規.docx --old 舊版內規.docx
        額外比對舊版，找出被整條刪掉的條號，提醒補「（刪除）」註記，
        並且比出「舊條號 → 新條號」，才判得了條層級的交叉引用。
        沒給舊版就一律印「未檢查」，不會印「沒有受影響」這種假的安心。
"""

import argparse
import difflib
import functools
import os
import re
import sys
import unicodedata

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from _common import (setup_console, read_paragraphs, read_paragraphs_with_kinds,
                     build_hierarchy, cn_from_int, cn_to_int, resolve_output, list_label, structure_view,
                     CITATION_FILLER, CITATION_FILLER_RE,
                     strip_article_no, normalize_for_compare,
                     is_external_reference, is_own_law_name, POINT_RE, HAS_DOCX, _CN_NUM)
import notices as nt

# 中文數字的「字元集合」，只給正規表示式的字元類別用（[%s] 那個位置），
# 不要拿它當「第 n 個字是數字 n」的查表——「零」在最前面，索引會整排錯開。
# 要數字轉中文一律用 int_to_cn。
#
# 為什麼要含百／千／零／〇：以前這裡是「一二三四五六七八九十」，
# `_TOKEN_RE` 與 `scan_reference_drift` 的條號樣式因此認不得「第一百二十條」——
# `parse_references` 對三位數條號回空清單，報告卻照印「條層級引用：通過」；
# 更糟的是「第一百二十條第三款」的前半段配不上，後半段的「第三款」變成裸款號，
# 被當成「本條第三款」錯掛到引用所在的那一條。三位數條號在真資料很常見
# （300 條的作業要點），這是靜默漏判。
# 跟 `_common._CN_NUM` 共用同一個常數，兩邊各寫一份遲早會不一致。
CN = _CN_NUM

_CLAUSE_RE = re.compile(r"^([%s]+)(\s*、)" % CN)
# 目分成兩個數字體系：「(一)」是目，「(1)」是目底下再一層。
# 以前兩種收在同一個 _ITEM_RE 裡，plan_renumber 把它們併成一串重編，
# --apply-renumber 就會把「(1) 全職人員…」實際改寫成「(二) 全職人員…」——
# 兩個層級被壓成一層，原文被毀，而且會先誤報一次「編號重複」（實測 idx 45）。
# 重編一律用原本的體系：中文的回中文，阿拉伯的回阿拉伯，永遠不跨體系。
_ITEM_CN_RE = re.compile(r"^([（(])\s*([%s]+)\s*([）)])" % CN)
_ITEM_AR_RE = re.compile(r"^([（(])\s*([0-9０-９]+)\s*([）)])")
_ITEM_RE = re.compile(r"^([（(])\s*([%s\d０-９]+)\s*([）)])" % CN)   # 兩種都收，只給取號用
# 點：「1.」「1、」「１．」。跟 _common.build_hierarchy 判「點」層用的是同一個物件，
# 兩邊各寫一份的話，改了一邊另一邊會對不上（scan 抓不到號碼，重編就靜默跳過）。
_POINT_RE = POINT_RE

_ITEM_STYLE_CN = "目（中文）"
_ITEM_STYLE_AR = "目（阿拉伯）"


def _item_style_of(text):
    """這一段的目是哪一種數字體系，抓不到回 None。"""
    if _ITEM_CN_RE.match(text):
        return _ITEM_STYLE_CN
    if _ITEM_AR_RE.match(text):
        return _ITEM_STYLE_AR
    return None


def _item_pattern(style):
    return _ITEM_AR_RE if style == _ITEM_STYLE_AR else _ITEM_CN_RE


def _number_text(style, value):
    """重編後要寫回原文的號碼：阿拉伯體系寫阿拉伯，其餘寫中文。"""
    return str(value) if style == _ITEM_STYLE_AR else int_to_cn(value)


# 中文數字轉阿拉伯數字，支援到 999。實作在 _common.cn_to_int：
# 層級脈絡判斷「編號有沒有重新起算」用的是同一份，兩邊各寫一份遲早會不一致。
cn_to_int = cn_to_int


# 阿拉伯數字轉中文數字，支援到 999（百位照法規寫法：一百十二、一百零五）。
# 實作在 _common.cn_from_int：層級脈絡的項次也要用同一份，兩邊各寫一份的結果是
# _common 那份只到 99，100 以上吐出「第十十五項」、110 以上直接當掉。
int_to_cn = cn_from_int


# ---------------------------------------------------------------------------
# 掃描目前的編號狀態
# ---------------------------------------------------------------------------

def scan(paragraphs, kinds=None):
    """
    走一遍全文，回傳每一段的編號資訊。

    kinds 是 read_paragraphs_with_kinds 回傳的來源種類（"p"／"cell"），
    往下傳給 build_hierarchy：表格儲存格不能被算成前一條的項，
    否則重編與交叉引用檢查看到的層級跟修正對照表不一樣。

    每個元素：
        {"index": 段次(從1), "level": 條/款/點/目/其他, "article": 所屬條號,
         "written": 目前寫的號碼(整數), "clause_written": 所屬款的號碼,
         "point_written": 所屬「1.」點的號碼, "item_parent": 阿拉伯目所屬的中文目號碼,
         "item_style": 目的數字體系（中文／阿拉伯）,
         "clause_serial"／"point_serial": 所屬的款／點是同一個位置的第幾組}

    組序號來自 build_hierarchy：同一項裡被「本公司辦理前項事項時……」這種沒有編號的
    段落分成兩組的款，各自從「一、」重新起算。不分群的話會誤報「編號重複」，
    --apply-renumber 還會把第二組實際改成「三、四、」——原文就毀了。

    點與目的「所屬」資訊要記下來，重編才分得出「同一款底下不同小群的 (1)」——
    不分群的話兩群的 (1) 會被併成一串，第二群的 (1) 會被改寫成 (3)（實測 idx 45／50）。
    """
    contexts = build_hierarchy(paragraphs, kinds)
    entries = []
    clause_written = None
    point_written = None
    item_parent = None       # 目前所在的中文目，阿拉伯目掛在它底下
    paragraph_no = 1         # 條底下第幾項；每一項的款目都是重新起算的
    clause_serial = 1        # 這一項裡的款是第幾組（編號重新起算就 +1）
    point_serial = 1         # 這一款裡的點是第幾組
    # 這一款底下先出現的是點還是中文目：先出現的就是上層（跟 build_hierarchy 照出現順序疊一樣）。
    # 手冊兩種寫法都有：「一、／1.／(一)」與「一、／(一)／1.」。以前寫死前者，後者的
    # 「(一) 1. 2.…(二) 1. 2.」被併成一串報重號、點後面的「(二)」被當成另一串報沒從一開始
    # （04 保險代理業務手冊看得到 Word 自動編號之後，誤報從 15 處變 70 處）
    order = None

    for idx, (text, context) in enumerate(zip(paragraphs, contexts), 1):
        level = context["level"]
        written = None
        item_style = None
        point_parent = None

        if level == "條":
            clause_written = point_written = item_parent = order = None
            paragraph_no = 1
            clause_serial = point_serial = 1
        elif level == "項":
            # 新的一項開始，上一項的款目作廢。不歸零的話，第二項的「(一)(二)」
            # 會被接到第一項的「(一)(二)」後面，先誤報「編號重複」，
            # --apply-renumber 再把它們實際改寫成「(三)(四)」，原文就毀了。
            clause_written = point_written = item_parent = order = None
            paragraph_no += 1
            clause_serial = point_serial = 1
        elif level == "款":
            match = _CLAUSE_RE.match(text)
            written = cn_to_int(match.group(1)) if match else None
            clause_written = written
            point_written = item_parent = order = None
            clause_serial = context.get("group_serial", 1)
            point_serial = 1
        elif level == "點":
            match = _POINT_RE.match(text)
            written = cn_to_int(unicodedata.normalize("NFKC", match.group(1))) if match else None
            point_written = written
            order = order or "點在上"
            if order == "點在上":
                item_parent = None
            else:
                point_parent = item_parent       # 點掛在中文目底下：每一個目的點各自一串
            point_serial = context.get("group_serial", 1)
        elif level == "目":
            item_style = _item_style_of(text)
            match = _ITEM_RE.match(text)
            written = cn_to_int(unicodedata.normalize("NFKC", match.group(2))) if match else None
            if item_style == _ITEM_STYLE_CN:
                item_parent = written
                order = order or "目在上"
                if order == "目在上":
                    point_written = None         # 新的目：底下的點重新起算，目自己也不掛在點底下
                    point_serial = 1

        entries.append({
            "index": idx, "level": level, "article": context["article"],
            "written": written, "clause_written": clause_written,
            "point_written": point_written, "item_style": item_style,
            "paragraph_no": paragraph_no,
            "clause_serial": clause_serial, "point_serial": point_serial,
            # 中文目自己就是群的頭，不掛在別的目底下
            "item_parent": None if item_style == _ITEM_STYLE_CN else item_parent,
            # 「一、／(一)／1.」寫法裡點所屬的中文目（另一種寫法是 None）
            "point_parent": point_parent,
            # 沒有「第X條」的規章（作業手冊常見），款目是在章／節底下重新起算的，
            # 重編時要用章節當範圍，不能全文一串編到一百多。
            "scope": (context.get("chapter", ""), context.get("section", "")),
        })
    return entries


def plan_renumber(paragraphs, entries):
    """
    算出「哪一段的編號要從幾號改成幾號」。

    款：同一條底下的款，由上而下重編為 一、二、三……
    目：同一條同一款底下的目，重編為 (一)(二)(三)……

    回傳 (變更清單, 款對照表, 目對照表)。
    對照表是給交叉引用檢查用的：{(條號, 舊號): 新號}
    """
    changes = []
    clause_map = {}
    item_map = {}
    if not numbering_check_applicable(entries):
        return changes, clause_map, item_map

    clause_counter = {}
    item_counter = {}
    chinese_keys = set()     # 目的對照表裡，哪些鍵已經被中文體系佔了

    for entry in entries:
        article = entry["article"]
        # 有「第X條」就以條為範圍；沒有就以章／節為範圍
        group = _numbering_group(entry)

        if entry["level"] == "款":
            clause_counter[group] = clause_counter.get(group, 0) + 1
            new_no = clause_counter[group]
            if entry["written"] is not None:
                # 鍵要帶「第幾項」：每一項的款都從一起算，第二項的第四款會蓋掉第一項的第四款（B1）
                _remember(clause_map, (article, entry.get("paragraph_no") or 1, entry["written"]), new_no)
            if entry["written"] != new_no:
                changes.append({
                    "index": entry["index"], "level": "款",
                    "article": article,
                    "old": entry["written"], "new": new_no,
                    "old_text": paragraphs[entry["index"] - 1],
                    "new_text": _CLAUSE_RE.sub(
                        lambda m: int_to_cn(new_no) + m.group(2),
                        paragraphs[entry["index"] - 1], count=1),
                })

        elif entry["level"] == "目":
            style = entry.get("item_style") or _ITEM_STYLE_CN
            key = _item_group_key(entry, group)
            item_counter[key] = item_counter.get(key, 0) + 1
            new_no = item_counter[key]
            if entry["written"] is not None:
                map_key = (article, entry.get("paragraph_no") or 1, entry["clause_written"], entry["written"])
                # 交叉引用寫的是「第二目」這種中文寫法，中文體系優先佔位，
                # 阿拉伯體系只在中文沒佔到時補上，避免兩種體系互相覆蓋。
                if style == _ITEM_STYLE_CN:
                    if map_key in chinese_keys:
                        _remember(item_map, map_key, new_no)
                    else:
                        item_map[map_key] = new_no
                        chinese_keys.add(map_key)
                elif map_key not in chinese_keys:
                    _remember(item_map, map_key, new_no)
            if entry["written"] != new_no:
                number = _number_text(style, new_no)
                changes.append({
                    "index": entry["index"], "level": "目", "style": style,
                    "article": article,
                    "old": entry["written"], "new": new_no,
                    "old_text": paragraphs[entry["index"] - 1],
                    "new_text": _item_pattern(style).sub(
                        lambda m: m.group(1) + number + m.group(3),
                        paragraphs[entry["index"] - 1], count=1),
                })

    return changes, clause_map, item_map


# 對照表查到「這個號碼有兩個以上、換號結果又不一樣」時的記號：引用沒寫是哪一個，不能猜。
_AMBIGUOUS = object()


def _remember(mapping, key, new_no):
    """記下「舊號 → 新號」。同一把鑰匙碰到不同的新號就記成分不出來。

    同一項裡被沒有編號的段落分成兩組的款、同一款底下不同點的目，號碼都會撞在一起。
    後面的蓋掉前面的話，第一組的第三款明明換了號，「第三款」卻被判成安全；
    引用只寫到「第三款」，本來就分不出是哪一組，要說分不出來，不能靜靜挑一個。
    兩邊新號一樣就沒有差別，不用記成分不出來。"""
    if key in mapping and mapping[key] != new_no:
        mapping[key] = _AMBIGUOUS
    else:
        mapping[key] = new_no


def _item_group_key(entry, group):
    """目重新起算的範圍。

    中文目掛在（範圍, 款, 點）底下；阿拉伯目再往下掛一層，多帶所屬的中文目。
    少了「點」與「所屬中文目」這兩段，同一款底下不同小群的 (1) 會被併成一串，
    第二群的 (1) 就會被改寫成 (3)——那是實測 idx 45 毀掉原文的那條路。
    """
    style = entry.get("item_style") or _ITEM_STYLE_CN
    base = (style, group, entry.get("clause_written"),
            entry.get("point_written"), entry.get("point_serial") or 1)
    if style == _ITEM_STYLE_AR:
        return base + (entry.get("item_parent"),)
    return base


def find_numbering_gaps(entries):
    """
    找出編號本身就有問題的地方（斷號、重號、沒從一開始）。

    這是「使用者刪了款但沒重編」的直接證據，也是最容易在 50 頁內規裡漏看的東西。
    """
    if not numbering_check_applicable(entries):
        return []
    return _numbering_problems(entries)


def _numbering_problems(entries, include_points=False):
    """find_numbering_gaps 的本體，不看「適不適用」：沒有條的文件由 point_numbering_issues 呼叫。
    include_points：「1.」那一層也查（有條的文件照舊不查，行為不變）。
    每一筆多帶 indices（這一組每一段的段次）與 scope（章、節），分辨「這次改出來的」要用。"""
    problems = []
    groups = {}
    doc_wide = include_points and _points_run_through(entries)
    for entry in entries:
        # 跟 plan_renumber 同一套：有「第X條」以條為範圍，沒有就以章／節為範圍。
        # 作業手冊每章各自從「一、」起算，全文合成一組會被誤判成「編號重複」。
        # 例外：要點常見「一、」一路編到底、跨章不重來，那種文件整份當一串查。
        group = _numbering_group(entry)
        if entry["level"] == "款":
            if doc_wide and (entry.get("clause_serial") or 1) == 1:
                group = ("全文",)
            groups.setdefault(("款", group), []).append(entry)
        elif entry["level"] == "目":
            # 分群方式跟 plan_renumber 一模一樣：兩種數字體系、不同的點與中文目
            # 各自成群，否則會把「(一)(1)(2)(二)(1)」誤報成編號重複。
            groups.setdefault(("目",) + _item_group_key(entry, group),
                              []).append(entry)
        elif entry["level"] == "點" and include_points:
            groups.setdefault(("點", group, entry.get("clause_written"), entry.get("point_parent"),
                               entry.get("point_serial") or 1), []).append(entry)

    for key, group in groups.items():
        written = [e["written"] for e in group]
        if any(w is None for w in written):
            continue
        expected = list(range(1, len(written) + 1))
        if written == expected:
            continue

        if len(set(written)) != len(written):
            reason = "編號重複"
        elif written[0] != 1:
            reason = "沒有從第一%s開始" % key[0]
        else:
            reason = "編號不連續（中間有缺號，通常是刪除後沒有重編）"

        # 沒有條的文件（include_points）指到第一個對不上的那一段：整份一串的要點動輒二三十點，
        # 講「第 3 段起」人還要自己往下數到出錯的地方
        at = 0
        if include_points:
            at = next(i for i, (w, x) in enumerate(zip(written + [None], expected + [None])) if w != x)
            at = min(at, len(group) - 1)
        problems.append({
            "level": key[0], "article": group[0]["article"],
            "style": group[0].get("item_style"),
            "written": written, "expected": expected, "reason": reason,
            "first_index": group[at]["index"], "at": at,
            "indices": [e["index"] for e in group], "scope": group[at].get("scope") or ("", ""),
            "parent": (group[0].get("clause_written") if key[0] != "款" else None),
        })
    problems.sort(key=lambda p: p["first_index"])
    return problems


def _points_run_through(entries):
    """沒有條的文件，第一層的點（一、）是不是全文一路編下去、跨章節不重來。

    各章節第一層那一串照出現順序排好，下一串接著上一串的號碼往下編的次數，
    比從「一、」重來的次數多，就是一路編到底（要點最常見）；否則各章節各自起算（手冊）。
    全文只有一串（沒有章節的要點、只有一章的文件）沒有「跨章節」可以比，那一串就是一路編下去的；
    只有同一串裡又被分組、從一重來（小標底下各自起算）才不是。"""
    runs = []
    regrouped = False
    for entry in entries:
        if entry["level"] != "款" or entry["written"] is None:
            continue
        if (entry.get("clause_serial") or 1) != 1:
            regrouped = True
            continue
        if runs and runs[-1][0] == entry.get("scope"):
            runs[-1][2] = entry["written"]
        else:
            runs.append([entry.get("scope"), entry["written"], entry["written"]])
    if len(runs) == 1:
        return not regrouped
    pairs = list(zip(runs, runs[1:]))
    through = sum(1 for prev, cur in pairs if cur[1] == prev[2] + 1)
    restart = sum(1 for prev, cur in pairs if cur[1] == 1)
    return through > restart


def numbering_check_applicable(entries):
    """款目編號檢查／重編只適用於「第X條」底下有款目的規章。

    作業手冊型文件沒有條，款目在標題（含程式看不到的小標）底下各自重新起算，
    無論用條還是章／節分組都會誤報「編號重複」、也會提出錯的重編。真資料實測：
    1,347 段的手冊用章／節分組仍誤報 14 處。所以沒有任何一條的文件直接跳過。"""
    return any(e.get("article") for e in entries)


def _numbering_group(entry):
    """編號重新起算的範圍：有條用（條, 項次），沒有條用 (章, 節)。
    plan_renumber 與 find_numbering_gaps 共用。

    項次一定要進來：一條有兩項時，每一項的款都是從「一、」重新起算的，
    合成一組會誤報「編號重複」，重編還會把第二項的款目實際改號（毀原文）。
    同一項裡被沒有編號的段落分成兩組的款（build_hierarchy 的「（第N組）」）也一樣，
    所以組序號也要進來。"""
    serial = entry.get("clause_serial") or 1
    article = entry.get("article") or ""
    if article:
        return (article, entry.get("paragraph_no") or 1, serial)
    return ("§",) + tuple(entry.get("scope") or ("", "")) + (serial,)


# 舊條有這麼多比例的字出現在同一條新條裡，就算「被併進去」而不是「被刪掉」。
# 0.6 是這樣抓的：真的併條時舊條文幾乎原封不動搬過去，覆蓋率都在 0.9 以上；
# 只是碰巧用詞相近的兩條通常落在 0.3 以下，0.6 留了很寬的安全帶。
MERGE_COVERAGE = 0.6


def _article_texts(paragraphs, kinds=None):
    """把全文切成一條一條：[(條號, 這一條的原文全文)]。原文保留原字。

    整條的文字（條文本體加底下的款目項）才是配對的依據。只拿第一段比，
    兩條開頭都寫「本公司辦理下列事項：」就會互相配錯。
    """
    units = []
    current = None
    for text, context in zip(paragraphs, build_hierarchy(paragraphs, kinds)):
        if context["level"] in ("章", "節"):
            # 條後面的章節標題不是那一條的內容：算進去的話，只改下一章的章名，
            # 引用上一條的地方就報「內容變了」，對照原文卻看不出那一條改了什麼
            continue
        if context["level"] == "條" and context["article"]:
            if current is None or context["article"] != current[0]:
                current = [context["article"], [strip_article_no(text)]]
                units.append(current)
                continue
        if current is not None:
            current[1].append(text)
    return [(article, "".join(parts)) for article, parts in units]


def _article_units(paragraphs, kinds=None):
    """比對用的條文：條號加上正規化過的全文。

    只差全半形或空白的同一條要配得起來，所以比對前一律正規化；
    要印出來或寫進產出檔的一律用 _article_texts 的原文。
    """
    return [(article, normalize_for_compare(text))
            for article, text in _article_texts(paragraphs, kinds)]


def _coverage(old_body, new_body):
    """舊條的文字有多少比例出現在新條裡（0.0~1.0）。用來認「併條」。"""
    if not old_body:
        return 0.0
    matcher = difflib.SequenceMatcher(None, old_body, new_body, autojunk=False)
    matched = sum(block.size for block in matcher.get_matching_blocks())
    return matched / float(len(old_body))


def _align_block(old_chunk, new_chunk):
    """對一個被改過的區塊做一對一對齊。

    回傳 ([(舊區塊內序號, 新區塊內序號或 None), ...], 有沒有走帶狀對齊)。

    對齊演算法跟修正對照表用的是同一支（diff_compare.align_chunk）：保持前後順序、
    總相似度最高。兩邊各寫一份的話，對照表說「這兩條是同一條」、交叉引用卻說
    「這一條被刪了」，兩張產出自相矛盾。

    align_chunk 遇到大區塊會自己印「改用帶狀對齊」的提醒，那段話講的是修正對照表，
    對條號對照是錯的描述，而且一次執行會被印好幾遍。用 diff_compare 自己的收集
    機制先接住，由呼叫端改印一句講條號對照的。
    """
    import diff_compare

    outer = diff_compare._banded_notices
    diff_compare._banded_notices = []
    try:
        pairs = diff_compare.align_chunk(old_chunk, new_chunk)
        banded = bool(diff_compare._banded_notices)
    finally:
        diff_compare._banded_notices = outer

    # align_chunk 回傳的是文字，同一份文件裡可能有兩條文字一模一樣，
    # 所以照順序走游標還原到底是第幾條，不要拿文字回去查。
    result = []
    oi = nj = 0
    for old_text, new_text in pairs:
        if old_text is not None and new_text is not None:
            result.append((oi, nj))
            oi += 1
            nj += 1
        elif old_text is not None:
            result.append((oi, None))
            oi += 1
        else:
            nj += 1
    return result, banded


def _own_words(old_body, holder_body):
    """舊條裡，佔位那一條沒有的字。"""
    matcher = difflib.SequenceMatcher(None, old_body, holder_body, autojunk=False)
    pieces, pos = [], 0
    for block in matcher.get_matching_blocks():
        pieces.append(old_body[pos:block.a])
        pos = block.a + block.size
    return "".join(pieces)


def _filled_by_holder(old_body, holder_body, new_body):
    """新條是不是佔位的那一條遞補來的（不是併條）：同號舊條自己獨有的字，新條裡沒有。

    兩條舊條用字差不多時（「甲類業務應…」「乙類業務應…」）同號的覆蓋率也過得了門檻，
    這裡不擋的話，刪掉第二條、第三條小改後遞補上來，會被當成第二條還在，
    引用第二條的地方就沒有人講了。以前用長度分（新條裝不下兩條才算遞補），新條遞補時又
    加了幾句就判錯。兩條共同的字兩邊都解釋得通，要看的是舊條獨有的字：真的併條時它們會留下來。"""
    return _coverage(_own_words(old_body, holder_body), new_body) < MERGE_COVERAGE


def _prefer_same_article(old_units, new_units, unpaired, new_indices,
                         old_to_new, new_to_old):
    """同號優先：條號一樣、內容又對得上的，一定是同一條。

    align_chunk 只看文字分數，併條時常常把「新的第四條」配給「舊的第五條」
    （併進去之後新條比較長，跟長的那一條分數比較高），結果報成
    「第四條不見了、併入第四條」——那句話沒有人看得懂。

    unpaired 會被就地改掉：換掉的那一條進來、原本佔位的那一條出去。
    """
    for i in list(unpaired):
        article, old_body = old_units[i]
        for j in new_indices:
            new_article, new_body = new_units[j]
            if not _same_article(new_article, article):
                continue
            if _coverage(old_body, new_body) < MERGE_COVERAGE:
                continue
            holder = new_to_old.get(j)
            if holder is not None and _filled_by_holder(old_body, old_units[holder][1], new_body):
                continue
            if holder is not None:
                del old_to_new[holder]
                unpaired.append(holder)
            old_to_new[i] = j
            new_to_old[j] = i
            unpaired.remove(i)
            break


def plan_article_map(old_paragraphs, new_paragraphs,
                     old_kinds=None, new_kinds=None):
    """
    用「內容」把舊版的條配到新版的條，回傳 {舊條號: {"new":…, "merged_into":…}}。

    new 是新版對應的條號，配不到就是 None；merged_into 是「被併進哪一條」。

    為什麼不能只比條號集合：條號預設不重編，但實務上使用者常常自己先遞補過，
    也常常把兩條併成一條。只比集合的話，「第十條改叫第九條」會被報成
    「第十條被刪除」，人就會去補一個根本不該補的「（刪除）」註記；
    而別的條文寫的「第十條」其實已經指到不同的內容，反而沒人講。
    """
    old_units = _article_units(old_paragraphs, old_kinds)
    new_units = _article_units(new_paragraphs, new_kinds)
    if not old_units:
        return {}
    old_bodies = [body for _, body in old_units]
    new_bodies = [body for _, body in new_units]

    # 先用 difflib 的 opcodes 把「一模一樣的條」整段對掉（跟 _compare_paragraphs
    # 同一套做法），只有真的被改過的 replace 區塊才送進相似度對齊。
    # 不做這一步的話，一份 300 條的規章即使只刪了 3 條，也要算 300x297 格相似度
    # （實測 1.9 秒，而且一定會觸發帶狀對齊的提醒），那個提醒還是假警報。
    old_to_new = {}
    new_to_old = {}
    unpaired = []
    banded = False
    for tag, i1, i2, j1, j2 in difflib.SequenceMatcher(
            None, old_bodies, new_bodies).get_opcodes():
        if tag == "equal":
            for offset in range(i2 - i1):
                old_to_new[i1 + offset] = j1 + offset
                new_to_old[j1 + offset] = i1 + offset
        elif tag == "delete":
            unpaired.extend(range(i1, i2))
        elif tag == "insert":
            pass                    # 新版多出來的條，沒有舊條要對過去
        else:
            block_pairs, block_banded = _align_block(old_bodies[i1:i2],
                                                     new_bodies[j1:j2])
            banded = banded or block_banded
            block_unpaired = []
            for local_i, local_j in block_pairs:
                if local_j is None:
                    block_unpaired.append(i1 + local_i)
                else:
                    old_to_new[i1 + local_i] = j1 + local_j
                    new_to_old[j1 + local_j] = i1 + local_i
            _prefer_same_article(old_units, new_units, block_unpaired,
                                 range(j1, j2), old_to_new, new_to_old)
            unpaired.extend(block_unpaired)

    if banded:
        nt.notice(nt.REMINDER,
                  "改動的條很多（舊 %d 條、新 %d 條），條號對照改用帶狀對齊；"
                  "若有整章搬移，條層級的交叉引用判斷可能配錯，請人工核對"
                  % (len(old_units), len(new_units)), "Step 0.5")
    unpaired.sort()

    mapping = {}
    for i, (article, _body) in enumerate(old_units):
        j = old_to_new.get(i)
        mapping[article] = {"new": new_units[j][0] if j is not None else None,
                            "merged_into": None}

    # 配不到的再問一次：它是不是整段被搬進某一條新條裡（併條）。
    for i in unpaired:
        article, old_body = old_units[i]
        best_article, best = "", 0.0
        for j, (new_article, new_body) in enumerate(new_units):
            # 併進去的話新條一定至少跟舊條一樣長，短的直接跳過，省下大量比對
            if len(new_body) < len(old_body) * 0.9:
                continue
            # 而且併條的新條除了吃下這一條，自己原本的內容還在，所以一定比它
            # 配到的那條舊文長出一截。只看「像不像」的話，兩條碰巧寫得像的短條
            # （「甲事項規定如下。」對「乙事項規定如下。」）會被誤報成併條，
            # 真正被刪掉的那一條就沒有人去補「（刪除）」註記了。
            holder = new_to_old.get(j)
            grown = len(new_body) - (len(old_units[holder][1])
                                     if holder is not None else 0)
            if grown < len(old_body) * MERGE_COVERAGE:
                continue
            # 遞補時多寫幾句，新條也會長出一截；舊條獨有的字沒留下來就不是併進去的
            if holder is not None and _filled_by_holder(old_body, old_units[holder][1], new_body):
                continue
            score = _coverage(old_body, new_body)
            if score > best:
                best_article, best = new_article, score
        if best >= MERGE_COVERAGE:
            mapping[article]["merged_into"] = best_article
    return mapping


def find_changed_paragraphs(old_paragraphs, new_paragraphs,
                            old_kinds=None, new_kinds=None):
    """回傳「本次有改過」的新版段次集合（1 起算）。

    比的是去掉條號、正規化過的本體：條號本身會因為重編而變，那不算改內容。
    一段的本體在舊版裡找得到（不管在哪一段）就算沒改。

    用途是條層級引用的保險絲：重編之後，「作者已經改好的新號」跟「還沒改的舊號」
    在文字上一模一樣，程式分不出來。分不出來的時候唯一安全的說法是
    「這一段本次有改，你自己確認」，不能猜。
    """
    old_bodies = set()
    for text in old_paragraphs:
        old_bodies.add(normalize_for_compare(strip_article_no(text)))
    changed = set()
    for idx, text in enumerate(new_paragraphs, 1):
        if normalize_for_compare(strip_article_no(text)) not in old_bodies:
            changed.add(idx)
    return changed


# 「第○條　（刪除）」的條文本體：整條只剩刪除註記（括號裡可以帶日期，例如「（民國某年刪除）」）
_DELETED_MARK_RE = re.compile(
    r"^(?:[（(][^（()）]{0,30}刪除[^（()）]{0,10}[）)]|(?:本條)?(?:已)?刪除)[。．.]?$")


def marked_deleted_articles(paragraphs, kinds=None):
    """全文哪幾條已經寫成「第○條　（刪除）」：{正規化條號}。號碼還在，內容已經沒了。"""
    return set(normalize_article_no(article) for article, body in _article_texts(paragraphs, kinds)
               if _DELETED_MARK_RE.match(body.strip()))


def find_deleted_articles(old_paragraphs, new_paragraphs,
                          old_kinds=None, new_kinds=None, article_map=None):
    """
    比對新舊版，找出新版找不到的舊條號。

    回傳 [{"article": 舊條號, "status": "刪除"／"併入", "into": 新條號}]。

    條號預設不重編，所以刪掉之後新版會出現條號斷點。依法制慣例，
    真的刪掉應該保留條號並註記「第○條　（刪除）」，讓後面的條號維持不變。
    但「併入別條」不是刪除——補「（刪除）」註記反而是錯的，所以分開報。
    作者已經照慣例註記的不列：這裡是提醒補註記用的，再建議補一次一模一樣的字沒有意義。
    （引用那一條的地方照舊報危險，那一關看的是條號對照，不看這裡。）

    article_map 給了就直接用，省得同一次執行把條號對照算兩遍。
    """
    if article_map is None:
        article_map = plan_article_map(old_paragraphs, new_paragraphs,
                                       old_kinds, new_kinds)
    marked = marked_deleted_articles(new_paragraphs, new_kinds)
    result = []
    for article, info in article_map.items():
        if info["new"] is not None:
            continue
        if info["merged_into"]:
            item = {"article": article, "status": "併入", "into": info["merged_into"]}
            if normalize_article_no(article) in marked:
                item["marked"] = True     # 作者已經寫了（刪除），內容搬到別條：報告不能再叫人「不要補註記」
            result.append(item)
        elif normalize_article_no(article) not in marked:
            result.append({"article": article, "status": "刪除", "into": ""})
    return result


# ---------------------------------------------------------------------------
# 交叉引用
# ---------------------------------------------------------------------------

# ---------------------------------------------------------------------------
# 交叉引用解析
# ---------------------------------------------------------------------------
#
# 這一段是整支程式風險最高的地方。內規裡的引用寫法遠比「第五條第二款」複雜：
#
#     前條第三款及第四款      ← 「及第四款」的範圍要延續前面的「前條」
#     第五條第二款至第四款    ← 範圍寫法，實際指的是第二、三、四款
#     依前款規定              ← 相對引用，要看它自己在第幾款
#     前二項                  ← 往前數兩個
#     依第五條規定            ← 只到條層級
#
# 每一種漏掉，就是一處指錯的引用送進正式修法文件。所以這裡用逐字掃描配上
# 範圍狀態，而不是一條大正規表示式硬套。
#
# 判定結果分四種：
#     安全      引用的目標編號沒變
#     需改寫    目標還在、只是換號，機械式改寫是安全的
#     危險      目標已被刪除，沒有正確的改寫方式
#     無法判定  解析不出來（可能是原文寫法特殊，也可能本來就寫錯）
#
# 「無法判定」一定要列出來，不能默默跳過 —— 沉默才是最危險的結果。

# 相對引用的「前」要是一個詞的開頭：「目前項目」「當前條件」「先前款項」裡的「前項」
# 「前條」「前款」不是引用。以前沒有邊界，「目前項目」被當成「前項」，
# 還會拿它去算「本條的前一項」。「以前項規定」是「以 前項」，「以」不在排除之列。
_PREV = r"(?<![目當先事提日眼從空])前"

_TOKEN_RE = re.compile(
    r"(?P<article>第\s*[%(cn)s\d]+\s*條(?:\s*之\s*[%(cn)s\d]+)?)"
    r"|(?P<prev_article>%(prev)s\s*[%(cn)s]*\s*條)"
    r"|(?P<this_article>本條)"
    r"|(?P<para>第\s*[%(cn)s\d]+\s*項)"
    r"|(?P<prev_para>%(prev)s\s*[%(cn)s]*\s*項)"
    r"|(?P<clause>第\s*[%(cn)s\d]+\s*款)"
    r"|(?P<prev_clause>%(prev)s\s*[%(cn)s]*\s*款)"
    r"|(?P<all_clause>各\s*款)"
    r"|(?P<item>第\s*[%(cn)s\d]+\s*目)"
    r"|(?P<prev_item>%(prev)s\s*[%(cn)s]*\s*目)"
    r"|(?P<rangemark>至)"
    r"|(?P<conj>[及或與和、])"
    r"|(?P<stop>[。；：])" % {"cn": CN, "prev": _PREV})

_NUM_IN_TOKEN = re.compile(r"[%s\d]+" % CN)
# 引用鏈裡說不出是哪一個的上層（「前二項第一款」是哪一項、「第一款至第三款第二目」是哪一款）
_UNKNOWN_PARENT = object()
# 這幾種記號之後，引用鏈還接得下去；其他的（條、本條、句號…）都斷在那裡
_CHAIN_KINDS = ("conj", "rangemark", "para", "prev_para", "clause", "prev_clause", "item")
# 隔著修飾語（「第二項第一款規定及第三款」）時，下一個號碼不能比前一個低一層才算同一串：
# 「前項規定及第三款」的第三款是不是前項的看不出來，照舊算本段自己的（不猜）。
_UNIT_RANK = {"條": 0, "項": 1, "款": 2, "目": 3}
_TOKEN_UNIT = {"article": "條", "para": "項", "clause": "款", "item": "目", "all_clause": "款"}


def _filler_keeps_chain(text, end, unit):
    """引用鏈結束在 end（下一個字是修飾語），接下去的 unit（條／項／款／目）還算不算同一串。"""
    last = text[end - 1:end]
    return _UNIT_RANK[unit] <= _UNIT_RANK.get(last, 0)


def _token_number(token_text):
    """從「第十二款」這種字串裡取出數字。取不到回 None。"""
    match = _NUM_IN_TOKEN.search(token_text.replace("第", "").replace("前", ""))
    return cn_to_int(match.group(0)) if match else None


def _relative_offset(token_text):
    """「前款」指前面 1 個，「前二款」指前面 2 個（前兩款）。回傳往前涵蓋幾個。"""
    number = _token_number(token_text)
    return number if number else 1


def _relative_targets(base_no, token_text):
    """相對引用指到哪幾號：「前款」＝[base-1]，「前二款」＝[base-2, base-1]。數不到回 None。

    「前二款」「前二項」是「前兩款」「前兩項」，不是「往前數第二款」。以前解成往前數第二款
    一個號碼：「五、不符前二款規定者」被當成只引第三款，第四款被刪也不報（實測 R-M）。"""
    if not base_no:
        return None
    count = _relative_offset(token_text)
    if base_no - count < 1:          # 先看數不數得到再展開（打錯成「前三億款」不能先排出三億個號碼）
        return None
    return list(range(base_no - count, base_no))


# 「前條」後面緊接著第X項／款／目（或「各款」），範圍才延續給後面的引用；
# 沒接的話「前條」自己就是一個條層級引用（「違反前條規定者」）。
_CHAINED_AFTER_RE = re.compile(r"\s*(?:第\s*[%s\d]+\s*[項款目]|各\s*款)" % CN)


def parse_references(text, own_article, own_clause, previous_article,
                    own_para=None, skip_declaration=False, own_item=None, own_para_no=None,
                    previous_articles=None):
    """
    解析一段文字裡的所有條款目引用。

    own_article／own_clause／own_para：這一段自己所在的條、款、項，
    用來解析沒寫範圍的引用（例如條文裡直接寫「第三款」，指的就是本條第三款；
    「前項」指的是本條的前一項）。
    previous_article：這一段的「前條」是哪一條。
    previous_articles：這一段之前的各條（照全文順序，最近的在最後）；「前二條」要往前數兩條。
        沒給就只知道 previous_article 那一條。
    skip_declaration：這一段開頭的「第X條」是這一條的條號，不是引用。
        不跳過的話，條層級判定會把條文自己的條號當成要改寫的引用，
        --rewrite-refs 就會直接改掉條號本身。

    回傳引用清單，每筆含 span（在原文的起訖位置，供改寫用）、
    article（指向哪一條）、kind（款／目／項／條）、numbers（指向哪幾號）；
    external 有值代表那是外部法規的條號（例如「個人資料保護法第五條」），
    本程式不判也不改。
    """
    references = []
    scope_article = own_article
    # 引用鏈：「第二項第四款」「第二款第三目」——款跟在項後面、目跟在款後面時，
    # 指的是那一項的款、那一款的目，不是本段自己所在的（B1、B2）。
    # 「前項第二款」「前款第二目」也一樣，上層寫成相對的而已；
    # 連接詞不會把鏈切斷：「第二項第一款及第三款」的第三款也是第二項的。
    chain_end = None         # 這一串寫到原文哪裡；下一個記號要緊接著才算同一串
    chain_head = None        # 這一串從哪裡開始（報告要顯示完整的「第二項第一款」）
    chain_para = None        # 這一串明寫的項（號碼或 _UNKNOWN_PARENT）
    chain_clause = None      # 這一串的款：(號碼, 所屬項, 項是不是明寫的)，或 _UNKNOWN_PARENT
    scope_span = None        # 範圍前綴在原文的位置，例如「前條」「第五條」
    pending_range = None     # 緊接在前一個引用後面的「至」結束在哪裡
    last_reference = None
    last_article = None      # 上一個條層級引用：「第五條至第七條」要展開
    article_range = None     # (「至」前面的那一條, 「至」結束的位置)
    # 外部法規的引用鏈延伸到哪個位置：「個人資料保護法第五條第三款」的「第三款」
    # 緊接在後面，也是別人家的，不能拿本文的對照表去判。
    external_chain_end = None
    external_law = ""        # 引用鏈目前是哪一部外部法規（「管理規則第7條、第13條」的第13條也是它的）
    filled_end = None        # 剛跨過修飾語的話，修飾語前面那一串結束在哪（見 _filler_keeps_chain）
    # 範圍是不是「前條」給的：新舊版各推算一次時，「前條第二款」的前條也要照舊版重算
    scope_relative = False

    def chained_here(position, conj=False):
        # 連接詞前面可以夾引用的修飾語：「第二項第一款規定及第三款」的第三款也是第二項的
        if chain_end is None:
            return False
        gap = text[chain_end:position]
        return not gap.strip() or bool(conj and CITATION_FILLER_RE.match(gap))

    def after_range(position):
        return (pending_range is not None and last_reference is not None
                and not text[pending_range:position].strip())

    def display_quote(token_span):
        """
        報告裡要顯示的引用字句。

        span 只涵蓋號碼那一段（改寫時只能動那裡），但報告寫「引用『第二款』」
        會讓人看不出是哪一條的第二款。所以緊接在範圍前綴後面的引用，
        顯示時把前綴一起帶上，變成「前條第二款」。
        """
        if scope_span and scope_span[1] == token_span[0]:
            return text[scope_span[0]:token_span[1]]
        return text[token_span[0]:token_span[1]]

    for match in _TOKEN_RE.finditer(text):
        kind = match.lastgroup
        token = match.group(0)

        # 緊接在外部法規條號後面的款目（中間只隔連接詞），一律跟著算外部的。
        # 不是緊接著的就不算，否則「保險法第五條所定事項，第三款另有規定」這種
        # 後半句其實是本文自己的引用，會被整句跳過不檢查。
        # 「保險法第一條規定及第四條」：連接詞前面可以夾引用的修飾語（CITATION_FILLER），後面的條號還是
        # 別人家的。以前「規定」就把鏈切斷，第四條被當成本文自己的條去判，指得到就沒事、指不到就報危險。
        filled, filled_end = filled_end, None
        chained = external_chain_end is not None and match.start() == external_chain_end
        if chained and filled is not None and kind in _TOKEN_UNIT:
            chained = _filler_keeps_chain(text, filled, _TOKEN_UNIT[kind])
        if (external_chain_end is not None and not chained and kind == "conj"
                and match.start() != external_chain_end
                and CITATION_FILLER_RE.match(text[external_chain_end:match.start()])):
            chained, filled_end = True, external_chain_end
        if chained and kind in ("clause", "item", "para", "conj", "rangemark", "all_clause"):
            external_chain_end = match.end()
            continue
        if kind != "article":
            external_chain_end = None
        if kind not in _CHAIN_KINDS:
            chain_end = chain_para = chain_clause = None

        if kind == "stop":
            # 句子結束，範圍重設回本條，「及」的延續也中斷
            scope_article = own_article
            scope_span = None
            scope_relative = False
            pending_range = None
            last_reference = None
            continue

        if kind == "conj":
            # 「及」「或」「、」本身不重設範圍，讓後面的「第四款」延用前面的條；
            # 緊接著的話項與款也延用（中間隔了別的字就不算，那已經不是同一串）
            if chained_here(match.start(), conj=True):
                if text[chain_end:match.start()].strip():
                    filled_end = chain_end
                chain_end, chain_head = match.end(), None
            else:
                chain_end = chain_para = chain_clause = None
            continue

        if kind == "rangemark":
            # 只有緊接在引用後面的「至」才是範圍。「依第二款規定送至主管機關，第四款…」的
            # 「至」跟款號無關，以前照樣把第二款到第四款併成一個範圍
            pending_range = None
            if last_reference and not text[last_reference["span"][1]:match.start()].strip():
                pending_range = match.end()
            if last_article and not text[last_article["span"][1]:match.start()].strip():
                article_range = (last_article, match.end())
            if chained_here(match.start()):
                chain_end, chain_head = match.end(), None
            continue

        if kind == "article":
            # 「管理規則第7條、第11條之1、第13條及第19條第1項」：法規名稱只緊貼在第一個條號前面，
            # 用「、」「及」「或」接下去的條號也是同一部的。以前只看緊貼的名稱，後面幾條被當成
            # 本規章的條號，報「第19條在新版中不存在」的危險（真資料：保險代理業務手冊）
            law = is_external_reference(text, match.span()) or (external_law if chained else "")
            if law:
                external_law = law
                # 別人家的法條。記一筆讓報告看得到，但不判、不改；
                # 範圍也不能留給它，否則後面沒帶條號的「第三款」會被算到它頭上。
                references.append({
                    "span": match.span(), "raw": display_quote(match.span()),
                    "token": token, "article": re.sub(r"\s+", "", token),
                    "kind": "條", "numbers": None, "is_range": False,
                    "external": law,
                })
                scope_article = own_article
                scope_span = None
                scope_relative = False
                external_chain_end = match.end()
                last_reference = last_article = article_range = None
                continue

            external_chain_end = None
            scope_article = re.sub(r"\s+", "", token)
            scope_span = match.span()
            scope_relative = False
            if skip_declaration and not text[:match.start()].strip():
                # 段落開頭的「第七條」是這一條的條號，不是引用
                scope_span = None
                last_reference = last_article = article_range = None
                continue
            # 條層級的引用本身也要記一筆。「本公司得依第五條規定辦理」這種
            # 沒帶款目的引用，只要第五條被整條刪掉就會指空，不能漏掉。
            reference = {
                "span": match.span(), "raw": token, "article": scope_article,
                "kind": "條", "numbers": None, "is_range": False,
            }
            references.append(reference)
            if article_range and not text[article_range[1]:match.start()].strip():
                # 「第五條至第七條」：兩端各記一筆（照常判，也照常改寫），夾在中間的另記一筆，
                # 位置放在兩端之間。中間的第六條被刪、條號不遞補時兩端都還在，少記這一筆
                # 就沒有任何一關會講。條號可能有「之一」，數不出來，要到判的時候照舊版的條找
                first = article_range[0]
                references.append({
                    "span": (first["span"][1], match.start()),
                    "raw": text[first["span"][0]:match.end()],
                    "article": first["article"], "kind": "條", "numbers": None, "is_range": True,
                    "range_inner": (first["article"], scope_article), "own_article": own_article,
                    "full_span": (first["span"][0], match.end()),
                })
            article_range = None
            last_article = reference
            last_reference = None
            continue

        if kind == "prev_article":
            offset = _relative_offset(token)
            scope_article = previous_article if offset == 1 else ""
            scope_span = match.span()
            scope_relative = True
            last_reference = last_article = None
            if not _CHAINED_AFTER_RE.match(text, match.end()):
                # 單獨寫的「前條」「前二條」本身就是條層級引用。以前這裡只設範圍、不記引用：
                # 「違反前條規定者」的前一條被刪、或中間插進一條，前條改指別條也沒有人講（C7b、C9）。
                chain = list(previous_articles if previous_articles is not None
                             else ([previous_article] if previous_article else []))
                targets = chain[-offset:] if len(chain) >= offset else None
                references.append({
                    "span": match.span(), "raw": token, "token": token,
                    "article": targets[-1] if targets else "", "kind": "條",
                    "numbers": None, "is_range": offset > 1, "relative": True,
                    "offset": offset, "targets": targets, "own_article": own_article,
                    "note": "" if targets else
                            "往前數不到%d條，解析不出「%s」指的是哪一條" % (offset, token),
                })
            continue

        if kind == "this_article":
            scope_article = own_article
            scope_span = match.span()
            scope_relative = False
            last_reference = None
            continue

        if kind in ("para", "prev_para"):
            # 項不像款目那樣把編號寫在文字裡，所以沒有「重編」可言；
            # 但它一樣會出事——刪掉一個項，後面的項次全部往前移，
            # 「前項」「第二項」就指到別的東西了。
            #
            # 早期版本這裡直接 continue，等於靜默略過，違反本程式的原則
            # （解析不出來也要列出來，沉默才是最危險的結果）。現在照樣產生
            # 引用記錄，交給 _judge 與 scan_reference_drift 判斷。
            if kind == "prev_para":
                offset = _relative_offset(token)
                targets = _relative_targets(own_para, token)
                if targets:
                    note, hint = "", None
                elif own_para:
                    # 知道自己是第幾項，卻算出往前指到第 0 項或更前面，
                    # 那就是明確的錯：本條第一項前面沒有項可以指。
                    if own_para == 1:
                        note = ("這一段是本條的第一項，前面沒有項可以指，"
                                "「%s」指不到東西" % token)
                    else:
                        note = ("這一段是本條的第 %d 項，前面只有 %d 項，"
                                "「%s」要再往前數 %d 項，指不到東西"
                                % (own_para, own_para - 1, token, offset))
                    hint = "危險"
                else:
                    note = ("這一段本身不在任何條的項次之內，"
                            "解析不出「%s」指的是哪一項" % token)
                    hint = None
                references.append({
                    "span": match.span(), "raw": display_quote(match.span()),
                    "token": token, "article": scope_article, "kind": "項",
                    "numbers": targets, "is_range": bool(targets and len(targets) > 1),
                    "relative": True, "offset": offset, "own_no": own_para,
                    "own_article": own_article,
                    "note": note, "status_hint": hint,
                })
                last_reference = None
                # 「前項第二款」的款是前項的；「前二項第二款」是哪一項說不出來
                chain_para = targets[0] if targets and len(targets) == 1 else _UNKNOWN_PARENT
                chain_head = match.start()
            else:
                number = _token_number(token)
                if number and after_range(match.start()) and last_reference["kind"] == "項":
                    # 「第二項至第四項」跟款一樣展開：夾在中間的第三項被刪也要算到
                    _merge_range(last_reference, number, match, text)
                    chain_para = _UNKNOWN_PARENT
                    chain_end = match.end()
                    pending_range = None
                    continue
                reference = {
                    "span": match.span(), "raw": display_quote(match.span()),
                    "token": token, "article": scope_article, "kind": "項",
                    "numbers": [number] if number else None,
                    "note": "" if number else "解析不出項次",
                    "own_article": own_article, "scope_relative": scope_relative,
                    "scope_span": scope_span,
                }
                references.append(reference)
                last_reference = reference if number else None
                chain_para = number or None
                chain_head = (scope_span[0] if scope_span and scope_span[1] == match.start()
                              else match.start())
            chain_clause = None
            chain_end = match.end() if chain_para is not None else None
            pending_range = None
            continue

        if kind == "all_clause":
            references.append({
                "span": match.span(), "raw": token, "article": scope_article,
                "kind": "款", "numbers": None, "note": "「各款」指全部，重編不影響",
            })
            last_reference = None
            continue

        if kind in ("clause", "item"):
            unit = "款" if kind == "clause" else "目"
            number = _token_number(token)
            alive = chained_here(match.start()) and (filled is None or _filler_keeps_chain(text, filled, unit))
            if number is None:
                # 項解析不出來會記一筆，款、目也一樣：沉默才是最危險的結果
                references.append({
                    "span": match.span(), "raw": display_quote(match.span()), "token": token,
                    "article": scope_article, "kind": unit, "numbers": None,
                    "note": "解析不出這個%s的號碼，請人工確認" % unit, "own_article": own_article,
                })
                last_reference = chain_end = chain_para = chain_clause = pending_range = None
                continue

            if after_range(match.start()) and last_reference["kind"] == unit:
                # 「第二款至第四款」：把範圍展開成 2、3、4，並把兩端合併成一筆
                _merge_range(last_reference, number, match, text)
                pending_range = None
                chain_end = match.end()
                if unit == "款":
                    chain_clause = _UNKNOWN_PARENT   # 範圍後面再接目，說不出是哪一款的目
                continue

            if not alive:
                chain_para = chain_clause = None
                chain_head = (scope_span[0] if scope_span and scope_span[1] == match.start()
                              else match.start())
            para, explicit = None, False
            clause_of = None
            unknown = ""
            if unit == "目" and chain_clause is not None:
                if chain_clause is _UNKNOWN_PARENT:
                    unknown = "款"
                else:
                    clause_of, para, explicit = chain_clause
            elif chain_para is not None:
                if chain_para is _UNKNOWN_PARENT:
                    unknown = "項"
                else:
                    para, explicit = chain_para, True
            if para is None and scope_article == own_article:
                para = own_para_no or own_para       # 沒寫項：本條就是本段所在的那一項
            reference = {
                "para": para, "para_explicit": explicit,
                "clause": clause_of if unit == "目" else None,
                # span 只涵蓋號碼那一段，改寫時只能動這裡；
                # raw 是報告要顯示的字句，會把「前條」「第五條」這種前綴帶上；
                # token 是純號碼字串，改寫時拿它去換，不能用 raw，
                # 否則「第五條第四款」會被改成「第五條第五條第三款」。
                "span": match.span(), "raw": display_quote(match.span()),
                "token": token, "article": scope_article,
                "kind": unit, "numbers": [number], "is_range": False,
                "own_article": own_article, "scope_relative": scope_relative,
                "scope_span": scope_span,
                "chain_start": match.start() if chain_head is None else chain_head,
            }
            if unknown:
                # 不能照本段自己的項、款去對：那是猜，猜錯就是把指空的引用判成安全
                reference.update(numbers=None, note="「%s」前面的%s不是確定的一個，解析不出這裡是哪一%s底下的%s"
                                                    % (text[reference["chain_start"]:match.end()], unknown,
                                                       unknown, unit))
            references.append(reference)
            last_reference = None if unknown else reference
            pending_range = None
            chain_end = match.end()
            if unit == "款":
                chain_clause = _UNKNOWN_PARENT if unknown else (number, para, explicit)
            continue

        if kind in ("prev_clause", "prev_item"):
            unit = "款" if kind == "prev_clause" else "目"
            offset = _relative_offset(token)
            # 「前目」往前數的是本段自己的目號，不是所在的款號（B2）
            base_no = own_clause if unit == "款" else own_item
            chain_para = None
            chain_end, chain_head = None, None
            if unit == "款":
                # 「前款第二目」的目是前款的；「前二款第二目」是哪一款說不出來
                targets = _relative_targets(base_no, token) if base_no else None
                chain_clause = ((targets[0], own_para_no or own_para, False)
                                if targets and len(targets) == 1 else _UNKNOWN_PARENT)
                chain_end, chain_head = match.end(), match.start()
            if base_no is None:
                references.append({
                    "span": match.span(), "raw": token, "article": scope_article,
                    "kind": unit, "numbers": None,
                    "note": "這一段本身不在任何%s之下，解析不出「%s」指的是哪一%s"
                            % (unit, token, unit),
                })
            else:
                targets = _relative_targets(base_no, token)
                references.append({
                    "span": match.span(), "raw": token, "token": token, "article": scope_article,
                    "kind": unit, "para": own_para_no or own_para, "para_explicit": False,
                    "clause": own_clause if unit == "目" else None,
                    "numbers": targets, "is_range": bool(targets and len(targets) > 1),
                    "relative": True, "offset": offset, "own_no": base_no,
                    "own_article": own_article,
                    "note": "" if targets else "「%s」往前數超出範圍" % token,
                })
            last_reference = None
            continue

    return references


# 範圍最多展開幾個號碼。一條底下的項、款、目不會上千，超過多半是號碼打錯（「第二款至第2000000款」）；
# 照展開會把記憶體吃光（3 億個號碼實測超過 6 GB）。
RANGE_EXPAND_LIMIT = 1000


def _merge_range(reference, number, match, text):
    """「第二款至第四款」：把範圍展開成 2、3、4，後一端併進前一筆。
    跨太多號碼的不展開：numbers 留 None、寫 note，跟解析不出來的引用一樣列給人確認。"""
    numbers = reference.get("numbers")
    reference["span"] = (reference["span"][0], match.span()[1])
    reference["raw"] = text[reference["span"][0]:reference["span"][1]]
    reference["is_range"] = True
    reference["end_token"] = match.group(0)
    if numbers and abs(number - numbers[0]) < RANGE_EXPAND_LIMIT:
        reference["numbers"] = list(range(min(numbers[0], number), max(numbers[0], number) + 1))
    else:
        reference["numbers"] = None
        reference["note"] = "「%s」這個範圍跨太多號碼（超過 %d 個），多半是號碼打錯，程式沒有展開，請人工確認" % (
            reference["raw"], RANGE_EXPAND_LIMIT)


# ---------------------------------------------------------------------------
# 手冊（沒有「第X條」）裡的相對引用：前款、本項第2至第5款、本節第一條第(二)項、第十款第一目
# ---------------------------------------------------------------------------
# 手冊的層級是 章 → 節 → 款「一、」→ 目「(一)」→ 點「1、」→「(1)」，可是寫的人引用時用字常常跟這個
# 層級對不上（實測：同一本裡「本項第2至第5款」的項是目、款是點；「經前款檢核作業」的款是目；
# 「本節第一條第(二)項」的條是款、項是目）。程式以前只會在「條」裡面找項、款、目，手冊一律解析不出來，
# 全部丟給人。現在照這一段在手冊裡的位置去找：用字跟層級對得上而且找得到的直接算對；
# 對不上的把寫的人可能指的每一層都試一遍，只有一種找得到就寫「可能是指 X」（推測），都找不到
# 或好幾種都找得到才要人確認。

OUTLINE_LEVELS = ("章", "節", "款", "目", "點", "小點")
# 寫的人用的字 → 手冊裡可能是哪一層
_OUTLINE_TERM_LEVELS = {"章": ("章",), "節": ("節",), "條": ("款",), "項": ("目", "點", "款"),
                        "款": ("款", "目", "點"), "目": ("目", "點"), "點": ("點", "小點")}
_OUTLINE_PATH_RE = re.compile(r"第\s*([%s\d０-９]+)\s*(章|節|款|目|點)" % CN)
_OUTLINE_SUBPOINT_RE = re.compile(r"[（(]\s*(\d+)\s*[）)]\s*$")
_ONUM = r"[（(]?\s*[%s\d０-９]+\s*[）)]?" % CN
_OUTLINE_UNIT = r"第\s*%s\s*(?:至\s*第?\s*%s\s*)?[章節條項款目點]" % (_ONUM, _ONUM)
_OUTLINE_REF_RE = re.compile(
    r"(?P<scope>本[章節條項款目點])?(?P<chain>(?:%s)+)"
    r"|%s\s*(?P<count>[%s]*)\s*(?P<prev>[項款目點])" % (_OUTLINE_UNIT, _PREV, CN))
_OUTLINE_UNIT_RE = re.compile(
    r"第\s*(%s)\s*(?:至\s*第?\s*(%s)\s*)?([章節條項款目點])" % (_ONUM, _ONUM))
# 緊接在法規名稱、書名號後面的（「注意事項第6點」「」第三點」）是在引外部規定，不是手冊自己的
_OUTLINE_LAW_BEFORE_RE = re.compile(
    r"(?:」|』|法|條例|辦法|準則|規則|細則|要點|規範|注意事項|範本|須知|手冊|原則|指引|規定)\s*$")
# 外部法規條號後面接著的條、款、項（「管理規則第7條、第13條及第19條第1項各款」）都還是那一部的
_EXTERNAL_TAIL_RE = re.compile(
    r"\s*(?:(?:[、及或與和至]\s*)?(?:第\s*%(num)s\s*(?:條(?:\s*之\s*[%(cn)s\d]+)?|[項款目])|各\s*款)"
    r"|%(filler)s\s*[、及或與和]\s*第\s*%(num)s\s*條(?:\s*之\s*[%(cn)s\d]+)?)"
    % {"num": _ONUM, "cn": CN, "filler": CITATION_FILLER})


def _outline_num(text):
    digits = re.sub(r"[（()）\s]", "", text or "")
    digits = digits.translate(str.maketrans("０１２３４５６７８９", "0123456789"))
    return int(digits) if digits.isdigit() else cn_to_int(digits)


def outline_path(context):
    """build_hierarchy 的一段 → 它在手冊裡的位置 (("章",6),("節",4),("款",10),("目",1),…)。

    ref 的寫法有兩種：Word 檔是「第六章第四節第十款第一目第1點(2)（第2組）」；純文字的手冊
    「一、」會寫成「第一點」、前面也不帶章節（「第一點第一目第1點」）。章、節從 chapter／section 補；
    節以下的層級名稱前後不合理（點底下又有目）時，照深淺依序當成款、目、點、小點。"""
    ref = re.sub(r"（第\d+組）$", "", context.get("ref") or "")
    path = [(level, _outline_num(number)) for number, level in _OUTLINE_PATH_RE.findall(ref)]
    sub = _OUTLINE_SUBPOINT_RE.search(ref)
    if sub and path:
        path.append(("小點", int(sub.group(1))))
    path = [(level, number) for level, number in path if number]
    head = [p for p in path if p[0] in ("章", "節")]
    rest = [p for p in path if p[0] not in ("章", "節")]
    if not any(p[0] == "章" for p in head) and context.get("chapter"):
        head.insert(0, ("章", _outline_num(_OUTLINE_PATH_RE.findall(context["chapter"])[0][0])
                        if _OUTLINE_PATH_RE.findall(context["chapter"]) else 0))
    if not any(p[0] == "節" for p in head) and context.get("section"):
        found = _OUTLINE_PATH_RE.findall(context["section"])
        head.append(("節", _outline_num(found[-1][0]) if found else 0))
    ranks = [_level_rank(level) for level, _n in rest]
    if ranks != sorted(set(ranks)) or len(ranks) != len(set(ranks)):
        rest = [(OUTLINE_LEVELS[2 + i], n) for i, (_level, n) in enumerate(rest[:4])]
    return tuple(p for p in head + rest if p[1])


def outline_index(contexts):
    """手冊每一個存在的位置 → 第一次出現的段次（含所有上層：有「第十款第一目」就也有「第十款」）。"""
    found = {}
    for idx, context in enumerate(contexts, 1):
        path = outline_path(context)
        for depth in range(1, len(path) + 1):
            found.setdefault(path[:depth], idx)
    return found


def outline_text(path, last_numbers=None):
    """位置寫成人看得懂的字：第四章第一節第二款第一目第2至5點。"""
    def num(level, n):
        return str(n) if level in ("點", "小點") else cn_from_int(n)

    parts = []
    for i, (level, number) in enumerate(path):
        numbers = last_numbers if (i == len(path) - 1 and last_numbers) else [number]
        shown = num(level, numbers[0]) if len(numbers) == 1 else \
            "%s至%s" % (num(level, numbers[0]), num(level, numbers[-1]))
        parts.append("(%s)" % shown if level == "小點" else "第%s%s" % (shown, level))
    return "".join(parts)


def _level_rank(level):
    return OUTLINE_LEVELS.index(level)


def _outline_chain_units(chain):
    """「第2至第5款」「第十款第一目」「第一條第(二)項」→ [(用字, [號碼…]), …]。"""
    units = []
    for start, end, term in _OUTLINE_UNIT_RE.findall(chain):
        first = _outline_num(start)
        last = _outline_num(end) if end else first
        if not first or not last or last < first or last - first > 30:
            return []
        units.append((term, list(range(first, last + 1))))
    return units


def _outline_targets(base, units, index):
    """從 base 往下照 units 一層一層找；每一種「用字 → 層級」的對法都試。回傳 [(層級組合, 目標位置們)]。"""
    results = []

    def walk(prefix, rest, levels):
        if not rest:
            return
        term, numbers = rest[0]
        floor = _level_rank(prefix[-1][0]) if prefix else -1
        for level in _OUTLINE_TERM_LEVELS.get(term, ()):
            if _level_rank(level) <= floor:
                continue
            if len(rest) == 1:
                targets = [prefix + ((level, n),) for n in numbers]
                if all(t in index for t in targets):
                    results.append((levels + (level,), targets))
            elif len(numbers) == 1 and prefix + ((level, numbers[0]),) in index:
                walk(prefix + ((level, numbers[0]),), rest[1:], levels + (level,))

    walk(base, units, ())
    return results


def _outline_prev(own, term, count, index):
    """「前款」「前二項」：在自己所在的各層裡，取最靠近自己、往前數得到的那一層。"""
    levels = _OUTLINE_TERM_LEVELS.get(term, ())
    for depth in range(len(own), 0, -1):
        level, number = own[depth - 1]
        if level not in levels or number <= count:
            continue
        targets = [own[:depth - 1] + ((level, number - k),) for k in range(count, 0, -1)]
        if all(t in index for t in targets):
            return level, targets
    return None


def _outline_external_regions(text, references):
    """外部法規條號連同後面接著的條、款、項，整段都不是手冊自己的引用。"""
    regions = []
    for reference in references:
        if not reference.get("external"):
            continue
        start, end = reference["span"]
        while True:
            more = _EXTERNAL_TAIL_RE.match(text, end)
            if not more or more.end() == end:
                break
            end = more.end()
        regions.append((start, end))
    return regions


# 手冊表格裡照抄的法條：「「保險代理人管理規則」第34條」一格是那一條的開頭，接下來的格是條文
# （第1項、第2項…；「一、要保書」是款；「明定…」「應訂定…」是旁邊說明欄的字）。這一條裡的
# 「前項」「第一項」指的是同一條的項（第76段「前項」＝第75段），跟手冊的章節款目無關：
# 照該條的項次對，對得上、對不上都不列（那是別部法規自己的事），只是不能再拿手冊的層級去猜。
_QUOTED_HEADER_RE = re.compile(
    r"^\s*「?([^「」\s]{2,60}?(?:法|條例|辦法|準則|規則|細則|要點|規範|注意事項|範本))」?\s*"
    r"第\s*[%s\d０-９]+(?:\s*[-－之]\s*[%s\d０-９]+)?\s*條\s*$" % (CN, CN))
_QUOTED_NOT_ITEM_RE = re.compile(
    r"^\s*(?:[%s]+\s*、|[（(]\s*[%s\d]+\s*[）)]|\d+\s*[、.．]|明定|規範|應訂定|本行)" % (CN, CN))


def quoted_law_blocks(paragraphs, kinds):
    """{段次: {"law": 法規名, "items": [這一條第1項、第2項…的段次]}}，只算表格儲存格裡的。"""
    blocks, current = {}, None
    for idx, text in enumerate(paragraphs, 1):
        kind = kinds[idx - 1] if kinds and idx - 1 < len(kinds) else ""
        if kind != "cell":
            current = None
            continue
        header = _QUOTED_HEADER_RE.match(text or "")
        if header:
            current = {"law": header.group(1), "items": []}
            continue
        if current is None:
            continue
        blocks[idx] = current
        if not _QUOTED_NOT_ITEM_RE.match(text or ""):
            current["items"].append(idx)
    return blocks


def outline_reference_findings(text, idx, context, index, references, quoted=None):
    """一段手冊文字裡的相對引用（見本節開頭）。回傳 (發現, 已處理的位置)：
    發現的 status 是「推測」（只有一種對得上，note 寫可能指哪裡）或「無法判定」；
    用字跟層級一致而且找得到的不列。已處理的位置讓呼叫端不要再用條文那一套判一次。
    quoted：這一段在表格裡照抄的法條中（見 quoted_law_blocks）：項、款、目是那一條的，不拿手冊的層級猜。"""
    own = outline_path(context)
    regions = _outline_external_regions(text, references)
    findings, covered = [], []
    for match in _OUTLINE_REF_RE.finditer(text):
        span = match.span()
        if quoted is not None and not match.group("scope"):
            covered.append(span)          # 照抄法條裡的項款目：該條自己的（第76段「前項」＝第75段）
            continue
        if any(start <= span[0] < end for start, end in regions):
            continue
        quote = match.group(0)
        if match.group("prev"):
            term = match.group("prev")
            count = cn_to_int(match.group("count")) if match.group("count") else 1
            hit = _outline_prev(own, term, count or 1, index)
            covered.append(span)
            # 往前數找不到的不列：手冊裡這種多半是照抄別部法規的條文（「十八、未依第十五條…」
            # 後面接「前項…」），以前也是當成引述別部法規，不叫人確認
            if hit and hit[0] != term:
                level, targets = hit
                findings.append(_outline_guess(idx, text, quote, span, term, (level,), targets, index))
            continue
        units = _outline_chain_units(match.group("chain"))
        if not units:
            continue
        scope = match.group("scope")
        if not scope and units[0][0] in ("條", "項", "章", "節"):
            # 沒有「本節」「本章」開頭的「第三十三條第一項」：手冊沒有條，多半是在照抄別部法規，
            # 交給條文那一套（記成引述別部法規）；「本節第一條」才是手冊自己的。
            # 「第一節」「第一章第二節」交給章節引用那一套（scan_outline_references，目錄行它會略過）
            continue
        if not scope and _OUTLINE_LAW_BEFORE_RE.search(text[:span[0]]):
            covered.append(span)          # 「注意事項第6點」：外部規定的點次，不是手冊的
            continue
        options = []
        if scope:
            # 「本項」「本款」從最靠近自己的那一層往上找，先找到的就是（「本項第2至第5款」＝
            # 自己所在的(一)底下的第2至5點，不是上一層款底下的第二至五目）
            levels = _OUTLINE_TERM_LEVELS.get(scope[1:], ())
            if scope == "本點":
                # 「一、」底下有 (一) 時，outline_path 把這一層排成款（點要留給更下層的「1.」），
                # 寫的人照樣叫它本點；只認點的話，「本點第一目」找不到自己所在的那一點
                levels += ("款",)
            for depth in range(len(own), 0, -1):
                if own[depth - 1][0] in levels:
                    options = _outline_targets(own[:depth], units, index)
                    if options:
                        break
        else:
            for level in _OUTLINE_TERM_LEVELS.get(units[0][0], ()):
                base = tuple(p for p in own if _level_rank(p[0]) < _level_rank(level))
                for levels, targets in _outline_targets(base, units, index):
                    if targets not in [t for _l, t in options]:
                        options.append((levels, targets))
        covered.append(span)
        if not options and not scope:
            continue                      # 沒寫「本X」、手冊裡也找不到：多半是外部規定的款目點，不判
        terms = tuple(term for term, _numbers in units)
        exact = [o for o in options if o[0] == terms]
        if exact:
            continue
        if len(options) == 1:
            levels, targets = options[0]
            findings.append(_outline_guess(idx, text, quote, span, "".join(terms), levels, targets, index))
        elif options:
            shown = "、".join(_outline_target_text(t, index) for _levels, t in options[:4])
            findings.append(_outline_unresolved(idx, text, quote, span, options,
                                                "「%s」可能指好幾個地方：%s，請人工確認" % (quote, shown)))
        else:
            findings.append(_outline_unresolved(idx, text, quote, span, [],
                                                "在本手冊找不到「%s」可能指的地方" % quote))
    unique, seen = [], set()
    for finding in findings:           # 同一段寫了兩次「前項」：講一次就好
        key = (finding["quote"], finding["note"])
        if key not in seen:
            seen.add(key)
            unique.append(finding)
    return unique, covered


def _outline_target_text(targets, index):
    numbers = [t[-1][1] for t in targets]
    where = outline_text(targets[0], numbers if len(numbers) > 1 else None)
    lines = sorted(index[t] for t in targets)
    return "%s（第%s段）" % (where, lines[0] if len(lines) == 1 else "%d～%d" % (lines[0], lines[-1]))


def _outline_guess(idx, text, quote, span, written, levels, targets, index):
    mismatch = "、".join("「%s」" % level for level in dict.fromkeys(levels))
    note = "可能是指%s（本手冊這一層叫%s，原文寫「%s」）" % (
        _outline_target_text(targets, index), mismatch, quote)
    return {"index": idx, "text": text, "quote": quote, "article": "", "kind": "目",
            "external": "", "span": span, "status": "推測", "note": note,
            "target_lines": sorted(index[t] for t in targets)}


def _outline_unresolved(idx, text, quote, span, options, note):
    return {"index": idx, "text": text, "quote": quote, "article": "", "kind": "目",
            "external": "", "span": span, "status": "無法判定", "note": note}


def scan_references(paragraphs, entries, clause_map, item_map,
                    known_articles=None, articles_with_clauses=None,
                    kinds=None, article_map=None, changed_paragraphs=None,
                    old_paragraphs=None, old_kinds=None):
    """
    掃描全文的交叉引用，判斷它們會不會因為重編而指錯。

    clause_map／item_map 是 plan_renumber() 算出來的「舊號 → 新號」對照。
    known_articles 是全文實際存在的條號集合，用來抓出指向不存在條號的引用。
    article_map 是 plan_article_map() 算出來的「舊條號 → 新條號」對照；
    沒給就代表沒有舊版可比對，條層級一律不下結論（報告印「未檢查」），
    絕對不可以因此印「沒有受影響」。
    changed_paragraphs 是 find_changed_paragraphs() 算出來的「本次有改過」段次，
    用來把「這一段自己也被改過」的條層級引用降級成危險（見 _judge）。
    old_paragraphs／old_kinds：舊版全文。給了（而且有 article_map）就再做一次「新舊版各推算一次」：
    同一段在舊版找回原本那一段，相對引用（前項、前X款）與款、項號各自推算指到誰，經條號對照
    比較（見 cross_version_references）。沒給就只看新版，跟以前一樣。
    """
    contexts = build_hierarchy(paragraphs, kinds)
    entry_by_index = {e["index"]: e for e in entries}
    if articles_with_clauses is None:
        articles_with_clauses = {e["article"] for e in entries
                                 if e["level"] == "款" and e["article"]}

    # 每一條有幾項，用來判斷「第三項」這種引用指不指得到
    para_counts = {}
    for context in contexts:
        if context["level"] in ("條", "項") and context["article"]:
            ordinal = _paragraph_ordinal(context) or 1
            key = context["article"]
            para_counts[key] = max(para_counts.get(key, 0), ordinal)

    cross = None
    if old_paragraphs is not None and article_map:
        cross = cross_version_references(old_paragraphs, paragraphs, old_kinds, kinds,
                                         article_map=article_map)

    findings = []
    # 整份沒有「第X條」（手冊）：款、目、項的相對引用改照手冊的章節款目去找（見 outline_reference_findings）
    outline = outline_index(contexts) if known_articles is not None and not known_articles else None
    quoted = quoted_law_blocks(paragraphs, kinds) if outline is not None else {}

    for idx, (text, context) in enumerate(zip(paragraphs, contexts), 1):
        entry = entry_by_index.get(idx, {})
        own_clause = entry.get("clause_written")
        references = _paragraph_references(text, context, entry, contexts, idx)
        if outline is not None:
            # 「第一章第一節第二款及第三款」整串由章節引用那一關判，這裡再判一次只會說「解析不出」
            chained = _outline_point_spans(text)
            references = [r for r in references if r.get("external") or not any(
                start <= r["span"][0] < end for start, end in chained)]
            handled, covered = outline_reference_findings(text, idx, context, outline, references,
                                                          quoted=quoted.get(idx))
            findings.extend(handled)
            references = [r for r in references if r.get("external") or not any(
                start <= r["span"][0] < end for start, end in covered)]

        for reference in references:
            finding = _judge(reference, text, idx, clause_map, item_map,
                             own_clause, known_articles, articles_with_clauses,
                             para_counts, article_map, changed_paragraphs)
            if cross is not None:
                key = (idx, tuple(reference["span"]))
                if key in cross["verdicts"]:
                    finding = _merge_cross(finding, cross["verdicts"][key])
                if finding and reference.get("relative") and idx in cross["added"]:
                    # 新版才有的段落：「前條」「前項」是照新版寫的，沒有「舊版指誰」可比
                    # （條層級那支保險絲把新增段落也算成「本次有改」，會誤報成危險）
                    if finding.get("note", "").startswith("危險（引用所在段落本次有改"):
                        finding = None
                if (finding and not finding.get("cross")
                        and finding.get("status") in ("危險", "無法判定")
                        and cross["old_status"].get(key) == finding["status"]):
                    # 舊版同一處就是一樣的問題（例：「前項」寫在本條第一項）：不是這次改出來的，
                    # 照列，但不進連帶決定表、提醒併成一則（大型內規實測 40 列都是這種）
                    # 同一個號碼在各項、各組換成幾號，這次變了就不是「舊版就這樣」：
                    # 兩項都有第三款、其中一項換了號，引用可能已經指錯，要有人看
                    if cross["old_hits"].get(key) == _reference_hits(clause_map, item_map, reference, own_clause):
                        finding = dict(finding, pre_existing=True,
                                       note=finding.get("note", "") + "（舊版同一處就是這樣，不是這次改出來的）")
                if finding and finding.get("range_added") and idx in cross["added"]:
                    finding = None    # 這一段是新版才寫的，範圍本來就是照新版的條寫的
            if finding:
                findings.append(finding)

    return findings


def _paragraph_references(text, context, entry, contexts, idx):
    """一段裡的引用。scan_references 與新舊版各推算一次共用，兩邊的解析才一模一樣。"""
    # own_para（這一段是所在條的第幾項）：條文本體與項照層級脈絡算；款、目、點是它所在的那一項
    # （「一、前項所定文件」的前項是本項的前一項，以前一律「解析不出」）。
    # 表格儲存格裡的段落層級是「其他」，ref 卻沿用所在條——照樣傳 own_para 的話，
    # 格內的「前項」會被當成「本條第一項的前項」，判成「前面沒有項可以指」的危險
    # （實測 no 23）。那一格根本不在條的項次結構裡，傳 None 走「解析不出」那一支。
    if context["level"] in ("條", "項"):
        own_para = _paragraph_ordinal(context)
    elif context["level"] in ("款", "目", "點") and context.get("article"):
        own_para = entry.get("paragraph_no")
    else:
        own_para = None
    previous = _previous_articles_of(contexts, idx)
    return parse_references(
        text, context["article"], entry.get("clause_written"),
        previous[-1] if previous else "",
        own_para=own_para,
        skip_declaration=(context["level"] == "條"),
        own_item=entry.get("written") if entry.get("level") == "目" else None,
        own_para_no=entry.get("paragraph_no"), previous_articles=previous)


def _merge_cross(judged, verdict):
    """只看新版的判定（judged）跟新舊版各推算一次的判定（verdict）合起來。

    verdict 是 None＝新舊版指到的是同一個（內容變了另外由 scan_reference_drift 報）。
    兩邊結論一樣就留只看新版那一筆（重編時照樣可以機械式改寫）；不一樣以新舊版比對為準，
    而且只列不改（list_only）：那是照內容對齊推出來的，不是本次重編自己算出來的號碼，
    要人在決定表上看過才改。"""
    if verdict is None:
        return None
    if (verdict.get("ambiguous") and judged is not None and judged.get("status") == "需改寫"
            and (judged.get("new_quote") or "") == (verdict.get("would_quote") or "")):
        return judged
    if (judged is not None and judged.get("status") == verdict.get("status")
            and (judged.get("new_quote") or "") == (verdict.get("new_quote") or "")):
        return judged
    out = dict(verdict)
    if out.get("status") == "需改寫":
        out["list_only"] = True
    return out


_ARTICLE_NO_RE = re.compile(r"^第\s*([%s\d]+)\s*條(?:\s*之\s*([%s\d]+))?" % (CN, CN))


def normalize_article_no(text):
    """條號正規化，**只給比對用**（寫進產出檔的原文一律保留原字）。

    全形數字先用 NFKC 轉半形，再把中文數字換成阿拉伯數字，所以
    「第１２條」「第12條」「第十二條」正規化後是同一把鑰匙。
    以前是照字面比，同一份文件裡混寫全形／中文就會判成「引用的條在新版中不存在」，
    那是最高等級的「危險」警告，人得一筆一筆回去查才發現是假警報。
    認不出條號就回去掉空白的原字，不硬猜。
    """
    if not text:
        return ""
    plain = re.sub(r"\s+", "", unicodedata.normalize("NFKC", text))
    match = _ARTICLE_NO_RE.match(plain)
    if not match:
        return plain
    main = cn_to_int(match.group(1))
    if main is None:
        return plain
    sub = cn_to_int(match.group(2)) if match.group(2) else None
    return "條%d%s" % (main, "之%d" % sub if sub else "")


def _same_article(left, right):
    return normalize_article_no(left) == normalize_article_no(right)


def _lookup_by_article(mapping, key):
    """字典查詢：先照原字，查不到再用正規化後的條號比一次。"""
    if key in mapping:
        return mapping[key]
    if isinstance(key, tuple):
        want = (normalize_article_no(key[0]),) + tuple(key[1:])
        for candidate, value in mapping.items():
            if (isinstance(candidate, tuple) and len(candidate) == len(key)
                    and (normalize_article_no(candidate[0]),) + tuple(candidate[1:]) == want):
                return value
        return None
    for candidate, value in mapping.items():
        if _same_article(candidate, key):
            return value
    return None


def _lookup_article_map(article_map, article):
    """在「舊條號 → 新條號」對照裡查一條，查不到回 None。條號先正規化再比。"""
    if not article_map:
        return None
    if article in article_map:
        return article_map[article]
    for candidate, value in article_map.items():
        if _same_article(candidate, article):
            return value
    return None


def _map_lookup(mapping, article, para, explicit, rest):
    """款／目對照表查詢。鍵是 (條, 項, …, 舊號)。
    有寫項就照那一項查；沒寫（本段所在的項只是推定）先照推定的項查，查不到再看
    全條只有一項有這個號碼就用它，好幾項都有回 _AMBIGUOUS（不能猜）。"""
    if para is not None:
        value = _lookup_by_article(mapping, (article, para) + tuple(rest))
        if value is not None or explicit:
            return value
    hits = {}
    for key, value in mapping.items():
        if (isinstance(key, tuple) and len(key) == 2 + len(rest)
                and _same_article(key[0], article) and tuple(key[2:]) == tuple(rest)):
            hits[key[1]] = value
    if len(hits) == 1:
        return list(hits.values())[0]
    return _AMBIGUOUS if hits else None


def _reference_hits(clause_map, item_map, reference, own_clause):
    """引用的每個款、目號碼，在那一條的各項分別換成幾號：[[(項, 新號), ...], ...]。其他層級回 None。"""
    unit = reference.get("kind")
    if unit not in ("款", "目") or not reference.get("numbers"):
        return None
    clause = reference.get("clause") if reference.get("clause") is not None else own_clause
    mapping = clause_map if unit == "款" else item_map
    out = []
    for number in reference["numbers"]:
        rest = (number,) if unit == "款" else (clause, number)
        hits = [(key[1], "分不出" if value is _AMBIGUOUS else value) for key, value in mapping.items()
                if isinstance(key, tuple) and len(key) == 2 + len(rest)
                and _same_article(key[0], reference["article"]) and tuple(key[2:]) == rest]
        out.append(sorted(hits, key=str))
    return out


def _judge(reference, text, index, clause_map, item_map, own_clause,
           known_articles, articles_with_clauses=None, para_counts=None,
           article_map=None, changed_paragraphs=None):
    """判斷單一筆引用會不會出問題。沒問題（安全）就回 None。

    條號一律先正規化再比（normalize_article_no）：全形數字、中文數字混寫的同一條
    以前會被判成「在新版中不存在」的假危險。
    """
    base = {"index": index, "text": text, "quote": reference["raw"],
            "article": reference["article"], "kind": reference["kind"],
            "external": reference.get("external", ""),
            # 引用在原文的位置（不論判成什麼）：「內容變了」那一關拿它去重，決定表拿它對位置
            "ref_span": tuple(reference.get("span") or ())}

    if reference.get("range_inner"):
        return _judge_article_range(base, reference, known_articles, article_map)

    if reference.get("external"):
        # 外部法規的條號：本程式沒有那部法規的新舊版，判不了也不該判。
        # 列出來讓人自己去查，但絕對不能改寫（實測 idx 142 就是被改掉的）。
        base.update({"status": "外部法規", "law": reference["external"],
                     "note": "這是「%s」的條號，不是本規章的條，本程式不檢查也不改寫"
                             % reference["external"]})
        return base

    if known_articles is not None and not known_articles and reference["kind"] in ("條", "項"):
        # 整份文件沒有「第X條」（業務手冊、作業要點常見，層級是章、節、款）：項也只長在條底下，
        # 所以這裡的「第十五條」「前項」「第三十三條第一項」都是在照抄別部法規的條文。
        # 以前一律判「在新版中不存在」的危險、「不在任何條的項次之內」的無法判定，
        # 一本法令遵循篇就冒出二三十列要人看的假警報。
        base.update({"status": "外部法規", "law": "",
                     "note": "本文件沒有「第X條」，這裡的條號、項次是在引述別部法規，本程式不檢查也不改寫"})
        return base

    if reference.get("note") and reference.get("numbers") is None:
        if "各款" in reference["raw"]:
            return None      # 「各款」指全部，不受重編影響
        base.update({"status": reference.get("status_hint") or "無法判定",
                     "note": reference["note"]})
        return base

    if not reference["article"]:
        base.update({"status": "無法判定",
                     "note": "解析不出這個引用指向哪一條，請人工確認"})
        return base

    if known_articles is not None and not any(
            _same_article(reference["article"], known) for known in known_articles):
        base.update({"status": "危險",
                     "note": "引用的 %s 在新版中不存在" % reference["article"]})
        return base

    if reference["kind"] == "條":
        # 以前這裡直接 return None，理由是「條號不重編，條存在就沒事」。
        # 但實務上使用者常常自己把條號往前遞補過：新版的確有「第七條」，
        # 內容卻已經是舊版的第八條——寫「第七條」的地方全部指錯，
        # 程式卻一聲不吭，報告還印「沒有受影響的交叉引用」（實測 idx 63、80）。
        if article_map is None:
            # 沒有舊版可比對，算不出舊條號跟新條號的對應。這裡不下任何結論，
            # 由 report() 把條層級整段印成「未檢查」。
            return None
        if reference.get("relative"):
            # 「前條」不能拿新版的前一條去查對照表：新版的前一條永遠在，查到的不是舊版沒有
            # （被當成新寫的引用放過，C9）就是新舊號一樣（C7b）。要照舊版的前一條算。
            return _judge_previous_article(base, reference, article_map,
                                           changed_paragraphs, index)
        target = _lookup_article_map(article_map, reference["article"])
        if target is None:
            # 舊版根本沒有這個條號（新版才有），代表這是新版新寫的引用，
            # 作者是照新版的條號寫的，沒有位移問題，不下判斷也不列出來。
            return None
        if target["new"] is not None and _same_article(target["new"], reference["article"]):
            # 舊第 N 條在新版還是第 N 條：不管作者照舊號還是新號寫，指到的都是同一條，
            # 下面那支保險絲要防的情況不存在。新版第 N 條如果是別條遞補來的，
            # 舊第 N 條在對照表裡不是刪了就是換了號，走不進這裡。
            return None
        if changed_paragraphs is not None and index in changed_paragraphs:
            # 這一段本次有改過。重編之後，「作者已經改好的新號」跟「還沒改的舊號」
            # 文字上一模一樣，程式分不出來，猜錯就是把對的條號改成錯的
            # （實測：作者已經把第七條改成第六條，程式又把它改成第五條）。
            base.update({
                "status": "危險",
                "note": "危險（引用所在段落本次有改，無法判斷是舊號或新號）："
                        "舊版的%s在新版是%s，請人工確認這裡的「%s」指的是哪一個"
                        % (reference["article"],
                           target["new"] or "已刪除或併入別條",
                           reference["article"]),
            })
            return base
        if target["new"] is None:
            if target["merged_into"]:
                base.update({
                    "status": "危險",
                    "note": "舊版的%s已併入%s，這個引用要指向哪裡必須人工確認"
                            % (reference["article"], target["merged_into"]),
                })
            else:
                base.update({
                    "status": "危險",
                    "note": "舊版的%s在新版已被刪除，沒有對應的新條號，必須人工確認"
                            % reference["article"],
                })
            return base
        base.update({
            "status": "需改寫", "new_quote": target["new"],
            "span": reference["span"],
            "note": "被引用的條還在，只是從%s變成%s"
                    % (reference["article"], target["new"]),
        })
        return base

    if reference.get("scope_relative") and article_map:
        # 「前條第二款」：前條在新舊版指的不是同一條，後面的款項號再怎麼對也沒有意義
        shifted = _judge_previous_scope(base, reference, text, article_map,
                                        changed_paragraphs, index, clause_map)
        if shifted is not None:
            return shifted or None

    if reference["kind"] == "項":
        # 項沒有寫在文字裡的編號，沒辦法機械式改寫；能做的是確認它指得到，
        # 指不到就一定要講。實際「指到的內容變了沒有」由 scan_reference_drift
        # 比對新舊版來抓。
        counts = para_counts or {}
        total = _lookup_by_article(counts, reference["article"]) or 0
        wanted = max(reference["numbers"])       # 「前二項」兩項都要指得到
        if not total:
            base.update({"status": "無法判定",
                         "note": "%s 底下推算不出項次，請人工確認這個引用指向哪裡"
                                 % reference["article"]})
            return base
        if wanted > total:
            base.update({"status": "危險",
                         "note": "%s 只有 %d 項，但這裡引用第 %d 項，指不到"
                                 % (reference["article"], total, wanted)})
            return base
        return None

    # 引用的條底下根本沒有款，代表這個引用本身有問題（常見於「前條」指錯條），
    # 不能報成「已被刪除」——那會讓人以為是這次修訂造成的。
    if (reference["kind"] == "款" and articles_with_clauses is not None
            and not any(_same_article(reference["article"], known)
                        for known in articles_with_clauses)):
        base.update({
            "status": "無法判定",
            "note": "%s 底下沒有任何款，這個引用可能原本就寫錯，請人工確認指向哪裡"
                    % reference["article"],
        })
        return base

    mapped = []
    for number in reference["numbers"]:
        if reference["kind"] == "款":
            rest = (number,)
        else:
            clause = reference.get("clause")
            rest = (clause if clause is not None else own_clause, number)
        mapped.append(_map_lookup(clause_map if reference["kind"] == "款" else item_map,
                                  reference["article"], reference.get("para"),
                                  reference.get("para_explicit"), rest))

    if any(m is _AMBIGUOUS for m in mapped):
        base.update({
            "status": "無法判定",
            "note": "%s 有好幾項或好幾組都有這個%s，引用沒寫是哪一個，請人工確認指向哪裡"
                    % (reference["article"], reference["kind"]),
        })
        return base

    if any(m is None for m in mapped):
        missing = [n for n, m in zip(reference["numbers"], mapped) if m is None]
        base.update({
            "status": "危險",
            "note": "引用的第%s%s已被刪除，沒有對應的新編號，必須人工確認要改成什麼"
                    % ("、".join(int_to_cn(n) for n in missing), reference["kind"]),
        })
        return base

    if reference.get("relative") and reference.get("own_no"):
        # 「前款」「前二款」是相對的：自己跟被指的那幾款一起換號，相對關係沒變就不用改。
        # 刪掉的是更前面的款時，「四、違反前款」重編成「三、違反前款」照樣指對；以前被報成
        # 「需改寫」，建議的新寫法卻還是「前款」（實測 R-C2）。
        own_rest = ((reference["own_no"],) if reference["kind"] == "款"
                    else (reference.get("clause") if reference.get("clause") is not None
                          else own_clause, reference["own_no"]))
        own_new = _map_lookup(clause_map if reference["kind"] == "款" else item_map,
                              reference["article"], reference.get("para"),
                              reference.get("para_explicit"), own_rest)
        if own_new is not None and own_new is not _AMBIGUOUS:
            if mapped == list(range(own_new - len(mapped), own_new)):
                return None
            base.update({"status": "需改寫", "span": reference["span"],
                         "new_quote": _join_numbers(mapped, reference["kind"]),
                         "note": "「%s」重編後指不到原本的第%s%s，要改成明寫的號碼"
                                 % (reference["raw"],
                                    "、".join(int_to_cn(n) for n in reference["numbers"]),
                                    reference["kind"])})
            return base

    if mapped == reference["numbers"]:
        return None          # 安全，編號沒變

    # 範圍引用只有在重編後仍然連續時，機械式改寫才成立
    if reference.get("is_range") and mapped != list(range(mapped[0], mapped[-1] + 1)):
        base.update({"status": "危險",
                     "note": "範圍引用在重編後不再連續，必須人工改寫"})
        return base

    new_quote = _rewrite_quote(reference, mapped)
    base.update({
        "status": "需改寫", "new_quote": new_quote, "span": reference["span"],
        "note": "被引用的%s還在，只是從第%s%s變成第%s%s"
                % (reference["kind"],
                   "、".join(int_to_cn(n) for n in reference["numbers"]),
                   reference["kind"],
                   "、".join(int_to_cn(n) for n in mapped), reference["kind"]),
    })
    return base


def _join_numbers(numbers, unit):
    """[2] →「第二款」，[2, 3] →「第二款及第三款」，連續三個以上 →「第二款至第四款」；不連續回空字串。"""
    if not numbers:
        return ""
    if len(numbers) == 1:
        return "第%s%s" % (int_to_cn(numbers[0]), unit)
    if numbers != list(range(numbers[0], numbers[0] + len(numbers))):
        return ""
    joiner = "及" if len(numbers) == 2 else "至"
    return "第%s%s%s第%s%s" % (int_to_cn(numbers[0]), unit, joiner, int_to_cn(numbers[-1]), unit)


def _join_articles(articles):
    """「第八條」「第七條及第八條」「第六條、第七條及第八條」。"""
    articles = list(articles or [])
    if len(articles) <= 1:
        return "".join(articles)
    return "、".join(articles[:-1]) + "及" + articles[-1]


def _old_previous_articles(own_article, offset, article_map):
    """這一段所在的條在舊版是哪一條、舊版往前 offset 條是哪幾條（照舊版順序）。

    article_map 的鍵就是舊版各條照出現順序排的。回傳 (舊版本條, [舊版前幾條])；
    這一條是新版才有的回 (None, None)，舊版也往前數不到回 (舊版本條, None)。"""
    if not own_article or not article_map:
        return None, None
    olds = list(article_map)
    own_old = None
    for old, info in article_map.items():
        if info.get("new") and _same_article(info["new"], own_article):
            own_old = old
            break
    if own_old is None:
        return None, None
    pos = olds.index(own_old)
    if pos < offset:
        return own_old, None
    return own_old, olds[pos - offset:pos]


def _gone_text(article_map, old):
    info = _lookup_article_map(article_map, old) or {}
    return ("已併入%s" % info["merged_into"]) if info.get("merged_into") else "已刪除"


def _article_order(article):
    """條號排順序用：第五條之一 → (5, 1)。認不出來回 None。"""
    match = re.match(r"^條(\d+)(?:之(\d+))?$", normalize_article_no(article))
    return (int(match.group(1)), int(match.group(2) or 0)) if match else None


def _articles_between(articles, first, last):
    """articles 裡夾在 first 與 last 中間的條（不含兩端）。兩端認不出來回 None。"""
    low, high = _article_order(first), _article_order(last)
    if low is None or high is None or high <= low:
        return None
    return [a for a in articles if _article_order(a) and low < _article_order(a) < high]


def _judge_article_range(base, reference, known_articles, article_map):
    """「第五條至第七條」夾在中間的條：照舊版有哪幾條去查（條號可能有「之一」，不能用數的）。
    兩端自己照一般的條層級判，這裡只看中間，一個範圍最多一筆。沒有舊版比不出來，由 report 印未檢查。"""
    if not article_map or not known_articles:
        return None
    first, last = reference["range_inner"]
    raw = reference["raw"]
    base["ref_span"] = reference["full_span"]      # 決定表要標整個範圍，不是中間那個「至」
    inner = _articles_between(list(article_map), first, last)
    if inner is None:
        base.update({"status": "無法判定",
                     "note": "解析不出「%s」這個範圍涵蓋哪幾條，請人工確認" % raw})
        return base
    lost = [a for a in inner if not (_lookup_article_map(article_map, a) or {}).get("new")]
    if lost:
        base.update({"article": lost[0], "status": "危險",
                     "note": "「%s」涵蓋的%s新版%s，範圍要怎麼寫必須人工確認"
                             % (raw, "、".join(lost), _gone_text(article_map, lost[0]))})
        return base
    # 兩端在新版的位置（兩端自己被刪時另外有危險，這裡先照原號算）
    new_first, new_last = [(_lookup_article_map(article_map, a) or {}).get("new") or a
                           for a in (first, last)]
    moved_out = []
    for article in inner:
        new = _lookup_article_map(article_map, article)["new"]
        if not _articles_between([new], new_first, new_last):
            moved_out.append((article, new))
    if moved_out:
        base.update({"article": moved_out[0][0], "status": "危險",
                     "note": "「%s」涵蓋的%s搬到範圍外了（新版是%s），範圍要怎麼寫必須人工確認"
                             % (raw, moved_out[0][0], moved_out[0][1])})
        return base
    carried = set(normalize_article_no(info["new"]) for info in article_map.values() if info.get("new"))
    added = [a for a in _articles_between(known_articles, new_first, new_last) or []
             if normalize_article_no(a) not in carried]
    if added:
        added.sort(key=_article_order)
        base.update({"article": added[0], "status": "無法判定", "range_added": True,
                     "note": "「%s」的範圍裡多了新版才有的%s，請人工確認這個範圍要不要包含它"
                             % (raw, "、".join(added))})
        return base
    return None


def _judge_previous_article(base, reference, article_map, changed_paragraphs, index):
    """單獨寫的「前條」「前二條」：照舊版的前一條（經條號對照）跟新版的前一條比。"""
    raw = reference["raw"]
    own_old, old_targets = _old_previous_articles(reference.get("own_article"),
                                                  reference.get("offset") or 1, article_map)
    if own_old is None or not old_targets:
        return None      # 這一條是新版才有的（照新版寫的），或舊版也數不到（本來就這樣寫）
    infos = [(old, _lookup_article_map(article_map, old)) for old in old_targets]
    actual = reference.get("targets") or []
    gone = [old for old, info in infos if not info or not info.get("new")]
    if gone:
        base.update({"status": "危險",
                     "note": "「%s」在舊版指%s，%s新版%s；現在改指%s，要指向哪裡必須人工確認"
                             % (raw, "、".join(old_targets), gone[0], _gone_text(article_map, gone[0]),
                                "、".join(actual) or "不到任何一條")})
        return base
    expected = [info["new"] for _, info in infos]
    if [normalize_article_no(x) for x in expected] == [normalize_article_no(x) for x in actual]:
        return None
    note = ("「%s」在舊版指%s（新版是%s），新版的%s卻是%s"
            % (raw, "、".join(old_targets), "、".join(expected), raw, "、".join(actual) or "（沒有）"))
    if changed_paragraphs is not None and index in changed_paragraphs:
        base.update({"status": "危險",
                     "note": "危險（引用所在段落本次有改，無法判斷是照舊版或新版寫的）：" + note})
        return base
    base.update({"status": "需改寫", "span": reference["span"],
                 "new_quote": _join_articles(expected),
                 "note": note + "，照舊版的意思要改寫成「%s」" % _join_articles(expected)})
    return base


def _judge_previous_scope(base, reference, text, article_map, changed_paragraphs, index,
                          clause_map):
    """「前條第二款」「前條第二項」的前條在新舊版是不是同一條。

    回傳 None＝前條沒改指，往下照款、項自己的判法；False＝不用列（同一串後面那幾個，
    改寫算在緊接前條的那一個上）；dict＝判定。"""
    own_old, old_targets = _old_previous_articles(reference.get("own_article"), 1, article_map)
    if own_old is None or not old_targets:
        return None
    old = old_targets[0]
    info = _lookup_article_map(article_map, old) or {}
    raw = reference["raw"]
    if not info.get("new"):
        base.update({"status": "危險",
                     "note": "「前條」在舊版指%s，那一條新版%s；「%s」現在改指%s的%s，必須人工確認"
                             % (old, _gone_text(article_map, old), raw, reference["article"] or "（沒有）",
                                reference["kind"])})
        return base
    if _same_article(info["new"], reference["article"]):
        return None
    note = ("「前條」在舊版指%s（新版是%s），新版的前條卻是%s，「%s」指到的已經不是原來那一%s"
            % (old, info["new"], reference["article"] or "（沒有）", raw, reference["kind"]))
    if changed_paragraphs is not None and index in changed_paragraphs:
        base.update({"status": "危險",
                     "note": "危險（引用所在段落本次有改，無法判斷是照舊版或新版寫的）：" + note})
        return base
    scope = reference.get("scope_span")
    if not scope or scope[1] != reference["span"][0]:
        return False
    token = text[reference["span"][0]:reference["span"][1]]
    if reference["kind"] == "款":
        # 款號照舊版那一條的對照換（同一條自己也重編時）；有舊版全文時另由新舊版各推算一次再核
        number = reference["numbers"][0]
        mapped = _map_lookup(clause_map, info["new"], None, False, (number,))
        if mapped is not None and mapped is not _AMBIGUOUS:
            token = "第%s款" % _number_like(token, mapped)
    new_quote = info["new"] + token
    base.update({"status": "需改寫", "span": (scope[0], reference["span"][1]),
                 "new_quote": new_quote, "list_only": True,
                 "note": note + "，照舊版的意思要改寫成「%s」" % new_quote})
    return base


def _number_like(written, value):
    """新號碼照原文的體系寫：阿拉伯寫阿拉伯（全形寫全形），中文寫中文。
    正式文件裡「第3款」被改寫成「第二款」就是兩種寫法混在一起。"""
    digits = re.sub(r"\D", "", written or "")
    if not digits:
        return int_to_cn(value)
    text = str(value)
    if unicodedata.normalize("NFKC", digits) != digits:
        text = text.translate(str.maketrans("0123456789", "０１２３４５６７８９"))
    return text


def _rewrite_quote(reference, mapped):
    """把引用字句裡的號碼換成新號碼。範圍引用只換頭尾兩端。"""
    unit = reference["kind"]
    token = reference.get("token") or reference.get("raw") or ""
    if reference.get("is_range"):
        return "第%s%s至第%s%s" % (_number_like(token, mapped[0]), unit,
                                   _number_like(reference.get("end_token", token), mapped[-1]), unit)
    return re.sub(r"第\s*[%s\d]+\s*%s" % (CN, unit),
                  "第%s%s" % (_number_like(token, mapped[0]), unit),
                  token, count=1)


def _paragraph_ordinal(context):
    """
    這一段是所在條的第幾項。build_hierarchy 已經算好了，從 ref 裡取出來。
    條文本體是第一項，之後每一個沒有編號的獨立段落依序遞增。
    """
    ref = context.get("ref", "")
    match = re.search(r"第([%s]+)項$" % CN, ref)
    if match:
        return cn_to_int(match.group(1))
    return 1 if context.get("level") in ("條", "項") else None


def _previous_article_of(contexts, index):
    """往回找「前條」指的是哪一條。"""
    current = contexts[index - 1]["article"]
    seen_current = False
    for context in reversed(contexts[:index]):
        if context["level"] != "條":
            continue
        if not seen_current:
            if context["article"] == current:
                seen_current = True
            continue
        return context["article"]
    return ""


def _previous_articles_of(contexts, index):
    """這一段所在的條之前的各條（照全文順序，最近的在最後）。「前二條」要往前數兩條。
    最後一個就是 _previous_article_of 那一條。"""
    current = contexts[index - 1]["article"]
    heads = []
    for context in contexts[:index]:
        if context["level"] == "條" and context["article"] and (
                not heads or heads[-1] != context["article"]):
            heads.append(context["article"])
    if not current or current not in heads:
        return []
    pos = len(heads) - 1 - heads[::-1].index(current)
    return heads[:pos]


# ---------------------------------------------------------------------------
# 新舊版各推算一次：相對引用（前條、前項、前X款）與款、項號的位移
# ---------------------------------------------------------------------------
# 只看新版的話，「前條」永遠指得到東西（新版的前一條），程式就判「通過」：刪掉第二十條之後
# 第二十一條的「前條」改指第十九條、插入第八條之一之後第九條的「前條報告」改指新的那一條，
# 都沒有人講。款、項也一樣：作者刪掉第二款又自己把三、改成二、，「第二十二條第三款」在新版
# 指不到東西，被報成「已被刪除」，其實是換號了；「前項」只確認項次存在，中間一項被刪也不報。
# 做法：同一段在舊版找回原本那一段（內容對內容），兩邊各自解析引用、各自推算指到誰；
# 舊版指到的那一條／項／款經「舊 → 新」對照換到新版，再跟新版實際指到的比：
#   一樣           → 沒事；相對引用指到的內容變了，另外報「編號沒變、但指到的內容變了」
#   不一樣         → 需改寫（照舊版的意思給新寫法，例如「第三款」→「第二款」；拿不準就不給）
#   舊版那一個被刪 → 危險
# 引用所在的段落本次也改過：作者可能已經照新版寫了，分不出來，一律危險（跟條層級同一條保險絲）。

_CROSS_SKIP = object()
_cross_memo = {}


def _body_key(text):
    """比對「這一段是不是同一段、有沒有改」用：拿掉開頭的條號與款目編號，再正規化。
    重編只換了開頭的號碼，不算改內容（那個號碼不是引用）。"""
    body = strip_article_no(text or "")
    for pattern in (_CLAUSE_RE, _ITEM_RE, _POINT_RE):
        if pattern.match(body):
            body = pattern.sub("", body, count=1)
            break
    return normalize_for_compare(body)


def _align_lists(old_keys, new_keys, fallback=False):
    """兩串文字一對一對齊：{舊序號: 新序號}。一模一樣的整段對掉，改過的區塊用修正對照表
    同一支對齊（_align_block）。fallback：還沒配到的，同一個位置在新版也空著就配給它
    （內容改很多、但只是同一項／同一款改寫）。"""
    mapping = {}
    for tag, i1, i2, j1, j2 in difflib.SequenceMatcher(
            None, old_keys, new_keys, autojunk=False).get_opcodes():
        if tag == "equal":
            for k in range(i2 - i1):
                mapping[i1 + k] = j1 + k
        elif tag == "replace":
            pairs, _ = _align_block(old_keys[i1:i2], new_keys[j1:j2])
            for local_i, local_j in pairs:
                if local_j is not None:
                    mapping[i1 + local_i] = j1 + local_j
    if fallback:
        used = set(mapping.values())
        for i in range(len(old_keys)):
            if i not in mapping and i < len(new_keys) and i not in used:
                mapping[i] = i
                used.add(i)
    return mapping


def _para_table(paragraphs, contexts):
    """{正規化條號: [(項次, 比對鍵, 原文), ...]}，照項次順序。"""
    table = {}
    for text, context in zip(paragraphs, contexts):
        if context["level"] not in ("條", "項") or not context["article"]:
            continue
        table.setdefault(normalize_article_no(context["article"]), []).append(
            (_paragraph_ordinal(context) or 1, _body_key(text), strip_article_no(text).strip()))
    return table


def _clause_table(paragraphs, entries):
    """{(正規化條號, 項次): [(寫的款號, 比對鍵, 本體), ...]}，照出現順序。"""
    table = {}
    for entry in entries:
        if entry["level"] != "款" or not entry["article"] or entry["written"] is None:
            continue
        text = paragraphs[entry["index"] - 1]
        table.setdefault((normalize_article_no(entry["article"]), entry.get("paragraph_no") or 1),
                         []).append((entry["written"], _body_key(text),
                                     _CLAUSE_RE.sub("", text, count=1).strip()))
    return table


def cross_version_references(old_paragraphs, new_paragraphs, old_kinds=None, new_kinds=None,
                             article_map=None):
    """新舊版各推算一次引用指到誰（說明見上）。

    回傳 {"verdicts": {(新版段次, 引用的 span): 判定或 None}, "drift": [...], "article_map": ...}。
    verdicts 只收「新舊版都解析得出來」的引用；None＝兩邊指到同一個；判定的格式跟 _judge 一樣。
    drift 是相對引用（前條、前項、前X款）指到同一個、但那一個的內容這次改了，格式跟
    scan_reference_drift 一樣。scan_references 與 scan_reference_drift 都要用，同一次執行
    只算一次（記住最後一組輸入）。"""
    key = (tuple(old_paragraphs), tuple(new_paragraphs),
           tuple(old_kinds or ()), tuple(new_kinds or ()))
    if _cross_memo.get("key") == key:
        return _cross_memo["value"]
    value = _cross_version_references(old_paragraphs, new_paragraphs, old_kinds, new_kinds,
                                      article_map)
    _cross_memo.clear()
    _cross_memo.update(key=key, value=value)
    return value


def _cross_version_references(old_paragraphs, new_paragraphs, old_kinds, new_kinds, article_map):
    if article_map is None:
        article_map = plan_article_map(old_paragraphs, new_paragraphs, old_kinds, new_kinds)
    result = {"verdicts": {}, "drift": [], "article_map": article_map, "added": set(),
              "old_status": {}, "old_hits": {}}
    if not article_map:
        return result
    old_ctx = build_hierarchy(old_paragraphs, old_kinds)
    new_ctx = build_hierarchy(new_paragraphs, new_kinds)
    old_entries = scan(old_paragraphs, old_kinds)
    new_entries = scan(new_paragraphs, new_kinds)
    old_by = dict((e["index"], e) for e in old_entries)
    new_by = dict((e["index"], e) for e in new_entries)
    _, plan_clause, _ = plan_renumber(new_paragraphs, new_entries)
    new_of = dict((normalize_article_no(old), info) for old, info in article_map.items())

    # 項：舊版每一條的每一項，在新版是哪一條第幾項（被刪的是 None）
    old_paras = _para_table(old_paragraphs, old_ctx)
    new_paras = _para_table(new_paragraphs, new_ctx)
    para_x = {}
    for art, items in old_paras.items():
        target = (new_of.get(art) or {}).get("new")
        news = new_paras.get(normalize_article_no(target), []) if target else []
        pairs = _align_lists([k for _, k, _ in items], [k for _, k, _ in news], fallback=True)
        for i, (ordinal, _, _) in enumerate(items):
            j = pairs.get(i)
            para_x[(art, ordinal)] = (target, news[j][0]) if j is not None else None

    # 款：舊版每一項底下的每一款，在新版是哪一條哪一項寫的第幾款
    old_clauses = _clause_table(old_paragraphs, old_entries)
    new_clauses = _clause_table(new_paragraphs, new_entries)
    clause_x = {}
    clause_twice = set()     # 同一項裡兩組都有的款號：引用沒寫是哪一組，不能拿來比
    new_clause_body = {}
    for (art, para), items in new_clauses.items():
        for written, _, body in items:
            new_clause_body[(art, para, written)] = body
    old_clause_body = {}
    for (art, para), items in old_clauses.items():
        target = (new_of.get(art) or {}).get("new")
        new_para = para
        moved = para_x.get((art, para))
        if moved:
            new_para = moved[1]
        news = new_clauses.get((normalize_article_no(target), new_para), []) if target else []
        pairs = _align_lists([k for _, k, _ in items], [k for _, k, _ in news], fallback=True)
        for i, (written, _, body) in enumerate(items):
            j = pairs.get(i)
            if (art, para, written) in clause_x:
                clause_twice.add((art, para, written))
            clause_x[(art, para, written)] = (target, new_para, news[j][0]) if j is not None else None
            old_clause_body[(art, para, written)] = body

    old_units = dict((normalize_article_no(a), b) for a, b in _article_units(old_paragraphs, old_kinds))
    new_units = dict((normalize_article_no(a), b) for a, b in _article_units(new_paragraphs, new_kinds))
    old_texts = dict((normalize_article_no(a), t) for a, t in _article_texts(old_paragraphs, old_kinds))
    new_texts = dict((normalize_article_no(a), t) for a, t in _article_texts(new_paragraphs, new_kinds))
    old_para_body = dict(((a, o), body) for a, items in old_paras.items() for o, _, body in items)
    new_para_body = dict(((a, o), body) for a, items in new_paras.items() for o, _, body in items)

    old_keys = [_body_key(t) for t in old_paragraphs]
    new_keys = [_body_key(t) for t in new_paragraphs]
    counterpart = dict((j, i) for i, j in _align_lists(old_keys, new_keys).items())
    result["added"] = set(j + 1 for j in range(len(new_paragraphs)) if j not in counterpart)

    # 舊版自己的「只看單一版本」判定：同一處舊版就判成危險／無法判定的，是本來就有的問題
    _, old_plan_clause, old_plan_item = plan_renumber(old_paragraphs, old_entries)
    old_known = {c["article"] for c in old_ctx if c["level"] == "條" and c["article"]}
    old_with_clauses = {e["article"] for e in old_entries if e["level"] == "款" and e["article"]}
    old_para_counts = {}
    for context in old_ctx:
        if context["level"] in ("條", "項") and context["article"]:
            ordinal = _paragraph_ordinal(context) or 1
            old_para_counts[context["article"]] = max(old_para_counts.get(context["article"], 0), ordinal)

    def plan_number(article, para, written):
        value = _lookup_by_article(plan_clause, (article, para, written))
        return value if value is not None else written

    def clause_key(article, para, explicit, number):
        if para is not None and (article, para, number) in clause_x:
            key = (article, para, number)
        elif explicit:
            return None
        else:
            hits = [k for k in clause_x if k[0] == article and k[2] == number]
            key = hits[0] if len(hits) == 1 else None
        return None if key in clause_twice else key

    for j0, text in enumerate(new_paragraphs):
        i0 = counterpart.get(j0)
        if i0 is None:
            continue          # 新版才有的段落：裡面的引用是照新版寫的
        idx = j0 + 1
        new_refs = [r for r in _paragraph_references(text, new_ctx[j0], new_by.get(idx, {}),
                                                     new_ctx, idx) if not r.get("external")]
        if not new_refs:
            continue
        old_refs = [r for r in _paragraph_references(old_paragraphs[i0], old_ctx[i0],
                                                     old_by.get(i0 + 1, {}), old_ctx, i0 + 1)
                    if not r.get("external")]
        changed = old_keys[i0] != new_keys[j0]

        def finding(n, status, note, new_quote="", span=None, ambiguous=False, would=""):
            out = {"index": idx, "text": text, "quote": n["raw"], "article": n["article"],
                   "kind": n["kind"], "external": "", "status": status, "note": note,
                   "cross": True, "ref_span": tuple(span or n["span"])}
            if status == "需改寫":
                out.update(new_quote=new_quote, span=tuple(span or n["span"]))
            if ambiguous:
                out.update(ambiguous=True, would_quote=would)
            return out

        def shifted(n, note, new_quote, span=None):
            if changed:
                return finding(n, "危險", "危險（引用所在段落本次有改，無法判斷是照舊編號或新編號寫的）："
                               + note, span=span, ambiguous=True, would=new_quote)
            if new_quote:
                return finding(n, "需改寫", note + "，照舊版的意思要改寫成「%s」" % new_quote,
                               new_quote, span)
            return finding(n, "需改寫", note + "；程式拿不準新寫法，請人工改寫", "", span)

        def drift_entry(n, target, old_body, new_body):
            return {"index": idx, "text": text, "quote": n["raw"], "target": target,
                    "old_body": old_body, "new_body": new_body,
                    "start": n["span"][0], "end": n["span"][1]}

        def judge_pair(o, n):
            kind = n["kind"]
            if kind == "條":
                if not n.get("relative") or not o.get("targets") or not n.get("targets"):
                    return _CROSS_SKIP
                expected = [(new_of.get(normalize_article_no(x)) or {}).get("new") for x in o["targets"]]
                if not all(expected) or [normalize_article_no(x) for x in expected] != \
                        [normalize_article_no(x) for x in n["targets"]]:
                    return _CROSS_SKIP          # 被刪、併入、改指：_judge 照條號對照判
                for old, new in zip(o["targets"], n["targets"]):
                    if old_units.get(normalize_article_no(old)) != new_units.get(normalize_article_no(new)):
                        return None, drift_entry(n, "%s（%s）" % (n["raw"], new),
                                                 old_texts.get(normalize_article_no(old)),
                                                 new_texts.get(normalize_article_no(new)))
                return None, None
            if kind not in ("項", "款") or not o.get("numbers") or not o.get("article"):
                return _CROSS_SKIP
            art = normalize_article_no(o["article"])
            relative = bool(n.get("relative"))
            absolute = (not relative and not n.get("scope_relative")
                        and not _same_article(n["article"], n.get("own_article") or ""))
            old_label = "%s第%s%s" % (o["article"], "、".join(int_to_cn(x) for x in o["numbers"]), kind)
            if kind == "項":
                keys = [(art, x) for x in o["numbers"]]
                if any(k not in para_x for k in keys):
                    return _CROSS_SKIP
                mapped = [para_x[k] for k in keys]
                old_bodies = [old_para_body.get(k) for k in keys]
            else:
                keys = [clause_key(art, o.get("para"), o.get("para_explicit"), x) for x in o["numbers"]]
                if any(k is None for k in keys):
                    return _CROSS_SKIP
                mapped = [clause_x[k] for k in keys]
                old_bodies = [old_clause_body.get(k) for k in keys]
            if any(m is None for m in mapped):
                gone = [x for x, m in zip(o["numbers"], mapped) if m is None]
                return finding(n, "危險", "「%s」在舊版指%s（%s），舊版的第%s%s這次刪掉了，要改指哪裡必須人工確認"
                               % (n["raw"], old_label, clip_body(old_bodies[o["numbers"].index(gone[0])]),
                                  "、".join(int_to_cn(x) for x in gone), kind)), None
            new_art = mapped[0][0]
            if kind == "項":
                finals = [m[1] for m in mapped]
                new_bodies = [new_para_body.get((normalize_article_no(m[0]), m[1])) for m in mapped]
            else:
                finals = [plan_number(m[0], m[1], m[2]) for m in mapped]
                new_bodies = [new_clause_body.get((normalize_article_no(m[0]), m[1], m[2])) for m in mapped]
                if any(x is _AMBIGUOUS for x in finals):
                    return _CROSS_SKIP          # 新版同一個號碼有兩組：_judge 照對照表列無法判定
            if relative:
                own = n.get("own_no")
                if kind == "款" and own:
                    own = plan_number(n["article"], n.get("para") or 1, own)
                    if own is _AMBIGUOUS:
                        return _CROSS_SKIP
                actual = list(range(own - len(finals), own)) if own else []
            else:
                actual = list(n.get("numbers") or [])
            same_article = absolute or _same_article(new_art, n["article"])
            if same_article and finals == actual:
                if relative and any(a != b for a, b in zip(old_bodies, new_bodies)):
                    return None, drift_entry(n, "%s（%s第%s%s）" % (n["raw"], new_art,
                                                                "、".join(int_to_cn(x) for x in finals), kind),
                                             "；".join(b or "" for b in old_bodies),
                                             "；".join(b or "" for b in new_bodies))
                return None, None
            note = "「%s」在舊版指%s（%s），新版要寫成%s第%s%s才指得到同一%s" % (
                n["raw"], old_label, clip_body(old_bodies[0]), new_art,
                "、".join(int_to_cn(x) for x in finals), kind, kind)
            span = None
            if relative:
                same_place = _same_article(new_art, n.get("own_article") or "") and (
                    kind == "項" or mapped[0][1] == (n.get("para") or 1))
                new_quote = _join_numbers(finals, kind) if same_place else ""
            elif not same_article:
                scope = n.get("scope_span")
                new_quote = ""
                if scope and scope[1] == n["span"][0] and len(finals) == 1:
                    new_quote = new_art + "第%s%s" % (_number_like(n["token"], finals[0]), kind)
                    span = (scope[0], n["span"][1])
            else:
                if n.get("is_range") and finals != list(range(finals[0], finals[-1] + 1)):
                    return finding(n, "危險", "範圍引用在新舊版對照後不再連續，必須人工改寫"), None
                new_quote = _rewrite_quote(n, finals) if len(finals) == 1 or n.get("is_range") else ""
            return shifted(n, note, new_quote, span), None

        sig = lambda r: (r["kind"], re.sub(r"\s+", "", r.get("raw") or ""))
        matcher = difflib.SequenceMatcher(None, [sig(r) for r in old_refs],
                                          [sig(r) for r in new_refs], autojunk=False)
        for tag, a1, a2, b1, b2 in matcher.get_opcodes():
            if tag != "equal":
                continue
            for o, n in zip(old_refs[a1:a2], new_refs[b1:b2]):
                old_judged = _judge(o, old_paragraphs[i0], i0 + 1, old_plan_clause, old_plan_item,
                                    old_by.get(i0 + 1, {}).get("clause_written"), old_known,
                                    old_with_clauses, old_para_counts, None, None)
                result["old_status"][(idx, tuple(n["span"]))] = (old_judged or {}).get("status")
                result["old_hits"][(idx, tuple(n["span"]))] = _reference_hits(
                    old_plan_clause, old_plan_item, o, old_by.get(i0 + 1, {}).get("clause_written"))
                outcome = judge_pair(o, n)
                if outcome is _CROSS_SKIP:
                    continue
                verdict, drift = outcome
                result["verdicts"][(idx, tuple(n["span"]))] = verdict
                if drift:
                    result["drift"].append(drift)
    return result


def clip_body(text, limit=24):
    text = re.sub(r"\s+", " ", text or "").strip()
    return text if len(text) <= limit else text[:limit] + "…"


def dedupe_drift(drift, references):
    """同一處引用已經在交叉引用判成需改寫／危險／無法判定，就不再列一次「內容變了」：
    決定表上同一段只要一筆說清楚，兩筆講同一件事人會以為是兩個問題。"""
    taken = {}
    for ref in references or []:
        span = ref.get("ref_span") or ref.get("span")
        # 標成「舊版就這樣」的不進決定表，拿來去重的話，這次內容換了的那一筆也跟著消失
        if ref.get("status") in ("需改寫", "危險", "無法判定") and span and not ref.get("pre_existing"):
            taken.setdefault(ref["index"], []).append(tuple(span))
    out = []
    for item in drift or []:
        start, end = item.get("start"), item.get("end")
        spans = taken.get(item["index"], [])
        if start is not None and any(start < b and a < end for a, b in spans):
            continue
        if start is not None and any(d["index"] == item["index"] and d.get("start") is not None
                                     and start < d["end"] and d["start"] < end for d in out):
            continue
        out.append(item)
    return out


def _paragraph_bodies(paragraphs, kinds=None):
    """
    把全文的「項」整理成 {(條號, 項次): 條文本體}。

    項沒有寫在文字裡的編號，項次是從條文本體開始往下數出來的。
    刪掉一個項，後面的項次全部往前移——「第二項」就指到別的東西了，
    這跟刪掉一個款完全是同一種問題，只是更難察覺，因為文件上看不出編號變動。
    """
    bodies = {}
    for text, context in zip(paragraphs, build_hierarchy(paragraphs, kinds)):
        if context["level"] not in ("條", "項") or not context["article"]:
            continue
        ordinal = _paragraph_ordinal(context) or 1
        bodies[(context["article"], ordinal)] = strip_article_no(text).strip()
    return bodies


def _numbered_bodies(paragraphs, entries):
    """把全文的款、目整理成兩張表，值是去掉編號後的本體清單。

    用來比對「同一個編號，新舊版指的是不是同一件事」。
    鍵是 (正規化條號, 項, 號碼)、目多帶所屬的款；項放 None 的那把鑰匙收全條所有同號的
    （引用沒寫項時用）。值是清單：同一項裡兩組都有第三款時兩個都留著一起比，
    分不出引用指哪一組，哪一個變了都要講。
    目分中文與阿拉伯兩個體系，引用寫的「第二目」是中文體系那一個（跟 plan_renumber 同一套）。
    """
    clauses, items, arabic = {}, {}, {}
    for entry in entries:
        if entry["written"] is None or not entry["article"]:
            continue
        text = paragraphs[entry["index"] - 1]
        article = normalize_article_no(entry["article"])
        para = entry.get("paragraph_no") or 1
        if entry["level"] == "款":
            body = _CLAUSE_RE.sub("", text, count=1).strip()
            for place in (para, None):
                clauses.setdefault((article, place, entry["written"]), []).append(body)
        elif entry["level"] == "目":
            table = items if entry.get("item_style") == _ITEM_STYLE_CN else arabic
            body = _ITEM_RE.sub("", text, count=1).strip()
            for place in (para, None):
                table.setdefault((article, place, entry["clause_written"], entry["written"]), []).append(body)
    for key, bodies in arabic.items():
        items.setdefault(key, bodies)
    return clauses, items


def _bodies_at(table, article, para, explicit, rest):
    """_numbered_bodies 的表查一筆。有寫項就照那一項；沒寫（本段所在的項只是推定）
    先照推定的項，查不到再看全條。跟 _map_lookup 同一套規矩。"""
    if para is not None:
        found = table.get((article, para) + rest)
        if found or explicit:
            return found
    return table.get((article, None) + rest)


def _drift_item(idx, text, quote, target, olds, news, start, end):
    """「內容變了」的一筆。olds、news 是同一個引用涵蓋的各個編號，範圍引用會有好幾個。"""
    gone = all(body is None for body in news)
    return {"index": idx, "text": text, "quote": quote, "target": target,
            "old_body": "；".join(olds),
            "new_body": None if gone else "；".join("（新版沒有）" if b is None else b for b in news),
            "start": start, "end": end}


# 條號後面還接著款項目（或「之X」），這個條層級引用就只是範圍前綴，不是引用到整條
_MORE_OF_THE_CHAIN_RE = re.compile(r"\s*(?:第\s*[%s\d]+\s*[款項目]|之\s*[%s\d])" % (CN, CN))


def scan_reference_drift(old_paragraphs, new_paragraphs,
                         old_kinds=None, new_kinds=None):
    """
    比對新舊版，找出「編號沒變、但指的東西變了」的交叉引用。

    為什麼一定要有這一關：
    如果使用者刪掉第二款之後，自己先把三、四、改成二、三、才拿來跑，
    編號連續性檢查會說「完全乾淨」——因為它確實乾淨。但別的條文寫的
    「依前條第二款規定」，指的已經從被刪掉的「原保險單正本」變成
    「契約變更申請書」，意思整個換掉，而且**表面上完全看不出來**。
    這是所有情況裡最危險的一種，正是因為它看起來沒問題。

    做法很直接：同一個條號、同一個款號，比對新舊版的條文本體。
    不一樣就把兩邊都列出來，交給人判斷。不自動改。

    引用的解析跟交叉引用同一支（_paragraph_references），不另外寫一套樣式：
    以前這一關自己比對「第X條第X款」，「第一條第二款及第三款」的第三款被當成本條的、
    「第一款至第三款」只看兩端、「第二項第一款」的款也掛不到第二項，
    目與「第五條至第七條」中間的條根本不看，內容換了沒有任何一關會講。
    """
    old_clauses, old_items = _numbered_bodies(old_paragraphs, scan(old_paragraphs, old_kinds))
    entries = scan(new_paragraphs, new_kinds)
    new_clauses, new_items = _numbered_bodies(new_paragraphs, entries)
    entry_by_index = dict((e["index"], e) for e in entries)
    old_paras = dict(((normalize_article_no(a), n), body) for (a, n), body
                     in _paragraph_bodies(old_paragraphs, old_kinds).items())
    new_paras = dict(((normalize_article_no(a), n), body) for (a, n), body
                     in _paragraph_bodies(new_paragraphs, new_kinds).items())
    # 比對用正規化過的，顯示用原文（產出檔一律保留原字）。條號都先正規化：
    # 文件宣告「第一條」、引用寫「第1條」是同一條，照字面查會查不到，內容換了也不報
    old_articles = dict((normalize_article_no(a), b) for a, b in _article_units(old_paragraphs, old_kinds))
    new_articles = dict((normalize_article_no(a), b) for a, b in _article_units(new_paragraphs, new_kinds))
    old_article_texts = dict((normalize_article_no(a), b) for a, b in _article_texts(old_paragraphs, old_kinds))
    new_article_texts = dict((normalize_article_no(a), b) for a, b in _article_texts(new_paragraphs, new_kinds))
    old_article_names = [a for a, _ in _article_texts(old_paragraphs, old_kinds)]
    contexts = build_hierarchy(new_paragraphs, new_kinds)
    # 相對引用（前條、前項、前X款）新舊版各推算一次；「前條第二款」的舊內容也要照舊版的前條取
    cross = cross_version_references(old_paragraphs, new_paragraphs, old_kinds, new_kinds)
    article_map = cross["article_map"]

    def article_changed(article):
        key = normalize_article_no(article)
        return old_articles.get(key) is not None and old_articles[key] != new_articles.get(key)

    findings = []
    for idx, (text, context) in enumerate(zip(new_paragraphs, contexts), 1):
        if "第" not in text:
            continue
        entry = entry_by_index.get(idx, {})
        for ref in _paragraph_references(text, context, entry, contexts, idx):
            if ref.get("external") or ref.get("relative") or not ref.get("article"):
                continue          # 別人家的法條；前條、前項、前X款由 cross 比

            if ref.get("range_inner"):
                inner = _articles_between(old_article_names, *ref["range_inner"]) or []
                inner = [a for a in inner if article_changed(a)]
                if inner:
                    keys = [normalize_article_no(a) for a in inner]
                    findings.append(_drift_item(
                        idx, text, ref["raw"], "、".join(inner),
                        [old_article_texts.get(k) or "" for k in keys],
                        [new_article_texts.get(k) for k in keys], *ref["span"]))
                continue

            if ref["kind"] == "條":
                if _MORE_OF_THE_CHAIN_RE.match(text, ref["span"][1]):
                    continue      # 「第五條第二款」看的是第二款
                if article_changed(ref["article"]):
                    key = normalize_article_no(ref["article"])
                    findings.append({
                        "index": idx, "text": text, "quote": text[ref["span"][0]:ref["span"][1]],
                        "target": ref["article"],
                        "old_body": old_article_texts.get(key), "new_body": new_article_texts.get(key),
                        "start": ref["span"][0], "end": ref["span"][1],
                    })
                continue

            if not ref.get("numbers"):
                continue          # 「各款」指全部；解析不出來的交叉引用那一關會列

            scope = ref.get("scope_span")
            start = ref.get("chain_start")
            if start is None:
                start = scope[0] if scope and scope[1] == ref["span"][0] else ref["span"][0]
            if is_external_reference(text, start):
                continue          # 「個人資料保護法第五條第三款」不是本文的款

            target_article = ref["article"]
            old_article = target_article
            if ref.get("scope_relative") and article_map:
                # 舊版的內容要照舊版的「前條」取：這一段所在的條在舊版的前一條。以前新舊兩邊
                # 都拿新版的前一條去查，刪掉一條之後比的根本不是同一條。這一條是新版才有的，
                # 引用是照新版寫的，沒有「舊版指什麼」可比。
                own_old, old_prev = _old_previous_articles(context["article"], 1, article_map)
                if own_old is None or not old_prev:
                    continue
                old_article = old_prev[0]

            unit = ref["kind"]
            old_key, new_key = normalize_article_no(old_article), normalize_article_no(target_article)
            para, explicit = ref.get("para"), ref.get("para_explicit")
            clause = ref.get("clause")
            if clause is None and _same_article(target_article, ref.get("own_article") or ""):
                clause = entry.get("clause_written")
            labels, olds, news = [], [], []
            for number in ref["numbers"]:
                if unit == "項":
                    old_body, new_body = old_paras.get((old_key, number)), new_paras.get((new_key, number))
                elif unit == "款":
                    old_body = _bodies_at(old_clauses, old_key, para, explicit, (number,))
                    new_body = _bodies_at(new_clauses, new_key, para, explicit, (number,))
                else:
                    old_body = _bodies_at(old_items, old_key, para, explicit, (clause, number))
                    new_body = _bodies_at(new_items, new_key, para, explicit, (clause, number))
                if old_body is None or old_body == new_body:
                    continue
                labels.append(_NUM_IN_TOKEN.search(ref["token"]).group(0) if len(ref["numbers"]) == 1
                              else int_to_cn(number))
                olds.append(old_body if unit == "項" else "；".join(old_body))
                news.append(new_body if unit == "項" or new_body is None else "；".join(new_body))
            if labels:
                upper = "第%s項" % int_to_cn(para) if explicit else ""
                if unit == "目" and ref.get("clause") is not None:
                    upper += "第%s款" % int_to_cn(ref["clause"])
                findings.append(_drift_item(
                    idx, text, text[start:ref["span"][1]],
                    "%s%s第%s%s" % (target_article, upper, "、".join(labels), unit),
                    olds, news, start, ref["span"][1]))
    # 相對引用（單獨的前條、前項、前X款）指到同一個、內容卻改了：上面的不看這幾種寫法
    findings += cross["drift"]
    findings.sort(key=lambda item: (item["index"], item.get("start") or 0))
    return dedupe_drift(findings, [])


# ---------------------------------------------------------------------------
# 輸出
# ---------------------------------------------------------------------------

# ---------------------------------------------------------------------------
# 章節引用：「依第三章第二節規定」
# ---------------------------------------------------------------------------
# 沒有「第X條」的要點、手冊，本文裡互相引用寫的是章節（「第三章第二節」「本章第二節」），
# 上面那套以條為錨點的引用檢查一個都抓不到。新增、刪除或搬動一章一節之後，後面的
# 章節整批換號，引用就指到別的地方——跟條號位移是同一種問題，只是換了一層。
# 做法：新舊版各排一份章節目錄，用標題把舊章節對到新章節，看出誰換了號、誰被刪了；
# 再掃新版本文裡的章節引用，照舊編號解讀（沒改過的段落一定是照舊編號寫的），
# 目標換了號就列出建議的新寫法，目標沒了就列成必須人工處理。只列不改。

_HEADING_NO_RE = re.compile(r"^第\s*([%s\d０-９]+)\s*[章節]" % CN)
# 漏了「第」的章標題（build_hierarchy 已照章號接續認成章，見 _common._BARE_CHAPTER_RE）
_BARE_CHAPTER_HEAD_RE = re.compile(r"^\s*([%s\d]+)\s*章" % CN)
_OUTLINE_NUM = r"[%s\d０-９]+" % CN
# 一串章節引用的開頭：「第三章」「第二節」「本章第二節」
_OUTLINE_START_RE = re.compile(r"(?P<this_ch>本章)?第\s*(?P<n>%s)\s*(?P<unit>[章節])" % _OUTLINE_NUM)
# 章名、節名可以夾在中間：「第三章陳報作業第二節保存期限二、」。名稱最多 24 字，碰到標點、
# 「、」或下一個「第」就停——「第二章、第三章」是兩個引用，不是一串。
_OUTLINE_GAP = r"[^，,。；;：:、第\n]{0,24}?"
_CHAIN_SECTION_RE = re.compile(r"%s第\s*(?P<n>%s)\s*節" % (_OUTLINE_GAP, _OUTLINE_NUM))
# 節（或章）底下的點：「二、」或「第二款」
_CHAIN_POINT_RE = re.compile(r"%s(?:(?P<cn>[%s]+)\s*、|第\s*(?P<kuan>%s)\s*款)"
                             % (_OUTLINE_GAP, CN, _OUTLINE_NUM))
# 「第三章第一節及第二節」：連接詞後面的「第二節」接著前一串的章；「第三章第一節規定及第二節」也是。
# 同本與跨本（batch._parse_outline）共用，兩邊才認得一樣的寫法。比對的字可能已經去掉空白
_OUTLINE_CONJ_RE = re.compile(r"^\s*(?:%s\s*(?:以及|暨|[及或與和、])|(?P<range>至))\s*$" % CITATION_FILLER)
# 章節引用前面緊接著別本的名稱（「依招攬作業要點第三章」「作業手冊中之第一章」）：
# 那是別本的章節，本程式沒有那一本的新舊版，不判。「本要點」「本手冊」是自己，照判。
# 「…篇」要三個字以上才算書名（「消費者保護篇」）：「本篇」「上篇」不是別本（v1.57.0，審查一高：不認篇名時，
# 別本的「第三章」被當成自己的章照新章號換，給出「第三章→第四章」的錯建議）
_OTHER_BOOK_BEFORE_RE = re.compile(
    r"(?<!本)[一-鿿]*(?:手冊|要點|辦法|規則|準則|須知|規範|細則|法|條例|規定|[一-鿿]{2}篇)"
    r"[」』》\"'\s]*(?:中之|之|中)?\s*$")
# 目錄行尾巴的點線與頁碼（「第一章 總則……3」），標題比對前要拿掉
_TOC_TAIL_RE = re.compile(r"[\s\.．·…‥_－\-]*[0-9０-９]*\s*$")
# 「第一章第一節一、及二、」：點後面接著的點，沒有「第」開頭。
# 「一、二、」的頓號就在號碼裡，所以中文點的連接詞可以沒有；「第一款及第二款」要有
# 連接詞前面可以夾引用的修飾語（「一、規定及二、」），這時連接詞不能省
_MORE_POINT_RE = re.compile(r"(?:(?P<to1>至)|%(filler)s(?:以及|及|與|和|或|暨))?\s*(?P<cn>[%(cn)s]+)\s*、"
                            r"|(?:(?P<to2>至)|%(filler)s(?:以及|、|及|與|和|或|暨))\s*(?P<full>第\s*(?P<kuan>%(num)s)\s*款)"
                            % {"cn": CN, "num": _OUTLINE_NUM, "filler": CITATION_FILLER})
# 「第一章第一節一至三、」：號碼寫在同一個頓號前面的範圍，前面那個號碼後面沒有頓號
_POINT_RANGE_HEAD_RE = re.compile(r"^\s*([%s]+)\s*至\s*$" % CN)


# 「依本要點」「依本作業手冊」是這份文件自己，不是別本。_OTHER_BOOK_BEFORE_RE 的 (?<!本)
# 只擋得住緊貼在字尾前的「本」，「依本要點第三章」照樣被當成別本的章節跳過不檢查。
# 法規字尾那幾種用 _common.is_own_law_name（跟外部法規判定同一條規則）；手冊、須知、規定
# 不在它的字尾表裡，這裡補一條同樣寫法的。
_OWN_BOOK_EXTRA_RE = re.compile(
    r"(?:^|(?<=[^一-鿿])|(?<=[依按照據及與和或、]))本(?!公司|行|國)[一-鿿]{0,6}?(?:手冊|須知|規定|篇)$")
_BOOK_TAIL_RE = re.compile(r"[」』》\"'\s]*(?:中之|之|中)?\s*$")
_COVER_VOLUME_RE = re.compile(r"(?:([壹貳參肆伍陸柒捌玖拾]+)\s*[、．.])?\s*([一-鿿]{2,}篇)\s*$")
# 「保險代理業務手冊參、第一章」：篇只寫號碼。要接在手冊、篇名後面才算，「壹、第一章」可能是自己的段落編號
_VOLUME_NUMBER_BEFORE_RE = re.compile(r"(?:手冊|[一-鿿]{2}篇)[」』》\"'\s]*([壹貳參肆伍陸柒捌玖拾]+)\s*[、．.]\s*$")
_CLAUSE_STOP_RE = re.compile(r"[，,。；;]")


def _own_volume_names(paragraphs):
    """封面寫的這一份自己的篇號、篇名（「參、人員管理篇」→ 參、人員管理篇）：寫自己的篇引自己的章，不是別本。"""
    names = set()
    for text in paragraphs[:10]:
        found = _COVER_VOLUME_RE.search(text or "")
        if found:
            names.update(value for value in found.groups() if value)
    return tuple(names)


def _other_book_before(before, own_volumes=()):
    """章節引用前面緊接著的是不是別本的名稱（是自己這一份就不算）。"""
    number = _VOLUME_NUMBER_BEFORE_RE.search(before)
    if number:
        return number.group(1) not in own_volumes
    match = _OTHER_BOOK_BEFORE_RE.search(before)
    if not match:
        return False
    name = _BOOK_TAIL_RE.sub("", match.group(0))
    return not (is_own_law_name(name) or _OWN_BOOK_EXTRA_RE.search(name) or name.endswith(own_volumes))


def _continues_other_book(text, citation, other_end):
    """緊接在別本章節後面的這一串也是別本的：「人員管理篇第一章…、第四節…」的第四節沒寫章，
    以前被當成自己這一章；「消費者保護篇第三章及第二章」的第二章也一樣。本章開頭的是自己的。"""
    if other_end is None or citation["this_ch"]:
        return False
    if _OTHER_BOOK_BEFORE_RE.search(text[max(0, citation["start"] - 20):citation["start"]]):
        return False                  # 自己寫了名稱（「本手冊第二節」）：前一關已經判過不是別本
    between = text[other_end:citation["start"]]
    if _OUTLINE_CONJ_RE.match(between):
        return True
    bare = not any(level == "章" for level, _value, _span in citation["parts"])
    return bare and not _CLAUSE_STOP_RE.search(between)


def _outline_bodies(paragraphs, kinds=None):
    """每一章、每一節底下的內文（正規化後串起來）：{(章, 0): …, (章, 節): …}。標題本身不算。"""
    bodies = {}
    for text, context in zip(paragraphs, build_hierarchy(paragraphs, kinds)):
        if context["level"] in ("章", "節"):
            continue
        chapter = _HEADING_NO_RE.match(context.get("chapter") or "")
        if not chapter:
            continue
        ch = cn_to_int(chapter.group(1)) or 0
        section = _HEADING_NO_RE.match(context.get("section") or "")
        sec = (cn_to_int(section.group(1)) or 0) if section else 0
        piece = normalize_for_compare(text)
        bodies.setdefault((ch, 0), []).append(piece)
        if sec:
            bodies.setdefault((ch, sec), []).append(piece)
    return dict((k, "\n".join(v)) for k, v in bodies.items())


SNIPPET_FULL_CHARS = 4000       # 兩邊加起來不到這麼多字才整段比
SNIPPET_WINDOW = 600            # 長文從第一處不同往後比幾個字


@functools.lru_cache(maxsize=20000)
def _diff_snippet(old, new, width=12):
    """兩段文字第一處不一樣的地方，前後各帶幾個字：(舊的那一截, 新的那一截)。
    傳進來的是整章：長文先跳過一樣的開頭、只比後面一小段（v1.60.2）。整章逐字比，字數加倍時間變四倍，
    10 萬字的章一次要半分鐘；要的只是第一處不同，而且畫面只留 40 字。"""
    old, new = old or "", new or ""
    start, part_old, part_new = 0, old, new
    if len(old) + len(new) > SNIPPET_FULL_CHARS:
        limit = min(len(old), len(new))
        while start < limit and old[start] == new[start]:
            start += 1
        part_old, part_new = old[start:start + SNIPPET_WINDOW], new[start:start + SNIPPET_WINDOW]
    matcher = difflib.SequenceMatcher(None, part_old, part_new, autojunk=False)
    for tag, i1, i2, j1, j2 in matcher.get_opcodes():
        if tag != "equal":
            i1, i2, j1, j2 = i1 + start, i2 + start, j1 + start, j2 + start
            return (clip_body(old[max(0, i1 - width):i2 + width], 40),
                    clip_body(new[max(0, j1 - width):j2 + width], 40))
    return "", ""


def _outline_title(text):
    title = _HEADING_NO_RE.sub("", text, count=1)
    if title == text:
        title = _BARE_CHAPTER_HEAD_RE.sub("", text, count=1)      # 漏了「第」的章標題：標題一樣要拿得出來
    return normalize_for_compare(_TOC_TAIL_RE.sub("", title))


def outline_units(paragraphs, kinds=None):
    """全文的章節目錄：{(章號, 節號或 0): (標題, 段次)}。

    同一個章節號出現兩次時，後面的蓋掉前面的：文件開頭的目錄在前、本文的標題在後，
    要的是本文那一個。"""
    units = {}
    for idx, (text, context) in enumerate(zip(paragraphs, build_hierarchy(paragraphs, kinds)), 1):
        if context["level"] not in ("章", "節"):
            continue
        match = _HEADING_NO_RE.match(text)
        if not match and context["level"] == "章":
            match = _BARE_CHAPTER_HEAD_RE.match(text)
        number = cn_to_int(match.group(1)) if match else None
        if number is None:
            continue
        if context["level"] == "章":
            key = (number, 0)
        else:
            chapter = _HEADING_NO_RE.match(context.get("chapter") or "")
            key = ((cn_to_int(chapter.group(1)) or 0) if chapter else 0, number)
        units[key] = (_outline_title(text), idx)
    return units


def plan_outline_map(old_units, new_units):
    """舊章節 → 新章節：{舊 key: 新 key，被刪掉的是 None}。

    先用標題對（標題在新舊版各只出現一次才算數），對不到的再退回「同一個號碼、
    新版那一個也還沒被別人認走」＝只改了標題。節先在對到的那一章裡找同標題，
    找不到再看全文（整節搬到別章）。"""
    mapping = {}
    used = set()

    def pick(key, candidates):
        free = [c for c in candidates if c not in used]
        if len(free) == 1:
            mapping[key] = free[0]
            used.add(free[0])
            return True
        return False

    def titled(units, keys, title):
        return [k for k in keys if units[k][0] == title]

    old_chapters = sorted(k for k in old_units if k[1] == 0)
    new_chapters = sorted(k for k in new_units if k[1] == 0)
    for key in old_chapters:
        title = old_units[key][0]
        if title and len(titled(old_units, old_chapters, title)) == 1:
            pick(key, titled(new_units, new_chapters, title))
    for key in old_chapters:
        if key not in mapping and not pick(key, [key] if key in new_units else []):
            mapping[key] = None

    old_sections = sorted(k for k in old_units if k[1])
    new_sections = sorted(k for k in new_units if k[1])
    for key in old_sections:
        title = old_units[key][0]
        if not title:
            continue
        chapter = mapping.get((key[0], 0))
        home = [k for k in new_sections if chapter and k[0] == chapter[0]]
        if not pick(key, titled(new_units, home, title)):
            if len(titled(old_units, old_sections, title)) == 1:
                pick(key, titled(new_units, new_sections, title))
    for key in old_sections:
        if key in mapping:
            continue
        chapter = mapping.get((key[0], 0))
        same = (chapter[0] if chapter else key[0], key[1])
        if not pick(key, [same] if same in new_units else []):
            mapping[key] = None
    return mapping


def _outline_text(key, point=None):
    chapter, section = key
    text = ("第%s章" % cn_from_int(chapter) if chapter else "") + \
        ("第%s節" % cn_from_int(section) if section else "")
    return text + ("%s、" % cn_from_int(point) if point else "")


def outline_points(paragraphs, kinds=None):
    """沒有「第X條」的文件裡，每一章（或節）底下的點：{(章號, 節號或 0): [(號碼, 本體), ...]}。"""
    points = {}
    for text, context in zip(paragraphs, build_hierarchy(paragraphs, kinds)):
        if context["level"] != "款" or context.get("article"):
            continue
        match = _CLAUSE_RE.match(text)
        if not match:
            continue
        chapter = _HEADING_NO_RE.match(context.get("chapter") or "")
        section = _HEADING_NO_RE.match(context.get("section") or "")
        key = ((cn_to_int(chapter.group(1)) or 0) if chapter else 0,
               (cn_to_int(section.group(1)) or 0) if section else 0)
        body = normalize_for_compare(_CLAUSE_RE.sub("", text, count=1))
        points.setdefault(key, []).append((cn_to_int(match.group(1)), body))
    return points


def plan_point_map(old_points, new_points, mapping):
    """舊的點 → 新的點：{(舊章節 key, 舊號碼): (新章節 key, 新號碼)，被刪的是 None}。

    在對到的那一個章節裡用內容對（內容一模一樣、而且只有一個），對不到的退回同一個號碼
    （內容改過、號碼沒動），再對不到就是被刪了。"""
    point_map = {}
    for key, olds in old_points.items():
        target = mapping.get(key, key)
        news = new_points.get(target, []) if target else []
        used = set()
        for number, body in olds:
            same = [n for n, b in news if b == body and n not in used]
            if body and len(same) == 1:
                point_map[(key, number)] = (target, same[0])
                used.add(same[0])
        numbers = set(n for n, _ in news)
        for number, _ in olds:
            if (key, number) in point_map:
                continue
            if target and number in numbers and number not in used:
                point_map[(key, number)] = (target, number)
                used.add(number)
            else:
                point_map[(key, number)] = None
    return point_map


def _outline_citations(text):
    """一段裡的章節引用，每一串是 {start, end, this_ch, parts}；parts 是
    [(層級, 號碼, 號碼在原文的起訖), ...]，層級是 章／節／點，照原文順序。"""
    found = []
    pos = 0
    while True:
        match = _OUTLINE_START_RE.search(text, pos)
        if not match:
            return found
        parts = [(match.group("unit"), cn_to_int(match.group("n")), match.span("n"))]
        end = match.end()
        if match.group("unit") == "章":
            section = _CHAIN_SECTION_RE.match(text, end)
            if section:
                parts.append(("節", cn_to_int(section.group("n")), section.span("n")))
                end = section.end()
        point = _CHAIN_POINT_RE.match(text, end)
        if point:
            group = "cn" if point.group("cn") else "kuan"
            head = _POINT_RANGE_HEAD_RE.match(text[end:point.start(group)]) if group == "cn" else None
            if head:
                # 「一至三、」：這一串停在「一」，「至三、」由 _more_points 接成範圍
                parts.append(("點", cn_to_int(head.group(1)), (end + head.start(1), end + head.end(1))))
                end += head.end(1)
            else:
                parts.append(("點", cn_to_int(point.group(group)), point.span(group)))
                end = point.end()
        found.append({"start": match.start(), "end": end,
                      "this_ch": bool(match.group("this_ch")), "parts": parts})
        pos = end


def _more_points(text, citation):
    """citation 結尾接著的點（「第一章第一節一、及二、」的「二、」）：跟 citation 同格式的 list，
    parts 只有「點」那一層；label 是給人看的全名，只寫「二、」看不出是哪裡的二。
    用「至」接的（「一、至三、」）多帶 range_from：範圍開頭的號碼，中間的點見 outline_range_problem。
    同本（scan_outline_references）與跨本（batch._parse_outline）共用，兩邊答案才一樣。"""
    points = [p for p in citation["parts"] if p[0] == "點"]
    if not points:
        return []
    head = text[citation["start"]:points[0][2][0]].rstrip("第")
    out, end = [], citation["end"]
    previous = points[0][1]
    while True:
        more = _MORE_POINT_RE.match(text, end)
        written = (more.group("cn") or more.group("kuan")) if more else None
        value = cn_to_int(unicodedata.normalize("NFKC", written)) if written else None
        if not value:
            return out
        group, start = ("cn", more.start("cn")) if more.group("cn") else ("kuan", more.start("full"))
        out.append({"start": start, "end": more.end(), "this_ch": False, "parts": [("點", value, more.span(group))],
                    "label": head + text[start:more.end()],
                    "range_from": previous if more.group("to1") or more.group("to2") else None})
        end, previous = more.end(), value


def outline_range_problem(raw, first, last, inner, lookup, fresh, shown):
    """範圍夾在中間的單位有事就回 (狀態, 說明, 端點照換)，沒事回 None。規則跟條的範圍（_judge_article_range）一樣。
    端點照換：範圍本身還成立、只是裡面多了新的單位，兩端的換號可以給建議；其他情況範圍要重寫，不給。

    raw：原文那一截。first、last：範圍兩端的舊號；inner：舊版夾在中間的單位。
    lookup(舊)→新版的位置（被刪回 None）。fresh：新版才有的單位。shown(單位)→給人看的寫法。
    兩端自己被刪或換號另外照一般判，這裡只看中間；兩端被刪時先照原號算。"""
    if first >= last:
        return "無法判定", "解析不出「%s」這個範圍涵蓋哪些，請人工確認" % raw, False
    lost = [unit for unit in inner if not lookup(unit)]
    if lost:
        return "危險", "「%s」涵蓋的%s新版已經沒有了，範圍要怎麼寫必須人工確認" % (
            raw, "、".join(shown(unit) for unit in lost)), False
    new_first, new_last = lookup(first) or first, lookup(last) or last
    out = [unit for unit in inner if not new_first < lookup(unit) < new_last]
    if out:
        return "危險", "「%s」涵蓋的%s搬到範圍外了（新版是%s），範圍要怎麼寫必須人工確認" % (
            raw, shown(out[0]), shown(lookup(out[0]))), False
    added = sorted(unit for unit in fresh if new_first < unit < new_last)
    if added:
        return "無法判定", "「%s」的範圍裡多了新版才有的%s，請人工確認這個範圍要不要包含它" % (
            raw, "、".join(shown(unit) for unit in added)), True
    return None


def range_rewrite(text, start, end, ends):
    """範圍裡的兩端都換得清楚時，text[start:end] 換完的樣子；有一端指不到（危險、無法判定）或根本沒換回空字串。
    ends：[{status, start, end, new_quote}]，位置是 text 的位置。同本、跨本共用。"""
    changed = [e for e in ends if e["status"] == "需改寫" and e.get("new_quote")]
    if not changed or any(e["status"] in ("危險", "無法判定") or (e["status"] == "需改寫" and not e.get("new_quote"))
                          for e in ends):
        return ""
    out = text[start:end]
    for item in sorted(changed, key=lambda e: -e["start"]):
        out = out[:item["start"] - start] + item["new_quote"] + out[item["end"] - start:]
    return out


def range_end_note(note, ends, shown=None):
    """範圍合成一筆時，兩端換號的資訊留在說明裡：人重寫範圍時看得到新號。shown(一端)→那一端原文。"""
    moves = ["「%s」→「%s」" % (shown(e) if shown else e["quote"], e["new_quote"]) for e in ends
             if e["status"] == "需改寫" and e.get("new_quote")]
    return "%s（兩端換號：%s）" % (note, "、".join(moves)) if moves else note


def outline_point_range_problem(raw, key, first, last, old_numbers, point_map, new_numbers):
    """「第一章第一節一、至三、」夾在中間的點。old_numbers／new_numbers：舊版、新版那個章節底下有哪些號碼。"""
    def lookup(number):
        mapped = point_map.get((key, number))
        return mapped[1] if mapped else None

    carried = set(lookup(number) for number in old_numbers)
    return outline_range_problem(raw, first, last, sorted(n for n in old_numbers if first < n < last), lookup,
                                 set(new_numbers) - carried, lambda number: "%s、" % cn_from_int(number))


def outline_unit_range_problem(raw, first, last, old_units, mapping, new_units):
    """「第一節至第三節」「第二章至第四章」夾在中間的章節。first、last 是舊版的 (章, 節)，層級不同就不看。"""
    def same_level(key, chapter):
        return bool(key[1]) == bool(first[1]) and (not key[1] or key[0] == chapter)

    if not same_level(last, first[0]):
        return None
    carried = set(mapping.get(key) for key in old_units)
    target = mapping.get(first) or first
    fresh = set(key for key in new_units if key not in carried and same_level(key, target[0]))
    inner = sorted(key for key in old_units if same_level(key, first[0]) and first < key < last)
    return outline_range_problem(raw, first, last, inner, mapping.get, fresh, _outline_text)


SELF_CHANGED_NOTE = "；這一段本次也改過，引用如果已經照新編號改好就不用動"


def _outline_point_spans(text):
    """一段裡寫到「點」那一層的章節引用（連接在後面的也算）在原文的起訖。"""
    spans = []
    for citation in _outline_citations(text):
        if any(part[0] == "點" for part in citation["parts"]):
            spans.append((citation["start"], citation["end"]))
            spans.extend((extra["start"], extra["end"]) for extra in _more_points(text, citation))
    return spans


def _rewrite_citation(text, citation, numbers, chapter_prefix=None):
    """照 numbers（層級 → 新號碼）改寫一串引用；阿拉伯數字寫的照樣寫阿拉伯數字。
    chapter_prefix：「本章第二節」「第二節」要補章號時的新章號。"""
    out = text[citation["start"]:citation["end"]]
    base = citation["start"]
    for level, _, (s, e) in sorted(citation["parts"], key=lambda p: -p[2][0]):
        written = text[s:e]
        value = numbers[level]
        new = str(value) if unicodedata.normalize("NFKC", written).isdigit() else cn_from_int(value)
        out = out[:s - base] + new + out[e - base:]
    if chapter_prefix:
        out = "第%s章" % cn_from_int(chapter_prefix) + (out[2:] if citation["this_ch"] else out)
    return out


def scan_outline_references(old_paragraphs, new_paragraphs, old_kinds=None, new_kinds=None,
                            drift=None):
    """新版本文裡的章節引用，目標換號或被刪的列出來。

    認得的寫法：「第三章第二節」「第三章」「本章第二節」「第二節」，章名節名夾在中間的
    「第三章陳報作業第二節保存期限」，以及接在後面的點「…第二節保存期限二、」「…第二款」。

    回傳 (moved, findings)：moved 是換了號或被刪的章節與點的數目（0＝都沒動，
    不用往下看）；findings 每一筆是 {index, text, quote, status, new_quote, note}，
    status 是「需改寫」（目標換了號）、「危險」（目標被刪了）或「無法判定」。

    drift（選填，list）：章節號沒變、但那一章節（或那一點）的內容這次改了的引用，
    照 scan_reference_drift 的格式加進去（「依第三章第二節所定期限」而第二節的期限改了，
    引用的那一段要重看；以前章節沒換號就整個不看，C8b）。不給就跟以前一樣。
    """
    old_units = outline_units(old_paragraphs, old_kinds)
    new_units = outline_units(new_paragraphs, new_kinds)
    mapping = plan_outline_map(old_units, new_units)
    old_points = outline_points(old_paragraphs, old_kinds)
    new_points = outline_points(new_paragraphs, new_kinds)
    point_map = plan_point_map(old_points, new_points, mapping)
    moved = (sum(1 for k, v in mapping.items() if v != k)
             + sum(1 for k, v in point_map.items() if v != k))
    if not moved and drift is None:
        return 0, []
    own_volumes = _own_volume_names(new_paragraphs)
    old_bodies = _outline_bodies(old_paragraphs, old_kinds) if drift is not None else {}
    new_bodies = _outline_bodies(new_paragraphs, new_kinds) if drift is not None else {}
    back = dict((v, k) for k, v in mapping.items() if v)
    changed = find_changed_paragraphs(old_paragraphs, new_paragraphs, old_kinds, new_kinds)
    contexts = build_hierarchy(new_paragraphs, new_kinds)

    findings = []
    for idx, (text, context) in enumerate(zip(new_paragraphs, contexts), 1):
        here = _HEADING_NO_RE.match(context.get("chapter") or "")
        here_new = (cn_to_int(here.group(1)) or 0) if here else 0
        previous = None       # 同一段前一串引用：(結尾位置, 舊章號, 舊章節 key, 開頭位置)

        def range_replaces_ends(start, end, status, note, keep_ends):
            """範圍中間有事：整串合成一筆（range），進決定表。中間被刪、搬走時兩端不能只照換（看起來像改好了，
            意思已經變了），不給建議；只是範圍裡多了新的單位時，兩端的換號還算數，照換給建議、請人確認要不要包含新的。"""
            ends = [f for f in findings if f["index"] == idx and start <= f["start"] and f["end"] <= end]
            findings[:] = [f for f in findings if not any(f is e for e in ends)]
            new_quote = range_rewrite(text, start, end, ends) if keep_ends else ""
            if any(SELF_CHANGED_NOTE in e["note"] for e in ends):
                note += SELF_CHANGED_NOTE
            findings.append({"index": idx, "text": text, "quote": text[start:end], "status": status,
                             "new_quote": new_quote, "note": range_end_note(note, ends), "start": start, "end": end,
                             "range": True, "advisory": bool(keep_ends and not new_quote)})

        def judge_range(citation, extra, key, first, last):
            """「一、至三、」：兩端判過了，這裡看夾在中間的點。"""
            start, end = citation["start"], extra["end"]
            target = mapping.get(key, key)
            if key not in old_units or target is None:
                return
            old_numbers = [n for n, _ in old_points.get(key, [])]
            problem = outline_point_range_problem(text[start:end], key, first, last, old_numbers, point_map,
                                                  [n for n, _ in new_points.get(target, [])])
            if problem:
                range_replaces_ends(start, end, *problem)
            elif drift is not None and target == key:
                for number in old_numbers:
                    if first < number < last:
                        _outline_drift(drift, idx, text, {"start": start, "end": end}, text[start:end], key, number,
                                       _outline_text(key, number), here_new, context, old_bodies, new_bodies,
                                       old_points, new_points)

        def judge(citation, key, point, bare, inherited, follows=False):
            """判一串引用。follows：接在前一串後面的點（「二、及三、」的「三、」），章節跟著前一串。"""
            start = citation["start"]
            quote = text[start:citation["end"]]

            def add(item, start=start, end=citation["end"]):
                # 在原文的起訖位置：決定表的「建議改法」照位置改寫，同一段兩處引用才不會互相改到
                item.update(start=start, end=end)
                findings.append(item)
            label = _outline_text(key, point)

            if key not in old_units and key != (0, 0):
                if follows or key in new_units or (bare and (here_new, key[1]) in new_units):
                    return        # 新寫的引用，照新編號寫、而且找得到；接在後面的由前一串講過了
                add({"index": idx, "text": text, "quote": quote,
                                 "status": "無法判定", "new_quote": "",
                                 "note": "新舊版都找不到%s" % _outline_text(key)})
                return
            target = mapping.get(key, key)
            title = old_units.get(key, ("",))[0]
            named = "%s（%s）" % (label, title) if title else label
            if target is None:
                if not follows:
                    add({"index": idx, "text": text, "quote": quote,
                                     "status": "危險", "new_quote": "",
                                     "note": "舊版的%s新版已經沒有了，引用要改指別處或刪掉" % named})
                return
            new_point = point
            if point:
                if (key, point) not in point_map:
                    if not any(n == point for n, _ in new_points.get(target, [])):
                        add({"index": idx, "text": text, "quote": quote,
                                         "status": "無法判定", "new_quote": "",
                                         "note": "新舊版的%s底下都找不到%s、"
                                                 % (_outline_text(key), cn_from_int(point))})
                    return
                mapped = point_map[(key, point)]
                if mapped is None:
                    add({"index": idx, "text": text, "quote": quote,
                                     "status": "危險", "new_quote": "",
                                     "note": "舊版的%s新版已經沒有了，引用要改指別處或刪掉" % named})
                    return
                new_point = mapped[1]
            if target == key and new_point == point:
                if drift is not None:
                    _outline_drift(drift, idx, text, citation, quote, key, point, named, here_new,
                                   context, old_bodies, new_bodies, old_points, new_points)
                return
            if inherited and target[1] == key[1] and new_point == point:
                return            # 章號跟著前一串改就好，這一串自己的節、點沒動
            renumbered = {"章": target[0], "節": target[1], "點": new_point}
            # 接在後面的點只有號碼，章節由前一串寫：補章號會變成「第一節一、及第一章二、」
            prefix = target[0] if bare and not inherited and not follows and target[0] != here_new else None
            new_quote = _rewrite_citation(text, citation, renumbered, prefix)
            if new_quote == quote:
                return            # 「本章第二節」：章跟著這一段一起換號、節號沒變，寫法不用動
            note = "舊版的%s新版是%s" % (named, _outline_text(target, new_point))
            if idx in changed:
                note += SELF_CHANGED_NOTE
            add({"index": idx, "text": text, "quote": quote,
                             "status": "需改寫", "new_quote": new_quote, "note": note})

        other_end = None      # 上一串別本章節的結尾
        for citation in _outline_citations(text):
            start = citation["start"]
            if not text[:start].strip() and (context["level"] in ("章", "節") or _TOC_LINE_RE.search(text)):
                # 段落開頭的章節號是這一段自己的標題，不是引用。目錄行的層級是「其他」
                # （build_hierarchy 不把目錄算成標題），要另外認，不然正確的新目錄會被
                # 當成舊章節的引用，決定表填「改」就把目錄改壞
                previous = None
                continue
            before = text[max(0, start - 20):start]
            if is_external_reference(text, (start, citation["end"])) or \
                    _other_book_before(before, own_volumes) or \
                    _continues_other_book(text, citation, other_end):
                previous = None
                other_end = citation["end"]
                continue          # 別本的章節
            numbers = dict((level, value) for level, value, _ in citation["parts"])
            if None in numbers.values():
                continue
            bare = "章" not in numbers
            inherited = False
            joint = _OUTLINE_CONJ_RE.match(text[previous[0]:start]) if previous else None
            if bare:
                if joint:
                    chapter = previous[1]          # 「第三章第一節及第二節」
                    inherited = True
                else:
                    # 「第二節」「本章第二節」＝這一段所在的那一章；照舊編號解讀要換回舊章號。
                    # 舊版整本沒有章（本來直接分節，這次才分章）：舊章號就是 0，跨本也這樣判
                    chapter = back.get((here_new, 0), (here_new if any(k[0] for k in old_units) else 0, 0))[0]
            else:
                chapter = numbers["章"]
            key = (chapter, numbers.get("節", 0))
            earlier = previous
            previous = (citation["end"], chapter, key, start)
            judge(citation, key, numbers.get("點"), bare, inherited)
            if joint and joint.group("range") and "點" not in numbers and earlier[2] in old_units \
                    and key in old_units:
                # 「第一節至第三節」：夾在中間的節也算被引用
                problem = outline_unit_range_problem(text[earlier[3]:citation["end"]], earlier[2], key,
                                                     old_units, mapping, new_units)
                if problem:
                    range_replaces_ends(earlier[3], citation["end"], *problem)
            for extra in _more_points(text, citation):
                previous = (extra["end"], chapter, key, start)
                judge(extra, key, extra["parts"][0][1], bare, inherited, follows=True)
                if extra["range_from"]:
                    judge_range(citation, extra, key, extra["range_from"], extra["parts"][0][1])
    if not moved:
        return 0, []
    return moved, findings


def _outline_drift(drift, idx, text, citation, quote, key, point, named, here_new, context,
                   old_bodies, new_bodies, old_points, new_points):
    """章節號沒變的引用：那一章節（或點）的內容這次改了就記一筆「內容變了」。
    引用寫在那一章節自己裡面的不記（「本章第二節」寫在第二章裡，改的就是它自己那一章）。"""
    here_sec = _HEADING_NO_RE.match(context.get("section") or "")
    here = (here_new, (cn_to_int(here_sec.group(1)) or 0) if here_sec else 0)
    if here[0] == key[0] and (key[1] == 0 or here[1] == key[1]):
        return
    if point:
        old_b = next((b for n, b in old_points.get(key, []) if n == point), None)
        new_b = next((b for n, b in new_points.get(key, []) if n == point), None)
    else:
        old_b, new_b = old_bodies.get(key), new_bodies.get(key)
    if old_b is None or new_b is None or old_b == new_b:
        return
    old_snip, new_snip = _diff_snippet(old_b, new_b)
    drift.append({"index": idx, "text": text, "quote": quote, "target": named,
                  "old_body": old_snip, "new_body": new_snip,
                  "start": citation["start"], "end": citation["end"]})


# ---------------------------------------------------------------------------
# 沒有「第X條」的文件：點的編號（一、／（一）／(1)／1.）與章節標題的編號
# ---------------------------------------------------------------------------
# 以前沒有條的文件整個不查點的編號：手冊裡的點常被程式看不到的小標分組、各自從一起算，
# 用章節分組照樣誤報（真資料 1,347 段誤報 14 處）。現在照查、全部都報，但分兩種講：
#   這次改出來的（舊版同一個地方沒有這個不連續）→ 警告
#   本來就有的（舊版同一個地方就是這樣）          → 提醒，合成一則列出位置
# 「是不是這次改出來的」不能只看旁邊的段落有沒有改：刪掉「二、」之後「一、三、」兩段
# 自己都沒動，所以拿舊版跑同一套檢查，同一個位置、同一串號碼舊版就有，才算本來就有。
# 章節標題（第一章、第三章少了第二章）只報這次改出來的。

_LEVEL_SHOWN = {"款": "一、", "點": "1.", "目": "（一）"}
_TOC_LINE_RE = re.compile(r"(?:[\.．·…‥_]{2,}|\t)\s*[0-9０-９]+\s*$")


def _kind(reason):
    """人看的問題名稱：跳號／重號／沒有從一開始（內部 reason 帶層級名，要點的文件看不懂）。"""
    if reason.startswith("編號重複"):
        return "重號"
    if reason.startswith("沒有從"):
        return "沒有從一開始"
    return "跳號"


def _written_text(problem, numbers):
    level, style = problem["level"], problem.get("style")
    if level == "款":
        return "".join("%s、" % cn_from_int(n) for n in numbers)
    if level == "點":
        return " ".join("%d." % n for n in numbers)
    if style == _ITEM_STYLE_AR:
        return "".join("(%d)" % n for n in numbers)
    return "".join("（%s）" % cn_from_int(n) for n in numbers)


def _point_place(problem):
    """「第二章第一節」「第二章第一節 二、底下」：人拿著回文件找得到的位置。"""
    where = "".join(problem["scope"]) or "全文"
    if problem["level"] != "款" and problem.get("parent"):
        where += " %s、底下" % cn_from_int(problem["parent"])
    return where


def point_numbering_issues(old_paragraphs, new_paragraphs, old_kinds=None, new_kinds=None):
    """沒有「第X條」的文件，點的編號有沒有跳號、重號、沒從一開始。

    回傳 list，每筆是 _numbering_problems 那一筆，多帶：
        this_round  True＝這次改出來的；False＝舊版同一個地方就是這樣
        place／written_text／expected_text  給畫面與提醒用的字"""
    new_entries = scan(new_paragraphs, new_kinds)
    if numbering_check_applicable(new_entries):
        return []          # 有條的文件照舊由 find_numbering_gaps 查
    old_problems = _numbering_problems(scan(old_paragraphs, old_kinds), include_points=True)

    def sign(p, with_place=True):
        base = (p["level"], p.get("style"), tuple(p["written"]))
        return base + ((p["scope"], p.get("parent")) if with_place else ())

    old_exact = set(sign(p) for p in old_problems)
    old_loose = set(sign(p, False) for p in old_problems)
    changed = find_changed_paragraphs(old_paragraphs, new_paragraphs, old_kinds, new_kinds)
    issues = []
    for p in _numbering_problems(new_entries, include_points=True):
        untouched = not (set(p["indices"]) & changed)
        existed = sign(p) in old_exact or (untouched and sign(p, False) in old_loose)
        issues.append(dict(p, this_round=not existed, place=_point_place(p), kind=_kind(p["reason"]),
                           written_text=_window_text(p, p["written"]),
                           expected_text=_window_text(p, p["expected"])))
    return issues


def _window_text(problem, numbers, keep=6):
    """一串太長（整份一路編的要點）就只印出錯那一段前後，其餘用「…」。"""
    if len(numbers) <= keep:
        return _written_text(problem, numbers)
    at = problem.get("at", 0)
    lo, hi = max(0, at - 2), min(len(numbers), at + 3)
    return (("…" if lo else "") + _written_text(problem, numbers[lo:hi])
            + ("…" if hi < len(numbers) else ""))


def _run_problems(numbers):
    """一串標題號碼有什麼問題（重新從一起算的當成另一串，例如文件前面的目錄）。"""
    runs, current = [], []
    for n, idx in numbers:
        if len(current) >= 2 and n == 1:     # 「第一章、第一章」緊接著是重號，不是另一串
            runs.append(current)
            current = []
        current.append((n, idx))
    if current:
        runs.append(current)
    problems = []
    for run in runs:
        written = [n for n, _ in run]
        expected = list(range(1, len(written) + 1))
        if written == expected:
            continue
        if len(set(written)) != len(written):
            reason = "編號重複"
        elif written[0] != 1:
            reason = "沒有從一開始"
        else:
            reason = "編號不連續（中間有缺號）"
        problems.append({"written": written, "expected": expected, "reason": reason,
                         "first_index": run[0][1]})
    return problems


def _heading_problems(paragraphs, kinds=None):
    chapters, sections, order = [], {}, []
    for idx, (text, context) in enumerate(zip(paragraphs, build_hierarchy(paragraphs, kinds)), 1):
        if context["level"] not in ("章", "節") or _TOC_LINE_RE.search(text):
            continue
        match = _HEADING_NO_RE.match(text)
        if not match and context["level"] == "章":
            match = _BARE_CHAPTER_HEAD_RE.match(text)
        number = cn_to_int(match.group(1)) if match else None
        if number is None:
            continue
        if context["level"] == "章":
            chapters.append((number, idx))
        else:
            owner = context.get("chapter") or ""
            if owner not in sections:
                order.append(owner)
            sections.setdefault(owner, []).append((number, idx))
    found = [dict(p, unit="章", owner="") for p in _run_problems(chapters)]
    for owner in order:
        found += [dict(p, unit="節", owner=owner) for p in _run_problems(sections[owner])]
    return found


def heading_numbering_issues(old_paragraphs, new_paragraphs, old_kinds=None, new_kinds=None):
    """章節標題本身的編號（第一章、第三章少了第二章；同一章裡兩個第一節），只回這次改出來的。

    節要比到是哪一章的：舊版第一章本來就跳號，這次第二章也改成同樣的號碼，不是「本來就有」。
    章自己換了號不算新問題，所以舊版的章先換算成新版的章號再比。"""
    mapping = plan_outline_map(outline_units(old_paragraphs, old_kinds),
                               outline_units(new_paragraphs, new_kinds))

    def chapter_no(owner):
        match = _HEADING_NO_RE.match(owner or "")
        return (cn_to_int(match.group(1)) or 0) if match else 0

    old = set()
    for p in _heading_problems(old_paragraphs, old_kinds):
        target = mapping.get((chapter_no(p["owner"]), 0)) if p["unit"] == "節" else None
        old.add((p["unit"], target[0] if target else None, tuple(p["written"])))
    issues = []
    for p in _heading_problems(new_paragraphs, new_kinds):
        if (p["unit"], chapter_no(p["owner"]) if p["unit"] == "節" else None, tuple(p["written"])) in old:
            continue
        shown = lambda nums: "、".join("第%s%s" % (cn_from_int(n), p["unit"]) for n in nums)
        issues.append(dict(p, kind=_kind(p["reason"]),
                           written_text=shown(p["written"]), expected_text=shown(p["expected"]),
                           place=("%s底下的節" % p["owner"]) if p["unit"] == "節" else "章"))
    return issues


def notice_numbering_issues(points, headings, limit=10):
    """點的編號與章節標題的問題走 notices（批次時畫面只剩一行）。"""
    for item in headings:
        nt.notice(nt.WARNING, "章節標題%s　%s：目前「%s」，應為「%s」（第 %d 段起）"
                  % (item["kind"], item["place"], item["written_text"],
                     item["expected_text"], item["first_index"]), "Step 0.5")
    fresh = [p for p in points if p["this_round"]]
    for item in fresh[:limit]:
        nt.notice(nt.WARNING, "點的編號%s（這次改出來的）　%s：目前「%s」，應為「%s」（第 %d 段起）"
                  % (item["kind"], item["place"], item["written_text"],
                     item["expected_text"], item["first_index"]), "Step 0.5")
    if len(fresh) > limit:
        nt.notice(nt.WARNING, "點的編號還有 %d 處這次改出來的問題沒列出來，完整清單見執行紀錄的「編號有問題的地方」"
                  % (len(fresh) - limit), "Step 0.5")
    old = [p for p in points if not p["this_round"]]
    if old:
        shown = "；".join("%s%s「%s」（第 %d 段）" % (p["place"], p["kind"], p["written_text"], p["first_index"])
                         for p in old[:limit])
        more = "；另有 %d 處見執行紀錄" % (len(old) - limit) if len(old) > limit else ""
        nt.notice(nt.REMINDER, "點的編號本來就有跳號或重號（舊版同一個地方就是這樣，這次沒動）%d 處：%s%s。"
                  "有些是被小標分成兩組、其實沒錯，請看一眼" % (len(old), shown, more), "Step 0.5")


# ---------------------------------------------------------------------------
# 同層連帶：增刪一項之後，同一層的引言與相對引用（v1.57.0，審查 H27、H28、H30、H31）
# ---------------------------------------------------------------------------
# 手冊的項多半是 Word 自動編號，中間刪一項後面自動遞補，「本點（三）」「前項」的字沒動、指到的卻換了；
# 段首「方式包括以下二種」底下多了第三種也沒人講。只看新版永遠指得到東西，所以跟條文那一套一樣新舊版各推算一次：
#   舊版指到的那一項，經段落對齊換到新版，跟新版照字面指到的一樣 → 沒事
#   不一樣 → 列進連帶表（舊版那一項被刪 → 【危險】；換了位置 → 給新寫法，「前項」這種不給）
# 引言：舊版寫的項數跟舊版實際項數對得上（這樣才確定它講的是這一串），新版對不上才列。
# 舊版就對不上、或這次沒有增刪的一律不列。只看沒有「第X條」的手冊：條文那一套已經新舊版各推算一次。

_SIBLING_NUM = r"[（(]\s*[%s\d０-９]+\s*[）)]" % CN
_SIBLING_REF_RE = re.compile(r"(?P<scope>本[節款項目點])\s*(?P<nums>%(n)s(?:\s*[、及與和或至]\s*%(n)s)*)"
                             % {"n": _SIBLING_NUM})
_SIBLING_NUM_RE = re.compile(r"(?P<to>至)?\s*[（(]\s*(?P<n>[%s\d０-９]+)\s*[）)]" % CN)
_LIST_INTRO_RE = re.compile(
    r"(?:以下|下列|如下|下述|分為|區分為|劃分為|包括|包含|計有|共有|共計|共分)"
    r"[^，,。；;：:、]{0,24}?(?P<n>[二三四五六七八九十兩\d０-９]+)\s*"
    r"(?P<unit>大類|階段|步驟|原則|部分|種|類|項|款|點|個)")


def _sibling_refs(text):
    """一段裡的相對引用：本點（三）、（四）／本節第二款／前項／前二款。"""
    refs = []
    for match in _SIBLING_REF_RE.finditer(text):
        numbers, ranged = [], False
        for piece in _SIBLING_NUM_RE.finditer(match.group("nums")):
            value = _outline_num(piece.group("n"))
            if not value:
                numbers = []
                break
            if piece.group("to") and numbers and numbers[-1] < value <= numbers[-1] + 30:
                ranged = True
                numbers += list(range(numbers[-1] + 1, value + 1))
            else:
                numbers.append(value)
        if numbers:
            refs.append({"span": match.span(), "quote": match.group(0), "scope": match.group("scope"),
                         "numbers": numbers, "ranged": ranged})
    for match in _OUTLINE_REF_RE.finditer(text):
        if any(ref["span"][0] < match.end() and match.start() < ref["span"][1] for ref in refs):
            continue
        if match.group("prev"):
            count = cn_to_int(match.group("count")) if match.group("count") else 1
            refs.append({"span": match.span(), "quote": match.group(0), "term": match.group("prev"),
                         "count": count or 1})
        elif match.group("scope"):
            units = _outline_chain_units(match.group("chain"))
            # 「本章第三節」是章節引用那一關判的（scan_outline_references），這裡再判一次只會多講一句
            if units and units[0][0] not in ("章", "節"):
                refs.append({"span": match.span(), "quote": match.group(0), "scope": match.group("scope"),
                             "units": units})
    return refs


def _sibling_target(ref, own, index):
    """這個相對引用從 own 這個位置算，指到哪幾個位置；算不出來或有好幾種可能回 None。"""
    if "term" in ref:
        hit = _outline_prev(own, ref["term"], ref["count"], index)
        return hit[1] if hit else None
    levels = _OUTLINE_TERM_LEVELS.get(ref["scope"][1:], ())
    if ref["scope"] == "本點":
        levels += ("款",)             # 見 outline_reference_findings：「一、」底下有 (一) 時這一層排成款
    for depth in range(len(own), 0, -1):
        if own[depth - 1][0] not in levels:
            continue
        base = own[:depth]
        if "units" in ref:
            options = _outline_targets(base, ref["units"], index)
            if options:
                return options[0][1] if len(options) == 1 else None
            continue
        for level in OUTLINE_LEVELS[_level_rank(base[-1][0]) + 1:]:
            targets = [base + ((level, number),) for number in ref["numbers"]]
            if all(target in index for target in targets):
                return targets
    return None


def _sibling_rewrite(ref, expected):
    """「本點（三）、（四）」→ 照舊版的意思換號後的寫法。範圍、上一層不同（搬到別的項底下）就不給。"""
    if ref.get("ranged") or "numbers" not in ref or len(expected) != len(ref["numbers"]):
        return ""
    if len(set(path[:-1] for path in expected)) != 1:
        return ""
    numbers = iter(path[-1][1] for path in expected)

    def swap(piece):
        written, value = piece.group("n"), next(numbers)
        shown = str(value) if unicodedata.normalize("NFKC", written).isdigit() else cn_from_int(value)
        return piece.group(0).replace(written, shown)

    start = ref["quote"].find(_SIBLING_NUM_RE.search(ref["quote"]).group(0).strip())
    return ref["quote"][:start] + _SIBLING_NUM_RE.sub(swap, ref["quote"][start:])


def _list_children(paths, at, own):
    """own 這個位置底下、at 之後的下一層項目：[(那一層的位置, 第一段的序號)]，照出現順序。"""
    children, depth = [], len(own)
    for index in range(at + 1, len(paths)):
        path = paths[index]
        if path[:depth] != own:
            break
        if len(path) <= depth:
            continue
        key = path[depth]
        if children and key[0] != children[0][0][0]:
            continue                  # 第一層以外的層級不算
        if not any(key == seen for seen, _first in children):
            children.append((key, index))
    return children


def _heads_under(index, parent, level):
    """index 裡 parent 底下 level 這一層的項目：[第一段的序號（從 0 算）]。"""
    return [line - 1 for path, line in index.items()
            if len(path) == len(parent) + 1 and path[:-1] == parent and path[-1][0] == level]


def _sibling_sources(old_heads, new_heads, forward, added):
    """這一串項目這次增刪了哪幾項（只記段次，異動的完整資料由 decision_table 對回 results）。"""
    sources = [{"old_index": line + 1} for line in old_heads if line not in forward]
    return sources + [{"new_index": line + 1} for line in new_heads if line in added]


def _intro_number(match):
    written = unicodedata.normalize("NFKC", match.group("n")).replace("兩", "二")
    return int(written) if written.isdigit() else cn_to_int(written)


def scan_sibling_links(old_paragraphs, new_paragraphs, old_kinds=None, new_kinds=None):
    """增刪項目帶到同一層的引言與相對引用（說明見本節開頭）。回傳的每一筆有 index、text、quote、status、note、
    sources（這次增刪的那幾項）；有新寫法的多帶 new_quote，有位置的帶 start、end。"""
    old_ctx = build_hierarchy(old_paragraphs, old_kinds)
    new_ctx = build_hierarchy(new_paragraphs, new_kinds)
    if any(c["level"] == "條" for c in new_ctx) or any(c["level"] == "條" for c in old_ctx):
        return []
    forward = _align_lists([_body_key(t) for t in old_paragraphs], [_body_key(t) for t in new_paragraphs])
    added = set(range(len(new_paragraphs))) - set(forward.values())
    if not added and len(forward) == len(old_paragraphs):
        return []                     # 沒有增刪段落，就沒有東西會遞補
    reverse = dict((new, old) for old, new in forward.items())
    old_paths = [outline_path(c) for c in old_ctx]
    new_paths = [outline_path(c) for c in new_ctx]
    old_index = outline_index(old_ctx)
    new_index = outline_index(new_ctx)
    findings = []

    def add(at, ref_span, quote, status, note, sources, new_quote=""):
        item = {"index": at + 1, "text": new_paragraphs[at], "quote": quote, "status": status, "note": note,
                "sources": sources, "new_quote": new_quote, "span": ref_span,
                "start": ref_span[0], "end": ref_span[1]}
        if not any((f["index"], f["quote"]) == (item["index"], quote) for f in findings):
            findings.append(item)

    for at, text in enumerate(new_paragraphs):
        old_at = reverse.get(at)
        if old_at is None or not new_paths[at] or (new_kinds and at < len(new_kinds) and new_kinds[at] == "cell"):
            continue
        old_text = old_paragraphs[old_at]
        for ref in _sibling_refs(text):
            if ref["quote"] not in old_text:
                continue              # 作者這次重寫了這個引用：是照新版寫的，沒有舊意思可比
            was = _sibling_target(ref, old_paths[old_at], old_index)
            if not was:
                continue
            now = _sibling_target(ref, new_paths[at], new_index) or []
            mapped = [forward.get(old_index[target] - 1) for target in was]
            expected = [None if line is None else new_paths[line] for line in mapped]
            if expected == now:
                continue
            level = was[0][-1][0]
            old_heads = _heads_under(old_index, was[0][:-1], level)
            kept = [path for path in expected if path]
            parent = (now[0] if now else kept[0] if kept else was[0])[:-1]
            new_heads = _heads_under(new_index, parent, level)
            sources = _sibling_sources(old_heads, new_heads, forward, added)
            if None in expected:
                if now == was and all(new_index[target] - 1 in added for target in now):
                    continue          # 同一個位置整項重寫：不是遞補，「內容改了」由 AI 看異動
                gone = "、".join(outline_text(target) for target, path in zip(was, expected) if path is None)
                add(at, ref["span"], ref["quote"], "危險",
                    "舊版指的%s這次刪掉了，新版%s，要改指別處或一起改寫"
                    % (gone, ("照位置變成指%s" % _outline_target_text(now, new_index)) if now else "指不到東西"),
                    sources)
                continue
            then, there = _outline_target_text(was, old_index), _outline_target_text(expected, new_index)
            add(at, ref["span"], ref["quote"], "位移",
                "舊版指的%s，增刪項之後照位置變成指%s，要確認引用有沒有跟著換"
                % (then if then == there else "%s（新版是%s）" % (then, there),
                   _outline_target_text(now, new_index) if now else "不到東西"),
                sources, _sibling_rewrite(ref, expected))
        new_intros = list(_LIST_INTRO_RE.finditer(text))
        if not new_intros:
            continue
        old_intros = list(_LIST_INTRO_RE.finditer(old_text))
        if len(old_intros) != len(new_intros):
            continue
        old_list = _list_children(old_paths, old_at, old_paths[old_at])
        new_list = _list_children(new_paths, at, new_paths[at])
        for old_intro, intro in zip(old_intros, new_intros):
            if _intro_number(old_intro) != len(old_list) or _intro_number(intro) == len(new_list):
                continue
            sources = _sibling_sources([line for _key, line in old_list], [line for _key, line in new_list],
                                       forward, added)
            add(at, intro.span(), intro.group(0), "項數不符",
                "這裡寫「%s」，舊版底下剛好 %d 項，這次增刪後新版有 %d 項，要確認段首的數量有沒有跟著改"
                % (intro.group(0), len(old_list), len(new_list)), sources)
    return findings


def notice_sibling_links(findings, limit=15):
    """同層連帶走 notices：留進 提醒.txt、批次摘要與條文檢查報告。"""
    for item in findings[:limit]:
        nt.notice(nt.WARNING, "同層連帶　第%d段「%s」：%s（已列進連帶決定表）"
                  % (item["index"], item["quote"], item["note"]), "Step 0.5")
    if len(findings) > limit:
        nt.notice(nt.WARNING, "同層連帶還有 %d 處沒列出來，都在連帶決定表" % (len(findings) - limit), "Step 0.5")


def notice_outline_references(findings, limit=15):
    """章節引用的問題走 notices：批次時畫面只剩一行，要留進 提醒.txt 與批次摘要才看得到。"""
    for item in findings[:limit]:
        if item["status"] == "需改寫":
            line = "第%d段引用「%s」要改成「%s」：%s" % (
                item["index"], item["quote"], item["new_quote"], item["note"])
        else:
            line = "第%d段引用「%s」：%s" % (item["index"], item["quote"], item["note"])
        level = nt.REMINDER if item["status"] == "無法判定" else nt.WARNING
        if item.get("new_quote"):
            line += "（已列進連帶決定表，報告上有建議改法）"
        elif item["status"] != "無法判定" or item.get("range"):
            line += "（已列進連帶決定表，這一處沒有建議改法，請人工決定怎麼寫）"
        nt.notice(level, "章節重編後的引用　" + line, "Step 0.5")
    if len(findings) > limit:
        nt.notice(nt.WARNING, "章節重編後的引用還有 %d 處沒列出來，完整清單見執行紀錄的「章節引用」"
                  % (len(findings) - limit), "Step 0.5")


def notice_article_references(references, drift, limit=15):
    """條、款、項引用的問題（需改寫／危險／無法判定）與「編號沒變、內容變了」走 notices。
    以前只印在畫面（批次時只剩一行），提醒.txt 與批次摘要都看不到，人就漏改。"""
    lines = []
    old_ones = [item for item in references or [] if item.get("pre_existing")]
    for item in references or []:
        if item.get("status") not in ("需改寫", "危險", "無法判定") or item.get("external"):
            continue
        if item.get("pre_existing"):
            continue
        if item["status"] == "需改寫" and item.get("new_quote"):
            line = "第%d段引用「%s」要改成「%s」：%s" % (
                item["index"], item["quote"], item["new_quote"], item["note"])
        else:
            line = "第%d段引用「%s」（%s）：%s" % (item["index"], item["quote"], item["status"],
                                              item.get("note") or "")
        lines.append((nt.REMINDER if item["status"] == "無法判定" else nt.WARNING, line))
    for item in drift or []:
        lines.append((nt.WARNING, "第%d段引用「%s」：編號沒變，但指到的%s內容這次有改"
                      % (item["index"], item["quote"], item["target"])))
    for level, line in lines[:limit]:
        nt.notice(level, "條文引用　" + line + "（已列進連帶決定表，請逐筆確認）", "Step 0.5")
    if len(lines) > limit:
        nt.notice(nt.WARNING, "條文引用的問題還有 %d 處沒列出來，完整清單見連帶決定表（來源「條文引用」）"
                  "與執行紀錄的「交叉引用」" % (len(lines) - limit), "Step 0.5")
    if old_ones:
        shown = "；".join("第%d段「%s」" % (item["index"], item["quote"]) for item in old_ones[:limit])
        nt.notice(nt.REMINDER, "條文引用本來就指不到或解析不出的有 %d 處（舊版同一處就是這樣，不是這次改出來的，"
                  "沒有列進連帶決定表）：%s%s" % (len(old_ones), shown, "…" if len(old_ones) > limit else ""),
                  "Step 0.5")


SKIPPED_NUMBERING = "未檢查（此文件沒有第X條，款目編號檢查不適用）"
# 同一份報告裡第二次講同一件事，理由不用再寫一遍
SKIPPED_NUMBERING_AGAIN = "未檢查（同上，此文件沒有第X條）"
# 條層級的引用只列不改，理由見 apply_changes
ARTICLE_REF_MANUAL = "條層級引用只列不改，請人工確認後自行修改"
# 新舊版都沒有「第X條」（要點、手冊）時，編號檢查的結論只講這一則
NO_ARTICLE_NOTE = ("這份文件沒有「第X條」：條號增刪與「第X條」引用的檢查不適用；"
                   "章節引用（第X章第X節…）有檢查；「一、二、三、」有沒有跳號本次未檢查"
                   "（沒有條可分組，小標底下常重新起算，程式判了容易誤報），請自己看一眼")
_ARTICLE_ONLY_CHECKS = ("款目編號", "新版少掉的條號", "條層級交叉引用")


# report() 這一輪有哪幾項是「沒檢查」。畫面上每一段各自印過「未檢查」了，
# 這裡收起來在最後發一則提醒——畫面留不住，而「沒有發現問題」與「根本沒檢查」
# 在產出檔裡看起來一模一樣，那才是危險的地方。
_unchecked = []


def _note_unchecked(item, reason):
    _unchecked.append("%s（%s）" % (item, reason))


def report(problems, changes, deleted_articles, references, drift=None,
           numbering_applicable=True, article_map=None, outline=None,
           point_issues=None, heading_issues=None):
    """把檢查結果印出來。每一段都要明講是「通過」「未檢查」還是「有問題」。

    numbering_applicable：款目編號檢查適不適用於這份文件（沒有「第X條」就不適用）。
    article_map：plan_article_map() 的「舊條號 → 新條號」對照；None 代表沒有舊版
        可比對，條層級與條號增刪一律印「未檢查」。

    為什麼要三態：沒檢查卻印「無，款目編號都是連續的」「沒有受影響的交叉引用」，
    使用者會以為程式看過了、沒問題，實際上是程式根本沒看。這種假的安心比不檢查
    更危險，所以任何沒跑到的分支一律印「未檢查」並說明原因。
    """
    del _unchecked[:]
    print("\n" + "=" * 62)
    print("編號檢查結果")
    print("=" * 62)

    print("\n【編號有問題的地方】")
    if not numbering_applicable and point_issues is not None:
        # 沒有條的文件：點的編號照章、節（與上一層的點）分組查，這次改出來的與本來就有的分開講
        if not point_issues:
            print("  通過，各章節底下點的編號（一、／（一）／(1)／1.）都是連續的")
        for tag, this_round in (("這次改出來的", True), ("本來就有的（舊版同一個地方就是這樣）", False)):
            group = [p for p in point_issues if p["this_round"] == this_round]
            if group:
                print("  %s，共 %d 處" % (tag, len(group)))
            for p in group:
                print("  %s：%s" % (p["place"], p["kind"]))
                print("      目前：%s" % p["written_text"])
                print("      應為：%s（第 %d 段起）" % (p["expected_text"], p["first_index"]))
    elif not numbering_applicable:
        print("  " + SKIPPED_NUMBERING)
        _note_unchecked("款目編號", "此文件沒有第X條，不適用")
    elif problems:
        print("  有問題，共 %d 處" % len(problems))
        for problem in problems:
            # 號碼照原本的數字體系印：阿拉伯目印「1、2」，中文目印「一、二」。
            # 印錯體系的話，人拿著報告回文件裡找不到那一段。
            style = problem.get("style")
            print("  %s %s：%s" % (problem["article"], problem["level"], problem["reason"]))
            print("      目前：%s" % "、".join(_number_text(style, n) for n in problem["written"]))
            print("      應為：%s（第 %d 段起）"
                  % ("、".join(_number_text(style, n) for n in problem["expected"]),
                     problem["first_index"]))
    else:
        print("  通過，款目編號都是連續的")

    print("\n【要重編的段落】")
    if not numbering_applicable:
        print("  " + SKIPPED_NUMBERING_AGAIN)
    elif changes:
        print("  有 %d 段要重編" % len(changes))
        for change in changes[:20]:
            style = change.get("style")
            print("  第%d段 %s %s：第%s%s → 第%s%s"
                  % (change["index"], change["article"], change["level"],
                     _number_text(style, change["old"]) if change["old"] else "?",
                     change["level"],
                     _number_text(style, change["new"]), change["level"]))
        if len(changes) > 20:
            print("  …另有 %d 段（完整清單見輸出檔）" % (len(changes) - 20))
    else:
        print("  通過，不需要重編")

    print("\n【新版少掉的條號】")
    if article_map is None:
        print("  未檢查（沒有給舊版，比不出條號有沒有被刪或被併；請加 --old 舊版檔）")
        _note_unchecked("新版少掉的條號", "沒有給舊版，比不出條號有沒有被刪或被併")
    elif not article_map:
        # 舊版根本沒有「第X條」，不是「每一條都找得到」，是根本沒有東西可以比。
        print("  未檢查（舊版沒有「第X條」，比不出條號對照）")
        _note_unchecked("新版少掉的條號", "舊版沒有「第X條」，比不出條號對照")
    elif not any(not d.get("marked") for d in deleted_articles):
        listed = set(d["article"] for d in deleted_articles)
        noted = [a for a, info in article_map.items()
                 if info["new"] is None and a not in listed]
        if noted or deleted_articles:
            print("  通過，不用補註記")
        else:
            print("  通過，舊版每一條在新版都找得到")
        if noted:
            print("  下列各條新版已註記（刪除）：%s" % "、".join(noted))
    else:
        gone = [d for d in deleted_articles if d["status"] == "刪除"]
        merged = [d for d in deleted_articles if d["status"] == "併入" and not d.get("marked")]
        print("  有問題，共 %d 條" % (len(gone) + len(merged)))
        if gone:
            print("  依法制慣例，刪除的條應保留條號並註記「（刪除）」，讓後面的條號維持不變，")
            print("  否則全文及其他規章裡引用這些條號的地方會全部指錯。建議補上：")
            for item in gone:
                print("      %s　（刪除）" % item["article"])
        if merged:
            # 併條不是刪除。補「（刪除）」註記反而是錯的，所以一定要分開講。
            print("  下列各條的內容是被併進別條，不是刪除，不要補「（刪除）」註記：")
            for item in merged:
                print("      %s　併入%s" % (item["article"], item["into"]))
    moved_marked = [d for d in deleted_articles if d.get("marked")] if article_map else []
    if moved_marked:
        print("  下列各條新版已註記（刪除），內容搬到別條：")
        for item in moved_marked:
            print("      %s　內容在%s" % (item["article"], item["into"]))

    external = [r for r in references if r["status"] == "外部法規"]
    dangerous = [r for r in references if r["status"] == "危險"]
    rewritable = [r for r in references if r["status"] == "需改寫"]
    unresolved = [r for r in references if r["status"] == "無法判定"]
    affected = dangerous + rewritable + unresolved
    article_level = [r for r in affected if r["kind"] == "條"]
    inner_level = [r for r in affected if r["kind"] != "條"]

    print("\n【交叉引用】")
    if external:
        laws = []
        for ref in external:
            if ref.get("law") and ref["law"] not in laws:
                laws.append(ref["law"])
        print("  外部法規引用（不檢查）%d 處：%s" % (len(external), "、".join(laws)))
        print("      這些是別部法規的條號，本程式沒有那部法規的新舊版，不判也不改寫。")
    guessed = [r for r in references if r["status"] == "推測"]
    if guessed:
        print("  手冊的相對引用（前款、本項第2至第5款…）用字跟本手冊層級不一致、程式推測指向的 %d 處：" % len(guessed))
        for ref in guessed:
            print("      第%d段「%s」：%s" % (ref["index"], ref["quote"], ref.get("note") or ""))
    if article_map is None:
        print("  條層級引用：未檢查（沒有舊版可比對，算不出舊條號對到新版哪一條；"
              "請加 --old 舊版檔）")
        _note_unchecked("條層級交叉引用", "沒有舊版可比對，算不出舊條號對到新版哪一條")
    elif not article_map:
        # 舊版沒有任何「第X條」，對照表是空的，條層級等於沒檢查
        print("  條層級引用：未檢查（舊版沒有「第X條」，算不出條號對照）")
        _note_unchecked("條層級交叉引用", "舊版沒有「第X條」，算不出條號對照")
    elif article_level:
        print("  條層級引用：有問題，共 %d 處（%s）"
              % (len(article_level), ARTICLE_REF_MANUAL))
    else:
        print("  條層級引用：通過，比對過新舊版條號，沒有指錯的「第X條」")
    if inner_level:
        print("  款目與項引用：有問題，共 %d 處" % len(inner_level))
    else:
        print("  款目與項引用：通過，沒有指錯的款目或項")

    # 新舊版對照推出來的（list_only）跟條層級一樣只列不改；沒有新寫法的也只能人改
    rewritable_inner = [r for r in rewritable if _auto_rewritable(r)]
    rewritable_article = [r for r in rewritable if not _auto_rewritable(r)]
    if rewritable_inner:
        print("  可機械式改寫 %d 處（加 --rewrite-refs 一併處理）：" % len(rewritable_inner))
        for ref in rewritable_inner:
            print("    第%d段「%s」→「%s」" % (ref["index"], ref["quote"], ref["new_quote"]))
            print("        %s" % ref["note"])
    if rewritable_article:
        # 條層級一律只列不改：作者可能已經自己改好了，文字上看不出來，猜錯就是
        # 把對的條號改成錯的。建議的新條號照印，改不改由人決定。
        print("  %s（%d 處）：" % (ARTICLE_REF_MANUAL, len(rewritable_article)))
        for ref in rewritable_article:
            if ref.get("new_quote"):
                print("    第%d段「%s」→ 建議改成「%s」"
                      % (ref["index"], ref["quote"], ref["new_quote"]))
            else:
                print("    第%d段「%s」" % (ref["index"], ref["quote"]))
            print("        %s" % ref["note"])
    if dangerous:
        print("\n  ⚠ 必須人工處理 %d 處 —— 本程式不會自動改：" % len(dangerous))
        for ref in dangerous:
            print("    第%d段：%s" % (ref["index"], ref["text"][:50]))
            print("        引用「%s」，%s" % (ref["quote"], ref["note"]))
    if unresolved:
        # 解析不出來的一定要列出來。沉默才是最危險的結果——使用者會以為
        # 程式看過了、沒問題，實際上是程式根本沒看懂那句話。
        print("\n  ? 解析不出來 %d 處 —— 可能是寫法特殊，也可能原文本來就寫錯，"
              "請人工看一下：" % len(unresolved))
        for ref in unresolved:
            print("    第%d段：%s" % (ref["index"], ref["text"][:50]))
            print("        引用「%s」，%s" % (ref["quote"], ref["note"]))

    if drift:
        print("\n【編號沒變、但指到的內容變了】共 %d 處 —— 這是最容易漏掉的一種"
              % len(drift))
        print("  表面上編號連續、看不出問題，但同一個編號在新舊版指的是不同的東西。")
        for item in drift:
            print("\n    第%d段：%s" % (item["index"], item["text"][:52]))
            print("        引用「%s」" % item["quote"])
            print("        舊版的%s是：%s" % (item["target"], item["old_body"]))
            if item["new_body"] is None:
                print("        新版沒有這一款了")
            else:
                print("        新版的%s是：%s" % (item["target"], item["new_body"]))
        print("\n  本程式不會自動改這些，請逐筆確認引用要指向哪裡。")

    if outline is not None:
        moved, found = outline
        print("\n【章節引用（第X章第X節）】")
        if not moved:
            print("  通過，章節編號沒有變動")
        elif not found:
            print("  通過，有 %d 個章節或點換號或刪除，但本文沒有引用到它們" % moved)
        else:
            print("  有問題，共 %d 處（有 %d 個章節或點換號或刪除；本程式只列不改）" % (len(found), moved))
            for item in found:
                print("    第%d段：%s" % (item["index"], item["text"][:50]))
                if item["new_quote"]:
                    print("        「%s」→ 建議改成「%s」" % (item["quote"], item["new_quote"]))
                else:
                    print("        引用「%s」" % item["quote"])
                print("        %s" % item["note"])

    print("=" * 62)
    if heading_issues:
        print("\n【章節標題的編號】這次改出來的，共 %d 處" % len(heading_issues))
        for h in heading_issues:
            print("  %s：%s　目前「%s」，應為「%s」（第 %d 段起）"
                  % (h["place"], h["kind"], h["written_text"], h["expected_text"], h["first_index"]))
    elif heading_issues is not None:
        print("\n【章節標題的編號】通過，這次沒有改出跳號或重號")

    unchecked = list(_unchecked)
    if not numbering_applicable and article_map == {}:
        # 新舊版都沒有「第X條」：條號那幾項是「不適用」，跟「該查沒查到」不同。
        # 點的編號有查（point_issues）就什麼都不用講；沒查（只有單獨呼叫 report 的舊路）
        # 才併成一則講清楚哪些不適用、哪一項沒查
        if point_issues is None:
            nt.notice(nt.REMINDER, NO_ARTICLE_NOTE, "Step 0.5")
        unchecked = [u for u in unchecked if not u.startswith(_ARTICLE_ONLY_CHECKS)]
    if unchecked:
        nt.notice(nt.REMINDER,
                  "編號檢查有 %d 項未檢查：%s。未檢查不等於沒問題，這幾項本次沒有跑到"
                  % (len(unchecked), "、".join(unchecked)), "Step 0.5")


def _edit_span(old, new):
    """old 改成 new 動到的是 old 的哪一段：(起, 迄, 換成的字)。去掉共同的頭尾。"""
    head = 0
    while head < min(len(old), len(new)) and old[head] == new[head]:
        head += 1
    tail = 0
    while tail < min(len(old), len(new)) - head and old[-1 - tail] == new[-1 - tail]:
        tail += 1
    return head, len(old) - tail, new[head:len(new) - tail]


def _auto_rewritable(ref):
    """--rewrite-refs 會自動改的引用：需改寫、有新寫法、不是外部法規、不是條層級、
    也不是新舊版對照推出來的（list_only，要人看過）。report 與 apply_changes 共用。"""
    return (ref.get("status") == "需改寫" and bool(ref.get("span")) and bool(ref.get("new_quote"))
            and not ref.get("external") and ref.get("kind") != "條" and not ref.get("list_only"))


def apply_changes(paragraphs, changes, references, rewrite_refs):
    """套用重編（以及選用的引用改寫），回傳新的段落列表。

    引用的 span 是**原文**的座標。以前先把段首換成新編號再用舊 span 切字，編號長度一變
    （十一→十）就切歪：「十一、依第十二款規定」變成「十、依第第十一款定」（A12）。
    現在同一段的編號改動與引用改寫都換算成原文上的區段，由後往前一次套上；
    兩者重疊（理論上不會）就只改編號、不動那一處引用。
    """
    result = list(paragraphs)
    edits = {}
    for change in changes:
        index = change["index"]
        edits.setdefault(index, []).append(_edit_span(paragraphs[index - 1], change["new_text"]))

    if rewrite_refs:
        # 只改「需改寫」的款目與項。「危險」「無法判定」「外部法規」一律不動，
        # 條層級也一律不動——只列出來給人看。
        #
        # 條層級為什麼不能自動改：重編之後，「作者已經改好的新號」跟「還沒改的
        # 舊號」在文字上一模一樣，程式沒有辦法分辨，而 _judge 一律往「還沒改」
        # 的方向解，猜錯就是把對的條號改成錯的（實測：作者已經把第七條改成
        # 第六條，程式又把它改成第五條）。款目與項不一樣，它們的新舊號是由
        # 本次重編自己算出來的，不是從文字上猜的。
        #
        # 外部法規那一條也特別重要：把別部法規的條號改掉，是在正式修法文件上
        # 寫錯別人的法條，比漏改嚴重得多（實測 idx 142）。
        #
        # 用 span 由後往前取代：同一段裡可能出現兩個「第四款」，
        # 用字串比對會改到錯的那一個。
        by_paragraph = {}
        for ref in references:
            if _auto_rewritable(ref):
                by_paragraph.setdefault(ref["index"], []).append(ref)

        for index, refs in by_paragraph.items():
            for ref in refs:
                start, end = ref["span"]
                taken = edits.get(index, [])
                if any(start < b and a < end for a, b, _ in taken):
                    continue
                edits.setdefault(index, []).append((start, end, ref["new_quote"]))

    for index, spans in edits.items():
        text = paragraphs[index - 1]
        for start, end, new in sorted(spans, key=lambda s: s[0], reverse=True):
            text = text[:start] + new + text[end:]
        result[index - 1] = text
    return result


def write_output(paragraphs, source_path, outdir, prefix):
    """輸出重編後的檔案，格式跟來源檔一致。"""
    base = "重編後_" + os.path.basename(source_path)
    output_path = resolve_output(outdir, prefix, base)

    if output_path.lower().endswith(".docx"):
        if not HAS_DOCX:
            output_path = os.path.splitext(output_path)[0] + ".txt"
            nt.notice(nt.REMINDER, "沒有安裝 python-docx，重編結果改輸出純文字檔", "重編輸出")
        else:
            from docx import Document
            doc = Document()
            for text in paragraphs:
                doc.add_paragraph(text)
            doc.save(output_path)
            print("\n已輸出重編後檔案：%s" % output_path)
            return output_path

    with open(output_path, "w", encoding="utf-8") as f:
        f.write("\n".join(paragraphs) + "\n")
    print("\n已輸出重編後檔案：%s" % output_path)
    return output_path


def main():
    setup_console()
    parser = argparse.ArgumentParser(
        description="Step 1.5：款目編號重編與交叉引用檢查")
    parser.add_argument("regulation_file", help="要檢查的內規檔案（通常是你剛改好的新版）")
    parser.add_argument("--old", default=None,
                        help="舊版檔案；給了才能找出被整條刪掉的條號")
    parser.add_argument("--apply", action="store_true",
                        help="實際重編款目編號並輸出檔案；不加就只檢查不動檔案")
    parser.add_argument("--rewrite-refs", action="store_true",
                        help="連同可機械式改寫的交叉引用一起改（引用到已刪除款目的、"
                             "以及外部法規的條號一律不動）")
    parser.add_argument("--outdir", default="", help="輸出資料夾")
    parser.add_argument("--prefix", default="", help="輸出檔名前綴")
    args = parser.parse_args()

    print("正在讀取：%s" % args.regulation_file)
    paragraphs, kinds = read_paragraphs_with_kinds(args.regulation_file)
    print("全文共 %d 段。" % len(paragraphs))
    # 編號一律看結構文字（Word 自動編號＋原文）；有自動編號的檔不改寫（見下面 --apply）
    auto_numbered = any(list_label(kinds, i) for i in range(len(paragraphs)))
    paragraphs, kinds = structure_view(paragraphs, kinds)

    entries = scan(paragraphs, kinds)
    applicable = numbering_check_applicable(entries)
    if not applicable:
        nt.notice(nt.REMINDER,
                  "這份文件沒有「第X條」（作業手冊型），款目編號檢查與重編不適用，"
                  "本次未檢查；交叉引用檢查照常", "Step 0.5")
    problems = find_numbering_gaps(entries)
    changes, clause_map, item_map = plan_renumber(paragraphs, entries)
    known_articles = {c["article"] for c in build_hierarchy(paragraphs, kinds)
                      if c["level"] == "條" and c["article"]}

    # 條層級的判定要先有「舊條號 → 新條號」的對照，所以舊版要先讀進來。
    article_map = None
    changed_paragraphs = None
    deleted_articles = []
    drift = []
    old_paragraphs = old_kinds = None
    if args.old:
        print("正在比對舊版：%s" % args.old)
        old_paragraphs, old_kinds = structure_view(*read_paragraphs_with_kinds(args.old))
        article_map = plan_article_map(old_paragraphs, paragraphs, old_kinds, kinds)
        changed_paragraphs = find_changed_paragraphs(old_paragraphs, paragraphs,
                                                     old_kinds, kinds)
        deleted_articles = find_deleted_articles(old_paragraphs, paragraphs,
                                                 old_kinds, kinds,
                                                 article_map=article_map)
        drift = scan_reference_drift(old_paragraphs, paragraphs, old_kinds, kinds)
    else:
        nt.notice(nt.REMINDER,
                  "沒有給 --old，無法檢查「編號沒變但指到的內容變了」這種情況，"
                  "條層級的交叉引用也只能印「未檢查」；強烈建議加上舊版一起跑"
                  "（--old 舊版內規.docx）", "Step 0.5")

    references = scan_references(paragraphs, entries, clause_map, item_map,
                                 known_articles=known_articles, kinds=kinds,
                                 article_map=article_map,
                                 changed_paragraphs=changed_paragraphs,
                                 old_paragraphs=old_paragraphs if args.old else None,
                                 old_kinds=old_kinds if args.old else None)
    drift = dedupe_drift(drift, references)

    report(problems, changes, deleted_articles, references, drift,
           numbering_applicable=applicable, article_map=article_map)

    if not args.apply:
        if changes or [r for r in references if r["status"] != "安全"]:
            print("\n這是檢查模式，沒有更動任何檔案。要實際重編請加 --apply。")
        return changes

    if auto_numbered:
        # 改寫的是結構文字：寫回去會把 Word 畫的「一、」變成文字，Word 再畫一次就成了「一、一、」
        print("\n這份用了 Word 自動編號，--apply 不改寫：自動編號請在 Word 裡確認，手打的編號請人工重編。")
        return changes

    updated = apply_changes(paragraphs, changes, references, args.rewrite_refs)
    write_output(updated, args.regulation_file, args.outdir, args.prefix)

    dangerous = [r for r in references if r["status"] == "危險"]
    if dangerous:
        print("\n⚠ 仍有 %d 處交叉引用引用到已刪除的款目，本程式沒有改動它們，"
              "請務必人工確認後再送出。" % len(dangerous))

    return changes


if __name__ == "__main__":
    main()
