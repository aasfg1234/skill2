"""工作區搬移：串流指紋、增量清單與安全解包。"""
import datetime
import contextlib
import fnmatch
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import re
import shutil
import tempfile
import zipfile
import zlib
import uuid

import workspace
from file_replace import replace_file

MANIFEST = "搬移清單.json"
BASELINE = ".搬移基準.json"
# 解開工作區換檔前寫的紀錄：還在就表示上一次沒做完。開頭跟暫存資料夾一樣，不會被打包，封包也夾帶不進來（見 _excluded）
JOURNAL = ".搬移暫存_解開紀錄.json"
ROUND_MARK = ".本輪進行中.json"        # 這一台中斷的紀錄（todo.ROUND_MARK）：搬到別台沒有意義，不進打包
CONFLICT = "_衝突/"
MEMO = "_skill累積/memoization/"
PROGRAM = "_skill程式/"
MARKERS = (workspace.LAYOUT_FILE, workspace.ACTIVE_OUTPUT_FILE, "法規作業.json")
# 解開封包的上限（isolated_runner 的倉庫用同一組）
MAX_ARCHIVE_ENTRIES = 200000
MAX_ARCHIVE_FILE_BYTES = 2 * 1024 ** 3
MAX_ARCHIVE_TOTAL_BYTES = 2 * 1024 ** 3
SENSITIVE_PATTERNS = (".env*", "*.secret*", "*.pem", "*.key", "auth.json", "sinopac*", "shioaji*",
                      "credentials*", "*.pfx", "*.p12", "id_rsa*", "*token*.txt", "*token*.json")


def _suspicious(name):
    lower = name.lower()
    return (any(fnmatch.fnmatchcase(lower, pattern) for pattern in SENSITIVE_PATTERNS)
            or bool(re.search(r"(?:^|[^a-z0-9])keys(?:[^a-z0-9]|$)", lower)) and lower.endswith(".json"))


def _excluded(name):
    return (name.startswith("~$") or name.lower().endswith(".tmp")
            or name in (".執行中.json", ROUND_MARK, "__pycache__", BASELINE, "中斷留底") or name.startswith(".搬移暫存_")
            or _suspicious(name))


def _keyed(items):
    if not isinstance(items, dict):
        raise ValueError("清單檔案欄位不正確")
    result = {}
    for name, meta in items.items():
        if not isinstance(name, str) or not _safe(name):
            raise ValueError("清單含不安全的路徑")
        if not isinstance(meta, dict) or type(meta.get("大小")) is not int or meta["大小"] < 0 or not isinstance(meta.get("sha256"), str) or not re.fullmatch(r"[0-9a-f]{64}", meta["sha256"]):
            raise ValueError("清單指紋格式不正確：%s" % name)
        key = name.casefold()
        if key in result:
            raise ValueError("清單含大小寫重複的路徑：%s" % name)
        result[key] = (name, meta)
    return result


def _baseline_record(root):
    path = root / BASELINE
    if not path.exists():
        return None
    value = _read_manifest(path)
    if value.get("格式版本") != 1 or not isinstance(value.get("檔案"), dict):
        raise ValueError("同步基準格式不正確")
    _keyed(value["檔案"])
    before = value.get("打包前基準")
    if before is not None:
        _keyed(before)
    return value


def _baseline(root):
    value = _baseline_record(root)
    return value["檔案"] if value is not None else None


def _write_baseline(root, files, extra=None):
    temp = root / (BASELINE + "." + uuid.uuid4().hex + ".tmp")
    try:
        record = {"格式版本": 1, "檔案": files}
        record.update(extra or {})
        temp.write_text(json.dumps(record, ensure_ascii=False, indent=2), encoding="utf-8")
        replace_file(temp, root / BASELINE)
    finally:
        if temp.exists():
            temp.unlink()


def _in_scope(name, output_only, prefix, include_memo, include_program=False):
    folded = name.casefold()
    if folded.startswith(PROGRAM.casefold()):
        return include_program and not output_only
    if folded.startswith("_skill累積/".casefold()):
        return include_memo
    if not output_only:
        return True
    # v1.51.0：法規證據改放工作區共用的 _法規證據/，只帶產出的封包也要帶，不然匯入時找不到證據檔
    return (folded in {marker.casefold() for marker in MARKERS} or folded.startswith(prefix.casefold())
            or folded.startswith("_法規證據/"))


def _merge_baseline(old, current, output_only, prefix, include_memo, include_program=False):
    preserved = {name: meta for name, meta in (old or {}).items()
                 if not _in_scope(name, output_only, prefix, include_memo, include_program)}
    updated = {name: meta for name, meta in current.items()
               if _in_scope(name, output_only, prefix, include_memo, include_program)}
    preserved.update(updated)
    return preserved


def _files(root, scope=None, excluded_roots=()):
    result = {}
    skipped = 0
    skipped_dirs = 0
    for folder, dirs, files in os.walk(root, followlinks=False):
        skipped_dirs += sum(1 for d in dirs if _suspicious(d))
        dirs[:] = sorted(d for d in dirs if not _excluded(d) and not (Path(folder) == Path(root) and d.casefold() in excluded_roots) and not (Path(folder) / d).is_symlink() and not (hasattr(Path(folder) / d, "is_junction") and (Path(folder) / d).is_junction()))
        for name in sorted(files):
            path = Path(folder) / name
            rel = path.relative_to(root).as_posix()
            if scope and not scope(rel):
                continue
            if _suspicious(name):
                skipped += 1
            if not _excluded(name) and not path.is_symlink():
                result[rel] = path
    return result, skipped, skipped_dirs


def _digest(stream):
    h = hashlib.sha256()
    size = 0
    while True:
        block = stream.read(1024 * 1024)
        if not block:
            return {"大小": size, "sha256": h.hexdigest()}
        size += len(block)
        h.update(block)


def _metadata(path):
    with open(path, "rb") as stream:
        return _digest(stream)


def _read_manifest(path):
    with open(path, encoding="utf-8") as f:
        return json.load(f)


def _memo_dir():
    from batch import cache_dir
    return Path(cache_dir())


def _program_dir():
    return Path(os.environ.get("REG_SKILL_DIR") or Path(__file__).resolve().parent.parent)


def _program_files():
    return _files(_program_dir(), excluded_roots=("memoization", "models", "_請求", "隔離區"))


def _repair_requests(args, settings, root, include_program):
    """把缺檔轉成搬移清單路徑；不要求搬工作區或程式外的路徑。"""
    import preflight
    missing = preflight.collect(args, settings, check_manifest=True)
    requests = set()
    count = 0

    def safe_inside(base, name):
        name = name.replace("\\", "/")
        if not _safe(name):
            return None
        base = base.resolve()
        target = base.joinpath(*PurePosixPath(name).parts).resolve()
        return name if target != base and target.is_relative_to(base) else None

    if include_program:
        for name in missing["程式"]:
            name = safe_inside(_program_dir(), name)
            if name:
                requests.add(PROGRAM + name)
                count += 1
    if args.include_memo:
        for name in missing["累積資料"]:
            name = safe_inside(_memo_dir(), name)
            if name:
                # 第一層不在時無法得知它原本是檔案還是資料夾。
                requests.update((MEMO + name, MEMO + name + "/"))
                count += 1
    folders = set()
    for filename, field in (("目前作業.json", "目前作業"), ("法規作業.json", "目前法規作業")):
        path = root / filename
        if path.is_file():
            value = _read_manifest(path)
            folder = value.get(field, "")
            if isinstance(folder, str) and folder in missing["工作區"]:
                folders.add(folder)
    for name in missing["工作區"]:
        safe = safe_inside(root, name)
        if safe:
            requests.add(safe + "/" if name in folders else safe)
            count += 1
    return sorted(requests), count


def _read_repair_requests(peer):
    requests = peer.get("要補", [])
    if not isinstance(requests, list) or any(not isinstance(name, str) or not _safe(name) for name in requests):
        raise ValueError("要補清單格式不正確")
    return requests


def _requested(key, requests):
    return any(key.startswith(name) if name.endswith("/") else key == name for name in requests)


def _pid_alive(pid):
    """這個 pid 的程式還在跑嗎（跟 run_all._pid_alive 同一套判斷；搬移不經過 run_all 的鎖）。"""
    try:
        pid = int(pid)
    except (TypeError, ValueError):
        return False
    if pid == os.getpid():
        return True
    if os.name == "nt":
        import ctypes
        handle = ctypes.windll.kernel32.OpenProcess(0x1000, False, pid)
        if not handle:
            return False
        code = ctypes.c_ulong()
        try:
            ok = ctypes.windll.kernel32.GetExitCodeProcess(handle, ctypes.byref(code))
        finally:
            ctypes.windll.kernel32.CloseHandle(handle)
        return bool(ok) and code.value == 259
    try:
        os.kill(pid, 0)
    except OSError:
        return False
    return True


@contextlib.contextmanager
def _transfer_lock(root):
    path = root / ".執行中.json"
    for attempt in (1, 2):
        try:
            fd = os.open(path, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
            break
        except FileExistsError:
            try:
                held = _read_manifest(path)
                command = str(held.get("指令") or "不明").replace("\n", " ").replace("\r", " ")
                started = str(held.get("開始") or "不明").replace("\n", " ").replace("\r", " ")
                pid = held.get("pid")
            except (OSError, ValueError, AttributeError):
                command, started, pid = "不明", "不明", None
            # v1.49.0：留下鎖的程式已經不在了（電腦當過、視窗被強制關掉）就自己收掉，
            # 跟一般指令一樣；以前搬移一律拒絕，要新手自己去刪隱藏檔
            if attempt == 1 and pid is not None and not _pid_alive(pid):
                path.unlink(missing_ok=True)
                continue
            raise ValueError("這個工作區正在跑別的指令（%s，%s），等它跑完再搬；確定沒有在跑才刪掉 .執行中.json" % (command, started)) from None
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            json.dump({"pid": os.getpid(), "指令": "工作區搬移", "開始": datetime.datetime.now().isoformat(timespec="seconds")}, f, ensure_ascii=False)
        yield
    finally:
        path.unlink(missing_ok=True)


def execute_locked(args, settings):
    created = []
    root = None
    try:
        if args.func is pack:
            root = Path(workspace.resolve_root(getattr(args, "workspace", ""), settings)).resolve()
        elif args.func is unpack:
            root = Path(os.path.abspath(args.destination))
            _reject_links(root)
            if not root.exists():
                path = root
                while not path.exists():
                    created.append(path)
                    path = path.parent
                for path in reversed(created):
                    path.mkdir()
        else:
            target = Path(os.path.abspath(args.target))
            root = target if target.is_dir() else target.parent
        with _transfer_lock(root):
            if args.func is not unpack and (root / JOURNAL).exists():
                raise ValueError("上一次解開工作區沒做完，這個工作區現在新舊混雜：先再跑一次解開工作區，程式會還原後重解")
            if args.func is pack:
                _settle_round(root)           # 沒跑完的那一輪不能當目前作業帶到別台（標記不進打包，別台認不出來）
            result = args.func(args, settings)
            if args.func is unpack and not result:
                _settle_round(root)           # 搬回來換了目前作業：這一台的舊標記過期了
            return result
    except (OSError, ValueError, TypeError) as exc:
        message = str(exc).replace("\n", " ")
        print(message if message.startswith("這個工作區正在跑別的指令") else "工作區搬移失敗：%s" % message)
        return 1
    finally:
        for path in created:
            try:
                path.rmdir()
            except OSError:
                pass


def _settle_round(root):
    if (root / ROUND_MARK).is_file():
        import todo
        line = todo.settle_round(str(root))
        if line:
            print(line, flush=True)


def pack(args, settings):
    try:
        root = Path(workspace.resolve_root(getattr(args, "workspace", ""), settings)).resolve()
        if not root.is_dir():
            raise ValueError("找不到工作區：%s" % root)
        suffix = "_清單_" if args.list_only else "_搬移_"
        extension = ".json" if args.list_only else ".zip"
        output = Path(args.output).resolve() if args.output else root.parent / (root.name + suffix + datetime.datetime.now().strftime("%Y%m%d_%H%M%S") + extension)
        if output == root or root in output.parents:
            raise ValueError("ZIP 必須放在工作區外")
        scope = None
        prefix = ""
        if args.output_only:
            active = workspace.current_output(str(root))
            if not active:
                raise ValueError("目前作業沒有有效的產出資料夾")
            prefix = Path(active).name + "/"
            scope = lambda k: _in_scope(k, True, prefix, False)
        files, skipped, skipped_dirs = _files(root, scope)
        include_program = getattr(args, "include_program", False) and not args.output_only
        program_root = _program_dir().resolve()
        if include_program and (root == program_root or root in program_root.parents or program_root in root.parents):
            raise ValueError("工作區與程式資料夾不能互相包含")
        if include_program and (output == program_root or program_root in output.parents):
            raise ValueError("ZIP 或清單不能放在程式資料夾內")
        if (root / "_skill程式").exists():
            raise ValueError("工作區含搬移保留名稱 _skill程式")
        if include_program:
            _reject_links(_program_dir())
            if not program_root.is_dir():
                raise ValueError("找不到程式資料夾")
            program_files, program_skipped, program_dirs = _program_files()
            skipped += program_skipped
            skipped_dirs += program_dirs
            files.update({PROGRAM + k: v for k, v in program_files.items()})
        if any(k.startswith("_skill累積/") or k == "_skill累積" for k in files) or (root / "_skill累積").exists():
            raise ValueError("工作區含搬移保留名稱 _skill累積")
        if (root / "_衝突").exists():
            raise ValueError("工作區含搬移保留名稱 _衝突")
        memo_root = _memo_dir().resolve()
        if memo_root == root or root in memo_root.parents:
            raise ValueError("累積資料目錄不能在工作區內")
        if args.include_memo and _memo_dir().is_dir():
            memo_files, memo_skipped, memo_dirs = _files(_memo_dir())
            skipped += memo_skipped
            skipped_dirs += memo_dirs
            files.update({MEMO + k: v for k, v in memo_files.items()})
        if MANIFEST in files or any(k.startswith("_skill累積/") and not k.startswith(MEMO) for k in files):
            raise ValueError("工作區含搬移保留名稱")
        all_files = {k: _metadata(v) for k, v in files.items()}
        peer = _read_manifest(args.previous) if args.previous else {}
        requested = [name for name in _read_repair_requests(peer)
                     if _in_scope(name, args.output_only, prefix, args.include_memo, include_program)]
        requested_folded = [name.casefold() for name in requested]
        grouped = {}
        for name in requested_folded:
            grouped.setdefault(name.rstrip("/"), []).append(name)
        unavailable = sum(not any(_requested(key.casefold(), group) for key in all_files) for group in grouped.values())
        repair_requests, missing_count = _repair_requests(args, settings, root, include_program) if args.list_only else ([], 0)
        previous = peer.get("全部檔案", {})
        if scope:
            previous = {k: v for k, v in previous.items() if scope(k) or (args.include_memo and k.casefold().startswith(MEMO.casefold()))}
        elif not args.include_memo:
            previous = {k: v for k, v in previous.items() if not k.casefold().startswith(MEMO.casefold())}
        if not include_program:
            previous = {k: v for k, v in previous.items() if not k.casefold().startswith(PROGRAM.casefold())}
        previous = {k: v for k, v in previous.items() if not any(_excluded(part) for part in k.split("/"))}
        own_record = _baseline_record(root)
        own_base = own_record["檔案"] if own_record is not None else None
        effective_base = own_base
        if own_record and own_record.get("最後打包ID") and peer.get("最後套用ID") != own_record["最後打包ID"]:
            effective_base = own_record.get("打包前基準")
        other_base = peer.get("基準")
        mine, theirs = _keyed(all_files), _keyed(previous)
        force_keys = set()
        for name in args.force_paths:
            if not _safe(name) or name.casefold() not in mine:
                raise ValueError("以我為準的檔案不存在或不在本次範圍：%s" % name)
            force_keys.add(name.casefold())
        own_b, peer_b = _keyed(effective_base or {}), _keyed(other_base or {})
        common = {k: v[1] for k, v in own_b.items() if k in peer_b and v[1] == peer_b[k][1]}
        selected, deleted, conflicts, blocked = {}, {}, {}, []
        after = {k: v[1] for k, v in theirs.items()}
        for key in sorted(mine.keys() | theirs.keys()):
            mine_value = mine.get(key, (None, None))[1]
            their_value = theirs.get(key, (None, None))[1]
            if key == workspace.VERSION_FILE.casefold() and None not in (mine_value, their_value) \
                    and mine_value != their_value:
                selected[mine[key][0]] = mine_value          # 版本紀錄兩邊不同不算衝突：解開時留高的
                after[key] = mine_value
                continue
            if key in force_keys:
                selected[mine[key][0]] = mine_value
                after[key] = mine_value
                continue
            if mine_value is not None and their_value is None and _requested(key, requested_folded):
                selected[mine[key][0]] = mine_value
                after[key] = mine_value
                continue
            if mine_value == their_value:
                continue
            base = common.get(key)
            if key in common and mine_value == base:
                continue
            if (key in common and their_value == base) or (key not in common and their_value is None):
                if mine_value is None:
                    deleted[theirs[key][0]] = their_value
                    after.pop(key, None)
                else:
                    selected[mine[key][0]] = mine_value
                    after[key] = mine_value
            elif key not in common and mine_value is None:
                continue
            elif mine_value is None:
                blocked.append(theirs[key][0])
            else:
                conflicts[CONFLICT + mine[key][0]] = mine_value
        new_base = {name: value for key, (name, value) in mine.items() if after.get(key) == value}
        transfer_id = uuid.uuid4().hex if not args.list_only else None
        manifest = {"格式版本": 1, "工作區資料夾名": root.name, "建立時間": datetime.datetime.now().isoformat(timespec="seconds"),
                    "模式": "只要產出" if args.output_only else ("變動" if args.previous else "全部"), "連同累積資料": args.include_memo,
                    "產出前綴": prefix, "連同程式": include_program,
                    "檔案": dict(selected, **conflicts), "全部檔案": all_files, "已刪除": deleted, "基準": own_base, "對方檔案": previous, "衝突": list(conflicts), "刪除衝突": blocked,
                    "搬移ID": transfer_id, "最後套用ID": (own_record or {}).get("最後套用ID"), "以我為準": [mine[key][0] for key in sorted(force_keys)]}
        if args.list_only:
            manifest["要補"] = repair_requests
        data = json.dumps(manifest, ensure_ascii=False, indent=2).encode("utf-8")
        output.parent.mkdir(parents=True, exist_ok=True)
        if args.list_only:
            output.write_bytes(data)
            note = "；缺 %d 個，已寫進清單請對方補" % missing_count if missing_count else ""
            if unavailable:
                note += "；對方要補的 %d 個這邊也沒有" % unavailable
            print("打包工作區：清單 %d 個檔；略過疑似帳密檔 %d 個、資料夾 %d 個（不搬）%s；清單：%s" % (len(all_files), skipped, skipped_dirs, note, output))
            return 0
        with zipfile.ZipFile(output, "w", compression=zipfile.ZIP_DEFLATED, allowZip64=True) as z:
            for name, meta in manifest["檔案"].items():
                source_name = name[len(CONFLICT):] if name.startswith(CONFLICT) else name
                h = hashlib.sha256()
                size = 0
                with open(files[source_name], "rb") as source, z.open(name, "w", force_zip64=True) as target:
                    for block in iter(lambda: source.read(1024 * 1024), b""):
                        target.write(block)
                        size += len(block)
                        h.update(block)
                if {"大小": size, "sha256": h.hexdigest()} != meta:
                    raise ValueError("打包期間檔案被改，請重跑")
            z.writestr(MANIFEST, data)
        side = Path(str(output) + ".清單.json")
        side.write_bytes(data)
        extra = {"最後打包ID": transfer_id, "打包前基準": effective_base}
        if own_record and "最後套用ID" in own_record:
            extra["最後套用ID"] = own_record["最後套用ID"]
        _write_baseline(root, _merge_baseline(own_base, new_base, args.output_only, prefix, args.include_memo, include_program), extra)
        same_note = "；兩邊一樣，不用搬" if args.previous and not selected and not deleted and not conflicts and not blocked and mine == theirs else ""
        same_note += "；衝突 %d 個，刪除衝突 %d 個" % (len(conflicts), len(blocked))
        if unavailable:
            same_note += "；對方要補的 %d 個這邊也沒有" % unavailable
        if args.previous and not common:
            same_note += "；沒有同步基準，這次不刪、不蓋，衝突 %d 個請人看" % (len(conflicts) + len(blocked))
        print("打包工作區：放了 %d 個檔（%.1f MB），沒變的 %d 個沒放，已刪除 %d 個；略過疑似帳密檔 %d 個、資料夾 %d 個（不搬）%s；ZIP：%s；清單：%s" %
              (len(selected), sum(v["大小"] for v in selected.values()) / 1048576, len(all_files)-len(selected), len(deleted), skipped, skipped_dirs, same_note, output, side))
        return 0
    except (OSError, ValueError, KeyError, TypeError, AttributeError, RuntimeError, zipfile.BadZipFile, zlib.error) as exc:
        print("打包工作區失敗：%s" % str(exc).replace("\n", " "))
        return 1


def _safe(name):
    if not name or "\\" in name or name.startswith("/") or re.match(r"^[A-Za-z]:", name):
        return False
    parts = name.rstrip("/").split("/")
    return all(p not in ("", ".", "..") and not re.search(r'[<>:"|?*\x00-\x1f]', p)
               and not p.endswith((".", " ")) and not re.match(r"(?i)^(con|prn|aux|nul|com[1-9]|lpt[1-9])(?:\.|$)", p) for p in parts)


def _reject_links(path):
    for part in (path, *path.parents):
        if part.is_symlink() or (hasattr(part, "is_junction") and part.is_junction()):
            raise ValueError("目的地含連結或接合點：%s" % part)


def _check_limits(infos):
    """v1.51.0：用中央目錄宣告的大小先加總，超過就不解（高壓縮 ZIP 幾 KB 可以解成幾十 GB，塞滿磁碟）。"""
    if len(infos) > MAX_ARCHIVE_ENTRIES:
        raise ValueError("ZIP 檔案數超過上限（%d 項）" % MAX_ARCHIVE_ENTRIES)
    total = 0
    for info in infos:
        if info.file_size > MAX_ARCHIVE_FILE_BYTES:
            raise ValueError("ZIP 單一檔案解壓後超過大小上限：%s" % info.filename)
        total += info.file_size
        if total > MAX_ARCHIVE_TOTAL_BYTES:
            raise ValueError("ZIP 解壓後總大小超過上限（%d GB）" % (MAX_ARCHIVE_TOTAL_BYTES // 1024 ** 3))


def _validate(z):
    infos = z.infolist()
    _check_limits(infos)
    names = [i.filename for i in infos]
    if any(not _safe(n) for n in names) or len(set(n.casefold() for n in names)) != len(names):
        raise ValueError("ZIP 含不安全或重複的路徑")
    if any(any(_suspicious(p) for p in n.split("/")) for n in names):
        raise ValueError("ZIP 含疑似帳密檔")
    if any((i.external_attr >> 16) & 0o170000 == 0o120000 for i in infos):
        raise ValueError("ZIP 含符號連結")
    bad = z.testzip()
    if bad:
        raise ValueError("ZIP 損壞：%s" % bad)
    manifest = json.loads(z.read(MANIFEST).decode("utf-8"))
    if not isinstance(manifest, dict) or not isinstance(manifest.get("檔案"), dict) or not isinstance(manifest.get("全部檔案"), dict):
        raise ValueError("清單欄位不正確")
    _keyed(manifest["檔案"])
    _keyed(manifest["全部檔案"])
    deleted = manifest.get("已刪除", {})
    if not isinstance(deleted, (dict, list)) or any(not isinstance(n, str) or not _safe(n) for n in deleted):
        raise ValueError("清單含不安全的刪除路徑")
    for name in list(manifest["檔案"]) + list(manifest["全部檔案"]) + list(deleted):
        rel = name[len(CONFLICT):] if name.startswith(CONFLICT) else name
        if rel.casefold().startswith(PROGRAM.casefold()):
            sub = rel[len(PROGRAM):]
            if not _safe(sub) or sub.split("/", 1)[0].casefold() in ("memoization", "models"):
                raise ValueError("程式路徑不可指向累積資料或模型：%s" % rel)
    expected = manifest["檔案"]
    for name, meta in expected.items():
        if not isinstance(name, str) or not isinstance(meta, dict) or not isinstance(meta.get("大小"), int) or not isinstance(meta.get("sha256"), str):
            raise ValueError("清單檔案欄位不正確")
    actual = {i.filename for i in infos if not i.is_dir()} - {MANIFEST}
    if set(expected) != actual:
        raise ValueError("ZIP 檔案與清單不一致：%s" % "、".join(sorted(set(expected) ^ actual)[:20]))
    bad = []
    for name, meta in expected.items():
        with z.open(name) as f:
            if _digest(f) != meta:
                bad.append(name)
    if bad:
        raise ValueError("指紋不符：%s" % "、".join(bad[:20]))
    return manifest


def _journal_path(dest, target):
    return target.relative_to(dest).as_posix() if target.is_relative_to(dest) else str(target)


def _write_journal(dest, stage, targets):
    """換檔前記下這次會動到的每個檔（targets 照實際順序）：原本就有的搬去 stage/old_N，沒有的是新增。
    強殺之後靠這份還原；N 的算法跟 backup() 一樣，只有原本存在的才佔編號。"""
    from _common import write_generated
    steps, folders, count = [], set(), 0
    for target in targets:
        saved = None
        if target.exists():
            saved = "old_%d" % count
            count += 1
        steps.append({"目標": _journal_path(dest, target), "舊": saved})
        parent = target.parent
        while not parent.exists():
            folders.add(parent)
            parent = parent.parent
    write_generated(dest / JOURNAL, {"格式版本": 1, "暫存": stage.name, "步驟": steps,
                                     "新資料夾": [_journal_path(dest, folder) for folder in folders]})


def _journal_target(dest, name, bases):
    """紀錄裡的路徑：工作區內是相對路徑；累積資料、程式是絕對路徑，只准在那兩個資料夾底下。"""
    if not isinstance(name, str):
        raise ValueError("路徑不是文字")
    if _safe(name):
        return dest.joinpath(*PurePosixPath(name).parts)
    target = Path(name)
    if target.is_absolute() and ".." not in target.parts and any(target.is_relative_to(base) for base in bases):
        return target
    raise ValueError("路徑不安全：%s" % name)


def _restore_interrupted(dest, bases):
    """上一次解開被強殺（紀錄還在）：把換過的檔全部還原成解開前的樣子，回傳還原了幾個檔；沒有中斷回 None。
    還原途中再被殺也沒關係：已還原的那一步 old_N 不在了就跳過，再跑一次會接著做。"""
    path = dest / JOURNAL
    if not path.exists():
        return None
    try:
        record = _read_manifest(path)
        name = record["暫存"]
        if not isinstance(name, str) or "/" in name or "\\" in name or not name.startswith(".搬移暫存_"):
            raise ValueError("暫存資料夾名稱不對")
        steps = [(_journal_target(dest, step["目標"], bases), step["舊"]) for step in record["步驟"]]
        folders = [_journal_target(dest, folder, bases) for folder in record["新資料夾"]]
        if any(saved is not None and not re.fullmatch(r"old_\d+", saved) for _, saved in steps):
            raise ValueError("備份檔名不對")
    except (OSError, ValueError, KeyError, TypeError, AttributeError) as exc:
        raise ValueError("上一次解開工作區沒做完，但紀錄 %s 讀不出來（%s）：工作區可能新舊混雜，舊檔還在 .搬移暫存_ 開頭的資料夾，"
                         "這裡不敢自己還原，請先別動這個工作區" % (path, str(exc)[:80])) from None
    stage = dest / name
    if not stage.is_dir() and any(saved for _, saved in steps):
        raise ValueError("上一次解開工作區沒做完，但放舊檔的資料夾 %s 不見了：工作區可能新舊混雜，這裡沒辦法還原，"
                         "請從備份或重新打包的封包處理" % stage)
    restored = 0
    try:
        for target, saved in reversed(steps):
            if saved is None:
                target.unlink(missing_ok=True)          # 解開前沒有這個檔
            elif (stage / saved).exists():
                target.parent.mkdir(parents=True, exist_ok=True)
                replace_file(stage / saved, target)
                restored += 1
    except OSError as exc:
        raise ValueError("上一次解開工作區沒做完，還原到一半失敗（%s）：檔案可能開著，關掉後再跑一次解開工作區，"
                         "還沒還原的舊檔都還在 %s" % (exc, stage)) from None
    for folder in sorted(folders, key=lambda item: len(item.parts), reverse=True):
        try:
            folder.rmdir()
        except OSError:
            pass
    path.unlink()
    shutil.rmtree(stage, ignore_errors=True)
    return restored


def _clean_leftovers(dest):
    """沒有紀錄的暫存：換檔還沒開始（只有 new_N）或寫紀錄寫到一半（.tmp），可以直接清。
    有 old_N 的留著、回傳名字：舊版程式中斷留下的，裡面可能是唯一一份舊檔。"""
    kept = []
    for path in dest.glob(".搬移暫存_*") if dest.is_dir() else ():
        if path.is_dir():
            if any(item.name.startswith("old_") for item in path.iterdir()):
                kept.append(path.name)
            else:
                shutil.rmtree(path, ignore_errors=True)
        elif path.name.endswith(".tmp"):
            path.unlink(missing_ok=True)
    return kept


def unpack(args, settings):
    dest = Path(os.path.abspath(args.destination))
    stage = None
    backups, placed, created_dirs = [], [], []
    dest_created = False
    committed = False
    journal_written = False
    restored_before = False
    try:
        _reject_links(dest)
        memo = Path(os.path.abspath(_memo_dir()))
        program = Path(os.path.abspath(_program_dir()))
        _reject_links(memo)
        _reject_links(program)
        restored = _restore_interrupted(dest, (memo, program))
        if restored is not None:
            restored_before = True
            print("上一次解開工作區沒做完：已還原 %d 個檔，工作區回到解開前的樣子，現在重新解開" % restored, flush=True)
        leftovers = _clean_leftovers(dest)
        if memo == dest or dest in memo.parents:
            raise ValueError("累積資料目錄不能在目的地內")
        if os.path.splitdrive(str(memo))[0].casefold() != os.path.splitdrive(str(dest))[0].casefold() and args.apply_memo:
            raise ValueError("累積資料與目的地必須在同一磁碟才能回滾")
        if getattr(args, "apply_program", False):
            if program == dest or program in dest.parents or dest in program.parents:
                raise ValueError("工作區與程式資料夾不能互相包含")
            if os.path.splitdrive(str(program))[0].casefold() != os.path.splitdrive(str(dest))[0].casefold():
                raise ValueError("程式與目的地必須在同一磁碟才能回滾")
        if dest.exists() and any(p.name != ".執行中.json" for p in dest.iterdir()) and not (dest / workspace.LAYOUT_FILE).is_file():
            raise ValueError("目的地不是空資料夾，也沒有工作區標記檔")
        with zipfile.ZipFile(args.zip_path) as z:
            manifest = _validate(z)
            output_only = manifest.get("模式") == "只要產出"
            prefix = manifest.get("產出前綴", "")
            if output_only and (not isinstance(prefix, str) or not prefix.endswith("/") or not _safe(prefix[:-1]) or "/" in prefix[:-1]):
                raise ValueError("只要產出的清單缺少有效產出前綴")
            baseline_path = dest / BASELINE
            baseline_before = _metadata(baseline_path) if baseline_path.is_file() else None
            old_record = _baseline_record(dest)
            old_base = old_record["檔案"] if old_record is not None else None
            if baseline_before != (_metadata(baseline_path) if baseline_path.is_file() else None):
                raise ValueError("%s 在搬移期間被改過，請重跑" % baseline_path)
            if (dest / BASELINE).resolve() == Path(args.zip_path).resolve():
                raise ValueError("ZIP 位置與同步基準重疊")
            sender = manifest["全部檔案"]
            peer = _keyed(manifest.get("對方檔案", {}))
            timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
            source_name = manifest.get("工作區資料夾名", "來源")
            if not isinstance(source_name, str) or not _safe(source_name) or "/" in source_name:
                raise ValueError("來源工作區名稱不正確")
            operations, warnings = [], list(manifest.get("刪除衝突", []))
            forced = manifest.get("以我為準", [])
            if not isinstance(forced, list) or any(not isinstance(name, str) or not _safe(name) for name in forced):
                raise ValueError("以我為準清單格式不正確")
            force_keys = {name.casefold() for name in forced}
            if not force_keys.issubset({name.casefold() for name in manifest["檔案"] if not name.startswith(CONFLICT)}):
                raise ValueError("以我為準的檔案不在封包中")
            planned_state = {}
            sent_keys = set()
            for name in manifest["檔案"]:
                conflict = name.startswith(CONFLICT)
                rel = name[len(CONFLICT):] if conflict else name
                if rel == ROUND_MARK:
                    continue                  # 舊封包可能帶著別台的標記：不解開，也不算不安全的路徑
                if rel.casefold().startswith(MEMO.casefold()):
                    if not args.apply_memo:
                        continue
                    base, sub = memo, rel[len(MEMO):]
                elif rel.casefold().startswith(PROGRAM.casefold()):
                    if not getattr(args, "apply_program", False):
                        continue
                    base, sub = program, rel[len(PROGRAM):]
                else:
                    base, sub = dest, rel
                if not _safe(sub) or any(_excluded(x) for x in sub.split("/")):
                    raise ValueError("檔案路徑不安全：%s" % rel)
                target = base.joinpath(*PurePosixPath(sub).parts)
                _reject_links(target)
                source_state = _metadata(target) if target.is_file() else None
                # 版本紀錄只往上記：對方的比較高就換，不然留這邊的；不算衝突，也不用跟基準比
                version_record = rel.casefold() == workspace.VERSION_FILE.casefold() and target.is_file()
                if version_record:
                    if not workspace.incoming_version_is_higher(z.read(name), dest):
                        continue
                    conflict = False
                if not conflict and not version_record and rel.casefold() not in force_keys and target.is_file() \
                        and rel.casefold() not in peer:
                    if source_state == manifest["檔案"][name]:
                        continue
                    conflict = True
                if conflict:
                    target = target.with_name(target.stem + ".衝突-" + source_name + "-" + timestamp + target.suffix)
                    if target.exists():
                        raise ValueError("衝突副本已存在：%s" % target)
                    warnings.append(rel)
                else:
                    sent_keys.add(rel.casefold())
                    if rel.casefold() in peer and not version_record:
                        # 已經跟封包一樣＝上次其實解完了（收尾時才被中斷），再解一次沒有壞處
                        if source_state != peer[rel.casefold()][1] and source_state != manifest["檔案"][name]:
                            raise ValueError("目的地在清單產生後改變：%s" % rel)
                _reject_links(target)
                if target.resolve() == Path(args.zip_path).resolve():
                    raise ValueError("ZIP 位置與目的地檔案重疊")
                if target.exists() and not target.is_file():
                    raise ValueError("目的地檔案被資料夾佔用：%s" % target)
                if any(p.exists() and not p.is_dir() for p in target.parents):
                    raise ValueError("目的地資料夾被檔案佔用：%s" % target)
                planned_state[target] = None if conflict else source_state
                operations.append((name, target, conflict, rel))
            planned = {}
            for _, target, _, _ in operations:
                key = str(target).casefold()
                if key in planned:
                    raise ValueError("多個檔案指向同一目的地：%s" % target)
                planned[key] = target
            for target in planned.values():
                if any(str(parent).casefold() in planned for parent in target.parents):
                    raise ValueError("同一目的地同時是檔案和資料夾：%s" % target)
            removed = []
            deleted = manifest.get("已刪除", {})
            if args.apply_deletions:
                for name in deleted:
                    if name.casefold() in sent_keys or name.casefold().startswith("_skill累積/".casefold()) or any(_excluded(p) for p in name.split("/")):
                        warnings.append(name)
                        continue
                    if name.casefold().startswith(PROGRAM.casefold()):
                        if not getattr(args, "apply_program", False):
                            continue
                        target = program.joinpath(*PurePosixPath(name[len(PROGRAM):]).parts)
                    else:
                        target = dest.joinpath(*PurePosixPath(name).parts)
                    _reject_links(target)
                    meta = deleted.get(name) if isinstance(deleted, dict) else None
                    if target.exists() and target.is_file() and isinstance(meta, dict) and _metadata(target) == meta:
                        if target.resolve() == Path(args.zip_path).resolve():
                            raise ValueError("ZIP 位置與刪除路徑重疊")
                        planned_state[target] = meta
                        removed.append(target)
                    elif target.exists():
                        warnings.append(name)
            # 指標最後套用。
            pending = []
            for item in operations:
                name, target, conflict, rel = item
                if not conflict and rel in ("目前作業.json", "法規作業.json"):
                    value = json.loads(z.read(name).decode("utf-8"))
                    field = "目前作業" if rel == "目前作業.json" else "目前法規作業"
                    folder = value.get(field, "")
                    if not isinstance(folder, str) or not _safe(folder) or "/" in folder:
                        warnings.append(rel)
                        continue
                    output = dest / folder
                    if not output.is_dir() and not any(t.is_relative_to(output) for _, t, _, _ in operations):
                        warnings.append(rel)
                        continue
                pending.append(item)
            operations = sorted(pending, key=lambda x: x[3] in MARKERS)
            if not dest.exists():
                dest.mkdir(parents=True)
                dest_created = True
            stage = Path(tempfile.mkdtemp(prefix=".搬移暫存_" + timestamp + "_", dir=dest))
            staged = []
            for index, (name, target, conflict, rel) in enumerate(operations):
                file = stage / ("new_%d" % index)
                with z.open(name) as source, open(file, "wb") as output:
                    shutil.copyfileobj(source, output, 1024 * 1024)
                staged.append((file, target, conflict, rel))
            def make_dirs(folder):
                missing = []
                while not folder.exists():
                    missing.append(folder)
                    folder = folder.parent
                for item in reversed(missing):
                    item.mkdir()
                    created_dirs.append(item)
            def backup(target):
                _reject_links(target)
                expected = planned_state[target]
                actual = _metadata(target) if target.is_file() else None
                if actual != expected or (target.exists() and not target.is_file()):
                    raise ValueError("%s 在搬移期間被改過，請重跑" % target)
                if target.exists():
                    saved = stage / ("old_%d" % len(backups))
                    replace_file(target, saved)
                    backups.append((saved, target))
            report = None
            if deleted and not args.apply_deletions:
                report = dest / ("搬移_來源已刪除_%s_%s.json" % (timestamp, uuid.uuid4().hex[:8]))
            _write_journal(dest, stage, [*removed, *(item[1] for item in staged), baseline_path, *filter(None, [report])])
            journal_written = True
            for target in removed:
                backup(target)
            for file, target, conflict, rel in staged:
                make_dirs(target.parent)
                backup(target)
                replace_file(file, target)
                placed.append(target)
            # 基準同樣納入回滾。
            paths, _, _ = _files(dest)
            current = {k: _metadata(v) for k, v in paths.items()}
            if manifest.get("連同累積資料") or any(k.startswith(MEMO) for k in sender):
                paths, _, _ = _files(memo)
                current.update({MEMO + k: _metadata(v) for k, v in paths.items()})
            if manifest.get("連同程式") or any(k.startswith(PROGRAM) for k in sender):
                paths, _, _ = _program_files()
                current.update({PROGRAM + k: _metadata(v) for k, v in paths.items()})
            now, sent = _keyed(current), _keyed(sender)
            conflicts = {rel.casefold() for _, _, conflict, rel in operations if conflict}
            newbase = {name: meta for key, (name, meta) in now.items() if key in sent and sent[key][1] == meta and key not in conflicts}
            newbase = _merge_baseline(old_base, newbase, output_only, prefix, bool(manifest.get("連同累積資料")), bool(manifest.get("連同程式")) and getattr(args, "apply_program", False))
            baseline = dest / BASELINE
            planned_state[baseline] = baseline_before
            backup(baseline)
            file = stage / "new_baseline"
            record = {"格式版本": 1, "檔案": newbase, "最後套用ID": manifest.get("搬移ID")}
            for key in ("最後打包ID", "打包前基準"):
                if old_record and key in old_record:
                    record[key] = old_record[key]
            file.write_text(json.dumps(record, ensure_ascii=False, indent=2), encoding="utf-8")
            replace_file(file, baseline)
            placed.append(baseline)
            if deleted and not args.apply_deletions:
                file = stage / "new_report"
                file.write_text(json.dumps(deleted, ensure_ascii=False, indent=2), encoding="utf-8")
                replace_file(file, report)
                placed.append(report)
            for target in removed:
                parent = target.parent
                while parent != dest and parent.is_relative_to(dest):
                    try:
                        parent.rmdir()
                    except OSError:
                        break
                    parent = parent.parent
            (dest / JOURNAL).unlink()
            committed = True
            cleanup_note = ""
            try:
                shutil.rmtree(stage)
                stage = None
            except OSError:
                cleanup_note = "；警告：暫存資料夾 %s 沒清乾淨，可以手動刪" % stage
            note = "；警告：%s" % "、".join(warnings[:20]) if warnings else ""
            if leftovers:
                note += "；以前中斷留下的暫存資料夾 %s 裡有舊檔，確認用不到再手動刪" % "、".join(leftovers)
            if deleted and not args.apply_deletions:
                note += "；來源刪了 %d 個檔，這裡沒刪；清單：%s" % (len(deleted), report)
            if not args.apply_memo and any(n.startswith(MEMO) for n in manifest["檔案"]):
                note += "；累積資料未套用（封包裡的累積資料沒有寫進來。確認封包來源可信後，請使用者自己開命令列再跑一次，加 --套用累積資料）"
            if not getattr(args, "apply_program", False) and (manifest.get("連同程式") or any(n.casefold().startswith(PROGRAM.casefold()) for n in sender) or any(n.casefold().startswith(PROGRAM.casefold()) for n in deleted)):
                note += "；程式未套用（封包裡的程式沒有寫進來。確認封包來源可信後，請使用者自己開命令列再跑一次，加 --套用程式）"
            note += cleanup_note
            print("解開工作區：套用 %d 個檔，刪除 %d 個；目的地：%s%s" % (len(operations), len(removed), dest, note))
            return 0
    except (OSError, ValueError, KeyError, TypeError, RuntimeError, zipfile.BadZipFile, zlib.error, AttributeError) as exc:
        if committed:
            print("解開工作區：已套用；警告：暫存資料夾 %s 沒清乾淨，可以手動刪" % stage)
            return 0
        rollback_errors = []
        for target in reversed(placed):
            try:
                target.unlink(missing_ok=True)
            except OSError as error:
                rollback_errors.append(str(error))
        for saved, target in reversed(backups):
            try:
                target.parent.mkdir(parents=True, exist_ok=True)
                replace_file(saved, target)
            except OSError as error:
                rollback_errors.append(str(error))
        for folder in reversed(created_dirs):
            try:
                folder.rmdir()
            except OSError:
                pass
        if journal_written and not rollback_errors:
            (dest / JOURNAL).unlink(missing_ok=True)      # 還原失敗就留著：下次解開會接著還原
        if stage and not rollback_errors:
            shutil.rmtree(stage, ignore_errors=True)
        if dest_created:
            try:
                dest.rmdir()
            except OSError:
                pass
        print("解開工作區失敗：%s%s%s" % (str(exc).replace("\n", " "), "；回滾失敗，備份保留：%s" % stage if rollback_errors else "",
                                          "；上一次沒解開完的部分已還原，工作區是解開前的樣子，換一個完好的封包再解一次"
                                          if restored_before and not rollback_errors else ""))
        return 1


def verify(args, settings):
    try:
        target = Path(args.target)
        if target.is_dir():
            if not args.manifest:
                raise ValueError("資料夾核對需要 --清單")
            manifest = _read_manifest(args.manifest)
            scope = None
            if manifest.get("模式") == "只要產出":
                prefixes = {k.split("/", 1)[0] + "/" for k in manifest["全部檔案"] if "/" in k and not k.startswith(MEMO)}
                scope = lambda k: k in MARKERS or any(k.startswith(p) for p in prefixes)
            paths, skipped, skipped_dirs = _files(target, scope)
            actual = {k: _metadata(v) for k, v in paths.items()}
            expected = manifest["全部檔案"]
            if manifest.get("連同累積資料") or any(k.startswith(MEMO) for k in expected):
                paths, memo_skipped, memo_dirs = _files(_memo_dir())
                skipped += memo_skipped
                skipped_dirs += memo_dirs
                actual.update({MEMO + k: _metadata(v) for k, v in paths.items()})
            if manifest.get("連同程式") or any(k.startswith(PROGRAM) for k in expected):
                paths, program_skipped, program_dirs = _program_files()
                skipped += program_skipped
                skipped_dirs += program_dirs
                actual.update({PROGRAM + k: _metadata(v) for k, v in paths.items()})
        else:
            skipped = 0
            skipped_dirs = 0
            with zipfile.ZipFile(target) as z:
                embedded = _validate(z)
                manifest = _read_manifest(args.manifest) if args.manifest else embedded
                actual = embedded["檔案"]
                expected = manifest["檔案"]
        actual, expected = _keyed(actual), _keyed(expected)
        same = [k for k in expected.keys() & actual.keys() if expected[k][1] == actual[k][1]]
        different = sorted(expected[k][0] for k in expected.keys() & actual.keys() if expected[k][1] != actual[k][1])
        missing = sorted(expected[k][0] for k in expected.keys() - actual.keys())
        extra = sorted(actual[k][0] for k in actual.keys() - expected.keys())
        print("核對工作區：相符 %d，內容不同 %d，少了 %d，多出 %d；不同：%s；少了：%s；略過疑似帳密檔 %d 個、資料夾 %d 個（不搬）" %
              (len(same), len(different), len(missing), len(extra), "、".join(different[:20]) or "無", "、".join(missing[:20]) or "無", skipped, skipped_dirs))
        return int(bool(different or missing or extra))
    except (OSError, ValueError, KeyError, TypeError, RuntimeError, zipfile.BadZipFile, AttributeError, zlib.error) as exc:
        print("核對工作區失敗：%s" % exc)
        return 1
