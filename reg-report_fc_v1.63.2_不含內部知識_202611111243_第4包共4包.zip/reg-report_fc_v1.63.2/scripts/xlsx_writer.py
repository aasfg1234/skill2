# -*- coding: utf-8 -*-
"""純 stdlib 寫 .xlsx（這台電腦沒有 openpyxl，而且我們不裝套件）。
.xlsx 就是一個 zip，裡面幾個 XML。只做報告需要的：多工作表、inline 字串、數字格、
一種字型（微軟正黑體 11）、靠左垂直置中自動換行、標題列粗體、欄寬照內容算。"""
import csv, io, os, re, sys, unicodedata, zipfile
from xml.sax.saxutils import escape

_REGDIFF = os.path.join(os.path.dirname(os.path.abspath(__file__)), "regdiff")
if _REGDIFF not in sys.path:
    sys.path.insert(0, _REGDIFF)
from _common import XML_CLEANUP_NOTICE, sanitize_for_xml, stable_zip_info
from file_replace import replace_file
import notices as nt

_CTRL = re.compile(r"[\x00-\x08\x0b\x0c\x0e-\x1f]")

# 這一份 .xlsx 清掉了幾個 XML 不合法字元。_CTRL 只清低位控制字元，U+FFFE、
# U+FFFF 與未配對代理字照樣寫進去——.xlsx 打不開，程式卻回報成功、exit 0
# （實測 no 32）。寫完一份發一則提醒，不是每一格一則。
_XML_CLEANED = [0]
_CELL_LIMIT = 32767      # Excel 儲存格上限
_CELL_KEEP = 32000       # 截斷後留的長度，留空間給截斷提示
# 這一張工作表截斷了幾格（_sheet_xml 每張表開頭歸零）。有截斷的表另存一份完整的 csv。
_TRUNCATED = [0]
# 上一次 write_xlsx 因為截斷而另存的完整 csv（正式路徑），write_tables_or_csv 拿去併進回傳清單
_SPILLED = []
# v1.55.x：這一次報告不能動的檔（keep_opinions 讀不到的舊報告）：{base_path: (讀不到的路徑, 寫成功後要呼叫的函式)}
_HOLD = {}
# 上一次 write_tables_or_csv 為什麼沒寫成 xlsx（OSError／ValueError；寫成了是 None）：呼叫端用它講該怎麼做
LAST_FAILURE = [None]


# 列印設定（每張工作表都一樣）：A4 橫向、寬度縮成一頁、高度不限，表頭每頁重複（表頭在 write_xlsx 的 definedNames）。
# 元素順序是 Excel 認的：sheetPr 要在 worksheet 最前面，pageMargins、pageSetup 要在 hyperlinks 之後，順序錯 Excel 會要修復。
_PRINT_FIT = '<sheetPr><pageSetUpPr fitToPage="1"/></sheetPr>'
_PRINT_PAGE = ('<pageMargins left="0.25" right="0.25" top="0.5" bottom="0.5" header="0.3" footer="0.3"/>'
               '<pageSetup paperSize="9" orientation="landscape" fitToWidth="1" fitToHeight="0"/>')


class XlsxOptionError(ValueError):
    """工作表選項格式不正確，不能改用 CSV 掩蓋設定錯誤。"""


class RichText:
    """同一個 Excel 儲存格內含一般文字與局部樣式的安全資料物件。

    ``runs`` 是 ``(文字, 樣式名稱)`` 的序列。目前只公開 ``red_underline``，
    用於人用報告標示真正有變動的字。``str()`` 一律回原文，CSV 退路與欄寬
    計算不會看到 Python 物件表示法。
    """

    def __init__(self, runs):
        normalized = []
        for run in runs or ():
            if isinstance(run, (list, tuple)) and len(run) == 2:
                text, style = run
            else:
                text, style = run, ""
            text = "" if text is None else str(text)
            if text:
                normalized.append((text, str(style or "")))
        self.runs = tuple(normalized)

    @property
    def text(self):
        return "".join(text for text, _style in self.runs)

    def __str__(self):
        return self.text

    def __len__(self):
        return len(self.text)

    def __contains__(self, value):
        return str(value) in self.text


def rich_text(value, highlight_ranges=()):
    """把原文字串與 0 起算、尾端不含的差異範圍組成 ``RichText``。

    重疊或相鄰範圍會合併；無效範圍安全略過。呼叫端只需提供原文與差異位置，
    不必自己處理 Excel XML。
    """
    text = "" if value is None else str(value)
    ranges = []
    for item in highlight_ranges or ():
        if not isinstance(item, (list, tuple)) or len(item) != 2:
            continue
        try:
            start, end = int(item[0]), int(item[1])
        except (TypeError, ValueError):
            continue
        start, end = max(0, start), min(len(text), end)
        if end > start:
            ranges.append((start, end))
    ranges.sort()
    merged = []
    for start, end in ranges:
        if merged and start <= merged[-1][1]:
            merged[-1] = (merged[-1][0], max(merged[-1][1], end))
        else:
            merged.append((start, end))
    if not merged:
        return RichText(((text, ""),))

    runs, cursor = [], 0
    for start, end in merged:
        if start > cursor:
            runs.append((text[cursor:start], ""))
        runs.append((text[start:end], "red_underline"))
        cursor = end
    if cursor < len(text):
        runs.append((text[cursor:], ""))
    return RichText(runs)


# 工作表選項只接受固定欄位。未知欄位一律擋下，避免拼錯後被靜默忽略。
# v1.51.0 新增：column_styles（某一欄的資料格都上同一種底色，例如承辦意見淡綠）、
# cell_styles（單格底色，例如 AI判定「要改」淡紅）、header_style（表頭列樣式，例如 header_fill 淡灰底）、
# filter_column／filter_values（自動篩選的「目前只顯示這些值」：值不在清單裡的列寫成篩選隱藏，
# Excel 打開時那一欄的篩選箭頭亮著，清除篩選就全部看得到）。
_SHEET_OPTION_KEYS = frozenset(("freeze_header", "freeze_columns", "auto_filter", "row_styles", "hidden_rows",
                                "links", "column_widths", "column_styles", "cell_styles", "header_style",
                                "filter_column", "filter_values"))
_ROW_STYLE_IDS = {
    "body": 1,
    "header": 2,
    "section": 3,        # 淡綠底（承辦意見欄）
    "warn": 4,           # 淡黃底（請承辦確認）
    "danger": 5,         # 淡紅底（要改）
    "header_fill": 11,   # 粗體＋淡灰底（表頭）
    "header_green": 12,  # 粗體＋淡綠底（承辦意見欄的表頭）
}
_LINK_STYLE_IDS = {
    "body": 6,
    "header": 7,
    "section": 8,
    "warn": 9,
    "danger": 10,
    "header_fill": 7,
    "header_green": 7,
}
# 承辦意見欄：承辦唯一要填的欄，凡有這一欄的工作表都上淡綠底、欄寬 40（欄是 precedents 在寫檔前才加的，所以認欄名）
OPINION_COLUMN = "承辦意見"
OPINION_TITLE = "承辦意見（空白＝同意；不同意請寫原因）"
OPINION_WIDTH = 40


def _opinion_title():
    """表頭要不要換成長句：讀回承辦意見的程式（precedents）宣告認得才換。
    它現在用「承辦意見」四個字找欄：表頭自己先改，收回饋會整欄找不到、意見全部收不回來，而且不會報錯。"""
    try:
        import precedents
    except ImportError:
        return OPINION_COLUMN
    return OPINION_TITLE if getattr(precedents, "READS_OPINION_TITLE", False) else OPINION_COLUMN
_CELL_REF_RE = re.compile(r"^\$?([A-Za-z]{1,3})\$?([1-9][0-9]*)$")
_MAX_EXCEL_COLUMN = 16384  # XFD
_MAX_EXCEL_ROW = 1048576


def truncate_note(sheet_name, csv_names=None):
    """某一格超過 Excel 上限被截斷時，格子裡留的那句提示（小瑕疵 17）。

    以前這句寫死成「全文見 _候選.csv」——那是「候選審查」那一張表的檔名，
    別張工作表被截斷時會把人指到一個跟它無關的檔案（「總結」表的長格子
    叫人去看 _候選.csv）。改成把**這一張工作表自己**的名字與對應的 csv
    寫進去，指到的才是真的有全文的那一份。

    csv_names：{工作表名: 該張表的 csv 檔名}。不給就用 write_tables_or_csv
    的預設命名（<同名>_<工作表名>.csv）。
    """
    target = (csv_names or {}).get(sheet_name) or ("_%s.csv" % sheet_name)
    return "…（已截斷，工作表「%s」的全文見同資料夾的 %s）" % (sheet_name, target)


def _csv_safe(value):
    """人會用 Excel 開的 CSV：格子以 = + - @ 或 tab／換行開頭時 Excel 會當公式算（「-」「=合計」變成 #NAME?
    或真的執行公式），前面補一個單引號讓它當文字。只用在這裡的退路 CSV（純給人看，程式不讀回）；
    決定表、AI 表程式會讀回去比指紋，不能動（審查 C14）。"""
    text = "" if value is None else str(value)
    return "'" + text if text[:1] in ("=", "+", "-", "@", "\t", "\r") else text


def _write_csv(path, header, rows):
    with io.open(path, "w", encoding="utf-8-sig", newline="") as f:
        writer = csv.writer(f)
        writer.writerow(header)
        for row in rows:
            writer.writerow([_csv_safe(cell) for cell in row])

def display_width(text):
    w = 0
    for ch in str(text):
        w += 2 if unicodedata.east_asian_width(ch) in ("W", "F") else 1
    return w

def column_widths(header, rows, lo=8, hi=80):
    # 欄數不能只看 header：像「總結」那種前面是兩欄統計、後面接一段 5 欄子表的參差列，
    # 資料列可能比 header 長，欄數要照最寬的那一列算，不然多出來的欄完全沒有 <col> 寬度。
    n = max(len(header), max((len(row) for row in rows), default=0))
    best = [0] * n
    for row in [header] + list(rows):
        for i in range(min(n, len(row))):
            for line in str(row[i] if row[i] is not None else "").split("\n"):
                best[i] = max(best[i], display_width(line))
    return [min(hi, max(lo, round(b * 1.1 + 2, 1))) for b in best]

def _col(i):  # 0 → A, 26 → AA
    s = ""
    i += 1
    while i:
        i, r = divmod(i - 1, 26)
        s = chr(65 + r) + s
    return s

def _clean_cell_text(value):
    """把一段儲存格文字清成 Excel XML 可接受的內容。"""
    text = ("" if value is None else str(value)).replace("\r", "")
    text = _CTRL.sub("", text)
    text, removed = sanitize_for_xml(text)
    _XML_CLEANED[0] += removed
    return text


def _rich_inline_string(value):
    """輸出 inline rich text；非標示文字沿用儲存格本身的字型。"""
    parts = []
    for text, run_style in value.runs:
        clean = _clean_cell_text(text)
        if not clean:
            continue
        properties = ""
        if run_style == "red_underline":
            properties = '<rPr><color rgb="FFFF0000"/><u/></rPr>'
        parts.append('<r>%s<t xml:space="preserve">%s</t></r>'
                     % (properties, escape(clean)))
    return "".join(parts) or '<t xml:space="preserve"></t>'


def _cell(ref, value, style, note=""):
    if isinstance(value, bool):
        value = str(value)
    if isinstance(value, int):
        return '<c r="%s" s="%d"><v>%d</v></c>' % (ref, style, value)
    if isinstance(value, float):
        # 分數這類欄要寫成數字格：寫成文字格的話，Excel 排序是照字串排（「9」排在「85」後面）
        return '<c r="%s" s="%d"><v>%s</v></c>' % (ref, style, repr(value))

    rich = value if isinstance(value, RichText) else None
    text = _clean_cell_text(rich.text if rich is not None else value)
    if len(text) > _CELL_LIMIT:
        # Excel 一格上限 32,767 字元，超過整份 .xlsx 打不開；全文另外看同名的
        # csv（沒有這個上限，見 truncate_note）。那份 csv 由 write_xlsx 真的寫出來
        # ——以前只有這句提示、沒有那個檔，截掉的字就不見了。
        text = text[:_CELL_KEEP] + note
        _TRUNCATED[0] += 1
        rich = None                 # 截斷後不可能再安全對回原差異位置
    if rich is not None:
        return '<c r="%s" s="%d" t="inlineStr"><is>%s</is></c>' % (
            ref, style, _rich_inline_string(rich))
    return '<c r="%s" s="%d" t="inlineStr"><is><t xml:space="preserve">%s</t></is></c>' % (
        ref, style, escape(text))

def _column_number(letters):
    """欄名轉成 1 起算數字，給儲存格座標驗證與排序使用。"""
    value = 0
    for letter in letters.upper():
        value = value * 26 + ord(letter) - ord("A") + 1
    return value


def _normal_cell_ref(value, label):
    """驗證單一 Excel 儲存格座標，並統一成沒有錨點符號的大寫形式。"""
    if not isinstance(value, str):
        raise XlsxOptionError("%s 必須是 Excel 儲存格座標，例如 A1" % label)
    match = _CELL_REF_RE.match(value.strip())
    if not match:
        raise XlsxOptionError("%s 不是有效的 Excel 儲存格座標：%r" % (label, value))
    letters, row_text = match.groups()
    column = _column_number(letters)
    row = int(row_text)
    if column > _MAX_EXCEL_COLUMN or row > _MAX_EXCEL_ROW:
        raise XlsxOptionError("%s 超出 Excel 工作表範圍：%s" % (label, value))
    return "%s%d" % (letters.upper(), row)


def _cell_ref_position(ref):
    """已正規化的儲存格座標回傳（列號、0 起算欄號）。"""
    match = _CELL_REF_RE.match(ref)
    return int(match.group(2)), _column_number(match.group(1)) - 1


def _safe_sheet_names(sheets):
    """產生 Excel 可接受而且不撞名的工作表名，保留原名到安全名的順序對應。"""
    used = set()
    names = []
    for index, (name, _header, _rows) in enumerate(sheets, 1):
        # 控制字元與 XML 不允許字元同樣不能留在工作表名裡，否則整份 xlsx 會壞掉。
        safe = re.sub(r"[\x00-\x1f\\\\/?*\[\]:]", "_", str(name))
        safe, _removed = sanitize_for_xml(safe, filler="_")
        safe = safe[:31] or "Sheet%d" % index
        base, serial = safe, 2
        # Excel 以不分大小寫的方式看工作表名，大小寫不同也必須避開。
        while safe.casefold() in used:
            suffix = "_%d" % serial
            safe = base[:31 - len(suffix)] + suffix
            serial += 1
        used.add(safe.casefold())
        names.append(safe)
    return names


def _sheet_location(sheet_name, cell_ref):
    """內部超連結位置；工作表名一律加引號，內含單引號時照 Excel 規則重複。"""
    return "'%s'!%s" % (sheet_name.replace("'", "''"), cell_ref)


def _prepare_sheet_options(sheet_options, sheets):
    """驗證工作表選項，並把超連結目標改成工作表索引，避免清理名稱後指錯表。"""
    if sheet_options is None:
        return [None] * len(sheets)
    if not isinstance(sheet_options, (list, tuple)):
        raise XlsxOptionError("sheet_options 必須是與 sheets 同順序的 list 或 tuple")
    if len(sheet_options) != len(sheets):
        raise XlsxOptionError("sheet_options 數量必須與 sheets 相同")

    originals = [name for name, _header, _rows in sheets]
    positions = {}
    for index, name in enumerate(originals):
        positions.setdefault(name, []).append(index)

    prepared = []
    for sheet_index, option in enumerate(sheet_options, 1):
        if option is None:
            prepared.append(None)
            continue
        if not isinstance(option, dict):
            raise XlsxOptionError("第 %d 個 sheet_options 必須是 dict 或 None" % sheet_index)
        unknown = set(option) - _SHEET_OPTION_KEYS
        if unknown:
            raise XlsxOptionError("第 %d 個 sheet_options 有不支援的欄位：%s"
                                  % (sheet_index, "、".join(sorted(map(str, unknown)))))

        values = {
            "freeze_header": option.get("freeze_header", False),
            "freeze_columns": option.get("freeze_columns", 0),
            "auto_filter": option.get("auto_filter", False),
            "row_styles": option.get("row_styles", {}),
            "hidden_rows": option.get("hidden_rows", ()),
            "links": option.get("links", []),
            "column_widths": option.get("column_widths"),
            "column_styles": option.get("column_styles", {}),
            "cell_styles": option.get("cell_styles", {}),
            "header_style": option.get("header_style"),
            "filter_column": option.get("filter_column"),
            "filter_values": option.get("filter_values"),
        }
        for key in ("freeze_header", "auto_filter"):
            if not isinstance(values[key], bool):
                raise XlsxOptionError("第 %d 個 sheet_options 的 %s 必須是 bool"
                                      % (sheet_index, key))
        freeze_columns = values["freeze_columns"]
        if isinstance(freeze_columns, bool) or not isinstance(freeze_columns, int) or not 0 <= freeze_columns <= 20:
            raise XlsxOptionError("第 %d 個 sheet_options 的 freeze_columns 必須是 0 到 20 的整數" % sheet_index)

        row_styles = values["row_styles"]
        if not isinstance(row_styles, dict):
            raise XlsxOptionError("第 %d 個 sheet_options 的 row_styles 必須是 dict"
                                  % sheet_index)
        checked_styles = {}
        for row, style in row_styles.items():
            if isinstance(row, bool) or not isinstance(row, int) or not 1 <= row <= _MAX_EXCEL_ROW:
                raise XlsxOptionError("第 %d 個 sheet_options 的 row_styles 列號必須是 1 到 %d 的整數"
                                      % (sheet_index, _MAX_EXCEL_ROW))
            if style not in _ROW_STYLE_IDS:
                raise XlsxOptionError("第 %d 個 sheet_options 的 row_styles 樣式不支援：%r"
                                      % (sheet_index, style))
            checked_styles[row] = style

        hidden_rows = values["hidden_rows"]
        if not isinstance(hidden_rows, (list, tuple, set, frozenset)):
            raise XlsxOptionError("第 %d 個 sheet_options 的 hidden_rows 必須是列號序列" % sheet_index)
        checked_hidden = set()
        for row in hidden_rows:
            if isinstance(row, bool) or not isinstance(row, int) or not 2 <= row <= _MAX_EXCEL_ROW:
                raise XlsxOptionError("第 %d 個 sheet_options 的 hidden_rows 列號必須是 2 到 %d 的整數"
                                      % (sheet_index, _MAX_EXCEL_ROW))
            checked_hidden.add(row)

        column_styles = values["column_styles"]
        if not isinstance(column_styles, dict):
            raise XlsxOptionError("第 %d 個 sheet_options 的 column_styles 必須是 dict" % sheet_index)
        checked_column_styles = {}
        for column, style in column_styles.items():
            if isinstance(column, bool) or not isinstance(column, int) or not 0 <= column < _MAX_EXCEL_COLUMN:
                raise XlsxOptionError("第 %d 個 sheet_options 的 column_styles 欄號必須是 0 起算的整數" % sheet_index)
            if style not in _ROW_STYLE_IDS:
                raise XlsxOptionError("第 %d 個 sheet_options 的 column_styles 樣式不支援：%r" % (sheet_index, style))
            checked_column_styles[column] = style
        cell_styles = values["cell_styles"]
        if not isinstance(cell_styles, dict):
            raise XlsxOptionError("第 %d 個 sheet_options 的 cell_styles 必須是 dict" % sheet_index)
        checked_cell_styles = {}
        for key, style in cell_styles.items():
            if (not isinstance(key, (list, tuple)) or len(key) != 2
                    or any(isinstance(v, bool) or not isinstance(v, int) for v in key)
                    or not 1 <= key[0] <= _MAX_EXCEL_ROW or not 0 <= key[1] < _MAX_EXCEL_COLUMN):
                raise XlsxOptionError("第 %d 個 sheet_options 的 cell_styles 鍵必須是 (列號, 0 起算欄號)" % sheet_index)
            if style not in _ROW_STYLE_IDS:
                raise XlsxOptionError("第 %d 個 sheet_options 的 cell_styles 樣式不支援：%r" % (sheet_index, style))
            checked_cell_styles[(key[0], key[1])] = style
        header_style = values["header_style"]
        if header_style is not None and header_style not in _ROW_STYLE_IDS:
            raise XlsxOptionError("第 %d 個 sheet_options 的 header_style 樣式不支援：%r" % (sheet_index, header_style))
        filter_column, filter_values = values["filter_column"], values["filter_values"]
        if filter_column is not None:
            if isinstance(filter_column, bool) or not isinstance(filter_column, int) or not 0 <= filter_column < _MAX_EXCEL_COLUMN:
                raise XlsxOptionError("第 %d 個 sheet_options 的 filter_column 必須是 0 起算的欄號" % sheet_index)
            if not values["auto_filter"]:
                raise XlsxOptionError("第 %d 個 sheet_options 的 filter_column 要配合 auto_filter=True" % sheet_index)
            if not isinstance(filter_values, (list, tuple, set, frozenset)) or not filter_values:
                raise XlsxOptionError("第 %d 個 sheet_options 的 filter_values 必須是至少一個值的序列" % sheet_index)
            filter_values = [str(v) for v in filter_values]
            # 值不在清單裡的資料列就是篩選隱藏的列：跟 hidden_rows 合起來，報告上「隱藏」只有這一套
            _name, _header, rows = sheets[sheet_index - 1]
            for row_number, row in enumerate(rows, 2):
                value = row[filter_column] if filter_column < len(row) else ""
                if str(value if value is not None else "") not in filter_values:
                    checked_hidden.add(row_number)
        else:
            filter_values = None

        raw_widths = values["column_widths"]
        checked_widths = None
        if raw_widths is not None:
            if not isinstance(raw_widths, (list, tuple)):
                raise XlsxOptionError("第 %d 個 sheet_options 的 column_widths 必須是 list、tuple 或 None"
                                      % sheet_index)
            _name, header, rows = sheets[sheet_index - 1]
            columns = max(len(header), max((len(row) for row in rows), default=0))
            if len(raw_widths) != columns:
                raise XlsxOptionError("第 %d 個 sheet_options 的 column_widths 數量必須是 %d"
                                      % (sheet_index, columns))
            checked_widths = []
            for column_index, width in enumerate(raw_widths, 1):
                if isinstance(width, bool) or not isinstance(width, (int, float)) or not 0 < width <= 255:
                    raise XlsxOptionError("第 %d 個 sheet_options 的第 %d 個 column_widths 必須是 0 到 255 的數字"
                                          % (sheet_index, column_index))
                checked_widths.append(float(width))

        links = values["links"]
        if not isinstance(links, (list, tuple)):
            raise XlsxOptionError("第 %d 個 sheet_options 的 links 必須是 list 或 tuple"
                                  % sheet_index)
        checked_links = []
        seen_refs = set()
        for link_index, link in enumerate(links, 1):
            if not isinstance(link, dict):
                raise XlsxOptionError("第 %d 個 sheet_options 的第 %d 個 links 項目必須是 dict"
                                      % (sheet_index, link_index))
            keys = set(link)
            if keys == {"ref", "url"}:
                # 對外網址（查證來源）：只收 http／https，別的協定（file:、javascript:）一律不寫
                ref = _normal_cell_ref(link["ref"], "links[%d].ref" % link_index)
                url = link["url"]
                if not isinstance(url, str) or not re.match(r"^https?://[^\s<>\"]+$", url):
                    raise XlsxOptionError("links[%d].url 必須是 http(s) 網址" % link_index)
                if ref in seen_refs:
                    raise XlsxOptionError("第 %d 個 sheet_options 的 links 重複設定儲存格：%s"
                                          % (sheet_index, ref))
                seen_refs.add(ref)
                row, column = _cell_ref_position(ref)
                checked_links.append({"ref": ref, "row": row, "column": column, "url": url})
                continue
            required = frozenset(("ref", "target_sheet", "target_ref"))
            if keys != required:
                missing = required - keys
                extra = keys - required
                parts = []
                if missing:
                    parts.append("缺少 %s" % "、".join(sorted(missing)))
                if extra:
                    parts.append("多出 %s" % "、".join(sorted(map(str, extra))))
                raise XlsxOptionError("第 %d 個 sheet_options 的第 %d 個 links 項目格式錯誤（%s）"
                                      % (sheet_index, link_index, "；".join(parts)))
            ref = _normal_cell_ref(link["ref"], "links[%d].ref" % link_index)
            target_ref = _normal_cell_ref(link["target_ref"], "links[%d].target_ref" % link_index)
            target_sheet = link["target_sheet"]
            if not isinstance(target_sheet, str):
                raise XlsxOptionError("links[%d].target_sheet 必須是原工作表名稱字串" % link_index)
            candidates = positions.get(target_sheet, [])
            if not candidates:
                raise XlsxOptionError("links[%d].target_sheet 找不到原工作表名稱：%s"
                                      % (link_index, target_sheet))
            if len(candidates) != 1:
                raise XlsxOptionError("links[%d].target_sheet 指到重複的原工作表名稱：%s"
                                      % (link_index, target_sheet))
            if ref in seen_refs:
                raise XlsxOptionError("第 %d 個 sheet_options 的 links 重複設定儲存格：%s"
                                      % (sheet_index, ref))
            seen_refs.add(ref)
            row, column = _cell_ref_position(ref)
            checked_links.append({
                "ref": ref,
                "row": row,
                "column": column,
                "target_index": candidates[0],
                "target_ref": target_ref,
            })
        _name, header, _rows = sheets[sheet_index - 1]
        if OPINION_COLUMN in header:
            column = header.index(OPINION_COLUMN)
            checked_column_styles.setdefault(column, "section")
            checked_cell_styles.setdefault((1, column), "header_green")
            if checked_widths:
                checked_widths[column] = float(OPINION_WIDTH)
        prepared.append({
            "freeze_header": values["freeze_header"],
            "freeze_columns": freeze_columns,
            "auto_filter": values["auto_filter"],
            "row_styles": checked_styles,
            "hidden_rows": checked_hidden,
            "links": checked_links,
            "column_widths": checked_widths,
            "column_styles": checked_column_styles,
            "cell_styles": checked_cell_styles,
            "header_style": header_style,
            "filter_column": filter_column,
            "filter_values": filter_values,
        })
    return prepared


def _extended_styles_needed(options):
    """只有需要新樣式時才擴充 styles.xml，未給選項的舊輸出保持原樣。"""
    for option in options:
        if not option:
            continue
        if option["links"]:
            return True
        if any(style not in ("body", "header") for style in option["row_styles"].values()):
            return True
        if option["column_styles"] or option["cell_styles"] or option["header_style"]:
            return True
    return False


def _cell_style_name(option, row_number, column, row_style):
    """一格用哪一種樣式：單格指定 > 整欄指定（只管資料列） > 整列樣式。"""
    cell = option["cell_styles"].get((row_number, column))
    if cell:
        return cell
    if row_number > 1:
        column_style = option["column_styles"].get(column)
        if column_style:
            return column_style
    return row_style


def _sheet_xml_old(header, rows, note=""):
    """舊版工作表 XML，供未給 sheet_options 時沿用（只多了列印設定）。"""
    widths = column_widths(header, rows)
    out = ['<?xml version="1.0" encoding="UTF-8" standalone="yes"?>',
           '<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">',
           _PRINT_FIT, "<cols>"]
    for i, width in enumerate(widths):
        out.append('<col min="%d" max="%d" width="%s" customWidth="1"/>' % (i + 1, i + 1, width))
    out.append("</cols><sheetData>")
    for row_number, row in enumerate([header] + list(rows), 1):
        style = 2 if row_number == 1 else 1
        cells = "".join(_cell("%s%d" % (_col(column), row_number), value, style, note)
                        for column, value in enumerate(row))
        out.append('<row r="%d">%s</row>' % (row_number, cells))
    out.append("</sheetData>" + _PRINT_PAGE + "</worksheet>")
    return "".join(out)


def _sheet_xml(header, rows, note="", option=None, sheet_names=None):
    """建立單張工作表 XML；option 為 None 時保留舊版輸出。"""
    if option is None:
        return _sheet_xml_old(header, rows, note)

    widths = option["column_widths"] or column_widths(header, rows)
    data_rows = [list(header)] + [list(row) for row in rows]
    links_by_row = {}
    for link in option["links"]:
        links_by_row.setdefault(link["row"], {})[link["column"]] = link

    out = ['<?xml version="1.0" encoding="UTF-8" standalone="yes"?>',
           '<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"'
           ' xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">',
           _PRINT_FIT]
    frozen_columns = option.get("freeze_columns") or 0
    if option["freeze_header"] or frozen_columns:
        # ySplit=1 固定表頭列；xSplit 固定左邊幾欄（往右捲看長文時，序號、判定還在畫面上）。
        # topLeftCell 指向凍結區之後的第一格，Excel 才會把凍結的列、欄留在原位。
        rows_frozen = 1 if option["freeze_header"] else 0
        first = "%s%d" % (_col(frozen_columns), rows_frozen + 1)
        pane = ("bottomRight" if rows_frozen and frozen_columns
                else "bottomLeft" if rows_frozen else "topRight")
        split = ((' xSplit="%d"' % frozen_columns) if frozen_columns else "") +                 ((' ySplit="%d"' % rows_frozen) if rows_frozen else "")
        out.append('<sheetViews><sheetView workbookViewId="0"><pane%s topLeftCell="%s" activePane="%s" state="frozen"/>'
                   '<selection pane="%s" activeCell="%s" sqref="%s"/></sheetView></sheetViews>'
                   % (split, first, pane, pane, first, first))
    out.append("<cols>")
    for index, width in enumerate(widths):
        out.append('<col min="%d" max="%d" width="%s" customWidth="1"/>'
                   % (index + 1, index + 1, width))
    out.append("</cols><sheetData>")

    row_numbers = list(range(1, len(data_rows) + 1))
    row_numbers.extend(sorted(row for row in links_by_row if row > len(data_rows)))
    for row_number in row_numbers:
        row = data_rows[row_number - 1] if row_number <= len(data_rows) else []
        row_style = option["row_styles"].get(
            row_number, (option["header_style"] or "header") if row_number == 1 else "body")
        link_columns = links_by_row.get(row_number, {})
        cells = []
        for column, value in enumerate(row):
            ref = "%s%d" % (_col(column), row_number)
            name = _cell_style_name(option, row_number, column, row_style)
            style = (_LINK_STYLE_IDS[name] if column in link_columns else _ROW_STYLE_IDS[name])
            cells.append(_cell(ref, value, style, note))
        # 參差列或表格外的連結格也要真的建立儲存格，藍色底線才會看得到。
        for column in sorted(column for column in link_columns if column >= len(row)):
            ref = "%s%d" % (_col(column), row_number)
            cells.append(_cell(ref, None, _LINK_STYLE_IDS[row_style], note))
        hidden = ' hidden="1"' if row_number in option["hidden_rows"] else ''
        out.append('<row r="%d"%s>%s</row>' % (row_number, hidden, "".join(cells)))
    out.append("</sheetData>")

    if option["auto_filter"] and widths:
        if option["filter_values"] is not None:
            # 篩選狀態：這一欄目前只顯示 filter_values 這幾個值；其他值的列上面已寫成 hidden。
            # Excel 打開時篩選箭頭亮著、「清除篩選」就全部看得到（比單純隱藏列好找）
            out.append('<autoFilter ref="A1:%s%d"><filterColumn colId="%d"><filters%s>%s</filters></filterColumn></autoFilter>'
                       % (_col(len(widths) - 1), len(data_rows), option["filter_column"],
                          ' blank="1"' if "" in option["filter_values"] else "",
                          "".join('<filter val="%s"/>' % escape(_clean_cell_text(v), {'"': "&quot;"})
                                  for v in option["filter_values"] if v)))
        else:
            out.append('<autoFilter ref="A1:%s%d"/>' % (_col(len(widths) - 1), len(data_rows)))
    if option["links"]:
        out.append("<hyperlinks>")
        url_index = 0
        for link in option["links"]:
            if link.get("url"):
                url_index += 1           # 對外網址：r:id 對到這一張的 _rels（見 sheet_url_rels）
                out.append('<hyperlink ref="%s" r:id="rIdU%d"/>' % (link["ref"], url_index))
                continue
            location = _sheet_location(sheet_names[link["target_index"]], link["target_ref"])
            out.append('<hyperlink ref="%s" location="%s"/>'
                       % (link["ref"], escape(location, {'"': "&quot;"})))
        out.append("</hyperlinks>")
    out.append(_PRINT_PAGE)
    out.append("</worksheet>")
    return "".join(out)


def sheet_url_rels(option):
    """這一張工作表的對外網址關係檔（xl/worksheets/_rels/sheetN.xml.rels）；沒有網址回 None。"""
    urls = [link["url"] for link in (option or {}).get("links") or [] if link.get("url")]
    if not urls:
        return None
    rels = ['<?xml version="1.0" encoding="UTF-8" standalone="yes"?>',
            '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">']
    for index, url in enumerate(urls, 1):
        rels.append('<Relationship Id="rIdU%d" Type="http://schemas.openxmlformats.org/officeDocument/2006/'
                    'relationships/hyperlink" Target="%s" TargetMode="External"/>'
                    % (index, escape(url, {'"': "&quot;"})))
    rels.append("</Relationships>")
    return "".join(rels)


def _styles_xml_old(font_name, font_size):
    return ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            '<styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">'
            '<fonts count="2"><font><sz val="%(s)s"/><name val="%(f)s"/></font>'
            '<font><b/><sz val="%(s)s"/><name val="%(f)s"/></font></fonts>'
            '<fills count="2"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill></fills>'
            '<borders count="1"><border><left/><right/><top/><bottom/><diagonal/></border></borders>'
            '<cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs>'
            '<cellXfs count="3">'
            '<xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/>'
            '<xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0" applyFont="1" applyAlignment="1"><alignment horizontal="left" vertical="center" wrapText="1"/></xf>'
            '<xf numFmtId="0" fontId="1" fillId="0" borderId="0" xfId="0" applyFont="1" applyAlignment="1"><alignment horizontal="left" vertical="center" wrapText="1"/></xf>'
            '</cellXfs><cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles></styleSheet>'
            ) % {"f": escape(str(font_name), {'"': "&quot;"}), "s": font_size}


def _styles_xml(font_name, font_size, extended=False):
    """建立樣式表；前三個樣式保持不變，新增樣式只在有選項時附加。"""
    if not extended:
        return _styles_xml_old(font_name, font_size)
    font = escape(str(font_name), {'"': "&quot;"})
    # style 0／1／2 的 XML 與舊版相同。3～5 是列樣式，6～10 是相同列樣式的藍色底線連結版。
    return ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            '<styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">'
            '<fonts count="4">'
            '<font><sz val="%(s)s"/><name val="%(f)s"/></font>'
            '<font><b/><sz val="%(s)s"/><name val="%(f)s"/></font>'
            '<font><color rgb="FF0000FF"/><u/><sz val="%(s)s"/><name val="%(f)s"/></font>'
            '<font><b/><color rgb="FF0000FF"/><u/><sz val="%(s)s"/><name val="%(f)s"/></font>'
            '</fonts>'
            '<fills count="6">'
            '<fill><patternFill patternType="none"/></fill>'
            '<fill><patternFill patternType="gray125"/></fill>'
            '<fill><patternFill patternType="solid"><fgColor rgb="FFD9EAD3"/><bgColor indexed="64"/></patternFill></fill>'
            '<fill><patternFill patternType="solid"><fgColor rgb="FFFFF2CC"/><bgColor indexed="64"/></patternFill></fill>'
            '<fill><patternFill patternType="solid"><fgColor rgb="FFF4CCCC"/><bgColor indexed="64"/></patternFill></fill>'
            '<fill><patternFill patternType="solid"><fgColor rgb="FFD9D9D9"/><bgColor indexed="64"/></patternFill></fill>'
            '</fills>'
            '<borders count="1"><border><left/><right/><top/><bottom/><diagonal/></border></borders>'
            '<cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs>'
            '<cellXfs count="13">'
            '<xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/>'
            '<xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0" applyFont="1" applyAlignment="1"><alignment horizontal="left" vertical="center" wrapText="1"/></xf>'
            '<xf numFmtId="0" fontId="1" fillId="0" borderId="0" xfId="0" applyFont="1" applyAlignment="1"><alignment horizontal="left" vertical="center" wrapText="1"/></xf>'
            '<xf numFmtId="0" fontId="0" fillId="2" borderId="0" xfId="0" applyFont="1" applyFill="1" applyAlignment="1"><alignment horizontal="left" vertical="center" wrapText="1"/></xf>'
            '<xf numFmtId="0" fontId="0" fillId="3" borderId="0" xfId="0" applyFont="1" applyFill="1" applyAlignment="1"><alignment horizontal="left" vertical="center" wrapText="1"/></xf>'
            '<xf numFmtId="0" fontId="0" fillId="4" borderId="0" xfId="0" applyFont="1" applyFill="1" applyAlignment="1"><alignment horizontal="left" vertical="center" wrapText="1"/></xf>'
            '<xf numFmtId="0" fontId="2" fillId="0" borderId="0" xfId="0" applyFont="1" applyAlignment="1"><alignment horizontal="left" vertical="center" wrapText="1"/></xf>'
            '<xf numFmtId="0" fontId="3" fillId="0" borderId="0" xfId="0" applyFont="1" applyAlignment="1"><alignment horizontal="left" vertical="center" wrapText="1"/></xf>'
            '<xf numFmtId="0" fontId="2" fillId="2" borderId="0" xfId="0" applyFont="1" applyFill="1" applyAlignment="1"><alignment horizontal="left" vertical="center" wrapText="1"/></xf>'
            '<xf numFmtId="0" fontId="2" fillId="3" borderId="0" xfId="0" applyFont="1" applyFill="1" applyAlignment="1"><alignment horizontal="left" vertical="center" wrapText="1"/></xf>'
            '<xf numFmtId="0" fontId="2" fillId="4" borderId="0" xfId="0" applyFont="1" applyFill="1" applyAlignment="1"><alignment horizontal="left" vertical="center" wrapText="1"/></xf>'
            '<xf numFmtId="0" fontId="1" fillId="5" borderId="0" xfId="0" applyFont="1" applyFill="1" applyAlignment="1"><alignment horizontal="left" vertical="center" wrapText="1"/></xf>'
            '<xf numFmtId="0" fontId="1" fillId="2" borderId="0" xfId="0" applyFont="1" applyFill="1" applyAlignment="1"><alignment horizontal="left" vertical="center" wrapText="1"/></xf>'
            '</cellXfs><cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles></styleSheet>'
            ) % {"f": font, "s": font_size}


def write_xlsx(path, sheets, font_name="微軟正黑體", font_size=11, csv_names=None,
               csv_dir=None, path_for=None, source="", sheet_options=None):
    """寫入多張工作表。

    sheets 維持 [(工作表名, header, rows), ...] 舊格式。sheet_options 與 sheets 同順序，
    每個元素可設定凍結表頭、篩選、列樣式與內部超連結；未給時沿用舊版 XML。
    csv_names、csv_dir、path_for 與 source 的行為不變，另存完整 csv 的路徑仍記在 _SPILLED。
    """
    sheets = [(str(name), list(header), list(rows)) for name, header, rows in sheets]
    # 先驗選項再開檔；設定錯誤時不會留下半份 zip，也不會讓 CSV 退路把錯誤吞掉。
    options = _prepare_sheet_options(sheet_options, sheets)
    safe_sheet_names = _safe_sheet_names(sheets)
    # 未給選項時保留舊版對工作表名的處理，避免既有輸出無端改名。
    if sheet_options is None:
        safe_sheet_names = []
        used = set()
        for index, (name, _header, _rows) in enumerate(sheets, 1):
            safe_name = re.sub(r'[\\/?*\[\]:]', "_", str(name))[:31] or "Sheet%d" % index
            base, serial = safe_name, 2
            while safe_name in used:
                suffix = "_%d" % serial
                safe_name = base[:31 - len(suffix)] + suffix
                serial += 1
            used.add(safe_name)
            safe_sheet_names.append(safe_name)
    _XML_CLEANED[0] = 0
    del _SPILLED[:]
    stem = os.path.splitext(os.path.basename(path))[0]
    names = {name: "%s_%s.csv" % (stem, name) for name, _header, _rows in sheets}
    names.update({str(key): value for key, value in (csv_names or {}).items() if value})
    truncated = []
    ct = ['<?xml version="1.0" encoding="UTF-8" standalone="yes"?>',
          '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">',
          '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>',
          '<Default Extension="xml" ContentType="application/xml"/>',
          '<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>',
          '<Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>']
    wb = ['<?xml version="1.0" encoding="UTF-8" standalone="yes"?>',
          '<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">']
    if any(option and (option["freeze_header"] or option["freeze_columns"]) for option in options):
        # 有凍結窗格時活頁簿也要宣告 bookViews，Excel 才能穩定辨識工作表檢視。
        wb.append('<bookViews><workbookView/></bookViews>')
    wb.append('<sheets>')
    rels = ['<?xml version="1.0" encoding="UTF-8" standalone="yes"?>',
            '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">']
    parts = {}
    for index, ((name, header, rows), safe_name, option) in enumerate(
            zip(sheets, safe_sheet_names, options), 1):
        ct.append('<Override PartName="/xl/worksheets/sheet%d.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>' % index)
        wb.append('<sheet name="%s" sheetId="%d" r:id="rId%d"/>'
                  % (escape(safe_name, {'"': "&quot;"}), index, index))
        rels.append('<Relationship Id="rId%d" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet%d.xml"/>' % (index, index))
        # 截斷提示用原始工作表名：人是照程式原本傳入的名稱找對應 csv，不是 Excel 清理後的名稱。
        _TRUNCATED[0] = 0
        shown_header = header if option is None else [_opinion_title() if cell == OPINION_COLUMN else cell
                                                     for cell in header]
        parts["xl/worksheets/sheet%d.xml" % index] = _sheet_xml(
            shown_header, rows, truncate_note(name, names), option, safe_sheet_names)
        url_rels = sheet_url_rels(option)
        if url_rels:
            parts["xl/worksheets/_rels/sheet%d.xml.rels" % index] = url_rels
        if _TRUNCATED[0]:
            truncated.append((name, header, rows, _TRUNCATED[0]))
    total_sheets = len(sheets)
    rels.append('<Relationship Id="rId%d" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/></Relationships>' % (total_sheets + 1))
    ct.append('</Types>')
    wb.append('</sheets>')
    # 有篩選狀態的工作表要在活頁簿登記 _FilterDatabase（Excel 自己存檔都會寫；沒有它有些版本不認篩選狀態）
    defined = []
    for index, ((name, header, rows), safe_name, option) in enumerate(zip(sheets, safe_sheet_names, options)):
        if option and option["filter_values"] is not None:
            columns = max(len(header), max((len(row) for row in rows), default=0)) or 1
            defined.append('<definedName name="_xlnm._FilterDatabase" localSheetId="%d" hidden="1">%s</definedName>'
                           % (index, escape(_sheet_location(safe_name, "$A$1:$%s$%d" % (_col(columns - 1), len(rows) + 1)),
                                            {'"': "&quot;"})))
    # 列印時第一列（表頭）每頁重複
    for index, ((_name, header, _rows), safe_name) in enumerate(zip(sheets, safe_sheet_names)):
        if header:
            defined.append('<definedName name="_xlnm.Print_Titles" localSheetId="%d">%s</definedName>'
                           % (index, escape(_sheet_location(safe_name, "$1:$1"), {'"': "&quot;"})))
    if defined:
        wb.append('<definedNames>%s</definedNames>' % "".join(defined))
    wb.append('</workbook>')
    parts['[Content_Types].xml'] = ''.join(ct)
    parts['_rels/.rels'] = ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
                            '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
                            '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>')
    parts['xl/workbook.xml'] = ''.join(wb)
    parts['xl/_rels/workbook.xml.rels'] = ''.join(rels)
    parts['xl/styles.xml'] = _styles_xml(
        font_name, font_size, extended=_extended_styles_needed(options))
    buffer = io.BytesIO()
    with zipfile.ZipFile(buffer, 'w', zipfile.ZIP_DEFLATED) as archive:
        for part_name in ('[Content_Types].xml', '_rels/.rels', 'xl/workbook.xml',
                          'xl/_rels/workbook.xml.rels', 'xl/styles.xml'):
            archive.writestr(stable_zip_info(part_name), parts[part_name].encode('utf-8'))
        for part_name in sorted(key for key in parts if key.startswith('xl/worksheets/')):
            archive.writestr(stable_zip_info(part_name), parts[part_name].encode('utf-8'))
    data = buffer.getvalue()
    try:
        with open(path, 'rb') as existing:
            unchanged = existing.read() == data
    except FileNotFoundError:
        unchanged = False
    if not unchanged:
        # v1.55.x：先寫暫存再換名。以前直接覆寫：寫到一半斷電、磁碟滿，舊報告（含承辦意見）就沒了
        temp = path + '.tmp'
        try:
            with open(temp, 'wb') as output:
                output.write(data)
            replace_file(temp, path)
        except BaseException:
            try:
                os.remove(temp)
            except OSError:
                pass
            raise
    if _XML_CLEANED[0]:
        nt.notice(nt.REMINDER, XML_CLEANUP_NOTICE % _XML_CLEANED[0], '審查包 xlsx')
    _XML_CLEANED[0] = 0
    folder = csv_dir or os.path.dirname(os.path.abspath(path))
    for name, header, rows, count in truncated:
        final = os.path.join(folder, names[name])
        _write_csv((path_for or (lambda value: value))(final), header, rows)
        _SPILLED.append(final)
        nt.notice(nt.REMINDER,
                  '工作表「%s」有 %d 格超過 Excel 一格 %d 字的上限，xlsx 裡已截斷；'
                  '完整內容另存在同資料夾的 %s' % (name, count, _CELL_LIMIT, names[name]),
                  source or '產出表格')
    return path


def csv_names_for(base_path, sheets):
    """每張工作表退成 csv 時要叫什麼檔名（只有檔名，不含資料夾）。

    一張表就 <同名>.csv，多張表就 <同名>_<工作表名>.csv——多張表擠成同一個
    檔名會互相蓋掉，而「候選明細」那三張表正是要分開看的三件事。
    """
    base = os.path.basename(base_path)
    names = [str(name) for name, _h, _r in sheets]
    if len(names) == 1:
        return {names[0]: base + ".csv"}
    return {name: "%s_%s.csv" % (base, name) for name in names}


def _locked(path, exc):
    """xlsx 寫不進去是因為被 Excel 開著（PermissionError，或旁邊有 Excel 的 ~$ 鎖定檔）。"""
    lock = os.path.join(os.path.dirname(path), '~$' + os.path.basename(path))
    return isinstance(exc, PermissionError) or os.path.exists(lock)


def _same_path(path):
    return os.path.normcase(os.path.abspath(path))


def hold_reports(base_path, unreadable=(), on_written=None):
    """報告寫出前先講好（precedents.keep_opinions）：unreadable 這次讀不到，不能覆寫、不能刪；
    on_written(實際寫出的路徑) 在 xlsx 真的寫成功之後才呼叫。只對下一次 write_tables_or_csv(base_path) 有效。"""
    _HOLD[_same_path(base_path)] = (set(_same_path(p) for p in unreadable), on_written)


def out_of_space(exc):
    """磁碟滿（Python 把 Windows 的 112／39 也對應成 errno 28，winerror 再看一次比較保險）。"""
    return getattr(exc, 'errno', None) == 28 or getattr(exc, 'winerror', None) in (39, 112)


def _copy_path(base_path):
    """另存副本的檔名（報告_HHMMSS.xlsx）。同一秒已經有一份就往後一秒：不蓋掉別的副本。"""
    import datetime
    from _common import tw_now
    now = tw_now()
    for offset in range(120):
        name = '%s_%s.xlsx' % (base_path, (now + datetime.timedelta(seconds=offset)).strftime('%H%M%S'))
        if not os.path.exists(name):
            break
    return name


def _remove_old_copies(base_path, keep=()):
    """正式那一份寫成功了：Excel 開著時另存的「報告_HHMMSS.xlsx」舊副本清掉（還開著的刪不掉就留著）。
    keep：不能刪的（這次讀不到的舊報告：裡面的承辦意見還沒收回來；v1.55.x）。"""
    folder = os.path.dirname(base_path) or '.'
    stem = os.path.basename(base_path)
    # .tmp：上一次寫到一半被中斷留下的暫存（新報告寫成功了，它沒用了）
    pattern = re.compile(r'^%s(?:_\d{6}\.xlsx|(?:_\d{6})?\.xlsx\.tmp)$' % re.escape(stem))
    try:
        names = os.listdir(folder)
    except OSError:
        return
    for name in names:
        if pattern.match(name) and _same_path(os.path.join(folder, name)) not in keep:
            try:
                os.remove(os.path.join(folder, name))
            except OSError:
                pass


def write_tables_or_csv(base_path, sheets, source="", path_for=None, csv_names=None,
                        sheet_options=None):
    """給人看的表只出一種格式：先試 .xlsx，寫不出來才退 .csv。

    base_path 不帶副檔名。sheet_options 與 sheets 同順序，傳給 write_xlsx；設定格式錯誤
    會直接拋出 XlsxOptionError，不可改用 csv 掩蓋。其餘 OSError／ValueError 仍保留 csv 退路。

    v1.55.x：舊報告只有在新檔寫成功之後才會被取代。xlsx 和 csv 都寫不出來時拋 OSError，舊報告原封不動；
    hold_reports 講好不能動的檔，這次一律另存副本。
    """
    from _common import tw_now, tw_today
    path_for = path_for or (lambda path: path)
    sheets = [(str(name), list(header), list(rows)) for name, header, rows in sheets]
    folder = os.path.dirname(base_path)
    names = csv_names_for(base_path, sheets)
    names.update({str(key): value for key, value in (csv_names or {}).items() if key in names})
    xlsx_final = base_path + '.xlsx'
    target = path_for(xlsx_final)
    unreadable, on_written = _HOLD.pop(_same_path(base_path), (set(), None))
    LAST_FAILURE[0] = None
    exc = None
    if _same_path(xlsx_final) not in unreadable:
        try:
            write_xlsx(target, sheets, csv_names=names, csv_dir=folder,
                       path_for=path_for, source=source, sheet_options=sheet_options)
        except XlsxOptionError:
            # 設定錯誤是呼叫端的資料問題，不能寫成一份看似成功、實際少掉格式與連結的 csv。
            raise
        except (OSError, ValueError) as error:
            exc = error
        else:
            _remove_old_copies(base_path, unreadable)
            if on_written:
                on_written(xlsx_final)
            # 有格子被截斷的工作表另存了完整的 csv：也是這一次真的寫出來的檔，一起回報。
            return [xlsx_final] + list(_SPILLED)
    busy = isinstance(exc, OSError) and _locked(xlsx_final, exc)
    if exc is None or busy:
        # v1.11.0：報告正在 Excel 裡開著（Windows 鎖檔）。以前改出一堆 csv、叫人關 Excel 再重跑；
        # 現在改存成加時間的檔名，這一次的結果照樣是 xlsx，講清楚開哪一份
        # v1.55.x：正式那一份這次讀不到（exc 是 None）也走這裡：裡面的承辦意見還沒收回來，不能蓋掉
        other = _copy_path(base_path)
        try:
            write_xlsx(path_for(other), sheets, csv_names=names, csv_dir=folder,
                       path_for=path_for, source=source, sheet_options=sheet_options)
        except XlsxOptionError:
            raise
        except (OSError, ValueError) as error:
            exc = exc or error
        else:
            if busy:
                message = ('%s 正在 Excel 裡開著，這次的結果存成 %s：關掉舊的那一份，打開這一份'
                           % (os.path.basename(xlsx_final), os.path.basename(other)))
            else:
                again = '法規報告' if '法規' in (source or '') else '繼續'
                message = ('%s 讀不到（被占用，或檔案壞了），沒有動它；這次的結果存成 %s。'
                           '關掉占用它的程式或修好檔案後跑一次 %s，裡面的承辦意見會接回來；'
                           '檔案真的救不回來就刪掉它，再跑一次 %s'
                           % (os.path.basename(xlsx_final), os.path.basename(other), again, again))
                _remove_old_copies(base_path, unreadable | {_same_path(other)})
            nt.notice(nt.REMINDER, message, source or '產出表格')   # notice 自己會印（v1.24.0：以前另外 print，同一句印兩次）
            if on_written:
                on_written(other)
            return [other] + list(_SPILLED)
    LAST_FAILURE[0] = exc
    # 半份 zip 一定要清掉：走 AtomicWrites 時那個 .tmp 會在收尾被當成這一次的產物搬走。
    # 正式 xlsx 留著（v1.55.x）：以前也刪掉，怕人把舊報告當成這一次的結果，但裡面有承辦意見，新的又不一定寫得出來。
    # 改成講清楚舊的還在、那是上一次的結果。
    if _same_path(target) != _same_path(xlsx_final):
        try:
            if os.path.exists(target):
                os.remove(target)
        except OSError:
            pass
    still = ('；%s 還在沒動，那是上一次的結果' % os.path.basename(xlsx_final)
             if os.path.isfile(xlsx_final) else '')
    nt.notice(nt.REMINDER, 'xlsx 寫不出來（%s），已改出 csv%s' % (exc, still), source or '產出表格')
    written = []
    for name, header, rows in sheets:
        final = os.path.join(folder, names[name])
        try:
            _write_csv(path_for(final), header, rows)
        except OSError as error:
            for path in [final] + written:       # 半份 csv 比沒有更糟：人會以為是完整的
                try:
                    os.remove(path_for(path))
                except OSError:
                    pass
            LAST_FAILURE[0] = error
            todo = '騰出磁碟空間後再跑一次' if out_of_space(error) else '處理好再跑一次'
            nt.notice(nt.WARNING, '%s 這次沒有寫出來（%s）。%s%s' % (
                os.path.basename(xlsx_final), error,
                '舊報告還在沒動，裡面是上一次的結果；' if os.path.isfile(xlsx_final) else '',
                todo), source or '產出表格')
            raise
        written.append(final)
    return written

