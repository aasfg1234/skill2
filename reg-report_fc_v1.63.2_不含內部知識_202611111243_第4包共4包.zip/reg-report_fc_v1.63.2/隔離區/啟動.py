import glob, os, runpy, shutil, sys, tempfile, zipfile
sys.dont_write_bytecode = True
z = glob.glob("**/reg-report程式.zip", recursive=True)[0]
t = os.path.abspath("_reg暫存")
os.makedirs(t, exist_ok=True)
tempfile.tempdir = os.environ["TEMP"] = os.environ["TMP"] = t
d = tempfile.mkdtemp(prefix="reg-prog-")
zipfile.ZipFile(z).extractall(d)
sys.argv = ["isolated_runner.py", *sys.argv[1:]]
try:
    runpy.run_path(os.path.join(d, "scripts", "isolated_runner.py"), run_name="__main__")
finally:
    shutil.rmtree(t, ignore_errors=True)
