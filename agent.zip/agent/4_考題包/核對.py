"""核對考題產出；以目前目錄為工作區，使用 --題 選擇題號。"""
import argparse
import contextlib
import csv
import io
import re
import zipfile
from collections import Counter, defaultdict
from pathlib import Path

import docx
import openpyxl

E = Path('ws/環境測試')
O = E / '輸出'

def rows(path, encoding='utf-8-sig'):
    with path.open(encoding=encoding, newline='') as f:
        return list(csv.DictReader(f))

def totals(paths, folder=None, count=None):
    result = defaultdict(int)
    if len(paths) == count:
        datasets = [rows(path) for path in paths]
    else:
        with zipfile.ZipFile(E / (folder + '.zip')) as z:
            names = [n for n in z.namelist() if n.endswith('.csv')]
            assert len(names) == count, '原始部門檔數不符'
            datasets = [list(csv.DictReader(io.StringIO(z.read(n).decode('utf-8-sig'), newline=''))) for n in names]
    for data in datasets:
        for row in data:
            result[row['部門']] += int(row['金額'])
    return dict(result)

def summary(path, expected, average=None):
    data = rows(path)
    # 題目沒指定欄名：金額總和、總金額、總和、合計…都算
    names = ('金額總和', '總金額', '金額合計', '總和', '合計', '總計', '金額')
    column = next((n for n in names if data and n in data[0]), None)
    assert column, '找不到金額總和的欄位（欄名：' + '、'.join(data[0]) + '）' if data else '沒有資料'
    actual = {r['部門']: round(float(str(r[column]).replace(',', ''))) for r in data}
    assert len(data) == len(expected) and actual == expected, '部門或金額不符'
    if average is not None:
        assert all(abs(float(str(r['平均金額']).replace(',', '')) - average[r['部門']]) <= 0.5 for r in data), '平均金額不符'

def sheet(path):
    wb = openpyxl.load_workbook(path, data_only=True)
    try:
        return list(wb.worksheets[0].values)
    finally:
        wb.close()

def check_s3():
    wb = openpyxl.load_workbook(E / 'excel/預算.xlsx', data_only=True)
    try:
        source = list(wb.worksheets[1].values)
    finally:
        wb.close()
    expected = [source[0]] + [r for r in source[1:] if r[1] > 100]
    assert sheet(O / '預算_大於100.xlsx') == expected, '預算內容不符'
    assert all(not any(c.isspace() for c in r['電話']) for r in rows(E / '名單.csv')), '電話仍有空白'
    return '預算及電話正確'

def check_s4():
    cmds = list(E.glob('*.cmd'))
    if not cmds: raise FileNotFoundError('沒有產出 .cmd')
    for p in cmds:
        content = p.read_bytes()
        if b'\r\n' not in content or b'\n' in content.replace(b'\r\n', b'') or b'\r' in content.replace(b'\r\n', b''):
            continue
        for encoding in ('utf-8-sig', 'cp950'):
            try: text = content.decode(encoding)
            except UnicodeDecodeError: continue
            for line in text.splitlines():
                line = line.strip().lstrip('@').strip()
                if re.match(r'(?i)^(?:rem\b|::|echo\b)', line): continue
                if re.search(r'(?i)\bnotepad(?:\.exe)?\b[^\r\n]*名單\.csv', line):
                    return f'{p.name} 為 CRLF，且包含記事本開啟名單的命令（實際雙擊效果請人工確認）'
    raise AssertionError('沒有同時使用 CRLF 並以記事本開啟名單.csv 的 .cmd')

def check_s5():
    tx, result = rows(E / '大檔/交易明細.csv'), rows(O / '檢查結果.csv')
    assert len(tx) == len(result), '筆數不符'
    for t, r in zip(tx, result):
        vals = list(r.values())
        assert len(vals) >= 2 and vals[0] == t['交易編號'] and vals[1] == ('要複核' if int(t['金額']) >= 450000 or t['客戶名稱'].endswith('9號有限公司') else '正常'), '交易編號或檢查結果不符'
    return '全部交易檢查結果正確'

def check_t2():
    tx = rows(E / '大檔/交易明細.csv')
    expected = defaultdict(list)
    for row in tx: expected[row['客戶名稱']].append(row)
    folder = E / '客戶'
    def verify(files):
        found = {}
        assert len(files) == len(expected), '客戶檔案數不符'
        for name, content in files:
            data = list(csv.DictReader(io.StringIO(content.decode('utf-8-sig'), newline='')))
            assert data, f'{name} 是空檔'
            customers = {r['客戶名稱'] for r in data}
            assert len(customers) == 1, f'{name} 混有不同客戶'
            customer = next(iter(customers))
            assert customer not in found, f'{customer} 有多個檔案'
            found[customer] = data
        assert set(found) == set(expected), '客戶不符'
        for customer, data in found.items():
            assert Counter(tuple(sorted(r.items())) for r in data) == Counter(tuple(sorted(r.items())) for r in expected[customer]), f'{customer} 的交易內容不符'
        return f'{len(files)} 個客戶檔的內容正確'
    errors = []
    paths = list(folder.glob('*.csv')) if folder.is_dir() else []
    files = [(p.name, p.read_bytes()) for p in paths]
    for archive in E.rglob('*.zip'):
        try:
            with zipfile.ZipFile(archive) as z:
                entries = [n for n in z.namelist() if n.lower().endswith('.csv') and not n.endswith('/')]
                candidates = []
                for name in entries:
                    content = z.read(name)
                    try:
                        header = next(csv.reader(io.StringIO(content.decode('utf-8-sig'), newline='')), [])
                    except UnicodeDecodeError:
                        continue
                    if set(tx[0]).issubset(header): candidates.append((name, content))
                files.extend((f'{archive}!{name}', content) for name, content in candidates)
        except Exception as exc: errors.append(f'{archive.name}：{exc}')
    if not files and not errors: raise FileNotFoundError('沒有產出客戶 CSV 或 ZIP')
    if errors: raise AssertionError('；'.join(errors))
    return verify(files)

def check_t3():
    tx = rows(E / '大檔/交易明細.csv')
    sums, counts = defaultdict(int), Counter()
    for r in tx:
        sums[r['部門']] += int(r['金額']); counts[r['部門']] += 1
    summary(O / '部門彙總.csv', sums, {k: v / counts[k] for k, v in sums.items()})
    return '部門總額及平均正確；各部門前 3 筆須人工對照'

def check_t4():
    source = [[c.text for c in r.cells] for r in docx.Document(E / '會議紀錄.docx').tables[0].rows]
    assert [list(r) for r in sheet(O / '待辦事項.xlsx')] == source, '表格內容不符'
    return '表格內容正確'

def check_month(month, count):
    folder = '多檔' if month == '10' else '多檔_11月'
    paths = sorted((E / folder).glob('*.csv'))
    summary(O / f'部門彙總_{month}月.csv', totals(paths, folder, count))
    return '部門加總正確'

def check_n1():
    table = docx.Document(E / '會議紀錄.docx').tables[0]
    source = [[c.text for c in r.cells] for r in table.rows]
    wanted = [r[1] for r in source[1:] if tuple(map(int, r[3].split('/'))) < (115, 12, 1)]
    data = sheet(O / '快到期.xlsx')
    text = [str(v) for r in data for v in r if v is not None]
    assert all(x in text for x in wanted) and all(r[1] not in text for r in source[1:] if r[1] not in wanted), '待辦篩選不符'
    return f'期限篩選正確（{len(wanted)} 項）'

def check_n2():
    # 一張表一個類別的寫法（例如「新增條文」「刪除條文」「修改條文」三張表）：把工作表名稱補成類別欄
    wb = openpyxl.load_workbook(O / '條文異動.xlsx', data_only=True)
    try:
        data = list(wb.worksheets[0].values)
        for ws in wb.worksheets:
            kind = next((k for k in ('新增', '刪除', '修改') if k in ws.title), None)
            rows = list(ws.values)
            if kind and rows:
                data += [tuple(r) + (kind,) for r in rows[1:]]
    finally:
        wb.close()
    article = re.compile(r'^\s*(第[一二三四五六七八九十百\d]+條(?:之[一二三四五六七八九十\d]+)?)')
    def provisions(path):
        result = {}
        for paragraph in docx.Document(path).paragraphs:
            text = paragraph.text.strip()
            match = article.match(text)
            if match: result[match.group(1)] = text
        return result
    old = provisions(E / '規章_舊.docx')
    new = provisions(E / '規章_新.docx')
    assert old and new, '無法讀取原始條文'
    expected = {}
    for key in old.keys() | new.keys():
        if key not in old: expected[key] = '新增'
        elif key not in new: expected[key] = '刪除'
        elif old[key] != new[key]: expected[key] = '修改'
    found = set()
    category_index = next((i for i, value in enumerate(data[0]) if value is not None and any(s in str(value) for s in ('類別', '類型', '異動情形', '異動狀態'))), None) if data else None
    for row in data:
        if row and row[-1] in ('新增', '刪除', '修改') and len(row) > len(data[0]):
            category = row[-1]
        elif category_index is not None:
            category = str(row[category_index] or '') if category_index < len(row) else ''
        else:
            category = next((str(v).strip() for v in row if v is not None and str(v).strip() in ('新增', '刪除', '修改')), '')
        category = category.strip()
        if category not in ('新增', '刪除', '修改'):
            continue
        text = ' '.join(str(v) for v in row if v is not None)
        # 最長條號優先，避免「第三條之一」誤認為「第三條」。
        ids = set(re.findall(r'第[一二三四五六七八九十百\d]+條(?:之[一二三四五六七八九十\d]+)?', text))
        for key in ids:
            assert key in expected, f'{key} 沒有異動或不在原始條文中'
            kind = expected[key]
            assert kind == category, f'{key} 的異動類別應為{kind}'
            # 條號可能另放一欄，所以只比對條號後面的內容。
            if key in old: assert article.sub('', old[key]).strip() in text, f'{key} 缺少正確舊條文全文'
            if key in new: assert article.sub('', new[key]).strip() in text, f'{key} 缺少正確新條文全文'
            found.add(key)
    assert found == set(expected), '缺少異動條文：' + '、'.join(sorted(set(expected) - found))
    return '異動條號、類別及新舊全文正確'

CHECKS = {'S1': None, 'S3': check_s3, 'S4': check_s4, 'S5': check_s5, 'T2': check_t2, 'T3': check_t3, 'T4': check_t4, 'R1': lambda: check_month('10', 15), 'R2': lambda: check_month('11', 12), 'N1': check_n1, 'N2': check_n2}

def answers():
    try:
        tx = rows(E / '大檔/交易明細.csv')
        print('S2 正確答案：筆數', len(tx), '總金額', sum(int(r['金額']) for r in tx), '前 5 大', sorted(tx, key=lambda r: int(r['金額']), reverse=True)[:5])
    except Exception as exc: print('S2 正確答案無法計算：', exc)
    try:
        data = rows(E / '舊系統匯出.csv', 'cp950')
        print('T1 正確答案：人數', len(data), '各部門', dict(Counter(r['部門'] for r in data)))
    except Exception as exc: print('T1 正確答案無法計算：', exc)
    print('N3 正確答案：施行日期 2026-12-01；截止日期 2026-11-20')

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--題', help='逗號分隔題號，例如 S1,S3')
    parser.add_argument('--產生cmd', metavar='路徑', help='產生雙擊用的 cmd 檔')
    args = parser.parse_args()
    if args.產生cmd:
        cmd = ('@echo off\nchcp 65001 >nul\ncd /d "%~dp0..\\.."\n'
               'where python >nul 2>&1\nif errorlevel 1 (\n'
               '    echo 找不到 Python，請先安裝 Python 並將它加入 PATH。\n'
               ') else (\n    set PYTHONIOENCODING=utf-8\n'
               '    python -B "%~dp0核對.py"\n)\npause\n')
        Path(args.產生cmd).write_bytes(cmd.replace('\n', '\r\n').encode('utf-8'))
        return
    selected = [s.strip().upper() for s in args.題.split(',')] if args.題 else list(CHECKS)
    unknown = set(selected) - set(CHECKS)
    if unknown: parser.error('未知題號：' + ','.join(sorted(unknown)))
    output = io.StringIO()
    with contextlib.redirect_stdout(output):
        passed = 0
        for name in selected:
            if name == 'S1':
                print('S1 看 R1（同樣的算法）')
                continue
            try:
                reason = CHECKS[name]()
                print(f'✓ {name}：{reason}'); passed += 1
            except FileNotFoundError as exc:
                print(f'✗ {name}：沒有產出或缺少所需檔案（{exc}）')
            except Exception as exc:
                print(f'✗ {name}：{type(exc).__name__}：{exc}')
        print(f'通過 {passed}／{sum(name != "S1" for name in selected)}')
        if not args.題: answers()
    report = output.getvalue()
    result = Path('_工作/考題包/核對結果.txt')
    result.parent.mkdir(parents=True, exist_ok=True)
    result.write_text(report, encoding='utf-8', newline='')
    print(report, end='')

if __name__ == '__main__': main()
