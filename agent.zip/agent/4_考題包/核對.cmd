@echo off
chcp 65001 >nul
cd /d "%~dp0..\.."
where python >nul 2>&1
if errorlevel 1 (
    echo 找不到 Python，請先安裝 Python 並將它加入 PATH。
) else (
    set PYTHONIOENCODING=utf-8
    python -B "%~dp0核對.py"
)
pause
