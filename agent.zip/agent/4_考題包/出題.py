def data_0():
    """在工作區做環境限制測試用的假資料（全是隨機假資料）。"""
    import csv
    import random
    from pathlib import Path
    
    import openpyxl
    
    random.seed(7)
    base = Path("ws/環境測試")
    depts = ["業務部", "財務部", "資訊部", "人資部", "法務部", "行銷部", "客服部", "稽核部"]
    
    multi = base / "多檔"
    multi.mkdir(parents=True, exist_ok=True)
    for i in range(1, 16):
        with open(multi / ("部門_%02d.csv" % i), "w", encoding="utf-8", newline="") as f:
            w = csv.writer(f)
            w.writerow(["日期", "部門", "金額"])
            for _ in range(20):
                w.writerow(["2026-10-%02d" % random.randint(1, 28), random.choice(depts), random.randint(100, 99999)])
    
    big = base / "大檔"
    big.mkdir(parents=True, exist_ok=True)
    with open(big / "交易明細.csv", "w", encoding="utf-8", newline="") as f:
        w = csv.writer(f)
        w.writerow(["交易編號", "日期", "客戶名稱", "部門", "金額", "備註"])
        for i in range(1, 9001):
            w.writerow(["T%06d" % i, "2026-%02d-%02d" % (random.randint(1, 10), random.randint(1, 28)),
                        "客戶%04d號有限公司" % random.randint(1, 3000), random.choice(depts),
                        random.randint(10, 500000), "一般交易，無特別說明"])
    
    xl = base / "excel"
    xl.mkdir(parents=True, exist_ok=True)
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "說明"
    ws["A1"] = "第二個工作表是預算"
    ws2 = wb.create_sheet("預算")
    ws2.append(["項目", "金額", "負責人"])
    for i in range(1, 41):
        ws2.append(["項目%02d" % i, random.randint(10, 300), random.choice(["王大明", "林小華", "陳志強"])])
    wb.save(xl / "預算.xlsx")
    
    names = ["王大明", "王大名", "林小華", "林曉華", "陳志強", "陳誌強", "張美玲", "李建國", "李建囯", "黃淑芬"]
    with open(base / "名單.csv", "w", encoding="utf-8", newline="") as f:
        w = csv.writer(f)
        w.writerow(["姓名", "電話", "部門"])
        for n in names:
            w.writerow([n, "09%02d %03d %03d" % (random.randint(10, 99), random.randint(0, 999), random.randint(0, 999)),
                        random.choice(depts)])
    
    for p in sorted(base.rglob("*")):
        if p.is_file():
            print(p.relative_to(base), p.stat().st_size)
    print("大檔字數", len((big / "交易明細.csv").read_text(encoding="utf-8")))

def data_1():
    """第二批考題的假資料：Big5 編碼的舊系統匯出檔、有表格的 Word 檔。"""
    import csv
    import io
    import random
    from pathlib import Path
    
    import docx
    
    random.seed(11)
    base = Path("ws/環境測試")
    depts = ["業務部", "財務部", "資訊部", "人資部", "法務部"]
    
    buf = io.StringIO()
    w = csv.writer(buf, lineterminator="\r\n")
    w.writerow(["員工編號", "姓名", "部門", "到職日"])
    for i in range(1, 121):
        w.writerow(["E%04d" % i, random.choice("陳林黃張李王吳劉蔡楊") + random.choice(["志明", "淑芬", "建宏", "美玲", "冠廷"]),
                    random.choice(depts), "20%02d/%02d/%02d" % (random.randint(10, 25), random.randint(1, 12), random.randint(1, 28))])
    (base / "舊系統匯出.csv").write_bytes(buf.getvalue().encode("cp950"))
    
    d = docx.Document()
    d.add_heading("115 年 10 月部門會議紀錄", 1)
    d.add_paragraph("出席：各部門主管。以下為待辦事項追蹤表。")
    t = d.add_table(rows=1, cols=4)
    for c, h in zip(t.rows[0].cells, ["項次", "待辦事項", "負責部門", "期限"]):
        c.text = h
    for i in range(1, 13):
        r = t.add_row().cells
        r[0].text, r[1].text = str(i), "完成第 %d 項流程調整" % i
        r[2].text, r[3].text = random.choice(depts), "115/%02d/%02d" % (random.randint(11, 12), random.randint(1, 28))
    d.add_paragraph("散會。")
    d.save(base / "會議紀錄.docx")
    print("ok", (base / "舊系統匯出.csv").stat().st_size, (base / "會議紀錄.docx").stat().st_size)

def data_2():
    """第三批考題：11 月的部門檔（測腳本重用）、一個壞掉的 xlsx（測錯誤紀錄）。"""
    import csv
    import random
    from pathlib import Path
    
    random.seed(23)
    base = Path("ws/環境測試")
    depts = ["業務部", "財務部", "資訊部", "人資部", "法務部", "行銷部", "客服部", "稽核部"]
    nov = base / "多檔_11月"
    nov.mkdir(parents=True, exist_ok=True)
    for i in range(1, 13):
        with open(nov / ("部門_%02d.csv" % i), "w", encoding="utf-8", newline="") as f:
            w = csv.writer(f)
            w.writerow(["日期", "部門", "金額"])
            for _ in range(25):
                w.writerow(["2026-11-%02d" % random.randint(1, 28), random.choice(depts), random.randint(100, 99999)])
    (base / "壞掉的報表.xlsx").write_bytes(b"PK\x03\x04" + bytes(random.randrange(256) for _ in range(3000)))
    print(len(list(nov.glob("*.csv"))), (base / "壞掉的報表.xlsx").stat().st_size)

def data_3():
    """第四批考題：新版常用工具（新舊版規章比對、PDF 公告、民國日期）。全是假資料。"""
    from pathlib import Path
    import docx
    import pymupdf
    
    base = Path("ws/環境測試")
    舊 = ["範例管理辦法", "第一條 為規範本公司範例作業，特訂定本辦法。", "第二條 本辦法適用於本公司全體員工。",
          "第三條 申請人應於每月五日前提出申請。", "第四條 主管應於三日內核定。", "第五條 本辦法經董事會通過後施行。"]
    新 = ["範例管理辦法", "第一條 為規範本公司範例作業，特訂定本辦法。", "第二條 本辦法適用於本公司全體員工及派遣人員。",
          "第三條 申請人應於每月十日前提出申請。", "第三條之一 緊急案件得先行辦理，事後補件。",
          "第五條 本辦法經董事會通過後施行，修正時亦同。"]
    for 名, 行們 in (("規章_舊.docx", 舊), ("規章_新.docx", 新)):
        d = docx.Document()
        for 行 in 行們:
            d.add_paragraph(行)
        d.save(base / 名)
    with pymupdf.open() as 文件:
        for 頁文 in (["公告", "主旨：修正範例管理辦法，自民國115年12月1日起施行。", "說明：申請期限改為每月十日前。"],
                     ["附件", "聯絡窗口：行政部，分機1234。", "截止日期：115/11/20"]):
            頁 = 文件.new_page()
            for i, 行 in enumerate(頁文):
                頁.insert_text((72, 72 + i * 24), 行, fontname="china-t", fontsize=12)
        文件.save(base / "公告.pdf")
    print("ok")

if __name__ == "__main__":
    data_0()
    data_1()
    data_2()
    data_3()
    from pathlib import Path
    base = Path("ws/環境測試")
    (base / "慢速檢查.py").write_text('# -*- coding: utf-8 -*-\n"""使用者寫好的檢查函式：每一筆交易要查一次，一筆大約 0.15 秒。"""\nimport time\n\n\ndef 檢查(交易):\n    """交易是一列 dict（交易明細.csv 的一列）。回傳「正常」或「要複核」。"""\n    time.sleep(0.15)  # 假裝在做很慢的比對\n    金額 = int(交易["金額"])\n    if 金額 >= 450000 or 交易["客戶名稱"].endswith("9號有限公司"):\n        return "要複核"\n    return "正常"\n', encoding="utf-8")
    import zipfile
    for folder in ('多檔', '多檔_11月'):
        with zipfile.ZipFile(base / (folder + '.zip'), 'w', zipfile.ZIP_DEFLATED) as archive:
            for item in sorted((base / folder).glob('*.csv')):
                archive.write(item, item.name)
    files = sorted(p for p in base.rglob("*") if p.is_file())
    print("檔案總數：", len(files))
    for p in files: print(p.as_posix())
