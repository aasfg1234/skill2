# Spade 第八輪探測：記憶、配方、掃描檔、同時做事

想更了解工具的實際行為，方便寫使用說明。請實際呼叫工具做下面六題。

## 規則

- 只在 `ws/spade探測/q8/` 底下建立和使用假資料；做完可以留著。不碰其他資料，不讀任何設定或帳密檔。
- 原文照抄，不要摘要或改寫；路徑可以換成代稱。保留換行、空行和標點。
- 每題記下工具名稱、參數和回傳原文，原文放在程式碼區塊裡。沒測到的寫「沒測」和原因，不要猜。
- 把結果寫成 `ws/spade探測/q8/第八輪結果.md`，一題一節。

## 1. 有哪些工具

**做法**：不用呼叫工具。列出你這次對話可以用的**全部**工具名稱。

**回報什麼**：一個工具一行：名稱、說明的第一句原文、參數名稱。名稱開頭是 `memory`、或名稱是 `load`、`analyze`、`remote_skills` 的，說明要整段照抄。

## 2. 記憶工具

第 1 題有記憶類工具才做；沒有就寫「沒有記憶工具」。

**做法**

1. 用記憶工具存一則：`探測測試 q8：這是一則測試用的記憶，可以刪掉`。
2. 用記憶工具把它讀回來（或列出全部記憶）。

**回報什麼**：照抄兩次呼叫的參數和完整回傳。另外寫：這則記憶存在哪裡（對話裡、工作區的檔案、還是看不到）；工作區有沒有多出新檔（用 `find` 找 `ws/` 底下名稱含 memory 或 記憶 的檔）。**先不要刪**，第二個對話會用到。

## 3. 配方與背景工作

**做法**：呼叫 `functions.load`，只做「列出清單」那一種用法（不帶任何會開始工作的參數）。沒有這個工具就寫「沒有」。

**回報什麼**：照抄參數和完整回傳。回傳裡有配方（recipe）的話，列出名稱和說明；**不要執行任何配方**。

## 4. 文字辨識的套件

**做法**：用 `functions.python` 執行（`command`，不帶 `input_files`）：

```python
import importlib.util, shutil
for 名 in ["pytesseract", "easyocr", "rapidocr_onnxruntime", "rapidocr", "paddleocr", "onnxruntime", "cv2", "ocrmypdf", "winocr", "pymupdf", "fitz", "PIL"]:
    print(名, "有" if importlib.util.find_spec(名) else "沒有")
print("tesseract 執行檔", "有" if shutil.which("tesseract") else "沒有")
import pymupdf
print("pymupdf 版本", pymupdf.__version__)
```

**回報什麼**：照抄完整回傳。

## 5. 掃描檔能不能靠看圖讀出來

**做法**

1. 用 `functions.python` 執行下面的程式（`command`，不帶 `input_files`）。它會做一份「只有圖、沒有文字」的假 PDF，再把第一頁轉成 PNG：

```python
from pathlib import Path
import pymupdf
資料夾 = Path("ws/spade探測/q8")
資料夾.mkdir(parents=True, exist_ok=True)
原 = pymupdf.open()
頁 = 原.new_page()
頁.insert_text((72, 100), "施行日期：115年12月1日", fontname="china-t", fontsize=20)
頁.insert_text((72, 140), "截止日期：115/11/20", fontname="china-t", fontsize=20)
圖 = 頁.get_pixmap(dpi=150)
掃描 = pymupdf.open()
新頁 = 掃描.new_page(width=頁.rect.width, height=頁.rect.height)
新頁.insert_image(新頁.rect, pixmap=圖)
掃描.save(資料夾 / "假掃描.pdf")
print("抽得到的字數:", len(pymupdf.open(資料夾 / "假掃描.pdf")[0].get_text().strip()))
pymupdf.open(資料夾 / "假掃描.pdf")[0].get_pixmap(dpi=150).save(資料夾 / "假掃描_第1頁.png")
print("ok")
```

2. 用 `functions.read` 讀 `ws/spade探測/q8/假掃描_第1頁.png`。

**回報什麼**：照抄兩次呼叫的完整回傳（圖片不用貼，寫「回傳是圖片」即可）。另外寫：你從圖上看出的兩個日期（照圖上寫的抄，不要換算），以及有沒有看不清楚的字。

## 6. 同時做好幾件事

第 1 題有 `agent` 工具才做第 1～4 步；有 `multi_tool_use.parallel` 才做第 5 步。沒有的寫「沒有」。

**做法**

1. 連續呼叫 `agent` **三次**，每次都設 `async: true`，`prompt` 分別用下面這段，只把 `<編號>` 換成 1、2、3：

   ```
   用 functions.python 執行下面的程式（command，不帶 input_files），然後照抄它印出的全部內容回報，不要做別的事：
   import time, datetime
   from pathlib import Path
   開始 = datetime.datetime.now().strftime("%H:%M:%S.%f")
   time.sleep(20)
   結束 = datetime.datetime.now().strftime("%H:%M:%S.%f")
   Path("ws/spade探測/q8").mkdir(parents=True, exist_ok=True)
   Path("ws/spade探測/q8/背景_<編號>.txt").write_text(f"背景<編號> 開始 {開始} 結束 {結束}", encoding="utf-8")
   print(f"背景<編號> 開始 {開始} 結束 {結束}")
   ```

2. 三個都送出後，馬上呼叫 `load`，不帶參數（只列清單）。
3. 對三個工作各呼叫一次 `load`（`source` 填第 1 步拿到的工作 ID），等它們做完。
4. 用 `read` 讀 `ws/spade探測/q8/背景_1.txt`、`背景_2.txt`、`背景_3.txt`。
5. 用 `multi_tool_use.parallel` **一次**讀這三個檔（三個 `read`）。

**回報什麼**

- 第 1 步三次呼叫的參數和完整回傳（工作 ID 照抄）。有哪一次被拒絕或報錯，照抄錯誤原文。
- 第 2、3、5 步的參數和完整回傳。
- 三個檔裡的開始、結束時間，排成一張表。另外寫：三段時間**有沒有重疊**（有重疊＝真的同時在跑，沒有＝一個做完才換下一個）。
- 從送出第一個 `agent` 到三個都拿到結果，大約花了多久。
- 工具說明裡有沒有寫「同時最多幾個背景工作」或類似的限制，有的話照抄。

## 最後

把六題結果寫進 `ws/spade探測/q8/第八輪結果.md`，每題一節。
