# 第七輪第 13 題：另開一個新對話貼這段

（使用者說明：跑完第七輪之後，**開一個新的對話**，把下面「---」以下整段貼進去。結果跟第七輪第 13 題比對，就知道每個對話有沒有自己的編號。）

---

想了解每次執行看得到哪些環境資訊。這題只印環境變數的**名稱**；名稱像對話、工作編號的，只印長度和「指紋」（雜湊的前 8 碼，只用來比對是不是同一個值，看不出原本的值）。不要印任何環境變數的值。

用 `functions.python` 執行下面的程式一次（用 `command`，不帶 `input_files`），完整回傳原文照抄，放在程式碼區塊裡，寫進 `ws/spade探測/q7/第13題_第二個對話.md`。

```python
import os, re, hashlib
家 = os.path.expanduser("~")
print("cwd:", os.getcwd().replace(家, "<home>"))
名稱們 = sorted(os.environ)
print("環境變數名稱:", ", ".join(名稱們))
樣子 = re.compile(r"SESSION|CONVERS|THREAD|CHAT|RUN|TASK|REQUEST|TRACE|SPADE|SPAID|AGENT|CONTEXT|CLIENT", re.I)
for 名 in 名稱們:
    if 樣子.search(名):
        值 = os.environ[名]
        print(名, "長度", len(值), "指紋", hashlib.sha256(值.encode()).hexdigest()[:8])
```
