# Spade 第七輪探測：工具的實際行為

想更了解工具的實際行為，方便寫使用說明。請實際呼叫工具做下面十三題。

## 規則

- 只在 `ws/spade探測/q7/` 底下建立和使用假資料；做完可以留著。不碰其他資料，不讀任何設定或帳密檔。第 4 題建立的 `.gitignore` 是這次專用的假資料。
- 原文照抄，不要摘要或改寫；路徑可以換成代稱。保留換行、空行、縮排和標點。
- 每題記下工具名稱、參數和要求的回傳原文，原文放在程式碼區塊裡。沒測到的寫「沒測」和原因，不要猜。
- 把結果寫成 `ws/spade探測/q7/第七輪結果.md`，一題一節。第 6 題的大量重複字元不用貼進結果。
- 第 10～12 題會用 `functions.agent` 交工作給子代理。`prompt` 照框裡的字原樣傳入，不要加字、刪字或改寫；其他參數只填題目寫的。

## 1. write 覆寫既有檔

**做法**

1. 用 `functions.write` 建立 `ws/spade探測/q7/write覆寫.txt`，內容為 `第一次`。
2. 再用 `functions.write` 寫入同一路徑，內容改成 `第二次`。
3. 用 `functions.read` 讀回該檔。

**回報什麼**

照抄第二次 `write` 的完整回傳，以及 `read` 的完整回傳。

## 2. grep 的正規表示式

**做法**

先用 `functions.write` 建立 `ws/spade探測/q7/grep正規表示式.txt`，內容為：

```text
abcd
aa
漢字
```

各呼叫一次 `functions.grep`，`path="ws/spade探測/q7"`、`glob="grep正規表示式.txt"`，`pattern` 依序使用以下三個值。每個值照框裡的字傳入（`\1`、`\p` 前面都只有一個反斜線）：

```text
abc(?=d)
(a)\1
\p{Han}
```

**回報什麼**

三次各自記錄實際傳入的 `pattern`，並照抄完整回傳，包含錯誤訊息、換行和縮排。

## 3. edit 的重疊原文

**做法**

用 `functions.write` 建立 `ws/spade探測/q7/edit重疊.txt`，內容恰好是 `aaa`。接著呼叫 `functions.edit`：

- `path`：該檔案路徑
- `before`：`aa`
- `after`：`X`

再用 `functions.read` 讀回該檔。

**回報什麼**

照抄 `edit` 和 `read` 的完整回傳，讓人看得出工具怎麼處理兩處重疊的位置，以及檔案最後的內容。

## 4. find、grep、tree 遇到 .gitignore

**做法**

在 `ws/spade探測/q7/` 建立以下三個檔案：

- `.gitignore`：內容為 `忽略.txt`
- `忽略.txt`：內容為 `Q7測試內容`
- `保留.txt`：內容為 `Q7測試內容`

接著各呼叫一次：

1. `functions.find`：`path="ws/spade探測/q7"`，`pattern="txt$"`。
2. `functions.grep`：`path="ws/spade探測/q7"`，`pattern="Q7測試內容"`。
3. `functions.tree`：`path="ws/spade探測/q7"`，`depth=1`。

**回報什麼**

照抄三次工具的完整回傳，並分別註明有沒有列出 `忽略.txt` 和 `保留.txt`。如果工具沒有接受某個參數，也照抄錯誤原文。

## 5. tree 同層英文大小寫排序

**做法**

在 `ws/spade探測/q7/排序/` 建立三個檔案 `B.txt`、`a.txt`、`_c.txt`，每個檔案各寫入一行 `test`。對這個資料夾呼叫 `functions.tree`，`depth=1`。

**回報什麼**

照抄 `tree` 的完整回傳，保留三個檔案的實際順序。

## 6. python 大量 stdout 保留多少

**做法**

分別呼叫兩次 `functions.python`，都用 `command`，不帶 `input_files`。每一行剛好 100 個字（6 位數行號＋93 個 `A`＋換行），最後一行是 `END`：

```python
for i in range(1, 701):
    print("%06d" % i + "A" * 93)
print("END")
```

第二次把 `701` 改成 `1501`（第一次約 7 萬字，第二次約 15 萬字）。

**回報什麼**

每次分別記錄：

- 回傳裡看得到的第一行和最後一行的行號（例如 `000001`、`000700`），有沒有看到 `END`。
- 中間有沒有跳號，跳在哪裡。
- 有沒有警告；有的話照抄警告完整原文，以及它在輸出的前面還是後面。

不要把大量的 `A` 貼進結果。

## 7. python 修改內容但保留大小和修改時間

**做法**

1. 用 `functions.write` 建立 `ws/spade探測/q7/時間測試.txt`，內容恰好是 `abc`。
2. 呼叫 `functions.python`，把該檔列在 `input_files`，用 `command` 執行：

   ```python
   import os
   from pathlib import Path

   p = Path("ws/spade探測/q7/時間測試.txt")
   before = p.stat()
   print("修改前內容:", p.read_bytes())
   print("修改前大小:", before.st_size)
   print("修改前 mtime_ns:", before.st_mtime_ns)

   p.write_bytes(b"xyz")
   os.utime(p, ns=(before.st_atime_ns, before.st_mtime_ns))

   after = p.stat()
   print("修改後內容:", p.read_bytes())
   print("修改後大小:", after.st_size)
   print("修改後 mtime_ns:", after.st_mtime_ns)
   ```

3. 呼叫結束後，用 `functions.read` 讀工作區的同一個檔案。

**回報什麼**

照抄 `python` 的完整回傳，包含有沒有 `Artifacts:` 區塊；再照抄工作區檔案的 `read` 回傳。依實際結果說明內容有沒有帶回。

## 8. edit 找不到原文時的預覽

**做法**

用 `functions.write` 建立 `ws/spade探測/q7/edit預覽.txt`，內容為以下五行：

```text
第一行
第二行
第三行
第四行
第五行
```

接著呼叫 `functions.edit`，`path` 指向該檔，`before="不存在的原文"`，`after="替換文字"`。

**回報什麼**

照抄 `edit` 的完整回傳，包含找不到原文的訊息、後面的檔案預覽、空行、縮排及標點。

## 9. 套件查詢工具的回傳格式

**做法**

1. 呼叫 `functions.check_python_packages`，`names` 同時放入 `openpyxl` 和 `spade-q7-package-does-not-exist-987654321`。前者用來查已安裝套件，後者用來查不存在的假套件。
2. 呼叫 `functions.list_python_packages`，不帶參數。

**回報什麼**

- 照抄 `check_python_packages` 的完整回傳。如果 `openpyxl` 實際上沒有安裝，照實記錄；再從套件清單選一個確定有的套件，與同一個假套件一起再查一次，照抄該次完整回傳。
- 照抄 `list_python_packages` 回傳的前 3 行，包含標頭或空行；如果不到 3 行，就照抄全部。

## 10. agent 一般模式（等它做完）

**做法**

1. 呼叫 `functions.agent`，只填 `prompt`（不填 `async`），內容照下面框裡的字：

   ```text
   請在 ws/spade探測/q7/子代理/ 建立「子代理寫的.txt」，內容恰好是「子代理寫入」。
   接著把你這次能用的所有工具名稱一行一個列出來（照工具清單上的原名），再寫出你的工作目錄（可以用代稱）。
   最後一則回覆的第一行只寫「完成」，下面接工具名稱和工作目錄。
   ```

2. 呼叫結束後，用 `functions.read` 讀工作區的 `ws/spade探測/q7/子代理/子代理寫的.txt`。

**回報什麼**

- 照抄 `agent` 的完整回傳，包含前後任何不是子代理寫的文字（例如標頭、統計、提示）。
- 照抄 `read` 的完整回傳；讀不到就照抄錯誤原文。

## 11. agent 背景模式和 load

**做法**

1. 呼叫 `functions.agent`，填 `async=true`，`prompt` 照下面框裡的字：

   ```text
   用 functions.python 執行以下程式（用 command，不帶 input_files）：
   import time
   time.sleep(60)
   print("背景完成")
   最後一則回覆只寫 python 回傳裡印出的那一行。
   ```

2. 拿到回傳後**馬上**呼叫 `functions.load`，不帶任何參數。
3. 呼叫 `functions.load`，`source` 填第 1 步回傳的任務 ID（等它做完）。
4. 用同一個任務 ID 再呼叫一次 `functions.load`。
5. 呼叫 `functions.load`，`source="q7-不存在的任務"`。

**回報什麼**

照抄 5 次呼叫的完整回傳（第 1 步是 `agent` 的回傳），包含任務 ID 的完整樣子和錯誤訊息。第 3 步請另外記下大約等了幾秒才回來。

## 12. 取消背景工作

**做法**

1. 呼叫 `functions.agent`，填 `async=true`，`prompt` 照下面框裡的字：

   ```text
   用 functions.python 執行以下程式（用 command，不帶 input_files）：
   import time
   time.sleep(120)
   print("不應該看到這行")
   最後一則回覆只寫 python 回傳裡印出的那一行。
   ```

2. 拿到回傳後**馬上**呼叫 `functions.load`，`source` 填任務 ID，`cancel=true`。
3. 呼叫 `functions.load`，不帶任何參數。

**回報什麼**

照抄 3 次呼叫的完整回傳。如果第 2 步沒有馬上回來、而是等到工作做完，也照實記錄大約等了幾秒。

## 13. 每次執行看得到哪些環境資訊

這題只印環境變數的**名稱**；名稱像對話、工作編號的，只印長度和「指紋」（雜湊的前 8 碼，只用來比對兩次是不是同一個值，看不出原本的值）。不要印任何環境變數的值。

**做法**

用 `functions.python` 執行下面的程式兩次（分成兩次呼叫，用 `command`，不帶 `input_files`）：

```python
import os, re, hashlib
家 = os.path.expanduser("~")
print("cwd:", os.getcwd().replace(家, "<home>"))
名稱們 = sorted(os.environ)
print("環境變數名稱:", ", ".join(名稱們))
樣子 = re.compile(r"SESSION|CONVERS|THREAD|CHAT|RUN|TASK|REQUEST|TRACE|SPADE|SPAID|AGENT|CONTEXT|CLIENT", re.I)
for 名 in 名稱們:
    if 樣子.search(名):
        值 = os.environ[名]
        print(名, "長度", len(值), "指紋", hashlib.sha256(值.encode()).hexdigest()[:8])
```

**回報什麼**

照抄兩次的完整回傳。另外寫一句：兩次的 cwd、每個有指紋的名稱，指紋是不是一樣。

## 最後

把十三題結果寫進 `ws/spade探測/q7/第七輪結果.md`，每題一節。測試用假資料可以留在 `q7/`。