"""日常資料處理工具。

用法（隔離 Python 工具）：把 `_工作/範本/常用工具.py` 列進 input_files，程式開頭寫
    import sys; sys.path.insert(0, "_工作/範本")
    from 常用工具 import *
有：讀表、寫表、寫多表、轉數字、轉數字欄、備份、寫雙擊檔、分組加總、前幾名、比對清單、打包成壓縮檔、
記錄任務、記錄錯誤、看檔、寫文字、寫JSON、讀Word表格、讀文件文字、找相似、轉日期、轉日期欄、轉民國、
比對文字、合併多檔、安全檔名、依欄拆分、存倉庫、工作代號、預期產出。docx／pdf／pptx 的套件用到才載入。
import 就會自動打卡，紀錄在 `_工作/紀錄/執行_*.csv`；設定環境變數 `常用工具_不打卡=1` 可關閉。
隔離區的打卡另記帶入和產出檔案的個數及副檔名，不記檔名；超過 5000 個時顯示「5000 個以上」。
中間檔可寫入 `_工作/倉庫/名稱/`，結束時自動存為同名 zip；下次將 zip 列入 input_files。
長工作可先呼叫 存倉庫() 存檔；之後清空資料夾也會存成空 zip。
設定 `常用工具_不開倉庫=1` 可關閉自動處理。
工作代號(名稱) 設定本次紀錄的代號（去頭尾空白、最多 40 字、不可換行）；
未設定時使用開過或存過的倉庫名稱，沒有則留空。任務及錯誤紀錄可傳 工作代號= 覆蓋。
程式若接住 sys.exit 引發的 SystemExit 並繼續執行，紀錄仍會保留該次結束碼。
直接 raise SystemExit(3) 會記成完成；被逾時砍掉的執行會留下「執行中」。
錯誤文字會遮掉引號內的內容與類似路徑的片段。
預期產出(路徑1, 路徑2) 可多次登記成果，結束時先檢查檔案是否存在且不是空檔，再打包倉庫並更新打卡；核對失敗會顯示原因並記入打卡。
記錄任務可填規則版本；執行、任務和錯誤紀錄會自動填入常用工具版本。
讀表及看檔會提醒沒有計算結果的 Excel 公式；看檔會列出 PDF 沒有文字的頁碼，讀文件文字會提醒。
"""

版本 = "2026.11.01"

import atexit
import csv
import functools
import hashlib
import math
import ntpath
import os
import posixpath
import re
import shutil
import sys
import tempfile
import threading
import time as _時間模組
import unicodedata
import zipfile
import xml.etree.ElementTree as ET
from datetime import date, datetime, time, timedelta
from io import StringIO
from pathlib import Path

from charset_normalizer import from_bytes
from openpyxl import Workbook, load_workbook
from openpyxl.utils.datetime import from_excel, to_excel


def _檢查欄位(欄位):
    if len(set(欄位)) != len(欄位):
        raise ValueError("欄名重複")


def _有公式的工作表(路徑, 名稱們):
    """只掃描指定工作表的 XML，避免沒有公式的檔案再用 openpyxl 讀一次。"""
    指定 = set(名稱們)
    結果 = set()
    with zipfile.ZipFile(路徑) as 壓縮檔:
        工作簿 = ET.fromstring(壓縮檔.read("xl/workbook.xml"))
        關係 = ET.fromstring(壓縮檔.read("xl/_rels/workbook.xml.rels"))
        目標 = {項.get("Id"): 項.get("Target") for 項 in 關係
              if 項.get("TargetMode") != "External"}
        標籤 = re.compile(rb"<(?:[A-Za-z_][\w.-]*:)?f(?:[\s/>])")
        for 工作表 in 工作簿.iter():
            if 工作表.tag.rsplit("}", 1)[-1] != "sheet" or 工作表.get("name") not in 指定:
                continue
            關係碼 = next((值 for 鍵, 值 in 工作表.attrib.items() if 鍵.endswith("}id")), None)
            位置 = 目標[關係碼]
            檔名 = posixpath.normpath(位置.lstrip("/") if 位置.startswith("/") else "xl/" + 位置)
            with 壓縮檔.open(檔名) as 檔案:
                尾 = b""
                while True:
                    區塊 = 檔案.read(65536)
                    if not 區塊:
                        break
                    資料 = 尾 + 區塊.replace(b"\x00", b"")
                    if 標籤.search(資料):
                        結果.add(工作表.get("name"))
                        break
                    尾 = 資料[-256:]
    return 結果


def _公式沒有值(路徑, 值簿, 名稱們):
    有公式 = _有公式的工作表(路徑, 名稱們)
    if not 有公式:
        return {}
    公式簿 = load_workbook(路徑, read_only=True, data_only=False)
    結果 = {}
    try:
        for 名稱 in 名稱們:
            if 名稱 not in 有公式:
                continue
            格數, 範例 = 0, []
            for 公式列, 值列 in zip(公式簿[名稱].iter_rows(), 值簿[名稱].iter_rows()):
                for 公式格, 值格 in zip(公式列, 值列):
                    if 公式格.data_type == "f" and 值格.value is None:
                        格數 += 1
                        if len(範例) < 3:
                            範例.append(公式格.coordinate)
            if 格數:
                結果[名稱] = 格數
                例子 = "、".join(範例)
                print(f"!! 工作表「{名稱}」有 {格數} 格公式沒有算好的值（例如 {例子}），讀到的是空白。請使用者用 Excel 打開這個檔、存檔一次再跑")
    finally:
        公式簿.close()
    return 結果


def _解碼(資料):
    """用整個檔判斷編碼：先試 utf-8、cp950，都不是再交給 charset_normalizer。"""
    for 候選 in ("utf-8-sig", "cp950"):
        try:
            return 資料.decode(候選), 候選
        except UnicodeDecodeError:
            pass
    結果 = from_bytes(資料).best()
    if 結果 is None:
        raise ValueError("無法判斷檔案編碼")
    return str(結果), 結果.encoding


def _讀取(路徑, 工作表=None):
    路徑 = Path(路徑)
    if 路徑.suffix.lower() == ".csv":
        文字, 編碼 = _解碼(路徑.read_bytes())
        資料列 = list(csv.reader(StringIO(文字, newline="")))
    elif 路徑.suffix.lower() == ".xlsx":
        活頁簿 = load_workbook(路徑, read_only=True, data_only=True)
        try:
            if 工作表 is None:
                工作頁 = 活頁簿.worksheets[0]
            elif isinstance(工作表, int) and not isinstance(工作表, bool):
                if not 1 <= 工作表 <= len(活頁簿.worksheets):
                    raise ValueError("找不到指定的工作表")
                工作頁 = 活頁簿.worksheets[工作表 - 1]
            elif isinstance(工作表, str) and 工作表 in 活頁簿.sheetnames:
                工作頁 = 活頁簿[工作表]
            else:
                raise ValueError("找不到指定的工作表")
            _公式沒有值(路徑, 活頁簿, [工作頁.title])
            資料列 = list(工作頁.iter_rows(values_only=True))
        finally:
            活頁簿.close()
        編碼 = "xlsx"
    else:
        raise ValueError("只支援 CSV 或 XLSX 檔案")
    if not 資料列:
        return [], [], 編碼
    欄位 = list(資料列[0])
    _檢查欄位(欄位)
    列 = []
    for 資料 in 資料列[1:]:
        if all(值 is None or str(值).strip() == "" for 值 in 資料):
            continue
        if len(資料) > len(欄位) and any(值 is not None and str(值).strip() for 值 in 資料[len(欄位):]):
            raise ValueError("資料列的欄位數超過欄名數")
        列.append(dict(zip(欄位, list(資料) + [None] * (len(欄位) - len(資料)))))
    return 列, 欄位, 編碼


def 讀表(路徑, 工作表=None):
    """讀取表格並回傳資料列與實際編碼。"""
    列, _, 編碼 = _讀取(路徑, 工作表)
    return 列, 編碼


_XLSX最多列 = 1048575  # 一張工作表扣掉標題列後最多幾列


def _準備表(列, 欄位, 數字欄, 名稱="寫表"):
    列 = list(列)
    欄位 = list(欄位) if 欄位 is not None else (list(列[0]) if 列 else [])
    _檢查欄位(欄位)
    數字欄 = list(數字欄) if 數字欄 is not None else []
    if set(數字欄) - set(欄位):
        raise ValueError("數字欄含有不存在的欄名")
    for 編號, 資料 in enumerate(列, 1):
        if set(資料) - set(欄位):
            raise ValueError(f"第 {編號} 列資料含有未指定的欄位")
    if 數字欄:
        列 = [dict(資料) for 資料 in 列]
        for 編號, 資料 in enumerate(列, 1):
            for 欄 in 數字欄:
                原值 = 資料.get(欄)
                數字, 原因 = 轉數字(原值)
                if 原因:
                    print(f"{名稱}：「{欄}」第 {編號} 列「{原值}」無法轉成數字，保留原值")
                else:
                    資料[欄] = 數字
    return 列, 欄位


def _檢查xlsx字數(欄位, 列):
    for 值 in 欄位:
        if isinstance(值, str) and len(值) > 32767:
            raise ValueError("XLSX 欄名超過 32767 字元")
    for 編號, 資料 in enumerate(列, 1):
        for 欄, 值 in 資料.items():
            if isinstance(值, str) and len(值) > 32767:
                raise ValueError(f"第 {編號} 列「{欄}」超過 XLSX 儲存格上限 32767 字元")


def _核對讀回(暫存路徑, 工作表, 列, 欄位, 是csv):
    讀回列, 讀回欄位, _ = _讀取(暫存路徑, 工作表)
    if len(讀回列) != len(列) or 讀回欄位 != 欄位:
        raise ValueError("寫回檢查失敗：筆數或欄位不符")
    for 編號, (原列, 讀回) in enumerate(zip(列, 讀回列), 1):
        for 欄 in 欄位:
            原值 = 原列.get(欄)
            if 是csv:
                預期 = "" if 原值 is None else str(原值)
            elif 原值 == "":
                預期 = None
            elif isinstance(原值, (datetime, date, time, timedelta)):
                預期 = from_excel(to_excel(原值), timedelta=isinstance(原值, timedelta))
            else:
                預期 = 原值
            if 讀回[欄] != 預期:
                raise ValueError(f"寫回檢查失敗：第 {編號} 列「{欄}」內容不符")


def _顯示寬度(值):
    if 值 is None:
        return 0
    if isinstance(值, (datetime, date)):
        return 10
    return max((sum(2 if unicodedata.east_asian_width(字) in "WF" else 1 for 字 in 行)
                for 行 in str(值).splitlines()), default=0)


def _美化(工作頁, 欄位, 列):
    from openpyxl.utils import get_column_letter
    for 序, 欄 in enumerate(欄位, 1):
        寬 = max([_顯示寬度(欄)] + [_顯示寬度(資料.get(欄)) for 資料 in 列[:1000]])
        工作頁.column_dimensions[get_column_letter(序)].width = min(max(寬 + 2, 6), 60)
    工作頁.freeze_panes = "A2"
    if 列:
        工作頁.auto_filter.ref = 工作頁.dimensions


def _寫xlsx(路徑, 表們, 美化):
    """表們：{工作表名稱（None＝預設名稱）: (欄位, 列)}。寫入暫存檔、逐張核對讀回後替換目標。"""
    for 欄位, 列 in 表們.values():
        _檢查xlsx字數(欄位, 列)
    路徑.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.NamedTemporaryFile(dir=路徑.parent, suffix=路徑.suffix, delete=False) as 暫存檔:
        暫存路徑 = Path(暫存檔.name)
    try:
        活頁簿 = Workbook()
        try:
            for 序, (名稱, (欄位, 列)) in enumerate(表們.items()):
                工作頁 = 活頁簿.active if 序 == 0 else 活頁簿.create_sheet()
                if 名稱 is not None:
                    工作頁.title = 名稱
                if not 欄位:
                    continue
                工作頁.append(欄位)
                for 資料 in 列:
                    工作頁.append([資料.get(欄) for 欄 in 欄位])
                for 工作列 in 工作頁.iter_rows():
                    for 儲存格 in 工作列:
                        if isinstance(儲存格.value, str) and 儲存格.value.startswith("="):
                            儲存格.data_type = "s"
                if 美化:
                    _美化(工作頁, 欄位, 列)
            活頁簿.save(暫存路徑)
        finally:
            活頁簿.close()
        for 序, (名稱, (欄位, 列)) in enumerate(表們.items(), 1):
            _核對讀回(暫存路徑, 名稱 if 名稱 is not None else 序, 列, 欄位, False)
        暫存路徑.replace(路徑)
    finally:
        暫存路徑.unlink(missing_ok=True)


def 寫表(路徑, 列, 欄位=None, 數字欄=None, 美化=True):
    """檢查欄位和內容，寫入暫存檔並核對讀回資料後替換目標。

    xlsx 預設調欄寬、凍結第一列、加篩選（美化=False 就不做）；超過一張工作表的上限時自動分成多張。
    """
    路徑 = Path(路徑)
    列, 欄位 = _準備表(列, 欄位, 數字欄)
    if 路徑.suffix.lower() not in (".csv", ".xlsx"):
        raise ValueError("只支援 CSV 或 XLSX 檔案")
    if 路徑.suffix.lower() == ".xlsx":
        if len(列) > _XLSX最多列:
            段們 = [列[起:起 + _XLSX最多列] for 起 in range(0, len(列), _XLSX最多列)]
            print(f"寫表：{len(列):,} 列超過一張工作表的上限（{_XLSX最多列:,} 列），"
                  f"分成 {len(段們)} 張工作表：資料1～資料{len(段們)}")
            _寫xlsx(路徑, {f"資料{序}": (欄位, 段) for 序, 段 in enumerate(段們, 1)}, 美化)
        else:
            _寫xlsx(路徑, {None: (欄位, 列)}, 美化)
        return len(列)
    路徑.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.NamedTemporaryFile(dir=路徑.parent, suffix=路徑.suffix, delete=False) as 暫存檔:
        暫存路徑 = Path(暫存檔.name)
    try:
        with 暫存路徑.open("w", encoding="utf-8-sig", newline="") as 檔案:
            寫入器 = csv.DictWriter(檔案, fieldnames=欄位)
            if 欄位:
                寫入器.writeheader()
                寫入器.writerows(列)
        _核對讀回(暫存路徑, None, 列, 欄位, True)
        暫存路徑.replace(路徑)
    finally:
        暫存路徑.unlink(missing_ok=True)
    return len(列)


def _檢查工作表名(名稱們):
    看過 = set()
    for 名稱 in 名稱們:
        if (not isinstance(名稱, str) or not 1 <= len(名稱) <= 31 or any(字 in "[]:*?/\\" for 字 in 名稱)
                or 名稱.startswith("'") or 名稱.endswith("'")):
            raise ValueError(f"工作表名稱不合法（1～31 字，不能有 []:*?/\\）：{名稱}")
        if 名稱.lower() in 看過:
            raise ValueError(f"工作表名稱重複：{名稱}")
        看過.add(名稱.lower())


def 寫多表(路徑, 表們, 數字欄=None, 美化=True):
    """把好幾張表寫進同一個 xlsx。表們：{工作表名稱: 列} 或 {工作表名稱: (列, 欄位)}。

    數字欄套用在有那一欄的工作表。回傳 {工作表名稱: 筆數}。
    """
    路徑 = Path(路徑)
    if 路徑.suffix.lower() != ".xlsx":
        raise ValueError("寫多表只支援 XLSX 檔案")
    if not 表們:
        raise ValueError("沒有要寫的工作表")
    _檢查工作表名(list(表們))
    數字欄 = list(數字欄) if 數字欄 is not None else []
    準備好, 用到的數字欄 = {}, set()
    for 名稱, 內容 in 表們.items():
        列, 欄位 = 內容 if isinstance(內容, tuple) else (內容, None)
        列 = list(列)
        欄位 = list(欄位) if 欄位 is not None else (list(列[0]) if 列 else [])
        這張數字欄 = [欄 for 欄 in 數字欄 if 欄 in 欄位]
        用到的數字欄.update(這張數字欄)
        列, 欄位 = _準備表(列, 欄位, 這張數字欄, f"寫多表「{名稱}」")
        if len(列) > _XLSX最多列:
            raise ValueError(f"工作表「{名稱}」超過一張工作表的上限（{_XLSX最多列:,} 列）")
        準備好[名稱] = (欄位, 列)
    if set(數字欄) - 用到的數字欄:
        raise ValueError("數字欄含有每張工作表都沒有的欄名")
    _寫xlsx(路徑, 準備好, 美化)
    return {名稱: len(列) for 名稱, (_, 列) in 準備好.items()}


def 轉數字(值):
    """轉換數字並回傳數值與失敗原因；逗號須符合千分位格式。"""
    if 值 is None:
        return None, "沒有數值"
    文字 = unicodedata.normalize("NFKC", str(值)).strip()
    if not 文字:
        return None, "空白"
    負數 = 文字.startswith("(") and 文字.endswith(")")
    if 負數:
        文字 = 文字[1:-1].strip()
    文字 = 文字.replace("$", "").replace("元", "").strip()
    if 負數 and 文字.startswith(("+", "-")):
        return None, "括號負數裡不能再有正負號"
    if "," in 文字 and not re.fullmatch(r"[+-]?\d{1,3}(?:,\d{3})+(?:\.\d*)?(?:[eE][+-]?\d+)?", 文字):
        return None, "千分位格式不對"
    文字 = 文字.replace(",", "")
    try:
        數字 = float(文字)
        if not math.isfinite(數字):
            raise ValueError
        if 負數:
            數字 = -數字
        return (int(數字) if 數字.is_integer() else 數字), ""
    except ValueError:
        return None, "無法轉成數字"


def 轉數字欄(列, 欄名):
    """轉換指定欄位，回傳有效數字及跳過的列與原因。"""
    有效, 跳過 = [], []
    for 編號, 資料 in enumerate(列, 1):
        原值 = 資料.get(欄名)
        數字, 原因 = 轉數字(原值)
        if 數字 is None:
            跳過.append((編號, 原值, 原因))
        else:
            有效.append(數字)
    return 有效, 跳過


def 備份(路徑):
    """備份工作區檔案至不重複的時間目錄並回傳備份路徑。"""
    根目錄 = Path.cwd().resolve()
    原檔 = Path(路徑).resolve()
    if not 原檔.is_file():
        raise FileNotFoundError("找不到要備份的檔案")
    try:
        相對路徑 = 原檔.relative_to(根目錄)
    except ValueError:
        raise ValueError("只能備份工作區內的檔案") from None
    備份目錄 = 根目錄 / "_工作" / "備份"
    備份目錄.mkdir(parents=True, exist_ok=True)
    名稱 = datetime.now().strftime("%Y%m%d_%H%M%S_%f")
    序號 = 1
    while True:
        目錄 = 備份目錄 / f"{名稱}{'_' + str(序號) if 序號 > 1 else ''}"
        try:
            目錄.mkdir()
            break
        except FileExistsError:
            序號 += 1
    目的地 = 目錄 / 相對路徑
    目的地.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(原檔, 目的地)
    return 目的地


def 寫雙擊檔(路徑, 指令列):
    """寫入 Windows 雙擊檔並回傳路徑。指令列可給一段文字，或一行一個的 list。"""
    路徑 = Path(路徑)
    if 路徑.suffix.lower() != ".cmd":
        raise ValueError("雙擊檔的副檔名必須是 .cmd")
    if not isinstance(指令列, str):
        指令列 = "\n".join(str(行) for 行 in 指令列)
    路徑.parent.mkdir(parents=True, exist_ok=True)
    內容 = "@echo off\nchcp 65001 >nul\n" + 指令列.replace("\r\n", "\n").replace("\r", "\n")
    路徑.write_bytes((內容.rstrip("\n") + "\n").replace("\n", "\r\n").encode("utf-8"))
    return 路徑


def _欄名清單(欄位):
    return [欄位] if isinstance(欄位, str) else list(欄位)


def _組鍵(資料, 欄位):
    return tuple("（空白）" if 資料.get(欄) in (None, "") else 資料[欄] for 欄 in 欄位)


def _有效列(列, 數字欄):
    有效, 跳過 = [], []
    for 編號, 資料 in enumerate(列, 1):
        原值 = 資料.get(數字欄)
        數字, 原因 = 轉數字(原值)
        if 數字 is None:
            跳過.append((編號, 原值, 原因))
        else:
            有效.append((資料, 數字))
    return 有效, 跳過


def _檢查資料欄(列, 欄位):
    for 編號, 資料 in enumerate(列, 1):
        for 欄 in 欄位:
            if 欄 not in 資料:
                raise ValueError(f"第 {編號} 列缺少欄位：{欄}")


def 分組加總(列, 分組欄, 數字欄):
    """檢查必要欄位後依分組計算筆數、總和及平均，並回傳跳過的列。"""
    欄位 = _欄名清單(分組欄)
    if set(欄位) & {"筆數", "總和", "平均"}:
        raise ValueError("分組欄與輸出欄名重複")
    列 = list(列)
    _檢查資料欄(列, 欄位 + [數字欄])
    有效, 跳過 = _有效列(列, 數字欄)
    組別 = {}
    for 資料, 數字 in 有效:
        鍵 = _組鍵(資料, 欄位)
        if 鍵 not in 組別:
            組別[鍵] = {**dict(zip(欄位, 鍵)), "筆數": 0, "總和": 0}
        組別[鍵]["筆數"] += 1
        組別[鍵]["總和"] += 數字
    for 組 in 組別.values():
        組["平均"] = 組["總和"] / 組["筆數"]
    return sorted(組別.values(), key=lambda 組: 組["總和"], reverse=True), 跳過


def 前幾名(列, 數字欄, n, 分組欄=None):
    """檢查必要欄位後依數字排名，並保留截止名次的同分列。"""
    if not isinstance(n, int) or isinstance(n, bool) or n < 0:
        raise ValueError("名次數量必須是非負整數")
    欄位 = _欄名清單(分組欄) if 分組欄 is not None else []
    列 = list(列)
    _檢查資料欄(列, 欄位 + [數字欄])
    if any("名次" in 資料 for 資料 in 列):
        raise ValueError("原列已有名次欄")
    有效, 跳過 = _有效列(列, 數字欄)
    組別 = {}
    for 資料, 數字 in 有效:
        組別.setdefault(_組鍵(資料, 欄位), []).append((資料, 數字))
    結果 = []
    for 鍵 in sorted(組別, key=lambda 鍵: tuple(str(值) for 值 in 鍵)):
        上個數字, 名次 = None, 0
        for 編號, (資料, 數字) in enumerate(sorted(組別[鍵], key=lambda 項: 項[1], reverse=True), 1):
            if 數字 != 上個數字:
                名次 = 編號
            if 名次 > n:
                break
            結果.append({**資料, "名次": 名次})
            上個數字 = 數字
    return 結果, 跳過


def 比對清單(甲, 乙, 鍵, 比較欄=None):
    """按鍵比對兩份清單；未指定比較欄時比較兩列非鍵欄位的聯集。"""
    鍵欄 = _欄名清單(鍵)
    def 建索引(列, 名稱):
        索引 = {}
        for 編號, 資料 in enumerate(列, 1):
            for 欄 in 鍵欄:
                if 欄 not in 資料:
                    raise ValueError(f"{名稱}第 {編號} 列缺少鍵：{欄}")
            值 = tuple(資料[欄] for 欄 in 鍵欄)
            if 值 in 索引:
                raise ValueError(f"{名稱}的鍵重複：{值}")
            索引[值] = 資料
        return 索引
    甲索引, 乙索引 = 建索引(甲, "甲"), 建索引(乙, "乙")
    結果 = {"只在甲": [], "只在乙": [], "兩邊不同": [], "相同": 0}
    缺少 = object()
    for 值, 甲列 in 甲索引.items():
        if 值 not in 乙索引:
            結果["只在甲"].append(甲列)
            continue
        乙列 = 乙索引[值]
        欄位 = _欄名清單(比較欄) if 比較欄 is not None else [欄 for 欄 in dict.fromkeys([*甲列, *乙列]) if 欄 not in 鍵欄]
        不同 = [欄 for 欄 in 欄位 if 甲列.get(欄, 缺少) != 乙列.get(欄, 缺少)]
        if 不同:
            結果["兩邊不同"].append((甲列, 乙列, 不同))
        else:
            結果["相同"] += 1
    結果["只在乙"] = [資料 for 值, 資料 in 乙索引.items() if 值 not in 甲索引]
    return 結果


def 打包成壓縮檔(zip路徑, 檔案們):
    """將表格、文字或位元組打包並確認檔數。"""
    for 名稱 in 檔案們:
        if (not isinstance(名稱, str) or not 名稱 or
                any(not 段 or 段 in (".", "..") or 段.endswith((" ", ".")) or
                    any(字 in '\\:*?"<>|' or ord(字) < 32 for 字 in 段)
                    for 段 in 名稱.split("/"))):
            raise ValueError(f"壓縮檔內路徑不合法：{名稱}")
    路徑 = Path(zip路徑)
    路徑.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(路徑, "w", compression=zipfile.ZIP_DEFLATED) as 壓縮檔:
        for 名稱, 內容 in 檔案們.items():
            if isinstance(內容, list):
                文字 = StringIO(newline="")
                if 內容:
                    寫入器 = csv.DictWriter(文字, fieldnames=list(內容[0]))
                    寫入器.writeheader()
                    寫入器.writerows(內容)
                內容 = 文字.getvalue().encode("utf-8-sig")
            elif isinstance(內容, str):
                內容 = 內容.encode("utf-8")
            elif not isinstance(內容, bytes):
                raise ValueError(f"檔案內容格式不支援：{名稱}")
            壓縮檔.writestr(名稱, 內容)
    with zipfile.ZipFile(路徑) as 壓縮檔:
        if len(壓縮檔.infolist()) != len(檔案們):
            raise ValueError("壓縮檔檢查失敗：檔數不符")
    return len(檔案們)


def _第一行錯誤(錯誤):
    文字 = str(錯誤).strip()
    return f"{type(錯誤).__name__}: {文字.splitlines()[0]}" if 文字 else type(錯誤).__name__


def _看xlsx(路徑):
    活頁簿 = load_workbook(路徑, read_only=True, data_only=True)
    try:
        工作表們 = []
        for 工作頁 in 活頁簿.worksheets:
            資料列 = [列 for 列 in 工作頁.iter_rows(values_only=True)
                   if any(值 is not None and str(值).strip() for 值 in 列)]
            工作表們.append({"名稱": 工作頁.title, "列數": max(len(資料列) - 1, 0),
                         "欄名": list(資料列[0]) if 資料列 else [], "前幾列": [list(列) for 列 in 資料列[1:4]]})
        return {"工作表": 工作表們, "公式沒有值": _公式沒有值(路徑, 活頁簿, 活頁簿.sheetnames)}
    finally:
        活頁簿.close()


def _看docx(路徑):
    import docx
    文件 = docx.Document(路徑)
    段落 = [段.text.strip() for 段 in 文件.paragraphs if 段.text.strip()]
    表格 = [{"列數": len(表.rows), "欄數": len(表.columns),
           "表頭": [格.text.strip() for 格 in 表.rows[0].cells] if 表.rows else []} for 表 in 文件.tables]
    return {"段落數": len(段落), "表格": 表格, "開頭": 段落[:3]}


def _看pdf(路徑):
    文字們 = _pdf各頁(路徑)
    資訊 = {"頁數": len(文字們), "開頭": (文字們[0] if 文字們 else "")[:200],
          "沒有文字的頁": [序 for 序, 文字 in enumerate(文字們, 1) if not 文字.strip()]}
    if not any(文字.strip() for 文字 in 文字們):
        資訊["提醒"] = "抓不到文字，可能是掃描檔（整頁是圖片）"
    return 資訊


def 看檔(路徑):
    """開工前一次看清楚檔案：類型、大小，以及編碼、工作表、列數、欄名、前幾列等。回傳 dict。

    檔案壞掉打不開時不會停，dict 裡會有「錯誤」（錯誤原文第一行）。
    """
    路徑 = Path(路徑)
    資訊 = {"路徑": 路徑.as_posix(), "類型": 路徑.suffix.lower().lstrip("."), "大小": 路徑.stat().st_size}
    try:
        類型 = 資訊["類型"]
        if 類型 == "csv":
            列, 欄位, 編碼 = _讀取(路徑)
            資訊.update(編碼=編碼, 列數=len(列), 欄名=欄位, 前幾列=列[:3])
        elif 類型 in ("xlsx", "xlsm"):
            資訊.update(_看xlsx(路徑))
        elif 類型 == "docx":
            資訊.update(_看docx(路徑))
        elif 類型 == "pdf":
            資訊.update(_看pdf(路徑))
        elif 類型 == "pptx":
            from pptx import Presentation
            資訊["投影片數"] = len(Presentation(路徑).slides)
        elif 類型 in ("xls", "doc", "ppt"):
            資訊["提醒"] = "舊版 Office 格式，請使用者另存成新版（xlsx、docx、pptx）再處理"
        else:
            資料 = 路徑.read_bytes()
            if b"\x00" in 資料[:8192]:
                資訊["提醒"] = "看起來不是文字檔"
            else:
                文字, 編碼 = _解碼(資料)
                行們 = 文字.splitlines()
                資訊.update(編碼=編碼, 行數=len(行們), 開頭=行們[:3])
    except Exception as 錯誤:  # 看檔只回報，不中斷
        資訊["錯誤"] = _第一行錯誤(錯誤)
    return 資訊


def 寫文字(路徑, 文字, 編碼="utf-8"):
    """寫文字檔：自動建資料夾、換行原樣保留、寫完讀回檢查。回傳路徑。"""
    路徑 = Path(路徑)
    路徑.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.NamedTemporaryFile(dir=路徑.parent, suffix=路徑.suffix, delete=False) as 暫存檔:
        暫存路徑 = Path(暫存檔.name)
    try:
        暫存路徑.write_bytes(文字.encode(編碼))
        if 暫存路徑.read_bytes().decode(編碼) != 文字:
            raise ValueError("寫回檢查失敗：內容不符")
        暫存路徑.replace(路徑)
    finally:
        暫存路徑.unlink(missing_ok=True)
    return 路徑.as_posix()


def 寫JSON(路徑, 資料):
    """寫 JSON 檔（中文不轉碼、縮排 2）：自動建資料夾、寫完讀回檢查。日期會存成文字。回傳路徑。"""
    import json
    文字 = json.dumps(資料, ensure_ascii=False, indent=2, default=str) + "\n"
    json.loads(文字)
    return 寫文字(路徑, 文字)


def _唯一欄名(表頭, 寬度):
    欄位, 看過 = [], {}
    for 序 in range(寬度):
        名稱 = 表頭[序] if 序 < len(表頭) and 表頭[序] else f"欄{序 + 1}"
        if 名稱 in 看過:
            看過[名稱] += 1
            名稱 = f"{名稱}_{看過[名稱]}"
        看過.setdefault(名稱, 1)
        欄位.append(名稱)
    return 欄位


def 讀Word表格(路徑):
    """讀 docx 裡的每一個表格。回傳 list，一個表格一個 list[dict]（第一列當欄名，空白列略過）。

    欄名空白的叫「欄1」「欄2」…，重複的加「_2」。
    """
    import docx
    結果 = []
    for 表 in docx.Document(路徑).tables:
        資料列 = [[格.text.strip() for 格 in 行.cells] for 行 in 表.rows]
        資料列 = [列 for 列 in 資料列 if any(列)]
        if not 資料列:
            結果.append([])
            continue
        寬度 = max(len(列) for 列 in 資料列)
        欄位 = _唯一欄名(資料列[0], 寬度)
        結果.append([dict(zip(欄位, 列 + [""] * (寬度 - len(列)))) for 列 in 資料列[1:]])
    return 結果


def _pdf各頁(路徑):
    try:
        import pymupdf
    except ImportError:
        try:
            import fitz as pymupdf
        except ImportError:
            pymupdf = None
    if pymupdf is not None:
        with pymupdf.open(路徑) as 文件:
            return [頁.get_text() for 頁 in 文件]
    from pypdf import PdfReader
    return [頁.extract_text() or "" for 頁 in PdfReader(路徑).pages]


def 讀文件文字(路徑):
    """讀出 docx、pdf、pptx 或文字檔的全部文字（docx 照原本順序含表格，表格一列一行、欄用 tab 分開）。

    pdf 每頁前面加「=== 第 N 頁 ===」，pptx 每張加「=== 第 N 張 ===」。表格檔請用 讀表。
    """
    路徑 = Path(路徑)
    類型 = 路徑.suffix.lower()
    if 類型 in (".csv", ".xlsx", ".xlsm"):
        raise ValueError("表格檔請用 讀表")
    if 類型 in (".doc", ".ppt", ".xls"):
        raise ValueError("舊版 Office 格式讀不了，請使用者另存成新版（docx、pptx、xlsx）")
    if 類型 == ".docx":
        import docx
        from docx.table import Table
        from docx.text.paragraph import Paragraph
        文件 = docx.Document(路徑)
        行們 = []
        for 子 in 文件.element.body.iterchildren():
            標籤 = 子.tag.rsplit("}", 1)[-1]
            if 標籤 == "p":
                行們.append(Paragraph(子, 文件).text)
            elif 標籤 == "tbl":
                for 行 in Table(子, 文件).rows:
                    行們.append("\t".join(格.text.strip() for 格 in 行.cells))
        return "\n".join(行們)
    if 類型 == ".pdf":
        頁們 = _pdf各頁(路徑)
        空白頁 = [str(序) for 序, 頁 in enumerate(頁們, 1) if not 頁.strip()]
        if 空白頁 and len(空白頁) == len(頁們):
            print("整份抓不到字，可能是掃描檔")
        elif 空白頁:
            print(f"第 {'、'.join(空白頁)} 頁抓不到字，可能是掃描的，這幾頁的內容沒有讀到")
        return "\n".join(f"=== 第 {序} 頁 ===\n{頁.rstrip()}" for 序, 頁 in enumerate(頁們, 1))
    if 類型 == ".pptx":
        from pptx import Presentation
        區塊 = []
        for 序, 投影片 in enumerate(Presentation(路徑).slides, 1):
            行們 = [f"=== 第 {序} 張 ==="]
            for 形狀 in 投影片.shapes:
                if getattr(形狀, "has_text_frame", False) and 形狀.text_frame.text.strip():
                    行們.append(形狀.text_frame.text)
                if getattr(形狀, "has_table", False):
                    for 行 in 形狀.table.rows:
                        行們.append("\t".join(格.text.strip() for 格 in 行.cells))
            區塊.append("\n".join(行們))
        return "\n".join(區塊)
    return _解碼(路徑.read_bytes())[0]


def _比對用(文字):
    return "".join(unicodedata.normalize("NFKC", str(文字)).split()).lower()


def 找相似(列, 欄, 門檻=85, 分組欄=None):
    """找出某一欄很像（可能重複輸入）的兩兩配對。回傳 [(甲列, 乙列, 相似度)]，相似度 0～100，由高到低。

    比較前會統一全形半形、拿掉空白、英文轉小寫；空白值略過。欄可給多個欄名的 list（接起來比）。
    給 分組欄 就只比同一組裡的資料（資料很多時快很多）。
    短的字差一個字分數就掉很多：三個字的名字差一個字約 67 分、四個字約 75 分，找打錯的名字用 門檻=60。
    """
    import difflib
    欄位 = _欄名清單(欄)
    組欄 = _欄名清單(分組欄) if 分組欄 is not None else []
    列 = list(列)
    _檢查資料欄(列, 欄位 + 組欄)
    if not 0 <= 門檻 <= 100:
        raise ValueError("門檻要在 0～100 之間")
    組別 = {}
    for 資料 in 列:
        文字 = _比對用("".join("" if 資料[欄] is None else str(資料[欄]) for 欄 in 欄位))
        if 文字:
            組別.setdefault(_組鍵(資料, 組欄), []).append((資料, 文字))
    配對數 = sum(len(組) * (len(組) - 1) // 2 for 組 in 組別.values())
    if 配對數 > 10_000_000:  # 實測短名字約每秒 100 萬對，長文字更慢
        print(f"找相似：要比 {配對數:,} 對，可能要一分鐘以上；可以用 分組欄 縮小範圍")
    結果 = []
    比對器 = difflib.SequenceMatcher(autojunk=False)
    for 組 in 組別.values():
        for 乙序 in range(1, len(組)):
            乙, 乙文字 = 組[乙序]
            比對器.set_seq2(乙文字)
            for 甲, 甲文字 in 組[:乙序]:
                比對器.set_seq1(甲文字)
                if 比對器.real_quick_ratio() * 100 < 門檻 or 比對器.quick_ratio() * 100 < 門檻:
                    continue
                分數 = round(比對器.ratio() * 100, 1)
                if 分數 >= 門檻:
                    結果.append((甲, 乙, 分數))
    return sorted(結果, key=lambda 項: 項[2], reverse=True)


_日期格式 = re.compile(r"(\d{1,4})\s*[年/.\-]\s*(\d{1,2})\s*[月/.\-]\s*(\d{1,2})\s*日?(?:[\sT].*)?")


def 轉日期(值):
    """轉成日期（datetime.date）並回傳 (日期, 失敗原因)。

    看得懂：115/12/25、115.12.25、115-12-25、民國115年12月25日、1151225、2026/12/25、2026年12月25日、
    20261225、後面帶時間的寫法、Excel 的日期數字（5 位數，例如 46381），以及 date、datetime。年份小於 1000 當民國年。
    """
    if 值 is None:
        return None, "沒有值"
    if isinstance(值, datetime):
        return 值.date(), ""
    if isinstance(值, date):
        return 值, ""
    if isinstance(值, bool):
        return None, "無法轉成日期"
    if isinstance(值, float) and not 值.is_integer():
        if 10000 <= 值 < 100000:
            return from_excel(值).date(), ""
        return None, "無法轉成日期"
    文字 = unicodedata.normalize("NFKC", str(int(值) if isinstance(值, float) else 值)).strip()
    if not 文字:
        return None, "空白"
    民國 = False
    for 前綴 in ("中華民國", "民國"):
        if 文字.startswith(前綴):
            文字, 民國 = 文字[len(前綴):].strip(), True
            break
    符合 = _日期格式.fullmatch(文字)
    if 符合:
        年, 月, 日 = (int(數) for 數 in 符合.groups())
    elif re.fullmatch(r"\d{7}", 文字):
        年, 月, 日 = int(文字[:3]), int(文字[3:5]), int(文字[5:])
    elif re.fullmatch(r"\d{8}", 文字) and not 民國:
        年, 月, 日 = int(文字[:4]), int(文字[4:6]), int(文字[6:])
    elif re.fullmatch(r"\d{5}", 文字) and not 民國:  # Excel 的日期數字（約 1927～2173 年）
        return from_excel(int(文字)).date(), ""
    else:
        return None, "看不出是哪種日期寫法"
    if 年 < 1000:
        年 += 1911
    elif 民國:
        return None, "寫了民國，年份卻是西元"
    try:
        return date(年, 月, 日), ""
    except ValueError:
        return None, "日期不存在"


def 轉日期欄(列, 欄名):
    """轉換指定欄位，回傳有效日期及跳過的 (第幾列, 原值, 原因)。"""
    有效, 跳過 = [], []
    for 編號, 資料 in enumerate(列, 1):
        原值 = 資料.get(欄名)
        日期, 原因 = 轉日期(原值)
        if 日期 is None:
            跳過.append((編號, 原值, 原因))
        else:
            有效.append(日期)
    return 有效, 跳過


def 轉民國(日期, 分隔="/"):
    """把日期寫成民國年文字，例如 115/12/25。日期也可以給 轉日期 看得懂的文字。"""
    if not isinstance(日期, date):
        日期, 原因 = 轉日期(日期)
        if 日期 is None:
            raise ValueError(f"轉民國：{原因}")
    if 日期.year <= 1911:
        raise ValueError("轉民國：民國元年以前的日期不能寫成民國年")
    return f"{日期.year - 1911}{分隔}{日期.month:02}{分隔}{日期.day:02}"


def 比對文字(舊, 新, 忽略空白=False):
    """逐行比對兩份文字（文字或一行一個的 list）。回傳 list[dict]，可以直接交給 寫表。

    每筆有：動作（新增／刪除／修改）、舊行號、舊內容、新行號、新內容（沒有的是 None）。行尾空白一律不算差異；
    忽略空白=True 時，行內空白也不算。
    """
    import difflib
    舊行 = 舊.splitlines() if isinstance(舊, str) else [str(行) for 行 in 舊]
    新行 = 新.splitlines() if isinstance(新, str) else [str(行) for 行 in 新]
    鍵 = (lambda 行: "".join(行.split())) if 忽略空白 else (lambda 行: 行.rstrip())
    比對器 = difflib.SequenceMatcher(None, [鍵(行) for 行 in 舊行], [鍵(行) for 行 in 新行], autojunk=False)
    結果 = []

    def 加(動作, 舊序=None, 新序=None):
        結果.append({"動作": 動作,
                   "舊行號": None if 舊序 is None else 舊序 + 1, "舊內容": None if 舊序 is None else 舊行[舊序],
                   "新行號": None if 新序 is None else 新序 + 1, "新內容": None if 新序 is None else 新行[新序]})

    for 種類, 舊起, 舊迄, 新起, 新迄 in 比對器.get_opcodes():
        if 種類 == "equal":
            continue
        配對 = min(舊迄 - 舊起, 新迄 - 新起) if 種類 == "replace" else 0
        for 位移 in range(配對):
            加("修改", 舊起 + 位移, 新起 + 位移)
        for 舊序 in range(舊起 + 配對, 舊迄):
            加("刪除", 舊序=舊序)
        for 新序 in range(新起 + 配對, 新迄):
            加("新增", 新序=新序)
    return 結果


def 合併多檔(路徑們, 工作表=None):
    """把好幾個 CSV／XLSX 合成一份，回傳 list[dict]。路徑們可給 list，或含 * 的寫法（例如 "ws/月報/*.csv"）。

    每列多一個「來源檔」欄（檔名）；原本就有「來源檔」的保留原值，所以可以分批合併再合一次。
    欄名不一樣也能合：欄位取聯集，沒有的欄是 None。
    """
    import glob
    if isinstance(路徑們, (str, Path)):
        路徑們 = [路徑們]
    展開 = []
    for 路徑 in 路徑們:
        if any(字 in str(路徑) for 字 in "*?["):
            找到 = sorted(glob.glob(str(路徑)))
            if not 找到:
                raise FileNotFoundError(f"找不到符合的檔案：{路徑}（有沒有列進 input_files？）")
            展開.extend(找到)
        else:
            展開.append(str(路徑))
    if not 展開:
        raise ValueError("沒有要合併的檔案")
    全部, 欄序, 各檔欄位 = [], {"來源檔": None}, []
    for 路徑 in 展開:
        列, 欄位, _ = _讀取(路徑, 工作表)
        各檔欄位.append(set(欄位) - {"來源檔"})
        欄序.update(dict.fromkeys(欄位))
        for 資料 in 列:
            資料 = dict(資料)
            if 資料.get("來源檔") in (None, ""):
                資料["來源檔"] = Path(路徑).name
            全部.append(資料)
    欄位 = list(欄序)
    全部 = [{欄: 資料.get(欄) for 欄 in 欄位} for 資料 in 全部]
    不齊 = [欄 for 欄 in 欄位[1:] if any(欄 not in 集 for 集 in 各檔欄位)]
    print(f"合併多檔：{len(展開)} 個檔，共 {len(全部)} 列" + (f"；這些欄不是每個檔都有：{'、'.join(map(str, 不齊))}" if 不齊 else ""))
    return 全部


_保留檔名 = {"CON", "PRN", "AUX", "NUL", *(f"COM{序}" for 序 in range(1, 10)), *(f"LPT{序}" for 序 in range(1, 10))}


def 安全檔名(文字, 上限=100):
    """把文字改成 Windows 可以用的檔名：\\/:*?"<>| 和控制字元換成 _，去掉結尾的點和空白。空的叫「（空白）」。"""
    文字 = re.sub(r'[\\/:*?"<>|\x00-\x1f]', "_", "" if 文字 is None else str(文字)).strip().rstrip(". ")
    if not 文字:
        文字 = "（空白）"
    if 文字.split(".")[0].upper() in _保留檔名:
        文字 = "_" + 文字
    return 文字[:上限].rstrip(". ") or "（空白）"


def 依欄拆分(列, 欄, 副檔名=".csv", 用途="檔案"):
    """依某一欄的值把資料分開。回傳 {名稱: list[dict]}，順序照第一次出現。

    用途="檔案"：名稱是安全的檔名加副檔名，可以直接交給 打包成壓縮檔，或逐個 寫表。
    用途="工作表"：名稱是合法的工作表名稱（31 字內），可以直接交給 寫多表。
    名稱整理後撞名（例如「A/B」和「A_B」）會加「_2」。
    """
    if 用途 not in ("檔案", "工作表"):
        raise ValueError("用途只能是「檔案」或「工作表」")
    列 = list(列)
    _檢查資料欄(列, [欄])
    分組 = {}
    for 資料 in 列:
        分組.setdefault(資料[欄], []).append(資料)
    結果, 看過 = {}, set()
    for 值, 組 in 分組.items():
        if 用途 == "檔案":
            主名 = 安全檔名(值)
            名稱, 序 = 主名 + 副檔名, 1
            while 名稱.lower() in 看過:
                序 += 1
                名稱 = f"{主名}_{序}{副檔名}"
        else:
            主名 = re.sub(r"[\[\]:*?/\\]", "_", "" if 值 is None else str(值)).strip().strip("'") or "（空白）"
            名稱, 序 = 主名[:31], 1
            while 名稱.lower() in 看過:
                序 += 1
                名稱 = f"{主名[:31 - len(str(序)) - 1]}_{序}"
        看過.add(名稱.lower())
        結果[名稱] = 組
    print(f"依欄拆分：依「{欄}」分成 {len(結果)} 份")
    return 結果


_任務欄位 = ["時間", "任務類型", "skill", "約幾秒", "工具呼叫次數", "Python次數", "重做次數",
         "撞到的限制", "用了的現成工具", "問使用者次數", "為什麼問", "跳過怪資料筆數",
         "沒驗證到的", "規則建議", "使用者更正", "工作代號", "規則版本", "常用工具版本"]
_錯誤欄位 = ["時間", "任務類型", "工具", "錯誤原文", "原因分類", "怎麼解決", "工作代號", "常用工具版本"]


def _記錄(檔名, 固定欄位, 欄位):
    未知 = set(欄位) - set(固定欄位)
    if 未知:
        raise ValueError(f"不認得的欄名：{'、'.join(sorted(未知))}")
    欄位.setdefault("時間", datetime.now().strftime("%Y-%m-%d %H:%M:%S"))
    欄位.setdefault("工作代號", _目前工作代號())
    if "常用工具版本" in 固定欄位:
        欄位["常用工具版本"] = 版本
    暫存 = StringIO(newline="")
    寫入器 = csv.writer(暫存)
    寫入器.writerow(固定欄位)
    寫入器.writerow(["、".join(map(str, 值)) if isinstance(值, list) else 值
                                 for 值 in (欄位.get(欄, "") for 欄 in 固定欄位)])
    目錄 = Path("_工作") / "紀錄"
    目錄.mkdir(parents=True, exist_ok=True)
    名稱 = f"{檔名}_{datetime.now():%Y%m%d_%H%M%S_%f}"
    序號 = 1
    while True:
        路徑 = 目錄 / f"{名稱}{'_' + str(序號) if 序號 > 1 else ''}.csv"
        try:
            with 路徑.open("xb") as 檔案:
                檔案.write(暫存.getvalue().encode("utf-8-sig"))
            break
        except FileExistsError:
            序號 += 1
    with 路徑.open(encoding="utf-8-sig", newline="") as 檔案:
        讀回 = list(csv.reader(檔案, strict=True))
    if len(讀回) != 2 or 讀回[0] != 固定欄位:
        raise ValueError("寫回檢查失敗：筆數或欄位不符")
    return 路徑.as_posix()


def 記錄任務(**欄位):
    """記錄任務並回傳新檔路徑。"""
    return _記錄("任務", _任務欄位, 欄位)


def _遮錯誤文字(文字):
    文字 = re.sub(r'''(?:'(?:\\.|[^'\\])*'|"(?:\\.|[^"\\])*"|「[^」]*」)''', "'…'", str(文字))
    return re.sub(r"\S*[\\/]\S*", "<路徑>", 文字)


def 記錄錯誤(**欄位):
    """記錄錯誤並回傳新檔路徑。"""
    未知 = set(欄位) - set(_錯誤欄位)
    if 未知:
        raise ValueError(f"不認得的欄名：{'、'.join(sorted(未知))}")
    if "原因分類" in 欄位 and 欄位["原因分類"] not in ("工具限制", "程式寫錯", "資料有問題", "規定擋下", "其他"):
        raise ValueError("原因分類不合法")
    if "錯誤原文" in 欄位:
        原文 = _遮錯誤文字(欄位["錯誤原文"])
        欄位["錯誤原文"] = (原文.splitlines() or [""])[0][:200]
    return _記錄("錯誤", _錯誤欄位, 欄位)


_對話環境變數 = ()
if "_手動工作代號" not in globals():
    _手動工作代號 = None


def 工作代號(名稱):
    """設定本次執行的工作代號；最後一次設定生效。"""
    global _手動工作代號
    if not isinstance(名稱, str) or any(字 in 名稱 for 字 in "\r\n\v\f\x1c\x1d\x1e\x85\u2028\u2029"):
        raise ValueError("工作代號必須是不可換行的文字")
    名稱 = 名稱.strip()
    if not 名稱 or len(名稱) > 40:
        raise ValueError("工作代號須為 1 至 40 字")
    _手動工作代號 = 名稱


if "_預期成果" not in globals():
    _預期成果 = {}
    _曾登記成果 = False


def 預期產出(*路徑):
    """登記結束時要核對的成果檔案，可多次呼叫。"""
    global _曾登記成果
    _曾登記成果 = True
    for 項 in 路徑:
        檔 = Path(項).absolute()
        _預期成果.setdefault(os.path.normcase(os.path.normpath(str(檔))), 檔)


def _核對成果():
    if not _曾登記成果:
        return ""
    缺少, 空的 = [], []

    def 顯示(檔):
        try:
            return 檔.relative_to(Path.cwd()).as_posix()
        except ValueError:
            return str(檔)

    for 檔 in _預期成果.values():
        if not 檔.is_file():
            缺少.append(顯示(檔))
        elif 檔.stat().st_size == 0:
            空的.append(顯示(檔))
    if 缺少 or 空的:
        說明 = "；".join((["缺少 " + "、".join(缺少)] if 缺少 else []) +
                      (["是空的 " + "、".join(空的)] if 空的 else []))
        print(f"!! 成果核對：{說明}（這次的成果不完整，不要回報做完）")
    else:
        print(f"成果核對：{len(_預期成果)} 個檔都在")
    return str(len(缺少) + len(空的))


def _目前工作代號():
    if _手動工作代號 is not None:
        return _手動工作代號
    名稱們 = _倉庫狀態["開過"] | _倉庫狀態["存過"]
    if 名稱們:
        return "、".join(sorted(名稱們))
    for 名稱 in _對話環境變數:
        if 名稱 in os.environ:
            return "對話" + hashlib.sha256(os.environ[名稱].encode("utf-8")).hexdigest()[:6]
    return ""


# reload 沿用首次匯入的工作目錄、開倉結果及結束處理器。
if "_倉庫狀態" not in globals():
    _倉庫狀態 = {"根": Path.cwd() / "_工作" / "倉庫", "帶入": set(), "開過": set(), "存過": set(), "失敗": set(), "啟用": False}


def _倉庫訊息(文字):
    try:
        print(" ".join(文字.splitlines()))
    except BaseException:
        pass


def _開倉庫():
    狀態 = _倉庫狀態
    根 = 狀態["根"]
    if not 根.exists():
        return
    for 箱 in sorted(根.glob("*.zip")):
        名稱 = 箱.stem
        狀態["帶入"].add(名稱)
        try:
            with zipfile.ZipFile(箱) as 壓縮檔:
                項目 = 壓縮檔.infolist()
                if (根 / 名稱).is_symlink():
                    raise ValueError("倉庫資料夾不能是符號連結")
                for 項 in 項目:
                    名 = 項.filename.replace("\\", "/")
                    if (not 名 or 名.startswith("/") or ntpath.splitdrive(名)[0] or
                            ".." in 名.split("/") or (項.external_attr >> 16) & 0o170000 == 0o120000):
                        raise ValueError("壓縮檔含不安全路徑")
                    目的 = (根 / 名稱 / 名).resolve()
                    if not 目的.is_relative_to((根 / 名稱).resolve()):
                        raise ValueError("壓縮檔含不安全路徑")
                if 壓縮檔.testzip() is not None:
                    raise ValueError("壓縮檔內容損壞")
                目錄 = 根 / 名稱
                目錄.mkdir(parents=True, exist_ok=True)
                for 項 in 項目:
                    目的 = 目錄.joinpath(*項.filename.replace("\\", "/").split("/"))
                    if 項.is_dir():
                        目的.mkdir(parents=True, exist_ok=True)
                    else:
                        目的.parent.mkdir(parents=True, exist_ok=True)
                        with 壓縮檔.open(項) as 來源, 目的.open("wb") as 輸出:
                            shutil.copyfileobj(來源, 輸出)
                狀態["開過"].add(名稱)
                _倉庫訊息(f"倉庫「{名稱}」已打開：{sum(not 項.is_dir() for 項 in 項目)} 個檔")
        except BaseException as 錯誤:
            狀態["失敗"].add(名稱)
            _倉庫訊息(f"倉庫「{名稱}」打開失敗：{type(錯誤).__name__}：{錯誤}")


def _倉庫相同(箱, 目錄, 檔們):
    try:
        with zipfile.ZipFile(箱) as 壓縮檔:
            項目 = [項 for 項 in 壓縮檔.infolist() if not 項.is_dir()]
            if len(項目) != len(檔們) or {項.filename for 項 in 項目} != {檔.relative_to(目錄).as_posix() for 檔 in 檔們}:
                return False
            for 檔 in 檔們:
                with 檔.open("rb") as 來源, 壓縮檔.open(檔.relative_to(目錄).as_posix()) as 舊檔:
                    while True:
                        片 = 來源.read(1024 * 1024)
                        if 片 != 舊檔.read(1024 * 1024):
                            return False
                        if not 片:
                            break
            return True
    except (OSError, zipfile.BadZipFile, KeyError, RuntimeError, EOFError):
        return False


def _存倉庫(名稱=None, 結束=False):
    狀態 = _倉庫狀態
    根 = 狀態["根"]
    if 名稱 is not None and (not isinstance(名稱, str) or not 名稱 or 名稱 in (".", "..") or
                           "/" in 名稱 or "\\" in 名稱 or ntpath.splitdrive(名稱)[0]):
        raise ValueError("倉庫名稱必須是單一資料夾名稱")
    if not 根.exists():
        return
    for 目錄 in sorted(根.iterdir()):
        if not 目錄.is_dir() or 目錄.is_symlink() or (名稱 is not None and 目錄.name != 名稱):
            continue
        名 = 目錄.name
        try:
            if 名 in 狀態["失敗"]:
                raise ValueError("原壓縮檔開啟失敗，保留原檔及資料夾")
            項目 = list(目錄.rglob("*"))
            if any(p.is_symlink() for p in 項目):
                raise ValueError("倉庫不能包含符號連結")
            檔們 = sorted(p for p in 項目 if p.is_file())
            if not 檔們 and 名 not in 狀態["開過"] and 名 not in 狀態["存過"]:
                continue
            箱 = 根 / (名 + ".zip")
            if not (箱.is_file() and _倉庫相同(箱, 目錄, 檔們)):
                暫存 = None
                try:
                    with tempfile.NamedTemporaryFile(dir=根, suffix=".tmp", delete=False) as 檔:
                        暫存 = Path(檔.name)
                    with zipfile.ZipFile(暫存, "w", compression=zipfile.ZIP_DEFLATED) as 壓縮檔:
                        for 檔 in 檔們:
                            壓縮檔.write(檔, 檔.relative_to(目錄).as_posix())
                    os.replace(暫存, 箱)
                finally:
                    if 暫存 is not None:
                        暫存.unlink(missing_ok=True)
            狀態["存過"].add(名)
            路徑 = f"_工作/倉庫/{名}.zip"
            大小 = 箱.stat().st_size
            if 大小 < 50 * 1024**2:
                _倉庫訊息(f"倉庫「{名}」：{len(檔們)} 個檔、{大小 / 1024**2:.1f} MB。下次請在 input_files 加上 {路徑}")
            if 名 not in 狀態["帶入"]:
                _倉庫訊息(f"這次沒帶舊箱子；如果工作區已經有 {路徑}，帶回會被拒絕，請把它加進 input_files 重跑")
            if 大小 >= 50 * 1024**2:
                _倉庫訊息(f"倉庫「{名}」已經 {大小 / 1024**2:.1f} MB，超過帶入上限 50 MB，下次帶不進隔離區。"
                         "要繼續就改請使用者在自己電腦執行（寫一個 .cmd 給使用者雙擊），"
                         "以後同類工作從一開始就把不同步驟的檔分到不同倉庫")
            elif 大小 > 40 * 1024**2:
                _倉庫訊息(f"倉庫「{名}」已經 {大小 / 1024**2:.1f} MB，快到帶入上限 50 MB（還要加上同一次帶的其他檔）。"
                         f"下一步之前請：刪掉之後用不到的檔、xlsx 中間檔改存 csv，"
                         f"或把不同步驟的檔分到不同倉庫（例如「{名}_清理」「{名}_合併」），每次只帶要用的那個")
            if 結束:
                shutil.rmtree(目錄)
        except BaseException as 錯誤:
            _倉庫訊息(f"倉庫「{名}」儲存失敗：{type(錯誤).__name__}：{錯誤}")


def 存倉庫(名稱=None):
    """立即存指定倉庫；名稱為 None 時存全部，資料夾保留供後續使用。"""
    try:
        _存倉庫(名稱)
    except BaseException as 錯誤:
        _倉庫訊息(f"倉庫儲存失敗：{type(錯誤).__name__}：{錯誤}")


def _結束存倉庫():
    try:
        _存倉庫(結束=True)
    except BaseException as 錯誤:
        _倉庫訊息(f"倉庫儲存失敗：{type(錯誤).__name__}：{錯誤}")


def _啟用倉庫():
    if _倉庫狀態["啟用"]:
        return
    _倉庫狀態["啟用"] = True
    atexit.register(_結束存倉庫)
    _開倉庫()


__all__ = ["讀表", "寫表", "寫多表", "轉數字", "轉數字欄", "備份", "寫雙擊檔",
           "分組加總", "前幾名", "比對清單", "打包成壓縮檔", "記錄任務", "記錄錯誤",
           "看檔", "寫文字", "寫JSON", "讀Word表格", "讀文件文字", "找相似",
           "轉日期", "轉日期欄", "轉民國", "比對文字", "合併多檔", "安全檔名", "依欄拆分", "存倉庫", "工作代號", "預期產出", "版本"]


def _掃描打卡檔案(根):
    """最多保留 5000 個檔的大小和修改時間，不讀取檔案內容。"""
    檔案 = {}
    for 目錄, 子目錄, 檔名們 in os.walk(根):
        相對目錄 = Path(目錄).relative_to(根)
        子目錄[:] = [名 for 名 in 子目錄 if 名 not in ("_spaid_system", "__pycache__")
                   and not (相對目錄 == Path("_工作") and 名 == "紀錄")]
        for 名 in 檔名們:
            if 名.startswith("_spaid_"):
                continue
            路徑 = Path(目錄) / 名
            try:
                if not 路徑.is_file():
                    continue
                資訊 = 路徑.stat()
            except OSError:
                continue
            if len(檔案) == 5000:
                return 檔案, True
            檔案[路徑.relative_to(根)] = (資訊.st_size, 資訊.st_mtime_ns)
    return 檔案, False


def _打卡檔案摘要(檔案, 超過):
    if 超過:
        return "5000 個以上"
    數量 = {}
    for 路徑 in 檔案:
        副檔名 = 路徑.suffix[1:].lower() or "無副檔名"
        數量[副檔名] = 數量.get(副檔名, 0) + 1
    if not 數量:
        return "0 個"
    明細 = "、".join(f"{名} {數}" for 名, 數 in sorted(數量.items(), key=lambda 項: (-項[1], 項[0])))
    return f"{len(檔案)} 個（{明細}）"


def _啟用打卡(記錄=True):
    """啟用執行紀錄；sys.exit 被接住後仍會保留最後一次的結束碼。"""
    # reload 會保留模組字典，沿用原先的狀態與結束處理器。
    global _打卡狀態
    if "_打卡狀態" not in globals():
        開始 = datetime.now()
        欄位 = ["開始", "結束", "秒數", "狀態", "程式", "用到的函式", "錯誤類型", "錯誤第一行", "工作代號", "成果缺少", "常用工具版本", "帶入檔", "產出檔"]
        入口 = sys.argv[0] if sys.argv and isinstance(sys.argv[0], str) else ""
        程式 = Path(入口.replace("\\", "/")).name if 入口 else ""
        if 程式 == "_spaid_command.py":
            程式 = "command"
        資料 = dict.fromkeys(欄位, "")
        資料.update(開始=開始.strftime("%Y-%m-%d %H:%M:%S"), 狀態="執行中", 程式=程式, 工作代號=_目前工作代號(), 常用工具版本=版本)
        根 = Path.cwd()
        隔離區 = 記錄 and any((根 / 名).is_file() for 名 in ("_spaid_guarded_runner.py", "_spaid_command.py"))
        帶入 = None
        if 隔離區:
            try:
                帶入, 超過 = _掃描打卡檔案(根)
                資料["帶入檔"] = _打卡檔案摘要(帶入, 超過)
            except OSError:
                pass
        狀態 = {"資料": 資料, "欄位": 欄位, "統計": {}, "區域": threading.local(),
              "鎖": threading.Lock(), "起點": _時間模組.perf_counter(), "結束碼": None}
        _打卡狀態 = 狀態
        try:
            路徑 = _記錄("執行", 欄位, dict(資料)) if 記錄 else None
            狀態["路徑"] = Path(路徑).absolute() if 路徑 else None
        except Exception:
            狀態["路徑"] = None

        def 記下錯誤(類型, 例外):
            資料["狀態"] = "出錯"
            資料["錯誤類型"] = 類型.__name__
            資料["錯誤第一行"] = (_遮錯誤文字(例外).splitlines() or [""])[0][:200]

        原hook = sys.excepthook
        def hook(類型, 例外, 回溯):
            try:
                記下錯誤(類型, 例外)
            except BaseException:
                pass
            原hook(類型, 例外, 回溯)
        sys.excepthook = hook

        原exit = sys.exit
        def exit(碼=None):
            try:
                if threading.current_thread() is threading.main_thread():
                    狀態["結束碼"] = 碼
            except BaseException:
                pass
            return 原exit(碼)
        sys.exit = exit

        def 結束():
            try:
                資料["成果缺少"] = _核對成果()
            except BaseException as 錯誤:
                資料["成果缺少"] = "核對失敗"
                try:
                    print(f"!! 成果核對失敗：{(str(錯誤).splitlines() or [type(錯誤).__name__])[0]}")
                except BaseException:
                    pass
            if _倉庫狀態["啟用"]:
                _結束存倉庫()
            try:
                if 帶入 is not None:
                    結束檔案, 超過 = _掃描打卡檔案(根)
                    產出 = {路徑: 資訊 for 路徑, 資訊 in 結束檔案.items() if 帶入.get(路徑) != 資訊}
                    資料["產出檔"] = _打卡檔案摘要(產出, 超過)
            except OSError:
                pass
            try:
                資料["工作代號"] = _目前工作代號()
                資料["結束"] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                資料["秒數"] = f"{_時間模組.perf_counter() - 狀態['起點']:.2f}"
                if 資料["狀態"] != "出錯":
                    例外 = getattr(sys, "last_exc", None)
                    if 例外 is None:
                        例外 = getattr(sys, "last_value", None)
                    if 例外 is not None:
                        記下錯誤(type(例外), 例外)
                if 資料["狀態"] != "出錯":
                    碼 = 狀態["結束碼"]
                    if 碼 is None or 碼 == 0:
                        資料["狀態"] = "完成"
                    elif isinstance(碼, str):
                        資料["狀態"] = f"中途結束({_遮錯誤文字(碼)[:50]})"
                    else:
                        資料["狀態"] = f"中途結束(結束碼 {碼})"
                if _曾登記成果 and 資料["狀態"] != "完成":
                    print("程式沒有正常結束，成果可能是半成品，要重跑")
                if 狀態["路徑"] is None:
                    return
                with 狀態["鎖"]:
                    資料["用到的函式"] = "、".join(
                        f"{名}×{次} {秒:.2f}秒" for 名, (次, 秒) in 狀態["統計"].items())
                暫存路徑 = None
                try:
                    with tempfile.NamedTemporaryFile(mode="w", encoding="utf-8-sig", newline="",
                                                     dir=狀態["路徑"].parent, delete=False) as 檔案:
                        暫存路徑 = Path(檔案.name)
                        寫入器 = csv.DictWriter(檔案, fieldnames=欄位)
                        寫入器.writeheader()
                        寫入器.writerow(資料)
                    with 暫存路徑.open(encoding="utf-8-sig", newline="") as 檔案:
                        if list(csv.DictReader(檔案, strict=True)) != [資料]:
                            raise ValueError("寫回檢查失敗")
                    os.replace(暫存路徑, 狀態["路徑"])
                finally:
                    if 暫存路徑 is not None:
                        暫存路徑.unlink(missing_ok=True)
            except BaseException:
                pass
        if _倉庫狀態["啟用"]:
            atexit.unregister(_結束存倉庫)
        atexit.register(結束)

    狀態 = _打卡狀態
    def 包裝(函式):
        @functools.wraps(函式)
        def 計時(*參數, **關鍵字):
            try:
                區域 = 狀態["區域"]
                深度 = getattr(區域, "深度", 0)
                起點 = _時間模組.perf_counter() if 深度 == 0 else 0
                區域.深度 = 深度 + 1
            except BaseException:
                return 函式(*參數, **關鍵字)
            try:
                return 函式(*參數, **關鍵字)
            finally:
                try:
                    區域.深度 = 深度
                    if 深度 == 0:
                        經過 = _時間模組.perf_counter() - 起點
                        with 狀態["鎖"]:
                            次, 秒 = 狀態["統計"].get(函式.__name__, (0, 0))
                            狀態["統計"][函式.__name__] = (次 + 1, 秒 + 經過)
                except BaseException:
                    pass
        return 計時
    for 名稱 in __all__:
        if 名稱 != "版本" and 記錄:
            globals()[名稱] = 包裝(globals()[名稱])


try:
    _多行程 = sys.modules.get("multiprocessing")
    if (os.environ.get("常用工具_不開倉庫") != "1" and
            threading.current_thread() is threading.main_thread() and
            (_多行程 is None or
             (_多行程.parent_process() is None and
              not getattr(_多行程.current_process(), "_inheriting", False)))):
        _啟用倉庫()
except BaseException as _錯誤:
    _倉庫訊息(f"倉庫啟用失敗：{type(_錯誤).__name__}：{_錯誤}")

try:
    _多行程 = sys.modules.get("multiprocessing")
    if (threading.current_thread() is threading.main_thread() and
            (_多行程 is None or
             (_多行程.parent_process() is None and
              not getattr(_多行程.current_process(), "_inheriting", False)))):
        _啟用打卡(os.environ.get("常用工具_不打卡") != "1")
except BaseException:
    pass
