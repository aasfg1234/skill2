import argparse
import datetime
import json
import os
from pathlib import Path, PureWindowsPath
import queue
import shutil
import subprocess
import sys
import threading
import time


def 產生cmd(路徑):
    內容 = '''@echo off
chcp 65001 >nul
cd /d "%~dp0"
where python >nul 2>nul
if errorlevel 1 (
    echo 找不到 Python，請安裝 Python 3.13 並讓命令列可以執行 python。
    pause
    exit /b 1
)
python -B "%~dp0本機執行.py"
pause
'''
    路徑.write_bytes(內容.replace('\n', '\r\n').encode('utf-8'))


def 不重複路徑(資料夾, 名稱):
    原路徑 = 資料夾 / 名稱
    路徑 = 原路徑
    序號 = 1
    while 路徑.exists():
        路徑 = 原路徑.with_name(f'{原路徑.stem}_{序號}{原路徑.suffix}')
        序號 += 1
    return 路徑


def 搬移(工作單, 資料夾):
    資料夾.mkdir(parents=True, exist_ok=True)
    shutil.move(str(工作單), str(不重複路徑(資料夾, 工作單.name)))


def 檢查(工作單, 工作區):
    with 工作單.open(encoding='utf-8-sig') as f:
        資料 = json.load(f)
    if not isinstance(資料, dict):
        raise ValueError('工作單必須是 JSON 物件')
    腳本 = 資料.get('腳本')
    if not isinstance(腳本, str) or not 腳本:
        raise ValueError('腳本必須是路徑字串')
    if Path(腳本).is_absolute() or PureWindowsPath(腳本).is_absolute() or PureWindowsPath(腳本).drive:
        raise ValueError('腳本必須使用工作區內的相對路徑')
    路徑 = (工作區 / 腳本).resolve()
    if not 路徑.is_relative_to((工作區 / '_工作').resolve()):
        raise ValueError('腳本必須在 _工作 資料夾內')
    if 路徑.suffix.lower() != '.py' or not 路徑.is_file():
        raise ValueError('腳本必須是存在的 .py 檔案')
    參數 = 資料.get('參數', [])
    if not isinstance(參數, list) or any(not isinstance(x, str) for x in 參數):
        raise ValueError('參數必須是字串清單')
    if any('\x00' in x for x in 參數):
        raise ValueError('參數不能包含 NUL 字元')
    if not isinstance(資料.get('說明'), str):
        raise ValueError('說明必須是字串')
    return 資料, 路徑, 參數


def 執行(工作單, 工作區, 腳本, 參數, 心跳秒):
    結果夾 = 工作區 / '_工作' / '本機' / '結果'
    結果夾.mkdir(parents=True, exist_ok=True)
    開始 = datetime.datetime.now()
    基名 = f'{工作單.stem}_{開始:%Y%m%d_%H%M%S}'
    結果檔 = 不重複路徑(結果夾, 基名 + '.txt')
    while 結果檔.with_suffix('.json').exists():
        基名 += '_1'
        結果檔 = 不重複路徑(結果夾, 基名 + '.txt')
    環境 = os.environ.copy()
    環境['PYTHONIOENCODING'] = 'utf-8'
    環境['PYTHONDONTWRITEBYTECODE'] = '1'
    佇列 = queue.Queue()
    子程式 = None
    狀態 = '失敗'
    結束碼 = None
    開始計時 = time.monotonic()
    with 結果檔.open('x', encoding='utf-8', newline='') as 紀錄:
        def 印心跳():
            訊息 = f'還在跑，已經 {int((time.monotonic() - 開始計時) / 60)} 分鐘\n'
            print(訊息, end='', flush=True)
            紀錄.write(訊息)
            紀錄.flush()
        try:
            子程式 = subprocess.Popen([sys.executable, '-u', str(腳本), *參數], cwd=工作區,
                                   env=環境, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                                   text=True, encoding='utf-8', errors='replace', bufsize=1)
            def 讀取():
                try:
                    with 子程式.stdout as 輸出:
                        for 行 in 輸出:
                            佇列.put(行)
                finally:
                    佇列.put(None)
            threading.Thread(target=讀取, daemon=True).start()
            while True:
                try:
                    行 = 佇列.get(timeout=心跳秒)
                except queue.Empty:
                    印心跳()
                    continue
                if 行 is None:
                    break
                print(行, end='', flush=True)
                紀錄.write(行)
                紀錄.flush()
            while True:
                try:
                    結束碼 = 子程式.wait(timeout=心跳秒)
                    break
                except subprocess.TimeoutExpired:
                    印心跳()
            狀態 = '成功' if 結束碼 == 0 else '失敗'
        except KeyboardInterrupt:
            狀態 = '中斷'
            if 子程式 is not None:
                子程式.terminate()
                try:
                    子程式.wait(timeout=5)
                except subprocess.TimeoutExpired:
                    子程式.kill()
                    子程式.wait()
                結束碼 = 子程式.returncode
        except OSError as exc:
            print(f'無法啟動工作：{exc}', flush=True)
            紀錄.write(f'無法啟動工作：{exc}\n')
    結束 = datetime.datetime.now()
    資料 = {'開始': 開始.isoformat(timespec='seconds'), '結束': 結束.isoformat(timespec='seconds'),
          '秒數': round(time.monotonic() - 開始計時, 3), '結束碼': 結束碼,
          '狀態': 狀態, '結果檔路徑': str(結果檔)}
    結果檔.with_suffix('.json').write_text(json.dumps(資料, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    搬移(工作單, 工作區 / '_工作' / '本機' / '已完成')
    if 狀態 == '成功':
        print('\n跑完了。請回 AI 說：本機跑完了', flush=True)
    elif 狀態 == '中斷':
        print('\n工作已中斷。請回 AI 說：本機執行中斷了', flush=True)
    else:
        print(f'\n失敗了（結束碼 {結束碼}）。請回 AI 說：本機跑失敗了', flush=True)
    return 狀態


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--工作區', type=Path, default=Path(__file__).resolve().parent.parent.parent)
    parser.add_argument('--不問', action='store_true')
    parser.add_argument('--心跳秒', type=float, default=60)
    parser.add_argument('--產生cmd', type=Path)
    args = parser.parse_args()
    if args.產生cmd:
        產生cmd(args.產生cmd)
        return
    if args.心跳秒 <= 0:
        parser.error('--心跳秒必須大於零')
    工作區 = args.工作區.resolve()
    本機 = 工作區 / '_工作' / '本機'
    工作單們 = sorted(p for p in 本機.glob('工作單*.json') if p.is_file())
    if not 工作單們:
        print('沒有要跑的工作。請先請 AI 準備工作單')
        return
    for 工作單 in 工作單們:
        try:
            資料, 腳本, 參數 = 檢查(工作單, 工作區)
        except (OSError, UnicodeError, ValueError) as exc:
            print(f'{工作單.name} 有問題：{exc}', flush=True)
            搬移(工作單, 本機 / '有問題')
            continue
        print(f"說明：{資料['說明']}\n腳本：{資料['腳本']}\n參數：{json.dumps(參數, ensure_ascii=False)}\n預計時間：{資料.get('預計分鐘', '未提供')} 分鐘", flush=True)
        if not args.不問 and input('按 Enter 開始，輸入 n 取消：').strip().lower() == 'n':
            print('已取消，工作單保留。')
            continue
        if 執行(工作單, 工作區, 腳本, 參數, args.心跳秒) == '中斷':
            break


if __name__ == '__main__':
    try:
        main()
    except KeyboardInterrupt:
        print('\n已取消。')
    except OSError as exc:
        print(f'無法處理工作：{exc}')
        sys.exit(1)
