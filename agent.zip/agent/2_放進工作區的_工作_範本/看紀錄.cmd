@echo off
chcp 65001 >nul
cd /d "%~dp0"
where python >nul 2>nul
if errorlevel 1 (
    echo 找不到 Python，請安裝 Python 3.13 並讓命令列可以執行 python。
    pause
    exit /b 1
)
python -B "%~dp0看紀錄.py"
if errorlevel 1 pause
