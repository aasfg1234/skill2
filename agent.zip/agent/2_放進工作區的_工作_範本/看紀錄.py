import argparse
import ast
import datetime
import json
import os
from pathlib import Path
import re
import tempfile
import zipfile


種類 = ("執行_", "任務_", "錯誤_")
檔名格式 = re.compile(r"^(?:執行|任務|錯誤)_(\d{8})_(\d{6})_\d{6}(?:_\d+)?\.csv$")
封存格式 = re.compile(r"^紀錄_封存_\d{4}-\d{2}\.zip$")


def 小檔清單(資料夾):
    return sorted(p for p in 資料夾.iterdir() if p.is_file() and p.name.startswith(種類) and p.suffix.lower() == '.csv')


def 封存(資料夾, 今天=None):
    今天 = 今天 or datetime.date.today()
    分月 = {}
    for 路徑 in 小檔清單(資料夾):
        match = 檔名格式.fullmatch(路徑.name)
        if not match:
            continue
        try:
            日期 = datetime.datetime.strptime(match.group(1), '%Y%m%d').date()
            時間 = match.group(2)
            datetime.time(int(時間[:2]), int(時間[2:4]), int(時間[4:]))
        except ValueError:
            continue
        if 日期 < 今天.replace(day=1):
            分月.setdefault(日期.strftime('%Y-%m'), []).append(路徑)
    for 月份, 檔案 in sorted(分月.items()):
        目標 = 資料夾 / f'紀錄_封存_{月份}.zip'
        暫存 = None
        try:
            舊內容 = []
            if 目標.exists():
                with zipfile.ZipFile(目標, 'r') as z:
                    舊內容 = [(info, z.read(info)) for info in z.infolist()]
            已有 = {}
            for info, data in 舊內容:
                已有.setdefault(info.filename, []).append(data)
            新增 = []
            對照 = []
            for 路徑 in 檔案:
                data = 路徑.read_bytes()
                名稱 = 路徑.name
                n = 1
                while 名稱 in 已有 and data not in 已有[名稱]:
                    名稱 = f'{路徑.stem}_重複{n}{路徑.suffix}'
                    n += 1
                if 名稱 not in 已有:
                    新增.append((名稱, data))
                    已有[名稱] = [data]
                對照.append((路徑, 名稱, data))
            if 新增 or not 目標.exists():
                with tempfile.NamedTemporaryFile(dir=資料夾, suffix='.tmp', delete=False) as f:
                    暫存 = Path(f.name)
                with zipfile.ZipFile(暫存, 'w', compression=zipfile.ZIP_DEFLATED) as z:
                    for info, data in 舊內容:
                        z.writestr(info, data)
                    for 名稱, data in 新增:
                        z.writestr(名稱, data)
                os.replace(暫存, 目標)
                暫存 = None
            with zipfile.ZipFile(目標, 'r') as z:
                for 路徑, 名稱, data in 對照:
                    if z.read(名稱) != data:
                        raise ValueError(f'封存內容不一致：{名稱}')
            for 路徑, 名稱, data in 對照:
                try:
                    if 路徑.read_bytes() != data:
                        raise ValueError('原檔內容已變更')
                    路徑.unlink()
                except (OSError, ValueError) as exc:
                    print(f'無法刪除 {路徑.name}：{exc}')
        except Exception as exc:
            print(f'無法封存 {月份}：{exc}；保留原始檔')
        finally:
            if 暫存 is not None:
                try:
                    暫存.unlink(missing_ok=True)
                except OSError:
                    pass


def 讀紀錄(資料夾):
    結果 = []
    封存數 = 0
    for 路徑 in sorted(資料夾.iterdir()):
        if 路徑.is_file() and 封存格式.fullmatch(路徑.name):
            try:
                with zipfile.ZipFile(路徑) as z:
                    項目 = [{'name': info.filename, 'text': z.read(info).decode('utf-8-sig')}
                          for info in z.infolist() if not info.is_dir() and info.filename.lower().endswith('.csv')]
                結果.extend(項目)
                封存數 += len(項目)
            except Exception as exc:
                print(f'無法讀取封存檔 {路徑.name}：{exc}')
    for 路徑 in 小檔清單(資料夾):
        with 路徑.open(encoding='utf-8-sig', newline='') as f:
            結果.append({'name': 路徑.name, 'text': f.read()})
    return 結果, 封存數


def main():
    位置 = Path(__file__).resolve().parent
    parser = argparse.ArgumentParser(description='將紀錄載入儀表板')
    parser.add_argument('--紀錄', type=Path, default=位置.parent / '紀錄')
    parser.add_argument('--儀表板', type=Path, default=位置 / '紀錄儀表板.html')
    parser.add_argument('--輸出', type=Path)
    parser.add_argument('--常用工具', type=Path, default=位置 / '常用工具.py')
    parser.add_argument('--不開', action='store_true')
    parser.add_argument('--不封存', action='store_true')
    args = parser.parse_args()
    輸出 = args.輸出 or args.紀錄.parent / '紀錄儀表板_最新.html'
    if not args.儀表板.is_file():
        print(f'找不到儀表板網頁：{args.儀表板}')
        print('看紀錄.cmd 要跟 紀錄儀表板.html、常用工具.py 放在同一個資料夾（Spade 工作區的 _工作\\範本\\），紀錄在旁邊的 _工作\\紀錄\\。')
        if (位置.parent / '紀錄儀表板' / '紀錄儀表板.html').is_file():
            print('這裡是原始檔資料夾，不是用來看紀錄的：請把這四個檔複製到 _工作\\範本\\ 再雙擊那裡的 看紀錄.cmd。')
        raise SystemExit(1)
    if args.紀錄.is_dir():
        if not args.不封存:
            封存(args.紀錄)
        紀錄, 封存數 = 讀紀錄(args.紀錄)
        if not 紀錄:
            print('紀錄資料夾目前沒有紀錄。')
    elif not args.紀錄.exists():
        print(f'找不到紀錄資料夾：{args.紀錄}（還沒有任何紀錄，或 看紀錄.cmd 沒有放在 _工作\\範本\\）。先產生空的儀表板。')
        紀錄, 封存數 = [], 0
    else:
        raise NotADirectoryError(f'紀錄路徑不是資料夾：{args.紀錄}')
    html = args.儀表板.read_text(encoding='utf-8-sig')
    if '</body>' not in html:
        raise ValueError('儀表板找不到 </body>')
    資料 = {'產生時間': datetime.datetime.now().isoformat(timespec='seconds'), '檔案': 紀錄}
    try:
        tree = ast.parse(args.常用工具.read_text(encoding='utf-8-sig'))
        資料['全部函式'] = [node.name for node in tree.body if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)) and not node.name.startswith('_')]
    except (OSError, UnicodeError, SyntaxError, ValueError) as exc:
        print(f'無法讀取常用工具函式清單：{exc}；仍會產生儀表板。')
    payload = json.dumps(資料, ensure_ascii=False).replace('</', '<\\/')
    html = html.replace('</body>', f'<script id="內建紀錄" type="application/json">{payload}</script>\n</body>', 1)
    暫存 = None
    try:
        if args.輸出 is None:
            輸出.parent.mkdir(parents=True, exist_ok=True)
        with tempfile.NamedTemporaryFile(mode='w', encoding='utf-8', newline='', dir=輸出.parent, suffix='.tmp', delete=False) as f:
            暫存 = Path(f.name)
            f.write(html)
        os.replace(暫存, 輸出)
        暫存 = None
    finally:
        if 暫存 is not None:
            暫存.unlink(missing_ok=True)
    print(f'讀了 {len(紀錄)} 個紀錄（其中 {封存數} 個在封存檔）')
    if not args.不開:
        os.startfile(str(輸出))


if __name__ == '__main__':
    try:
        main()
    except (OSError, ValueError, UnicodeError) as exc:
        print(f'無法產生儀表板：{exc}')
        raise SystemExit(1)
