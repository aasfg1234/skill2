"""分段執行範本（Python 3.13，僅用標準函式庫）

複製本檔到 _工作/任務/<任務名>.py，只修改下方設定及三個函式。
第一次以 script 參數執行該檔，timeout_secs 設 900，input_files 帶入 INPUT_FILES 所列原始資料；
之後每次再加上進度包，路徑保持一致。每次呼叫都是新的空目錄。
看輸出：有「還沒做完」就把它下面列的檔照抄成 input_files、args 加 --續跑 再執行；有「全部做完」就結束。
改了 do_item、list_items 的邏輯或設定後，舊進度包不能沿用：刪掉進度包或改 TASK_NAME。
原始輸入檔加進度包超過 10 個時，先把原始輸入打包成一個 zip 再用。
結果只用 JSON 的型別（dict 的鍵用文字、用 list 不用 tuple）。
POOL 設為 thread 適合主要在等的工作，設為 process 適合主要在算的工作。
工作項目及結果須可轉 JSON；清單順序與內容每次必須一致。
時間只在兩項工作之間檢查：每一項要切到幾秒內做完（一項很久就拆成多項）。
行程池到時間會停止尚未收妥的項目；執行緒池會等執行中的項目做完，可能超過時間預算。
並行工作中已收妥的任何項目出錯都會回報；進度包只保存依序連續完成的結果。
do_item 不應依賴無法重做的外部副作用。finish 應可重複執行。
產出寫在 _工作/任務/<任務名>/ 或使用者指定的 ws/ 底下，不要寫在最上層（會被帶回工作區變成雜物）。
範例讀取 CSV，逐行計算欄位數；請依任務修改設定及三個函式。
"""

import concurrent.futures
import csv
import hashlib
import json
import os
from pathlib import Path
import sys
import tempfile
import time
import zipfile

# 設定：INPUT_FILES 寫工作區的相對路徑（例如 ws/資料夾/資料.csv），跟 input_files 帶入的一樣。
TASK_NAME = "欄位統計"
PROGRESS_PATH = "_工作/任務/欄位統計/進度包.zip"
INPUT_FILES = ["ws/範例/資料.csv"]
TIME_BUDGET = 750
SAVE_INTERVAL = 30
WORKERS = 1
POOL = "process"  # "thread"＝主要在等（網路、慢函式），"process"＝主要在算


def list_items():
    """回傳順序固定的全部工作項目；內容變更時指紋也應跟著改變。"""
    with open(INPUT_FILES[0], encoding="utf-8-sig", newline="") as source:
        return list(csv.reader(source))


def do_item(item):
    """處理一項，回傳可轉 JSON 的結果。"""
    return {"欄位數": len(item)}


def finish(results):
    """所有結果依原順序傳入；在此寫入最終產出。"""
    output = Path("_工作/任務/欄位統計/欄位統計.json")
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(results, ensure_ascii=False, indent=2), encoding="utf-8")
    return str(output)


def _json(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False)


def _load(path, total, fingerprint):
    if not path.exists():
        return [], []
    with zipfile.ZipFile(path) as archive:
        state = json.loads(archive.read("state.json"))
        if (state["任務名"] != TASK_NAME or state["總數"] != total
                or state["清單指紋"] != fingerprint):
            raise ValueError("工作項目清單或任務名與進度包不一致，請確認原始資料；不會繼續執行。")
        segments = []
        results = []
        for name in state["結果分段檔"]:
            data = archive.read(name)
            part = json.loads(data)
            if not isinstance(part, list):
                raise ValueError("進度包的結果分段格式錯誤。")
            segments.append((name, data))
            results.extend(part)
        if state["下一個位置"] != len(results) or len(results) > total:
            raise ValueError("進度包的結果數量與記錄不一致。")
        return results, segments


def _save(path, total, fingerprint, results, segments):
    """先在同一目錄完成新 zip，才以 replace 原子替換舊檔。"""
    path.parent.mkdir(parents=True, exist_ok=True)
    saved_count = sum(len(json.loads(data)) for _, data in segments)
    new_segments = list(segments)
    if saved_count < len(results):
        name = f"results/{len(new_segments):08d}.json"
        new_segments.append((name, _json(results[saved_count:]).encode("utf-8")))
    state = {"總數": total, "下一個位置": len(results), "任務名": TASK_NAME,
             "清單指紋": fingerprint, "結果分段檔": [name for name, _ in new_segments]}
    fd, temporary = tempfile.mkstemp(prefix=".進度包-", suffix=".tmp", dir=path.parent)
    try:
        with os.fdopen(fd, "wb") as raw:
            with zipfile.ZipFile(raw, "w", compression=zipfile.ZIP_DEFLATED) as archive:
                archive.writestr("state.json", _json(state).encode("utf-8"))
                for name, data in new_segments:
                    archive.writestr(name, data)
            raw.flush()
            os.fsync(raw.fileno())
        os.replace(temporary, path)
    finally:
        if os.path.exists(temporary):
            os.unlink(temporary)
    return new_segments


def main():
    path = Path(PROGRESS_PATH)
    if "--續跑" in sys.argv and not path.exists():
        print(f"找不到進度包 {path.as_posix()}：請把它列進 input_files 再跑")
        raise SystemExit(1)
    if WORKERS < 1 or TIME_BUDGET <= 0 or SAVE_INTERVAL <= 0:
        raise ValueError("WORKERS、TIME_BUDGET、SAVE_INTERVAL 必須大於零。")
    if POOL not in ("thread", "process"):
        raise ValueError("POOL 必須是 thread 或 process。")
    start = time.monotonic()
    deadline = start + TIME_BUDGET
    items = list(list_items())
    fingerprint = hashlib.sha256(_json(items).encode("utf-8")).hexdigest()
    results, segments = _load(path, len(items), fingerprint)
    last_save = time.monotonic()
    error = None
    executor = None
    pending = {}
    completed = {}
    next_submit = len(results)
    try:
        if WORKERS > 1 and len(results) < len(items) and time.monotonic() < deadline:
            executor_class = (concurrent.futures.ThreadPoolExecutor if POOL == "thread"
                              else concurrent.futures.ProcessPoolExecutor)
            executor = executor_class(max_workers=WORKERS)
        while len(results) < len(items) and time.monotonic() < deadline:
            if executor is None:
                index = len(results)
                try:
                    result = do_item(items[index])
                    results.append(json.loads(_json(result)))
                except Exception as exc:
                    error = (index, exc)
                    break
            else:
                while next_submit < len(items) and next_submit < len(results) + WORKERS:
                    future = executor.submit(do_item, items[next_submit])
                    pending[future] = next_submit
                    next_submit += 1
                done, _ = concurrent.futures.wait(
                    pending, timeout=max(0, deadline - time.monotonic()),
                    return_when=concurrent.futures.FIRST_COMPLETED)
                for future in done:
                    index = pending.pop(future)
                    try:
                        value = future.result()
                        completed[index] = (True, json.loads(_json(value)))
                    except Exception as exc:
                        completed[index] = (False, exc)
                while len(results) in completed:
                    index = len(results)
                    ok, value = completed.pop(index)
                    if not ok:
                        error = (index, value)
                        break
                    results.append(value)
                if error:
                    break
            if time.monotonic() - last_save >= SAVE_INTERVAL:
                segments = _save(path, len(items), fingerprint, results, segments)
                last_save = time.monotonic()
    finally:
        if executor is not None:
            if POOL == "process":
                # 3.13 沒有公開的終止工作行程 API；先終止未完成的工作以免逾時。
                if pending:
                    for process in executor._processes.values():
                        if process.is_alive():
                            process.terminate()
                executor.shutdown(wait=True, cancel_futures=True)
            else:
                executor.shutdown(wait=True, cancel_futures=True)
                for future, index in pending.items():
                    if future.cancelled():
                        continue
                    try:
                        value = future.result()
                        completed[index] = (True, json.loads(_json(value)))
                    except Exception as exc:
                        completed[index] = (False, exc)
                while error is None and len(results) in completed:
                    index = len(results)
                    ok, value = completed.pop(index)
                    if not ok:
                        error = (index, value)
                        break
                    results.append(value)
    if error is None:
        failures = [(index, value) for index, (ok, value) in completed.items() if not ok]
        if failures:
            error = min(failures, key=lambda failure: failure[0])
    _save(path, len(items), fingerprint, results, segments)
    if error:
        index, exc = error
        print(f"工作項目 {index + 1}（{_json(items[index])}）出錯：{exc}")
        print(f"先修好 do_item 或資料再重跑；已完成的 {len(results)} 項保存在進度包")
        raise SystemExit(1)
    if len(results) == len(items) and error is None:
        output = finish(results)
        print(f"全部做完：{output if output is not None else '已產生最終結果'}")
    else:
        print(f"還沒做完：已做 {len(results)}/{len(items)}。下一次 input_files 照抄：")
        for filename in [*INPUT_FILES, path.as_posix()]:
            print(filename)
        print("下一次執行加參數 --續跑")


if __name__ == "__main__":
    try:
        main()
    except Exception as exc:
        print(f"執行失敗：{exc}")
        raise SystemExit(1) from exc
