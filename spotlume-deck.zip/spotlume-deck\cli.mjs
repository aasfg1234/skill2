#!/usr/bin/env node
// 光點簡報 Claude Code skill 的指令程式（2026-10-15 使用者：「我想用 claude code 的 skill 在對話中就可以作出簡報」）。
//
// 做法：App 怎麼做一份簡報，這裡就怎麼做，只是「AI 的回答」改由對話中的 Claude 來寫（不呼叫 AI API、不花錢）：
//   表單 → 大綱 → 大綱檢查修正 → 一頁一頁做 → 每頁自動檢查、修一次 → 整份審查 → 看截圖修正 → 匯出
// 每一步的說明（提示詞）、解析、檢查、組裝、匯出都直接用 App 的程式（scripts/deck-skill/lib.ts），App 改了這裡跟著變。
// 照 Max 會員的設定：沒有浮水印、可以上網、最多 30 頁、自動修正／整份審查／看圖修正都開。
//
// 用法：node scripts/deck-skill/cli.mjs <指令> [--dir 工作資料夾] …（node cli.mjs help 看全部）
import { createHash } from 'node:crypto';
import { existsSync } from 'node:fs';
import { mkdir, readFile, rename, rm, stat, writeFile } from 'node:fs/promises';
import { createRequire } from 'node:module';
import { homedir } from 'node:os';
import { basename, dirname, extname, join, resolve } from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';

const HERE = dirname(fileURLToPath(import.meta.url));
/**
 * 安裝包（scripts/deck-skill/package.mjs 打包出來的）：App 的程式已經先打包在 dist/，不需要整個光點專案；
 * playwright 等套件裝在 cli.mjs 旁邊。在光點專案裡跑（開發）時，每次直接打包最新的 App 程式。
 */
const PACKAGED = existsSync(join(HERE, 'dist', 'lib.mjs'));
const ROOT = PACKAGED ? HERE : join(HERE, '..', '..');
const CACHE = join(ROOT, 'node_modules', '.cache', 'deck-skill');
const DEFAULT_OUT = PACKAGED ? join(homedir(), 'Documents', '光點簡報') : join(ROOT, '..', '簡報成品');
const CLI = `node "${fileURLToPath(import.meta.url)}"`;
const MAX_SLIDES = 30;
const SHOT_WIDTH = 1280;

// ─── 小工具 ───

const pad = (n) => String(n).padStart(2, '0');
const slideTask = (i) => `slide-${pad(i + 1)}`;
const fail = (message) => {
  const error = new Error(message);
  error.userFacing = true;
  throw error;
};

/** 只是開關、後面不接值的參數：寫在頁碼前面（revise --self 3）也不會把頁碼吃掉。 */
const FLAGS = new Set(['self', 'force', 'no-review', 'no-visual', 'no-autofix']);

function parseArgs(argv) {
  const args = { _: [] };
  for (let i = 0; i < argv.length; i += 1) {
    const a = argv[i];
    if (a.startsWith('--')) {
      const key = a.slice(2);
      const next = argv[i + 1];
      if (FLAGS.has(key) || next === undefined || next.startsWith('--')) args[key] = true;
      else {
        args[key] = next;
        i += 1;
      }
    } else args._.push(a);
  }
  return args;
}

/**
 * 檔名、資料夾名：拿掉 Windows 不准的字，和 $、`、% 這種印成指令時會被 shell 展開的字；
 * 太長就截斷，但英文單字不從中間切、結尾不留半個括號或標點。
 */
function safeName(text, max = 40) {
  const t = String(text).replace(/[\\/:*?"<>|$`%!\u0000-\u001f]/g, ' ').replace(/\s+/g, ' ').trim();
  let s = t.slice(0, max);
  if (t.length > max && /[A-Za-z0-9]$/.test(s) && /[A-Za-z0-9]/.test(t[max])) s = s.replace(/[A-Za-z0-9]+$/, '') || s;
  return s.replace(/[\s.。,，、：:;；（(「『【\-—]+$/, '') || '簡報';
}

function stamp(date = new Date()) {
  return `${date.getFullYear()}${pad(date.getMonth() + 1)}${pad(date.getDate())}-${pad(date.getHours())}${pad(date.getMinutes())}`;
}

const esc = (s) => String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');

// ─── 載入 App 程式（esbuild 打包；每個指令各打包一份，多個指令同時跑也不會互相蓋掉） ───

function esbuild() {
  return createRequire(join(ROOT, 'functions', 'package.json'))('esbuild');
}

const rawPlugin = {
  name: 'raw',
  setup(b) {
    b.onResolve({ filter: /\?raw$/ }, (args) => ({ path: join(args.resolveDir, args.path.replace(/\?raw$/, '')), namespace: 'raw' }));
    b.onLoad({ filter: /.*/, namespace: 'raw' }, async (args) => ({ contents: await readFile(args.path, 'utf8'), loader: 'text' }));
  },
};

async function loadLib() {
  if (PACKAGED) return import(pathToFileURL(join(HERE, 'dist', 'lib.mjs')).href);
  await mkdir(CACHE, { recursive: true });
  const outfile = join(CACHE, `lib-${process.pid}-${Date.now()}.mjs`);
  await esbuild().build({
    entryPoints: [join(ROOT, 'scripts', 'deck-skill', 'lib.ts')],
    outfile,
    bundle: true,
    platform: 'node',
    format: 'esm',
    external: ['jszip', 'node-unrar-js', 'node-unrar-js/*', 'firebase-admin', 'firebase-admin/*', 'firebase-functions', 'firebase-functions/*'],
    logLevel: 'error',
    plugins: [rawPlugin],
  });
  try {
    return await import(pathToFileURL(outfile).href);
  } finally {
    await rm(outfile, { force: true });
  }
}

/** 附件在瀏覽器裡用 App 的 readAttachments 讀（Office 要 DOMParser、圖片要 canvas）。 */
async function browserReader() {
  if (PACKAGED) return readFile(join(HERE, 'dist', 'browser.js'), 'utf8');
  const result = await esbuild().build({
    entryPoints: [join(ROOT, 'scripts', 'deck-skill', 'browser.ts')],
    bundle: true,
    write: false,
    platform: 'browser',
    format: 'iife',
    external: ['node-unrar-js'],
    logLevel: 'error',
    plugins: [
      {
        // RAR 的 WASM 在這裡用不到（讀 RAR 會回「不能讀」的說明，不影響其他檔案）
        name: 'url-stub',
        setup(b) {
          b.onResolve({ filter: /\?url$/ }, () => ({ path: 'stub', namespace: 'url-stub' }));
          b.onLoad({ filter: /.*/, namespace: 'url-stub' }, () => ({ contents: 'export default ""', loader: 'js' }));
        },
      },
    ],
  });
  return result.outputFiles[0].text;
}

async function launchBrowser() {
  const { chromium } = createRequire(join(ROOT, 'package.json'))('playwright');
  for (const channel of [undefined, 'msedge', 'chrome']) {
    try {
      return await chromium.launch(channel ? { channel } : {});
    } catch (error) {
      if (channel === 'chrome') fail(`開不了檢查用的瀏覽器：${String(error.message).split('\n')[0]}`);
    }
  }
}

// ─── 工作資料夾與狀態 ───

function workDir(args) {
  const dir = args.dir;
  if (!dir || dir === true) fail('要用 --dir 指定工作資料夾（new 指令印出來的那個）。');
  return resolve(dir);
}

const statePath = (W) => join(W, 'state.json');

async function loadState(W) {
  if (!existsSync(statePath(W))) fail(`找不到 ${statePath(W)}：這不是光點簡報的工作資料夾。`);
  return JSON.parse(await readFile(statePath(W), 'utf8'));
}

/** 先寫暫存檔再改名：指令被中斷時不會留下寫一半的 state.json。 */
async function saveState(W, state) {
  state.deck.updatedAt = new Date().toISOString();
  const tmp = `${statePath(W)}.tmp`;
  await writeFile(tmp, JSON.stringify(state, null, 1));
  await rename(tmp, statePath(W));
}

function alive(pid) {
  try {
    process.kill(pid, 0);
    return true;
  } catch (error) {
    return error.code === 'EPERM';
  }
}

async function lockOwner(lock) {
  return Number(await readFile(join(lock, 'pid'), 'utf8').catch(() => '')) || 0;
}

/**
 * 同一個工作資料夾一次只讓一個指令改狀態（可以同時開好幾個助手寫不同頁）。
 * 鎖裡記著拿鎖的程式編號：那個程式已經不在（例如指令逾時被中斷），馬上解開，不用乾等。
 */
async function withLock(W, fn) {
  // 資料夾不對（--dir 打錯、被刪）：直接講，不要當成「被鎖住」乾等 10 分鐘（2026-10-18 審查）
  if (!existsSync(statePath(W))) fail(`找不到 ${statePath(W)}：這不是光點簡報的工作資料夾（--dir 打錯了嗎？）。`);
  const lock = join(W, '.lock');
  const started = Date.now();
  for (;;) {
    try {
      await mkdir(lock);
      await writeFile(join(lock, 'pid'), String(process.pid));
      break;
    } catch (error) {
      if (error.code !== 'EEXIST') throw error;
      if (await deadLock(lock)) {
        await takeOverLock(W, lock);
        continue;
      }
      if (Date.now() - started > 10 * 60_000) fail(`工作資料夾被另一個還在跑的指令（程式編號 ${await lockOwner(lock)}）鎖住超過 10 分鐘。確定沒有在跑，執行：${CLI} unlock --dir "${W}"`);
      await sleep(300);
    }
  }
  try {
    return await fn();
  } finally {
    if ((await lockOwner(lock)) === process.pid) await rm(lock, { recursive: true, force: true }).catch(() => {});
  }
}

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

/** 鎖的主人已經不在（指令逾時被中斷），或一分鐘了還沒寫上主人。 */
async function deadLock(lock) {
  const owner = await lockOwner(lock);
  const age = await stat(lock).then((s) => Date.now() - s.mtimeMs, () => 0);
  return (owner && !alive(owner)) || (!owner && age > 60_000);
}

/**
 * 接手死掉的鎖：好幾個指令同時在等時，只讓一個來刪（.lock-takeover 用「不存在才建」搶），
 * 搶到後再確認一次還是死的才刪——不然後到的會把先到的人剛建好的新鎖刪掉，兩個人同時改 state.json
 *（2026-10-18 審查實測 20 次有 3 次）。Windows 刪資料夾偶爾 EPERM／EBUSY：忽略，下一輪再試。
 */
async function takeOverLock(W, lock) {
  const marker = join(W, '.lock-takeover');
  try {
    await writeFile(marker, String(process.pid), { flag: 'wx' });
  } catch {
    // 別人正在接手；接手的人中途被中斷留下的標記，10 秒後清掉
    const age = await stat(marker).then((s) => Date.now() - s.mtimeMs, () => 0);
    if (age > 10_000) await rm(marker, { force: true }).catch(() => {});
    await sleep(200);
    return;
  }
  try {
    if (await deadLock(lock)) await rm(lock, { recursive: true, force: true }).catch(() => {});
  } finally {
    await rm(marker, { force: true }).catch(() => {});
  }
}

// ─── 跟 App 一樣的資料整理 ───

/** 大綱確認後以投影片上的標題與重點為準（jobs.ts outlineFromSlides）。 */
function sentOutline(deck) {
  return { ...deck.outline, slides: deck.slides.map((s) => ({ id: s.id, title: s.title, points: s.points, imageIds: s.imageIds })) };
}

/** 逐頁、修改時附件只帶這頁用到的圖片資料，PDF、文字檔只留名稱（runner.ts slimFor）。 */
function slimFor(deck, index, html = '') {
  const outline = sentOutline(deck);
  const used = new Set([...html.matchAll(/asset:([\w-]+)/g)].map((m) => m[1]).concat(outline.slides[index]?.imageIds ?? []));
  return deck.attachments.map((a) => (a.kind === 'image' && used.has(a.id) ? a : { ...a, data: '' }));
}

const htmlsOf = (deck) => deck.slides.map((s) => s.html ?? '');

function attachmentFile(W, a) {
  const ext = a.kind === 'pdf' ? '.pdf' : a.kind === 'text' ? '.txt' : `.${(a.mediaType.split('/')[1] || 'jpg').replace('jpeg', 'jpg')}`;
  return join(W, 'attachments', `${a.id}${ext}`);
}

// ─── 寫給 Claude 的工作說明 ───

const KIND_LABEL = {
  outline: '寫大綱',
  outlinefix: '調整大綱（只改有問題的頁）',
  slide: '做這一頁',
  fix: '自動修正這一頁（檢查找到問題）',
  review: '整份審查',
  visual: '看截圖修正',
  revise: '修改這一頁',
};

function toolsText(tools) {
  if (!tools) return '這一步不上網（App 這一步也不開放）。';
  const list = [];
  if (tools.search) list.push(`上網搜尋最多 ${tools.search.maxUses} 次（用 WebSearch）`);
  if (tools.fetch) list.push(`讀網頁最多 ${tools.fetch.maxUses} 個（用 WebFetch，沒有就交給 web-fetch 助手；claude.ai/artifact 連結用 Artifact 工具的 read；說明裡寫的 web_fetch 就是它）`);
  return `可以${list.join('、')}。說明裡的 web_search 就是 WebSearch。`;
}

/** 把一個工作的說明寫成檔案：共用背景（system）另存一份，同一份簡報內容一樣就同一個檔。 */
async function writeTaskPrompt(W, task, plan, files) {
  await mkdir(join(W, 'prompts'), { recursive: true });
  await mkdir(join(W, 'answers'), { recursive: true });
  const hash = createHash('sha1').update(plan.prompt.system).digest('hex').slice(0, 8);
  const rulesFile = join(W, 'prompts', `rules-${hash}.md`);
  if (!existsSync(rulesFile)) await writeFile(rulesFile, `<!-- 背景規則：App 給 AI 的 system 提示詞。同一個檔名內容不會變，讀過一次就好。 -->\n\n${plan.prompt.system}\n`);
  const answerFile = join(W, 'answers', `${task.id}.md`);
  // 同名工作重新排（再改一次同一頁、加附件後重寫大綱、內容過期重出說明）：舊的回答一定要重寫，不能被誤送
  await rm(answerFile, { force: true });
  const list = plan.prompt.attachments
    .map((a) => `- ${a.id}（${a.name}）：${files(a) ?? '（這一步沒有帶這個檔案的內容）'}`)
    .join('\n');
  const head = [
    `# 工作 ${task.id}：${KIND_LABEL[task.kind]}${task.index !== undefined ? `（第 ${task.index + 1} 頁）` : ''}`,
    '',
    `- 先讀背景規則：${rulesFile}`,
    `- 回答寫到：${answerFile}`,
    `- 寫完執行：${CLI} answer --dir "${W}" ${task.id}`,
    `- 回答長度：App 給 AI 的上限約 ${plan.maxTokens} token，照下面「回答格式」寫，不要多寫說明文字。`,
    `- ${toolsText(plan.tools)}`,
    list ? `- 附件（App 會把檔案直接給 AI 看；請用 Read 打開）：\n${list}` : '- 這一步沒有附件。',
    '',
    '---',
    '',
  ].join('\n');
  const promptFile = join(W, 'prompts', `${task.id}.md`);
  await writeFile(promptFile, `${head}${plan.prompt.user}\n`);
  Object.assign(task, { promptFile, rulesFile, answerFile });
  return task;
}

/** 截圖路徑照這次的工作資料夾重算（state.json 裡記的是絕對路徑，資料夾搬家、改名後會指到別處）。 */
const inShots = (W, file) => join(W, 'shots', basename(file));

function attachmentPaths(W, deck, extra = {}) {
  return (a) => extra[a.id] ?? (deck.attachments.some((x) => x.id === a.id) && a.data ? attachmentFile(W, a) : null);
}

async function addTask(W, state, lib, task) {
  const { deck } = state;
  const form = deck.form;
  let plan;
  let extra = {};
  if (task.kind === 'outline') {
    plan = lib.planTask({ task: 'outline', form, attachments: deck.attachments }, false);
  } else if (task.kind === 'outlinefix') {
    plan = lib.planTask({ task: 'outlinefix', form, outline: deck.outline, issues: task.issues }, false);
  } else if (task.kind === 'slide') {
    plan = lib.planTask({ task: 'slide', form, outline: sentOutline(deck), index: task.index, attachments: slimFor(deck, task.index) }, false);
  } else if (task.kind === 'fix' || task.kind === 'revise') {
    const html = task.before;
    plan = lib.planTask({ task: 'revise', form, outline: sentOutline(deck), index: task.index, html, note: task.note, attachments: slimFor(deck, task.index, html) }, false);
    if (task.shot) {
      task.shot = inShots(W, task.shot);
      const shot = (await readFile(task.shot)).toString('base64');
      plan = { ...plan, prompt: lib.withShot(plan.prompt, shot) };
      extra = { shot: task.shot };
    }
  } else if (task.kind === 'review') {
    plan = lib.planTask({ task: 'review', form, outline: sentOutline(deck), htmls: htmlsOf(deck), attachments: [] }, false);
  } else if (task.kind === 'visual') {
    task.shots = task.shots.map((s) => ({ ...s, file: inShots(W, s.file) }));
    const shots = await Promise.all(task.shots.map(async (s) => ({ index: s.index, data: (await readFile(s.file)).toString('base64') })));
    plan = { prompt: lib.buildVisualPrompt(form, sentOutline(deck), shots), maxTokens: lib.REVIEW_MAX_TOKENS };
    extra = Object.fromEntries(task.shots.map((s) => [`p${s.index + 1}`, s.file]));
  }
  await writeTaskPrompt(W, task, plan, attachmentPaths(W, deck, extra));
  state.pending = state.pending.filter((t) => t.id !== task.id);
  state.pending.push(task);
}

// ─── 檢查（文字規則＋實際畫出來量，跟櫃台 runner.ts check 一樣） ───

function deckSize(lib, deck) {
  return lib.slideSizeOf(deck.form);
}

async function renderPage(lib, browser, deck, html, { shotFile } = {}) {
  const size = deckSize(lib, deck);
  const doc = lib.composeSlideHtml(lib.deckCss({ form: deck.form, outline: deck.outline }), html, size, deck.attachments);
  // 先刪舊截圖：這次拍不到時，不要留著上一版的圖讓人以為是新的（2026-10-18 審查）
  if (shotFile) await rm(shotFile, { force: true }).catch(() => {});
  const page = await browser.newPage({ viewport: size, deviceScaleFactor: shotFile ? SHOT_WIDTH / size.width : 1 });
  const errors = [];
  // 計時器用完要清掉：沒清的話 node 會等它跑完才結束，每個 answer 白等 30 秒（2026-10-17 實測單頁 33 秒，其中 29 秒在等這個）
  const within = (p, ms, what) => {
    let timer;
    const late = new Promise((_, reject) => {
      timer = setTimeout(() => reject(new Error(`${what}超過 ${ms / 1000} 秒`)), ms);
    });
    return Promise.race([p, late]).finally(() => clearTimeout(timer));
  };
  try {
    // AI 寫的頁不准連外：只放行字型（自己網站）與 data:
    const fontOrigin = new URL(doc.match(/https?:\/\/[^"']+\/fonts\//)?.[0] ?? 'https://spotlume.web.app/fonts/').origin;
    await page.route('**/*', (route) => {
      const url = route.request().url();
      if (/^(data|about|blob):/.test(url) || url.startsWith(`${fontOrigin}/fonts/`)) return route.continue();
      errors.push(`連外：${url.slice(0, 80)}`);
      return route.abort();
    });
    page.on('pageerror', (e) => errors.push(`程式錯誤：${String(e.message).slice(0, 120)}`));
    const withHooks = doc.replace(/<head[^>]*>/i, (m) => `${m}<style>${lib.MEASURE_NO_ANIMATION_CSS}</style><script>${lib.MEASURE_ERROR_HOOK}</${'script'}>`);
    await page.setContent(withHooks, { waitUntil: 'load', timeout: 30_000 });
    await within(
      page.evaluate(async () => {
        await document.fonts.ready;
      }),
      10_000,
      '等字型',
    );
    await page.waitForTimeout(1500);
    // 先拍照再量：量測會點每個能點的地方
    if (shotFile) {
      await mkdir(dirname(shotFile), { recursive: true });
      await page.screenshot({ path: shotFile, type: 'jpeg', quality: 70, timeout: 30_000 });
    }
    const issues = lib.measureIssues(await within(page.evaluate(lib.measureSlideInPage), 30_000, '量版面'));
    return { issues, errors };
  } catch (error) {
    // 跟櫃台一樣（runner.ts check）：畫面檢查跑不完就略過，不要讓這一頁永遠過不去；文字規則的檢查照樣有
    errors.push(`畫面檢查沒跑完（${String(error.message).split('\n')[0].slice(0, 100)}），這次只做文字規則檢查`);
    return { issues: [], errors };
  } finally {
    await page.close().catch(() => {});
  }
}

/** 截圖路徑；這次畫面檢查沒跑完、沒拍到就照實說。 */
const shotText = (file) => (existsSync(file) ? file : '（這次沒有截圖：畫面檢查沒跑完）');

/**
 * userChanged：使用者要求改過這一頁（revise）。換掉大綱排的元件是使用者的意思，不算「沒照大綱」
 *（2026-10-17 skill 測試：使用者要「點了才出現說明」，sl-delta 沒有這功能、換成 sl-stat，build 卻一直列這頁、也跳不過）。
 */
async function checkSlide(lib, browser, deck, index, html, shotFile, { userChanged = false } = {}) {
  const form = deck.form;
  const outline = sentOutline(deck);
  const assets = slimFor(deck, index, html);
  const text = form.useKit
    ? lib.lintKitSlide(html, { language: form.language, research: outline.research, ...lib.slideCheckContext(form, outline, index, assets) })
    : lib.lintFreeSlide(html, { language: form.language, research: outline.research, sharedCss: outline.sharedCss });
  const measured = await renderPage(lib, browser, deck, html, { shotFile });
  const lint = userChanged ? text.filter((i) => i.code !== 'component-mismatch') : text;
  return { issues: [...lint, ...measured.issues], errors: measured.errors };
}

/** 元件自己會一段一段來（播放時按 → 才出下一段；kit.js syncSteppers、addStepper）。 */
const STEPPERS = {
  'sl-steps': '流程一段一段亮',
  'sl-timeline': '時間軸一段一段亮',
  'sl-roadmap': '路線圖一段一段亮',
  'sl-cycle': '循環一段一段亮',
  'sl-chat': '對話一則一則出現',
  'sl-funnel': '漏斗一層一層出現',
  'sl-waterfall': '瀑布圖一根一根長出來',
};

/** 這一頁播放時有哪些互動（交件時告訴使用者上台怎麼用）。 */
function interactionsOf(lib, html) {
  const out = [];
  for (const s of lib.COMPONENT_SPECS) if (s.interactive && /^sl-[a-z-]+$/.test(s.tag) && new RegExp(`<${s.tag}\\b`, 'i').test(html)) out.push(s.name);
  for (const [tag, text] of Object.entries(STEPPERS)) if (new RegExp(`<${tag}\\b(?![^>]*\\bstatic\\b)`, 'i').test(html)) out.push(`按 → ${text}`);
  if (/\sstepwise\b/i.test(html)) out.push('按 → 一步一步揭曉');
  if (/\sdata-step\s*=/i.test(html)) out.push('按 → 逐步出現');
  if (/\smore\s*=\s*"/i.test(html)) out.push('點 ＋ 看補充');
  if (/<sl-(?:chart|share)\b[^>]*\snotes\s*=/i.test(html)) out.push('點圖表看說明');
  if (/<sl-custom\b[\s\S]*<button\b/i.test(html)) out.push('自由設計裡的按鈕');
  return [...new Set(out)];
}

function issueLines(issues) {
  return issues.map((i) => `  - ${i.level === 'error' ? '［要改］' : '［提醒］'}${i.message}`).join('\n');
}

// ─── 階段推進 ───

function progressText(deck) {
  const done = deck.slides.filter((s) => s.html).length;
  return `${done}/${deck.slides.length} 頁完成`;
}

async function advance(W, state, lib, browser, log) {
  if (state.pending.length) return;
  const { deck, options } = state;
  if (state.phase === 'slides') {
    state.phase = 'review';
    const pages = htmlsOf(deck).filter((h) => h.trim()).length;
    if (options.review && pages >= lib.REVIEW_MIN_PAGES) {
      await addTask(W, state, lib, { id: 'review', kind: 'review' });
      log.push('每一頁都做好了。接下來「整份審查」：從頭看一遍整份，找出最多 3 頁要改的。');
      return;
    }
  }
  if (state.phase === 'review') {
    state.phase = 'visual';
    if (options.visual && htmlsOf(deck).filter((h) => h.trim()).length >= lib.REVIEW_MIN_PAGES) {
      const shots = [];
      for (const [index, html] of htmlsOf(deck).entries()) {
        if (!html.trim()) continue;
        const file = join(W, 'shots', `visual-${pad(index + 1)}.jpg`);
        await rm(file, { force: true });
        await renderPage(lib, browser, deck, html, { shotFile: file });
        // 拍照失敗（字型、頁面載入逾時）的頁不放進去，跟櫃台一樣（runner.ts：有照片才放）；放了會讀不到檔、卡在這一步
        if (existsSync(file)) shots.push({ index, file });
      }
      if (shots.length >= 2) {
        await addTask(W, state, lib, { id: 'visual', kind: 'visual', shots });
        log.push(`接下來「看截圖修正」：已經拍好 ${shots.length} 頁的照片，看畫面找出最多 3 頁要改的。`);
        return;
      }
    }
  }
  if (state.phase === 'visual') {
    state.phase = 'done';
    deck.stage = 'ready';
    log.push(`全部完成。執行 ${CLI} build --dir "${W}" 輸出檔案。`);
  }
}

/** 採用一次修改（applyJob.ts applyToSlide）：內容沒變就不推舊版；換了內容，舊的「自動修正」標記就不算數了。 */
function acceptRevision(slide, html, notes, reason, maxHistory) {
  if (notes) slide.speakerNotes = notes;
  if (html === slide.html) return false;
  slide.history = [...(slide.history ?? []), slide.html].filter(Boolean).slice(-maxHistory);
  slide.html = html;
  slide.status = 'success';
  slide.autoFixed = undefined;
  slide.pendingCompare = reason;
  return true;
}

const editsSlide = (t) => t.kind === 'fix' || t.kind === 'revise';

const SLIDE_FORMAT = '一個 ```html 區塊（最外層是 <div class="sl-slide" …>）；表單要講者備註時，後面再一個 ```notes 區塊。';
const REVIEW_FORMAT = '只回一個 JSON：{ "summary": "…", "pages": [ { "page": 3, "problem": "…", "fix": "…" } ] }（page 從 1 起算；沒有要改的頁就 "pages": []）。';
const ANSWER_FORMAT = {
  outline: '一個 JSON 物件（可以放在 ```json 區塊），欄位照說明最後的範例：title、subtitle、research、imageNotes、sharedCss、slides。',
  outlinefix: '只回一個 JSON 陣列，照說明最後的範例（每個項目是要改的那一頁和新的 points）。',
  slide: SLIDE_FORMAT,
  fix: SLIDE_FORMAT,
  revise: SLIDE_FORMAT,
  review: REVIEW_FORMAT,
  visual: REVIEW_FORMAT,
};

/**
 * 同一頁剛被改過：還在排隊的同一頁工作，說明裡的「目前的 HTML」已經過期。
 * 修改工作改用最新內容重出說明（不然照舊版回答，會把剛改好的蓋掉）；自動修正是針對舊版的問題，直接取消（App 也是：jobs.ts 頁面變了就不採用）。
 */
async function refreshSameSlide(W, state, lib, index, log) {
  const slide = state.deck.slides[index];
  for (const t of [...state.pending]) {
    if (t.index !== index || !editsSlide(t) || t.before === slide.html) continue;
    if (t.kind === 'fix') {
      state.pending = state.pending.filter((x) => x !== t);
      log.push(`第 ${index + 1} 頁已經改過，${t.id}（針對舊版的自動修正）取消。`);
      continue;
    }
    t.before = slide.html;
    await addTask(W, state, lib, t);
    log.push(`${t.id} 的說明已更新成第 ${index + 1} 頁的最新內容，照新的說明回答。`);
  }
}

// ─── 指令 ───

/**
 * skill 跟 App 不同的預設值（決策 D022，2026-10-17 使用者選「預設開」）：
 * 上網搜尋在 App 要扣點所以預設關；skill 用對話額度、不另外花錢，關著時「業界約 6 成」只能標未查證（盲測扣分），所以預設開。
 */
const SKILL_DEFAULTS = { webSearch: true };

const FIELD_SPEC = [
  ['topic', '主題（必填）', '這份簡報要講什麼？越具體越好'],
  ['purpose', '目的', '例如：爭取下一季預算'],
  ['audience', '聽眾', '例如：部門主管'],
  ['slideCount', '頁數', `1～${MAX_SLIDES}；沒填＝頁數交給 AI`],
  ['autoSlides', '頁數交給 AI', `true／false：AI 依內容與演講時間決定頁數；沒填頁數就是 true；true 又寫了 slideCount 時，slideCount 是上限`],
  ['visualStyle', '視覺風格', '見下方風格清單'],
  ['styleTuning', '微調風格', '見下方旋鈕；只填想改的，例如 {"type":"elegant","card":"glass"}'],
  ['primaryColor', '主要顏色', '#RRGGBB；空白＝交給風格'],
  ['secondaryColor', '輔助顏色', '#RRGGBB；空白＝交給風格'],
  ['motion', '動畫程度', 'calm 低調（柔和淡入）／lively 生動（依序出現、數字跑動）／bold 炫目（粒子、路徑、3D）'],
  ['interactivity', '互動多寡', '0 不要／1 少（1～2 頁）／2 適中（約一半的頁）／3 多（幾乎每頁）'],
  ['useKit', '使用光點元件庫', 'true（版面穩定，建議）／false（AI 自由發揮，可能跑版）'],
  ['referenceUrls', '參考網址', '一行一個'],
  ['webSearch', '允許上網搜尋', 'true／false：查最新資料與數字，並附來源'],
  ['language', '語言', '繁體中文／簡體中文／English／日本語／한국어'],
  ['aspectRatio', '畫面比例', '16:9／4:3'],
  ['durationMinutes', '演講時間（分鐘）', '1～300'],
  ['backgroundInfo', '背景資訊', '聽眾已經知道什麼、目前的狀況'],
  ['requiredContent', '一定要包含', '例如：費用、風險、下一步'],
  ['excludedContent', '不要包含', '例如：未確認的數字'],
  ['dataSources', '資料來源', '例如：2026 年公司年報'],
  ['textDensity', '文字量', 'concise 精簡／normal 適中／detailed 詳細'],
  ['tone', '語氣', 'professional 專業／teaching 教學／sales 說服／story 故事／formal 正式'],
  ['generateNotes', '產生講者備註', 'true／false：每頁附上台時要說的話'],
  ['coverMaster', '封面版型', ''],
  ['contentMaster', '內容版型', ''],
  ['showTitleBar', '標題列', 'true／false'],
  ['showSlideNumbers', '頁碼', 'true／false'],
  ['useCharts', '圖表', 'true／false'],
  ['useTimelines', '時間軸', 'true／false'],
  ['useFlowcharts', '流程圖', 'true／false'],
  ['useImages', '插圖', 'true／false'],
];

/**
 * 表單跟櫃台一樣檢查（functions/src/validate.ts validateForm，Max 方案）：不合法的語氣、顏色、頁數直接講清楚。
 * 先把寫成字串的 "true"／"false"／"8" 轉成真的開關與數字（不然 "false" 會被當成「開」）。
 * validateForm 會丟掉微調風格（櫃台不需要），這裡補回去，畫面要用。
 */
function checkForm(lib, input) {
  const d = lib.DEFAULT_MOBILE_FORM;
  const raw = { ...SKILL_DEFAULTS, ...input };
  for (const [key, value] of Object.entries(raw)) {
    if (typeof d[key] === 'boolean' && typeof value === 'string' && /^(true|false)$/i.test(value.trim())) raw[key] = value.trim().toLowerCase() === 'true';
    if (typeof d[key] === 'number' && typeof value === 'string' && value.trim() !== '' && Number.isFinite(Number(value))) raw[key] = Number(value);
  }
  // 頁數交給 AI（2026-10-18，預設）：上限照 Max 方案；使用者說了頁數就是自己指定（說「最多 N 頁」就寫 autoSlides true＋slideCount N）
  // 開關先轉好再判斷（"False" 原本會被當成開）；頁數寫空字串、null 也算沒寫（2026-10-18 審查）
  if (raw.slideCount === '' || raw.slideCount === null) delete raw.slideCount;
  if (raw.slideCount === undefined) {
    if (raw.autoSlides === false) fail('autoSlides 是 false（自己指定頁數），但沒寫 slideCount。寫上頁數，或拿掉 autoSlides 交給 AI。');
    raw.autoSlides = true;
    raw.slideCount = MAX_SLIDES;
  }
  let form;
  try {
    form = lib.validateForm(raw, lib.DEFAULT_PLANS.max, true);
  } catch (error) {
    fail(`表單有問題：${String(error.message).split('\n')[0]}（執行 spec 看每一欄可以填什麼）`);
  }
  if (!lib.MOBILE_STYLES.some((s) => s.name === form.visualStyle)) fail(`沒有「${form.visualStyle}」這個風格。執行 spec 看風格清單。`);
  const tuning = lib.normalizeForm(raw).styleTuning;
  if (tuning) form.styleTuning = tuning;
  return form;
}

async function cmdSpec(lib) {
  const d = lib.DEFAULT_MOBILE_FORM;
  const lines = ['# 光點簡報表單（跟 App「新增簡報」一樣；使用者沒回答的用預設）', '', '| 欄位 | 名稱 | 預設 | 可以填 |', '|---|---|---|---|'];
  for (const [key, label, hint] of FIELD_SPEC) {
    let opts = hint;
    if (key === 'coverMaster') opts = lib.COVER_MASTERS.map((m) => `${m.id} ${m.name}`).join('／');
    if (key === 'contentMaster') opts = lib.CONTENT_MASTERS.map((m) => `${m.id} ${m.name}`).join('／');
    const dv = key in SKILL_DEFAULTS ? SKILL_DEFAULTS[key] : d[key];
    const value =
      key === 'slideCount' ? '（交給 AI）'
      : dv === undefined ? '（照風格）'
      : dv === '' ? '（空白）'
      : JSON.stringify(dv) + (key in SKILL_DEFAULTS ? '（skill 預設，App 是 ' + JSON.stringify(d[key]) + '）' : '');
    lines.push(`| ${key} | ${label} | ${value} | ${opts} |`);
  }
  lines.push('', '## 視覺風格（visualStyle 填名稱）', '');
  let group = '';
  for (const s of lib.MOBILE_STYLES) {
    if (s.group !== group) {
      group = s.group;
      lines.push(`- **${group}**`);
    }
    lines.push(`  - ${s.name}：${s.description}`);
  }
  lines.push('', '## 微調風格旋鈕（styleTuning；Max 可以用，只填要改的）', '');
  for (const [knob, { label, options }] of Object.entries(lib.KNOB_LABELS)) {
    lines.push(`- ${knob}（${label}）：${Object.entries(options).map(([k, v]) => `${k} ${v}`).join('／')}`);
  }
  lines.push('', '## 附件', '', '圖片、PDF、文字檔、Word／PowerPoint／Excel、ZIP 都可以（最多 20 個、共約 24MB）。用 new 的 --attach 或 attach 指令加入。');
  console.log(lines.join('\n'));
}

async function readAttachmentsInto(W, state, lib, paths) {
  if (!paths.length) return [];
  const { deck } = state;
  const browser = await launchBrowser();
  const notes = [];
  try {
    const page = await browser.newPage();
    await page.setContent('<!doctype html><meta charset="utf-8"><body></body>');
    await page.addScriptTag({ content: await browserReader() });
    for (const p of paths) {
      const file = resolve(p);
      if (!existsSync(file)) {
        notes.push(`找不到檔案：${file}`);
        continue;
      }
      const bytes = await readFile(file);
      const type = { '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg', '.png': 'image/png', '.gif': 'image/gif', '.webp': 'image/webp', '.pdf': 'application/pdf', '.txt': 'text/plain', '.md': 'text/plain', '.csv': 'text/plain' }[extname(file).toLowerCase()] ?? '';
      try {
        const result = await page.evaluate(([name, t, b64, existing]) => window.slRead(name, t, b64, existing), [basename(file), type, bytes.toString('base64'), deck.attachments]);
        deck.attachments.push(...result.attachments);
        notes.push(...result.notes);
        for (const a of result.attachments) notes.push(`加入 ${a.id}：${a.name}（${a.kind === 'image' ? `圖片 ${a.width}×${a.height}` : a.kind === 'pdf' ? 'PDF' : '文字'}）`);
      } catch (error) {
        notes.push(`${basename(file)}：${String(error.message).replace(/^Error: /, '').split('\n')[0]}`);
      }
    }
  } finally {
    await browser.close();
  }
  if (deck.attachments.length > lib.MAX_ATTACHMENTS) fail(`附件最多 ${lib.MAX_ATTACHMENTS} 個（現在 ${deck.attachments.length} 個）。`);
  if (lib.attachmentsPayloadSize(deck.attachments) > lib.MAX_TOTAL_BASE64) fail('附件加起來太大（上限約 24MB）。');
  await mkdir(join(W, 'attachments'), { recursive: true });
  for (const a of deck.attachments) {
    const f = attachmentFile(W, a);
    if (!existsSync(f)) await writeFile(f, a.kind === 'text' ? a.data : Buffer.from(a.data, 'base64'));
  }
  return notes;
}

async function cmdNew(lib, args) {
  const formFile = args.form;
  let input = {};
  if (formFile && formFile !== true) input = JSON.parse(await readFile(resolve(formFile), 'utf8'));
  if (!String(input.topic ?? '').trim()) fail('表單一定要有 topic（主題）。');
  const form = checkForm(lib, input);
  // 先確認檢查用的瀏覽器開得起來，不要做到第一頁才發現
  await (await launchBrowser()).close();
  const out = resolve(args.out && args.out !== true ? args.out : DEFAULT_OUT);
  // 同一分鐘、同一主題開兩份（換風格做兩版比較）：資料夾名稱加 -2、-3，不要共用、互相蓋掉（2026-10-18 審查）
  const base = join(out, '製作中', `${stamp()}-${safeName(form.topic, 20).replace(/\s+/g, '-')}`);
  await mkdir(dirname(base), { recursive: true });
  let W = base;
  for (let k = 2; ; k += 1) {
    try {
      await mkdir(W);
      break;
    } catch (error) {
      if (error.code !== 'EEXIST') throw error;
      W = `${base}-${k}`;
    }
  }
  const deck = lib.createDeck(form, []);
  const state = {
    version: 1,
    out,
    options: { autoFix: !args['no-autofix'], review: !args['no-review'], visual: !args['no-visual'] },
    // 上網預設開是給 skill 自己查證用的；匯入 App 之後照 App 的預設（關，App 上網要扣點），使用者明說要開才開（2026-10-18 審查）
    appWebSearch: input.webSearch === undefined ? false : form.webSearch,
    phase: 'outline',
    deck,
    pending: [],
  };
  const attach = [args.attach, ...args._.slice(1)].filter((x) => x && x !== true).flatMap((x) => String(x).split('|'));
  let notes;
  try {
    notes = await readAttachmentsInto(W, state, lib, attach);
    await addTask(W, state, lib, { id: 'outline', kind: 'outline' });
    await saveState(W, state);
  } catch (error) {
    // 沒開成功就不要留下一個空的工作資料夾
    await rm(W, { recursive: true, force: true });
    throw error;
  }
  console.log(`工作資料夾：${W}`);
  if (notes.length) console.log(`附件：\n${notes.map((n) => `  - ${n}`).join('\n')}`);
  await printNext(W, state);
}

async function cmdAttach(lib, args) {
  const W = workDir(args);
  await withLock(W, async () => {
    const state = await loadState(W);
    if (state.phase !== 'outline') fail('大綱已經寫好了，附件只能在寫大綱之前加（App 也一樣）。要重來請用 new 開新的一份。');
    const before = state.deck.attachments.length;
    const notes = await readAttachmentsInto(W, state, lib, args._.slice(1));
    // 真的加了附件才重出大綱說明（重出會刪掉已經寫好的大綱回答；2026-10-18 審查：沒給檔案也被刪）
    if (state.deck.attachments.length !== before) await addTask(W, state, lib, { id: 'outline', kind: 'outline' });
    await saveState(W, state);
    console.log(notes.map((n) => `- ${n}`).join('\n') || '沒有加入任何附件。');
    await printNext(W, state);
  });
}

function outlineText(deck, { mark } = {}) {
  const o = deck.outline;
  const slides = deck.slides.length ? deck.slides : o.slides;
  const lines = [`# ${o.title}`, o.subtitle ? `副標題：${o.subtitle}` : '', ''];
  for (const [i, s] of slides.entries()) {
    lines.push(`${i + 1}. ${s.title}${mark?.has(i) ? '（已調整）' : ''}`);
    for (const p of s.points) lines.push(`   - ${p}`);
    if (s.imageIds?.length) lines.push(`   - 圖片：${s.imageIds.join('、')}`);
  }
  if (o.research) lines.push('', `參考資料：${o.research.length} 字（存在 outline.json 的 research）`);
  return lines.filter((l, i) => l !== '' || i > 0).join('\n');
}

async function writeOutlineFile(W, deck) {
  const o = deck.outline;
  const file = join(W, 'outline.json');
  await writeFile(
    file,
    // research、imageNotes、sharedCss 也放進來：使用者改了方向（不要提某些內容、多一頁新主題）時，參考資料要跟著改，不然每一頁都還會讀到舊的
    JSON.stringify(
      {
        title: o.title,
        subtitle: o.subtitle,
        research: o.research,
        imageNotes: o.imageNotes ?? {},
        sharedCss: o.sharedCss ?? '',
        slides: o.slides.map((s) => ({ title: s.title, points: s.points, imageIds: s.imageIds })),
      },
      null,
      2,
    ),
  );
  return file;
}

/**
 * skill 專屬的大綱品質提醒（App 沒有這一關）。2026-10-17 盲測：skill＋Opus 輸在互動頁少、
 * 主要論點建立在「未查證」的說法上。只提醒、不擋：對話中的 Claude 改 outline.json，再給使用者看。
 */
function skillOutlineNotes(lib, deck, outline = deck.outline) {
  const { form } = deck;
  const notes = [];
  const content = outline.slides.slice(1);
  const heavy = lib.COMPONENT_SPECS.filter((s) => s.interactive && !s.thin && s.tag.startsWith('sl-'));
  const heavyTags = new Set(heavy.map((s) => s.tag));
  const isHeavy = (s) => heavyTags.has(lib.mainComponentOf(s.points) ?? '');
  const interactive = content.filter((s) => isHeavy(s) || s.points.some((p) => /^\s*互動[：:]/.test(p))).length;
  const target = form.useKit === false ? 0 : lib.interactivePageTarget({ interactivity: form.interactivity, slideCount: outline.slides.length });
  if (interactive < target) {
    notes.push(
      `互動頁只有 ${interactive} 頁（封面不算），這份的互動設定要大約 ${target} 頁：再挑 ${target - interactive} 頁內容適合的，在 points 最後寫「互動：…」` +
        '（算錢、回本→試算；保守／預期／樂觀→情境切換；圖表、大數字→點了看原因或算法）。',
    );
  }
  if (form.useKit !== false && form.interactivity >= 2 && content.length >= 5 && !content.some(isHeavy)) {
    const names = heavy.slice(0, 6).map((s) => s.name).join('、');
    notes.push(`整份沒有大型互動（${names}…）。有算錢、比較情境、問觀眾的內容，挑一頁當那頁的主要元件；真的都不適合就不要硬塞。`);
  }
  if (form.webSearch) {
    // 只算投影片上會出現的（標題、重點）：research 裡次要的背景說法標著未查證沒關係，算進來提醒會永遠消不掉（2026-10-18 審查）
    const pages = outline.slides.map((s, i) => ([s.title, ...s.points].join('\n').match(/未查證/g) ?? []).length ? i + 1 : 0).filter(Boolean);
    if (pages.length) {
      notes.push(
        `第 ${pages.join('、')} 頁有標「未查證」的說法，這份允許上網：論點靠它的先用 WebSearch 查，查到就換成數字＋來源寫進 research；` +
          '查不到的不要當主要論點（改成試算並寫出算式，或寫明待用公司資料確認）；只是補充說明的，保留標註就好。',
      );
    }
  }
  return notes;
}

function skillNotesText(notes) {
  return notes.length ? `\n\nskill 品質提醒（給使用者看大綱之前先處理，改 outline.json 後執行 check-outline 再看一次）：\n${notes.map((n) => `  - ${n}`).join('\n')}` : '';
}

/** App 的解析器讀不懂回答：標記起來，answer 才知道要講「回答格式」。 */
function parsed(fn) {
  try {
    return fn();
  } catch (error) {
    if (!error.userFacing) error.parseError = true;
    throw error;
  }
}

async function answerOutline(W, state, lib, task, text, log) {
  const { deck } = state;
  const imageIds = deck.attachments.filter((a) => a.kind === 'image').map((a) => a.id);
  let outline = parsed(() => lib.parseOutline(text, imageIds));
  if (!outline.slides.length) fail('大綱裡沒有任何一頁。請照回答格式重寫。');
  // 最多 30 頁（Max 方案）：多的截掉並講清楚，不要等到 confirm 才擋（App 也是截到方案上限）
  if (outline.slides.length > MAX_SLIDES) {
    log.push(`大綱寫了 ${outline.slides.length} 頁，最多 ${MAX_SLIDES} 頁，第 ${MAX_SLIDES + 1} 頁以後先拿掉了（可以在 outline.json 調整）。`);
    outline = { ...outline, slides: outline.slides.slice(0, MAX_SLIDES) };
  }
  if (deck.form.useKit) outline = lib.normalizeOutlineComponents(outline);
  deck.outline = outline;
  deck.title = outline.title || deck.title;
  deck.stage = 'outline';
  const issues = deck.form.useKit ? lib.outlineIssuesToFix(outline, deck.form, deck.attachments) : [];
  if (issues.length && state.options.autoFix) {
    state.phase = 'outlinefix';
    await addTask(W, state, lib, { id: 'outlinefix', kind: 'outlinefix', issues: issues.map((i) => i.message), allowed: issues.map((i) => i.index) });
    log.push(
      `大綱有 ${issues.length} 個版面安排的問題，App 會請 AI 只調整那幾頁（只有被點名的頁改了才會採用）：\n${issues.map((i) => `  - 第 ${i.index + 1} 頁：${i.message}`).join('\n')}\n` +
        '注意：說明裡的 JSON 頁碼 index 是從 0 起算（封面是 0），上面的「第幾頁」是從 1 起算。',
    );
    return;
  }
  state.phase = 'confirm';
  const file = await writeOutlineFile(W, deck);
  const checked = !deck.form.useKit ? '（沒用元件庫，App 不做大綱檢查）' : issues.length ? '（大綱檢查有問題，但自動修正關閉）' : '（大綱檢查通過，不用調整）';
  log.push(`大綱完成（${outline.slides.length} 頁）${checked}。\n\n${outlineText(deck)}${skillNotesText(skillOutlineNotes(lib, deck))}\n\n給使用者看、確認或修改。要改就直接編輯 ${file}，改好（或不用改）執行：${CLI} confirm --dir "${W}"`);
}

async function answerOutlineFix(W, state, lib, task, text, log) {
  const { deck } = state;
  const fixed = parsed(() => lib.parseOutlineFix(text, deck.outline));
  const applied = lib.applyOutlineFix(deck.outline, fixed, { form: deck.form, attachments: deck.attachments, allowed: new Set(task.allowed) });
  deck.outline = applied.outline;
  state.phase = 'confirm';
  const file = await writeOutlineFile(W, deck);
  const pages = (list) => list.map((i) => `第 ${i + 1} 頁`).join('、');
  const summary = `${applied.changed.length ? `採用 ${pages(applied.changed)} 的調整` : '沒有採用任何調整'}${applied.rejected.length ? `；${pages(applied.rejected)} 沒採用（不是檢查點名的頁，或改了問題沒變少），保留原本的` : ''}`;
  log.push(`大綱檢查：${summary}。\n\n${outlineText(deck, { mark: new Set(applied.changed) })}${skillNotesText(skillOutlineNotes(lib, deck))}\n\n給使用者看、確認或修改。要改就直接編輯 ${file}，改好（或不用改）執行：${CLI} confirm --dir "${W}"`);
}

/**
 * 手改的圖片說明：只留使用者附的圖片、字串、300 字內（跟 parseOutline 一樣）。
 * 櫃台最多收 500 字，超過的話這份匯入 App 之後每個 AI 修改都會被擋（2026-10-18 審查）。
 */
function cleanImageNotes(raw, deck) {
  if (!raw || typeof raw !== 'object') return deck.outline.imageNotes;
  const images = new Set(deck.attachments.filter((a) => a.kind === 'image').map((a) => a.id));
  return Object.fromEntries(Object.entries(raw).filter(([id, note]) => images.has(id) && typeof note === 'string').map(([id, note]) => [id, note.slice(0, 300)]));
}

/** 讀使用者（或 Claude）手改過的 outline.json，整理成 App 的大綱格式；confirm 與 check-outline 共用。 */
async function readEditedOutline(W, lib, deck, warnings) {
  let edited;
  try {
    edited = JSON.parse(await readFile(join(W, 'outline.json'), 'utf8'));
  } catch (error) {
    fail(`outline.json 不是合法的 JSON（${String(error.message).split('\n')[0]}），改好再執行一次。`);
  }
  if (!edited || typeof edited !== 'object' || !Array.isArray(edited.slides) || !edited.slides.length) fail('outline.json 的 slides 是空的。');
  const bad = edited.slides.findIndex((s) => !s || typeof s !== 'object');
  if (bad >= 0) fail(`outline.json 的第 ${bad + 1} 頁不是 { "title": …, "points": […] } 的格式。`);
  if (edited.slides.length > MAX_SLIDES) fail(`最多 ${MAX_SLIDES} 頁。`);
  const imageIds = new Set(deck.attachments.filter((a) => a.kind === 'image').map((a) => a.id));
  const outline = {
    ...deck.outline,
    title: String(edited.title ?? deck.outline.title).slice(0, 300),
    subtitle: String(edited.subtitle ?? deck.outline.subtitle ?? '').slice(0, 300),
    research: typeof edited.research === 'string' ? edited.research.slice(0, 12_000) : deck.outline.research,
    imageNotes: cleanImageNotes(edited.imageNotes, deck),
    sharedCss: typeof edited.sharedCss === 'string' ? lib.cleanSharedCss(edited.sharedCss) : deck.outline.sharedCss,
    slides: edited.slides.map((s, i) => {
      const points = (Array.isArray(s.points) ? s.points : []).map((p) => String(p).slice(0, 300)).filter(Boolean);
      if (points.length > 8) warnings.push(`第 ${i + 1} 頁有 ${points.length} 條重點，只留前 8 條（App 也是）。`);
      return {
        id: deck.outline.slides[i]?.id ?? `outline-edit-${i + 1}`,
        title: String(s.title ?? '').slice(0, 300),
        points: points.slice(0, 8),
        imageIds: (Array.isArray(s.imageIds) ? s.imageIds : []).filter((id) => imageIds.has(id)),
      };
    }),
  };
  return deck.form.useKit ? lib.normalizeOutlineComponents(outline) : outline;
}

/** 等確認時看手改過的 outline.json：App 的大綱檢查＋skill 品質提醒，都只提醒、不存檔。 */
async function cmdCheckOutline(lib, args) {
  const W = workDir(args);
  const state = await loadState(W);
  if (state.phase !== 'confirm') fail(`現在不是確認大綱的時候（目前：${phaseName(state)}）。`);
  const { deck } = state;
  const warnings = [];
  const outline = await readEditedOutline(W, lib, deck, warnings);
  const issues = deck.form.useKit ? lib.outlineIssuesToFix(outline, deck.form, deck.attachments) : [];
  const notes = skillOutlineNotes(lib, deck, outline);
  const lines = [...warnings.map((w) => `注意：${w}`)];
  if (issues.length) lines.push(`大綱檢查的提醒：\n${issues.map((i) => `  - 第 ${i.index + 1} 頁：${i.message}`).join('\n')}`);
  if (notes.length) lines.push(skillNotesText(notes).trim());
  console.log(lines.length ? lines.join('\n') : `outline.json 沒有要提醒的地方（${outline.slides.length} 頁）。給使用者看，確認後執行：${CLI} confirm --dir "${W}"`);
}

async function cmdConfirm(lib, args) {
  const W = workDir(args);
  await withLock(W, async () => {
    const state = await loadState(W);
    if (state.phase !== 'confirm') fail(`現在不是確認大綱的時候（目前：${phaseName(state)}）。`);
    const { deck } = state;
    const warnings = [];
    deck.outline = await readEditedOutline(W, lib, deck, warnings);
    // 表單的頁數不跟著大綱改（App 的大綱畫面加減頁也不改，提示詞的「頁數」那行照使用者原本選的）
    deck.title = deck.outline.title || deck.title;
    deck.slides = lib.slidesFromOutline(deck.outline);
    deck.stage = 'generating';
    state.phase = 'slides';
    for (const i of deck.slides.keys()) await addTask(W, state, lib, { id: slideTask(i), kind: 'slide', index: i });
    await saveState(W, state);
    console.log(`開始一頁一頁做（${deck.slides.length} 頁）。`);
    if (warnings.length) console.log(warnings.map((w) => `注意：${w}`).join('\n'));
    // 手改過的大綱 App 不會再檢查；這裡只提醒、不擋，給寫各頁時參考
    const reminders = deck.form.useKit ? lib.outlineIssuesToFix(deck.outline, deck.form, deck.attachments) : [];
    if (reminders.length) console.log(`大綱檢查的提醒（不擋，做那幾頁時留意）：\n${reminders.map((i) => `  - 第 ${i.index + 1} 頁：${i.message}`).join('\n')}`);
    await printNext(W, state);
  });
}

async function answerSlide(W, state, lib, browser, task, text, log) {
  const { deck } = state;
  const slide = deck.slides[task.index];
  const r = parsed(() => lib.extractSlideResult(text));
  if (!r.html.trim()) fail('回答裡找不到 HTML。請照回答格式（```html 區塊）重寫。');
  const shot = join(W, 'shots', `${pad(task.index + 1)}.jpg`);
  const label = `第 ${task.index + 1} 頁「${slide.title}」`;

  const noteWarning = deck.form.generateNotes && !r.notes && task.kind === 'slide' ? '\n（這頁沒有講者備註：回答裡少了 ```notes 區塊。要補就用 revise。）' : '';
  const errorText = (errors) => (errors.length ? `\n注意：${errors.slice(0, 3).join('；')}` : '');

  if (task.kind === 'slide') {
    slide.html = r.html;
    slide.speakerNotes = r.notes || slide.speakerNotes;
    slide.status = 'success';
    const { issues, errors } = await checkSlide(lib, browser, deck, task.index, r.html, shot);
    if (issues.length && state.options.autoFix) {
      await addTask(W, state, lib, { id: `fix-${pad(task.index + 1)}`, kind: 'fix', index: task.index, before: r.html, beforeIssues: issues, note: lib.autoFixNote(issues) });
      log.push(`${label}做好了，自動檢查找到 ${issues.length} 個問題（App 會請 AI 修一次）：\n${issueLines(issues)}${errorText(errors)}\n截圖：${shotText(shot)}${noteWarning}`);
    } else log.push(`${label}做好了${issues.length ? `（有 ${issues.length} 個提醒，自動修正關閉）：\n${issueLines(issues)}` : '，檢查通過。'}${errorText(errors)}\n截圖：${shotText(shot)}${noteWarning}`);
    return;
  }

  if (task.kind === 'fix') {
    const { issues: after, errors } = await checkSlide(lib, browser, deck, task.index, r.html, shot + '.fix.jpg');
    if (lib.lintScore(after) < lib.lintScore(task.beforeIssues)) {
      acceptRevision(slide, r.html, r.notes, '自動修正', lib.MAX_SLIDE_HISTORY ?? 5);
      slide.autoFixed = task.beforeIssues.filter((i) => !after.some((a) => a.code === i.code)).map((i) => i.code);
      await rm(shot, { force: true });
      if (existsSync(shot + '.fix.jpg')) await writeFile(shot, await readFile(shot + '.fix.jpg'));
      log.push(`${label}自動修正採用（問題 ${task.beforeIssues.length} → ${after.length}）${after.length ? `，還剩：\n${issueLines(after)}` : '。'}${errorText(errors)}`);
      await refreshSameSlide(W, state, lib, task.index, log);
    } else log.push(`${label}修了沒有比較好（${task.beforeIssues.length} → ${after.length}），保留原本的（App 也是這樣）。${errorText(errors)}`);
    await rm(shot + '.fix.jpg', { force: true });
    return;
  }

  // revise：整份審查、看圖修正、使用者要求的修改，一律採用（App 一樣），但檢查結果給 Claude 參考
  const byUser = (task.sources ?? [task.source]).includes('user');
  const userChanged = byUser || (state.userRevised ?? []).includes(task.index);
  const { issues, errors } = await checkSlide(lib, browser, deck, task.index, r.html, shot, { userChanged });
  const changed = acceptRevision(slide, r.html, r.notes, task.reason, lib.MAX_SLIDE_HISTORY ?? 5);
  if (changed && byUser) state.userRevised = [...new Set([...(state.userRevised ?? []), task.index])];
  for (const key of ['review', 'visual']) {
    const rec = deck[key];
    if ((task.sources ?? [task.source]).includes(key) && rec) rec.pages = rec.pages.map((p) => (p.index === task.index ? { ...p, fixed: true } : p));
  }
  log.push(`${label}${changed ? '已修改' : '內容跟原本一樣，沒有變'}（${task.reason}）${issues.length ? `。檢查還有：\n${issueLines(issues)}` : '，檢查通過。'}${errorText(errors)}\n截圖：${shotText(shot)}`);
  if (changed) await refreshSameSlide(W, state, lib, task.index, log);
}

async function answerReview(W, state, lib, task, text, log) {
  const { deck } = state;
  const review = parsed(() => lib.parseReview(text, htmlsOf(deck)));
  const key = task.kind === 'review' ? 'review' : 'visual';
  const name = key === 'review' ? '整份審查' : '看圖修正';
  deck[key] = { at: new Date().toISOString(), summary: review.summary, pages: review.pages.map((p) => ({ index: p.index, problem: p.problem, fixed: false })) };
  const shots = new Map((task.shots ?? []).map((s) => [s.index, s.file]));
  for (const p of review.pages) {
    const slide = deck.slides[p.index];
    if (!slide?.html) continue;
    // 這頁已經有修改在排隊（例如使用者剛要求改）：合併成一個，不要兩個工作拿同一個舊版各改各的
    const queued = state.pending.find((t) => t.kind === 'revise' && t.index === p.index);
    if (queued) {
      queued.note = `${queued.note}\n\n另外：${key === 'review' ? lib.reviewFixNote(p) : lib.visualFixNote(p)}`;
      queued.sources = [...new Set([...(queued.sources ?? [queued.source]), key])];
      queued.before = slide.html;
      // 看圖修正的說明寫著「附圖是這一頁目前的樣子」：合併時也要帶上照片（2026-10-18 審查）
      if (key === 'visual' && shots.get(p.index)) queued.shot = shots.get(p.index);
      await addTask(W, state, lib, queued);
      // 重出說明會刪掉舊的回答檔：講清楚要重寫，不然送的時候只會看到「找不到回答檔」
      log.push(`${queued.id} 的說明已經併入${name}的建議並更新（舊的回答檔已刪），照新的說明重寫再送。`);
      continue;
    }
    await addTask(W, state, lib, {
      id: `${key}-fix-${pad(p.index + 1)}`,
      kind: 'revise',
      source: key,
      index: p.index,
      before: slide.html,
      note: key === 'review' ? lib.reviewFixNote(p) : lib.visualFixNote(p),
      reason: `${name}：${p.problem}`,
      ...(key === 'visual' && shots.get(p.index) ? { shot: shots.get(p.index) } : {}),
    });
  }
  log.push(`${name}：${review.summary || '（沒有總結）'}\n${review.pages.length ? review.pages.map((p) => `  - 第 ${p.index + 1} 頁：${p.problem}`).join('\n') : '  沒有要改的頁。'}`);
}

/**
 * 送回答。可以一次送好幾個（answer --dir … slide-02 slide-03 slide-04）：共用一個檢查用的瀏覽器，
 * 少開幾次瀏覽器、少跑幾輪指令（2026-10-17 skill 加速：一頁一輪「讀說明→寫→送」，10 頁要 10 分鐘）。
 * 照順序一個一個處理，某一個有問題就停在那裡，前面送成功的照樣算數。
 */
async function cmdAnswer(lib, args) {
  const W = workDir(args);
  // 重複的編號只送一次（2026-10-18 審查）
  const ids = [...new Set(args._.slice(1))];
  if (!ids.length) fail('要寫工作編號，例如 answer --dir … slide-03（可以一次送好幾個：slide-03 slide-04）。');
  if (ids.length > 1 && args.file && args.file !== true) fail('--file 只能配一個工作編號。');
  let browser = null;
  const getBrowser = async () => (browser ??= await launchBrowser());
  try {
    for (const [n, id] of ids.entries()) {
      try {
        await answerOne(lib, W, args, id, getBrowser, n === ids.length - 1, ids.length > 1);
      } catch (error) {
        if (n > 0 && error.userFacing) {
          error.message = `${ids.slice(0, n).join('、')} 已經送出。${id}：${error.message}` +
            (n < ids.length - 1 ? `\n還沒送：${ids.slice(n + 1).join('、')}` : '');
        }
        throw error;
      }
    }
  } finally {
    await browser?.close();
  }
}

async function answerOne(lib, W, args, id, getBrowser, last, batch) {
  await withLock(W, async () => {
    const state = await loadState(W);
    const task = state.pending.find((t) => t.id === id);
    // 一次送好幾個、中斷後重跑同一個指令：已經送過的略過，繼續送後面的（不要卡在第一個送過的）
    if (!task && batch) {
      console.log(`${id} 已經送過（不在待做清單），略過。`);
      if (last && state.phase !== 'confirm') await printNext(W, state);
      return;
    }
    if (!task) fail(`沒有待做的工作 ${id}。目前待做：${state.pending.map((t) => t.id).join('、') || '（沒有）'}`);
    // 回答檔照這次的工作資料夾算（資料夾搬家、改名後，state.json 裡記的舊絕對路徑會指到別處；2026-10-18 審查）
    const file = args.file && args.file !== true ? resolve(args.file) : join(W, 'answers', `${id}.md`);
    if (!existsSync(file)) fail(`找不到回答檔 ${file}。`);
    // 這頁在說明產生之後又被別的工作改過：照舊版寫的回答會蓋掉新內容（App 也會擋：jobs.ts 頁面變了就不採用）
    if (editsSlide(task) && state.deck.slides[task.index]?.html !== task.before) {
      const log = [];
      if (task.kind === 'fix') {
        state.pending = state.pending.filter((t) => t !== task);
        log.push(`第 ${task.index + 1} 頁在這次自動修正之前已經被改過，${id} 取消（針對的是舊版的問題）。`);
      } else {
        task.before = state.deck.slides[task.index].html;
        await addTask(W, state, lib, task);
      }
      await saveState(W, state);
      if (task.kind === 'fix') {
        console.log(log.join('\n'));
        await printNext(W, state);
        return;
      }
      fail(`第 ${task.index + 1} 頁在這份說明產生之後又被改過，照舊內容寫的回答會蓋掉新的修改。說明已經更新成最新內容（${task.promptFile}），請照新的說明重寫回答再送一次。`);
    }
    const text = await readFile(file, 'utf8');
    const log = [];
    // 先把這個工作拿掉：審查、看圖修正會新增同名以外的工作，大綱檢查會新增 outlinefix
    state.pending = state.pending.filter((t) => t.id !== id);
    try {
      if (task.kind === 'outline') await answerOutline(W, state, lib, task, text, log);
      else if (task.kind === 'outlinefix') await answerOutlineFix(W, state, lib, task, text, log);
      else if (task.kind === 'review' || task.kind === 'visual') await answerReview(W, state, lib, task, text, log);
      else await answerSlide(W, state, lib, await getBrowser(), task, text, log);
    } catch (error) {
      // App 的解析器讀不懂回答：工作還在待做（state 沒存），講清楚要怎麼寫。
      // 其他錯誤（瀏覽器當掉、檔案不見）照實丟出去，不要說成「回答格式不對」（2026-10-18 審查）
      if (!error.parseError) throw error;
      fail(`${String(error.message).split('\n')[0]}\n回答格式：${ANSWER_FORMAT[task.kind]}\n工作 ${id} 還在待做，改好回答再送一次。`);
    }
    // 大綱階段不自動往下（要等使用者確認）
    if (task.kind !== 'outline' && task.kind !== 'outlinefix' && !state.pending.length) await advance(W, state, lib, await getBrowser(), log);
    await saveState(W, state);
    console.log(log.join('\n\n'));
    // 一次送好幾個：下一步只在最後印一次
    if (last && state.phase !== 'confirm') await printNext(W, state);
  });
}

async function cmdRevise(lib, args) {
  const W = workDir(args);
  const n = Number(args._[1]);
  const note = args.note;
  if (!n || !note || note === true) fail('用法：revise --dir … <第幾頁> --note "要怎麼改" [--self]');
  // --self：Claude 自己看截圖、檢查結果發現要改（不是使用者要求）：不算使用者改過，之後照樣檢查元件有沒有照大綱
  //（2026-10-18 審查：原本一律記成使用者要求，自己修時換掉元件也不會被抓）
  const source = args.self ? 'claude' : 'user';
  await withLock(W, async () => {
    const state = await loadState(W);
    const total = state.deck.slides.length;
    if (!total) fail('大綱還沒確認，還沒有頁可以改。');
    if (!Number.isInteger(n) || n < 1 || n > total) fail(`沒有第 ${args._[1]} 頁（這份共 ${total} 頁）。`);
    const slide = state.deck.slides[n - 1];
    if (!slide.html) fail(`第 ${n} 頁還沒做好，先完成 ${slideTask(n - 1)} 再改。`);
    // 同一頁已經有修改在排隊（使用者再補一句、或整份審查也要改這頁）：合併成一個，一次改完，不會互相蓋掉
    const queued = state.pending.find((t) => t.kind === 'revise' && t.index === n - 1);
    if (queued) {
      queued.note = `${queued.note}\n\n另外：${note}`;
      queued.sources = [...new Set([...(queued.sources ?? [queued.source]), source])];
      queued.before = slide.html;
      await addTask(W, state, lib, queued);
      console.log(`第 ${n} 頁已經有一個修改在排隊（${queued.id}），這次的要求合併進去，一次改完。`);
    } else {
      // 自己看截圖要改的：說明附上這頁目前的截圖（跟看圖修正一樣），改畫面問題才看得到在改什麼
      const shot = join(W, 'shots', `${pad(n)}.jpg`);
      await addTask(W, state, lib, {
        id: `revise-${pad(n)}`, kind: 'revise', source, index: n - 1, before: slide.html, note,
        reason: args.self ? '看截圖後修改' : '依備註修改',
        ...(args.self && existsSync(shot) ? { shot } : {}),
      });
      console.log(`已排入第 ${n} 頁的修改（revise-${pad(n)}）。`);
    }
    if (state.phase === 'done') state.phase = 'visual';
    await saveState(W, state);
    await printNext(W, state);
  });
}

async function cmdSkip(lib, args) {
  const W = workDir(args);
  const id = args._[1];
  if (!id) fail('要寫跳過哪個工作，例如 skip --dir … fix-03（大綱和每一頁不能跳過）。');
  await withLock(W, async () => {
    const state = await loadState(W);
    const task = state.pending.find((t) => t.id === id);
    if (!task) fail(`沒有待做的工作 ${id}。`);
    if (task.kind === 'outline' || task.kind === 'slide') fail('大綱與每一頁不能跳過。');
    state.pending = state.pending.filter((t) => t.id !== id);
    const log = [`已跳過 ${id}。`];
    if (task.kind === 'outlinefix' && state.phase === 'outlinefix') {
      state.phase = 'confirm';
      const file = await writeOutlineFile(W, state.deck);
      log.push(`${outlineText(state.deck)}${skillNotesText(skillOutlineNotes(lib, state.deck))}\n\n給使用者看、確認或修改（${file}），然後執行：${CLI} confirm --dir "${W}"`);
    } else if (!state.pending.length) {
      const browser = await launchBrowser();
      try {
        await advance(W, state, lib, browser, log);
      } finally {
        await browser.close();
      }
    }
    await saveState(W, state);
    console.log(log.join('\n\n'));
    if (state.phase !== 'confirm') await printNext(W, state);
  });
}

function phaseName(state) {
  const PHASE = {
    outline: '寫大綱',
    outlinefix: '大綱檢查修正',
    confirm: '等使用者確認大綱',
    slides: `一頁一頁做（${progressText(state.deck)}）`,
    review: '整份審查',
    visual: '看截圖修正',
    done: '全部完成',
  };
  // 做完後再用 revise 修改：階段退回「看截圖修正」，改完才會回到完成；這時其實是在改指定的頁
  //（2026-10-17 skill 測試：關了看圖修正，revise 後卻印「目前：看截圖修正」）
  const revising = state.pending.length && state.pending.every((t) => t.kind === 'revise' && (t.sources ?? [t.source]).every((s) => s === 'user' || s === 'claude'));
  if (revising && state.phase === 'visual') return '修改指定的頁';
  return PHASE[state.phase] ?? state.phase;
}

async function printNext(W, state) {
  const { deck } = state;
  const lines = [`\n目前：${phaseName(state)}`];
  if (state.phase === 'confirm') lines.push(`等使用者確認大綱，然後執行：${CLI} confirm --dir "${W}"`);
  else if (state.phase === 'done' && !state.pending.length) lines.push(`執行：${CLI} build --dir "${W}"`);
  else if (state.pending.length) {
    const rules = [...new Set(state.pending.map((t) => basename(t.rulesFile)))];
    // 同一頁有兩個工作（例如 fix 還沒做、使用者又要求改）：要一個做完再做下一個，不能分給不同助手
    const samePage = (t) => t.index !== undefined && state.pending.some((o) => o !== t && o.index === t.index && editsSlide(o) && editsSlide(t));
    const clash = state.pending.some(samePage);
    // 審查、看圖修正會把建議併進同一頁排隊中的修改：有修改在排隊時，先做完修改再送審查（審查也才看得到最新的頁）
    const wholeAfterEdits = state.pending.some((t) => t.kind === 'review' || t.kind === 'visual') && state.pending.some(editsSlide);
    lines.push(`待做的工作（${state.pending.length} 個${state.pending.length > 1 ? (clash ? '；標「同一頁」的要一個做完再做下一個，其他可以分給助手同時做' : '，彼此獨立、可以分給助手同時做') : ''}）：`);
    for (const t of state.pending) {
      // 整份的工作（審查、看圖修正）要看整份，主對話做；分頁的助手看到也不要接（2026-10-18 測試：送出後的提示會引導助手去做）
      const whole = t.kind === 'review' || t.kind === 'visual' ? '［整份：主對話做］' : '';
      lines.push(`- ${t.id}：${KIND_LABEL[t.kind]}${t.index !== undefined ? `（第 ${t.index + 1} 頁「${deck.slides[t.index]?.title ?? deck.outline?.slides[t.index]?.title ?? ''}」）` : ''}${samePage(t) ? '［同一頁］' : ''}${whole}`);
    }
    if (wholeAfterEdits) lines.push('先把 fix／revise 做完、送出，再送 review／visual。');
    lines.push(`說明：${join(W, 'prompts')}\\<工作編號>.md；背景規則：${rules.map((r) => join(W, 'prompts', r)).join('、')}（同一個檔讀過就不用再讀）`);
    lines.push(`回答寫到 ${join(W, 'answers')}\\<工作編號>.md，再執行 ${CLI} answer --dir "${W}" <工作編號>（寫好幾個可以一次送：<編號1> <編號2> …）`);
  }
  console.log(lines.join('\n'));
}

async function cmdNext(lib, args) {
  const W = workDir(args);
  await printNext(W, await loadState(W));
}

async function cmdStatus(lib, args) {
  const W = workDir(args);
  const state = await loadState(W);
  const { deck } = state;
  console.log(`主題：${deck.form.topic}\n風格：${deck.form.visualStyle}\n階段：${phaseName(state)}`);
  if (deck.outline) console.log(`\n${outlineText(deck)}`);
  if (deck.slides.length) {
    console.log('\n每一頁：');
    for (const [i, s] of deck.slides.entries()) console.log(`  ${i + 1}. ${s.title}：${s.html ? '完成' : '還沒做'}${s.pendingCompare ? `（${s.pendingCompare}）` : ''}`);
  }
  await printNext(W, state);
}

async function cmdBuild(lib, args) {
  const W = workDir(args);
  await withLock(W, async () => {
    const state = await loadState(W);
    const { deck } = state;
    const done = deck.slides.filter((s) => s.html);
    if (!done.length) fail('還沒有做好的頁。');
    if (state.pending.length && !args.force) fail(`還有 ${state.pending.length} 個待做的工作（${state.pending.map((t) => t.id).join('、')}）。做完再輸出，或加 --force 先輸出目前的版本。`);
    // 全部頁面重新畫一次：最後的截圖＋檢查結果，做成總覽
    const browser = await launchBrowser();
    const rows = [];
    try {
      for (const [i, s] of deck.slides.entries()) {
        if (!s.html) continue;
        const shot = join(W, 'shots', `final-${pad(i + 1)}.jpg`);
        const { issues, errors } = await checkSlide(lib, browser, deck, i, s.html, shot, { userChanged: (state.userRevised ?? []).includes(i) });
        rows.push({ i, title: s.title, shot, flags: [...issues.map((x) => x.message.split('；')[0]), ...errors] });
      }
    } finally {
      await browser.close();
    }
    const now = new Date().toISOString();
    const final = lib.normalizeDeck({ ...deck, stage: state.pending.length ? 'generating' : 'ready', updatedAt: now });
    delete final.job;
    delete final.share;
    // 使用者在對話裡已經看過、確認過定稿：匯入 App 不要每頁都跳「修改前後對照」（舊版還在 history，App 的「還原」照樣能用）
    // 最後一次改動不是自動修正（之後又被審查、使用者改過），「已自動修正」的標記就不算數了（舊版程式留下的也一起清）
    final.slides = final.slides.map(({ pendingCompare, ...s }) => (pendingCompare && pendingCompare !== '自動修正' ? { ...s, autoFixed: undefined } : s));
    // 匯入 App 之後的上網設定照 App 的預設（見 new 的 appWebSearch）；舊的工作資料夾沒有記錄就照原本的
    if (typeof state.appWebSearch === 'boolean') final.form = { ...final.form, webSearch: state.appWebSearch };
    // 匯入 App 之後叫得動 AI 嗎：用 Max 方案照櫃台的規則檢查一次（圖片說明太長、單頁太大…，2026-10-18 審查）
    let appProblem = '';
    try {
      lib.validateRequest({ task: 'review', form: final.form, outline: sentOutline(final), htmls: final.slides.map((s) => s.html) }, lib.DEFAULT_PLANS.max);
    } catch (error) {
      appProblem = `\n⚠ 匯入 App 之後，AI 修改會被擋：${String(error.message).split('\n')[0]}。改好（例如用 revise 縮短那一頁）再 build 一次。`;
    }
    // 同名的檔是「另一份簡報」就不要蓋掉，加 (2)、(3)；是這一份（重新輸出）才覆蓋
    const base = safeName(args.name && args.name !== true ? args.name : deck.title || deck.form.topic);
    let name = base;
    for (let k = 2; ; k += 1) {
      const existing = join(state.out, `${name}-備份檔.json`);
      const other = existsSync(existing) ? await readFile(existing, 'utf8').then((t) => JSON.parse(t).decks?.[0]?.id !== deck.id, () => true) : false;
      if (!other) break;
      name = `${base} (${k})`;
    }
    const htmlFile = join(state.out, `${name}.html`);
    const backupFile = join(state.out, `${name}-備份檔.json`);
    const html = lib.renderPresentationToHtml(lib.toPresentation(final, { watermark: null }), { showControls: true, includeBranding: true, lang: lib.playerLang(final.form.language) });
    const backup = JSON.stringify({ format: lib.BACKUP_FORMAT, exportedAt: now, decks: [final] });
    lib.parseBackup(backup); // App「還原」讀得進去才算數
    await mkdir(state.out, { recursive: true });
    await writeFile(htmlFile, html);
    await writeFile(backupFile, backup);
    const report = join(W, 'report.html');
    const bad = rows.filter((r) => r.flags.length).length;
    await writeFile(
      report,
      `<!doctype html><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>${esc(deck.title)}・總覽</title>
<style>body{font:15px/1.5 system-ui,"PingFang TC","Noto Sans TC",sans-serif;margin:0;padding:20px;background:#f5f5f7;color:#1d1d1f}.g{display:grid;grid-template-columns:repeat(auto-fill,minmax(300px,1fr));gap:14px}
figure{margin:0;background:#fff;border-radius:12px;overflow:hidden;box-shadow:0 1px 3px rgba(0,0,0,.1)}figure.bad{outline:3px solid #ff9f0a}img{width:100%;display:block}figcaption{padding:8px 10px;font-size:13px}.f{color:#b25000}.ok{color:#248a3d}</style>
<h1>${esc(deck.title)}</h1><p>${rows.length} 頁，${bad ? `${bad} 頁有提醒` : '全部通過檢查'}</p><div class="g">${rows
        .map((r) => `<figure class="${r.flags.length ? 'bad' : ''}"><img src="shots/${basename(r.shot)}"><figcaption><b>${r.i + 1}. ${esc(r.title)}</b><br>${r.flags.length ? `<span class="f">${esc(r.flags.join('；'))}</span>` : '<span class="ok">通過</span>'}</figcaption></figure>`)
        .join('')}</div>`,
    );
    const mb = (n) => (n < 1024 * 1024 ? `${Math.max(1, Math.round(n / 1024))} KB` : `${(n / 1024 / 1024).toFixed(1)} MB`);
    const missing = deck.slides.map((s, i) => (s.html ? null : i + 1)).filter(Boolean);
    const partial = missing.length || state.pending.length
      ? `\n⚠ 這是半成品：${missing.length ? `第 ${missing.join('、')} 頁還沒做；` : ''}${state.pending.length ? `還有 ${state.pending.map((t) => t.id).join('、')} 沒做。` : ''}做完再 build 一次會覆蓋這份。`
      : '';
    const interactions = deck.slides
      .map((s, i) => (s.html ? [i + 1, interactionsOf(lib, s.html)] : null))
      .filter((x) => x && x[1].length)
      .map(([n, list]) => `  第 ${n} 頁：${list.join('、')}`)
      .join('\n');
    console.log(`輸出完成（${done.length} 頁${bad ? `，${bad} 頁有提醒` : '，全部通過檢查'}）${name !== base ? `（同名的是另一份簡報，這份改叫「${name}」）` : ''}：${partial}${appProblem}
- 直接播放：${htmlFile}（${mb(Buffer.byteLength(html))}）
- App 還原用的備份檔：${backupFile}（${mb(Buffer.byteLength(backup))}）
- 每頁截圖總覽：${report}（每頁最後的樣子：${join(W, 'shots')}\\final-NN.jpg）
${rows.filter((r) => r.flags.length).map((r) => `  第 ${r.i + 1} 頁：${r.flags.slice(0, 3).join('；')}`).join('\n')}
播放時才看得到的互動（截圖都是全部出現後的樣子）：
${interactions || '  （沒有）'}`);
  });
}

function help() {
  console.log(`光點簡報指令（${CLI}）
  spec                                 表單欄位、預設值、風格清單
  new --form 表單.json [--attach 檔案|檔案] [--out 輸出資料夾] [--no-autofix] [--no-review] [--no-visual]
                                       （--no-autofix 連大綱檢查修正一起關）
  attach --dir 工作資料夾 檔案…        寫大綱前加附件
  next --dir 工作資料夾                下一步要做什麼
  answer --dir 工作資料夾 工作編號… [--file 回答檔]   可以一次送好幾個
  check-outline --dir 工作資料夾       改完 outline.json 再檢查一次（只提醒、不存檔）
  confirm --dir 工作資料夾             使用者確認（或改好 outline.json）後開始做每一頁
  revise --dir 工作資料夾 頁碼 --note "要怎麼改" [--self]   --self：不是使用者要求、是你自己看了要改
  skip --dir 工作資料夾 工作編號       跳過審查／修正（大綱與每一頁不能跳過）
  status --dir 工作資料夾
  build --dir 工作資料夾 [--name 檔名] [--force]
  unlock --dir 工作資料夾              確定沒有指令在跑、卻一直說被鎖住時用`);
}

async function cmdUnlock(lib, args) {
  const W = workDir(args);
  const lock = join(W, '.lock');
  const owner = await lockOwner(lock);
  if (owner && alive(owner) && !args.force) fail(`程式編號 ${owner} 還在跑，等它跑完。確定要解開加 --force。`);
  await rm(lock, { recursive: true, force: true });
  console.log('已解開。');
}

async function main() {
  const args = parseArgs(process.argv.slice(2));
  const cmd = args._[0];
  if (!cmd || cmd === 'help') return help();
  const commands = { spec: cmdSpec, new: cmdNew, attach: cmdAttach, next: cmdNext, answer: cmdAnswer, 'check-outline': cmdCheckOutline, confirm: cmdConfirm, revise: cmdRevise, skip: cmdSkip, status: cmdStatus, build: cmdBuild, unlock: cmdUnlock };
  const run = commands[cmd];
  if (!run) {
    help();
    fail(`沒有「${cmd}」這個指令。`);
  }
  const lib = await loadLib();
  await run(lib, args);
}

main().catch((error) => {
  // 程式自己講得出原因的（userFacing）只印原因；其他錯誤（瀏覽器當掉、檔案不見）印第一行＋怎麼看完整錯誤，
  // 不要因為訊息裡有中文路徑就只印一行（2026-10-18 審查）
  const message = String(error?.message ?? error);
  if (process.env.DECK_DEBUG) console.error(error);
  else if (error?.userFacing) console.error(`✗ ${message}`);
  else console.error(`✗ 程式出錯：${message.split('\n')[0]}\n（設 DECK_DEBUG=1 再跑一次看完整錯誤；檢查用的瀏覽器當掉、檔案被刪這類問題，重跑同一個指令通常就好）`);
  process.exitCode = 1;
});
