# 光點簡報 skill（spotlume-deck）

在 Claude Code 的對話裡說「幫我做一份 OO 的簡報」，Claude 就照光點簡報 App 的流程做出整份簡報：
表單 → 大綱 → 檢查 → 使用者確認 → 一頁一頁做 → 自動檢查修正 → 整份審查 → 看截圖修正 → 輸出。

輸出兩個檔：

- `.html`：瀏覽器直接打開播放（會動、可以點、有講者模式）。
- `-備份檔.json`：光點 App（https://spotlume.web.app）「帳號 → 資料與備份 → 從備份還原」匯入。

內容由對話中的 Claude 寫，不另外呼叫 AI API。

## 安裝

需要 Node.js 20 以上。

1. 把這個資料夾放到 Claude Code 的個人 skill 資料夾，名稱用 `spotlume-deck`：
   - Windows：`C:\Users\<你>\.claude\skills\spotlume-deck\`
   - macOS／Linux：`~/.claude/skills/spotlume-deck/`
2. 在這個資料夾執行：

   ```
   npm install
   ```

3. 檢查用的瀏覽器：電腦有 Microsoft Edge 或 Google Chrome 就不用另外裝；都沒有的話執行 `npx playwright install chromium`（會下載上百 MB）。
4. 重新開 Claude Code，說「幫我做一份簡報」就會用到。

## 檔案

- `SKILL.md`：給 Claude 看的流程說明。
- `cli.mjs`：指令程式（Claude 用 Bash 執行）。
- `dist/lib.mjs`：光點 App 的程式（提示詞、元件庫、檢查、匯出），打包日期 2026-10-19。
- `dist/browser.js`：讀附件（Word、PowerPoint、Excel、PDF、ZIP）用。

做好的簡報預設放在「文件\光點簡報」，工作資料夾在它底下的「製作中」。
