"""記住本機語意計算速度；讀寫失敗不影響工作。"""
import datetime
import hashlib
import json
import math
import os
import platform
import tempfile
from file_replace import replace_file


MAX_SECONDS = 60       # 一段（一條）最多幾秒才採用記下的速度


def _machine():
    raw = platform.node() + platform.machine() + str(os.cpu_count())
    return hashlib.sha1(raw.encode('utf-8')).hexdigest()[:12]


def _path():
    import batch
    return os.path.join(batch.cache_dir(), '語意速度.json')


def _read(path):
    try:
        with open(path, encoding='utf-8') as f:
            data = json.load(f)
        return data if isinstance(data, dict) else {}
    except (OSError, ValueError, TypeError):
        return {}


def get(kind):
    try:
        entry = _read(_path()).get(_machine(), {}).get(kind, {})
        value = entry.get('每單位秒')
        # 每段超過 60 秒不像真的（檔案被改壞）：不用，照預設估
        return float(value) if isinstance(value, (int, float)) and not isinstance(value, bool) and math.isfinite(value) and 0 < value <= MAX_SECONDS else None
    except Exception:
        return None


def record(kind, seconds, units):
    temp = None
    try:
        if units < 20:
            return
        value = float(seconds) / units
        if not math.isfinite(value) or value <= 0 or value > MAX_SECONDS:
            return
        path = _path()
        data = _read(path)
        machine = _machine()
        entries = data.get(machine)
        if not isinstance(entries, dict):
            entries = {}
            data[machine] = entries
        old = get(kind)
        if old is not None:
            value = old * 0.5 + value * 0.5
        entries[kind] = {'每單位秒': value, '單位數': units, '更新': datetime.date.today().isoformat()}
        os.makedirs(os.path.dirname(path), exist_ok=True)
        with tempfile.NamedTemporaryFile(mode='w', encoding='utf-8', dir=os.path.dirname(path), delete=False) as f:
            temp = f.name
            json.dump(data, f, ensure_ascii=False, indent=2)
            f.write('\n')
        replace_file(temp, path)
        temp = None
        return True
    except Exception:
        pass
    finally:
        if temp:
            try:
                os.unlink(temp)
            except OSError:
                pass


def duration(seconds):
    if not isinstance(seconds, (int, float)) or not math.isfinite(seconds) or seconds > 7 * 24 * 3600:
        return '估不出來'
    if seconds < 60:
        return '不到 1 分鐘'
    return '約 %d 分鐘' % math.ceil(seconds / 60)
