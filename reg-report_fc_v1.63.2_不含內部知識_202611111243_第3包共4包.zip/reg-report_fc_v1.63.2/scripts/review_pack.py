# -*- coding: utf-8 -*-
"""
第 1.5 步：把候選與異動打包成「審查包」給 AI 看。

程式篩（相似、關鍵詞、句子、文脈、語意、跨本）只會「列」，不會「判」。
這支把每一筆候選、每一處異動連同前後文一次組好，讓 AI 判斷時「候選段全文、
異動段新舊文、兩邊的前後文」三樣一起看，不必自己東翻西找。

AI 只寫判斷，不填「要改嗎」「改成什麼」——那兩欄仍是人的決定，見 review-import。
"""

import csv
import glob
import io
import json
import os
import re
import unicodedata
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
REGDIFF = os.path.join(HERE, "regdiff")
for _path in (HERE, REGDIFF):
    if _path not in sys.path:
        sys.path.insert(0, _path)

import decision_table as dt
import notices as nt
from _common import (SUPPORTED_EXTS, build_hierarchy, diff_runs, format_scope, locate,
                     display_ref, place, read_paragraphs, read_paragraphs_with_kinds, read_paragraphs_with_metadata,
                     structure_paragraphs, structure_text, strip_numbering_prefix)


class ReviewPackError(ValueError):
    pass


# ---------------------------------------------------------------------------
# 前後文範圍
# ---------------------------------------------------------------------------

# 要點的「一、」那一層 build_hierarchy 寫成「第三點」（見 _common._use_point_refs），一樣當成一款
_CLAUSE_KEY_RE = re.compile(r"^(.*?款|第[^第]+?點)")


def _clause_key(ctx):
    """從 ref 取出「…款」為止的前綴，款頭本身跟它底下的目共用同一把鑰匙。"""
    match = _CLAUSE_KEY_RE.match(ctx.get("ref") or "")
    return match.group(1) if match else ""


def _same(ctx, key, val):
    if key == "article":
        return ctx.get("article") == val
    return _clause_key(ctx) == val


_MAX_WINDOW = 15  # 包大小保底：不管哪一種規則，單側最多只給 15 段


def context_range(contexts, index0, fallback=3, max_window=_MAX_WINDOW):
    """算前後文範圍：有條→整條＋條外前後各 1 段；無條有款→整款＋款外前後各 1 段；
    都沒有→前後各 fallback 段。回傳 (start0, end0, label)：start0/end0 給 range() 直接用
    （end0 不含）；label 是實際套用的規則，要印在「前後文（新版，<label>）」那行。

    max_window：單側最多幾段（預設 _MAX_WINDOW＝15）。write_pack 遇到「單一候選
    區塊本身就超過 --max-chars」時會傳 3 進來重算，把那個候選的前後文縮小
    （見 write_pack 的 _SHRUNK_WINDOW）。

    「整款」判斷靠 ref 裡「…款」那段前綴（_clause_key）。款底下的「1.」「2.」子標題
    現在由 build_hierarchy 標成「點」層（ref 帶「第1點」），掃款不會再被它截斷；
    但仍有真的沒有任何條號的段落（例如條款之外的獨立小標），ref 是空字串、
    level「其他」，掃款的迴圈碰到就會停下來。停在那種段落時把 label 換成
    「同一群（款內）」，讓人知道這個範圍可能沒有涵蓋到整款、只是同一小群。
    """
    ctx = contexts[index0]
    if ctx.get("article"):
        key, val = "article", ctx["article"]
        label = "整條＋前後各 1 段"
        start = index0
        while start > 0 and _same(contexts[start - 1], key, val):
            start -= 1
        end = index0 + 1
        while end < len(contexts) and _same(contexts[end], key, val):
            end += 1
        start0, end0 = max(0, start - 1), min(len(contexts), end + 1)
    elif ctx.get("level") in ("款", "目"):
        key, val = "clause_key", _clause_key(ctx)
        label = "整款＋前後各 1 段"
        start = index0
        while start > 0 and _same(contexts[start - 1], key, val):
            start -= 1
        end = index0 + 1
        while end < len(contexts) and _same(contexts[end], key, val):
            end += 1
        cut_short = ((start > 0 and not contexts[start - 1].get("ref")) or
                    (end < len(contexts) and not contexts[end].get("ref")))
        if cut_short:
            label = "同一群（款內）＋前後各 1 段"
        start0, end0 = max(0, start - 1), min(len(contexts), end + 1)
    else:
        label = "前後各 %d 段" % fallback
        start0 = max(0, index0 - fallback)
        end0 = min(len(contexts), index0 + fallback + 1)

    capped = False
    if index0 - start0 > max_window:
        start0 = index0 - max_window
        capped = True
    if (end0 - 1) - index0 > max_window:
        end0 = index0 + max_window + 1
        capped = True
    start0 = max(0, start0)
    end0 = min(len(contexts), end0)
    if capped:
        label += "（已截到前後各 %d 段）" % max_window
    return start0, end0, label


# ---------------------------------------------------------------------------
# 逐字標記新舊差異
# ---------------------------------------------------------------------------

def mark_diff(old_text, new_text):
    """把新舊文字的差異標成〔刪：x〕〔加：x〕，其餘照抄。"""
    out = []
    for kind, text in diff_runs(old_text or "", new_text or ""):
        if kind == "delete":
            out.append("〔刪：%s〕" % text)
        elif kind == "insert":
            out.append("〔加：%s〕" % text)
        else:
            out.append(text)
    return "".join(out)


# ---------------------------------------------------------------------------
# 讀某次 compare 的產出：候選、異動、新舊版全文
# ---------------------------------------------------------------------------

def staged_file_by_sha(inputs_dir, sha, preferred=None):
    """輸入/ 裡內容（SHA-256）等於 sha 的那一份留底；preferred 對得上就用它，找不到回 None。

    留底檔名會因角色前綴、舊排法、apply 另外留的一份而不同，而且同名的留底會被之後的
    stage_inputs 覆寫（finalize 在同一個產出資料夾留乾淨版、中途失敗的 compare 重跑），
    輸入指紋.json 也跟著改——檔名與輸入指紋都當不了憑據。憑據是決定表指紋檔記的 SHA：
    這張表是對哪一份算的，就只認那一份。finalize 的對位檢查與這裡的審查包共用這一支。
    """
    if not sha or not os.path.isdir(inputs_dir):
        return None
    if preferred and os.path.isfile(preferred) and dt.file_sha256(preferred) == sha:
        return preferred
    for name in sorted(os.listdir(inputs_dir)):
        path = os.path.join(inputs_dir, name)
        if os.path.isfile(path) and os.path.splitext(name)[1].lower() != ".json" \
                and dt.file_sha256(path) == sha:
            return path
    return None


def load_book(outdir):
    """讀 <outdir> 這次 compare（或 batch 某一本）的候選表、異動清單、新舊版全文。
    找不到該有的檔案就 ReviewPackError，不猜、不補。"""
    # 讀端一律走 locate：新排法（<outdir>/2_Log檔案、2_Log檔案）優先，找不到再看
    # 舊排法（檔案平鋪在 outdir）。這一步是接在 compare 後面跑的，使用者手上
    # 可能還有上一版程式產出的資料夾。
    csv_path = locate(outdir, "連帶決定表.csv")[0]
    changes_path = locate(outdir, "異動清單.json")[0]
    inputs_dir = locate(outdir, "輸入")[0]
    fingerprint_path = os.path.join(inputs_dir, "輸入指紋.json")
    if not os.path.isfile(csv_path):
        raise ReviewPackError("找不到連帶決定表：%s（請先跑 開始）" % csv_path)
    if not os.path.isfile(changes_path):
        raise ReviewPackError("找不到異動清單：%s（請先跑 開始）" % changes_path)
    if not os.path.isfile(fingerprint_path):
        raise ReviewPackError("找不到輸入指紋檔：%s" % fingerprint_path)

    try:
        rows = dt.read_table(csv_path)
    except dt.DecisionTableError as exc:
        raise ReviewPackError(str(exc))
    except (ValueError, UnicodeDecodeError, OSError) as exc:
        raise ReviewPackError("連帶決定表讀不出來（%s）；請跑 開始 重新比對" % exc)

    try:
        with io.open(changes_path, encoding="utf-8") as f:
            changes = json.load(f)
    except (ValueError, UnicodeDecodeError, OSError) as exc:
        raise ReviewPackError("異動清單.json 讀不出來（%s）；請跑 開始 重新比對" % exc)

    try:
        sidecar = dt.read_sidecar(dt.sidecar_path_for(csv_path))
    except dt.DecisionTableError as exc:
        raise ReviewPackError(str(exc))
    draft_name = (sidecar.get("草稿") or {}).get("檔名", "")
    if not draft_name:
        raise ReviewPackError("指紋檔沒有草稿檔名：%s" % dt.sidecar_path_for(csv_path))

    try:
        with io.open(fingerprint_path, encoding="utf-8-sig") as f:
            fingerprint = json.load(f)
    except (ValueError, UnicodeDecodeError, OSError) as exc:
        raise ReviewPackError("輸入指紋.json 讀不出來（%s）；請跑 開始 重新比對" % exc)
    # no 1：留底檔名照 SUPPORTED_EXTS 篩，不是只認 .docx。compare 早就吃得下
    # .txt／.md 了，這裡若只撿 .docx，草稿是 .txt 的那幾本會在第 1.5 步被擋成
    # 「找不到草稿檔」——使用者會以為檔案掉了，其實是這個步驟自己不認格式。
    # （角色、比對參數這些非檔名的鍵沒有支援的副檔名，自然被篩掉。）
    input_names = sorted(n for n in fingerprint
                         if os.path.splitext(n)[1].lower() in SUPPORTED_EXTS)
    roles = fingerprint.get("角色") or {}
    if roles.get("舊版"):
        # 新版留底（run_all.stage_inputs 的角色留底）：舊版直接照角色取，不用猜。
        # 草稿要取「新版_<草稿檔名>」而不是角色表上的「新版」：finalize 會拿 apply
        # 產出的乾淨版再 stage 一次，角色表的「新版」那時已經指向乾淨版了，但
        # review-pack 要看的仍然是這張決定表對應的那份草稿。
        old_name = roles["舊版"]
        draft_staged = "新版_" + draft_name
        if draft_staged not in fingerprint:
            draft_staged = roles.get("新版") or ""
        missing = [n for n in (old_name, draft_staged)
                   if not n or not os.path.isfile(os.path.join(inputs_dir, n))]
        if missing:
            raise ReviewPackError(
                "輸入/ 裡找不到角色留底的檔案：%s（請跑 開始 重新比對）"
                % "、".join(m or "（缺新版）" for m in missing))
        old_path = os.path.join(inputs_dir, old_name)
        draft_path = os.path.join(inputs_dir, draft_staged)
    else:
        # 這個功能之前產生的產出資料夾：留底照原檔名，只能用「哪一個不是草稿」去猜。
        # 猜得出來就往下走，但一定要講一聲——舊新同檔名時舊版早就被蓋掉了，
        # 這裡讀到的「舊版」其實是草稿，刪除段的前後文會整段對錯人。
        if draft_name not in input_names:
            raise ReviewPackError("輸入指紋.json 裡找不到草稿檔：%s" % draft_name)
        old_names = [n for n in input_names if n != draft_name]
        if len(old_names) == 0 and len(input_names) == 1:
            # batch 遇到「沒有草稿，用舊版當草稿」的本（見 batch.read_manifest 的「有草稿」欄），
            # 新舊版其實是同一個檔；舊式留底用 basename 當指紋鍵，同一個檔名只留一筆，
            # 輸入指紋.json 因此只剩一個輸入檔。這裡不當成缺檔，新舊版都指到同一份。
            old_names = [draft_name]
        elif len(old_names) != 1:
            # finalize 用同一個 outdir 再跑一次時，args.new_file 常常是 apply 產出的
            # 「新版_定稿_乾淨版.docx」，跟原本的草稿檔名不同，stage_inputs 會把它也留在
            # 輸入/ 底下，「輸入/」因此多出第三個輸入檔。這不是「舊版＋草稿」以外的第三本，
            # 是同一輪流程的終稿，先排除檔名含「定稿」「乾淨版」的檔（跟排除 draft_name
            # 是同一件事：都是「這不是要挑的舊版」），剩一個才用；還是不只一個才真的報錯。
            filtered = [n for n in old_names if "定稿" not in n and "乾淨版" not in n]
            if len(filtered) == 1:
                old_names = filtered
            else:
                raise ReviewPackError(
                    "輸入指紋.json 裡的輸入檔不是「舊版＋草稿」各一份：%s" % input_names)
        nt.notice(nt.REMINDER,
                  "這個產出資料夾是舊式留底（輸入指紋.json 沒有「角色」），舊版是用檔名猜的"
                  "（猜成 %s）%s；舊新同檔名時舊版其實早就被新版蓋掉了，"
                  "刪除段的前後文可能不是舊版的。要確定的話請跑 開始 重新比對"
                  % (old_names[0],
                     "，而且新舊版指到同一份" if old_names[0] == draft_name else ""),
                  "審查包")
        old_path = os.path.join(inputs_dir, old_names[0])
        draft_path = os.path.join(inputs_dir, draft_name)
    # 留底要是「這張決定表當初對的那一份」才能用：審查包的前後文、異動段的新舊文都從
    # 這兩份讀，留底被改過、被之後的 stage_inputs 蓋掉的話，AI 看到的是別的字，
    # 畫面上卻沒有任何一句話講過這件事。憑據是決定表指紋檔記的 SHA（舊版那一筆是
    # 這一版起才記的；更早的指紋檔沒有，退回比輸入指紋.json）。
    legacy = not roles.get("舊版")

    def resolve(label, path, anchor):
        want = (anchor or {}).get("SHA256")
        if want:
            found = staged_file_by_sha(inputs_dir, want, path)
            if found is None and legacy and label == "舊版" and os.path.isfile(path):
                # 舊式留底：舊新同檔名時舊版早就被新版蓋掉了，本來就找不到那一份；
                # 上面已經發過「舊版是用檔名猜的」提醒，照猜的那一份往下走。
                return path
            if found is None:
                raise ReviewPackError(
                    "輸入/ 裡找不到跟決定表指紋相符的%s留底（%s）：留底在比對之後被覆寫或"
                    "修改過，審查包不能用它；請跑 開始 重新比對" % (label, anchor.get("檔名") or ""))
            return found
        if not os.path.isfile(path):
            raise ReviewPackError("輸入/ 裡找不到%s留底：%s（請跑 開始 重新比對）" % (label, path))
        recorded = fingerprint.get(os.path.basename(path))
        if isinstance(recorded, str) and recorded and dt.file_sha256(path) != recorded:
            raise ReviewPackError(
                "輸入/ 的%s留底跟輸入指紋.json 對不上：%s。留底在比對之後被改過，"
                "審查包不能用它；請跑 開始 重新比對" % (label, os.path.basename(path)))
        return path

    draft_path = resolve("草稿", draft_path, sidecar.get("草稿"))
    old_path = resolve("舊版", old_path, sidecar.get("舊版"))
    try:
        # 連來源種類一起讀：審查包的條號要跟修正對照表一模一樣，
        # 表格儲存格在兩邊都不能被算成前一條的「第X項」。
        old_paragraphs, old_kinds = read_paragraphs_with_kinds(old_path)
        # 草稿連結構標記一起讀（同一份段落與種類）：每一段在第幾張表（v1.7.4，體檢判「重複」要分得出不同的表）
        new_paragraphs, new_kinds, new_meta = read_paragraphs_with_metadata(draft_path)
    except (ValueError, UnicodeDecodeError, OSError) as exc:
        raise ReviewPackError("草稿或舊版讀不出來（%s）；請跑 開始 重新比對" % exc)

    # 定義連動的精準來源留在 sidecar，不寫進人填的 CSV。載入後再掛回記憶體列，
    # review_pack 才能避開同段多個一般異動造成的錯配。
    definition_map = {}
    for entry in sidecar.get("定義來源") or []:
        if not isinstance(entry, dict):
            continue
        key = (str(entry.get("候選段次") or ""), entry.get("候選全文SHA256") or "")
        if key[1]:
            definition_map[key] = [dict(source) for source in (entry.get("來源") or [])
                                   if isinstance(source, dict)]
    for row in rows:
        key = (str(row.get("候選段次") or ""), dt.text_sha256(row.get("候選全文") or ""))
        if key in definition_map:
            row["_定義來源異動"] = definition_map[key]

    return {
        "rows": rows,
        "changes": changes,
        "old_paragraphs": old_paragraphs,
        "new_paragraphs": new_paragraphs,
        "old_contexts": build_hierarchy(old_paragraphs, old_kinds),
        "new_contexts": build_hierarchy(new_paragraphs, new_kinds),
        # 前後文給 AI 看的那一份：補上 Word 自動編號（「二、 合作機構篩選」），不然一整串款目
        # 看不出誰是第幾款。只拿來顯示；比對、指紋、候選全文照舊用原文
        "old_shown": structure_paragraphs(old_paragraphs, old_kinds),
        "new_shown": structure_paragraphs(new_paragraphs, new_kinds),
        # 每一段在第幾張 Word 表格（不在表格裡是 None）。位置（ref）只到條／款，表格裡的段落分不出是哪一張表
        "new_tables": [(m.get("table") or (None,))[0] if isinstance(m, dict) else None for m in new_meta],
        # 每一段是不是表格儲存格：報告把表格裡連續刪增的段收成一處（表格一列是好幾段）
        "old_cells": [str(kind) == "cell" for kind in old_kinds or ()],
        "new_cells": [str(kind) == "cell" for kind in new_kinds or ()],
        "draft_name": draft_name,
        "outdir": outdir,
        # 指紋檔整份帶著走：review-import 要拿裡面每一列的「候選全文SHA256」
        # 驗決定表上的候選全文有沒有被手改過。
        "sidecar": sidecar,
        "新訂": _is_new_rule(outdir),
    }


def _is_new_rule(outdir):
    """這一本是新訂規章嗎（比對時記在 輸入來源.json）。"""
    try:
        with io.open(locate(outdir, "輸入來源.json")[0], encoding="utf-8") as f:
            return bool(json.load(f).get("新訂"))
    except (OSError, ValueError, AttributeError):
        return False


# ---------------------------------------------------------------------------
# 候選列 ←→ 異動清單 對應
# ---------------------------------------------------------------------------

def _change_text_for_match(change):
    """narrow 用：刪除的異動只剩舊文，其餘看新文。"""
    if change.get("修改類型") == "刪除":
        return change.get("old_text") or ""
    return change.get("new_text") or ""


def _definition_source_matches(changes, row):
    """定義連動列先依 P5 的真實異動座標與文字指紋找來源。

    decision_table 把真實異動 ID 寫入「異動條文ID」，通常 _find_changes 已可找到；
    這一層仍先看「異動段次」與 P5 指紋，避免同條號多處異動或舊 ref 重複時取錯。
    """
    sources = [source for source in (row.get("_定義來源異動") or [])
               if isinstance(source, dict)]
    if not sources:
        return []
    out = []
    for source in sources:
        old_index, new_index = source.get("old_index"), source.get("new_index")
        old_sha, new_sha = source.get("old_text_sha256"), source.get("new_text_sha256")
        for change in changes or []:
            if old_index and change.get("old_index") != old_index:
                continue
            if new_index and change.get("new_index") != new_index:
                continue
            if old_sha and dt.text_sha256(change.get("old_text") or "") != old_sha:
                continue
            if new_sha and dt.text_sha256(change.get("new_text") or "") != new_sha:
                continue
            if not any(change is seen for seen in out):
                out.append(change)
    return out


def _definition_positions(row):
    """決定表的「異動段次」轉成新舊座標；舊 CSV 沒有就回空。"""
    out = []
    for piece in (row.get("異動段次") or "").split("；"):
        piece = piece.strip()
        match = re.match(r"^舊版\s*(\d+)$", piece)
        if match:
            out.append(("old_index", int(match.group(1))))
            continue
        if piece.isdigit():
            out.append(("new_index", int(piece)))
    return out


def _definition_position_matches(changes, row):
    """沒有指紋的舊 finding，仍優先用定義異動段次找，不再只靠固定標籤。"""
    positions = _definition_positions(row)
    if not positions:
        return []
    out = []
    for key, index in positions:
        for change in changes or []:
            if change.get(key) == index and not any(change is seen for seen in out):
                out.append(change)
    return out


class _ChangeIndex:
    """一本異動清單的查表（v1.55.1）。候選列 × 片段 × 異動逐筆掃，全改 2000 段要打包十幾分鐘；
    這裡掃一次、之後查表。每一格都照清單順序，查到的東西和順序跟逐筆掃一樣。"""

    def __init__(self, changes):
        self.changes = changes
        self.count = len(changes)
        self.by_ref, self.by_ids, self.by_id, self.by_pos, self.by_old_pos = {}, {}, {}, {}, {}
        self.new_indexes = set(c["new_index"] for c in changes if c.get("new_index"))
        self.old_indexes = set(c["old_index"] for c in changes if c.get("old_index"))
        for at, change in enumerate(changes):
            ref = change.get("ref") or ""
            if ref:
                self.by_ref.setdefault(ref, []).append(change)
            ids = frozenset(change.get("spec_ids") or [])
            self.by_ids.setdefault(ids, []).append(change)
            for one in ids:
                self.by_id.setdefault(one, []).append(at)
            if change.get("new_index"):
                self.by_pos.setdefault("段次 %d" % change["new_index"], change)
            elif change.get("old_index"):
                self.by_old_pos.setdefault("舊版段次 %d" % change["old_index"], change)


def _change_index(data):
    """data（一本）的查表：算一次留在 data 裡；清單換過或長度變了就重建。"""
    changes = data.get("changes") or []
    index = data.get("_異動查表")
    if index is None or index.changes is not changes or index.count != len(changes):
        index = data["_異動查表"] = _ChangeIndex(changes)
    return index


def _find_changes(changes, piece, summary_hint="", index=None):
    """回傳所有比對得上的異動清單項目（可能不只一筆）。

    比對順序：piece == change["ref"]，或 piece 用「、」拆開後跟 change["spec_ids"]
    比對（先找 set 完全相等，沒有再找交集非空），或 piece == "段次 %d" % new_index，
    最後是刪除型的 piece == "舊版段次 %d" % old_index。

    ref 這一階不保證唯一：巢狀「1.」「2.」子標題被 build_hierarchy 當成無法辨識的
    段落，同一款底下好幾個子群組的目次編號會從頭算起，ref 因此重複
    （例如兩組「(1)」都算成「…第一款(1)」）。這裡不去動 build_hierarchy，改用候選列的
    「異動摘要」（新文或舊文前面一截、可能結尾帶「…」）收斂：留下新文／舊文開頭
    對得上摘要的那幾筆；收斂後還是不只一筆，就整批回傳，讓每一筆各自變成一個
    「異動段」小節，交給人／AI 自己比對，不硬猜。

    spec_ids 這一階：有正式基準時決定表的「異動條文ID」是
    「、」.join(spec_ids)（見 baseline_release.change_label），例如
    「A-003、A-003-1」——piece 因此可能一次帶好幾個條文ID，要拆開比對，
    不能整串跟單一異動的 spec_ids 列表做成員比對（永遠對不上）。

    index：這份 changes 的 _ChangeIndex；沒給就現做一份（結果一樣，只是每次都掃一遍）。"""
    if index is None:
        index = _ChangeIndex(changes)

    def narrow(found):
        """好幾處對得上時用「異動摘要」收斂；收斂不了就全部交給人看，不挑第一處（B16）。"""
        if len(found) > 1 and summary_hint:
            hint = summary_hint[:-1] if summary_hint.endswith("…") else summary_hint
            narrowed = [ch for ch in found if hint and _change_text_for_match(ch).startswith(hint)]
            if narrowed:
                return narrowed
        return found

    # P5 定義連動的來源 ID 已是實際異動 ref。ref 不唯一時由 summary／段次收斂，
    # 不拿「定義變更」這類固定字當識別鍵。
    by_ref = list(index.by_ref.get(piece, ()))
    if by_ref:
        return narrow(by_ref)
    parts = set(p.strip() for p in piece.split("、") if p.strip()) if piece else set()
    if parts:
        # 同一條兩處異動（第一項、第三項）條文ID 一樣：以前一律對到第一處，
        # 第二處造成的候選拿到的新舊文、指紋都是第一處的
        exact = list(index.by_ids.get(frozenset(parts), ()))
        if exact:
            return narrow(exact)
        overlap = sorted(set(at for part in parts for at in index.by_id.get(part, ())))
        if overlap:
            return narrow([index.changes[at] for at in overlap])
    by_pos = index.by_pos.get(piece)
    if by_pos is not None:
        return [by_pos]
    # 刪除型異動沒有新版段次，決定表的「異動條文ID」寫的是「舊版段次 N」
    # （見 regdiff/run_all.step_duplicates）。少了這一階，無條號文件把一段整段刪掉
    # 之後，候選底下永遠印「找不到對應異動」。
    by_old_pos = index.by_old_pos.get(piece)
    if by_old_pos is not None:
        return [by_old_pos]
    return []


def _cross_outline_changes(ref, data):
    """跨本章節引用：依新舊目錄定位被引用單位及造成改號的同級增刪。"""
    import renumber
    old = data.get("old_shown") or data.get("old_paragraphs") or []
    new = data.get("new_shown") or data.get("new_paragraphs") or []
    if not old or not new:
        return []
    citations = renumber._outline_citations(ref)
    if not citations:
        return []
    old_units = renumber.outline_units(old)
    new_units = renumber.outline_units(new)
    mapping = renumber.plan_outline_map(old_units, new_units)
    selected_old, selected_new, inserted, deleted = [], [], [], []

    for citation in citations:
        numbers = dict((level, number) for level, number, _ in citation["parts"])
        level = "節" if numbers.get("節") else "章"
        if level == "節":
            candidates = [key for key in old_units if key[1] == numbers["節"]
                          and (not numbers.get("章") or key[0] == numbers["章"])]
        else:
            candidates = [(numbers.get("章"), 0)] if (numbers.get("章"), 0) in old_units else []
        # 未寫章號而同號節有多處，不能猜是哪一節。
        if len(candidates) != 1:
            continue
        target = candidates[0]
        mapped = mapping.get(target)
        selected_old.append(old_units[target][1])
        if mapped in new_units:
            selected_new.append(new_units[mapped][1])
        if mapped is None or mapped == target:
            continue
        if level == "節":
            old_siblings = [key for key in old_units if key[1] and key[0] == target[0]]
            new_siblings = [key for key in new_units if key[1] and key[0] == mapped[0]]
        else:
            old_siblings = [key for key in old_units if not key[1]]
            new_siblings = [key for key in new_units if not key[1]]
        used_new = set(value for value in mapping.values() if value is not None)
        for key in old_siblings:
            if old_units[key][1] < old_units[target][1] and mapping.get(key) is None:
                deleted.append(old_units[key][1])
        for key in new_siblings:
            if new_units[key][1] < new_units[mapped][1] and key not in used_new:
                inserted.append(new_units[key][1])

    out = []
    for change in data.get("changes") or []:
        oi, ni = change.get("old_index"), change.get("new_index")
        if (oi in selected_old or ni in selected_new
                or (not oi and ni in inserted)
                or (not ni and oi in deleted)):
            out.append(change)
    return out


def _cross_number_changes(ref, data):
    """跨本條、全文連號的點：沿用既有的新舊編號對應，找受影響的段及前面的增刪。"""
    import batch
    import renumber
    old = data.get("old_shown") or data.get("old_paragraphs") or []
    new = data.get("new_shown") or data.get("new_paragraphs") or []
    if not old or not new:
        return []
    items = batch._parse_numbers(ref, 0)
    if not items:
        return []
    old_scan, new_scan = renumber.scan(old), renumber.scan(new)
    kind = items[0]["kind"]
    if kind == "條":
        def article_positions(entries):
            return {renumber.normalize_article_no(e["article"]): e["index"]
                    for e in entries if e["level"] == "條" and e.get("article")}
        old_pos, new_pos = article_positions(old_scan), article_positions(new_scan)
        mapping = {}
        for key, value in renumber.plan_article_map(old, new).items():
            mapped = value.get("new") or value.get("merged_into")
            mapping[renumber.normalize_article_no(key)] = renumber.normalize_article_no(mapped) if mapped else None
        targets = [renumber.normalize_article_no("第%s條%s" % (
            item["num"], "之" + item["sub"] if item.get("sub") else "")) for item in items]
        old_boundaries = [e["index"] for e in old_scan if e["level"] in ("章", "節", "條")]
        new_boundaries = [e["index"] for e in new_scan if e["level"] in ("章", "節", "條")]
    else:
        if any(e["level"] == "條" for e in old_scan) or not renumber._points_run_through(old_scan):
            return []
        old_entries = [e for e in old_scan if e["level"] == "款" and e.get("written") is not None]
        new_entries = [e for e in new_scan if e["level"] == "款" and e.get("written") is not None]
        if len({e["written"] for e in old_entries}) != len(old_entries) or len({e["written"] for e in new_entries}) != len(new_entries):
            return []
        old_pos = {e["written"]: e["index"] for e in old_entries}
        new_pos = {e["written"]: e["index"] for e in new_entries}
        outline_map = renumber.plan_outline_map(renumber.outline_units(old), renumber.outline_units(new))
        points = renumber.plan_point_map(renumber.outline_points(old), renumber.outline_points(new), outline_map)
        mapping = {number: (target[1] if target else None) for (_, number), target in points.items()}
        targets = [batch._cited_number(item["num"]) for item in items]
        old_boundaries = [e["index"] for e in old_scan if e["level"] in ("章", "節", "款")]
        new_boundaries = [e["index"] for e in new_scan if e["level"] in ("章", "節", "款")]

    def span(positions, boundaries, key):
        start = positions[key]
        after = [pos for pos in boundaries if pos > start]
        return start, min(after) if after else float("inf")

    def inside(value, interval):
        return isinstance(value, int) and interval[0] <= value < interval[1]

    found = []
    used = set(value for value in mapping.values() if value is not None)
    for target in targets:
        if target not in old_pos:
            continue
        mapped = mapping.get(target)
        old_span = span(old_pos, old_boundaries, target)
        new_span = span(new_pos, new_boundaries, mapped) if mapped in new_pos else None
        removed = [span(old_pos, old_boundaries, key) for key in old_pos
                   if old_pos[key] < old_pos[target] and mapping.get(key) is None] if mapped and mapped != target else []
        added = [span(new_pos, new_boundaries, key) for key in new_pos
                 if new_pos[key] < new_pos[mapped] and key not in used] if new_span and mapped != target else []
        for change in data.get("changes") or []:
            oi, ni = change.get("old_index"), change.get("new_index")
            if (inside(oi, old_span) or (new_span and inside(ni, new_span))
                    or (not oi and any(inside(ni, interval) for interval in added))
                    or (not ni and any(inside(oi, interval) for interval in removed))):
                if not any(change is previous for previous in found):
                    found.append(change)
    return found


def changes_for_row(row, book, books=None):
    """把候選列的「異動條文ID」用「；」拆開，逐段找出對應的異動清單項目。
    有「X：」前綴且 X 在 books 裡就到 books[X] 找（跨本）；找不到的片段直接略過。
    回傳 [(book_name, change), ...]；book_name 本本是空字串，跨本是來源本名稱。
    一個片段可能對到不只一筆異動（見 _find_changes），每一筆都各佔一項。"""
    books = books or {}
    out = []
    raw = (row.get("異動條文ID") or "").strip()
    if not raw:
        return out
    # 摘要可能帶「【整條刪除】」前綴（決定表上給人看的標記）。這裡是拿摘要去跟
    # 條文原文做開頭比對，前綴不是原文的一部分，比對前一定要先拿掉。
    summary_hint = dt.strip_deleted_prefix((row.get("異動摘要") or "").strip())
    definition_linkage = "定義連動" in [s.strip() for s in (row.get("來源") or "").split("；")]
    if definition_linkage:
        # P5 的 in-memory 資料（批次流程）最精準；CSV 重讀後沒有私有鍵時用異動段次。
        matches = _definition_source_matches(book.get("changes") or [], row)
        if not matches:
            matches = _definition_position_matches(book.get("changes") or [], row)
        for match in matches:
            out.append(("", match))
        if matches:
            return out
    seen = set()
    for piece in raw.split("；"):
        piece = piece.strip()
        if not piece:
            continue
        book_name = ""
        ref = piece
        if "：" in piece:
            name, rest = piece.split("：", 1)
            if name in books:
                book_name = name
                ref = rest
            elif "跨本引用" in (row.get("來源") or ""):
                # 來源本不在這批時不能拿候選本的同編號異動頂替。
                continue
        data = books[book_name] if book_name else book
        index = _change_index(data)
        matches = _find_changes(index.changes, ref, summary_hint, index)
        if book_name and "跨本引用" in (row.get("來源") or ""):
            for extra in _cross_outline_changes(ref, data) + _cross_number_changes(ref, data):
                if not any(extra is found for found in matches):
                    matches.append(extra)
        for match in matches:
            if (book_name, id(match)) not in seen:
                seen.add((book_name, id(match)))
                out.append((book_name, match))
    return out


# ---------------------------------------------------------------------------
# 區塊文字
# ---------------------------------------------------------------------------

def _context_lines(paragraphs, index0, start0, end0, own_label, changed_set):
    lines = []
    for i in range(start0, end0):
        idx1 = i + 1
        if i == index0:
            lines.append("  %d　%s" % (idx1, own_label))
        elif idx1 in changed_set:
            lines.append("  %d　%s　※本段也有異動" % (idx1, paragraphs[i]))
        else:
            lines.append("  %d　%s" % (idx1, paragraphs[i]))
    return lines


def _change_context(change, data, max_window=_MAX_WINDOW):
    """回傳 (版本標籤, 段落, 層級脈絡, index0, start0, end0, 本本異動段次集合, 範圍標籤)。
    有新版段次就用新版；只有舊版段次（刪除）就用舊版，並標「（舊版）」。
    段落是顯示用的那一份（補上 Word 自動編號，見 load_book 的 *_shown），只拿來印前後文。"""
    if change.get("new_index"):
        idx0 = change["new_index"] - 1
        paragraphs, contexts = data.get("new_shown") or data["new_paragraphs"], data["new_contexts"]
        changed = _change_index(data).new_indexes
        version = "新版"
    else:
        idx0 = (change.get("old_index") or 1) - 1
        paragraphs, contexts = data.get("old_shown") or data["old_paragraphs"], data["old_contexts"]
        changed = _change_index(data).old_indexes
        version = "舊版"
    if idx0 < 0 or idx0 >= len(paragraphs):
        raise ReviewPackError(
            "異動清單 序號 %s 的段次 %d 超出草稿段數 %d，表和草稿對不上，請跑 開始 重新比對"
            % (change.get("序號"), idx0 + 1, len(paragraphs)))
    start0, end0, label = context_range(contexts, idx0, max_window=max_window)
    return version, paragraphs, contexts, idx0, start0, end0, changed, label


def _change_lines(change, data, heading, max_window=_MAX_WINDOW):
    version, paragraphs, contexts, idx0, start0, end0, changed, label = _change_context(
        change, data, max_window=max_window)
    old_text, new_text = change.get("old_text") or "", change.get("new_text") or ""
    # Word 自動編號補在前面（不在原文裡，也不是這次改的字，所以不進【刪】【增】標記）
    lines = [heading,
             "- 舊文：%s" % (structure_text(old_text, change.get("old_label") or "") if old_text
                             else "（無，新增段落）"),
             "- 新文：%s" % structure_text(mark_diff(old_text, new_text), change.get("new_label") or "")]
    focus = _focus_line(change)
    if focus:
        lines.append(focus)
    lines.append("- 前後文（%s，%s）：" % (version, label))
    lines += _context_lines(paragraphs, idx0, start0, end0, "※本段就是異動段", changed)
    return lines


def _focus_line(change):
    """一段裡寫了好幾款、只改了其中一款（diff_compare.refine_item_refs）：直接告訴 AI 是哪一款、
    那一款改前改後，整段幾款的長文不必自己逐字找。只落在新增的那一款（舊版沒有）也講。"""
    focus_old, focus_new = change.get("focus_old_text") or "", change.get("focus_new_text") or ""
    if not focus_new and not focus_old:
        return ""
    where = display_ref(change.get("ref") or change.get("old_ref") or "") or "段內其中一款"
    if focus_old and focus_new:
        return "- 這處修改只落在%s：「%s」改成「%s」" % (where, focus_old, mark_diff(focus_old, focus_new))
    if focus_new:
        return "- 這處修改只落在%s（新加的這一款）：「%s」" % (where, focus_new)
    return "- 這處修改只落在舊版的%s：「%s」" % (display_ref(change.get("old_ref") or "") or where, focus_old)


def _paren(ref, extra):
    """組「（ref，extra）」；ref 是空的（build_hierarchy 認不得的段落，例如「3. 電訪
    目的及內容：」這種巢狀阿拉伯數字子標題）就只印「（extra）」，不留一個空逗號。"""
    parts = [p for p in (ref, extra) if p]
    return "（%s）" % "，".join(parts)


def _candidate_change_heading(change, book_name=""):
    """book_name 非空表示這處異動來自跨本（見 changes_for_row 的 book_name），
    標題加「（來源本：<名>）」讓人／AI 一眼看出這段舊文、新文是哪一本的，不會誤以為
    是自己這本的異動。"""
    ref = change.get("ref") or change.get("scope") or ""
    if change.get("new_index"):
        pos = "新版段次 %d" % change["new_index"]
    else:
        pos = "舊版段次 %d，已刪除" % (change.get("old_index") or 0)
    heading = "### 異動段%s" % _paren(ref, pos)
    if book_name:
        heading += "（來源本：%s）" % book_name
    return heading


def _candidate_section_lines(row, book, max_window=_MAX_WINDOW):
    line = dt.line_of(row.get("候選段次"))
    if not line or line > len(book["new_paragraphs"]):
        return ["### 候選段（無法定位到草稿段落）",
                "- 全文：%s" % (row.get("候選全文") or "")]
    idx0 = line - 1
    ctx = book["new_contexts"][idx0] if idx0 < len(book["new_contexts"]) else {}
    ref = ctx.get("ref") or format_scope(ctx) or ""
    start0, end0, label = context_range(book["new_contexts"], idx0, max_window=max_window)
    changed = _change_index(book).new_indexes
    lines = ["### 候選段%s" % _paren(ref, "段次 %d" % line),
             "- 全文：%s" % (row.get("候選全文") or ""),
             "- 前後文（%s%s）：" % ("" if book.get("體檢") else "新版，", label)]
    lines += _context_lines(book.get("new_shown") or book["new_paragraphs"], idx0, start0, end0,
                            "※本段就是候選段", changed)
    return lines


def _candidate_block(n, row, book, books, max_window=_MAX_WINDOW):
    """組一個候選的 markdown 區塊。

    max_window：這個區塊裡每一段前後文單側最多幾段。預設 _MAX_WINDOW；
    write_pack 發現這個區塊本身就超過 --max-chars 時，會用 _SHRUNK_WINDOW（3）
    重組一次，並在結尾加一行說明前後文被縮過。"""
    header = "## R%d　候選段次 %s　來源：%s" % (
        n, row.get("候選段次") or "（無）", row.get("來源") or "")
    # 這一列是被「修改」「新增」還是「刪除」帶出來的，要判的事不一樣
    # （被刪除帶出來的，別章的平行條文多半也要一起刪），所以放進標題那一行。
    change_type = (row.get("修改類型") or "").strip()
    if change_type:
        header += "　修改類型：%s" % change_type
    relation = row.get("關係／分數") or ""
    if relation:
        header += "　關係：%s" % relation
    parts = [header]

    matches = changes_for_row(row, book, books)
    if not matches and book.get("體檢"):
        pass
    elif not matches:
        parts.append("（找不到對應異動，請看異動清單）")
    else:
        # 異動段的新舊文與前後文只寫在 LLM異動清單.md（每處一次）：以前每個候選都整段再印一次，
        # 同一處異動掛十幾個候選就印十幾次，審查包將近一半是重複的字
        parts.append("### 對應異動（新舊文與前後文在 %s）\n%s" % (
            "、".join(sorted(set(_change_list_file(name) for name, _ in matches))),
            "\n".join(_matched_change_lines(matches, book, books))))

    parts.append("\n".join(_candidate_section_lines(row, book, max_window=max_window)))
    import learned
    learned_phrases = learned.phrases()
    if learned_phrases:
        hint = learned.boilerplate_hint(row, book, learned_phrases)     # v1.20.0：以前判過〔套語命中〕的那一截字
        if hint:
            parts.append(hint)
    if book.get("體檢"):
        parts.append("### 要判的事\n這個內部引用指的是不是正確的那一處？請對照全文與前後文判斷。")
    else:
        parts.append("### 要判的事\n候選段是不是也該跟著這次的改動一起改？"
                     "三樣一起看：候選段全文、異動段新舊文（看異動清單的那個編號）、兩邊的前後文。")
    if max_window < _MAX_WINDOW:
        parts.append("（前後文已縮減：全文太長）")
    return "\n".join(parts)


def _change_list_file(book_name):
    """異動段寫在哪一份異動清單：本本是自己的，跨本是來源本的。"""
    return "%s的 LLM異動清單.md" % book_name if book_name else "本本的 LLM異動清單.md"


def change_number(change, data):
    """這處異動在它那一本的異動清單裡是 C 幾（跟 AI異動審查.csv 的異動ID 同一套）；找不到回 0。"""
    for index, item in enumerate(data.get("changes") or [], 1):
        if item is change:
            return index
    return 0


def _change_ref(book_name, change, data):
    """候選區塊裡的一行：C 編號＋位置＋改了什麼的一小段，讓 AI 不翻異動清單也知道是哪一處。"""
    number = change_number(change, data)
    heading = _candidate_change_heading(change, "")[len("### 異動段"):]     # 來源本已經寫在編號前面
    head = "%s%s" % (("%s C%d" % (book_name, number)) if book_name else "C%d" % number, heading)
    summary = (change.get("new_text") or change.get("old_text") or "").strip()
    if len(summary) > 40:
        summary = summary[:40] + "…"
    return "%s：%s" % (head, summary) if summary else head


def _implied_move(change, book):
    """只在相同文字的增刪兩端皆唯一時推定搬移，不修改異動資料。"""
    if change.get("移列") or not isinstance(book, dict):
        return None
    kind = change.get("修改類型")
    if kind not in ("刪除", "新增"):
        return None

    def normalized(item):
        key = "old_text" if item.get("修改類型") == "刪除" else "new_text"
        return "".join(strip_numbering_prefix((item.get(key) or "").lstrip()).split())

    value = normalized(change)
    if len(value) < 10 or not any(word in value for word in
            ("本章", "本節", "本款", "本點", "前項", "前條", "上開", "前述")):
        return None
    changes = book.get("changes") or []
    same = [c for c in changes if c.get("修改類型") == kind
            and not c.get("移列") and normalized(c) == value]
    other_kind = "新增" if kind == "刪除" else "刪除"
    matches = [c for c in changes if c.get("修改類型") == other_kind
               and not c.get("移列") and normalized(c) == value]
    if len(same) != 1 or same[0] is not change or len(matches) != 1:
        return None
    return {"方向": "移出" if kind == "刪除" else "移入",
            "對應段次": matches[0].get("new_index" if kind == "刪除" else "old_index"),
            "內容相同": True}


def _move_reminder(change, book):
    """以兩版全文的章節位置標出搬移後需要核對的相對指涉。"""
    implied = not change.get("移列")
    move = change.get("移列") or _implied_move(change, book)
    if not move or not isinstance(book, dict):
        return ""
    if move.get("方向") == "移出":
        old_index, new_index = change.get("old_index"), move.get("對應段次")
    elif move.get("方向") == "移入":
        old_index, new_index = move.get("對應段次"), change.get("new_index")
    else:
        return ""
    old_ctx, new_ctx = book.get("old_contexts") or [], book.get("new_contexts") or []
    op, np = book.get("old_paragraphs") or [], book.get("new_paragraphs") or []
    if not (isinstance(old_index, int) and isinstance(new_index, int)
            and 0 < old_index <= min(len(old_ctx), len(op))
            and 0 < new_index <= min(len(new_ctx), len(np))):
        return ""
    old, new = old_ctx[old_index - 1], new_ctx[new_index - 1]
    text = op[old_index - 1] + "\n" + np[new_index - 1]
    notes = []

    def location(contexts, paragraphs, index, level):
        key = contexts[index - 1].get(level) or ""
        if not key:
            return "第%d段（章節待核對）" % index
        for i in range(index - 1, -1, -1):
            if contexts[i].get("level") == ("章" if level == "chapter" else "節"):
                return paragraphs[i].strip() or key
        return key

    for word, level in (("本章", "chapter"), ("本節", "section")):
        if word not in text:
            continue
        oc, nc = old.get("chapter") or "", new.get("chapter") or ""
        os_, ns = old.get("section") or "", new.get("section") or ""
        unknown = not oc or not nc or (level == "section" and (not os_ or not ns))
        changed = oc != nc or (level == "section" and os_ != ns)
        if changed or unknown:
            def where(contexts, paragraphs, index):
                chapter = location(contexts, paragraphs, index, "chapter")
                if level == "chapter":
                    return chapter
                return chapter + "、" + location(contexts, paragraphs, index, "section")
            notes.append("『%s』原本在%s，現在在%s%s" % (
                word, where(old_ctx, op, old_index), where(new_ctx, np, new_index),
                "；章節待核對" if unknown else ""))
    for word in ("本款", "本點", "前項", "前條", "上開", "前述"):
        if word in text:
            notes.append("搬移後請核對『%s』仍指同一處" % word)
    if not notes:
        return ""
    edited = "（疑似搬移（刪除和新增的內容一樣））" if implied else ("（內容有修改）" if not move.get("內容相同") else "")
    return ("- 程式提醒%s：%s。指到別處給 9 分〔改變原意〕；指不到給 10 分〔無法執行〕；"
            "核對後仍指同一處才可以放行。" % (edited, "；".join(notes)))


def _scope_normalize(text):
    """只略過項次、空白及標點，不改變文字。"""
    text = strip_numbering_prefix(text or "")
    return "".join(c for c in text if not c.isspace() and not unicodedata.category(c).startswith("P"))


def _scope_sentences(text):
    for sentence in re.split(r"[。；;！？!?\n]+", text or ""):
        sentence = strip_numbering_prefix(sentence.strip()).strip()
        if sentence and any(word in sentence for word in ("不得", "應", "禁止", "須", "不可")):
            yield sentence


def _scope_siblings(contexts, first, second):
    if not (isinstance(first, int) and isinstance(second, int)
            and 0 < first <= len(contexts) and 0 < second <= len(contexts)
            and abs(first - second) <= 3):
        return False
    a, b = contexts[first - 1], contexts[second - 1]
    if any(a.get(k, "") != b.get(k, "") for k in ("chapter", "section", "level", "group_serial")):
        return False
    # 同層也須屬於同一個父層。
    level = a.get("level") or ""
    if level == "條":
        return True
    if a.get("article", "") != b.get("article", ""):
        return False
    if level in ("款", "目", "點"):
        pattern = {"款": r"第[^第]+款$", "目": r"第[^第]+目$", "點": r"第[^第]+點$"}[level]
        return re.sub(pattern, "", a.get("ref") or "") == re.sub(pattern, "", b.get("ref") or "")
    return level not in ("章", "節", "條")


def _scope_related(left, right):
    # 至少四字連續共用詞句，排除僅有「不得」的巧合。
    import difflib
    a, b = _scope_normalize(left), _scope_normalize(right)
    return difflib.SequenceMatcher(None, a, b, autojunk=False).find_longest_match(0, len(a), 0, len(b)).size >= 4


def _scope_groups(book):
    """按段次索引一次建立組群；清單或前後文物件換掉時重建。"""
    changes = book.get("changes") or []
    old_ctx, new_ctx = book.get("old_contexts") or [], book.get("new_contexts") or []
    cache = book.get("_範圍提醒快取")
    if (cache and cache[0] is book.get("changes") and cache[1] is book.get("old_contexts")
            and cache[2] is book.get("new_contexts") and cache[3] == len(changes)):
        return cache[4]
    positions = {"刪除": {}, "新增": {}}
    for c in changes:
        kind = c.get("修改類型")
        if kind in positions:
            index = c.get("old_index" if kind == "刪除" else "new_index")
            positions[kind].setdefault(index, []).append(c)
    result = {}
    numbers = {id(c): i for i, c in enumerate(changes, 1)}
    for paired in changes:
        if paired.get("修改類型") != "修改" or not paired.get("old_index") or not paired.get("new_index"):
            continue
        for kind, contexts, index_key, text_key, paired_text in (
                ("合併", old_ctx, "old_index", "old_text", paired.get("new_text") or ""),
                ("拆分", new_ctx, "new_index", "new_text", paired.get("old_text") or "")):
            extra_type = "刪除" if kind == "合併" else "新增"
            index = paired.get(index_key)
            if not isinstance(index, int):
                continue
            candidates = [c for n in range(index - 3, index + 4) for c in positions[extra_type].get(n, [])]
            extras = [c for c in candidates if _scope_siblings(contexts, index, c.get(index_key))
                      and not (c.get("移列") or _implied_move(c, book))
                      and _scope_related(c.get(text_key) or "", paired_text)]
            extras.sort(key=lambda c: numbers[id(c)])
            if not extras:
                continue
            group = [paired] + extras
            old_group = [paired] + (extras if kind == "合併" else [])
            new_group = [paired] + (extras if kind == "拆分" else [])
            old_group.sort(key=lambda c: c.get("old_index") or 0)
            new_sentences = {_scope_normalize(sentence) for c in new_group
                             for sentence in _scope_sentences(c.get("new_text"))}
            missing = [(c, sentence) for c in old_group for sentence in _scope_sentences(c.get("old_text"))
                       if _scope_normalize(sentence) and _scope_normalize(sentence) not in new_sentences]
            sources = "、".join("段 %s" % c.get("old_index") for c in old_group)
            ids = "、".join("C%d" % numbers[id(c)] for c in sorted(group, key=lambda c: numbers[id(c)]))
            messages = ["- 程式提醒：疑似%s（來源：%s；對應 %s），舊版段 %s 的這句在整組新文找不到同樣寫法，請核對義務或禁止範圍是否變小：『%s』。範圍變小且未交代原因，照限縮義務處理（9 分〔改變原意〕或依現有評分規則）；核對後範圍沒變才可以放行。" % (kind, sources, ids, source.get("old_index"), sentence)
                        for source, sentence in missing]
            fingerprint = json.dumps({"類型": kind, "缺少": sorted(sentence for _, sentence in missing),
                                      "組員": sorted((c.get("old_text") or "", c.get("new_text") or "") for c in group)},
                                     ensure_ascii=False, sort_keys=True) if missing else ""
            for c in group:
                entry = result.setdefault(id(c), {"messages": [], "fingerprints": []})
                entry["messages"].extend(messages)
                if fingerprint:
                    entry["fingerprints"].append(fingerprint)
    book["_範圍提醒快取"] = (book.get("changes"), book.get("old_contexts"), book.get("new_contexts"), len(changes), result)
    return result


def _scope_reminder(change, book, group_only=False, fingerprint=False):
    """回傳組群提醒；指紋只含類型、缺少的句子及組員新舊文。"""
    if not isinstance(book, dict):
        return ""
    entry = _scope_groups(book).get(id(change))
    if not entry:
        return ""
    if group_only:
        return True
    return "\n".join(sorted(entry["fingerprints"]) if fingerprint else entry["messages"])


def _matched_change_lines(matches, book, books):
    """對應異動每筆一行；連續刪除／新增的整塊提醒同一塊只印一次（v1.62.1）。"""
    lines, seen = [], set()
    for name, change in matches:
        data = books[name] if name else book
        lines.append("- " + _change_ref(name, change, data))
        block = _consecutive_reminder(change, data)
        if block and block not in seen:
            seen.add(block)
            lines.append(block)
    return lines


# 候選連到的那一格太短（「部」「12」這種表格碎格）就不附整塊：這種連結多半是字面巧合，
# 每個候選多 400 字只會淹沒真正的線索（考卷陸篇一張直書表，97 個候選連到碎格）
CONSECUTIVE_MIN_CHARS = 6


def _consecutive_reminder(change, book, fingerprint=False):
    """同本同類、同範圍且段次相鄰的增刪（2～12 段，像表格整列）；超過 12 段多半是整章、整本新增或刪除，
    逐段提醒沒有幫助，不提醒（v1.62.1）。只放進候選審查包和候選指紋，不進異動列自己的指紋。"""
    if not isinstance(book, dict):
        return ""
    kind = change.get("修改類型")
    if kind not in ("刪除", "新增"):
        return ""
    index_key = "old_index" if kind == "刪除" else "new_index"
    text_key = "old_text" if kind == "刪除" else "new_text"
    contexts = book.get("old_contexts" if kind == "刪除" else "new_contexts") or []

    def chapter(item):
        index = item.get(index_key)
        if isinstance(index, int) and 0 < index <= len(contexts):
            return contexts[index - 1].get("chapter") or ""
        return ""

    scope, ch = change.get("scope") or "", chapter(change)
    items = [c for c in book.get("changes") or []
             if c.get("修改類型") == kind and (c.get("scope") or "") == scope
             and chapter(c) == ch and isinstance(c.get(index_key), int) and c[index_key] > 0]
    items.sort(key=lambda c: c[index_key])
    groups, group = [], []
    for item in items:
        if group and item[index_key] != group[-1][index_key] + 1:
            groups.append(group)
            group = []
        group.append(item)
    groups.append(group)
    matches = [c for c in items if c.get(index_key) == change.get(index_key)
               and (c.get(text_key) or "") == (change.get(text_key) or "")]
    target = next((c for c in matches if c is change), None)
    if target is None and len(matches) == 1:
        target = matches[0]
    if target is None or len(re.sub(r"\s", "", target.get(text_key) or "")) < CONSECUTIVE_MIN_CHARS:
        return ""
    group = next((g for g in groups if 2 <= len(g) <= 12 and any(c is target for c in g)), [])
    if not group:
        return ""
    texts = [(c.get(text_key) or "").strip() for c in group]
    if fingerprint:
        return json.dumps({"類型": kind, "內容": texts}, ensure_ascii=False, sort_keys=True)
    cells = [text if len(text) <= 40 else text[:39] + "…" for text in texts]
    content = "｜".join(cells)
    prefix = "- 程式提醒：這筆是連續%s的一部分（%s段 %d～%d，共 %d 段，可能是表格整列或整塊%s）：" % (
        kind, "舊" if kind == "刪除" else "新", group[0][index_key], group[-1][index_key], len(group), kind)
    suffix = "。候選段還提到被%s的文件、步驟、負責單位時，判斷是否要跟著改，不要只因候選段保留同一文件就判無關。" % kind
    limit = max(0, 400 - len(prefix) - len(suffix))
    if len(content) > limit:
        content = content[:max(0, limit - 1)] + "…"
    return prefix + content + suffix


def _change_reminders(change, book, fingerprint=False, include_block=False):
    """所有實際提醒；指紋不含因段次變動而改寫的位置。"""
    move = _move_reminder(change, book)
    if fingerprint:
        move = re.sub(r"第\d+段（章節待核對）", "章節待核對", move)
    scope = _scope_reminder(change, book, fingerprint=True) if fingerprint else _scope_reminder(change, book)
    block = _consecutive_reminder(change, book, fingerprint) if include_block else ""
    return [r for r in (move, scope, block) if r]


def _change_list_block(n, change, book):
    if change.get("new_index"):
        pos = "新版段次 %d" % change["new_index"]
    else:
        pos = "刪除（舊版段次 %d）" % (change.get("old_index") or 0)
    ref = change.get("ref") or change.get("scope") or ""
    header_parts = ["C%d" % n, pos, change.get("修改類型") or ""]
    if ref:
        header_parts.append(ref)
    move = change.get("移列") or {}
    if move.get("說明"):
        # 搬移：刪除／新增其實是同一段換位置（異動清單「移列」欄），不寫的話 AI 會當成廢止一條、新訂一條
        # 新的說明自己會寫「內容有修改」；舊版留下的異動清單沒有，才補
        edited = not move.get("內容相同") and "內容有修改" not in move["說明"]
        header_parts.append("（%s%s）" % (move["說明"], "，內容也有改" if edited else ""))
    header = "## " + "　".join(header_parts)
    lines = _change_lines(change, book, header)
    reminders = _change_reminders(change, book, include_block=False)
    if reminders:
        lines[1:1] = reminders
    # v1.10.0：規範資料庫裡跟這一處相關的條文（本段引用的、內容相近的），判〔牴觸規定〕〔可能越界〕先對照
    import rule_library as lib
    own = [os.path.basename(os.path.normpath(book["outdir"]))] if book.get("outdir") else []
    related = lib.related_lines(change.get("new_text") or change.get("old_text") or "", exclude_names=own)
    if related:
        lines += ["### 規範資料庫"] + related
    lines.append("### 要判的事\n改完的這一段跟前後文有沒有矛盾？同條其他項有沒有該一起改卻沒改？")
    return "\n".join(lines)


# ---------------------------------------------------------------------------
# 寫審查包
# ---------------------------------------------------------------------------

# AI 要填的三欄。任何一列的任何一欄有字，就當作「人（或 AI）已經填過了」。
AI_ANSWER_COLUMNS = ("AI判斷", "AI分數", "AI理由")


CAND_SHA_COLUMN = "審查內容SHA256"
CHANGE_SHA_COLUMN = "異動SHA256"


def _context_sha256(data, change):
    """審查包給 AI 看的前後文（_change_lines 印的那幾段，不含異動段本身）的指紋；data 沒有段落資料
    （row_assist 的 {"changes": …}、人工待辦只有異動清單）或段次對不上就回 ""。
    指紋要含前後文：AI 判〔前後不一致〕〔同條矛盾〕看的是鄰段，鄰段改了、異動段沒動，
    以前指紋一樣就把上一輪「段12 仍寫三日」的答案原封沿用，重新比對後報告還講舊話（審查 C4）。"""
    if not isinstance(data, dict) or not data.get("new_contexts") or not data.get("new_paragraphs"):
        return ""
    try:
        _version, paragraphs, _contexts, idx0, start0, end0, _changed, _label = _change_context(change, data)
    except (ReviewPackError, KeyError, TypeError):
        return ""
    around = [paragraphs[i] for i in range(start0, end0) if i != idx0 and 0 <= i < len(paragraphs)]
    return dt.text_sha256("\n".join(around))


def change_sha256(change, data=None):
    """一處異動的指紋：舊文與新文一起算（只看新文的話，舊文不同、新文相同的兩輪分不出來）。
    data（load_book 的那一份）有給就連審查包印給 AI 的前後文一起算（見 _context_sha256）；
    打包、匯入、報告三邊都要傳同一份 data，指紋才會一樣。"""
    parts = "%s\n\x00\n%s" % (change.get("old_text") or "", change.get("new_text") or "")
    context = _context_sha256(data, change)
    if context:
        parts += "\n\x00\n前後文：" + context
    for reminder in _change_reminders(change, data, fingerprint=True):
        if reminder:
            parts += "\n\x00\n" + reminder
    return dt.text_sha256(parts)


def _candidate_context_sha256(row, book):
    """候選段的前後文（_candidate_section_lines 印的那幾段，不含候選段本身）指紋；book 沒段落資料回 ""。"""
    if not isinstance(book, dict) or not book.get("new_contexts") or not book.get("new_paragraphs"):
        return ""
    line = dt.line_of(row.get("候選段次"))
    paragraphs = book.get("new_shown") or book["new_paragraphs"]
    if not line or line > len(paragraphs) or line > len(book["new_contexts"]):
        return ""
    idx0 = line - 1
    start0, end0, _label = context_range(book["new_contexts"], idx0)
    around = [paragraphs[i] for i in range(start0, end0) if i != idx0 and 0 <= i < len(paragraphs)]
    return dt.text_sha256("\n".join(around))


def _ids_without_external(ids):
    """異動條文ID 拿掉「外部引用」那一段。

    審查匯入時，外部引用查到同一段引用過時，會併進已經在表上的候選列（異動條文ID 多一段
    「外部引用」）。AI 審的候選本身沒變；這一段算進指紋的話，同一列 AI 已經判好的答案
    會被當成「不是對這一輪的字判的」丟掉，報告上寫「AI 審查尚未完成」。"""
    parts = str(ids or "").split("；")
    return "；".join(part for part in parts if part.strip() != "外部引用")


def refresh_cross_book_sources(rows, book, books=None):
    """打包與匯入共用來源全文；舊決定表也要重算目前的搬移提醒。"""
    import row_assist as ra
    sources = dict(books or {})
    names = {piece.split("：", 1)[0].strip()
             for row in rows for piece in (row.get("異動條文ID") or "").split("；")
             if "：" in piece}
    if names and book.get("outdir") and any(name not in sources for name in names):
        sources.update({name: data for name, data in ra.sibling_books(book["outdir"]).items()
                        if name not in sources})
    for row in rows:
        matching = [(name, ch) for name, ch in changes_for_row(row, book, sources) if name]
        if matching and all(sources[name].get("old_contexts") is not None
                            and sources[name].get("new_contexts") is not None for name, _ in matching):
            row[dt.SOURCE_PRINT_COLUMN] = ra.source_fingerprint(row, book, sources)
    return sources


def candidate_sha256(row, book):
    """一列候選「AI 審的是什麼」的指紋：候選全文、異動條文ID、異動摘要，
    加上它掛的「本本」每一處異動的新舊文。

    只算候選全文不夠：重跑 compare 時常見的是異動那一段改了（五日 → 七日），
    候選那一段一個字都沒動。AI 判的是「這一段要不要跟著那處異動改」，
    異動變了，上一輪「建議改成五日」的理由就不能再用。

    刻意不在這裡查別本（跨本「X：ref」那一段）：查不查得到要看呼叫端有沒有把 X 載進來，
    batch-review-pack 會、單本 review-import 不會——同一列在兩條路上算出兩種指紋，
    混著用就把整批跨本列當成過期丟掉。跨本那一段讀列上的「來源異動指紋」欄：
    寫表時（row_assist.annotate）手上有各本異動，就把來源異動完整新舊文的指紋寫進表，
    打包、匯入、沿用上一輪讀的都是這一格。只看「異動摘要」不夠：它只有新文前 40 字，
    來源條文在後面從五日改成七日時指紋不變，上一輪「改成五日」會被當成這一輪的答案。
    沒有這一格（本本列、這一版之前的表）就不加，本本列的指紋跟以前一樣。
    """
    parts = [row.get("候選全文") or "", _ids_without_external(row.get("異動條文ID")), row.get("異動摘要") or ""]
    # 本本的異動連前後文一起算（跨本的 name 非空，來源本不在手上，照舊只算新舊文）
    parts += sorted(change_sha256(ch, None if name else book) for name, ch in changes_for_row(row, book))
    # 連續刪除／新增那一整塊（候選審查包印的那行）；只算進候選指紋（v1.62.1）
    parts += sorted("連續塊：" + block for block in (_consecutive_reminder(ch, book, fingerprint=True)
                                                    for name, ch in changes_for_row(row, book) if not name) if block)
    source = (row.get(dt.SOURCE_PRINT_COLUMN) or "").strip()
    if source:
        parts.append("來源：" + source)
    context = _candidate_context_sha256(row, book)
    if context:
        parts.append("前後文：" + context)
    return dt.text_sha256("\n\x00\n".join(parts))


def _cover_note(book):
    """封面不進逐段比對，AI 看不到核定日：判施行日、函日期時要對照（v1.57.0，審查 H89、H90）。不算進指紋。"""
    import rule_checks
    new = [text for _index, text in rule_checks.cover_lines(book.get("new_paragraphs") or [])]
    old = [text for _index, text in rule_checks.cover_lines(book.get("old_paragraphs") or [])]
    if not new:
        return ""
    note = "本本封面（不在異動裡，判施行日、函日期時拿來對照）：修訂版「%s」" % "／".join(new)
    return note + ("；現行版「%s」\n\n" % "／".join(old) if old and old != new else "\n\n")


def _new_csv_path(final_path):
    """AI候選判斷.csv → AI候選判斷.new.csv（同資料夾）。"""
    base, _ext = os.path.splitext(final_path)
    return base + ".new.csv"


# ---------------------------------------------------------------------------
# 外部規章引用：程式抓到的每一處（E1、E2…）交給 AI 檢查，另外附上可能漏抓的段落
# ---------------------------------------------------------------------------
EXTERNAL_FILE = "AI外部引用.csv"
EXTERNAL_SHA_COLUMN = "段落SHA256"
EXTERNAL_HEADER = ["引用ID", "段次", "程式抓到", "AI判斷", "AI理由", "AI更正", "查證來源", "類別",
                   EXTERNAL_SHA_COLUMN, "沿用查證"]
# 提到法規、機關或函令的字：這些段落程式卻沒抓到任何引用，就交給 AI 看有沒有漏
_EXTERNAL_HINT_RE = re.compile(
    r"[一-鿿]{2,40}(?:法|條例|辦法|準則|規則|細則|要點|規範|注意事項|自律規範)"
    r"|主管機關|金管會|金融監督管理委員會|保險局|銀行局|證期局|函令|令釋|函示|公會")
# 太長的清單 AI 讀不完，也沒有人會看；超過就只列前面這麼多段並講一聲
EXTERNAL_SUSPECT_LIMIT = 200


EXTERNAL_FROZEN_FILE = "外部引用清單.json"


def _paragraphs_sha(paragraphs):
    return dt.text_sha256("\n\x00\n".join(paragraphs))


def freeze_external(outdir, book, items):
    """審查打包時把這一輪的 E1… 存起來。之後匯入、報告都照這份對：
    AI 判漏抓、名稱錯誤、非外部法規會改登錄表、排除表，照新表現抓，E 編號就跟 AI 表錯位。"""
    data = {"新版全文SHA256": _paragraphs_sha(book["new_paragraphs"]), "引用": items}
    with io.open(place(outdir, EXTERNAL_FROZEN_FILE), "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=1)


def _frozen_external(book):
    """打包時凍結的 E1…；沒有這個檔、或新版全文已經不是打包時那一份，回 None（改成現抓）。"""
    outdir = book.get("outdir")
    if not outdir:
        return None
    path = locate(outdir, EXTERNAL_FROZEN_FILE)[0]
    try:
        with io.open(path, encoding="utf-8") as f:
            data = json.load(f)
    except (OSError, ValueError):
        return None
    if data.get("新版全文SHA256") != _paragraphs_sha(book["new_paragraphs"]):
        return None
    return data.get("引用") or []


def external_items(book, live=False):
    """這一本草稿裡程式抓到的外部規章引用，每一筆多帶「引用ID」（E1 起）與段落指紋。
    打包時凍結過就照凍結的那一份（見 freeze_external）；`live=True` 一律照現在的登錄表重抓。"""
    import rule_checks as rc
    if not live:
        frozen = _frozen_external(book)
        if frozen is not None:
            return frozen
    paragraphs = book["new_paragraphs"]
    items = []
    for i, mention in enumerate(rc.external_mentions(paragraphs), 1):
        text = paragraphs[mention["段次"] - 1]
        items.append(dict(mention, 引用ID="E%d" % i,
                          sha=dt.text_sha256("%s\n\x00\n%s" % (text, mention["引用"]))))
    return items


def external_suspects(book, items):
    """提到法規、機關或函令、但程式沒抓到任何外部引用的段落：[(段次, 全文)]。"""
    import rule_checks as rc
    from _common import clean_law_name
    covered = set(m["段次"] for m in items)
    out = []
    for idx, text in enumerate(book["new_paragraphs"], 1):
        if idx in covered:
            continue
        for match in _EXTERNAL_HINT_RE.finditer(text):
            word = match.group(0)
            if word[-1:] in "法則規點項" or word.endswith(("條例", "辦法", "準則", "要點", "規範", "注意事項")):
                if not clean_law_name(word):
                    continue      # 「方法」「作法」「本辦法」這種
            out.append((idx, text))
            break
    return out


_BATCH_TEXTS = {}
_CITE_NO_RE = re.compile(r"^第\s*([零〇一二三四五六七八九十百千兩\d０-９]+)\s*([條點])")
_LEAD_NO_RE = re.compile(r"^\s*第\s*([零〇一二三四五六七八九十百千兩\d０-９]+)\s*條|^\s*([零〇一二三四五六七八九十百千兩]+)\s*、")


def batch_book_texts(outdir):
    """這一批一起比對的每一本規章的舊版全文：{規章名: 段落 list}（別本引用的號碼照舊版解讀）。
    含沒進流程的本（未受影響規章.json）。不是批次產出回 {}。"""
    import batch as bt
    from _common import SYSTEM_DIR, batch_root_of, book_dir, read_paragraphs
    root = batch_root_of(outdir) if outdir else ""
    if not root:
        return {}
    if root in _BATCH_TEXTS:
        return _BATCH_TEXTS[root]
    texts = {}
    manifest = os.path.join(root, SYSTEM_DIR, "輸入", "規章清單.csv")
    names = []
    if os.path.isfile(manifest):
        # 人會用 Excel 改清單、另存成 Big5：跟 batch.read_manifest 一樣走 open_csv（審查 C5）
        from _common import open_csv
        with open_csv(manifest) as f:
            names = [(r.get("規章名") or "").strip() for r in csv.DictReader(f)]
    untouched = bt.unaffected_docs(root)
    new_rules = set(bt.new_rule_books(root))
    for name in names:
        if not name:
            continue
        path = ""
        if name in untouched:
            path = untouched[name]["舊版"]
        else:
            staged = os.path.join(book_dir(root, name), SYSTEM_DIR, "輸入")
            # 新訂沒有舊版（舊版留底是空白檔）：別本引用它，核對的是它的修訂版
            found = (sorted(glob.glob(os.path.join(staged, ("新版_*" if name in new_rules else "舊版_*"))))
                     if os.path.isdir(staged) else [])
            path = found[0] if found else ""
        if path and os.path.isfile(path):
            try:
                texts[name] = read_paragraphs(path)
            except (ValueError, OSError, UnicodeDecodeError, SystemExit):
                continue
    _BATCH_TEXTS[root] = texts
    return texts


def _batch_citation_ok(citation, name, paragraphs):
    """「招攬作業要點第三點」：那一本舊版裡真的有第三點（第X條同理）。只寫名稱（未指明條號）也算。
    章節那種寫法不在這裡判（交給 AI）。回傳說明字串，對不上回 ""。"""
    from _common import cn_to_int
    rest = (citation or "")[len(name):].strip()
    if not rest or rest.startswith("（未指明條號）"):
        return "%s在這一批" % name
    match = _CITE_NO_RE.match(rest)
    if not match:
        return "%s在這一批，名稱精確比對成功（未提供完整條號，交由 AI 查證）" % name
    import unicodedata
    want = cn_to_int(unicodedata.normalize("NFKC", match.group(1)))
    kind = match.group(2)
    for text in paragraphs:
        lead = _LEAD_NO_RE.match(text or "")
        if not lead:
            continue
        if kind == "條" and lead.group(1) and cn_to_int(unicodedata.normalize("NFKC", lead.group(1))) == want:
            return "%s在這一批，第%s條存在" % (name, match.group(1))
        if kind == "點" and lead.group(2) and cn_to_int(lead.group(2)) == want:
            return "%s在這一批，第%s點存在" % (name, match.group(1))
    return ""


# 「保險代理業務手冊 伍、消費者保護篇」第二章消費者申訴處理、「保險代理業務手冊參、第一章…、第四節…」：
# 書名是這一批每一本共用的，看後面接的篇（壹貳參肆…，有的還寫篇名）才知道是哪一本；
# 再看後面寫的第幾章、第幾節，到那一本去核對存在、章節名相符
_VOLUME_RE = re.compile(
    r"[」』\s，,_、]*(?:中之|之)?\s*([壹貳參肆伍陸柒捌玖拾]+)\s*[、\-－‧.．]?\s*([^\s「」『』、，,。；()（）]{1,10}?篇)?")
_UNIT_AFTER_RE = re.compile(
    r"[」』\s，,、]*(?:之|的)?\s*第\s*([零〇一二三四五六七八九十百兩\d０-９]+)\s*(章|節)\s*([^\s，,。、；」『「]{0,30})")
_HEAD_RE = re.compile(r"^\s*第\s*([零〇一二三四五六七八九十百兩\d０-９]+)\s*(章|節)\s*(.*)$")


def _plain_title(text):
    text = unicodedata.normalize("NFKC", text or "")
    return re.sub(r"[\s()（）]|\d+$", "", re.sub(r"[\t ]+\d+\s*$", "", text))


def _clean_head(text):
    return re.sub(r"[\t ]+\d+\s*$", "", (text or "").strip())       # 目錄行後面的頁碼


def _find_heading(paragraphs, unit, number, cited, after=0, before=None):
    """在段落裡找「第N章／第N節」標題（章名對得上的；cited 空就不比章名）。回傳 (段索引, 標題字)。"""
    from _common import cn_to_int
    # 「第一章之規定辦理」「第一章的…」：章號後面直接接之／的，是沒寫章名，只比號碼
    want_title = "" if re.match(r"\s*(?:之|的)", cited or "") else _plain_title(cited)
    for i in range(after, before if before is not None else len(paragraphs)):
        head = _HEAD_RE.match(paragraphs[i] or "")
        if not head or head.group(2) != unit or cn_to_int(unicodedata.normalize("NFKC", head.group(1))) != number:
            continue
        real = _plain_title(head.group(3))
        if real and want_title and not (want_title.startswith(real) or real.startswith(want_title)):
            continue
        return i, _clean_head(head.group(3))
    return None


def _batch_volume_note(text, item, batch_texts, own, own_paragraphs):
    """引用本手冊的另一篇（或本篇）：對到這一批的那一本、核對寫到的章（節）存在而且名稱相符。
    對得上回說明字串；對不上（篇對不到、沒有那一章、名稱不一樣）回 ""，照舊交給 AI。"""
    from _common import cn_to_int
    name = item.get("名稱") or ""
    if (text or "").strip() == name:
        return "這一段就是本手冊的書名，不是外部規章"
    volume = _VOLUME_RE.match(text or "", item.get("訖") or 0)
    if not volume or not volume.group(1):
        return ""
    numeral, title = volume.group(1), volume.group(2) or ""
    books = list(batch_texts) + ([own] if own not in batch_texts else [])
    names = [n for n in books if re.search(r"[_\s]%s\s*[-－、]" % numeral, n)]
    if title:
        names = [n for n in names if title in n] or [n for n in books if title in n]
    if len(names) != 1:
        return ""
    target = names[0]
    where = "本篇" if target == own else target
    paragraphs = own_paragraphs if target == own else batch_texts[target]
    shown = "%s%s" % (numeral, "、" + title if title else "")
    pos, found, named = volume.end(), [], False
    scope = (0, None)
    while True:
        unit = _UNIT_AFTER_RE.match(text, pos)
        if not unit:
            break
        number = cn_to_int(unicodedata.normalize("NFKC", unit.group(1)))
        hit = _find_heading(paragraphs, unit.group(2), number, unit.group(3), *scope)
        if not hit:
            return ""            # 寫到的章、節在那一本找不到（或名稱對不上）：交給 AI
        found.append("第%s%s「%s」" % (unit.group(1), unit.group(2), hit[1]))
        named = named or bool(unit.group(3)) and not re.match(r"\s*(?:之|的)", unit.group(3))
        if unit.group(2) == "章":
            # 節要在這一章底下找（到下一章為止）
            nxt = next((j for j in range(hit[0] + 1, len(paragraphs))
                        if (_HEAD_RE.match(paragraphs[j] or "") or [None, None, None])[2] == "章"), None)
            scope = (hit[0] + 1, nxt)
        pos = unit.end()
    if not found:
        return "「%s」是這一批的%s" % (shown, where)
    return "「%s」%s存在%s（%s）" % (shown, "、".join(found), "，名稱相符" if named else "", where)


def _table_reused(outdir):
    """本輪 AI外部引用.csv 上，查證快取帶來的列：(程式抓到, 段落指紋) → 那一筆（跟快取同格式）。
    「沿用查證」寫「程式核對」的不收：那是每次打包重算的。v1.51.0：查證快取搬家、換電腦時用這些列保底。"""
    import datetime
    from _common import open_csv
    path = locate(outdir, EXTERNAL_FILE)[0]
    if not os.path.isfile(path):
        return {}
    try:
        with open_csv(path) as f:
            rows = list(csv.DictReader(f))
    except (OSError, UnicodeDecodeError, csv.Error, ValueError):
        return {}          # 表讀不出來的情況 _write_ai_csv 會中止並講清楚
    found = {}
    for row in rows:
        when = (row.get("沿用查證") or "").strip()
        try:
            datetime.date.fromisoformat(when)
        except ValueError:
            continue
        if (row.get("AI判斷") or "").strip():
            entry = dict((c, row.get(c) or "") for c in ("AI判斷", "AI理由", "AI更正", "查證來源", "類別"))
            entry["日期"] = when
            found[((row.get("程式抓到") or "").strip(), (row.get(EXTERNAL_SHA_COLUMN) or "").strip())] = entry
    return found


def _law_changed_here(outdir):
    """這一輪被「法規更動」標記過：它刪查證快取就是要重查，快取找不到時不能拿表上的舊答案保底。"""
    import review_import as ri
    reasons = (ri.read_import_status(outdir) or {}).get("需重新打包") or []
    return any(str(r).startswith("法規更動") for r in reasons)


def _external_answered_here(outdir, items):
    """與 _write_ai_csv 相同的指紋或舊表位置規則，保留本輪 AI 判斷。"""
    from _common import open_csv
    path = locate(outdir, EXTERNAL_FILE)[0]
    if not os.path.isfile(path):
        return set()
    try:
        with open_csv(path) as f:
            reader = csv.DictReader(f)
            rows = list(reader)
            fields = reader.fieldnames or []
    except (OSError, UnicodeDecodeError, csv.Error, ValueError):
        return set()  # _write_ai_csv 會報錯並保留原檔
    answered = [r for r in rows if not (r.get('沿用查證') or '').strip() and (r.get('AI判斷') or '').strip()]
    result = set()
    for item in items:
        for row in answered:
            old_sha = (row.get(EXTERNAL_SHA_COLUMN) or '').strip()
            if (old_sha and old_sha == item['sha'] and str(row.get('段次', '')).strip() == str(item['段次'])) or (
                    EXTERNAL_SHA_COLUMN not in fields and (row.get('引用ID') or '').strip() == item['引用ID']
                    and str(row.get('段次', '')).strip() == str(item['段次'])):
                result.add(item['引用ID'])
                break
    return result


def _has_version_note(paragraph, name):
    import unicodedata
    paragraph = unicodedata.normalize('NFKC', paragraph or '')
    name = unicodedata.normalize('NFKC', name or '')
    matches = list(re.finditer(r'\s*'.join(re.escape(c) for c in name if not c.isspace()), paragraph)) if name.strip() else []
    if not matches:
        return True
    return any(re.search(r'\d{2,3}\s*[./年]\s*\d{1,2}|字\s*第|號\s*令|修正|版', paragraph[m.end():m.end() + 40]) for m in matches)


# 沿用的查證每本每輪最多排幾列重查，舊工作區第一輪才不會一次爆量；舊的先查，連不上網做不成的排後面，其餘下一輪排
CARRIED_RECHECK_MAX = 30
# 這一輪排了重查的列，它們的舊答案與舊來源：連不上網時照這一份留著（review_import._keep_old_when_offline）
RECHECK_FILE = "重查舊答案.json"
RECHECK_OFFLINE = "連不上網"


def recheck_state(outdir):
    """這一輪排了重查的列 {段落指紋: 舊答案}；沒有（舊產出、壞檔）回 {}。"""
    path = locate(outdir, RECHECK_FILE)[0]
    try:
        with io.open(path, encoding="utf-8") as f:
            value = json.load(f)
    except (OSError, ValueError):
        return {}
    return value if isinstance(value, dict) else {}


def write_recheck_state(outdir, state):
    from _common import write_generated
    write_generated(place(outdir, RECHECK_FILE), state)


def _save_recheck(outdir, book, items, reused, recheck, tried):
    """記下這一輪交回重查的列的舊答案。同一輪重新打包時，已經確定連不上網的那幾筆照留。"""
    import verify_cache as vc
    state = dict(tried)
    for item in items:
        if item["引用ID"] in recheck:
            hit = reused[item["引用ID"]]
            state[item["sha"]] = dict(dict((c, hit.get(c) or "") for c in vc.FIELDS), 日期=hit["日期"],
                                      鑰匙=vc.key(item["引用"], book["new_paragraphs"][item["段次"] - 1]))
    if state or os.path.isfile(locate(outdir, RECHECK_FILE)[0]):
        write_recheck_state(outdir, state)


def _recheck_carried(items, reused, tried=()):
    """查證快取帶回來、但不能再帶下去的列：查證來源只是首頁或清單頁、理由是 AI 自己還沒查完、同一句套在一堆不同的引用上。
    回傳 {引用ID: 給 AI 看的一句}，這幾列交給 AI 這一輪重查。程式核對的列、看著承辦意見重查過的列不算。
    tried：這一輪已經確定連不上網的段落指紋，不再交回去。排的順序：連不上網做不成的次數少的先（每一列都輪得到），再來舊的先。"""
    import review_import as ri
    import scoring_rubric as sr
    import verify_cache as vc
    from _common import external_category
    carried = [(item, reused[item["引用ID"]]) for item in items if item["引用ID"] in reused]
    carried = [(item, hit) for item, hit in carried if hit["日期"] != "程式核對" and not hit.get(vc.SEEN_FIELD)
               and item.get("sha") not in tried]
    repeated = sr.repeated_external_reasons([dict(hit, 引用=item["引用"]) for item, hit in carried])
    found = []
    for item, hit in carried:
        reason = hit.get("AI理由") or ""
        page = ri.weak_source(hit.get("AI判斷"), reason, hit.get("類別") or external_category(item.get("名稱") or ""),
                              hit.get("查證來源"))
        if page:
            note = ("上次的查證來源只是首頁或清單頁（%s）：這次要打開實際的條文頁重查，查證來源填那一頁；"
                    "公會清單頁只查得到備查日期的，理由寫明備查日或備查版（要有日期）" % page)
        elif sr.NOT_ASKING_RE.search(reason):
            note = "上次的理由寫還要補查：這次要真的查完再判"
        elif sr.squash_reason(reason) in repeated:
            note = "上次的理由跟好幾處不同的引用一字不差：這次要寫這一處查到什麼"
        else:
            continue
        found.append((int(hit.get(vc.RETRY_FIELD) or 0), hit["日期"], item["引用ID"], note))
    found.sort(key=lambda entry: entry[:2])
    later = max(0, len(found) - CARRIED_RECHECK_MAX)
    if found:
        nt.notice(nt.REMINDER, "%d 列沿用的查證要 AI 重查（來源只是首頁或清單頁，或理由是模板句）%s"
                  % (len(found) - later, "；另有 %d 列排到下一輪" % later if later else ""), "review-pack")
    return dict((rid, note) for _tries, _when, rid, note in found[:CARRIED_RECHECK_MAX])


def lm_version_said(text, latest):
    import law_memory as lm
    return lm.version_said(text, latest)


def _external_lags(book, items):
    """{引用ID: 版本過時那一筆}：段落裡「法規名稱(日期修正)」比法規版本表舊、而且就是這一處引用的法規（v1.60.18）。"""
    import law_memory as lm
    lines = sorted(set(item["段次"] for item in items))
    try:
        hits = lm.version_lag([("", line, book["new_paragraphs"][line - 1]) for line in lines])
    except (OSError, ValueError, KeyError, TypeError):
        return {}
    by_line = {}
    for hit in hits:
        by_line.setdefault(str(hit["段次"]), []).append(hit)
    out = {}
    for item in items:
        cited = lm.norm_name(str(item.get("名稱") or item.get("引用") or ""))
        if not item.get("名稱"):
            cited = lm._TRAILING_ARTICLE_RE.sub("", cited)
        for hit in by_line.get(str(item["段次"]), []):
            name = lm.norm_name(hit["法規名稱"])
            if cited and name and cited == name:
                out[item["引用ID"]] = hit
                break
    return out


def _external_pack(outdir, book, kept):
    """寫 2_Log檔案/LLM外部引用清單.md 與 2_Log檔案/AI外部引用.csv。回傳 (引用數, 可能漏抓段數)。"""
    import batch as bt
    import scoring_rubric as sr
    import verify_cache as vc
    items = external_items(book, live=True)
    freeze_external(outdir, book, items)
    suspects = external_suspects(book, items)
    # 有效期內查過的同一處引用直接沿用（見 verify_cache），AI 只查沒沿用的
    cache_folder = bt.cache_dir(outdir)
    entries = vc.load(cache_folder)
    days = vc.valid_days()                 # 設定.html「查證沿用天數」，留空 90
    reused = {}
    # v1.51.0：重跑審查打包時，查證快取找不到（搬家、換電腦）的列保留本輪表的答案；以前整輪 288 列清到剩 49 列、
    # 也沒提醒。有效期照舊算（過期要重查），「法規更動」標記過的這一輪不保底
    table_rows = {} if _law_changed_here(outdir) else _table_reused(outdir)
    table_kept, table_expired = 0, 0
    # 引用的是這一批一起比對的本行規章：程式自己核對號碼存在，不用 AI 上網查、也不用人確認
    own = os.path.basename(os.path.normpath(outdir))
    batch_texts = batch_book_texts(outdir)
    # v1.9.0 規範資料庫：內部規範程式核對條號就判沒問題；外部規範把那一條條文給 AI 看
    import rule_library as lib
    library = lib.load()
    for warning in library.warnings:
        nt.notice(nt.REMINDER, warning, "review-pack")
    from_library = {}
    # v1.40.0：承辦對那一段寫了要改的意見：程式核對、查證快取都不先填，交給 AI 看著意見重查；
    # 重查過的（快取記著看過同一句意見）才照沿用
    import precedents as pc
    marks, checked, disputed_ids = {}, set(), set()
    answered_here = _external_answered_here(outdir, items)
    old_marks = pc.seen_marks(outdir, EXTERNAL_FILE)
    unsafe_marks = set()
    for item in items:
        name = item.get("名稱") or ""
        paragraph = book["new_paragraphs"][item["段次"] - 1]
        opinion = pc.disputed(paragraph)
        if opinion:
            k = vc.key(item["引用"], paragraph)
            checked.add(k)
            hit = vc.lookup(entries, k, days=days)
            found = library.citation(name, item.get("條號") or "")
            if hit and hit.get(vc.SEEN_FIELD) == opinion:
                reused[item["引用ID"]] = hit
            else:
                if item["引用ID"] in answered_here and old_marks.get(k) != opinion:
                    unsafe_marks.add(k)
                else:
                    marks[k] = opinion
                disputed_ids.add(item["引用ID"])
                if found:
                    from_library[item["引用ID"]] = found
            continue
        if name and name != own and name in batch_texts:
            note = _batch_citation_ok(item["引用"], name, batch_texts[name])
            if note:
                reused[item["引用ID"]] = {
                    "AI判斷": "沒問題", "AI更正": "", "查證來源": "", "類別": "本行內規", "日期": "程式核對",
                    "AI理由": "〔本批規章〕程式核對：%s%s" % (note, "" if book.get("體檢") else "；要不要跟著改看連帶決定表的跨本引用列")}
                continue
        note = _batch_volume_note(book["new_paragraphs"][item["段次"] - 1], item, batch_texts, own,
                                  book["new_paragraphs"])
        if note:
            reused[item["引用ID"]] = {
                "AI判斷": "沒問題", "AI更正": "", "查證來源": "", "類別": "本行內規", "日期": "程式核對",
                "AI理由": "〔本批規章〕程式核對：%s" % note}
            continue
        found = library.citation(name, item.get("條號") or "")
        if found and found["doc"]["資料夾"] == lib.INTERNAL and found["exists"] is True:
            reused[item["引用ID"]] = {
                "AI判斷": "沒問題", "AI更正": "", "查證來源": lib.source_text(found["doc"]), "類別": "本行內規",
                "日期": "程式核對", "AI理由": "〔資料庫規章〕程式核對：%s" % found["note"]}
            continue
        if found:
            from_library[item["引用ID"]] = found
        hit = vc.lookup(entries, vc.key(item["引用"], book["new_paragraphs"][item["段次"] - 1]), days=days)
        # 上次是照資料庫的另一份（舊版）查的：資料庫換了新版就重查
        if hit and found and (hit.get("查證來源") or "").startswith(lib.SOURCE_PREFIX) \
                and not (hit.get("查證來源") or "").startswith(lib.source_text(found["doc"])):
            hit = None
        elif not hit and not found:
            row = table_rows.get((str(item["引用"]).strip(), str(item["sha"]).strip()))
            if row:
                hit = vc.lookup({"表": row}, "表", days=days)
                table_kept += 1 if hit else 0
                table_expired += 0 if hit else 1
        if hit:
            reused[item["引用ID"]] = hit
    if table_kept:
        nt.notice(nt.REMINDER, "%d 列查證快取不在，沿用本輪表的答案" % table_kept, "review-pack")
    if table_expired:
        nt.notice(nt.REMINDER, "%d 列查證超過有效天數（%d 天），這次要重查" % (table_expired, days), "review-pack")
    # v1.60.18（模擬重新檢視 R4、R10）：程式已經知道手冊寫的版本比最新的舊。清單上標出來；
    # 沿用的「沒問題」沒講到版本、也沒寫最新日期的不沿用，這次要重查（以前 E22、E24 跟已更新的 E25 同一版卻判沒問題）
    lag_of = _external_lags(book, items)
    for rid, hit in list(reused.items()):
        lag = lag_of.get(rid)
        if lag and hit.get("AI判斷") == "沒問題" and hit.get("日期") != "程式核對" \
                and not lm_version_said(hit.get("AI理由") or "", lag["已知最新版"]):
            del reused[rid]
    tried = dict((sha, old) for sha, old in recheck_state(outdir).items() if old.get(RECHECK_OFFLINE))
    recheck = _recheck_carried(items, reused, tried)
    _save_recheck(outdir, book, items, reused, recheck, tried)
    for rid in recheck:
        del reused[rid]
    from _common import external_category, config_section
    import law_fetch as lf
    enabled = os.environ.get("REG_NO_LAW_FETCH") != "1" and config_section("設定").get("打包時先抓法條", True) is not False
    eligible = [item for item in items if item["引用ID"] not in reused
                and not (from_library.get(item["引用ID"]) or {}).get("text")
                and external_category(item.get("名稱") or "") in ("", "法律", "主管機關法規")]
    laws = lf.fetch_batch([(i.get("名稱"), i.get("條號")) for i in eligible], cache_folder) if enabled else {}
    evidence = {}
    for item in eligible:
        name, number = item.get("名稱") or "", item.get("條號") or ""
        data = laws.get(name)
        if data is None:
            continue
        rid = item["引用ID"]
        url = lf.BASE + "LawClass/LawAll.aspx?pcode=" + data.get("pcode", "")
        key = lf.article_key(number)
        article = next((a for a in data.get("articles", []) if lf.article_key(a["article_no"]) == key), None) if key else None
        if data.get("ambiguous"):
            note = "同名現行法規有歧義：%s；照引用查證規則自己上網查" % "、".join(
                x['name'] + ' ' + lf.BASE + 'LawClass/LawAll.aspx?pcode=' + x['pcode'] for x in data['ambiguous'])
        elif data.get("error"):
            note = "沒抓到：%s；照引用查證規則自己上網查" % data["error"]
        elif not data.get("pcode"):
            note = "找不到同名；附近似名稱：%s；照引用查證規則自己上網查" % ("、".join(data.get("similar", [])) or "無")
        elif data.get("revoked"):
            article = None
            note = "已廢止（廢止日期：%s）；%s；請另查現行規範，照引用查證規則自己上網查" % (data.get('law_date') or '未載明', url)
        elif not number:
            note = "現行；%s" % url
            if rid not in answered_here and rid not in disputed_ids \
                    and not _has_version_note(book['new_paragraphs'][item['段次'] - 1], name):
                reused[rid] = {"AI判斷": "沒問題", "AI更正": "", "查證來源": url, "類別": external_category(name),
                               "日期": "程式核對", "AI理由": "〔未指明條號〕程式核對：全國法規資料庫有「%s」（現行），名稱相符" % name}
            elif rid not in answered_here:
                note += "；名稱後有日期或版本註記，請自行核對是否過時"
        elif article:
            flno = str(key[1]) + ("-" + str(key[2]) if key[2] else "")
            single = lf.BASE + "LawClass/LawSingle.aspx?pcode=" + data["pcode"] + "&flno=" + flno
            note = "官方原文：見〈零〉的〈%s %s〉；查證來源可以寫 %s" % (name, article["article_no"], single)
        else:
            last = data.get("articles", [])
            note = "找不到該條；現行條文最後一條是%s；照引用查證規則自己上網查" % (last[-1]["article_no"] if last else "未知")
        evidence[rid] = (name, number, data, article, note)
    lines = [sr.pointer("外部引用"), "---", ""]
    if enabled:
        lines += ["# 零、程式先抓好的官方原文", ""]
        grouped = {}
        for rid, entry in evidence.items():
            name, number, data, article, note = entry
            if data.get("pcode") and not data.get("error") and not data.get('revoked') and (article or not number):
                grouped.setdefault((name, lf.article_key(number) if number else None), []).append((rid, entry))
        for group in grouped.values():
            name, number, data, article, note = group[0][1]
            lines += ["## %s%s" % (name, " " + article["article_no"] if article else ""), "",
                      "引用ID：" + "、".join(x[0] for x in group), "", note, "抓取日期：" + data.get("article_date", ""), ""]
            lines += ["最新修正日期：" + (data.get('law_date') or '未載明'), ""]
            if article:
                lines += ["> " + article["new_text"].replace("\n", "\n> "), ""]
        missing = {}
        for rid, (name, number, data, article, note) in evidence.items():
            if data.get('error') or data.get('ambiguous') or not data.get('pcode') or data.get('revoked') or (number and not article):
                missing.setdefault(name, {}).setdefault(note, []).append(rid)
        lines += ["## 要自己上網查的（同一部只查一次）", ""]
        if not missing:
            lines += ["（沒有）", ""]
        for name, reasons in missing.items():
            lines += ["- %s：%s" % (name, "；".join("%s（引用ID：%s）" % (note, '、'.join(ids)) for note, ids in reasons.items()))]
        lines.append("")
        lf.report(laws, sum(bool(v[3]) for v in evidence.values()),
                  sum(rid in reused and reused[rid]['AI理由'].startswith('〔未指明條號〕') for rid in evidence))
    lines += ["# 一、程式抓到的外部規章引用", ""]
    if reused:
        lines += ["（標「已沿用」的那幾處，%d 天內查證過、段落文字沒變，AI外部引用.csv 已經填好，不用重查；"
                  "只查其他的。法規改了要提前重查：跑 run_all.py 法規更動 <法規名>）" % days, ""]
    if not items:
        lines.append("（沒有）")
    for item in items:
        hit = reused.get(item["引用ID"])
        mark = ""
        if hit:
            mark = ("　程式已核對（%s）" % ("全國法規資料庫" if hit["AI理由"].startswith("〔未指明條號〕") else "規範資料庫" if hit["AI理由"].startswith("〔資料庫規章〕") else "這一批的規章")
                    if hit["日期"] == "程式核對" else "　已沿用 %s 的查證" % hit["日期"])
        lines += ["## %s　段次 %d　程式抓到：%s%s" % (item["引用ID"], item["段次"], item["引用"], mark),
                  "", "> " + book["new_paragraphs"][item["段次"] - 1].replace("\n", "\n> "), ""]
        if item["引用ID"] in recheck and not hit:
            lines += ["**要重查**：" + recheck[item["引用ID"]], ""]
        if item["引用ID"] in lag_of and not hit:
            import law_memory as lm
            lines += [lm.lag_note(lag_of[item["引用ID"]]) + "。查證後確實舊了就判「有誤」〔引用過時〕，AI更正寫現行日期；"
                      "判「沒問題」要在理由寫查到的最新修正日。", ""]
        if item["引用ID"] in evidence:
            lines += [evidence[item["引用ID"]][4], ""]
        found = from_library.get(item["引用ID"])
        if found and not hit:
            doc = found["doc"]
            lines.append("**規範資料庫有這一份**：%s（%s%s）。%s。查證來源可以寫「%s」。"
                         % (lib.source_text(doc), "版本 %s、" % doc["版本"] if doc["版本"] else "",
                            "日期 %s" % doc["日期"] if doc["日期"] else "沒寫日期", found["note"], lib.source_text(doc)))
            if doc.get("轉法") in ("OCR", "AI"):
                lines.append("（這一份是從圖片轉出來的文字，可能有錯字：字形相近的錯字不要當成引用錯誤）")
            if found["text"]:
                lines += ["", "資料庫裡的%s：" % lib.article_label(found["key"]), "",
                          "> " + found["text"][:3000].replace("\n", "\n> ")]
            lines.append("")
    lines += ["# 二、提到法規、機關或函令，但程式沒抓到引用的段落", ""]
    if not suspects:
        lines.append("（沒有）")
    for idx, text in suspects[:EXTERNAL_SUSPECT_LIMIT]:
        lines += ["## 段次 %d" % idx, "", "> " + text.replace("\n", "\n> "), ""]
    if len(suspects) > EXTERNAL_SUSPECT_LIMIT:
        lines.append("（另有 %d 段沒列出來；清單太長，請先處理上面這些）"
                     % (len(suspects) - EXTERNAL_SUSPECT_LIMIT))
        nt.notice(nt.REMINDER, "LLM外部引用清單.md 可能漏抓的段落有 %d 段，只列了前 %d 段"
                  % (len(suspects), EXTERNAL_SUSPECT_LIMIT), "review-pack")
    if checked:
        for k in unsafe_marks:
            marks.pop(k, None)
        pc.save_seen_marks(outdir, EXTERNAL_FILE, marks, checked)
    from _common import write_generated
    write_generated(place(outdir, "LLM外部引用清單.md"), "\n".join(lines) + "\n")
    from _common import external_category
    # 類別先照登錄表填好（登錄過的名稱），AI 只要補沒登錄的
    body = []
    for item in items:
        hit = reused.get(item["引用ID"])
        if hit:
            body.append([item["引用ID"], item["段次"], item["引用"], hit["AI判斷"], hit["AI理由"], hit["AI更正"],
                         hit["查證來源"], hit["類別"] or external_category(item["名稱"]), item["sha"], hit["日期"]])
        else:
            body.append([item["引用ID"], item["段次"], item["引用"], "", "", "", "",
                         external_category(item["名稱"]), item["sha"], ""])
    # 上一輪的外部引用答案不帶：跨輪沿用由查證快取管（有 90 天有效期），同一輪重跑才帶。
    # v1.25.0：AI 自己補的「新增」漏抓列例外：檔案沒變就帶到下一輪（程式還是抓不到，不帶就整列消失）
    _write_ai_csv(outdir, EXTERNAL_FILE, EXTERNAL_HEADER, body, kept, key_column=EXTERNAL_SHA_COLUMN,
                  answer_columns=("AI判斷", "AI理由", "AI更正", "查證來源", "類別"), previous_round=False,
                  carry_new_rows=True)
    return len(items), min(len(suspects), EXTERNAL_SUSPECT_LIMIT)


# ---------------------------------------------------------------------------
# 條文檢查高風險項：compare 存下來的那幾筆（K1、K2…）交給 AI 查證
# ---------------------------------------------------------------------------
RULECHECK_FILE = "AI條文檢查.csv"
RULECHECK_SHA_COLUMN = "內容SHA256"
RULECHECK_HEADER = ["檢查ID", "段次", "檢查項目", "程式發現", "AI判斷", "AI理由", "查證來源",
                    RULECHECK_SHA_COLUMN]


def rulecheck_items(outdir):
    """compare 存的 條文檢查待查證.json，每一筆多帶「檢查ID」（K1 起）、「段次」與指紋。
    沒有這個檔（舊的產出資料夾）回 None。"""
    import rule_checks as rc
    path = locate(outdir, rc.AI_REVIEW_FILE)[0]
    if not os.path.isfile(path):
        return None
    try:
        with io.open(path, encoding="utf-8") as f:
            findings = json.load(f)
        if not isinstance(findings, list):
            raise ValueError("內容不是清單")
    except (OSError, ValueError) as exc:
        # 壞檔（寫到一半被中斷）不要 traceback：講清楚怎麼修（審查 C6）
        raise ReviewPackError("%s 讀不出來（%s）：請重新比對（跑 繼續），比對會重寫它" % (rc.AI_REVIEW_FILE, exc))
    import rule_library as lib
    own = [os.path.basename(os.path.normpath(outdir))]
    items = []
    for i, item in enumerate(findings, 1):
        line = item.get("index") or ""
        parts = [item.get("check") or "", item.get("detail") or "", item.get("quote") or "", str(line)]
        # v1.10.0：附給 AI 對照的規範資料庫條文也算進指紋——資料庫換了條文，判過的答案不沿用。
        # 資料庫沒有相關條文時不加，指紋跟以前一樣（舊答案照常沿用）
        related = lib.related_digest(_rulecheck_query(item), exclude_names=own)
        if related:
            parts.append("資料庫:" + related)
        items.append(dict(item, 檢查ID="K%d" % i, 段次=line, sha=dt.text_sha256("\n\x00\n".join(parts))))
    return items


def _rulecheck_query(item):
    """找資料庫相關條文用的字：程式抓到的那一句（相關原文）與說明。"""
    return "\n".join(x for x in (item.get("quote") or "", item.get("detail") or "") if x)


def _rulecheck_pack(outdir, book, kept):
    """寫 2_Log檔案/LLM條文檢查清單.md 與 2_Log檔案/AI條文檢查.csv。回傳項數（沒有待查證檔回 0）。"""
    import scoring_rubric as sr
    items = rulecheck_items(outdir)
    if items is None:
        return 0
    import rule_library as lib
    own = [os.path.basename(os.path.normpath(outdir))]
    paragraphs = book["new_paragraphs"]
    lines = [sr.pointer("條文檢查"), "---", ""]
    if not items:
        lines.append("（這一輪沒有高風險項）")
    contexts = book.get("new_contexts") or []
    for item in items:
        line = item["段次"]
        known = contexts[line - 1]["ref"] if isinstance(line, int) and 1 <= line <= len(contexts) else ""
        where = item.get("ref") or display_ref(known) or ("第%s段" % line if line else "全文")
        lines += ["## %s　%s　[%s]　%s" % (item["檢查ID"], where, item["check"], item["detail"]), ""]
        if item.get("quote"):
            lines += ["相關原文：" + item["quote"], ""]
        if item.get("action"):
            lines += ["程式建議：" + item["action"], ""]
        line = item["段次"]
        if isinstance(line, int) and 1 <= line <= len(paragraphs):
            lines += ["新版這一段：", "", "> " + paragraphs[line - 1].replace("\n", "\n> "), ""]
        if item.get("old_text"):
            # 程式依內容相近配的兩段：要先確認是不是同一段，舊文要給全，不能只有前 40 個字
            lines += ["程式配對的舊版這一段（現行版第 %s 段，要先確認跟新版那段是不是同一段）：" % item.get("old_index"), "",
                      "> " + item["old_text"].replace("\n", "\n> "), ""]
        lines += lib.related_lines(_rulecheck_query(item), exclude_names=own)
    from _common import write_generated
    write_generated(place(outdir, "LLM條文檢查清單.md"), "\n".join(lines) + "\n")
    # v1.40.0：承辦對那一段（或程式抓到的那一句）寫了要改的意見：上一輪的答案不帶，看過同一句意見判過的才帶
    import precedents as pc
    disputed = {}
    for item in items:
        line = item["段次"]
        texts = [item.get("quote") or ""]
        if isinstance(line, int) and 1 <= line <= len(paragraphs):
            texts.append(paragraphs[line - 1])
        opinion = pc.disputed(*texts)
        if opinion:
            disputed[item["sha"]] = opinion
    _write_ai_csv(outdir, RULECHECK_FILE, RULECHECK_HEADER,
                  [[item["檢查ID"], item["段次"], item["check"], item["detail"], "", "", "", item["sha"]]
                   for item in items], kept, answer_columns=("AI判斷", "AI理由", "查證來源"), disputed_keys=disputed)
    return len(items)


def _input_digests(outdir):
    """這一本 輸入/ 裡每一份留底 Word 的 SHA-256（排好）；沒有就回空 tuple。"""
    folder = locate(outdir, "輸入")[0]
    if not os.path.isdir(folder):
        return ()
    return tuple(sorted(dt.file_sha256(os.path.join(folder, name)) for name in os.listdir(folder)
                        if os.path.splitext(name)[1].lower() in (".docx", ".doc", ".pdf", ".txt", ".md")
                        and os.path.isfile(os.path.join(folder, name))))


def _squash_name(text):
    """比名稱用：拿掉空白與「（未指明條號）」這類括註。"""
    return re.sub(r"[（(][^）)]*[）)]", "", "".join(str(text or "").split()))


def _same_candidate_spots(outdir, rows, changes, prior):
    """v1.25.0：檔案沒變的上一輪（prior），哪幾列候選（R 編號, 段次）、哪幾處異動（C 編號, 段次）內容也沒變。
    候選比 候選全文、異動條文ID（不含程式匯入時加的「外部引用」）、異動摘要、因為哪一處修改；異動比新舊文。"""
    from _common import open_csv
    cand, chg = set(), set()
    if not prior:
        return cand, chg
    try:
        with open_csv(locate(prior, "連帶決定表.csv")[0]) as f:
            old_rows = list(csv.DictReader(f))
        with io.open(locate(prior, "異動清單.json")[0], encoding="utf-8") as f:
            data = json.load(f)
        old_changes = data.get("changes") if isinstance(data, dict) else data
    except (OSError, ValueError, csv.Error, UnicodeDecodeError):
        return cand, chg

    def same(a, b):
        return (all((a.get(c) or "") == (b.get(c) or "") for c in ("候選全文", "異動摘要", "因為哪一處修改", "候選段次"))
                and _ids_without_external(a.get("異動條文ID")) == _ids_without_external(b.get("異動條文ID")))
    # 舊一輪可能有推定搬移，這一輪因重複增刪而消失；不能只看目前狀態。
    old_normalized = [dict(ch) for ch in old_changes or []]
    for ch in old_normalized:
        for key in ("old_index", "new_index"):
            value = ch.get(key)
            if isinstance(value, str):
                ch[key] = int(value) if value.isdigit() else None
    old_book = {"changes": old_normalized}
    old_has_implied = any(_implied_move(ch, old_book) for ch in old_normalized)
    for i, (row, old) in enumerate(zip(rows, old_rows), 1):
        old_move = old_has_implied and any(_implied_move(ch, old_book)
                       for name, ch in changes_for_row(old, old_book) if not name)
        if same(row, old) and not old_move:
            cand.add(("R%d" % i, str(row.get("候選段次") or "").strip()))
    for i, (ch, old) in enumerate(zip(changes, old_normalized), 1):
        if (not _implied_move(old, old_book)
                and all(str(ch.get(c) or "") == str(old.get(c) or "") for c in ("old_text", "new_text", "new_index", "old_index"))):
            chg.add(("C%d" % i, str(ch.get("new_index") or "刪除").strip()))
    return cand, chg


def _same_change_list(outdir, prior):
    """兩輪的 異動清單.json 一模一樣（異動的編號 C1、C2… 就一樣）。讀不到算不一樣。"""
    try:
        with io.open(locate(outdir, "異動清單.json")[0], encoding="utf-8") as f:
            mine = json.load(f)
        with io.open(locate(prior, "異動清單.json")[0], encoding="utf-8") as f:
            theirs = json.load(f)
    except (OSError, ValueError):
        return False
    return mine == theirs


def unchanged_previous(outdir):
    """上一次同一種的那一輪（比對找比對）這一本的資料夾，前提是兩輪讀的檔案一模一樣；不是就回 ""（v1.25.0）。
    檔案一樣，前後文、異動就一樣：程式改了指紋的算法（例如多算前後文）之後，舊答案照位置對也不會指錯。"""
    from _common import previous_output
    prior = previous_output(outdir)
    if not prior or not os.path.isdir(prior):
        return ""
    mine = _input_digests(outdir)
    return prior if mine and mine == _input_digests(prior) else ""


# 這兩張表的模板句打包時不帶回（比照法規表）：比對流程的舊答案，AI 不用等承辦寫「請重查」就會重判
TEMPLATE_TABLES = ("AI候選判斷.csv", "AI異動審查.csv")


def _write_ai_csv(outdir, filename, header, data_rows, kept, key_column=None,
                  answer_columns=AI_ANSWER_COLUMNS, previous_round=True, disputed_keys=(),
                  same_spots=None, carry_new_rows=False, no_position_keys=()):
    """寫一張 AI CSV，直接寫在原檔名。AI 已經判過、而且審的內容沒變（指紋一樣）的列，把答案帶進新表：

        這個資料夾現在那一份：同一輪重跑 review-pack（補了語意、改了 --per-file……）
        上一輪歸檔在 2_Log檔案/歷次/ 的那一份：重跑「開始」之後（previous_round）

    以前已有填答就另存 .new.csv，叫人「自行對照後改名」；重跑開始則四張表整批變回空白，
    AI 要從頭再審一次。指紋記的是這一列審的是哪一段字（見 candidate_sha256 等），字變了就不帶，
    舊理由不會套到新的字上。程式自己先填的列（「沿用查證」有值：查證快取、同一批規章的核對）
    不當成 AI 的答案，也不會被蓋掉。kept 收「檔名 N 列」給畫面講。

    same_spots（v1.25.0）：上一次同一種的那一輪讀的檔案一模一樣時，呼叫端核對過內容沒變的
    (編號, 段次)：指紋對不上（新版程式改了指紋算法）也照位置帶上一輪的答案。
    carry_new_rows（v1.25.0，外部引用）：檔案一模一樣時，上一輪 AI 自己加的「新增」漏抓列也帶過來。
    TEMPLATE_TABLES 的舊答案（上一輪、答案庫）是模板句就不帶；這一輪自己填的留著，匯入時擋下來 AI 看得到原因。
    """
    import scoring_rubric as sr
    from _common import archived_file, open_csv
    final_path = place(outdir, filename)
    key_column = key_column or header[-1]
    key_index = header.index(key_column)
    columns = [c for c in answer_columns if c in header]
    carried = {}
    by_position = {}          # 舊表沒有指紋欄（較早的表、AI 改寫時拿掉了）：退回用 編號＋段次 對
    extra_rows = []
    # 這個資料夾現在那一份裡 AI 答過的每一列（用「指紋＋位置」或「編號＋位置」認）。
    # 以前只記個數，跟「帶回了幾列」相減——帶回的列也算上一輪歸檔那一份的，
    # 兩邊一抵銷，「要重判」的提醒就少報甚至不報（第三批）。改成逐列記、逐列勾。
    answered_here = set()
    used_here = set()
    sources = [locate(outdir, filename)[0]]
    if previous_round:
        sources.append(archived_file(outdir, filename))
    prior = unchanged_previous(outdir) if (same_spots or carry_new_rows or previous_round) else ""
    prior_file = locate(prior, filename)[0] if prior else ""
    # 檔案一樣、異動清單也一樣的上一輪：C3、K1、段749 這種編號不會重編、移位，理由寫了也照帶（v1.25.0）
    same_numbers = bool(prior) and _same_change_list(outdir, prior)
    # archived_file 這個資料夾自己有表就回它自己：重新打包時上一輪那一份就讀不到了，另外加進來（排最後，
    # 這個資料夾的答案優先）
    if prior_file and os.path.isfile(prior_file) and \
            os.path.normcase(prior_file) not in [os.path.normcase(p) for p in sources if p]:
        sources.append(prior_file)
    by_prior_position = {}    # v1.25.0：檔案沒變的上一輪，(編號, 段次) → 答案
    prior_new_rows = []
    for position, path in enumerate(sources):
        if not path or not os.path.isfile(path):
            continue
        try:
            with open_csv(path) as f:
                reader = csv.DictReader(f)
                old_rows = list(reader)
                old_fields = list(reader.fieldnames or [])
        except (OSError, UnicodeDecodeError, csv.Error, ValueError) as exc:
            from _common import warn_read_failure
            warn_read_failure(path, exc, "審查答案無法沿用" + ("，已中止打包並保留原檔" if position == 0 else "，略過這份上一輪資料"), "審查打包")
            if position == 0:
                raise ReviewPackError("%s 讀不出來：請關掉 Excel 或另存成 CSV UTF-8 後再跑（%s）" % (path, exc)) from exc
            continue
        for row in old_rows:
            if (row.get("沿用查證") or "").strip():
                continue
            answers = dict((c, row.get(c) or "") for c in columns)
            if not any(v.strip() for v in answers.values()):
                continue
            if header[0] == "引用ID" and (row.get("引用ID") or "").strip() == "新增":
                if position == 0:
                    extra_rows.append([row.get(c) or "" for c in header])   # AI 自己加的漏抓列照留
                elif carry_new_rows and prior_file and os.path.normcase(path) == os.path.normcase(prior_file):
                    prior_new_rows.append([row.get(c) or "" for c in header])
                continue
            if position and not previous_round:
                continue              # 外部引用：上一輪那一份只拿 AI 補的新增列，其餘交給查證快取
            if position and prior_file and os.path.normcase(path) == os.path.normcase(prior_file):
                by_prior_position.setdefault(((row.get(header[0]) or "").strip(), (row.get(header[1]) or "").strip()),
                                             answers)
            key = (row.get(key_column) or "").strip()
            spot_here = (row.get(header[1]) or "").strip()
            if position == 0:
                answered_here.add(("指紋", key, spot_here) if key
                                  else ("位置", (row.get(header[0]) or "").strip(), spot_here))
            if key and (key not in carried or carried[key][0] == position):
                # 同一個指紋可能有好幾列（同一段字出現在不同段次）：每一列的答案連它的位置一起記，
                # 帶回時照位置對，不能讓第一列的答案蓋到別列（B17）
                carried.setdefault(key, [position, {}])[1][(row.get(header[1]) or "").strip()] = answers
            elif not key and position == 0 and key_column not in old_fields:
                # 整張表都沒有指紋欄（這一版之前的表）才照位置沿用；有欄、只是這一列被清空的不沿用——
                # 照位置帶回去會配上新的指紋，舊答案掛到新的字上、匯入也驗不出來（審查 C11）
                spot = ((row.get(header[0]) or "").strip(), (row.get(header[1]) or "").strip())
                by_position.setdefault(spot, answers)
    out_rows, count = [], 0
    banked = [0]
    # v1.39.0：承辦要 AI 改的那一段（disputed_keys：指紋 → 那一句意見），上一輪的答案是看著同一句判的就照帶，
    # 不然重判完的答案下一輪又被清掉、每一輪都重判
    import precedents as pc
    disputed = disputed_keys if isinstance(disputed_keys, dict) else dict.fromkeys(disputed_keys, True)
    source_marks = ([pc.seen_marks(outdir, filename)] + [pc.seen_marks_near(p, filename) for p in sources[1:]]
                    if disputed else [])
    new_marks, checked, unsafe_marks = {}, set(), set()
    older_rows = []           # 帶了舊答案（上一輪、答案庫）的列在 out_rows 的位置
    templates = 0
    for row in data_rows:
        row = list(row)
        key = str(row[key_index]).strip()
        mark = None
        older = False
        # 程式先填好的「類別」（登錄過的法規名稱）不算答案：以前算進去，AI 查好、還沒匯入的外部引用答案
        # 重新打包時整批被清空（審查 比對#6）
        prefilled = any(str(row[header.index(c)]).strip() for c in columns if c != "類別")
        answers = None
        if key in carried:
            spots = carried[key][1]
            if len(spots) == 1:
                spot = list(spots)[0]
            else:
                spot = str(row[1]).strip()                   # 好幾列同指紋：照位置，對不上就不帶
            answers = spots.get(spot)
            if answers is not None and key in disputed:
                seen = source_marks[carried[key][0]].get(key) == disputed[key]
                if carried[key][0] > 0 and not seen:
                    answers = None                   # v1.22.0：承辦在報告寫了不同意：上一輪的答案不帶，重判
                mark = disputed[key] if seen else None
            if answers is not None and carried[key][0] > 0:
                # v1.22.0：上一輪的答案，理由寫了 C3、段749 這種會跟著重編、移位的指向，就不帶（重判）：
                # 報告會把 C3 換成這一輪的第 3 處異動，指到無關的段落（審查 比對#1）
                import answer_bank as ab
                trusted = same_numbers and os.path.normcase(sources[carried[key][0]]) == os.path.normcase(prior_file)
                if not trusted and ab.points_elsewhere(answers, str(row[1]).strip(), spot):
                    answers = None
                older = answers is not None
            if answers is not None and carried[key][0] == 0:
                used_here.add(("指紋", key, spot))
        if answers is None and key not in no_position_keys:
            spot = (str(row[0]).strip(), str(row[1]).strip())
            answers = by_position.get(spot)
            if answers is not None:
                used_here.add(("位置",) + spot)
        if answers is None and same_spots and key not in disputed_keys and key not in no_position_keys:
            spot = (str(row[0]).strip(), str(row[1]).strip())
            if spot in same_spots and spot in by_prior_position:
                answers = by_prior_position[spot]         # v1.25.0：檔案沒變、內容核對過：照位置帶
                older = True
        if answers is None and previous_round and key and key not in disputed_keys:
            # v1.20.0：本工作區沒有，別的工作區審過一模一樣的字（AI答案庫）
            import answer_bank as ab
            answers = ab.get(filename, key, str(row[1]).strip())
            if answers:
                answers = dict((c, answers.get(c, "")) for c in columns)
                banked[0] += 1
                older = True
        if older and filename in TEMPLATE_TABLES and sr.NOT_ASKING_RE.search(answers.get("AI理由") or ""):
            answers, older = None, False
            templates += 1
        if answers and filename == "AI異動審查.csv":
            # v1.51.0：評分等級改了，舊答案（〔牴觸規定〕6 分、〔可能的影響〕3 分）先換成現行分數，不然帶回來匯入會退件
            import scoring_rubric as sr
            answers = sr.migrate_change_answer(answers)
        if answers and not prefilled:
            for column, value in answers.items():
                if column == "類別" and not str(value).strip():
                    continue                         # 舊答案沒寫類別：留程式照登錄表填的
                row[header.index(column)] = value
            count += 1
            if older:
                older_rows.append(len(out_rows))
        if key and key in disputed:
            checked.add(key)
            if answers and not prefilled and mark is not None:
                new_marks[key] = mark                # 帶回的是看著這句意見判的
            elif not answers and not prefilled:
                new_marks[key] = disputed[key]       # 交給 AI 看著這句意見重判
            else:
                unsafe_marks.add(key)
        out_rows.append(row)
    if filename in TEMPLATE_TABLES:
        cells = [dict(zip(header, row)) for row in out_rows]
        repeated = sr.repeated_reasons(cells)
        for index in older_rows:
            if sr.squash_reason(cells[index].get("AI理由")) in repeated:
                for column in columns:
                    out_rows[index][header.index(column)] = ""
                count -= 1
                templates += 1
    if templates:
        nt.notice(nt.REMINDER, "%s 有 %d 列舊答案是模板句（AI 自己還沒查完，或同一句整批複製），這次不帶回，要重判"
                  % (filename, templates), "review-pack")
    if disputed:
        for key in unsafe_marks:
            new_marks.pop(key, None)
        pc.save_seen_marks(outdir, filename, new_marks, checked)
    dropped = len(answered_here - used_here)
    if dropped:
        # 這一輪 AI 判過、但審的字已經變了（重跑了開始、補了語意改了候選）：舊答案不能套到新的字上
        nt.notice(nt.REMINDER, "%s 有 %d 列 AI 判過、但審的內容已經變了，這次要重判（其餘沿用）"
                  % (filename, dropped), "review-pack")
    out_rows += extra_rows
    if prior_new_rows:
        # v1.25.0：上一輪 AI 補的漏抓列（檔案沒變）：這一輪已經有同一段同一個名稱的（AI 又加了、或程式抓到了）就不帶
        have = set((str(r[1]).strip(), _squash_name(r[header.index("AI更正")] if "AI更正" in header else ""))
                   for r in extra_rows)
        caught = dict()
        for r in out_rows:
            caught.setdefault(str(r[1]).strip(), []).append(_squash_name(r[2]))
        for r in prior_new_rows:
            spot, name = str(r[1]).strip(), _squash_name(r[header.index("AI更正")] if "AI更正" in header else "")
            if (spot, name) in have or (name and any(name in got for got in caught.get(spot, []))):
                continue
            out_rows.append(r)
            count += 1
    new_path = _new_csv_path(final_path)
    if os.path.isfile(new_path):
        os.remove(new_path)             # 上一版程式留下的 .new.csv，不再需要
    with io.open(final_path, "w", encoding="utf-8-sig", newline="") as f:
        writer = csv.writer(f, quoting=csv.QUOTE_ALL)
        writer.writerow(header)
        for row in out_rows:
            writer.writerow(row)
    if count:
        kept.append("%s %d 列%s" % (filename, count, "（其中 %d 列是以前審過一樣的字（這個或別的工作區），從 AI 答案庫帶）" % banked[0]
                                     if banked[0] else ""))
    return final_path


# 每份審查包放了哪幾列、每列要讀哪幾本的異動清單（ai_tables.merge 寫先讀我.md 用）
PACK_INDEX = "審查包索引.json"
# 單一候選區塊自己就超過 max_chars 時，前後文縮到單側幾段再重算一次。
_SHRUNK_WINDOW = 3
_MIN_WINDOW = 0           # 縮到這樣（只留候選段本身）還超過，就切成幾份（_split_block）
# --max-chars 預設值。一份 LLM審查包_NN.md 的字元數上限（v1.51.0：60000 → 25000，比照法規審查包）。
DEFAULT_MAX_CHARS = 25000


def _split_block(block, budget):
    """單一候選縮到最小還超過 budget：切成幾份，每份不超過 budget。盡量切在換行，一行太長才切在字中間；
    不截掉原文。第 2 份起開頭寫明是同一列，AI 看完全部才判一列。"""
    head = block.split("\n", 1)[0]
    limit = max(200, budget - len(head) - 60)     # 留給第 2 份起的開頭那一行
    pieces, current = [], ""
    for line in block.split("\n"):
        while len(line) > limit:
            if current:
                pieces.append(current)
                current = ""
            pieces.append(line[:limit])
            line = line[limit:]
        if current and len(current) + 1 + len(line) > limit:
            pieces.append(current)
            current = ""
        current += ("\n" if current else "") + line
    if current:
        pieces.append(current)
    total = len(pieces)
    return [piece if i == 0 else "%s（續，第 %d／%d 份；同一列，全部看完才判一列）\n%s" % (head, i + 1, total, piece)
            for i, piece in enumerate(pieces)]


def _pack_chunks(blocks, per_file, max_chars):
    """把候選區塊切成一份一份的審查包。

    切檔規則有兩條，先到先切：
        一、區塊數達 per_file
        二、累計字元數加上下一個區塊會超過 max_chars

    為什麼要數字數：舊寫法只數區塊（`blocks[i:i+per_file]`），
    一個候選掛十幾處異動時單一區塊就好幾萬字，實測單檔 13.7 萬字——貼進 AI
    直接超過脈絡長度，人要自己在 Notepad 裡切，而且切在哪裡沒有規則可循。

    單一區塊本身就超過 max_chars 的不會到這裡：呼叫端先縮前後文，還超過就用 _split_block 切開。
    """
    chunks = []
    current = []
    used = 0
    for block in blocks:
        size = len(block) + 2      # 加上區塊之間的 "\n\n"
        if current and (len(current) >= per_file or
                        (max_chars and used + size > max_chars)):
            chunks.append(current)
            current, used = [], 0
        current.append(block)
        used += size
    if current:
        chunks.append(current)
    return chunks or [[]]


def write_pack(outdir, per_file=40, books=None, quiet=False, loaded_books=None,
               max_chars=DEFAULT_MAX_CHARS):
    """寫 LLM審查包_NN.md、LLM異動清單.md、AI候選判斷.csv、AI異動審查.csv。
    舊的 LLM審查包_*.md 先刪。books：{來源本名稱: 該本的產出資料夾}，跨本候選用；
    沒給 loaded_books 時才會逐一 load_book(path)。

    loaded_books：呼叫端已經把所有本都 load_book 過（{規章名: load_book 回傳值}）
    就傳這個，直接拿來用，不再逐本重新 load——batch-review-pack 原本 N 本各呼叫
    一次 write_pack，這裡又逐本重載全部本，N 本就是 N² 次 docx／csv 讀取。
    有給的話連自己這本也不重載：用 outdir 的資料夾名稱（batch 產出結構固定是
    <產出根目錄>/<規章名>）在 loaded_books 裡找，找不到才退回 load_book(outdir)
    （例如單本 review-pack，outdir 資料夾名稱不是規章名）。

    quiet=True 不印「候選 N 筆、異動 M 處、審查包 K 份」——batch-review-pack 逐本
    呼叫時自己會印帶規章名的那一行，兩行重複沒有意義；單本 review-pack CLI 不傳
    這個參數，行為不變。回傳 {"包": [...], "候選數", "異動數", "異動清單": 路徑,
    "保留填答": [檔名...]}。

    四張 AI 表每次都照這一輪的列重寫；AI 已經判過、審的內容（指紋）沒變的答案帶回同一列，
    重跑開始時連上一輪歸檔的那一份也讀（見 _write_ai_csv）。不再另存 .new.csv。

    max_chars：一份審查包的字元數上限（預設 DEFAULT_MAX_CHARS＝25000，
    CLI 是 `--max-chars`）。區塊數達 per_file **或** 再加一個區塊就超過 max_chars
    就換檔；0 表示不看字數、只數區塊。見 _pack_chunks 與 _SHRUNK_WINDOW。"""
    if loaded_books is not None:
        own_name = os.path.basename(os.path.normpath(outdir))
        book = loaded_books.get(own_name) or load_book(outdir)
    else:
        book = load_book(outdir)
        loaded_books = {}
        for name, path in (books or {}).items():
            loaded_books[name] = load_book(path)

    rows = book["rows"]
    changes = book["changes"]
    # 補載的來源本也用來產生審查包：指紋和印出來的跨本異動、提醒要出自同一份（v1.62.1）
    loaded_books = refresh_cross_book_sources(rows, book, loaded_books)

    change_blocks = [_change_list_block(i, ch, book) for i, ch in enumerate(changes, 1)]
    change_list_path = place(outdir, "LLM異動清單.md")
    from _common import write_generated
    import scoring_rubric as sr
    # 新訂整本都是新增：先講清楚，AI 才不會去找「舊版哪裡不見了」
    new_rule_note = ("本本是新訂規章：沒有現行版，每段都算新增。要判的是條文本身（前後文、別本、上位規定有沒有矛盾），"
                     "不是新舊差異。\n\n" if book.get("新訂") else "")
    write_generated(change_list_path, ("# 體檢：現有文件\n" if book.get("體檢") else sr.pointer("異動")) + "\n---\n\n" + new_rule_note + ("" if book.get("體檢") else _cover_note(book))
                    + ("\n\n".join(change_blocks) if change_blocks else "（沒有異動）") + "\n")

    # 每張 AI 表各自帶回 AI 判過的答案：一張填過、一張沒填是常態
    # （AI 先答完候選、異動那張還空著）。
    # 最後一欄是這一列審的是哪一段字的指紋（程式填、AI 不動）：重跑 compare 之後
    # 列ID 與段次常常一模一樣，只有字變了（五日 → 七日），只靠列ID 對的話，
    # 上一輪「建議改成五日」的理由會原封不動匯進這一輪的表。
    kept = []           # 沿用 AI 已判過的答案（見 _write_ai_csv）
    import precedents as pc
    cand_rows = [["R%d" % i, row.get("候選段次") or "", "", "", "", candidate_sha256(row, book)]
                 for i, row in enumerate(rows, 1)]
    disputed = dict((r[-1], pc.disputed(row.get("候選全文"))) for r, row in zip(cand_rows, rows)
                    if pc.disputed(row.get("候選全文")))
    # v1.25.0：上一次比對讀的檔案一模一樣：程式改了指紋算法也照位置帶（內容逐列核對過）
    same_cand, same_change = _same_candidate_spots(outdir, rows, changes, unchanged_previous(outdir))
    _write_ai_csv(outdir, "AI候選判斷.csv",
                  ["列ID", "候選段次", "AI判斷", "AI分數", "AI理由", CAND_SHA_COLUMN],
                  cand_rows, kept, disputed_keys=disputed, same_spots=same_cand,
                  no_position_keys={r[-1] for r, row in zip(cand_rows, rows)
                                    if "：" in (row.get("異動條文ID") or "")
                                     or any(ch.get("移列") or _implied_move(ch, book) or _scope_reminder(ch, book, group_only=True)
                                            or _consecutive_reminder(ch, book)
                                            for name, ch in changes_for_row(row, book) if not name)})
    pack_dir = os.path.dirname(place(outdir, "LLM審查包_01.md"))
    rows = book["rows"]
    changes = book["changes"]

    blocks = [_candidate_block(i, row, book, loaded_books) for i, row in enumerate(rows, 1)]
    per_file = max(1, per_file)
    max_chars = max(0, int(max_chars or 0))

    # 評分標準整批只寫一份（AI審查/評分標準.md，見 ai_tables.merge）：每一份開頭只寫一行指過去。
    # 那一行也佔字數：--max-chars 是整份檔的上限，切包時要先扣掉它
    import scoring_rubric as sr
    cand_rubric = sr.pointer("候選") + "\n審查包的候選只寫異動編號；可用 `看列 <規章> R12` 一次看候選和對應異動。\n---\n\n"
    budget = max(1, max_chars - len(cand_rubric)) if max_chars else 0

    # 單一區塊自己就超過上限：先把那個候選的前後文縮到前後各 _SHRUNK_WINDOW 段重算一次（區塊尾巴會多一行說明），
    # 再縮到只剩候選段本身；還是超過就切成幾份（v1.51.0，以前照放＋提醒，超過平台讀取門檻 AI 讀不到）。
    # 原文一個字都不截掉，只是分開放
    split_rows = {}
    if budget:
        for i, block in enumerate(blocks):
            if len(block) <= budget:
                continue
            for window in (_SHRUNK_WINDOW, _MIN_WINDOW):
                blocks[i] = _candidate_block(i + 1, rows[i], book, loaded_books, max_window=window)
                if len(blocks[i]) <= budget:
                    break
            else:
                split_rows[i] = _split_block(blocks[i], budget)

    pieces = []             # [(列ID, 區塊)]；切開的列有好幾筆
    for i, block in enumerate(blocks):
        pieces += [("R%d" % (i + 1), part) for part in split_rows.get(i, [block])]
    block_rows = dict((id(block), rid) for rid, block in pieces)
    from _common import open_csv, write_generated
    with open_csv(locate(outdir, "AI候選判斷.csv")[0]) as f:
        answered = {r.get("列ID") for r in csv.DictReader(f) if (r.get("AI判斷") or "").strip()}
    ordered = sorted((block for _rid, block in pieces), key=lambda block: block_rows[id(block)] in answered)
    chunks = _pack_chunks(ordered, per_file, budget) if ordered else [[]]
    pack_paths = []
    pack_index = {}
    for idx, chunk in enumerate(chunks, 1):
        path = place(outdir, "LLM審查包_%02d.md" % idx)
        content = "\n\n".join(chunk) if chunk else "（沒有候選）"
        write_generated(path, cand_rubric + content + "\n")
        pack_paths.append(path)
        pack_index[os.path.basename(path)] = list(dict.fromkeys(block_rows[id(block)] for block in chunk))
    # 只刪不再使用的舊包，相同內容的包保留原檔。
    current = {os.path.abspath(p) for p in pack_paths}
    for folder in {pack_dir, os.path.abspath(outdir)}:
        for stale in glob.glob(os.path.join(folder, "LLM審查包_*.md")):
            if os.path.abspath(stale) not in current:
                os.remove(stale)
    # 每一列候選掛哪幾本的異動清單（跨本候選要讀來源本那一份）：先讀我.md 照這個列要讀的檔
    needs = dict(("R%d" % i, sorted(set(name for name, _ in changes_for_row(row, book, loaded_books) if name)))
                 for i, row in enumerate(rows, 1))
    with io.open(place(outdir, PACK_INDEX), "w", encoding="utf-8") as f:
        json.dump({"審查包": pack_index, "跨本異動清單": needs}, f, ensure_ascii=False)
    for i, parts in split_rows.items():
        nt.notice(nt.REMINDER, "R%d 單一候選超過 %d 字，已切成 %d 份放進審查包（同一列，全部看完才判一列）"
                  % (i + 1, max_chars, len(parts)), "review-pack")

    # 「查證來源」：放寬或限縮義務的異動，AI 要先上網查上位規定（見 scoring_rubric 的異動評分）
    _write_ai_csv(outdir, "AI異動審查.csv",
                  ["異動ID", "新版段次", "AI判斷", "AI分數", "AI理由", "查證來源", CHANGE_SHA_COLUMN],
                  [["C%d" % i, ch.get("new_index") or "刪除", "", "", "", "", change_sha256(ch, book)]
                   for i, ch in enumerate(changes, 1)], kept,
                  answer_columns=AI_ANSWER_COLUMNS + ("查證來源",),
                  disputed_keys=dict((change_sha256(ch, book), pc.disputed(ch.get("new_text"), ch.get("old_text")))
                                     for ch in changes if pc.disputed(ch.get("new_text"), ch.get("old_text"))),
                  same_spots=same_change,
                  no_position_keys={change_sha256(ch, book) for ch in changes
                                    if ch.get("移列") or _implied_move(ch, book) or _scope_reminder(ch, book, group_only=True)})

    external_count, suspect_count = _external_pack(outdir, book, kept)
    rulecheck_count = _rulecheck_pack(outdir, book, kept)

    if not quiet:
        print("候選 %d 筆、異動 %d 處、審查包 %d 份、外部規章引用 %d 處（另有 %d 段可能漏抓，一起給 AI 看）、"
              "條文檢查高風險 %d 項"
              % (len(rows), len(changes), len(pack_paths), external_count, suspect_count, rulecheck_count))
        if kept:
            print("沿用 AI 已判過、內容沒變的答案：%s（只有其他列要 AI 判）" % "、".join(kept))
    return {"包": pack_paths, "候選數": len(rows), "異動數": len(changes),
            "異動清單": change_list_path, "保留填答": kept,
            "外部引用數": external_count, "可能漏抓段數": suspect_count, "條文檢查數": rulecheck_count}
