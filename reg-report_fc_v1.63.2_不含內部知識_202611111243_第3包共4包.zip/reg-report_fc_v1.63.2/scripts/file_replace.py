# -*- coding: utf-8 -*-
"""換檔、改名、搬檔的共用入口：檔案暫時被占用時等一下重試（v1.55.0）。

Windows 上換掉已存在的檔案，偶爾會撞到別的程式短暫開著它（多半是防毒掃描，公司電腦更常見），
os.replace 丟 PermissionError。實測幾毫秒後重試就過，所以直接失敗會讓正式流程無故中斷。
重試有上限：真的開在 Excel 裡的檔，等完還是把原本的例外丟出去，呼叫端照原本的方式處理，不會假裝成功。

scripts/ 底下的程式換檔一律走 replace_file，不要直接呼叫 os.replace（test_v1550_r_replace 會查）。
這裡每次都用 os.replace、os.rename 本身，測試 mock.patch.object(某模組.os, "replace", ...) 才模擬得到失敗。
這個檔只用標準函式庫、不 import 專案模組，放在 scripts/（_common 會把它加進 sys.path）。
"""
import math
import os
import shutil
import time

MAX_WAIT = 2.0            # 總共最多等幾秒：比防毒久一點，但不能讓人以為當掉
QUICK_WAIT = 0.2          # 只是偵測開著沒有：幾毫秒的掃描等得過，真的開著的檔不用每個等滿
FIRST_PAUSE = 0.005
LONGEST_PAUSE = 0.5
WAIT_ENV = "REG_REPLACE_MAX_WAIT"     # 測試用：只能縮短，見 tests/_test_env.py
BUSY_CODES = (5, 32, 33)  # 拒絕存取、共用違規、鎖定違規


def _busy(exc):
    return isinstance(exc, PermissionError) or getattr(exc, "winerror", None) in BUSY_CODES


def _limit(max_wait):
    try:
        limit = float(os.environ.get(WAIT_ENV, MAX_WAIT))
    except ValueError:
        limit = MAX_WAIT
    if not math.isfinite(limit) or not 0 <= limit <= MAX_WAIT:
        limit = MAX_WAIT
    return limit if max_wait is None else min(limit, max_wait)


def _retry(action, src, dst, max_wait):
    limit = _limit(max_wait)
    waited = 0.0
    pause = FIRST_PAUSE
    while True:
        try:
            return action(src, dst)
        except OSError as exc:
            if not _busy(exc) or waited >= limit:
                raise
        pause = min(pause, LONGEST_PAUSE, limit - waited)
        time.sleep(pause)
        waited += pause
        pause *= 2


def replace_file(src, dst, max_wait=None):
    """os.replace，暫時被占用時重試。失敗時 src、dst 都維持原樣，例外照丟。"""
    _retry(os.replace, src, dst, max_wait)


def rename_file(src, dst, max_wait=None):
    """os.rename，暫時被占用時重試。跟 os.rename 一樣不蓋掉已存在的檔（Windows）。"""
    _retry(os.rename, src, dst, max_wait)


def remove_file(path):
    """os.remove，暫時被占用時重試。檔案不存在照丟 FileNotFoundError。"""
    _retry(lambda src, _dst: os.remove(src), path, None, None)


def move_path(src, dst):
    """shutil.move，暫時被占用時重試。

    不能直接重試 shutil.move：它改名失敗會改成複製再刪，暫時的占用會變成搬一半、重試又把資料夾搬進目的地裡。
    所以先重試改名；改名還是不行（跨磁碟、一直被占用）才交給 shutil.move 照原本的方式做。"""
    if not os.path.lexists(dst):
        try:
            rename_file(src, dst)
            return
        except OSError:
            pass
    shutil.move(src, dst)
