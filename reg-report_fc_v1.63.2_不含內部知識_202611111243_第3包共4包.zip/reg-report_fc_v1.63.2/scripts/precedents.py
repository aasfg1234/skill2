# -*- coding: utf-8 -*-
"""
承辦意見與本單位判例（v1.20.0；v1.22.0 依深度審查重寫對列、判例、白名單）。

檢視報告的主要幾頁最後多一欄「承辦意見」：承辦看報告時直接打（同意、不同意：理由、不是錯字……）。
- 報告重出前，先把舊報告（這一輪的，加上前一輪的）裡的承辦意見讀回來、填回新報告的同一列。
  對列只用每一頁固定幾個不會變的欄（規章、段落原文、法規名稱……，不用段次：前面插一段也對得到）；
  兩列這幾欄完全一樣時照出現順序對，不會互相蓋掉。
- 有意見的列存成「本單位判例」（memoization/內部知識/判例.json）：一列一則，承辦改了意見就換成新的。
  評分標準附最近 30 則（承辦不同意的排前面），AI 慢慢學會本單位的判斷標準。
  承辦不同意的那一段，下一輪不沿用舊答案（見 disputed），一定重判。
- 錯漏字的列寫「不是錯字」：那一列「建議處理」裡「X」改成「Y」的 X（原文片段）記進錯漏字白名單，
  以後同一個原文片段不再列（比對原文片段要完全一樣，不用子字串）。

判例、白名單都是本單位資料：放 memoization/內部知識/，打包分享時照使用者選擇決定要不要包。

v1.54.0：同一份安裝給兩個單位用時，A 的判例不能印給 B 看。判例、準則、白名單寫入時記「單位」（設定頁的單位類型、業務範圍），
讀出時只給同單位（current_unit、same_unit、unit_visible）。舊資料沒有標記：不知道是誰的，照舊顯示；不主動刪改，同一列有人寫新意見時照舊更新。

v1.57.0：條文比對報告同一處修改收成一列（收合列），每一段原本那一列放「各段明細」頁。收合列跟法規追蹤「依段落彙整」的合併列
走同一套規矩（一格管好幾段、新報告講過的段舊意見不再算、段拆開了意見跟著回到每一段）；差別只在成員：
合併列的成員是段落全文（查段次總表），收合列的成員是各段明細的整列 {"鍵": 那一段單獨成列時的鍵, "列": 那一列}。
"""

import datetime
import csv
import glob
import hashlib
import os
import re
from file_replace import replace_file

OPINION = "承辦意見"
READS_OPINION_TITLE = True      # xlsx_writer 看到這個才把表頭換成「承辦意見（空白＝同意；…）」
_BOOK_KEY_COLUMNS = ("修改規章", "候選規章", "規章", "規章A", "規章B")
_BOOK_PREFIX = re.compile(r"^[（(][^（）()]{1,40}[）)]")
MERGED_SHEET = "依段落彙整"       # 法規追蹤這一頁同一句「請確認」的段會合成一列，段次欄寫「56、63」
SEGMENT_SHEET = "段次總表"
MEMBERS = "合併原文"             # 判例列 dict 裡記合併列每一段全文的鍵（不是報告的欄）
COMPARE_SHEET = "條文比對報告"
DETAIL_SHEET = "各段明細"        # 同一處修改收成一列時，每一段原本那一列放這一頁（沒有承辦意見欄）
HEAD_COLUMN = "收合列序號"       # 各段明細這一段屬於條文比對報告哪一列
COLLAPSED_KIND = "同一處修改"    # 收合列「檢查類型」欄的開頭：讀回報告時靠它認收合列
DELETED_TEXT = "（本段已刪除）"
_LINE_SPLIT = re.compile(r"[、,，\s]+")
# 加「承辦意見」欄的頁
OPINION_SHEETS = ("依段落彙整", "法規影響報告", "條文比對報告", "條文檢查報告", "引用檢查報告", "重複矛盾報告")
# 對同一列用的欄（有哪幾欄用哪幾欄）：都是程式列的、AI 重判也不會變的。段次不用：前面插一段，段次全部移位
KEY_COLUMNS = ("法規名稱", "條號", "公布或修正日", "修改規章", "修改段落原文", "候選規章", "候選段落原文",
               "規章A", "原文A", "規章B", "原文B", "檢查項目", "規章", "段落原文", "原文", "引用")
# 舊報告沒有上面任何一欄時，退回用「這些以外的欄」
_VOLATILE = ("序號", "AI判定", "判定", "最高判定", "判定分數(0-10)", "最高分數", "判定理由", "建議處理", OPINION,
             "官方來源", "事件ID", "列ID", "查證來源", "相關法規", "檢查類型", "法規原文")
# 判例裡記「這一段原文」的欄（承辦不同意的段落，下一輪不沿用舊答案）
_TEXT_COLUMNS = ("段落原文", "候選段落原文", "修改段落原文", "原文A", "原文B", "原文")
JUDGEMENTS = "判例.json"
WHITELIST = "錯漏字白名單.json"
LIMIT = 30
TYPO_VERDICT = "錯漏字"
_FIX_RE = re.compile(r"「([^」]{2,40})」改成「")
_SQUASH = re.compile(r"[\s\x00-\x1f￾￿]+")


def folder():
    import batch
    return os.path.join(batch.cache_dir(), "內部知識")


# ---------------------------------------------------------------------------
# 單位（v1.54.0）
# ---------------------------------------------------------------------------

UNIT = "單位"
OTHER_UNITS = "其他單位"       # 白名單的鍵是詞本身，別的單位也說不是錯字時記在這裡


def current_unit(settings=None):
    """目前設定頁的分析單位：{"類型": 字串, "業務範圍": [字串]}。settings＝設定那一段；沒給就讀設定.html。"""
    if settings is None:
        try:
            from _common import config_section
            settings = config_section("設定")
        except Exception:
            settings = {}
    import unit_profile as up
    return {"類型": str((settings or {}).get(up.UNIT_KEY) or "").strip(),
            "業務範圍": up.split_values(str((settings or {}).get(up.SCOPE_KEY) or ""))}


def _unit_parts(unit):
    """(類型, 業務範圍集合)；舊標記、壞標記都當空白。"""
    if not isinstance(unit, dict):
        return "", set()
    scope = unit.get("業務範圍")
    if isinstance(scope, str):
        scope = [scope]
    return str(unit.get("類型") or "").strip(), set(str(x).strip() for x in scope or [] if str(x).strip())


def same_unit(stored, current):
    """True＝同單位（類型相同、業務範圍有交集）；False＝不同；None＝不確定（有一邊空白，兩邊有填的又沒有對不上）。
    不用整串指紋比：業務範圍多勾、少勾一項還是同一個單位，歷史判例不能因此全部消失。"""
    kind_a, scope_a = _unit_parts(stored)
    kind_b, scope_b = _unit_parts(current)
    if kind_a and kind_b and kind_a != kind_b:
        return False
    if scope_a and scope_b and not scope_a & scope_b:
        return False
    return True if kind_a and kind_b and scope_a and scope_b else None


def _unit_filled(unit):
    kind, scope = _unit_parts(unit)
    return bool(kind and scope)


def unit_visible(entry, current=None):
    """這一則（判例、準則、白名單、審查經驗）能不能給目前單位看。
    沒標記、或寫入時單位空白：不知道是誰的，照舊顯示（舊資料的取捨）。
    有標記而現在這邊沒填完：可能是新裝還沒設定的別單位，不給；標記和目前設定完全相同時例外。"""
    current = current_unit() if current is None else current
    others = entry.get(OTHER_UNITS)
    for mark in [entry.get(UNIT)] + (others if isinstance(others, list) else []):
        if not any(_unit_parts(mark)) or _unit_parts(mark) == _unit_parts(current):
            return True      # 標記和目前設定一模一樣就是自己，只填一半也一樣
        verdict = same_unit(mark, current)
        if verdict or (verdict is None and _unit_filled(current)):
            return True
    return False


def _tag(text):
    return hashlib.sha1(text.encode("utf-8")).hexdigest()[:8]


def split_key(key, unit):
    """同一個鍵被別的單位用掉時改用的鍵：後面加這個單位的範圍指紋。"""
    kind, scope = _unit_parts(unit)
    return "%s@%s" % (key, _tag("、".join(sorted(scope)) or kind))


def own_key(table, base, unit=None):
    """這個單位的這一則存在 table 的哪個鍵。鍵帶單位類型，類型不同的單位不會用到同一個鍵；單位類型空白時用原本的鍵。
    這只能避開看得到的：隔離區看不到別單位的條目，同類型、業務範圍沒交集時還是可能跟它同鍵，
    那種情況靠帶回時 memo_merge 依條目的單位分開，不是靠這裡。
    第三層（類型指紋＠範圍指紋）照前綴找：業務範圍微調後指紋不同，同一列還是同一則。"""
    unit = current_unit() if unit is None else unit
    kind = _unit_parts(unit)[0]
    tagged = "%s@%s" % (base, _tag(kind)) if kind else base
    for key in (tagged, base):
        if key in table and unit_visible(table[key], unit):
            return key
    prefix = tagged + "@"
    for key in sorted(table):
        if key.startswith(prefix) and unit_visible(table[key], unit):
            return key
    return split_key(tagged, unit) if tagged in table else tagged


def _word_marks(entry):
    others = entry.get(OTHER_UNITS)
    return [mark for mark in [entry.get(UNIT)] + (others if isinstance(others, list) else []) if any(_unit_parts(mark))]


def join_word(local, remote):
    """白名單同一個詞、兩邊內容不同：本機那筆為主，倉庫那筆的單位併進「其他單位」。本機是沒標記的舊資料回 None（走一般合併）。"""
    marks = _word_marks(local)
    if not marks:
        return None
    added = []
    for mark in _word_marks(remote):
        if not any(same_unit(mark, known) is True for known in marks + added):
            added.append(mark)
    if not added:
        return dict(local)
    return dict(local, **{OTHER_UNITS: list(local.get(OTHER_UNITS) or []) + added})


def visible_word(entry, unit):
    """倉庫裡這個詞給這個單位看的樣子：別單位的標記、說明都拿掉。"""
    others = entry.get(OTHER_UNITS)
    if not others:
        return entry
    if unit_visible({UNIT: entry.get(UNIT)}, unit):
        return dict((key, value) for key, value in entry.items() if key != OTHER_UNITS)
    mine = [mark for mark in (others if isinstance(others, list) else []) if unit_visible({UNIT: mark}, unit)]
    return {"詞": entry.get("詞"), UNIT: mine[0] if mine else {}}


def read_json(path, default):
    """讀累積資料的 JSON（v1.22.0）：記事本存的 BOM 也收；讀不出來（壞檔）把它改名留著，回 default——
    以前讀不出來當成空的，下一次存檔就把整份判例、答案庫蓋掉。"""
    from _common import tw_now, tw_today
    import json
    if not os.path.isfile(path):
        return default
    try:
        with open(path, encoding="utf-8-sig") as f:
            value = json.load(f)
    except ValueError:
        stamp = tw_now().strftime("%Y%m%d%H%M%S")
        try:
            replace_file(path, "%s.壞檔-%s" % (path, stamp))
            print("提醒：%s 讀不出來，已改名成 .壞檔-%s 留著（裡面的資料沒刪，可以自己修好再改回來）"
                  % (os.path.basename(path), stamp), flush=True)
        except OSError:
            pass
        return default
    except OSError:
        return default
    return value if isinstance(value, type(default)) else default


def _read(name, default):
    return read_json(os.path.join(folder(), name), default)


def _write(name, value):
    import json
    os.makedirs(folder(), exist_ok=True)
    path = os.path.join(folder(), name)
    with open(path + ".tmp", "w", encoding="utf-8") as f:
        json.dump(value, f, ensure_ascii=False, indent=1)
    replace_file(path + ".tmp", path)


def _squash(value):
    return _SQUASH.sub("", "" if value is None else str(value))[:200]   # 寫進 xlsx 會被清掉的字不算


def _cell(header, row, name):
    index = header.index(name) if name in header else None
    return str(row[index] or "") if index is not None and index < len(row) else ""


def _collapsed(sheet, header, row):
    """這一列是條文比對報告的收合列嗎（同一處修改收成的那一列）。"""
    return sheet == COMPARE_SHEET and _cell(header, row, "檢查類型").startswith(COLLAPSED_KIND)


def _base_key(sheet, header, row):
    columns = [i for i, name in enumerate(header) if name in KEY_COLUMNS]
    if not columns:
        columns = [i for i, name in enumerate(header) if name and name not in _VOLATILE]
    # 收合列的候選欄放的是最要處理的那一段，換人最高就會變：不算進鍵，同一處修改重出還是同一個鍵
    # （對不到單一異動的收合列沒有修改規章，候選規章就是它的規章，要留著）
    skip = ()
    if _collapsed(sheet, header, row):
        skip = ("候選規章", "候選段落原文") if _cell(header, row, "修改規章") else ("候選段落原文",)
    # 規章名去掉括號前綴再算鍵：v1.51.0 起報告顯示簡稱，全名時代寫的意見才對得上
    parts = [sheet] + ["" if header[i] in skip else
                       _squash(_BOOK_PREFIX.sub("", str(row[i] or "")) if header[i] in _BOOK_KEY_COLUMNS else row[i])
                       if i < len(row) else "" for i in columns]
    # 整段刪除的列修改段落原文都一樣，同一本全部只差「第幾個」：收合之後順序會變，要靠刪掉的字分開
    if sheet == COMPARE_SHEET and _cell(header, row, "修改段落原文").strip() == DELETED_TEXT:
        parts.append(_squash(_cell(header, row, "修改前原文")))
    return hashlib.sha256("\x00".join(parts).encode("utf-8")).hexdigest()[:24]


def row_keys(sheet, header, rows):
    """一頁每一列的鍵：頁名＋不會變的欄；這幾欄完全一樣的列加「第幾個」，不會互相蓋掉。"""
    seen = {}
    keys = []
    for row in rows:
        base = _base_key(sheet, header, row)
        seen[base] = seen.get(base, 0) + 1
        keys.append(base if seen[base] == 1 else "%s#%d" % (base, seen[base]))
    return keys


def row_key(sheet, header, row):
    """單獨一列的鍵（不管同頁有沒有重複的列）。"""
    return _base_key(sheet, header, row)


_REPORT_CACHE = {}        # (路徑, 修改時間, 大小) → 讀好的頁；同一行程內同一份報告只解析一次（v1.51.0）


def _opinion_sheets(path, sheets=OPINION_SHEETS):
    """報告裡有承辦意見欄的那幾頁（OPINION_SHEETS）：[(頁名, 列 list[list[str]], set())]。
    只解析這幾頁、跳過「段次總表」（最大的一頁，沒有意見欄）；不靠套件，跟 report_review._sheets_with_hidden 同一套讀法。"""
    import xml.etree.ElementTree as ET
    import zipfile
    import _common as cm
    found = []
    with zipfile.ZipFile(path) as archive:
        workbook = ET.fromstring(archive.read("xl/workbook.xml"))
        names = [node.get("name") for node in workbook.findall("m:sheets/m:sheet", cm._XLSX_NS)]
        wanted = [name for name in names if name in sheets]
        if not wanted:
            return []
        shared = cm._xlsx_shared_strings(archive)
        for name in wanted:
            tree = ET.fromstring(archive.read(cm._xlsx_sheet_part(archive, name)))
            rows = []
            for row in tree.findall(".//m:sheetData/m:row", cm._XLSX_NS):
                row_number = int(row.get("r") or len(rows) + 1)
                while len(rows) < row_number - 1:
                    rows.append([])
                cells = {}
                for position, cell in enumerate(row.findall("m:c", cm._XLSX_NS)):
                    ref = cell.get("r") or ""
                    index = cm._xlsx_col_index(ref) if ref else position
                    kind = cell.get("t")
                    if kind == "s":
                        value = cell.find("m:v", cm._XLSX_NS)
                        text = shared[int(value.text)] if value is not None and value.text else ""
                    elif kind == "inlineStr":
                        inline = cell.find("m:is", cm._XLSX_NS)
                        text = "".join(t.text or "" for t in inline.findall(".//m:t", cm._XLSX_NS)) if inline is not None else ""
                    else:
                        value = cell.find("m:v", cm._XLSX_NS)
                        text = value.text if value is not None and value.text is not None else ""
                    cells[index] = text
                rows.append([cells.get(i, "") for i in range((max(cells) + 1) if cells else 0)])
            found.append((name, rows, set()))
    return found


def _load_report(path):
    stat = os.stat(path)
    key = (os.path.normcase(os.path.abspath(path)), stat.st_mtime_ns, stat.st_size)
    hit = _REPORT_CACHE.get(key)
    if hit is not None:
        return hit
    sheets = _opinion_sheets(path, OPINION_SHEETS + (DETAIL_SHEET,))
    _REPORT_CACHE[key] = sheets
    return sheets


def report_readable(path):
    """這份報告的承辦意見讀得到嗎：真的解析裡面的 XML（zip 目錄完好、內容壞掉也算讀不到）。不印警告。"""
    try:
        _load_report(path)
    except Exception:
        return False
    return True


def _read_report(path):
    """v1.51.0：只讀有承辦意見欄的頁（跳過段次總表），同一行程內以路徑＋修改時間＋大小快取。"""
    try:
        sheets = _load_report(path)
    except Exception as exc:
        from _common import warn_read_failure
        warn_read_failure(path, exc, "無法取得承辦意見；若是本資料夾最新報告，不改用更舊報告回填，請修復後重跑", "承辦意見")
        raise
    return sheets


def _segment_table(header, rows):
    """段次總表的列 → {(規章, 段次): 全文}。規章全名、去掉前綴的簡稱都查得到（兩本簡稱相同時報告本來就留全名）。"""
    if not all(name in header for name in ("規章", "段次", "全文")):
        return {}
    book, line, text = header.index("規章"), header.index("段次"), header.index("全文")
    version = header.index("版本") if "版本" in header else None
    table = {}
    for row in rows:
        if len(row) <= max(book, line, text) or (version is not None and row[version] != "現行版"):
            continue
        for name in (str(row[book]), _BOOK_PREFIX.sub("", str(row[book]))):
            table.setdefault((name, str(row[line]).strip()), str(row[text]))
    return table


def _segments_of(path):
    """這份報告的段次總表（讀過就留著；只有承辦在合併列寫了字才會讀到這裡）。"""
    stat = os.stat(path)
    key = (os.path.normcase(os.path.abspath(path)), stat.st_mtime_ns, stat.st_size, SEGMENT_SHEET)
    if key not in _REPORT_CACHE:
        sheets = _opinion_sheets(path, (SEGMENT_SHEET,))
        rows = sheets[0][1] if sheets else []
        _REPORT_CACHE[key] = _segment_table(rows[0], rows[1:]) if rows else {}
    return _REPORT_CACHE[key]


def _merged_lines(sheet, header, row):
    """合併列的段次（「56、63」→ ["56", "63"]）；不是合併列回 []。"""
    if sheet != MERGED_SHEET or "段次" not in header:
        return []
    index = header.index("段次")
    lines = [x for x in _LINE_SPLIT.split(str(row[index] if index < len(row) else "")) if x.isdigit()]
    return lines if len(lines) > 1 else []


def _detail_groups(header, rows):
    """各段明細的列 → {收合列序號: [成員]}；成員＝{"鍵": 那一段單獨成列時的鍵, "列": 那一列 dict}。"""
    if HEAD_COLUMN not in header:
        return {}
    index = header.index(HEAD_COLUMN)
    groups = {}
    for row in rows:
        number = str(row[index] if index < len(row) else "").strip()
        if number:
            groups.setdefault(number, []).append({"鍵": _base_key(COMPARE_SHEET, header, row),
                                                  "列": dict(zip(header, row))})
    return groups


def _report_groups(path):
    """這份報告的各段明細（同一行程內讀過就留著）。"""
    stat = os.stat(path)
    key = (os.path.normcase(os.path.abspath(path)), stat.st_mtime_ns, stat.st_size, DETAIL_SHEET)
    if key not in _REPORT_CACHE:
        rows = next((rows for name, rows, _hidden in _read_report(path) if name == DETAIL_SHEET), [])
        _REPORT_CACHE[key] = _detail_groups(rows[0], rows[1:]) if rows else {}
    return _REPORT_CACHE[key]


def _head_number(header, row):
    return _cell(header, row, "序號").strip()


def _member_texts(table, header, row, lines):
    """合併列每一段的全文：照 規章＋段次 回查段次總表，查不到的段略過。"""
    index = header.index("規章") if "規章" in header else None
    book = str(row[index]) if index is not None and index < len(row) else ""
    names = (book, _BOOK_PREFIX.sub("", book))
    found = (next((table[(name, line)] for name in names if (name, line) in table), None) for line in lines)
    return [text for text in found if text]


def _report_members(path, sheet, header, row):
    """報告裡一列合併列每一段的全文（寫判例用）。段次總表讀不到時只留第一段，印一行提醒。
    收合列回各段明細的成員；找不到（承辦把那一頁刪了）只留收合列本身，印一行提醒。"""
    if _collapsed(sheet, header, row):
        members = _report_groups(path).get(_head_number(header, row), [])
        if not members and _cell(header, row, OPINION).strip():
            print("提醒：條文比對報告序號 %s 在「各段明細」頁對不到，這句意見只留在這一列，"
                  "那幾段下一輪不會因這句意見重判" % _head_number(header, row), flush=True)
        return members
    lines = _merged_lines(sheet, header, row)
    if not lines:
        return []
    try:
        members = _member_texts(_segments_of(path), header, row, lines)
    except Exception as exc:
        members = []
        print("提醒：讀不到 %s 的段次總表（%s）" % (os.path.basename(path), exc), flush=True)
    if len(members) < len(lines):
        print("提醒：合併列段次 %s 有 %d 段對不到段次總表，那幾段下一輪不會因這句意見重判"
              % ("、".join(lines), len(lines) - len(members)), flush=True)
    return members


def _with_text(header, row, text):
    """同一列換一段原文（算那一段的列鍵）。"""
    index = header.index("段落原文")
    return [text if i == index else value for i, value in enumerate(row)]


def _member_key(row, member):
    """成員單獨成列時的鍵。row＝合併列的 dict；member＝段落全文，或收合列的成員。"""
    if isinstance(member, dict):
        return member["鍵"]
    header = [name for name in row if name not in ("頁", "鍵", MEMBERS)]
    return _base_key(row.get("頁", ""), header, _with_text(header, [row[name] for name in header], member))


def _member_aliases(opinions):
    """舊報告合併列的意見對到每一段：{那一段單獨成列時的鍵: (意見, 列)}。"""
    aliases = {}
    for value in opinions.values():
        row = value[1]
        for member in row.get(MEMBERS) or ():
            aliases.setdefault(_member_key(row, member), value)
    return aliases


def _same_key_opinions(opinions):
    """舊報告幾列完全一樣時，第二列起的鍵帶「#2」：{不帶 # 的鍵: [那幾列的意見]}。
    收合列的成員只有不帶 # 的鍵，要靠這張表才接得到第二列寫的字。"""
    table = {}
    for key, value in opinions.items():
        table.setdefault(key.split("#")[0], []).append(value)
    return table


def _collapsed_opinion(key, members, opinions, aliases):
    """收合列要填回的意見：這一列的舊意見，加上每一段的舊意見（段數變動、舊報告還是一段一列都帶得過來）。
    一格裡的意見可能已經是「；」接起來的：一樣的句子只留一次，同一格的句子順序不動，不同意的那一格排前面。"""
    found, known = [], set()
    same = _same_key_opinions(opinions)
    hits = [opinions.get(key) or aliases.get(key.split("#")[0])]
    for item in members:
        hits += same.get(item["鍵"]) or [aliases.get(item["鍵"])]
    for hit in hits:
        fresh = []
        for sentence in _sentences(hit[0]) if hit else []:
            normalized = sentence.strip()
            if normalized not in known:
                fresh.append(sentence)
                known.add(normalized)
        if fresh:
            found.append("；".join(fresh))
    return "；".join(sorted(found, key=lambda text: not disagrees(text)))


def _filled_opinion(name, header, row, key, opinions, aliases, segments, groups=None):
    """新報告這一列要填回的意見。一般的列：同一列的舊意見；舊報告是合併列時，這一段在裡面也算。
    合併列：每一段的舊意見都算（段數變動、舊報告還是單列時都帶得過來），不同意的排前面。
    收合列同一個規矩，成員來自這份報告的各段明細（groups）。"""
    if _collapsed(name, header, row):
        return _collapsed_opinion(key, (groups or {}).get(_head_number(header, row), ()), opinions, aliases)
    lines = _merged_lines(name, header, row)
    if not lines:
        hit = opinions.get(key)
        if not hit and name in (MERGED_SHEET, COMPARE_SHEET):
            hit = aliases.get(key.split("#")[0])
        return hit[0] if hit else ""
    texts = [str(row[header.index("段落原文")])] + _member_texts(segments, header, row, lines)
    found = []
    for text in texts:
        base = _base_key(name, header, _with_text(header, row, text))
        hit = opinions.get(base) or aliases.get(base)
        if hit and hit[0] not in found:
            found.append(hit[0])
    return "；".join(sorted(found, key=lambda text: not disagrees(text)))


def old_reports(base):
    """base（不帶副檔名）旁邊這一輪寫過的報告：檢視報告.xlsx、檢視報告_HHMMSS.xlsx……，新的在前。"""
    found = [p for p in glob.glob(glob.escape(base) + "*.xlsx") if not os.path.basename(p).startswith("~$")]
    # v1.26.0：報告改名之前寫的那一份（同一個資料夾的 檢視報告.xlsx）也讀，承辦寫的意見才帶得過來
    folder = os.path.dirname(os.path.abspath(base))
    for pattern in REPORT_PATTERNS:
        found += [p for p in glob.glob(os.path.join(glob.escape(folder), pattern))
                  if not os.path.basename(p).startswith("~$") and p not in found]
    return sorted(found, key=os.path.getmtime, reverse=True)


def _previous_reports(base):
    """前一輪的報告（重新比對、內規改過重跑法規追蹤會開新一輪：上一輪報告寫的意見要帶到新報告）。"""
    try:
        from _common import previous_output
        output = os.path.dirname(os.path.dirname(os.path.abspath(base)))
        prior = previous_output(output)
    except Exception:
        return []
    return report_files(prior) if prior and os.path.isdir(prior) else []


def _member_keys(path, sheet, header, row):
    """合併列每一段單獨成列時的鍵。段次總表讀不到或對不上的段不算：寧可舊意見留著，也不要弄丟。"""
    if _collapsed(sheet, header, row):
        return [item["鍵"] for item in _report_groups(path).get(_head_number(header, row), ())]
    lines = _merged_lines(sheet, header, row)
    try:
        texts = _member_texts(_segments_of(path), header, row, lines) if lines else []
    except Exception:
        return []
    return [_base_key(sheet, header, _with_text(header, row, text)) for text in texts]


def _newer_report_wins(found, origin, merged, shadowed=(), seen=None, legacy=()):
    """合併列一格管好幾段：新報告的合併列（不管寫了字還是承辦清空）已經替每一段講過話，
    更舊的報告裡那幾段的意見不再算，舊合併列也不再替新報告講過的段帶意見。
    新報告沒講到的段（不在合併列裡、段次總表對不上）的舊意見照留：舊合併列的第一段被新報告講過時，
    意見改掛在還沒人講過的那幾段上（_hand_over），不跟著第一段一起不見。
    found 就地改；origin＝{列鍵: 第幾份報告（0 最新）}，merged＝[(第幾份, 路徑, 頁, 表頭, 列, 列鍵)]；
    shadowed＝第一段的列鍵被新報告佔走的舊合併列 [(第幾份, 意見, 列 dict)]。
    v1.55.x：新合併列沒看過的字（seen 沒有這句，legacy 以外）不算它講過話，照留，跟 harvest 同一個規矩。"""
    seen = seen or {}
    oldest = max([origin[key] for key, value in found.items() if value] + [item[0] for item in shadowed], default=-1)
    spoken = {}
    heard = {}
    for order, path, sheet, header, row, row_key_ in merged:
        if order < oldest:                # 沒有比它舊的意見就不用讀段次總表
            for base in _member_keys(path, sheet, header, row):
                spoken[base] = min(spoken.get(base, order), order)
                if row_key_ in legacy:
                    heard[base] = None
                elif heard.get(base, ()) is not None:
                    heard.setdefault(base, set()).update(seen.get(row_key_, ()))

    def not_heard(base, text):
        return base in heard and heard[base] is not None and _text_print(text) not in heard[base]

    def unspoken(row, order):
        return [member for member in row.get(MEMBERS) or ()
                if min(spoken.get(_member_key(row, member), order), origin.get(_member_key(row, member), order)) >= order]

    handed = []
    for key, value in list(found.items()):
        if not value:
            continue
        order = origin[key]
        row = value[1]
        rest = unspoken(row, order)
        if spoken.get(key.split("#")[0], order) < order:
            if not_heard(key.split("#")[0], value[0]):
                continue
            found[key] = None
            handed.append((order, value[0], row, rest))
        elif row.get(MEMBERS):
            row[MEMBERS] = rest
    for order, text, row in shadowed:
        handed.append((order, text, row, unspoken(row, order)))
    for order, text, row, rest in handed:
        _hand_over(found, origin, order, text, row, rest)


def _hand_over(found, origin, order, text, row, rest):
    """舊合併列的意見改掛到 rest（新報告沒講到的那幾段）的第一段上。"""
    if not rest:
        return
    if isinstance(rest[0], dict):
        key = rest[0]["鍵"]
        if not found.get(key):
            found[key] = (text, dict(rest[0]["列"], 頁=row.get("頁", ""), 鍵=key, **{MEMBERS: rest}))
            origin[key] = order
        return
    header = [name for name in row if name not in ("頁", "鍵", MEMBERS)]
    values = [rest[0] if name == "段落原文" else row[name] for name in header]
    key = _base_key(row.get("頁", ""), header, values)
    if not found.get(key):
        found[key] = (text, dict(zip(header, values), 頁=row.get("頁", ""), 鍵=key, **{MEMBERS: rest}))
        origin[key] = order


# v1.55.x：出報告時有舊報告讀不到，那一份的承辦意見欄不完整：空白不等於承辦清掉了。
# 記在這裡，寫 {"報告": [檔名], "讀不到": [當時讀不到的檔，相對這一輪；可能在前一輪]}
OPINIONS_PENDING = "承辦意見未接回.json"
# 每份報告出的時候，每一列看過哪些意見 {報告檔名: {列鍵: [意見的指紋]}}。
# 空白、改字算不算數看它：看過那句才清掉或改掉，算承辦的決定；沒看過（別份才有的字）就兩邊都留
OPINIONS_SHOWN = "承辦意見底稿.json"
_COPY_NAME = re.compile(r"_\d{6}\.xlsx$")


def _log_file(report, name):
    """report：1_結果彙整/ 裡的報告（或不帶副檔名的 base）；紀錄檔放同一輪的 2_Log檔案/。
    不在 1_結果彙整/ 底下的報告不記（沒有「這一輪」可放），回 ""。"""
    from _common import SYSTEM_DIR
    folder = os.path.dirname(os.path.abspath(report))
    if os.path.basename(folder) != "1_結果彙整":
        return ""
    return os.path.join(os.path.dirname(folder), SYSTEM_DIR, name)


def _read_log(path):
    import json
    try:
        with open(path, encoding="utf-8-sig") as f:
            data = json.load(f)
    except (OSError, ValueError):
        return {}
    return data if isinstance(data, dict) else {}


def _pending_names(report):
    path = _log_file(report, OPINIONS_PENDING)
    names = _read_log(path).get("報告") if path else None
    return [str(name) for name in names] if isinstance(names, list) else []


def _note_pending(report, unreadable):
    """這份報告寫出來了：有舊報告讀不到＝意見不完整，記下來；完整就把紀錄清掉（舊的副本這時也收掉了）。"""
    from _common import to_record, write_generated
    path = _log_file(report, OPINIONS_PENDING)
    if not path:
        return
    folder = os.path.dirname(os.path.abspath(report))
    if unreadable:
        names = [n for n in _pending_names(report) if os.path.isfile(os.path.join(folder, n))]
        write_generated(path, {"報告": sorted(set(names + [os.path.basename(report)])),
                               "讀不到": [to_record(item, os.path.dirname(folder)) for item in unreadable]})
    elif os.path.isfile(path):
        os.remove(path)


def _note_shown(report, seen):
    """這份報告看過哪些意見（seen：{列鍵: 指紋 set}）。檔案已經不在的舊紀錄順手清掉。"""
    from _common import write_generated
    path = _log_file(report, OPINIONS_SHOWN)
    if not path:
        return
    folder = os.path.dirname(os.path.abspath(report))
    record = dict((name, value) for name, value in _read_log(path).items()
                  if os.path.isfile(os.path.join(folder, name)))
    record[os.path.basename(report)] = dict((key, sorted(value)) for key, value in seen.items())
    write_generated(path, record)


def _note_written(report, unreadable, seen):
    try:
        _note_shown(report, seen)
        _note_pending(report, unreadable)
    except OSError as exc:
        print("提醒：承辦意見的紀錄沒有更新（%s）" % exc, flush=True)


def _shown_opinions(report):
    """這份報告出的時候看過哪些意見 {列鍵: 指紋 list}；沒有紀錄（舊工作區、不是程式出的）回 None。"""
    path = _log_file(report, OPINIONS_SHOWN)
    value = _read_log(path).get(os.path.basename(report)) if path else None
    return value if isinstance(value, dict) else None


def _text_print(text):
    return hashlib.sha256(str(text).strip().encode("utf-8")).hexdigest()[:16]


def _text_prints(text):
    """一句意見的指紋，含「；」分開的每一段：兩份合併過的意見，之後跟單獨那一段也對得上。"""
    return set([_text_print(text)] + [_text_print(part) for part in str(text).split("；") if part.strip()])


def _unreadable_paths(output):
    from _common import from_record
    path = _log_file(os.path.join(output, "1_結果彙整", "x"), OPINIONS_PENDING)
    items = _read_log(path).get("讀不到") if path else None
    return [from_record(output, item) for item in items] if isinstance(items, list) else []


def opinions_pending(output):
    """這一輪有哪些舊報告當時讀不到、承辦意見還沒接回來：回傳檔名（只列還在的），沒有回 []。"""
    return sorted(set(os.path.basename(path) for path in _unreadable_paths(output) if os.path.exists(path)))


def opinions_recoverable(output):
    """當時讀不到的舊報告，現在有沒有一份讀得到（或被刪掉了）：有才值得重出。"""
    return any(not os.path.exists(path) or report_readable(path) for path in _unreadable_paths(output))


def known_unreadable(output, path):
    """這份已經記在「讀不到」裡（重出過了還是讀不到，不用再試）。"""
    target = os.path.normcase(os.path.abspath(path))
    return any(os.path.normcase(os.path.abspath(item)) == target for item in _unreadable_paths(output))


def _can_write(path):
    """寫得進去嗎（Excel 開著、同步占用都不行）。只開不寫，不動修改時間。
    不看 ~$ 檔：Excel 當掉會留下來，使用者看不到也沒開著；Excel 真的開著時這裡本來就開不了。"""
    try:
        os.close(os.open(path, os.O_RDWR))
    except OSError:
        return False
    return True


def _official_and_copies(output):
    """(這一輪的正式報告, 還要併回去的副本)。沒有底稿的副本（舊的，或底稿不見了）只有比正式報告新才算：
    字收進去之後它照規矩留著不刪，再併一次也沒有新東西。"""
    from _common import report_base_name, round_kind
    # 法規追蹤那一輪看資料夾名：round_kind 只分比對、體檢，沿用鏈靠它，不能在那裡加第三種
    law = os.path.basename(os.path.normpath(output)).endswith("_法規追蹤")
    official = os.path.join(output, "1_結果彙整", report_base_name(output, "法規追蹤" if law else round_kind(output)) + ".xlsx")
    stem = official[:-len(".xlsx")]
    if not os.path.isfile(official):
        return official, []
    return official, [path for path in report_files(output) if path.startswith(stem + "_") and _COPY_NAME.search(path)
                      and report_readable(path)
                      and (_shown_opinions(path) is not None or os.path.getmtime(path) > os.path.getmtime(official))]


def copies_to_merge(output):
    """這一輪另存的副本（報告_HHMMSS.xlsx），正式那一份現在寫得進去了：回傳可以併回去的副本，沒有回 []。
    副本還開著就先不併：併了也刪不掉，下一次又要併一次。"""
    official, copies = _official_and_copies(output)
    if not copies or not report_readable(official) or not _can_write(official):
        return []
    return [path for path in copies if _can_write(path)]


def reports_open(output):
    """有副本要併，但正式報告或副本還開著：回傳開著的檔名，沒有回 []。檔案壞了不算開著。"""
    official, copies = _official_and_copies(output)
    if not copies:
        return []
    return [os.path.basename(path) for path in [official] + copies if not _can_write(path)]


def _sentences(text):
    return [part for part in str(text).split("；") if part.strip()]


def _older_opinion(found, origin, seen, legacy, key, text, row, order):
    """更舊的報告同一列有字，新的那份已經講過話了：新的那份看過這句（清掉、改掉）就不要它；
    沒看過（另一份才有的字：副本出來之後才寫在正本上）兩邊都留。比的單位是「；」分開的一整句，不比子字串：
    「沒問題」不等於「沒問題嗎？這段應該要改」。"""
    known = seen.setdefault(key, set())
    latest = found.get(key)
    skip = key in legacy or _text_print(text) in known
    have = {sentence.strip() for sentence in _sentences(latest[0])} if latest else set()
    fresh = []
    for sentence in _sentences(text):
        normalized = sentence.strip()
        if normalized not in have and _text_print(sentence) not in known:
            fresh.append(sentence)
            have.add(normalized)
    known |= _text_prints(text)
    if skip or not fresh:
        return
    if latest:
        found[key] = (latest[0] + "；" + "；".join(fresh), latest[1])
    else:
        found[key] = ("；".join(fresh), row)
        origin[key] = order


def harvest(paths, unreadable=None, reports=None, counts=None, seen=None, held=None):
    """舊報告裡的承辦意見：{列鍵: (意見, 那一列 dict)}。新的報告優先（paths 新的在前）：
    新的那份同一列是空的（承辦清掉了），就不拿更舊那份的意見回來；合併列清空時，它底下每一段都算清空。
    v1.55.x：空白只有在「看過那句意見」的報告才算清掉（OPINIONS_SHOWN）。新的那份出的時候沒看過的字
    （出報告時舊報告讀不到；或副本出來之後才寫在正本上）照留，同一列兩份都有字就兩句都留。
    沒有紀錄的舊報告照以前的規矩。
    counts（dict，選填）：每份報告每一頁有字的承辦意見幾格 {報告路徑: {頁: 格數}}（v1.50.0 收回饋印給 AI 看）。
    seen（dict，選填）：每一列看過哪些意見 {列鍵: 指紋 set}，寫進這次報告的紀錄。
    held（list，選填）：讀得到、但這次沒收它的意見的檔（同資料夾最新那份讀不到），不能刪。"""
    found = {}
    origin = {}
    merged = []
    shadowed = []
    blocked = set()
    visited = set()
    seen = {} if seen is None else seen
    legacy = set()
    no_record = []
    with_copies = set(os.path.normcase(os.path.abspath(os.path.dirname(path))) for path in paths
                      if _COPY_NAME.search(os.path.basename(path)))
    for order, path in enumerate(paths):
        folder = os.path.normcase(os.path.abspath(os.path.dirname(path)))
        if folder in blocked and unreadable is None and reports is None:
            continue
        latest = folder not in visited
        visited.add(folder)
        try:
            sheets = _read_report(path)
        except Exception:
            if unreadable is not None:
                unreadable.append(path)
            if latest:
                blocked.add(folder)
            continue
        if reports is not None:
            reports.append(path)
        if folder in blocked:
            if held is not None:
                held.append(path)
            continue
        partial = os.path.basename(path) in _pending_names(path)
        shown = _shown_opinions(path)
        if shown is None and folder in with_copies and _log_file(path, OPINIONS_SHOWN):
            # 底稿不見或壞了，又有副本：看不出誰看過什麼，寧可字都留：空白不算清掉，副本這次也不刪
            # （不在 1_結果彙整/ 底下的報告本來就沒有底稿，照舊）
            shown = {}
            no_record.append(os.path.basename(path))
            if held is not None and _COPY_NAME.search(os.path.basename(path)):
                held.append(path)
        for sheet, rows, _hidden in sheets:
            header = [OPINION if str(cell).startswith(OPINION) else cell for cell in (rows[0] if rows else [])]
            if sheet not in OPINION_SHEETS or OPINION not in header:
                continue
            col = header.index(OPINION)
            body = rows[1:]
            if counts is not None:
                counts.setdefault(path, {})[sheet] = sum(1 for row in body if str((row[col] if col < len(row) else "") or "").strip())
            for report_row, (key, row) in enumerate(zip(row_keys(sheet, header, body), body), 2):
                detail = dict(zip(header, row), 頁=sheet, 鍵=key, 報告列=report_row, 報告檔名=os.path.basename(path))
                reason = str(detail.get("判定理由") or "")
                marker = re.search(r"…（全文見 2_Log檔案/([^/\\]+理由全文\.csv)）$", reason)
                if marker and str((row[col] if col < len(row) else "") or "").strip():
                    log_path = os.path.join(os.path.dirname(os.path.dirname(path)), "2_Log檔案", marker.group(1))
                    try:
                        with open(log_path, encoding="utf-8-sig", newline="") as handle:
                            matches = [r.get("判定理由全文", "") for r in csv.DictReader(handle)
                                       if r.get("頁") == sheet and r.get("序號") == str(detail.get("序號") or "")
                                       and r.get("判定理由全文", "").startswith(reason[:marker.start()])]
                        if len(matches) == 1:
                            detail["AI理由全文"] = matches[0]
                            detail["AI理由全文檔"] = log_path
                            detail["AI理由序號"] = str(detail.get("序號") or "")
                    except (OSError, csv.Error, UnicodeError):
                        pass
                is_merged = bool(_merged_lines(sheet, header, row)) or _collapsed(sheet, header, row)
                text = str((row[col] if col < len(row) else "") or "")
                if not text.strip() and (partial or (shown is not None and key not in shown)):
                    continue                  # 這格出報告時就是空的：沒看過舊意見，空白不算清掉
                if is_merged:
                    merged.append((order, path, sheet, header, row, key))
                if key in found:
                    members = _report_members(path, sheet, header, row) if is_merged and text else []
                    known = key in legacy or _text_print(text) in seen.get(key, ())
                    if is_merged and text and order > origin[key] and known:
                        shadowed.append((order, text, dict(detail, **{MEMBERS: members})))
                    elif text:
                        older = dict(detail)
                        if members:
                            older[MEMBERS] = members
                        _older_opinion(found, origin, seen, legacy, key, text, older, order)
                    continue
                origin[key] = order
                seen[key] = set(shown.get(key) or ()) if shown is not None else set()
                if shown is None:
                    legacy.add(key)
                if not text.strip():
                    found[key] = None
                    continue
                seen[key] |= _text_prints(text)
                found[key] = (text, detail)
                members = _report_members(path, sheet, header, row)
                if members:
                    found[key][1][MEMBERS] = members
    if no_record and held is not None:
        print("提醒：%s 沒有承辦意見底稿（不見或壞了）：這幾份的空白不算清掉，字都收進新報告；副本先留著不刪，"
              "確認新報告沒問題再自己刪" % "、".join(no_record), flush=True)
    _newer_report_wins(found, origin, merged, shadowed, seen, legacy)
    return dict((k, v) for k, v in found.items() if v)


def keep_opinions(sheets, options, base):
    """報告寫出前呼叫：加「承辦意見」欄、填回舊意見、存判例。出錯只印一行，不擋報告。
    v1.55.x：讀失敗和「真的沒有意見」分開。讀不到的舊報告不能被這次的報告蓋掉或刪掉（xlsx_writer.hold_reports），
    這次寫出來的報告記成「意見不完整」，下一次出報告時它的空白不算承辦清掉。"""
    unreadable = []
    seen = {}
    held = []
    filled = 0
    try:
        filled = add_opinion_column(sheets, options, base, unreadable, seen, held)
    except Exception as exc:                  # 舊報告壞掉、讀不到：報告照出，只是沒填回
        print("提醒：讀舊報告的承辦意見失敗（%s），這次報告的承辦意見欄是空的" % exc, flush=True)
        unreadable += [path for path in (old_reports(base) if base else []) if path not in unreadable]
    if base:
        import xlsx_writer as xw
        if hasattr(xw, "hold_reports"):
            xw.hold_reports(base, unreadable + held, lambda path: _note_written(path, unreadable, seen))
    if filled:
        print("承辦意見：從上一份報告填回 %d 格（判例已存進 memoization/內部知識/）" % filled, flush=True)
    return filled


def add_opinion_column(sheets, options, base, unreadable=None, seen=None, held=None):
    """報告寫出前：主要幾頁最後加「承辦意見」欄，填回舊報告的意見；有意見的列存成判例。
    sheets＝[(頁名, 表頭, 列)]、options 跟它同順序（就地改）。回傳填回幾格。
    unreadable（list，選填）：這次讀不到的舊報告記在這裡。seen、held 見 harvest。"""
    seen = {} if seen is None else seen
    opinions = harvest(old_reports(base) + _previous_reports(base), unreadable, seen=seen, held=held) if base else {}
    if opinions:
        try:
            remember(opinions.values())
        except OSError as exc:                # 判例存不進去不能連累報告：意見照樣填回，下次再存
            print("提醒：承辦意見沒存成判例（%s）；報告裡的意見照樣填回，下一次出報告會再存" % exc, flush=True)
    filled = 0
    aliases = _member_aliases(opinions)
    segments = next((_segment_table(header, rows) for name, header, rows in sheets if name == SEGMENT_SHEET), {})
    groups = next((_detail_groups(header, rows) for name, header, rows in sheets if name == DETAIL_SHEET), {})
    for index, (name, header, rows) in enumerate(sheets):
        if name not in OPINION_SHEETS or OPINION in header:
            continue
        new_header = list(header) + [OPINION]
        width = len(header)
        padded = [list(row) + [""] * max(0, width - len(row)) for row in rows]
        new_rows = []
        for key, row in zip(row_keys(name, header, padded), padded):
            text = _filled_opinion(name, header, row, key, opinions, aliases, segments, groups)
            filled += bool(text)
            if text:
                seen.setdefault(key, set()).update(_text_prints(text))
            new_rows.append(row[:width] + [text])
        sheets[index] = (name, new_header, new_rows)
        if index < len(options) and isinstance(options[index], dict):
            widths = list(options[index].get("column_widths") or [])
            if widths:
                options[index]["column_widths"] = widths[:width] + [20] * max(0, width - len(widths)) + [30]
    return filled


# ---------------------------------------------------------------------------
# 判例與白名單
# ---------------------------------------------------------------------------

def _clip(text, n):
    text = str(text or "").strip()
    return text[:n] + ("…" if len(text) > n else "")


_SCOPE_SHOWN = 6        # 收合列的意見範圍最多列幾段要處理的段名


def _book_short(name):
    """「保險代理業務手冊_伍-消費者保護篇202511」→「伍-消費者保護篇」（取不出來用全名）。"""
    text = str(name or "")
    return re.sub(r"\d{6,8}$", "", text.split("_")[-1]).strip(" -_") or text


def _collapsed_scope(row, members):
    """v1.63.2：收合列一格意見管同一處修改的每一段（下一輪都重判）。列出要處理的段，
    不然 AI 只看到候選欄那一段（最要處理的一段），回覆使用者時會講成只記了那一段。"""
    base = str(row.get("修改規章") or "").strip()
    labels, todo = [], []
    for m in members:
        seg = str(m.get("候選段次") or "").strip()
        book = str(m.get("候選規章") or "").strip() if seg else base
        seg = seg or str(m.get("修改段次") or "").strip()
        if not seg:
            continue
        label = ("段" + seg) if seg[:1].isdigit() else seg
        if book and base and book != base:
            label = "%s %s" % (_book_short(book), label)
        if label in labels:
            continue
        labels.append(label)
        if str(m.get("AI判定") or "").strip() not in ("", "不用改", "沒問題"):
            todo.append(label)
    if not labels:
        return ""
    head = "這格意見管同一處修改全部 %d 段（下一輪都重判）" % len(labels)
    if not todo:
        return head + "，AI 原判都不用改"
    shown = "、".join(todo[:_SCOPE_SHOWN]) + ("等 %d 段" % len(todo) if len(todo) > _SCOPE_SHOWN else "")
    rest = len(labels) - len(todo)
    return head + "：要處理 %s" % shown + ("；其餘 %d 段原判不用改" % rest if rest else "")


def _summary(row):
    keep = []
    members = [m["列"] for m in row.get(MEMBERS) or ()
               if isinstance(m, dict) and isinstance(m.get("列"), dict)]
    collapsed = bool(members) and str(row.get("檢查類型") or "").startswith(COLLAPSED_KIND)
    if collapsed:
        scope = _collapsed_scope(row, members)
        collapsed = bool(scope)
        if scope:
            keep.append(scope)      # 放最前面：待整理準則那一段只留前 120 字
    for name in ("法規名稱", "相關法規", "條號", "檢查項目", "修改規章", "修改段次", "候選規章", "候選段次",
                 "規章", "規章A", "段次", "段次A", "規章B", "段次B", "檢查類型"):
        if collapsed and name in ("修改段次", "候選規章", "候選段次", "檢查類型"):
            continue                # 收合列這幾欄只是最要處理的那一段，段次已在上面列齊
        value = str(row.get(name) or "").strip()
        if value:
            keep.append("%s %s" % (name, value[:40]))
    if row.get("修改段落原文"):
        keep.append("修改後「%s」" % _clip(row["修改段落原文"], 50))
    text = None if collapsed else (row.get("候選段落原文") or row.get("段落原文") or row.get("原文A") or row.get("原文"))
    if text:
        keep.append("段落「%s」" % _clip(text, 60))
    return "；".join(keep)


def _row_texts(row):
    """一列自己的原文。異動列加修改前原文：整段刪除的異動靠舊文字才認得出來（disputed 問的是新舊全文）。"""
    values = [row.get(c) for c in _TEXT_COLUMNS]
    if str(row.get("檢查類型") or "").startswith("本次異動"):
        values.append(row.get("修改前原文"))
    return values


def _texts(row):
    """這一列講的原文（前 80 字）：承辦不同意時，這幾段下一輪都重判。合併列是每一段（MEMBERS），不只顯示的第一段。"""
    values = _row_texts(row)
    for member in row.get(MEMBERS) or ():
        values += _row_texts(member["列"]) if isinstance(member, dict) else [member]
    return sorted(set(_squash(value)[:80] for value in values if _squash(value)))


def _typo_snippets(row):
    """錯漏字那一列的原文片段（建議處理裡「X」改成「Y」的 X）。不是錯漏字的列回 []。"""
    verdict = str(row.get("AI判定") or "")
    kind = str(row.get("檢查類型") or "")
    if verdict != TYPO_VERDICT and TYPO_VERDICT not in kind:
        return []
    return [s.strip() for s in _FIX_RE.findall(str(row.get("建議處理") or "")) if len(s.strip()) >= 2]


def remember(items):
    """[(意見, 列 dict)] → 判例（一列一則：承辦改了意見就換成新的）；錯漏字列寫「不是錯字」，原文片段進白名單。
    回傳 (新記或改了幾則, 新記的白名單片段)。"""
    from _common import tw_now, tw_today
    table = dict((r["鍵"], r) for r in _read(JUDGEMENTS, []) if isinstance(r, dict) and r.get("鍵"))
    words = dict((w["詞"], w) for w in _read(WHITELIST, []) if isinstance(w, dict) and w.get("詞"))
    now = tw_now().strftime("%Y-%m-%d %H:%M:%S")
    changed, new_words = 0, []
    enriched = False
    unit = current_unit()
    # v1.51.0 列鍵改過算法（規章去前綴）：舊判例的鍵對不上。同一頁、同一段原文、同一句意見就是同一則，不再多記一筆
    known = {(r.get("頁", ""), tuple(r.get("原文") or ()), r.get("承辦意見")): k for k, r in table.items()
             if r.get("原文") and unit_visible(r, unit)}       # 別單位寫過同一句，不算自己記過
    for opinion, row in items:
        sheet = row.get("頁", "")
        key = own_key(table, row.get("鍵") or row_key(sheet, list(row), list(row.values())), unit)
        old = table.get(key)
        legacy_key = known.get((sheet, tuple(_texts(row)), opinion)) if not old else None
        if legacy_key:
            key, old = legacy_key, table[legacy_key]
        if old and old.get("承辦意見") == opinion:
            for field, value in (("AI判定", str(row.get("AI判定") or row.get("最高判定") or row.get("判定") or "")),
                                 ("AI理由", str(row.get("AI理由全文") or row.get("判定理由") or "")),
                                 ("AI分數", str(row.get("判定分數(0-10)") or row.get("最高分數") or row.get("影響程度(0-10)") or "")),
                                 ("報告列", row.get("報告列")), ("報告檔名", row.get("報告檔名") or old.get("報告檔名") or ""), ("AI理由全文檔", row.get("AI理由全文檔") or ""),
                                 ("AI理由序號", row.get("AI理由序號") or "")):
                if field == "AI理由" and old.get(field) and value:
                    prefix = re.split(r"…（全文見|\.\.\.（全文見", value, maxsplit=1)[0]
                    marked = bool(re.search(r"…（全文見|\.\.\.（全文見|已截斷", value))
                    old_marked = bool(re.search(r"…（全文見|\.\.\.（全文見|已截斷", old[field]))
                    if not old_marked and (marked or (len(prefix) < len(old[field]) and old[field].startswith(prefix))):
                        continue
                if old.get(field) != value:
                    old[field] = value
                    enriched = True
            continue
        changed += 1
        table[key] = {"鍵": key, "頁": sheet, "內容": _summary(row),
                      "AI判定": str(row.get("AI判定") or row.get("最高判定") or row.get("判定") or ""),
                      "AI理由": str(row.get("AI理由全文") or row.get("判定理由") or ""),
                      "AI分數": str(row.get("判定分數(0-10)") or row.get("最高分數") or row.get("影響程度(0-10)") or ""),
                      "報告列": row.get("報告列"), "報告檔名": row.get("報告檔名") or "", "AI理由全文檔": row.get("AI理由全文檔") or "",
                      "AI理由序號": row.get("AI理由序號") or "", "承辦意見": opinion,
                      "不同意": disagrees(opinion), "原文": _texts(row), "記錄時間": now,
                      "記錄日": now[:10], UNIT: unit}
        if "不是錯字" in opinion or "非錯字" in opinion:
            for snippet in _typo_snippets(row):
                if snippet not in words:
                    new_words.append(snippet)
                    words[snippet] = {"詞": snippet, "說明": opinion[:80], "記錄日": now[:10], UNIT: unit}
                elif not unit_visible(words[snippet], unit):
                    if not any(_unit_parts(unit)):
                        print("提醒：「%s」這次沒記成不是錯字：別的單位記過這個詞，而設定頁的單位類型、業務範圍是空白，"
                              "分不出是哪個單位。填好設定頁再寫一次" % snippet, flush=True)
                        continue
                    new_words.append(snippet)
                    words[snippet].setdefault(OTHER_UNITS, []).append(unit)
    if changed or enriched:
        _write(JUDGEMENTS, sorted(table.values(), key=lambda r: r.get("記錄時間") or r.get("記錄日", ""), reverse=True))
    if new_words:
        _write(WHITELIST, sorted(words.values(), key=lambda r: r["詞"]))
    return changed, new_words


# 「可以」後面要斷句才算同意：「可以改成三道防線」是要改
_AGREE_HEAD = re.compile(r"^[\s「『（(]*(同意|贊同|贊成|認同|沒問題|沒有問題|無問題|無誤|無意見|OK|Ok|ok|可以(?=$|[，,。．！!、；;\s]))")


def disagrees(opinion):
    """承辦是不是要 AI 改（v1.39.0 使用者定：空白＝同意；寫了字就算要改，開頭是同意、沒問題、OK 這類字眼才算同意）。
    以前要寫「不同意、判錯、應改為」這類字才算，「行內稱呼為三道防線」「這段只是目錄」寫了原因也被當成同意，
    那一段下一輪照帶舊答案。同意開頭後仍有轉折或指定修改時，算要改。"""
    text = str(opinion or "").strip()
    if not text:
        return False
    match = _AGREE_HEAD.match(text)
    if match:
        tail = text[match.end():]
        return ("不同意" in text or text.lstrip("「『（( ").startswith("同意不了") or
                any(word in tail for word in ("但", "不過", "只是", "可是", "改成", "改為", "應改", "應為", "應該", "請改", "請修")))
    return True


_disagrees = disagrees                         # 舊名字（v1.20／v1.21 的呼叫端）


_auto_done = set()


def _auto_collect():
    """附判例給 AI 之前，先把目前工作區各輪報告裡新寫的承辦意見收進來（v1.22.0）：
    承辦寫完沒說「收回饋」就直接重新比對、重跑法規追蹤，新寫的意見也會先存成判例再打包。"""
    if os.environ.get("REG_NO_ANSWER_BANK") == "1":
        return
    try:
        import unit_facts as uf
        root = uf.current_workspace()
    except Exception:
        root = ""
    if not root or root in _auto_done or not os.path.isdir(root):
        return
    _auto_done.add(root)
    try:
        collect(recent_outputs(root))
    except Exception as exc:
        print("提醒：收承辦意見失敗（%s）" % exc, flush=True)


def recent_outputs(root):
    """目前這一輪＋前一輪（比對／體檢那條、法規追蹤那條各自算）。打包前自動收承辦意見只讀這幾輪：
    以前讀工作區所有輪的報告 xlsx 整份解析，占打包時間一半、隨輪數無限長（第二次審查）。「收回饋」照舊讀全部。"""
    import workspace as ws
    from _common import previous_output, _direct_previous_output
    heads = []
    try:
        heads.append(ws.current_output(root))
    except Exception:
        pass
    try:
        import law_impact as li
        heads.append(li.current(root))
    except Exception:
        pass
    found = []
    for output in heads:
        if not output or not os.path.isdir(output):
            continue
        found.append(output)
        # 同一種的前一輪（比對找比對）＋時間上緊鄰的前一輪（可能是剛跑完的體檢，承辦也可能寫在那份）
        for finder in (previous_output, _direct_previous_output):
            try:
                prior = finder(output)
            except Exception:
                prior = ""
            if prior and os.path.isdir(prior):
                found.append(prior)
    seen, unique = set(), []
    for output in found:
        key = os.path.normcase(os.path.abspath(output))
        if key not in seen:
            seen.add(key)
            unique.append(output)
    return unique


def lines(limit=LIMIT):
    """附給 AI 的「本單位判例」：最近 limit 則，承辦不同意的排前面。沒有判例回 []。"""
    _auto_collect()
    unit = current_unit()
    rows = [r for r in _read(JUDGEMENTS, []) if isinstance(r, dict) and unit_visible(r, unit)]
    if not rows:
        return []
    rows.sort(key=lambda r: r.get("記錄時間") or r.get("記錄日", ""), reverse=True)     # 新的在前
    rows = sorted(rows[:limit], key=lambda r: not disagrees(r.get("承辦意見")))           # 穩定排序：不同意的排前面
    out = ["**本單位判例**（承辦看報告後寫的意見，最近 %d 則；承辦不同意的排前面）："
           "同類的情況照承辦的意思判；承辦不同意的那一段，表上空著的一定重判，不要照舊答案寫"
           "（程式已經帶回來的，是看過同一句意見判的，不用再改）。" % len(rows)]
    for r in rows:
        out.append("- 〔%s〕%s｜AI 判：%s｜承辦：%s" % (r.get("頁", ""), r.get("內容", ""), r.get("AI判定", ""),
                                                  r.get("承辦意見", "")))
    return out


_dispute_cache = {}


def _disputes():
    """承辦不同意的判例：{原文前 80 字: 意見}（檔案沒變就不重讀：沿用答案時每一列都要問一次）。只算同單位的（v1.54.0）。"""
    path = os.path.join(folder(), JUDGEMENTS)
    try:
        stamp = os.stat(path).st_mtime_ns
    except OSError:
        return {}
    unit = current_unit()
    stamp = (stamp, unit["類型"], tuple(unit["業務範圍"]))
    hit = _dispute_cache.get(path)
    if not hit or hit[0] != stamp:
        table = {}
        for r in _read(JUDGEMENTS, []):
            # 照現在的規則重算，舊判例存的旗標不準
            if isinstance(r, dict) and disagrees(r.get("承辦意見")) and unit_visible(r, unit):
                for text in r.get("原文") or []:
                    table.setdefault(text, r.get("承辦意見", ""))
        hit = _dispute_cache[path] = (stamp, table)
    return hit[1]


def has_disputes():
    return bool(_disputes())


# v1.39.0：承辦要 AI 改的那一段，以前每一輪都清掉舊答案重判，重判完的答案下一輪又被清掉，永遠停不下來。
# 每一輪記下「哪幾列是看著承辦哪一句意見判的」（存在那一輪的 2_Log檔案/），下一輪同一句意見就照帶。
SEEN_FILE = "看過的承辦意見.json"


def _seen_path(output):
    return os.path.join(output, "2_Log檔案", SEEN_FILE)


def seen_marks(output, table):
    """這一輪（output）那張表記過的 {指紋: 看過的那句意見}。沒記過回 {}。"""
    if not output:
        return {}
    value = read_json(_seen_path(output), {})
    marks = value.get(table) if isinstance(value, dict) else None
    return dict(marks) if isinstance(marks, dict) else {}


def seen_marks_near(path, table):
    """往上找表所屬的看過意見；歸檔表只找同一個歸檔時間資料夾以內。"""
    folder = os.path.dirname(os.path.abspath(path or "."))
    for _ in range(8):
        if os.path.isfile(_seen_path(folder)):
            return seen_marks(folder, table)
        parent = os.path.dirname(folder)
        if parent == folder or os.path.basename(parent) == "歷次":
            break
        folder = parent
    return {}


def save_seen_marks(output, table, marks, checked=()):
    """記下這一輪那張表看過意見的列。checked＝這次打包看過的指紋：不在 marks 裡的拿掉，別的列（別本規章）不動。"""
    import json
    path = _seen_path(output)
    value = read_json(path, {}) if os.path.isfile(path) else {}
    value = value if isinstance(value, dict) else {}
    old = value.get(table) if isinstance(value.get(table), dict) else {}
    for key in checked:
        old.pop(key, None)
    old.update(marks)
    if old:
        value[table] = old
    else:
        value.pop(table, None)
    if not value and not os.path.isfile(path):
        return
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path + ".tmp", "w", encoding="utf-8") as f:
        json.dump(value, f, ensure_ascii=False, indent=1)
    replace_file(path + ".tmp", path)


def disputed(*texts):
    """這幾段原文（任一段）承辦寫過「不同意」嗎：有就回那一句意見，沒有回 ""。沿用舊答案之前先問這一支。
    所以要在這裡先收意見：打包時第一個問的是這一支，附判例（lines）排在各本都打包完之後，
    只靠 lines 收的話，承辦沒說收回饋就重跑，這一輪的舊答案已經沿用完了。"""
    _auto_collect()
    table = _disputes()
    if not table:
        return ""
    for text in texts:
        key = _squash(text)[:80]
        if key and key in table:
            return table[key]
    return ""


def whitelist():
    unit = current_unit()
    return [w["詞"] for w in _read(WHITELIST, []) if isinstance(w, dict) and w.get("詞") and unit_visible(w, unit)]


def is_whitelisted(snippet, words=None):
    """錯字的原文片段承辦說過不是錯字（片段要完全一樣，只差空白）。"""
    words = whitelist() if words is None else words
    target = _squash(snippet)
    return bool(target) and any(_squash(w) == target for w in words)


def whitelist_lines():
    words = whitelist()
    if not words:
        return []
    return ["**本單位確認不是錯字的寫法**：承辦看過，下面這些原文片段不是錯字，「原文」一模一樣的不要再列："
            + "、".join("「%s」" % w for w in words)]


# ---------------------------------------------------------------------------
# 收回饋（v1.21.0）：承辦寫完意見跟 AI 說「收回饋」，不用重出報告就存成判例
# ---------------------------------------------------------------------------

COMMAND = "收回饋"
# v1.26.0：比對報告／體檢報告／法規追蹤報告，加上舊的 檢視報告（跟 _common.REPORT_PATTERNS 一樣）
REPORT_PATTERNS = ("比對報告*.xlsx", "體檢報告*.xlsx", "法規追蹤報告*.xlsx", "檢視報告*.xlsx")


PAGES = {"比對": "條文比對報告、條文檢查報告、引用檢查報告", "體檢": "條文比對報告、條文檢查報告、引用檢查報告",
         "法規追蹤": "依段落彙整"}
SHORT_FEEDBACK = "寫回饋：報告最後一欄「承辦意見」可以直接打字（只寫幾列也行），存檔後跟 AI 說「%s」，以後 AI 就照你的判法判。" % COMMAND
_SHOWN = "回饋提示.json"


def feedback_lines(command=COMMAND, kind=""):
    """報告產出後印給人看的那一段：寫回饋有什麼好處、怎麼寫、寫完跟 AI 說什麼。
    kind（比對／體檢／法規追蹤）：只列那份報告真的有的頁（v1.24.0）。"""
    pages = PAGES.get(kind, "條文比對、條文檢查、引用檢查、依段落彙整、法規影響報告")
    return [
        "【寫回饋，AI 會越判越準】報告的%s這幾頁，" % pages +
        "最後一欄是「承辦意見」，覺得 AI 判錯或想補充的列，直接打字就好：",
        "  例：「這段講外匯業務，不受這條影響」「行內稱呼為三道防線」「不是錯字，本行慣用」「同意，下次修訂一起改」。"
        "空白、或以「同意／沒問題／OK」開頭＝同意；其他文字＝不同意或要補充（下一輪 AI 照你的意思重判）。只寫幾列也可以。",
        "  寫了有什麼好處：",
        "  - 你的意見會存成「本單位判例」，以後比對、體檢、法規追蹤三條流程的 AI 都先照你的判法判，"
        "用越久越懂本單位、越判越準；要 AI 改的那一段下一輪一定重判，重判過一次就照新答案帶，不會每輪重判。",
        "  - 寫「不是錯字」的詞記進本單位慣用語，以後不會再被當成錯字列出來。",
        "  - 報告之後重出，你寫的字會留在原本那一列，不會被蓋掉。",
        "  寫完在 Excel 按存檔，然後跟 AI 說「%s」（或「回饋寫完了」）就好；不用管是哪一條流程。" % command,
    ]


def _content_tag(path):
    import hashlib
    try:
        with open(path, "rb") as f:
            return hashlib.sha256(f.read()).hexdigest()[:16]
    except OSError:
        return int(os.path.getmtime(path))


def screen_feedback(output, kind, report=""):
    """畫面上要印的回饋提示：同一份報告第一次印整段，之後只印一行（v1.24.0：做完之後每說一次「繼續」都重印八行，太長）。"""
    import json
    report = report or (report_files(output) or [""])[0]
    # v1.32.1：用報告內容的指紋，不用修改時間：做完的那一輪每說一次「法規繼續」報告都重寫一次（內容一樣、時間變了），
    # 以前每次都當成新報告、重印整段，回饋提示.json 也每次都變（同步工具以為有改動）
    stamp = "%s|%s" % (os.path.basename(report), _content_tag(report) if report and os.path.isfile(report) else 0)
    path = os.path.join(output, "2_Log檔案", _SHOWN)
    try:
        with open(path, encoding="utf-8") as f:
            seen = json.load(f).get("報告") == stamp
    except (OSError, ValueError, AttributeError):
        seen = False
    if seen:
        return [SHORT_FEEDBACK]
    try:
        os.makedirs(os.path.dirname(path), exist_ok=True)
        with open(path, "w", encoding="utf-8") as f:
            json.dump({"報告": stamp}, f, ensure_ascii=False)
    except OSError:
        pass
    return feedback_lines(kind=kind)


def report_files(output):
    """一個產出資料夾 1_結果彙整/ 裡的報告（含 Excel 開著時另存的 _HHMMSS），新的在前。"""
    folder = os.path.join(output, "1_結果彙整")
    found = []
    for pattern in REPORT_PATTERNS:
        found += [p for p in glob.glob(os.path.join(glob.escape(folder), pattern))
                  if not os.path.basename(p).startswith("~$")]
    return sorted(found, key=os.path.getmtime, reverse=True)


def collect(outputs):
    """收回饋：outputs（產出資料夾，目前那一輪放最前面）每一份報告的承辦意見存成判例。
    回傳 {"報告": 讀了哪幾份, "讀不到": [...], "意見": 幾格, "不同意": 幾格, "新判例": 幾則, "新慣用語": [詞]}。"""
    result = {"報告": [], "讀不到": [], "意見": 0, "不同意": 0, "新判例": 0, "新慣用語": [], "各頁": {}}
    opinions = {}
    for output in outputs:
        paths = report_files(output)
        for key, value in harvest(paths, result["讀不到"], result["報告"], result["各頁"]).items():
            opinions.setdefault(key, value)
    result["意見"] = len(opinions)
    result["不同意"] = sum(1 for text, _row in opinions.values() if _disagrees(text))
    if opinions:
        result["新判例"], result["新慣用語"] = remember(opinions.values())
    return result


def _per_page_lines(result):
    """v1.50.0：最新那份報告每一頁承辦意見各幾格（回覆使用者直接抄；第三次模擬 0 格時 AI 又寫程式去數一次）。"""
    counts = result.get("各頁") or {}
    paths = [p for p in result.get("報告") or [] if p in counts]
    if not paths:
        return []
    # v1.51.0：有意見的每一份都印（以前只印最新那一份，意見寫在體檢、法規追蹤報告時對不起來）；
    # 工作區可能有十幾輪，全是 0 格的併成一句；全部 0 格時照舊印最新那一份
    written = [p for p in paths if any(counts[p].values())] or paths[:1]
    lines = ["  %s 各頁：%s（回覆使用者直接抄，不用自己讀報告數）" %
             (os.path.basename(path), "、".join("%s %d 格" % (sheet, n) for sheet, n in counts[path].items()) or "沒有承辦意見欄")
             for path in written]
    if len(paths) > len(written):
        lines.append("  其他 %d 份報告沒有承辦意見。" % (len(paths) - len(written)))
    return lines


def collect_lines(result):
    """收回饋的結果，用人看得懂的話講。"""
    lines = []
    if not result["報告"] and not result["讀不到"]:
        return ["收回饋：這個工作區還沒有報告（1_結果彙整/ 裡沒有比對報告、體檢報告或法規追蹤報告）。"]
    if result["讀不到"]:
        lines.append("收回饋：有 %d 份報告讀不到（%s）：多半是 Excel 還在存檔或檔案壞了，存好再說一次「%s」。"
                     % (len(result["讀不到"]), "、".join(os.path.basename(p) for p in result["讀不到"]), COMMAND))
    if not result["意見"]:
        lines.append("收回饋：讀了 %d 份報告，「承辦意見」欄都還是空的。寫了卻沒收到的話，"
                     "多半是還沒在 Excel 按存檔：存檔後再說一次「%s」。" % (len(result["報告"]), COMMAND))
        lines += _per_page_lines(result)
        return lines
    lines.append("收回饋：讀了 %d 份報告，收到 %d 格承辦意見（其中要 AI 改的 %d 格），新存了 %d 則本單位判例。"
                 % (len(result["報告"]), result["意見"], result["不同意"], result["新判例"]))
    lines += _per_page_lines(result)
    if result["新慣用語"]:
        lines.append("  記進本單位慣用語（以後不再當錯字）：%s" % "、".join(result["新慣用語"]))
    lines.append("  從下一輪起，比對、體檢、法規追蹤的 AI 都會先看這些判例再判（存在 skill 的 memoization/內部知識/）。")
    # v1.24.0：講清楚現在這份報告不會變、不同意的段什麼時候重判
    lines.append("  現在這份報告不會跟著改；要 AI 改的那幾段（同意、沒問題、OK 以外的意見），下一輪（重新比對、再體檢或法規追蹤開新一輪）AI 一定重判。")
    if result["新判例"] < result["意見"]:
        # v1.51.0：審查打包、出報告時程式會先自動收一次，這裡的數字跟「打包時收了 N 格」對得起來
        lines.append("  這 %d 格以前就收過了（含審查打包、出報告時程式自動收的），不重複記。" % (result["意見"] - result["新判例"]))
    return lines


# ---------------------------------------------------------------------------
# 本單位判斷準則（v1.40.0）
# ---------------------------------------------------------------------------
# 判例只附最近 30 則、而且只是「那一段」的例子：「行內稱呼為三道防線」這種意見，換一份文件、換一個寫法 AI 就不一定聯想得到。
# 收回饋後，AI 把每則要改的意見寫成一句通用準則＋關鍵詞（記準則），準則整張每一輪都附給 AI。
# 一則準則記著它是從哪幾則判例、哪一句意見整理的：承辦改了那句意見，準則就不再附、那則判例重新列進「待整理」。

RULES_FILE = "判斷準則.json"
RULES_COMMAND = "記準則"
RULE_MAX = 200
KEYWORD_MAX = 6
_TYPO_ONLY = ("不是錯字", "非錯字")


def _rule_book():
    value = _read(RULES_FILE, {})
    entries = value.get("準則") if isinstance(value, dict) else None
    return [e for e in (entries or []) if isinstance(e, dict) and e.get("編號")]


def rule_id(entry):
    """舊準則依建立時間、文字及原編號產生可重現的代號。"""
    import json
    data = json.dumps([entry.get("建立時間", ""), entry.get("準則", ""), entry.get("編號", ""),
                       entry.get("不用準則", "")], ensure_ascii=False, separators=(",", ":"))
    return hashlib.sha256(data.encode("utf-8")).hexdigest()


def _judgements(unit=None):
    """全部判例 {鍵: 判例}；給 unit 就只留這個單位看得到的。"""
    return dict((r["鍵"], r) for r in _read(JUDGEMENTS, []) if isinstance(r, dict) and r.get("鍵")
                and (unit is None or unit_visible(r, unit)))


def _live(entry, cases):
    """這則準則（或「不用準則」）還算數嗎：至少一則來源判例的意見跟整理時一樣、而且還是要改。"""
    return any(cases.get(key, {}).get("承辦意見") == said and disagrees(said)
               for key, said in (entry.get("判例") or {}).items())


def rules():
    """還算數的準則（不含「不用準則」的紀錄），照編號排。只給同單位的（v1.54.0）。"""
    cases = _judgements()
    unit = current_unit()
    found = [e for e in _rule_book() if e.get("準則") and not e.get("停用") and _live(e, cases) and unit_visible(e, unit)]
    return sorted(found, key=lambda e: int(re.sub(r"\D", "", e["編號"]) or 0))


def rule_lines():
    """附給 AI 的「本單位判斷準則」（評分標準、先讀我）。沒有準則回 []。"""
    found = rules()
    if not found:
        return []
    out = ["**本單位判斷準則**（承辦回饋整理成的準則，適用時照著判；跟下面的判例或你自己的看法不一樣時，照準則。準則管寫法和業務偏好，不能免除法規不符、實質錯誤（金額、期限、義務被放寬）的檢查。"
           "準則的範圍以承辦原話為準：原話明確講通則且比準則寬，才照原話的意思套到其他檢查）："]
    for e in found:
        words = "、".join(e.get("關鍵詞") or [])
        # v1.41.0：附承辦原話。模擬時 AI 把「括號日期本行每年統一更新，平常不用改」寫窄成比對情境的準則，
        # 換到體檢的引用檢查就沒套上
        said = list(dict.fromkeys(str(v).strip() for v in (e.get("判例") or {}).values() if str(v).strip()))[:2]
        out.append("- %s　%s%s%s" % (e["編號"], e["準則"], "（關鍵詞：%s）" % words if words else "",
                                    "（承辦原話：%s）" % "／".join("「%s」" % _clip(s, 80) for s in said) if said else ""))
    return out


def rules_todo():
    """還沒整理成準則的要改意見：[(判例 dict)]，新的在前。錯漏字「不是錯字」的走白名單，不列。只列同單位的（v1.54.0）。"""
    cases = _judgements(current_unit())
    covered = set()
    for e in _rule_book():
        for key, said in (e.get("判例") or {}).items():
            if cases.get(key, {}).get("承辦意見") == said:
                covered.add(key)
    todo = [r for key, r in cases.items() if key not in covered and disagrees(r.get("承辦意見"))
            and not any(w in str(r.get("承辦意見")) for w in _TYPO_ONLY)]
    return sorted(todo, key=lambda r: r.get("記錄時間") or r.get("記錄日", ""), reverse=True)


def rules_todo_lines(limit=20):
    """「還有幾則回饋沒整理成準則」那一段：給收回饋的畫面、先讀我。沒有回 []。"""
    todo = rules_todo()
    if not todo:
        return []
    out = ["**承辦回饋待整理成準則（%d 則）**：每一則想一想「承辦為什麼這樣說、以後哪些類似的地方也該這樣判」，"
           "寫成一句通用準則＋關鍵詞（2～%d 個，原文會出現的字）。承辦只說特定一處（例如「這裡」「這段」「本段」「此處」）時，預設寫「不用準則」和原因，或只限那一段，不能擴大成通則。承辦明確講通則（例如「平常不用改」「每年統一更新」）才依原話放寬套到其他檢查；通則的範圍不可以比承辦原話窄。"
           "好幾則講同一件事可以合寫一條。寫成 JSON 檔，跑「%s <檔案>」存起來，再把寫好的準則一條一條講給使用者聽，請他看有沒有寫錯。"
           % (len(todo), KEYWORD_MAX, RULES_COMMAND),
           "  JSON 格式：[{\"判例\": [\"代號\"], \"準則\": \"…\", \"關鍵詞\": [\"…\"]}, {\"判例\": [\"代號\"], \"不用準則\": \"原因\"}]；"
           "改既有準則寫 \"編號\": \"R3\"，並在 \"判例\" 列出這次整理過的來源代號，沒列的來源保留舊意見；"
           "不要了寫 {\"編號\": \"R3\", \"停用\": true}。"]
    used = {}
    for key in _judgements(current_unit()):
        used[key[:8]] = used.get(key[:8], 0) + 1
    for r in todo[:limit]:
        code = r["鍵"][:8] if used.get(r["鍵"][:8], 0) < 2 else r["鍵"]     # 前 8 碼撞在一起（同一列幾個版本）就寫全名
        def clipped(value, reason=False):
            value = str(value or "")
            if reason:
                where = ("%s（頁：%s，序號：%s）；或 " % (r["AI理由全文檔"], r.get("頁", ""), r.get("AI理由序號", ""))
                         if r.get("AI理由全文檔") and r.get("AI理由序號") else "")
                where += "%s 的鍵 %s、AI理由欄" % (os.path.join(folder(), JUDGEMENTS), r["鍵"])
            else:
                where = ((r["報告檔名"] + " 第 %s 列" % r["報告列"] if r.get("報告檔名") else "報告第 %s 列" % r["報告列"]) if r.get("報告列") else (r.get("報告檔名") or "報告") + "該列")
            return value[:600] + ("…（全文見%s）" % where if len(value) > 600 else "")
        out.append("- 代號 %s〔%s〕%s｜AI 判：%s｜AI 分數：%s｜AI 理由：%s｜承辦：%s" %
                   (code, r.get("頁", ""), _clip(r.get("內容"), 120), r.get("AI判定", ""),
                    r.get("AI分數", ""), clipped(r.get("AI理由"), reason=True), clipped(r.get("承辦意見"))))
    if len(todo) > limit:
        out.append("- 還有 %d 則，存完這批再跑一次「%s」會再列。" % (len(todo) - limit, COMMAND))
    return out


class RulesError(ValueError):
    pass


def save_rules(items):
    """AI 寫好的準則存進 內部知識/判斷準則.json。items＝JSON 讀出來的 list。
    回傳 [(動作, 編號, 準則)]；格式不對整批不存，丟 RulesError（列出每一個錯）。"""
    from _common import tw_now
    if not isinstance(items, list) or not items:
        raise RulesError("準則檔要是一個 list，至少一則")
    unit = current_unit()
    cases = _judgements(unit)                    # 別單位的判例、準則看不到，也接不上、改不到
    book = _rule_book()
    for entry in book:
        entry.setdefault("代號", rule_id(entry))
    by_id = dict((e["編號"], e) for e in book if unit_visible(e, unit))
    errors, plans = [], []

    def resolve(code):
        code = str(code or "").strip()
        if code in cases:
            return code
        hits = [k for k in cases if code and k.startswith(code)] if len(code) >= 6 else []
        return hits[0] if len(hits) == 1 else None

    for n, item in enumerate(items, 1):
        tag = "第 %d 則" % n
        if not isinstance(item, dict):
            errors.append("%s：要是 {…}" % tag)
            continue
        number = str(item.get("編號") or "").strip()
        if number and number not in by_id:
            errors.append("%s：沒有編號 %s 的準則" % (tag, number))
            continue
        cases_value = item.get("判例", [])
        words = item.get("關鍵詞", [])
        if (not isinstance(cases_value, list) or
                not all(isinstance(code, (str, int, float)) and not isinstance(code, bool) for code in cases_value) or
                not isinstance(words, list) or not all(isinstance(w, str) for w in words) or
                any(not isinstance(item.get(field, ""), str) for field in ("準則", "不用準則"))):
            errors.append("%s：判例要是字串或數字的清單、關鍵詞要是字串清單，準則及不用準則要是字串" % tag)
            continue
        if item.get("停用"):
            if not number:
                errors.append("%s：停用要寫編號" % tag)
            else:
                plans.append(("停用", number, None, {}))
            continue
        keys = []
        for code in cases_value:
            key = resolve(code)
            if not key:
                errors.append("%s：代號 %s 對不到判例（抄畫面上的代號）" % (tag, code))
            else:
                keys.append(key)
        if not keys and not number:
            errors.append("%s：要寫是哪幾則判例（\"判例\": [\"代號\"]）" % tag)
        text = str(item.get("準則") or "").strip()
        skip = str(item.get("不用準則") or "").strip()
        if bool(text) == bool(skip):
            errors.append("%s：「準則」和「不用準則」要寫一個（只能一個）" % tag)
            continue
        if text:
            if len(text) > RULE_MAX:
                errors.append("%s：準則寫太長（%d 字，上限 %d）：寫成一句通用規則" % (tag, len(text), RULE_MAX))
            if not isinstance(words, list) or not 1 <= len(words) <= KEYWORD_MAX or \
                    not all(isinstance(w, str) and 2 <= len(w.strip()) <= 20 for w in words):
                errors.append("%s：關鍵詞要 1～%d 個、每個 2～20 字（原文會出現的字）" % (tag, KEYWORD_MAX))
        plans.append(("改" if number else "新增", number, keys, {"準則": text, "關鍵詞": [w.strip() for w in words] if text else [],
                                                            "不用準則": skip}))
    if errors:
        raise RulesError("；".join(errors))
    now = tw_now().strftime("%Y-%m-%d %H:%M:%S")
    done = []
    serial = max([int(re.sub(r"\D", "", e["編號"]) or 0) for e in book] + [0])
    for action, number, keys, fields in plans:
        if action == "停用":
            entry = by_id[number]
            entry["停用"] = True                      # 判例照留：那幾則還算整理過，不會又列成待整理
            entry["停用時間"] = now
            done.append((action, number, entry.get("準則", "")))
            continue
        if action == "新增":
            serial += 1
            number = "R%d" % serial
            import uuid
            entry = {"編號": number, "代號": uuid.uuid4().hex, "判例": {}, "建立時間": now, UNIT: unit}
            book.append(entry)
            by_id[number] = entry
        entry = by_id[number]
        entry.setdefault(UNIT, unit)                 # 舊準則被改寫：內容已經是這個單位的了
        entry.update(fields)
        entry.pop("停用", None)
        entry.pop("停用時間", None)
        for key in keys or []:
            entry.setdefault("判例", {})[key] = cases[key].get("承辦意見", "")
        entry["更新時間"] = now
        done.append(("不用準則" if fields["不用準則"] else action, number, fields["準則"] or fields["不用準則"]))
    _write(RULES_FILE, {"準則": book})
    return done
