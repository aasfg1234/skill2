# -*- coding: utf-8 -*-
"""
第 1.5 步：驗證 AI 判斷、把三欄寫回連帶決定表（人看的結果在 1_結果彙整/檢視報告.xlsx）。

AI 讀 review_pack 產出的審查包，填好 AI候選判斷.csv、AI異動審查.csv 兩張 CSV
（只能填 AI判斷／AI分數／AI理由三欄，列ID／候選段次等對照欄是程式先填好的，不能動）。
這支負責：
    1. 驗證兩張 CSV：列ID／異動ID 對得上、段次對得上、判斷字對、分數與判斷相符、
       理由夠格。任何一條不過，整批中止，什麼都不寫。
    2. 通過後把「AI判斷」「AI分數」「AI理由」三欄寫回連帶決定表.csv（走
       decision_table.write_rows_csv，COLUMNS 之外的欄照留；「要改嗎」「改成什麼」
       原樣不動；指紋檔 .json 也不動，因為列指紋只算候選全文）。
    3. 外部引用、條文檢查查證的結果一併寫好（匯入狀態檔），檢視報告重建時讀。

AI 只寫判斷三欄；檢視報告產出就是這一輪的最後一站，不另外要人填表或回覆。
"""

import csv
import difflib
import io
import json
import os
import re
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
REGDIFF = os.path.join(HERE, "regdiff")
for _path in (HERE, REGDIFF):
    if _path not in sys.path:
        sys.path.insert(0, _path)

import decision_table as dt
import notices as nt
import review_pack as rp
import scoring_rubric as sr
from _common import _decode_text, locate, place
from file_replace import replace_file

CAND_VERDICTS = ("建議修改", "需再檢查", "不用改")
CHANGE_VERDICTS = ("沒問題", "需再檢查", "建議修改")
AI_COLUMNS = ["AI判斷", "AI分數", "AI理由"]
REQUIRED_REASON_WORDS = {
    "建議修改": ("改成",),
    "需再檢查": ("請確認", "請問"),
    "名稱錯誤": ("改成",),
    "本文名稱錯誤": ("改成",),
    "引用過時": ("改成",),
    "條號錯誤": ("改成",),
    "有問題": ("改成",),
}
CHANGE_SOURCE_SCORES = (5, 6)
# v1.51.0：分數等級改過（〔牴觸規定〕8 分）：這幾個標籤不管幾分都要先查上位規定
CHANGE_SOURCE_LABELS = ("牴觸規定", "疑似牴觸", "刪除控管", "需查依據")


def blocking_rules():
    lines = ["候選及異動的判斷、分數和理由須符合評分標準；理由須以對應標籤開頭。",
             "異動評為 %s 分（或用 %s 標籤）且表有查證來源欄時，須填來源。"
             % (" 或 ".join(map(str, CHANGE_SOURCE_SCORES)), "、".join("〔%s〕" % n for n in CHANGE_SOURCE_LABELS)),
             "外部引用需要更正的列須填 AI更正；指定須查證的列須填網址或規範資料庫來源。",
             "條文檢查指定須查證的標籤須填網址或規範資料庫來源。"]
    lines.extend("「%s」的理由須包含 %s。" % (key, " 或 ".join("「%s」" % word for word in words))
                 for key, words in REQUIRED_REASON_WORDS.items())
    return lines
# 兩張 AI CSV 該有的欄（review_pack._write_ai_csv 寫出來的表頭）。缺欄、欄名打錯
# 的訊息要點名是哪一欄，見 _check_sheet_shape。
CAND_REQUIRED = ["列ID", "候選段次"] + AI_COLUMNS
CHANGE_REQUIRED = ["異動ID", "新版段次"] + AI_COLUMNS

_HIGH = {"建議修改"}           # 分數要 ≥ 7
_LOW = {"不用改", "沒問題"}     # 分數要 ≤ 3
_MID = {"需再檢查"}            # 分數要 4–6

class ReviewError(ValueError):
    pass


# ---------------------------------------------------------------------------
# 讀兩張 AI CSV
# ---------------------------------------------------------------------------

def _read_ai_csv(path):
    """讀一張 AI CSV，回傳 (dict 的 list, 表頭欄名 list 或 None)。

    表頭要一起回傳（小瑕疵 19）：「缺欄位」「欄名打錯」「只有表頭」這三種問題
    光看資料列分不出來——欄名打錯時每一列的 AI判斷 都讀成空字串，錯誤訊息會變成
    幾十行「AI判斷不是允許的字：「」」，真正的原因（表頭上寫的是「AI判定」）
    一個字都沒有。見 _check_sheet_shape。

    編碼不寫死：AI 填完的表多半經過 Excel 手動確認再存檔，
    台灣的 Excel 預設另存就是 Big5（cp950），選「Unicode 文字」則是 UTF-16。
    以前寫死 `encoding="utf-8-sig"` 而且沒有 try，這兩種檔一律
    UnicodeDecodeError traceback——人看到的是一坨堆疊，不知道是編碼問題。
    改走 `_common._decode_text`：它會先看 BOM（UTF-32／UTF-16），
    再依序試 utf-8-sig／utf-8／cp950／big5hkscs，而且解完做一次亂碼檢查。
    真的認不出來才轉成 ReviewError，訊息直接告訴人怎麼另存。
    """
    with io.open(path, "rb") as f:
        raw = f.read()
    try:
        text = _decode_text(raw, path)
    except (UnicodeDecodeError, ValueError, SystemExit):
        # SystemExit：_decode_text 的 _reject_if_garbled 解出亂碼時丟的就是它
        # （那是給 CLI 直接中止用的）。這一步是可以救的錯，要轉成本模組的錯誤型別，
        # 讓 run_all 印成「[中止] ……」而不是整串 traceback。
        raise ReviewError("AI 檔編碼讀不出來：%s（請在 Excel 另存成「CSV UTF-8」再匯入）" % path)
    # newline="" 跟 open(..., newline="") 同義：不做換行轉換，
    # 理由欄裡包在引號中的換行才不會被切成兩列。
    reader = csv.DictReader(io.StringIO(text, newline=""))
    rows = list(reader)
    fieldnames = list(reader.fieldnames) if reader.fieldnames else None
    if fieldnames and any(name != (name or "").strip() for name in fieldnames):
        # 表頭有尾端空白（「AI判斷 」）：形狀檢查 strip 後放行，逐列卻拿不到那一欄、每列報「不是允許的字：「」」。
        # 讀進來就把欄名修齊，列的鍵也跟著換（審查 C13）
        fieldnames = [(name or "").strip() for name in fieldnames]
        rows = [dict(((key or "").strip() if isinstance(key, str) else key, value) for key, value in row.items())
                for row in rows]
    return rows, fieldnames


def load_ai_files(outdir):
    """讀 AI候選判斷.csv、AI異動審查.csv，回傳 (候選列, 異動列, 表頭資訊)。

    前兩個都是 dict 的 list；第三個是 {檔名: {"path": 路徑, "fieldnames": 欄名或 None}}，
    給 validate 判「表頭本身有沒有問題」用（見 _check_sheet_shape）。
    找不到檔案就 ReviewError；編碼認不出來也是 ReviewError（見 _read_ai_csv）；
    欄位內容對不對留給 validate 判斷。"""
    # 讀端走 locate：新排法（2_Log檔案/）優先，找不到再看舊排法（平鋪在 outdir）
    cand_path = locate(outdir, "AI候選判斷.csv")[0]
    change_path = locate(outdir, "AI異動審查.csv")[0]
    if not os.path.isfile(cand_path):
        raise ReviewError("找不到 AI候選判斷.csv：%s（請先跑 審查打包，讓 AI 填好再匯入）" % cand_path)
    if not os.path.isfile(change_path):
        raise ReviewError("找不到 AI異動審查.csv：%s（請先跑 審查打包，讓 AI 填好再匯入）" % change_path)
    cand_rows, cand_fields = _read_ai_csv(cand_path)
    change_rows, change_fields = _read_ai_csv(change_path)
    meta = {"AI候選判斷.csv": {"path": cand_path, "fieldnames": cand_fields},
            "AI異動審查.csv": {"path": change_path, "fieldnames": change_fields}}
    return cand_rows, change_rows, meta


# ---------------------------------------------------------------------------
# 驗證（純函式，不做任何 I/O）
# ---------------------------------------------------------------------------

def _s(value):
    """欄位值轉字串再去頭尾空白；AI CSV 讀出來一定是字串，但 validate 是公開的純函式，
    別的呼叫端（例如測試、Task 4）可能直接塞 int／None 進來，這裡不要讓它整個炸掉。"""
    return "" if value is None else str(value).strip()


_SCORE_RE = re.compile(r"^(10|[0-9])(?:\.0+)?$")


def _score_ok(raw):
    """回傳 (通不通過, 分數)；一定要是半形 0–10 整數（逐字元比對，不是先轉數字再判斷範圍）才算過。
    這樣擋得住 `int()` 會放行的怪輸入：全形數字（`int("８")` Python 認得，但人眼看不出跟半形的差別）、
    「8.5」。「8.0」照 8 收：AI 用 pandas 寫 CSV 時整數欄常變成這樣，意思沒有歧義（審查 C10）。"""
    raw = _s(raw)
    if not _SCORE_RE.match(raw):
        return False, None
    return True, int(raw.split(".")[0])


# 欄名「像但不等於」的門檻：「AI判定」對「AI判斷」是 0.75，「備註」對「AI理由」是 0。
_SIMILAR_ENOUGH = 0.6


def _looks_like(name, target):
    """name 是不是 target 打錯字的版本（不是就回 0）。"""
    return difflib.SequenceMatcher(None, name, target).ratio()


def _check_sheet_shape(filename, path, ai_rows, fieldnames, required_cols, expect_rows=True):
    """AI CSV 的「形狀」對不對：空檔／只有表頭／缺欄位／欄名打錯（小瑕疵 19）。

    為什麼要單獨檢查（而不是交給 _validate_sheet 逐列驗）：這四種問題在逐列驗證
    底下長得一模一樣——欄名打成「AI判定」時每一列的 AI判斷 都讀成空字串，
    畫面上是幾十行「AI判斷不是允許的字：「」」，人看不出真正的原因是表頭；
    表整個空掉時則是幾十行「缺列ID：R1、R2……」，同樣看不出檔案根本沒內容。
    四種各給一句話，講的是這一次真正發生的事：

        「%s」是空檔（0 bytes）
        「%s」只有表頭，沒有任何資料列
        「%s」缺欄位：%s
        「%s」欄名不對：%s（應為 %s）

    path 可以不給（None）：呼叫端手上只有已經讀好的列與表頭時，就只驗表頭。
    expect_rows=False 時不驗「只有表頭」——決定表本來就 0 列候選（compare 一筆
    候選都沒列）時，空白的 AI CSV 是正確的產出，不是壞檔。
    回傳錯誤字串 list；空 list 表示形狀沒問題，可以往下逐列驗。
    """
    errors = []
    if path and os.path.isfile(path):
        try:
            if os.path.getsize(path) == 0:
                return ["「%s」是空檔（0 bytes）" % filename]
        except OSError:
            pass
    if not fieldnames:
        # 有檔案但連表頭都讀不出來（整份空白、或只有幾個空行）：跟 0 bytes 同一件事。
        return ["「%s」是空檔（0 bytes）" % filename]

    actual = [(name or "").strip() for name in fieldnames]
    spare = [name for name in actual if name and name not in required_cols]
    missing = []
    for want in required_cols:
        if want in actual:
            continue
        # 有一個沒人認領、又跟它很像的欄名 → 是打錯字，不是缺欄位。
        best, best_score = "", 0.0
        for name in spare:
            score = _looks_like(name, want)
            if score > best_score:
                best, best_score = name, score
        if best and best_score >= _SIMILAR_ENOUGH:
            spare.remove(best)
            errors.append("「%s」欄名不對：%s（應為 %s）" % (filename, best, want))
        else:
            missing.append(want)
    if missing:
        errors.append("「%s」缺欄位：%s" % (filename, "、".join(missing)))
    if errors:
        return errors
    if expect_rows and not ai_rows:
        return ["「%s」只有表頭，沒有任何資料列" % filename]
    return []


def _validate_sheet(filename, ai_rows, id_col, id_prefix, pos_col, expected_ids, expected_pos,
                    optional_ids=()):
    """驗證一張 AI CSV：列ID／異動ID 對齊、段次對得上、判斷字、分數、理由。
    verdicts 依 id_prefix 決定（候選用 R、異動用 C，剛好對應兩套判斷字）。
    回傳這張表全部的錯誤字串（不是遇第一個就停）。"""
    verdicts = CAND_VERDICTS if id_prefix == "R" else CHANGE_VERDICTS
    errors = []
    by_id = {}
    dup_ids = []
    for row in ai_rows:
        rid = _s(row.get(id_col))
        if not rid:
            continue
        if rid in by_id and rid not in dup_ids:
            # AI 填表把同一個列ID／異動ID 填到兩列：後面那列會把前面覆蓋掉，
            # 整份表看起來卻少了一列（另一列憑空消失），不擋住的話錯得很隱晦。
            dup_ids.append(rid)
        by_id[rid] = row
    for rid in dup_ids:
        errors.append("「%s」%s重複：%s" % (filename, id_col, rid))

    expected_set = set(expected_ids)
    actual_set = set(by_id.keys())
    for missing in expected_ids:
        if missing not in actual_set and missing not in optional_ids:
            errors.append("「%s」缺%s：%s" % (filename, id_col, missing))
    for extra in sorted(actual_set - expected_set, key=lambda x: (len(x), x)):
        errors.append("「%s」多出%s：%s" % (filename, id_col, extra))

    for i, rid in enumerate(expected_ids, 1):
        row = by_id.get(rid)
        if row is None:
            continue
        tag = "「%s」%s" % (filename, rid)

        actual_pos = _s(row.get(pos_col))
        want_pos = _s(expected_pos[i - 1])
        if actual_pos != want_pos:
            errors.append("%s：%s不符（決定表是「%s」，AI檔是「%s」）"
                          % (tag, pos_col, want_pos, actual_pos))

        verdict = _s(row.get("AI判斷"))
        if not verdict and not _s(row.get("AI分數")) and not _s(row.get("AI理由")):
            # 整列沒填：講一句就好（以前「判斷不是允許的字」「分數」「理由是空的」各報一行）
            errors.append("%s：還沒填（AI判斷、AI分數、AI理由都空白）" % tag)
            continue
        verdict_ok = verdict in verdicts
        if not verdict_ok:
            errors.append("%s：AI判斷不是允許的字：「%s」（只能是 %s）"
                          % (tag, verdict, "／".join(verdicts)))

        score_ok, score = _score_ok(row.get("AI分數"))
        if not score_ok:
            errors.append("%s：分數要是 0–10 的半形整數：「%s」" % (tag, _s(row.get("AI分數"))))
        elif verdict_ok:
            if verdict in _HIGH and score < 7:
                errors.append("%s：分數 %d 與判斷「%s」不符（%s要 ≥ 7）" % (tag, score, verdict, verdict))
            elif verdict in _LOW and score > 3:
                errors.append("%s：分數 %d 與判斷「%s」不符（%s要 ≤ 3）" % (tag, score, verdict, verdict))
            elif verdict in _MID and not (4 <= score <= 6):
                errors.append("%s：分數 %d 與判斷「%s」不符（%s要 4–6）" % (tag, score, verdict, verdict))

        reason = _s(row.get("AI理由"))
        if not reason:
            errors.append("%s：AI理由是空的" % tag)
        else:
            # 評分標準（scoring_rubric）：理由開頭的〔標籤〕就是對到哪一條，那一條的分數就是 AI分數。
            # 只規定區段的話，同一區段裡給 7 還是 9 各說各話，這裡把它釘死
            table = "候選" if id_prefix == "R" else "異動"
            label = sr.label_in(reason)
            expected = sr.score_of(table, label) if label else None
            if not label:
                errors.append("%s：AI理由要用評分標準的標籤開頭，例如「〔%s〕…」（可用：%s）"
                              % (tag, sr.TABLES[table][1][1], sr.labels(table)))
            elif expected is None:
                errors.append("%s：「〔%s〕」不是%s評分標準的標籤（可用：%s）"
                              % (tag, label, table, sr.labels(table)))
            elif score_ok and expected != score:
                errors.append("%s：標籤「〔%s〕」是 %d 分，AI分數卻填 %d%s" % (
                    tag, label, expected, score,
                    sr.LEGACY_SCORE_NOTE if id_prefix == "C" and (label, score) in sr.LEGACY_CHANGE_SCORES else ""))
            if verdict == "建議修改" and not any(word in reason for word in REQUIRED_REASON_WORDS[verdict]):
                errors.append("%s：AI理由沒有寫「改成」（建議修改要寫建議改法）" % tag)
            if verdict == "需再檢查" and not any(word in reason for word in REQUIRED_REASON_WORDS[verdict]):
                errors.append("%s：AI理由沒有寫「請確認」或「請問」（需再檢查要寫查什麼、問誰）" % tag)
            errors += _not_asking_errors(tag, reason)
            # 異動審查的 5、6 分（需查依據、可能越界）要先上網查上位規定；表上有「查證來源」欄
            # （新版 review-pack 產的）就一定要填，舊表沒有這一欄不擋
            if (id_prefix == "C" and "查證來源" in row and score_ok
                    and (score in CHANGE_SOURCE_SCORES or label in CHANGE_SOURCE_LABELS)
                    and not _s(row.get("查證來源"))):
                errors.append("%s：%d 分要先上網查上位規定，查證來源 要寫查了哪些網址或關鍵字" % (tag, score))

    return errors


def _not_asking_errors(tag, reason):
    """理由寫的是 AI 自己還沒查完的事：比照法規表擋（見 scoring_rubric.NOT_ASKING_RE）。"""
    hit = sr.NOT_ASKING_RE.search(reason or "")
    if not hit:
        return []
    return ["%s：理由寫的是 AI 自己還沒查完的事（「%s」），不是問承辦：先查完再判；"
            "查不到就寫查了哪裡、要承辦確認什麼，不要留給之後補查" % (tag, hit.group(0))]


def same_reason_errors(filename, ai_rows, id_col):
    """同一張表 4～6 分的理由一字不差超過門檻：整批複製的模板，擋（比照法規表 _cross_checks）。"""
    errors = []
    for reason, rows in sr.repeated_reasons(ai_rows).items():
        ids = [_s(row.get(id_col)) for row in rows]
        errors.append("「%s」%s…：%d 列理由一字不差（%s…）：每一列要寫這一段為什麼要確認、確認什麼；"
                      "一起看就夠的，寫清楚這一段跟其他段的差別" % (filename, "、".join(ids[:6]), len(ids), reason[:40]))
    return errors


def validate(rows, changes, ai_cand, ai_change, meta=None):
    """驗證 AI候選判斷.csv、AI異動審查.csv 兩張表，回傳全部錯誤字串（不是遇第一個
    就停）；沒有錯誤回傳空 list。純函式，不讀檔（meta 給了路徑時只 stat 檔案大小）。

    meta（選填，load_ai_files 的第三個回傳值）給了就先驗表頭的「形狀」——空檔、
    只有表頭、缺欄位、欄名打錯（見 _check_sheet_shape）。形狀不對的那一張表
    **不再逐列驗**：表頭都錯了，逐列驗只會噴幾十行看不出原因的衍生錯誤，
    把真正該講的那一句淹掉。"""
    meta = meta or {}

    def sheet_errors(filename, ai_rows, required, expect_rows, validate_args):
        info = meta.get(filename)
        if info is not None:
            shape = _check_sheet_shape(filename, info.get("path"), ai_rows,
                                       info.get("fieldnames"), required,
                                       expect_rows=expect_rows)
            if shape:
                return shape
        return _validate_sheet(*validate_args)

    cand_ids = ["R%d" % i for i in range(1, len(rows) + 1)]
    cand_pos = [_s(row.get("候選段次")) for row in rows]
    # 外部引用檢查匯入時接在決定表最後的列（來源只有「外部引用」）：那時候 AI候選判斷.csv
    # 早就填好了，裡面沒有它們；可以不填，填了照樣驗
    optional = set("R%d" % i for i, row in enumerate(rows, 1) if dt.appended_row(row))
    errors = sheet_errors("AI候選判斷.csv", ai_cand, CAND_REQUIRED, bool(set(cand_ids) - optional),
                          ("AI候選判斷.csv", ai_cand, "列ID", "R", "候選段次",
                           cand_ids, cand_pos, optional))

    change_ids = ["C%d" % i for i in range(1, len(changes) + 1)]
    change_pos = [_s(ch["new_index"]) if ch.get("new_index") else "刪除" for ch in changes]
    errors += sheet_errors("AI異動審查.csv", ai_change, CHANGE_REQUIRED, bool(changes),
                           ("AI異動審查.csv", ai_change, "異動ID", "C", "新版段次",
                            change_ids, change_pos))
    return (errors + same_reason_errors("AI候選判斷.csv", ai_cand, "列ID")
            + same_reason_errors("AI異動審查.csv", ai_change, "異動ID"))


# ---------------------------------------------------------------------------
# 驗原文：決定表的「候選全文」有沒有被手改過
# ---------------------------------------------------------------------------



def check_row_texts(rows, sidecar):
    """逐列比對「候選全文」與指紋檔的 候選全文SHA256。

    回傳 (不符的列索引 set（0 起算）, 指紋檔有沒有列指紋)。

    為什麼要驗：決定表是給人用 Excel 開來填「要改嗎」「改成什麼」
    的，同一張表上的「候選全文」欄很容易被順手改掉（想順便把錯字修掉、
    貼上時把儲存格蓋掉）。以前 review-import 只驗兩張 AI CSV 的列ID 對不對得上，
    改過的原文就這樣一路進到報告，報告上印的「候選全文」已經不是草稿裡
    那一段，但沒有任何一個字提示這件事。

    舊版留底的指紋檔沒有「列」（格式版本 1 之前的產出）就整批照舊匯入，
    由呼叫端發一則提醒——那不是「文字被改過」，是「這次沒得驗」。

    列與指紋怎麼對一律走 dt.match_sidecar（不看列序）。對到了但指紋不同＝被手改過；
    一筆都對不到＝段次與全文都跟初比對不一樣，同樣算不符。
    """
    sidecar_rows = (sidecar or {}).get("列") or []
    if not sidecar_rows:
        return set(), False
    matched, _ = dt.match_sidecar(rows, sidecar_rows)
    bad = set()
    for i, row in enumerate(rows):
        k = matched[i]
        if k is None or sidecar_rows[k].get("候選全文SHA256") != dt.text_sha256(row.get("候選全文") or ""):
            bad.add(i)
    return bad, True


def stale_ai_rows(ai_rows, id_col, id_prefix, sha_col, expected_shas):
    """AI 檔裡「不是對這一輪那段字判的」列：程式填的指紋欄跟現在那一段的指紋對不上。

    回傳 (索引 set（0 起算，對應 expected_shas）, AI 檔有沒有指紋欄)。
    重跑 compare 之後列ID 與段次常常一模一樣，只有字變了；只靠列ID 對，上一輪
    AI 的理由就會匯進這一輪的表。指紋欄空白的列（AI 把它清掉了）一樣算對不上。
    """
    if not ai_rows or not any(sha_col in row for row in ai_rows):
        return set(), False
    by_id = dict((_s(row.get(id_col)), row) for row in ai_rows)
    stale = set()
    for i, want in enumerate(expected_shas):
        row = by_id.get("%s%d" % (id_prefix, i + 1))
        if row is not None and _s(row.get(sha_col)) != want:
            stale.add(i)
    return stale, True


# ---------------------------------------------------------------------------
# 報告
# ---------------------------------------------------------------------------

def _count_by(ai_rows, verdicts):
    counts = dict((v, 0) for v in verdicts)
    for row in ai_rows:
        v = (row.get("AI判斷") or "").strip()
        if v in counts:
            counts[v] += 1
    return counts


# ---------------------------------------------------------------------------
# 匯入主流程
# ---------------------------------------------------------------------------

AI_REVIEW_RECORD = "AI審查紀錄.json"
AI_IMPORT_STATUS = "AI審查匯入狀態.json"


def record_review(outdir, rows, changes, complete):
    """寫「這一輪審完了」的紀錄（AI審查紀錄.json，人工待辦拿它判斷 AI 審查做完沒）。

    只在每一列都真的匯入時才寫（complete）：有過期（AI 判的不是這一輪的字）或原文不符
    （決定表被手改）的列，那幾列沒有 AI 判定，流程不能當成審完往報告走——以前照寫，
    人工待辦看到紀錄就說審完了，報告上那幾列是空的，只有畫面上一行提醒。
    不完整時連舊的紀錄也刪掉，免得上一次的紀錄剛好對得上。"""
    path = place(outdir, AI_REVIEW_RECORD)
    if not complete:
        if os.path.isfile(path):
            os.remove(path)
        return
    with io.open(path, "w", encoding="utf-8") as f:
        json.dump(ai_review_signature(rows, changes), f, ensure_ascii=False)


def read_import_status(outdir):
    """上一次匯入留下的狀態（_write_import_status 寫的）；沒有或讀不出來回 None。"""
    path = locate(outdir, AI_IMPORT_STATUS)[0]
    if not os.path.isfile(path):
        return None
    try:
        with io.open(path, encoding="utf-8") as f:
            return json.load(f)
    except (OSError, ValueError):
        return None


def _write_import_status(outdir, result):
    """記錄匯入結果給人工待辦與外部報告讀；舊產出沒有此檔仍可照舊使用。"""
    status = {
        "格式版本": 1,
        "候選": dict(result.get("候選") or {}),
        "異動": dict(result.get("異動") or {}),
        "原文不符": list(result.get("原文不符") or []),
        "AI過期": list(result.get("AI過期") or []),
        # 四張表裡 AI 判的不是這一輪的字、沒匯入的（R…、C…、E…、K…）：有就要重跑審查打包讓 AI 重判
        "需重新打包": list(result.get("需重新打包") or []),
        # review-pack 重新打包時會清掉「無法查證」的外部引用答案；
        # 人用報告仍需顯示本輪已匯入的結果，故以段落指紋留一份唯讀快照。
        "外部引用結果": [
            {key: _s(row.get(key)) for key in
             ("引用ID", "AI判斷", "AI理由", "AI更正", "查證來源", "類別", rp.EXTERNAL_SHA_COLUMN)}
            for row in (result.get("外部引用結果") or [])
            if _s(row.get(rp.EXTERNAL_SHA_COLUMN)) and _s(row.get("AI判斷"))
        ],
    }
    # 這一份狀態是對哪一版 AI 表寫的：審查打包會重寫 AI 表，表變了狀態就不算數。
    # 以前人工待辦比檔案時間（狀態檔 ≥ AI 表），FAT／exFAT 隨身碟時間粒度 2 秒會判錯（審查 A7）
    status["AI表指紋"] = ai_table_prints(outdir)
    path = place(outdir, AI_IMPORT_STATUS)
    tmp = path + ".tmp"
    with io.open(tmp, "w", encoding="utf-8") as f:
        json.dump(status, f, ensure_ascii=False, indent=2)
        f.write("\n")
    replace_file(tmp, path)
    return path


def ai_table_prints(outdir):
    """這一本現在的 AI候選判斷.csv、AI異動審查.csv 檔案指紋 {檔名: SHA256}；沒有的檔不列。"""
    prints = {}
    for filename in ("AI候選判斷.csv", "AI異動審查.csv"):
        path = locate(outdir, filename)[0]
        if os.path.isfile(path):
            prints[filename] = dt.file_sha256(path)
    return prints


def mark_repack(outdir, reason):
    """叫這一本回到「審查打包」那一站（run_all 的「法規更動」用）：匯入狀態記 需重新打包，
    「審完了」的紀錄拿掉。人工待辦看到就派審查打包；重新打包時作廢的查證不會再沿用，AI 重新上網查。
    回傳有沒有改到東西。"""
    status = read_import_status(outdir) or {"格式版本": 1, "候選": {}, "異動": {}, "原文不符": [], "AI過期": []}
    reasons = [r for r in (status.get("需重新打包") or []) if r]
    if reason not in reasons:
        reasons.append(reason)
    status["需重新打包"] = reasons
    status["AI表指紋"] = ai_table_prints(outdir)
    path = place(outdir, AI_IMPORT_STATUS)
    tmp = path + ".tmp"
    with io.open(tmp, "w", encoding="utf-8") as f:
        json.dump(status, f, ensure_ascii=False, indent=2)
        f.write("\n")
    replace_file(tmp, path)
    record = place(outdir, AI_REVIEW_RECORD)
    if os.path.isfile(record):
        os.remove(record)
    return True


def ai_review_signature(rows, changes):
    """這一次 AI 審的是哪些候選列、哪些異動（指紋）。人工待辦拿現在的表算一次比對：
    不一樣（補了語意、重跑了開始）就是還要 AI 審。之後才接上去的列（外部引用、驗收新候選）不算。"""
    return {"列": sorted("%s@%s" % (dt.text_sha256(r.get("候選全文") or ""), (r.get("候選段次") or "").strip())
                        for r in rows if not dt.appended_row(r)),
            "異動": sorted(rp.change_sha256(ch) for ch in changes)}


def import_review(outdir, book_name="", books=None, book=None, defer_learning=False):
    """驗證兩張 AI CSV → 通過就把 AI判斷／AI分數／AI理由 三欄寫回連帶決定表.csv，
    驗證不過就 raise ReviewError（訊息是
    每行一條的全部錯誤），什麼都不寫。`books`（{規章名: book}，選填）給跨本候選查
    來源本的異動全文用。

    `book`（rp.load_book 的回傳值，選填）給得出就不再重新 load_book——批次逐本
    呼叫時，第一階段驗證已經 load_book 過一次（見 run_all.cmd_batch_review_import
    的 loaded dict），這裡不用再讀一次連帶決定表／異動清單／docx。

    匯入前先驗原文：決定表上的「候選全文」要跟初比對指紋檔
    （<決定表>.json 的「列」）的 候選全文SHA256 一致，不一致的列不寫 AI 三欄，
    另外列一張「原文已修改未匯入」表並發一則警告。見 check_row_texts。

    外部引用學到的名稱（登錄表、排除表）在最後才寫；`defer_learning=True`（批次）就留給
    呼叫端在整批做完後 flush_learned()，不然後面幾本的 E 編號會照改過的表重抓而錯位。

    回傳 {"候選": {判斷: 數}, "異動": {判斷: 數}, "報告": xlsx路徑,
          "表": [(工作表名, header, rows), ...], "原文不符": [列ID...]}。"""
    if not defer_learning:
        discard_learned()
    if book is None:
        book = rp.load_book(outdir)
    rows, changes = book["rows"], book["changes"]
    rp.refresh_cross_book_sources(rows, book, books)
    ai_cand, ai_change, ai_meta = load_ai_files(outdir)
    import ai_tables as at

    errors = validate(rows, changes, ai_cand, ai_change, ai_meta)
    ext_rows = load_external(outdir)
    offline_keys = _keep_old_when_offline(outdir, ext_rows)
    ext_errors, ext_good, ext_stale = check_external(book, ext_rows, required=external_required(outdir))
    errors += ext_errors
    rc_items = rp.rulecheck_items(outdir)
    rc_rows = load_rulecheck(outdir)
    for filename, table_rows in (("AI候選判斷.csv", ai_cand), ("AI異動審查.csv", ai_change),
                                 (rp.EXTERNAL_FILE, ext_rows), (rp.RULECHECK_FILE, rc_rows)):
        for warning in at.repeated_text_warnings(table_rows):
            nt.notice(nt.REMINDER, "%s：%s" % (filename, warning), "review-import")
    rc_errors, rc_good, rc_stale = check_rulecheck(rc_items, rc_rows,
                                                   required=rulecheck_required(outdir))
    errors += rc_errors
    if errors:
        raise ReviewError("\n".join(errors))

    csv_path = locate(outdir, "連帶決定表.csv")[0]
    sidecar = book.get("sidecar")
    if sidecar is None:
        # load_book 沒把指紋檔存進 book（舊的 book dict、或呼叫端自己組的）就補讀一次。
        try:
            sidecar = dt.read_sidecar(dt.sidecar_path_for(csv_path))
        except dt.DecisionTableError:
            sidecar = {}
        book["sidecar"] = sidecar
    bad_idx, has_fingerprints = check_row_texts(rows, sidecar)
    if rows and not has_fingerprints:
        nt.notice(nt.REMINDER,
                  "指紋檔沒有列指紋，這次沒驗原文（舊版留底的產出資料夾）；"
                  "決定表上的候選全文有沒有被手改過，這一輪查不出來",
                  "review-import")
    mismatch_ids = ["R%d" % (i + 1) for i in sorted(bad_idx)]
    if mismatch_ids:
        nt.notice(nt.WARNING,
                  "有 %d 列候選全文與初比對指紋不符（列ID %s），這幾列的 AI 判斷沒有匯入；"
                  "請還原決定表，或跑 開始 重新比對"
                  % (len(mismatch_ids), "、".join(mismatch_ids)),
                  "review-import")

    # AI 判斷是不是對「這一輪」的字判的：AI 檔裡 review-pack 填的指紋要跟現在那一段一樣。
    stale_cand, cand_has_sha = stale_ai_rows(
        ai_cand, "列ID", "R", rp.CAND_SHA_COLUMN,
        [rp.candidate_sha256(row, book) for row in rows])
    stale_change, change_has_sha = stale_ai_rows(
        ai_change, "異動ID", "C", rp.CHANGE_SHA_COLUMN,
        [rp.change_sha256(ch, book) for ch in changes])
    stale_cand -= bad_idx          # 原文被手改的那幾列上面已經講過了
    stale_ids = (["R%d" % (i + 1) for i in sorted(stale_cand)]
                 + ["C%d" % (i + 1) for i in sorted(stale_change)])
    if stale_ids:
        nt.notice(nt.WARNING,
                  "有 %d 列 AI 判斷不是對這一輪的字判的（%s）：AI 檔記的指紋跟現在的候選／異動"
                  "對不上，多半是重新比對之後拿上一輪的 AI 檔來匯入；這幾列沒有匯入，"
                  "請跑 繼續（會回到審查打包）讓 AI 重判" % (len(stale_ids), "、".join(stale_ids)),
                  "review-import")
    no_sha = []
    if ai_cand and not cand_has_sha:
        no_sha.append("AI候選判斷.csv 的「%s」" % rp.CAND_SHA_COLUMN)
    if ai_change and not change_has_sha:
        no_sha.append("AI異動審查.csv 的「%s」" % rp.CHANGE_SHA_COLUMN)
    if no_sha:
        # 上一版 review-pack 產的表沒有這一欄。照舊匯入，但不能默不作聲。
        nt.notice(nt.WARNING,
                  "AI 檔缺指紋欄（%s），無法確認 AI 判斷是對這一輪的字判的；"
                  "重新比對過的話請跑 繼續（會回到審查打包）讓 AI 重判" % "、".join(no_sha),
                  "review-import")
    # 沒匯入的列（手改過＋AI 過期）不進報告的判斷與統計：報告上看得到判斷，
    # 人就會以為那一列審過了。
    skipped = bad_idx | stale_cand
    skip_ids = set(mismatch_ids) | set(stale_ids)
    ai_cand = [r for r in ai_cand if _s(r.get("列ID")) not in skip_ids]
    ai_change = [r for r in ai_change if _s(r.get("異動ID")) not in skip_ids]

    cand_by_id = {(r.get("列ID") or "").strip(): r for r in ai_cand}
    for i, row in enumerate(rows, 1):
        if (i - 1) in skipped:
            # 候選全文已經不是初比對那一段了，AI 是照著被改過的文字判的；
            # 寫回去只會讓報告看起來有憑有據。三欄清空，不留上一輪的舊判斷——
            # 留著的話決定表上那一列會掛著跟旁邊文字對不上的 AI 建議，
            # 而人填「要改嗎」時看的正是這一張表（審查發現）。
            row["AI判斷"] = row["AI分數"] = row["AI理由"] = ""
            continue
        ai_row = cand_by_id.get("R%d" % i, {})
        _, score = _score_ok(ai_row.get("AI分數"))
        row["AI判斷"] = (ai_row.get("AI判斷") or "").strip()
        row["AI分數"] = "" if score is None else str(score)      # 空白不能寫成 "None"
        row["AI理由"] = (ai_row.get("AI理由") or "").strip()

    dt.write_rows_csv(csv_path, rows)

    rc_counts = None
    if rc_items:
        rc_counts = dict((v, 0) for v in sr.RULECHECK_VERDICTS + (NOT_REVIEWED,))
        for item in rc_items:
            state = _rulecheck_state(item, rc_good)[0]
            rc_counts[state] = rc_counts.get(state, 0) + 1
        if rc_good is None:
            nt.notice(nt.REMINDER,
                      "AI條文檢查.csv 沒有填：條文檢查高風險 %d 項沒有 AI 判斷（報告「條文檢查報告」標「AI 沒審」）"
                      % len(rc_items), "review-import")
        if rc_stale:
            nt.notice(nt.WARNING,
                      "AI條文檢查.csv 有 %d 列不是對這一輪的字判的（%s），沒有匯入；"
                      "請跑 繼續（會回到審查打包）讓 AI 重判" % (len(rc_stale), "、".join(rc_stale)), "review-import")
    ext_counts = None
    if ext_good is not None:
        ext_counts = _count_external(ext_good)
        _remember_external(outdir, book, ext_good)
        import law_memory as lm
        lm.remember_external_versions(ext_good, rp.external_items(book))
        if offline_keys:
            import batch as bt
            import verify_cache as vc
            vc.note_retry(bt.cache_dir(outdir), offline_keys)
        done = apply_external(book, ext_good, csv_path)
        # v1.27.2：排除表要等整批看完才知道（別本可能有同名的真引用），由 flush_learned 講
        if done["登錄"]:
            nt.notice(nt.REMINDER,
                      "外部規章：程式抓錯的已自動修正（%s），下一次比對就會抓對，不用人處理"
                      % "、".join("登錄：%s" % n for n in done["登錄"]), "review-import")
        if done["決定表"]:
            # 講報告上去哪裡看，不叫人填決定表（報告產出就是最後一站）
            nt.notice(nt.WARNING,
                      "外部規章引用的本文名稱錯誤、引用過時或條號錯誤共 %d 處（AI 已查證）：報告「引用檢查報告」需要改內文的列，"
                      "建議處理寫了改法" % done["決定表"], "review-import")
        if done["本行內規"]:
            names = list(dict.fromkeys(done["本行內規"]))
            nt.notice(nt.REMINDER,
                      "引用本行自己的內規 %d 處（網路上查不到，程式只確認名稱，內容請承辦確認）：%s：報告「引用檢查報告」"
                      "判定「無法查證」、理由寫〔本行內規〕的列"
                      % (len(done["本行內規"]), "、".join(names[:5]) + ("等 %d 份" % len(names) if len(names) > 5 else "")),
                      "review-import")
        if done["無法查證"]:
            names = list(dict.fromkeys(done["無法查證"]))
            nt.notice(nt.REMINDER,
                      "外部規章：%d 處 AI 沒能查證（%s）：報告「引用檢查報告」判定「無法查證」的列"
                      % (len(done["無法查證"]), "、".join(names[:5]) + ("等 %d 處" % len(names) if len(names) > 5 else "")),
                      "review-import")
    elif ext_rows is not None and rp.external_items(book):
        nt.notice(nt.REMINDER, "AI外部引用.csv 沒有填，這一輪沒做外部規章引用的 AI 檢查", "review-import")
    if ext_stale:
        nt.notice(nt.WARNING,
                  "AI外部引用.csv 有 %d 列不是對這一輪的字判的（%s），沒有匯入；請跑 繼續（會回到審查打包）讓 AI 重判"
                  % (len(ext_stale), "、".join(ext_stale)), "review-import")
    # 以前這裡另出一份 LLM審查報告.xlsx（批次再合一份 LLM審查總表.xlsx）：內容全都已經在
    # 1_結果彙整/檢視報告.xlsx，沒有程式讀它、人也不用開，不再產生。
    repack = stale_ids + list(ext_stale or []) + list(rc_stale or [])
    record_review(outdir, rows, changes, complete=not (repack or mismatch_ids))
    if not (repack or mismatch_ids):
        try:
            import answer_bank as ab
            ab.harvest_compare(outdir)        # v1.20.0：別的工作區審到一樣的字直接帶
            import learned
            learned.learn_boilerplate(rows, ai_cand, book)    # 〔套語命中〕的那一截字，下次打包提示
        except Exception as exc:              # 答案庫沒存到不擋匯入
            print("提醒：AI 答案庫沒存到（%s）" % exc, flush=True)

    result = {"候選": _count_by(ai_cand, CAND_VERDICTS), "異動": _count_by(ai_change, CHANGE_VERDICTS),
              "原文不符": mismatch_ids, "AI過期": stale_ids, "需重新打包": repack,
              "外部引用": ext_counts, "條文檢查": rc_counts,
              "外部引用結果": list(ext_good or []), "連不上網": len(offline_keys)}
    result["匯入狀態"] = _write_import_status(outdir, result)
    if not defer_learning:
        flush_learned()
    return result


# ---------------------------------------------------------------------------
# 外部規章引用檢查（AI外部引用.csv）
# ---------------------------------------------------------------------------
# 程式用規則抓外部規章引用（rule_checks.external_mentions），抓得到寫法固定的，
# 抓不到的是「名稱對不對、是不是真的外部法規、條號合不合理、母法有沒有改過」這種要讀懂的事，
# 還有寫法特別的漏網之魚。review-pack 把每一處（E1…）和可能漏抓的段落交給 AI，
# 這裡驗 AI 填的表，有誤／漏抓發警告、需查證發提醒。
# AI 完全沒填（整張空白）就當成這一輪沒做外部引用檢查，講一聲，不擋其他兩張表匯入。

# 這幾種標籤的 AI更正 一定要填：程式要照它修登錄表，或照它寫建議改法
_FIX_REQUIRED = ("名稱錯誤", "本文名稱錯誤", "引用過時", "條號錯誤", "漏抓")
_URL_RE = re.compile(r"https?://")
# 清單頁：檔名主幹是 list／index 這類（regulationlist、index03）；checklist、文件檔不算
_ENTRY_STEM_RE = re.compile(r"(?:.*(?<!check))?(?:list|index)\d*", re.IGNORECASE)
_DOCUMENT_SUFFIXES = (".pdf", ".doc", ".docx", ".odt", ".xls", ".xlsx", ".ods", ".ppt", ".pptx", ".zip", ".txt")


def entry_page(source):
    """查證來源裡第一個「不是實際頁面」的網址：純網域首頁（路徑空或 /），或清單頁（最後一段檔名主幹是 list／index
    這類，例 regulationlist.aspx、index.html）而且沒有查詢參數。沒有回空字串（v1.51.0：以前只查有沒有 http）。"""
    from urllib.parse import urlsplit
    for token in re.split(r"[\s;；,，、]+", source or ""):
        if not _URL_RE.match(token):
            continue
        parts = urlsplit(token)
        if parts.query:
            continue
        path = parts.path or ""
        stem, suffix = os.path.splitext(path.rstrip("/").rsplit("/", 1)[-1])
        if path in ("", "/") or (suffix.lower() not in _DOCUMENT_SUFFIXES and _ENTRY_STEM_RE.fullmatch(stem)):
            return token
    return ""


def _checked_online(verdict, label):
    """這一列的答案靠上網查證（查證來源要是實際打開的頁面）。"""
    return verdict in ("沒問題", "漏抓") or label in ("本文名稱錯誤", "引用過時", "條號錯誤")


# 公會的法規清單頁列的是規範名稱和備查版本，自律規範查到這裡就是查到了：理由有寫是哪一版、哪一天備查的就算數。
# 要有日期（民國或西元）：只寫「名稱相符」等於沒查版本；日期要接著「備查」「版」，不然是別的事的日期
_LISTED_DATE = r"\d{2,4}\s*[./年-]\s*\d{1,2}\s*[./月-]\s*\d{1,2}\s*日?"
_LISTED_VERSION_RE = re.compile(r"備查版[^。；\n]{0,6}(?:%s|\d{6,8})|%s[^。；\n]{0,30}備查|%s\s*(?:網頁|修正)?版"
                                % (_LISTED_DATE, _LISTED_DATE, _LISTED_DATE))
GUILD_CATEGORY = "公會自律規範"


def _listed_version_said(reason, category, source):
    """理由寫明了清單頁查到的備查日或版本。網域首頁不算（首頁看不到版本）。
    「備查日」是舊規則的寫法，不分類別照收；其他寫法只收公會自律規範：法律、法規的版本要看條文頁。"""
    if "備查日" in reason:
        return True
    from urllib.parse import urlsplit
    page = urlsplit(entry_page(source)).path
    return category == GUILD_CATEGORY and page not in ("", "/") and bool(_LISTED_VERSION_RE.search(reason))


def weak_source(verdict, reason, category, source):
    """這一列要上網查證、查證來源卻只是網域首頁或清單頁：回那個網址，沒問題回空字串。
    本行內規查不到網路來源；公會清單頁的例外是理由寫明備查日或備查版（見 _listed_version_said）。"""
    reason = reason or ""
    if not _checked_online(verdict, sr.label_in(reason)) or category == "本行內規" \
            or _listed_version_said(reason, category, source):
        return ""
    return entry_page(source)


def external_required(outdir):
    """這一輪審查打包有沒有把外部引用交給 AI：打包時凍結了外部引用清單就是有（rp.freeze_external）。
    有的話 AI外部引用.csv 空白或不見了要擋下來；舊版產出沒有這份，照舊可以不填（相容）。"""
    return os.path.isfile(locate(outdir, rp.EXTERNAL_FROZEN_FILE)[0])


def rulecheck_required(outdir):
    """這一輪審查打包有沒有把條文檢查交給 AI：寫了條文檢查清單就是有（rp._rulecheck_pack）。"""
    return os.path.isfile(locate(outdir, RULECHECK_LIST)[0])


def _offline_row(row):
    """這一列 AI 回的是連不上網（不是查了之後的結論）。"""
    import verify_cache as vc
    return _s(row.get("AI判斷")) == "無法查證" and (
        sr.label_in(_s(row.get("AI理由"))) == "無法連網" or vc._connection_not_found(row))


def _keep_old_when_offline(outdir, rows):
    """排了重查、這一輪卻連不上網的列：舊答案、舊來源照留，不能因為這次查不了就把查過的結論降成「無法查證」。
    表上的答案換回舊的（報告、下一步都照它走），只在重查舊答案.json 記一筆，報告上註記。
    回傳這幾列的快取鑰匙：匯入成功才算一次沒做成（見 verify_cache.note_retry）。"""
    saved = rp.recheck_state(outdir)
    if not saved or not rows:
        return []
    import verify_cache as vc
    from _common import tw_today
    keys = []
    for row in rows:
        old = saved.get(_s(row.get(rp.EXTERNAL_SHA_COLUMN)))
        if not old or not _offline_row(row):
            continue
        row.update((column, old.get(column) or "") for column in vc.FIELDS)
        row["沿用查證"] = old.get("日期") or ""
        old[rp.RECHECK_OFFLINE] = tw_today().isoformat()
        keys.append(old.get("鑰匙") or "")
    if not keys:
        return []
    rp.write_recheck_state(outdir, saved)
    path = locate(outdir, rp.EXTERNAL_FILE)[0]
    header = _read_ai_csv(path)[1]
    tmp = path + ".tmp"
    with io.open(tmp, "w", encoding="utf-8-sig", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=header, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(rows)
    replace_file(tmp, path)
    nt.notice(nt.REMINDER, "%d 列排了重查，但這一輪連不上網：舊答案、舊來源照留，下一輪換別列先查" % len(keys), "review-import")
    return keys


def load_external(outdir):
    """讀 AI外部引用.csv；沒有這個檔（舊的產出資料夾、還沒跑過新版 review-pack）回 None。"""
    path = locate(outdir, rp.EXTERNAL_FILE)[0]
    if not os.path.isfile(path):
        return None
    return _read_ai_csv(path)[0]


def _category(row, item):
    from _common import external_category
    return _s(row.get("類別")) or (external_category(item["名稱"]) if item else "")


def external_value_errors(tag, verdict, reason, carried=False):
    """外部引用一列的判斷字配標籤、理由。check_external 與 填表 共用（v1.51.0）。
    carried：程式從查證快取帶回來的列，模板句打包時就換掉了，這裡不再擋。"""
    errors = [] if carried else _not_asking_errors(tag, reason)
    label = sr.label_in(reason)
    if not reason:
        errors.append("%s：AI理由是空的" % tag)
    elif not label:
        errors.append("%s：AI理由要用標籤開頭（可用：%s）" % (tag, sr.external_labels()))
    elif verdict in sr.EXTERNAL_VERDICTS and not sr.external_label_ok(verdict, label):
        errors.append("%s：「〔%s〕」配不上判斷「%s」（%s 可用：%s）"
                      % (tag, label, verdict, verdict, sr.external_labels(verdict)))
    if label in ("名稱錯誤", "本文名稱錯誤", "引用過時", "條號錯誤") and not any(word in reason for word in REQUIRED_REASON_WORDS[label]):
        errors.append("%s：〔%s〕的理由要寫「改成…」" % (tag, label))
    return errors


_TEXT_NAME_NEGATION = re.compile(
    r"(?:手冊(?:原文|本文|內文)?|內文|本文|原文|段落)(?:本身|中的名稱|的名稱)?(?:無須|不必|不用|不需要|無需|沒有|並未|並無|未|沒|不)(?:改|寫錯|錯誤|有誤|誤植|錯)"
    r"|(?:無須|不必|不用|不需要|無需)改(?:手冊|內文|本文|原文|段落)"
)
_TEXT_NAME_CONFLICT = re.compile(
    r"(?:手冊(?:原文|本文|內文)?|內文|本文|原文|段落)(?:本身|中的(?:法規)?名稱|的(?:法規)?名稱|所寫(?:的)?(?:法規)?名稱)?(?:應該|應|須|要|需要|需|建議)?(?:改成|改為|改|寫錯|有誤|誤植|錯誤|不正確|不對|漏字|錯字|誤寫|非現行)"
)


def _new_external_conflict(tag, reason):
    """辨識標籤與本文需修改的理由互相矛盾。"""
    if sr.label_in(reason) == "名稱錯誤" and _TEXT_NAME_CONFLICT.search(_TEXT_NAME_NEGATION.sub("", reason)):
        return ["%s：理由說手冊本文要改，與〔名稱錯誤〕矛盾；舊答案也請核對：本文寫錯改用〔本文名稱錯誤〕，只是程式剪錯則說明原文正確，請用填表修改" % tag]
    return []


def rulecheck_value_errors(tag, verdict, reason):
    """條文檢查一列的判斷字、標籤、理由。check_rulecheck 與 填表 共用（v1.51.0）。"""
    errors = []
    if verdict not in sr.RULECHECK_VERDICTS:
        errors.append("%s：AI判斷 只能是 %s：「%s」" % (tag, "／".join(sr.RULECHECK_VERDICTS), verdict))
    label = sr.label_in(reason)
    if not reason:
        errors.append("%s：AI理由是空的" % tag)
    elif not label:
        errors.append("%s：AI理由要用標籤開頭（可用：%s）" % (tag, sr.rulecheck_labels()))
    elif verdict in sr.RULECHECK_VERDICTS and not sr.rulecheck_label_ok(verdict, label):
        errors.append("%s：「〔%s〕」配不上判斷「%s」（%s 可用：%s）"
                      % (tag, label, verdict, verdict, sr.rulecheck_labels(verdict)))
    if verdict == "有問題" and not any(word in reason for word in REQUIRED_REASON_WORDS[verdict]):
        errors.append("%s：「有問題」的理由要寫「改成…」" % tag)
    return errors


def answer_value_errors(name, row, new_external_answer=True):
    """填表前驗一列的值（表上既有的值＋這次填的合起來）：只看這一列自己，對不對得上這一輪交給匯入。
    訊息跟審查匯入同一套。不是這裡管的表回 None。"""
    verdict, reason = _s(row.get("AI判斷")), _s(row.get("AI理由"))
    if name in ("AI候選判斷.csv", "AI異動審查.csv"):
        id_col, prefix = ("列ID", "R") if name == "AI候選判斷.csv" else ("異動ID", "C")
        rid = _s(row.get(id_col)) or "（沒有%s）" % id_col
        return _validate_sheet(name, [dict(row, **{id_col: rid})], id_col, prefix, id_col, [rid], [rid])
    if name == rp.EXTERNAL_FILE:
        rid = _s(row.get("引用ID")) or "新增"
        tag = "「%s」%s" % (name, rid)
        if not verdict and not reason and not _s(row.get("AI更正")):
            return ["%s：還沒填（AI判斷、AI理由都空白）" % tag]
        errors = []
        if rid == "新增" and verdict != "漏抓":
            errors.append("%s：自己加的列 AI判斷 只能填「漏抓」" % tag)
        elif rid != "新增" and verdict not in ("有誤", "無法查證", "沒問題"):
            errors.append("%s：AI判斷 只能是 有誤／無法查證／沒問題：「%s」" % (tag, verdict))
        return (errors + external_value_errors(tag, verdict, reason, bool(_s(row.get("沿用查證"))))
                + (_new_external_conflict(tag, reason) if new_external_answer else []))
    if name == rp.RULECHECK_FILE:
        tag = "「%s」%s" % (name, _s(row.get("檢查ID")) or "（沒有檢查ID）")
        if not verdict and not reason:
            return ["%s：還沒填（AI判斷、AI理由都空白）" % tag]
        return rulecheck_value_errors(tag, verdict, reason)
    return None


def check_external(book, ai_rows, required=False):
    """驗 AI外部引用.csv。回傳 (錯誤 list, 驗過可匯入的列 list 或 None＝整張沒填, 過期的引用ID list)。

    這一步盡量不留給人：法律與主管機關法規要 AI 上網查證（沒附查證網址就退件），
    「無法查證」只收本行內規、查無資料、無法連網三種。
    過期：這一列審的是哪一段、哪一處引用，由段落指紋記著；重跑 compare 之後字變了就不匯入。

    required：這一輪審查打包有把外部引用交給 AI（見 import_review）。有要查的引用、
    表卻不見了或整張沒填，就是錯誤——以前回「沒有錯誤」，照樣匯入、標成審完，
    引用檢查頁沒有任何查證結果。"""
    if ai_rows is None and not required:
        return [], None, []
    items = dict((item["引用ID"], item) for item in rp.external_items(book))
    if ai_rows is None:
        if items:
            return (["找不到「%s」：這一輪有 %d 處外部引用要 AI 上網查證，表被刪掉或移走了；請重跑 審查打包"
                     % (rp.EXTERNAL_FILE, len(items))], None, [])
        return [], None, []
    # 從查證快取沿用的列（「沿用查證」有日期）不算 AI 這一輪填的：只有它們、別的都沒填，
    # 而且還有沒沿用到的引用，就是 AI 這一輪沒做外部引用檢查
    answered = [r for r in ai_rows if not _s(r.get("沿用查證"))
                and (_s(r.get("AI判斷")) or _s(r.get("AI理由")) or _s(r.get("AI更正")))]
    reused = set(_s(r.get("引用ID")) for r in ai_rows if _s(r.get("沿用查證")))
    if not answered and not (items and set(items) <= reused):
        if required and items:
            todo = len(set(items) - reused)
            return (["「%s」整張沒填：這一輪有 %d 處外部引用要 AI 上網查證；請 AI 照 先讀我.md 填好再匯入"
                     % (rp.EXTERNAL_FILE, todo)], None, [])
        return [], None, []
    total = len(book["new_paragraphs"])
    errors, good, stale, seen = [], [], [], set()
    carried_pages = []
    for row in ai_rows:
        rid = _s(row.get("引用ID"))
        tag = "「%s」%s" % (rp.EXTERNAL_FILE, rid or "（沒有引用ID）")
        verdict = _s(row.get("AI判斷"))
        reason = _s(row.get("AI理由"))
        fix = _s(row.get("AI更正"))
        source = _s(row.get("查證來源"))
        item = items.get(rid)
        if rid == "新增":
            line = _s(row.get("段次"))
            if not (line.isdigit() and 1 <= int(line) <= total):
                errors.append("%s：段次要是 1–%d 的整數：「%s」" % (tag, total, line))
            if verdict != "漏抓":
                errors.append("%s：自己加的列 AI判斷 只能填「漏抓」" % tag)
            if sr.label_in(reason) == "本文名稱錯誤" and line.isdigit() and 1 <= int(line) <= total:
                original = _s(row.get("程式抓到"))
                if not original or book["new_paragraphs"][int(line) - 1].count(original) != 1:
                    errors.append("%s：漏抓且本文名稱錯誤時，程式抓到要填本文原有名稱，且須在該段唯一出現" % tag)
        elif item:
            if rid in seen:
                errors.append("%s：引用ID 重複" % tag)
            seen.add(rid)
            if _s(row.get(rp.EXTERNAL_SHA_COLUMN)) not in ("", item["sha"]):
                stale.append(rid)
                continue
            if not verdict and not reason and not fix:
                errors.append("%s：還沒填（AI判斷、AI理由都空白）" % tag)
                continue
            if verdict not in ("有誤", "無法查證", "沒問題"):
                errors.append("%s：AI判斷 只能是 有誤／無法查證／沒問題：「%s」" % (tag, verdict))
        else:
            errors.append("%s：引用ID 對不上（程式抓到的是 E1…E%d，自己加的列寫「新增」）"
                          % (tag, len(items)))
            continue
        label = sr.label_in(reason)
        errors += external_value_errors(tag, verdict, reason, bool(_s(row.get("沿用查證"))))
        conflict = _new_external_conflict(tag, reason)
        if conflict:
            nt.notice(nt.WARNING, conflict[0] + "；這次保留答案、不登錄名稱，報告列需人工確認", "外部引用")
        if label == "本文名稱錯誤" and fix and (item or rid == "新增"):
            line = item["段次"] if item else int(row["段次"]) if _s(row.get("段次")).isdigit() else 0
            if 1 <= line <= total and _splice_text_name(book["new_paragraphs"][line - 1], item, row, fix) is None:
                errors.append("%s：無法唯一定位本文原有名稱，或 AI更正包含條號；請確認原文與正確全銜後重新填寫" % tag)
        category = _category(row, item)
        if category and category not in sr.EXTERNAL_CATEGORIES:
            errors.append("%s：類別只能是 %s：「%s」" % (tag, "／".join(sr.EXTERNAL_CATEGORIES), category))
        if (label == "名稱錯誤" or verdict == "漏抓") and category not in sr.EXTERNAL_CATEGORIES:
            errors.append("%s：〔%s〕要填類別（%s），匯入時照它加進登錄表"
                          % (tag, label or verdict, "／".join(sr.EXTERNAL_CATEGORIES)))
        if (label in _FIX_REQUIRED or verdict == "漏抓") and not fix:
            errors.append("%s：〔%s〕要在 AI更正 填正確的寫法" % (tag, label or verdict))
        if (label == "名稱錯誤" or (verdict == "漏抓" and label != "本文名稱錯誤")) and fix:
            # 這一格會進登錄表、下一輪程式照字面找：帶著引號、「依」的名稱登錄進去就永遠抓錯（審查 C9）
            better = bad_law_name(_law_name_of(fix))
            if better:
                errors.append("%s：AI更正 要寫法規全銜本身（不加引號、不加「依」「及」這類字）：「%s」應該是「%s」"
                              % (tag, _law_name_of(fix), better))
        checked_online = _checked_online(verdict, label)
        if checked_online and category not in ("本行內規",) and not _URL_RE.search(source) \
                and not _library_source(source):
            errors.append("%s：法律、主管機關法規、公會自律規範要上網查證，查證來源 要填實際打開的網址"
                          "（規範資料庫有全文的，寫「資料庫：外部規範/檔名」）" % tag)
        if weak_source(verdict, reason, category, source):
            # v1.51.0：網域首頁、清單頁不算查證（規則本來就禁止，以前程式只查有沒有 http）；
            # 公會清單頁查備查日期的例外：理由寫明「備查日」。程式從查證快取帶回來的舊答案（沿用查證有值）只提醒，
            # 不然舊規則下查過的列下一輪整批退件。v1.53.0：沿用列打包時就排進重查（rp._recheck_carried），這裡剩超過每輪上限的
            if _s(row.get("沿用查證")):
                carried_pages.append(rid)
            else:
                errors.append("%s：查證來源要填實際打開的那一頁（條文頁）的網址，不是網域首頁或清單頁：%s"
                              "（公會清單頁查備查日期的例外：理由寫明備查日或備查版，要有日期）"
                              % (tag, weak_source(verdict, reason, category, source)))
        if source.startswith("資料庫：") and not _library_source(source):
            errors.append("%s：查證來源「%s」在規範資料庫找不到這個檔（照 資料庫/目錄.csv 的資料夾/檔名寫）"
                          % (tag, source[:80]))
        if label == "查無資料" and not source:
            errors.append("%s：〔查無資料〕要在 查證來源 寫查了哪些網址或關鍵字" % tag)
        if label == "查無資料":
            from verify_cache import CONNECTION_ERROR_RE
            if CONNECTION_ERROR_RE.search(reason + "\n" + source):
                errors.append("%s：這是連線或憑證問題，不是查無資料：先用 `py scripts/run_all.py 查法條 <網址>` "
                              "讀官方頁（它會處理政府網站的憑證）；真的讀不到就寫〔無法連網〕，不會被記住、下次再查。" % tag)
        good.append(row)
    for rid in sorted(set(items) - seen, key=lambda x: int(x[1:])):
        errors.append("「%s」缺 %s（程式抓到的每一處都要判）" % (rp.EXTERNAL_FILE, rid))
    for reason, rows in sr.repeated_external_reasons([r for r in ai_rows if not _s(r.get("沿用查證"))]).items():
        errors.append("「%s」%s…：同一句理由套在 %d 列不同的引用上（%s…）：每一處要寫這一處查到什麼（條號、條文內容）"
                      % (rp.EXTERNAL_FILE, "、".join(_s(r.get("引用ID")) for r in rows[:6]), len(rows), reason[:40]))
    if carried_pages:
        nt.notice(nt.REMINDER, "%d 列沿用的查證來源是網域首頁或清單頁（%s…）：這次照收，下一輪排進重查"
                  % (len(carried_pages), "、".join(carried_pages[:5])), "review-import")
    return errors, good, stale


def _library_source(source):
    """查證來源寫的是規範資料庫裡真的有的一份（v1.9.0）。"""
    import rule_library as lib
    return (source or "").strip().startswith(lib.SOURCE_PREFIX) and lib.load().has_source(source)


def _remember_external(outdir, book, rows):
    """AI 這一輪上網查過的（有誤、沒問題，v1.8.0 起加上〔本行內規〕）存進查證快取，下一輪同一處引用直接沿用。"""
    import batch as bt
    import verify_cache as vc
    folder = bt.cache_dir(outdir)
    if not folder:
        return 0
    items = dict((item["引用ID"], item) for item in rp.external_items(book))
    import precedents as pc
    seen = pc.seen_marks(outdir, rp.EXTERNAL_FILE) if outdir else {}     # v1.40.0：看著承辦意見重查的那幾處
    pairs = []
    total = len(book["new_paragraphs"])
    for row in rows:
        item = items.get(_s(row.get("引用ID")))
        if item:
            k = vc.key(item["引用"], book["new_paragraphs"][item["段次"] - 1])
            pairs.append((k, dict(row, **{vc.SEEN_FIELD: seen[k]}) if seen.get(k) else row, item["引用"]))
        elif _s(row.get("引用ID")) == "新增" and sr.label_in(_s(row.get("AI理由"))) in ("正確", "未指明條號"):
            # AI 補的漏抓、查過名稱正確：這一輪匯入會把名稱加進登錄表，下一輪程式就抓得到這一處。
            # 照程式到時候的寫法（「名稱（未指明條號）」）存一筆「沒問題」，不然下一輪又要上網查一次
            line = _s(row.get("段次"))
            if not (line.isdigit() and 1 <= int(line) <= total):
                continue
            citation = re.sub(r"\s+", "", _s(row.get("AI更正")))
            if not re.search(r"第[%s\d]+[條點]" % "零〇一二三四五六七八九十百千", citation):
                citation += "（未指明條號）"
            pairs.append((vc.key(citation, book["new_paragraphs"][int(line) - 1]),
                          dict(row, **{"AI判斷": "沒問題", "AI更正": ""}), citation))
    return vc.record(folder, pairs)


def _law_name_of(citation):
    """「洗錢防制法第十條」→「洗錢防制法」（登錄表只記名稱）。"""
    text = re.sub(r"\s+", "", citation or "")
    text = re.sub(r"（未指明條號）$", "", text)
    match = re.match(r"^(.+?)第[%s\d]+[條點]" % "零〇一二三四五六七八九十百千", text)
    return match.group(1) if match else text


_LAW_NAME_JUNK_RE = re.compile(r"[「」『』《》〈〉\"']|^(?:依|按|照|依據|依照|準用|適用|遵守|違反|及|與|或|、)")


def _comma_titled(text, cleaned):
    """全銜本身有頓號（銀行、證券商及保險公司等機構合作推廣他業商品或提供相關服務規範）。
    剝字規則只認頓號後面那一段，登錄表還沒有這個名字時（AI 第一次補登），驗表就叫 AI 砍掉「銀行、」，
    砍了又跟官網全銜不合，卡住整批（v1.47.1 模擬）。前面多的只是「詞、詞、」、沒有動詞時照 AI 寫的。"""
    from _common import _LAW_NAME_CUES, _LAW_NAME_LEADERS
    if not text.endswith(cleaned):
        return False
    prefix = text[:-len(cleaned)]
    words = prefix.split("、")[:-1]
    return (bool(re.match(r"^(?:[一-鿿]{1,12}、)+$", prefix))
            and not any(re.search(r"(?:自律規範|注意事項|條例|辦法|準則|規則|細則|要點|規範|法)$", w) for w in words)
            and not any(cue in prefix for cue in _LAW_NAME_CUES)
            and not set(prefix) & set(_LAW_NAME_LEADERS))


def bad_law_name(name):
    """要登錄的名稱不像法規全銜本身時，回建議的寫法；像的話回 ""。
    「「保險法」」「依保險法」「依保險法第五條及保險代理人管理規則」這種登錄進去，
    下一輪程式用字面找到的名稱就帶著引號、「依」，AI 又判名稱錯誤、_learn 回「登錄表已有」，每輪重複。
    字尾不在 clean_law_name 認得的那幾種（範本、指引…）時不擋：AI 判了就照它。"""
    from _common import clean_law_name
    text = re.sub(r"\s+", "", name or "")
    if not text:
        return ""
    # 這一格本來就是 AI 填的法規名稱：全銜裡的責任用語不能當成句子切掉，不然正確的全銜過不了
    cleaned = clean_law_name(text, cited=True)
    if cleaned and cleaned != text and not _comma_titled(text, cleaned):
        return cleaned
    if _LAW_NAME_JUNK_RE.search(text):
        return cleaned or re.sub(r"[「」『』《》〈〉\"']", "", text)
    return ""


def _splice_citation(text, item, fix):
    """把那一處外部引用換成 AI更正（「名稱＋條號」的寫法）。

    原文就是照「引用」那樣寫的，整段換掉。原文寫法不一樣時——名稱加引號（「保險法」第五條）、
    「同法第五條」、第二個條號（保險法第五條、第七條的「第七條」，起訖只框條號）——
    AI更正的名稱跟程式抓到的一樣就只換條號，名稱那一段照原文留著；整段換掉的話
    引號會少一半、「同法」被改寫、第二個條號前面多出一次名稱。
    AI更正連後面的括號一起寫（保險法(115.09.30修正)），原文緊接的那個括號也一起換掉，
    不然新舊兩個括號會疊在一起。"""
    start, end = item["起"], item["訖"]
    original = text[start:end]
    name, number = item.get("名稱") or "", item.get("條號") or ""
    tail = fix[len(original):] if fix.startswith(original) else ""
    if tail[:1] in ("(", "（") and text[end:end + 1] in ("(", "（"):
        close = re.search(r"[)）]", text[end:])
        if close:
            end += close.end()
    if (original == item.get("引用") or not number or not original.endswith(number)
            or not fix.startswith(name)):
        return text[:start] + fix + text[end:]
    return text[:end - len(number)] + fix[len(name):] + text[end:]


def _splice_text_name(text, item, row, fix):
    """只替換名稱，保留引用內外的條號、引號與其他文字；無法定位時不猜。"""
    if _law_name_of(fix) != re.sub(r"\s+", "", fix) or re.search(r"§\s*\d", fix):
        return None
    if item:
        start, end = item["起"], item["訖"]
        original, name = text[start:end], item.get("名稱") or ""
    else:
        original = _s(row.get("程式抓到"))
        if not original or text.count(original) != 1:
            return None
        start = text.index(original)
        end = start + len(original)
        name = _law_name_of(original).strip("「」『』《》〈〉\"' ")
    if not name or original.count(name) != 1:
        return None
    offset = original.index(name)
    return text[:start + offset] + fix + text[start + offset + len(name):]


_LEARNED = []      # [(表, 名稱, 類別, 說明)]：這一次匯入學到、還沒寫進 memoization/ 的名稱
# v1.27.2：這一次匯入裡，AI 判成真的外部引用（沒問題、有誤〔引用過時、條號錯誤〕、無法查證、漏抓、名稱錯誤的更正）的名稱。
# 同一個名稱在某一段是手冊自己的章節標題（AI 判非外部法規）、在別段是真的引用時，不整個名稱加進排除表：
# 以前一加就整本都不抓，別段真的引用從此漏掉；標題那一段的判斷照段落文字存在查證紀錄，下一輪照樣沿用
_CITED = set()


def _squash(name):
    return re.sub(r"\s+", "", name or "")


def _learn(kind, name, category, note):
    """排一個名稱等著寫進登錄表（kind="登錄"）或排除表（"排除"）。表上或排隊裡已經有就回 False。"""
    from _common import external_exclusions, external_registry
    key = re.sub(r"\s+", "", name)
    known = (set(n for n, _ in external_registry()) if kind == "登錄" else external_exclusions())
    if key in known or any(k == kind and n == key for k, n, _, _ in _LEARNED):
        return False
    _LEARNED.append((kind, key, category, note))
    return True


def flush_learned():
    """把排隊的名稱寫進登錄表、排除表（下一次比對生效）。回傳真的寫了幾個。
    最新的判斷贏：登錄的名稱從排除表拿掉、排除的名稱從登錄表拿掉——兩張表都有同一個名字時，
    登錄表那條路（rule_checks 照字面找）不看排除表，每一輪都要 AI 再判一次非外部法規（審查 C2）。"""
    from _common import (add_external_exclusion, add_external_registry,
                         remove_external_exclusion, remove_external_registry)
    written = 0
    excluded, kept = [], []
    for kind, name, category, note in _LEARNED:
        if kind == "登錄":
            remove_external_exclusion(name)
            written += bool(add_external_registry(name, category, note))
        elif name in _CITED:
            kept.append(name)               # v1.27.2：別段是真的引用：只那一段判非外部法規，不整個名稱排除
        else:
            remove_external_registry(name)
            if add_external_exclusion(name, note):
                written += 1
                excluded.append(name)
    if excluded:
        nt.notice(nt.REMINDER, "外部規章：程式抓錯的已自動修正（排除：%s），下一次比對就不會再抓"
                  % "、".join(excluded), "review-import")
    if kept:
        nt.notice(nt.REMINDER, "外部規章：%s 在某一段是手冊自己的標題、在別段是真的外部引用：不加進排除表，"
                  "只那一段判非外部法規（下一輪照段落沿用）" % "、".join("「%s」" % n for n in kept), "review-import")
    del _LEARNED[:]
    _CITED.clear()
    return written


def discard_learned():
    """匯入中止：排隊的名稱不寫（重跑匯入會再學一次）。"""
    del _LEARNED[:]
    _CITED.clear()


def apply_external(book, rows, table_path):
    """AI 判完之後程式自己做的事（不用人）：
        程式抓錯（名稱錯誤、漏抓）→ 名稱加進登錄表；非外部法規 → 加進排除表。下一次比對就抓對。
        本文引用錯（引用過時、條號錯誤）→ 接進連帶決定表，建議改法照位置把那一處換成 AI更正。
    登錄表、排除表不在這裡寫，先排進 _LEARNED，由 flush_learned() 在匯入做完時一次寫：
    引用ID（E1…）是照登錄表、排除表現抓的，中途改表，同一輪後面的報告與其他本的 E 編號就整個錯位。
    回傳 {"逐列": [每一列做了什麼], "登錄": [...], "排除": [...], "決定表": 新增幾列, "無法查證": [...]}。"""
    items = dict((item["引用ID"], item) for item in rp.external_items(book))
    paragraphs = book["new_paragraphs"]
    done = {"逐列": [], "登錄": [], "排除": [], "決定表": 0, "無法查證": [], "本行內規": []}
    fixes = []
    for row in rows:
        rid = _s(row.get("引用ID"))
        item = items.get(rid)
        verdict = _s(row.get("AI判斷"))
        label = sr.label_in(_s(row.get("AI理由")))
        fix = _s(row.get("AI更正"))
        source = _s(row.get("查證來源"))
        action = ""
        if _new_external_conflict("", _s(row.get("AI理由"))):
            done["逐列"].append("判斷與理由衝突：未登錄，報告列需人工確認")
            continue
        if item and label != "非外部法規" and verdict in ("沒問題", "有誤", "無法查證"):
            _CITED.add(_squash(item["名稱"]))
        if fix and (label in ("名稱錯誤", "本文名稱錯誤", "引用過時", "條號錯誤") or verdict == "漏抓"):
            _CITED.add(_squash(_law_name_of(fix)))
        if label == "名稱錯誤" or (verdict == "漏抓" and label != "本文名稱錯誤"):
            name = _law_name_of(fix)
            if _learn("登錄", name, _category(row, item), "AI 外部引用檢查〔%s〕" % label):
                done["登錄"].append(name)
                action = "已加進登錄表：%s" % name
            else:
                action = "登錄表已有：%s" % name
        elif label == "非外部法規" and item:
            if _learn("排除", item["名稱"], "", "AI 外部引用檢查"):
                done["排除"].append(item["名稱"])
            action = "已加進排除表：%s" % item["名稱"]
        elif label in ("本文名稱錯誤", "引用過時", "條號錯誤") and (item or (verdict == "漏抓" and label == "本文名稱錯誤")):
            line = item["段次"] if item else int(row["段次"])
            text = paragraphs[line - 1]
            original = item["引用"] if item else _s(row.get("程式抓到"))
            replacement = (_splice_text_name(text, item, row, fix) if label == "本文名稱錯誤"
                           else _splice_citation(text, item, fix))
            if replacement is None:
                raise ReviewError("本文名稱錯誤：無法唯一定位原名稱或更正含條號，請重新核對")
            fixes.append({"段次": line, "候選全文": text,
                          "建議改法": replacement,
                          "異動內容": "「%s」→「%s」（外部引用〔%s〕）" % (original, fix, label),
                          "關係": "〔%s〕查證：%s" % (label, source)})
            action = "列進連帶決定表（第 %d 段）" % line
        elif verdict == "無法查證":
            # v1.24.0：〔本行內規〕（本行自己的規範，網路上本來就查不到）跟 AI 真的沒查到的分開講
            done["本行內規" if label == "本行內規" else "無法查證"].append(item["引用"] if item else rid)
            action = "要承辦確認"
        done["逐列"].append(action)
    if fixes:
        done["決定表"] = dt.append_external_rows(table_path, fixes)
        done["決定表"] = max(done["決定表"], len(fixes))
    return done


def _count_external(rows):
    counts = dict((v, 0) for v in sr.EXTERNAL_VERDICTS)
    for row in rows:
        verdict = _s(row.get("AI判斷"))
        if verdict in counts:
            counts[verdict] += 1
    return counts


# ---------------------------------------------------------------------------
# 條文檢查高風險項（AI條文檢查.csv）
# ---------------------------------------------------------------------------
# 條文檢查報告的「高」風險項（應→得、數值期間、條號重複、定義變更連動、待補殘留）加上施行日期，
# 以前只躺在檢視報告裡，沒有表可以回覆，也不擋驗收。review-pack 把它們（K1…）交給 AI 上網查證，
# 這裡驗 AI 填的表：結果（判斷、理由、網址）都寫進檢視報告，不另外要人回覆。

NOT_REVIEWED = "（AI 沒審）"


# 審查打包把條文檢查交給 AI 時寫的清單（review_pack._rulecheck_pack）：有它就表示這一輪要 AI 判
RULECHECK_LIST = "LLM條文檢查清單.md"


def load_rulecheck(outdir):
    """讀 AI條文檢查.csv；沒有這個檔回 None。"""
    path = locate(outdir, rp.RULECHECK_FILE)[0]
    if not os.path.isfile(path):
        return None
    return _read_ai_csv(path)[0]


def check_rulecheck(items, ai_rows, required=False):
    """驗 AI條文檢查.csv。回傳 (錯誤 list, {檢查ID: 列} 或 None＝整張沒填, 過期的檢查ID list)。

    required：這一輪審查打包有把條文檢查交給 AI（見 import_review）。有高風險項、
    表卻不見了或整張沒填，就是錯誤——以前照樣匯入，那幾項變成「AI 沒審」丟給人。"""
    if items is None:
        return [], None, []
    if ai_rows is None:
        if required and items:
            return (["找不到「%s」：這一輪有 %d 項條文檢查要 AI 判，表被刪掉或移走了；請重跑 審查打包"
                     % (rp.RULECHECK_FILE, len(items))], None, [])
        return [], None, []
    if not [r for r in ai_rows if _s(r.get("AI判斷")) or _s(r.get("AI理由"))]:
        if required and items:
            return (["「%s」整張沒填：這一輪有 %d 項條文檢查要 AI 判；請 AI 照 先讀我.md 填好再匯入"
                     % (rp.RULECHECK_FILE, len(items))], None, [])
        return [], None, []
    by_id = dict((item["檢查ID"], item) for item in items)
    errors, good, stale, seen = [], {}, [], set()
    for row in ai_rows:
        kid = _s(row.get("檢查ID"))
        tag = "「%s」%s" % (rp.RULECHECK_FILE, kid or "（沒有檢查ID）")
        item = by_id.get(kid)
        if item is None:
            errors.append("%s：檢查ID 對不上（這一輪是 K1…K%d）" % (tag, len(items)))
            continue
        if kid in seen:
            errors.append("%s：檢查ID 重複" % tag)
        seen.add(kid)
        if _s(row.get(rp.RULECHECK_SHA_COLUMN)) not in ("", item["sha"]):
            stale.append(kid)
            continue
        verdict, reason, source = _s(row.get("AI判斷")), _s(row.get("AI理由")), _s(row.get("查證來源"))
        if not verdict and not reason:
            errors.append("%s：還沒填（AI判斷、AI理由都空白）" % tag)
            continue
        errors += rulecheck_value_errors(tag, verdict, reason)
        label = sr.label_in(reason)
        if item.get("check") == "用語混用" and label == "前後一致" and len(reason) < 20:
            nt.notice(nt.REMINDER, "%s：用語混用判〔前後一致〕，理由請寫兩種寫法各用在哪裡" % tag, "review-import")
        if label in sr.RULECHECK_URL_LABELS and not _URL_RE.search(source) and not _library_source(source):
            errors.append("%s：〔%s〕要上網查證，查證來源 要填實際打開的網址"
                          "（照審查包附的規範資料庫條文判的，寫「資料庫：資料夾/檔名」）" % (tag, label))
        if label == "查無依據" and not source:
            errors.append("%s：〔查無依據〕要在 查證來源 寫查了哪些網址或關鍵字" % tag)
        good[kid] = row
    for kid in sorted(set(by_id) - seen, key=lambda x: int(x[1:])):
        errors.append("「%s」缺 %s（每一項都要判）" % (rp.RULECHECK_FILE, kid))
    return errors, good, stale


def _rulecheck_state(item, good):
    """(AI判斷, AI理由, 查證來源, 要不要人確認)。"""
    row = (good or {}).get(item["檢查ID"])
    if row is None:
        return NOT_REVIEWED, "", "", True
    verdict = _s(row.get("AI判斷"))
    return verdict, _s(row.get("AI理由")), _s(row.get("查證來源")), verdict != "沒問題"
