# -*- coding: utf-8 -*-
"""法規證據介面：MCP、官方網頁、官方資料檔、本機文件使用相同事件格式。

只蒐集證據，不把查不到、解析失敗或匯入文件推論成「沒有修法」。
"""
import datetime as dt
import hashlib
from html.parser import HTMLParser
import json
from pathlib import Path
import re
import subprocess
import sys
import urllib.parse
import urllib.request
import urllib.error
import xml.etree.ElementTree as ET
import zipfile
import io
import queue
import threading
import ssl
import socket
import http.client
import importlib.util
import os
from file_replace import replace_file

MAX_BYTES = 40 * 1024 * 1024
STATUSES = {"現行", "草案", "已公布未施行", "廢止", "待確認"}


class SourceError(ValueError):
    pass


class BrokenFile(SourceError):
    """來源檔本身壞了、解析不了（截斷的 PDF、壞的 ZIP／XML）：只影響那一則，快取裡那一份要丟掉重抓（v1.51.0）。"""


# 證據檔名：內容 SHA-256 的前 16 碼＋副檔名（v1.51.0；以前 64 碼）。同內容只存一份
EVIDENCE_DIGEST_CHARS = 16
LIST_MEMORY_DAYS = 7           # 清單記憶用不滿幾天，到了就整份重讀：網站改舊公告時最多晚這麼久才看到
LIST_RECHECK_DAYS = 30         # 最近幾天的公告一定重讀，不沿用（晚上架的公告、剛改過的標題都在這段）


def evidence_name(raw, suffix):
    return digest(raw)[:EVIDENCE_DIGEST_CHARS] + suffix


def stamp():
    from _common import tw_now
    return tw_now().isoformat(timespec="seconds")


def digest(value):
    raw = value if isinstance(value, bytes) else json.dumps(value, ensure_ascii=False, sort_keys=True).encode("utf-8")
    return hashlib.sha256(raw).hexdigest()


def date(value, optional=True):
    text = re.sub(r"\s+", "", str(value or ""))
    if not text and optional:
        return ""
    match = re.fullmatch(r"(?:(?:中華)?民國)?\s*(\d{2,4})[-/.年]\s*(\d{1,2})[-/.月]\s*(\d{1,2})日?", text)
    if not match:
        # 官方資料也使用 YYYYMMDD / 民國 YYYMMDD。
        match = re.fullmatch(r"(\d{3,4})(\d{2})(\d{2})", text)
    if not match:
        raise SourceError("日期必須是 YYYY-MM-DD 或民國年月日：%s" % text)
    year, month, day = map(int, match.groups())
    if year < 1911:
        year += 1911
    try:
        return dt.date(year, month, day).isoformat()
    except ValueError as exc:
        raise SourceError("無效日期：%s" % text) from exc


def official_host(host):
    host = (host or "").lower()
    # v1.23.0：加銀行公會、壽險公會、產險公會（references/法規來源地圖.md 列的來源）。以前不認，公會自律規範
    # 判適用也給不了 7 分，錯誤訊息叫 AI 改給〔待確認適用〕，又被「適用不能用待確認適用」擋，兩條互卡
    return host.endswith(".gov.tw") or host in {
        "law.lia-roc.org.tw", "www.lia-roc.org.tw", "lia-roc.org.tw", "www.ciaa.org.tw", "ciaa.org.tw",
        "www.ba.org.tw", "ba.org.tw", "www.nlia.org.tw", "nlia.org.tw"}


def official(url):
    """可以自動讀的官方網址：官方網域而且是 https://（v1.51.0 起不收 http://：沒加密，內容中途可能被改）。
    http:// 的官方網址 fetch() 會先改成 https 再試，失敗就當讀不到。只看來源算不算官方（不連網）用 official_source。"""
    parsed = urllib.parse.urlsplit(str(url or ""))
    return parsed.scheme == "https" and official_host(parsed.hostname)


def official_source(url):
    """這條法規記的來源網址是不是官方網域（判 7 分以上、版本表用）：http:// 也算，只是不會拿它去連網。"""
    parsed = urllib.parse.urlsplit(str(url or ""))
    return parsed.scheme in ("https", "http") and official_host(parsed.hostname)


def https_url(url):
    """http:// 改成 https://（其他照舊）。"""
    parsed = urllib.parse.urlsplit(str(url or ""))
    if parsed.scheme == "http":
        return urllib.parse.urlunsplit(("https",) + tuple(parsed)[1:])
    return str(url or "")


# v1.58.0：標題看得出「整部改」：修正「某某辦法」後面沒接第幾條、部分條文（5/6 內控辦法全文修正就長這樣）；
# 法律的修正公告寫成「修正保險法條文」「制定某某條例」（全國法規新訊的寫法，沒有引號）
_MAJOR_TITLE_RE = re.compile(r"(?:修正|訂定|制定|廢止)「[^」]{2,60}(?:法|辦法|規則|準則|條例|標準|細則|要點|規範)」(?!第|部分|之|有關|附表|規定|、)"
                             r"|^(?:修正|增訂|制定|廢止|刪除)[^「」：:]{2,40}(?:法|條例)(?:條文)?$")
_QUERY_SUFFIX_RE = re.compile(r"\.(pdf|docx|xml|json|zip)(?:$|[&#])", re.I)
_LINK_DATE_RE = re.compile(r"(?<![\d.])(\d{2,3})[.．-](\d{1,2})[.．-](\d{1,2})(?![\d.])|(?<!\d)(1\d{2})(\d{2})(\d{2})(?!\d)")
_NOTICE_ID_RE = re.compile(r"(?:gazette\.nat\.gov\.tw|join\.gov\.tw)/.*?meta[iI]d[=/](\d+)")
EARLY_DAYS = 90             # 起日前幾天內的整部修正也列入；法規補入同一個範圍
_BUNDLE_LINK_RE = re.compile(r"下載附件|壓縮檔")     # 銀行公會每列的「下載附件（zip 壓縮檔）」：附件在公告頁一份一份抓
_GENERIC_LINK_TITLES = ("檔案下載", "下載", "下載檔案", "PDF", "pdf")
_NEXT_PAGE_LINKS = ("下一頁", "下頁", "Next", ">", "›", "»")     # 銀行公會的下一頁只有一個「>」
# 註記會算進內容指紋：不能寫起日（起日每天滾動，AI 會天天重判同一條）
EARLY_NOTE = "公告日在這一輪起日之前，但標題看來是整部修正、訂定或廢止：怕手冊還沒跟上，一併列入"


def major_title(title):
    """標題看來是整部法規修正、訂定、廢止（不是部分條文或函釋），草案不算。"""
    title = (title or "").strip()
    return "草案" not in title and bool(_MAJOR_TITLE_RE.search(title))


def notice_key(link):
    """同一則公告的鍵。金管會把預告連到 join.gov.tw/.../metaId/169252，全國法規新訊連到 gazette…metaid=169252：同一則。"""
    found = _NOTICE_ID_RE.search(link or "")
    return "公報:" + found.group(1) if found else link


def days_before(day, days):
    return (dt.date.fromisoformat(day) - dt.timedelta(days=days)).isoformat()


def coverage_problem(item):
    """這個來源有沒有真的沒抓齊。公告清單的狀態一律是「部分完成」（看不到網站沒列的東西），
    所以有讀滿起日、沒有失敗的（trouble=False）不算問題。舊的狀態檔沒有 trouble，照舊算。"""
    if item.get("status") == "完成":
        return False
    return not (item.get("kind") == "公告清單" and item.get("trouble") is False)


def title_wanted(source, title):
    """公告清單先看標題，再決定要不要打開（全國法規新訊半年 2,300 多筆，多半是別的部會）。
    title_always 的字優先：金管會自己發的一律要看，不管標題還有什麼字。"""
    title = title or ""
    if any(word in title for word in source.get("title_always") or ()):
        return True
    if any(word in title for word in source.get("title_exclude") or ()):
        return False
    wanted = source.get("title_keywords") or ()
    return not wanted or any(word in title for word in wanted)


def link_suffix(url):
    """連結的副檔名。銀行公會的附件網址長這樣：…/DownloadFile?intId=1&downName=.pdf，副檔名在查詢字串。"""
    parts = urllib.parse.urlsplit(url)
    suffix = Path(parts.path).suffix.lower()
    if suffix:
        return suffix
    found = _QUERY_SUFFIX_RE.search(parts.query)
    return "." + found.group(1).lower() if found else ""


def link_date(href):
    """檔名裡的日期（保代公會清單頁沒有日期欄）：114.10.23 某規範.pdf、某規範-備查版1130916.pdf。讀不出來回 ""。"""
    name = urllib.parse.unquote(Path(urllib.parse.urlsplit(href or "").path).stem)
    for found in _LINK_DATE_RE.finditer(name):
        parts = [p for p in found.groups() if p]
        if not 90 <= int(parts[0]) <= 199:      # 「10.1.1版」是版本號，不是民國 10 年
            continue
        try:
            return date("%s.%s.%s" % tuple(parts))
        except SourceError:
            continue
    return ""


def chinese_count(text):
    return len(re.findall(r"[\u4e00-\u9fff]", text or ""))


def foreign_text(text):
    """附件主要是外文（銀行公會把英文版也放在同一則公告）：中文很少、拉丁字母過半。
    太短的不算（可能只是封面）；數字表、字型壞掉的亂碼不是外文，不能當外文略過。"""
    text = re.sub(r"\s+", "", text or "")
    return (len(text) >= 500 and chinese_count(text) < len(text) * 0.05
            and len(re.findall(r"[A-Za-z]", text)) >= len(text) * 0.5)


def has_chinese_version(chinese, text):
    """這則公告的中文附件夠不夠當這份外文的中文版：中文至少 2,000 字，或至少有外文長度的三成。
    只有一張中文封面的不算，不然沒有中文版的外文全文會整份不見。"""
    return chinese >= min(2000, len(re.sub(r"\s+", "", text or "")) * 0.3)


def records_text(records):
    return "\n\n".join(str(r.get("new_text") or r.get("LawContent") or "") for r in records if isinstance(r, dict))


def row_title(row, label):
    """這一列的連結字只是「檔案下載」時，標題用這一列其他的字。"""
    words = [re.sub(r"\s+", " ", part).strip() for part in row.get("parts", [])]
    words = [word for word in words if word and word not in _GENERIC_LINK_TITLES and not re.fullmatch(r"\d+\.?", word)]
    return (words[0] if words else label).strip()


_DRAFT_DONE_RE = re.compile(r"同意備查|准予備查|准予核備|核定|核准|洽悉")


def draft_status(title):
    """公告標題的效力：有「草案」而且沒有「同意備查」「核定」這類已經定案的字，才是草案（v1.23.0）。
    「所報…修正草案一案，請依說明二辦理後同意備查」已經備查，以前被當草案：最高只能 5 分，也不記進版本表。"""
    title = title or ""
    return "草案" if "草案" in title and not _DRAFT_DONE_RE.search(title) else "待確認"


def _ipv4_first(address, timeout=None, source_address=None, *args, **kwargs):
    """連線先試 IPv4，IPv6 排後面而且只等幾秒（v1.11.0）。

    有些電腦的 IPv6 連不出去（實測連 law.fsc.gov.tw 的 IPv6 要等 21 秒才逾時），Python 預設先試 IPv6、
    等到逾時才換 IPv4，每抓一頁白等 20 秒、一輪體檢多等約 150 秒。台灣官方網站都有 IPv4。
    抓到的內容跟以前一模一樣，只是換連線順序。"""
    host, port = address
    infos = socket.getaddrinfo(host, port, 0, socket.SOCK_STREAM)
    infos.sort(key=lambda info: 0 if info[0] == socket.AF_INET else 1)
    real_timeout = timeout if isinstance(timeout, (int, float)) else None
    last = None
    for number, (family, kind, proto, _name, target) in enumerate(infos):
        sock = socket.socket(family, kind, proto)
        try:
            is_last = number == len(infos) - 1
            # 不是最後一個位址：最多等 5 秒就換下一個（IPv6 不通不要卡 20 秒）
            sock.settimeout(real_timeout if is_last or real_timeout is None else min(real_timeout, 5))
            if source_address:
                sock.bind(source_address)
            sock.connect(target)
            sock.settimeout(real_timeout)
            return sock
        except OSError as exc:
            last = exc
            sock.close()
    raise last or OSError("連不上 %s" % host)


class _HTTPConnection(http.client.HTTPConnection):
    def __init__(self, *args, **kwargs):
        http.client.HTTPConnection.__init__(self, *args, **kwargs)
        self._create_connection = _ipv4_first


class _HTTPSConnection(http.client.HTTPSConnection):
    def __init__(self, *args, **kwargs):
        http.client.HTTPSConnection.__init__(self, *args, **kwargs)
        self._create_connection = _ipv4_first


class _HTTPHandler(urllib.request.HTTPHandler):
    def http_open(self, req):
        return self.do_open(_HTTPConnection, req)


class _HTTPSHandler(urllib.request.HTTPSHandler):
    def https_open(self, req):
        return self.do_open(_HTTPSConnection, req, context=self._context)


_SSL_SHARED = []


def _ssl_context():
    """整個程式共用一個（v1.60.1）：建一次約 25 毫秒，一輪幾百次。每條連線的憑證、主機名稱照舊驗。"""
    if not _SSL_SHARED:
        _SSL_SHARED.append(_new_ssl_context())
    return _SSL_SHARED[0]


def _new_ssl_context():
    try:
        import truststore
        context = truststore.SSLContext(ssl.PROTOCOL_TLS_CLIENT)
    except ImportError:
        context = ssl.create_default_context()
    # 只放寬 RFC 5280 嚴格格式檢查：部分政府憑證缺 Subject Key Identifier。
    # 憑證鏈、到期與主機名稱仍照常驗證；不改其他驗證旗標。
    try:
        context.verify_flags &= ~getattr(ssl, "VERIFY_X509_STRICT", 0)
    except Exception:
        # 系統信任庫的 context 可能不支援讀寫 verify_flags。
        pass
    return context


def fetch(url):
    # 測試、離線環境：REG_NO_NETWORK=1 時不連網，來源記成失敗（不等於沒有修法）
    if os.environ.get("REG_NO_NETWORK") == "1":
        raise SourceError("這個環境設定不連網（REG_NO_NETWORK=1），沒有自動讀取：%s" % url)
    url = https_url(url)            # v1.51.0：http:// 一律改走 https；改了還是連不上就當讀不到
    if not official(url):
        raise SourceError("自動讀取只接受政府及已列入的公會來源（https://）：%s" % url)
    # 附件網址常帶中文檔名（…/使用手冊20171020.pdf）：urllib 只收 ASCII，以前直接 'ascii' codec 錯誤、附件讀不到
    url = urllib.parse.quote(url, safe=":/?&=%#+;,@!$'()*~[]")

    class OfficialRedirect(urllib.request.HTTPRedirectHandler):
        def redirect_request(self, req, fp, code, msg, headers, newurl):
            if not official(newurl):
                raise SourceError("來源轉址到未支援網域：%s" % newurl)
            return super().redirect_request(req, fp, code, msg, headers, newurl)

    request = urllib.request.Request(url, headers={"User-Agent": "reg-report/1.3.0 (legal-source-reader)"})
    context = _ssl_context()
    opener = urllib.request.build_opener(OfficialRedirect(), _HTTPHandler(), _HTTPSHandler(context=context))
    try:
        with opener.open(request, timeout=20) as response:
            raw = response.read(MAX_BYTES + 1)
    except (ssl.SSLCertVerificationError, urllib.error.URLError) as exc:
        if isinstance(exc, urllib.error.HTTPError):     # exc.reason 常是空的，以前印「官網讀取失敗：<none>」
            raise SourceError("官網讀取失敗：對方回 HTTP %d（網站暫時有問題時等一下再查）" % exc.code) from exc
        reason = exc.reason if isinstance(exc, urllib.error.URLError) else exc
        if isinstance(reason, ssl.SSLCertVerificationError):
            raise SourceError("官網憑證驗證失敗：%s；這不是法規查不到，請改用瀏覽器開官網核對，或把官方下載檔放進規範資料庫再查"
                              % (getattr(reason, "verify_message", None) or str(reason))) from exc
        raise SourceError("官網讀取失敗：%s" % reason) from exc
    if len(raw) > MAX_BYTES:
        raise SourceError("來源超過 40 MB，請下載後分檔匯入")
    return raw


_SITE_LINK_WORDS = ("使用手冊", "操作手冊", "網站導覽", "隱私權", "資訊安全政策", "政府網站資料開放", "無障礙", "常見問題")
_SITE_LINK_PATHS = ("/usemanual/", "/manual/", "/sitemap", "/privacy", "/accessibility")


def site_link(url, label=""):
    """公告頁上的網站共用連結（頁首頁尾的使用手冊、網站導覽、隱私權政策…），不是這一則公告的附件。"""
    path = urllib.parse.unquote(urllib.parse.urlsplit(url).path).lower()
    text = (label or "") + path
    return any(word in text for word in _SITE_LINK_WORDS) or any(part in path for part in _SITE_LINK_PATHS)


class Page(HTMLParser):
    """保留段落、表格列、連結；不把 script/style 當法規原文。"""
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.parts, self.links, self.rows = [], [], []
        self.ignore = 0
        self.anchor = None
        self.row = None

    def handle_starttag(self, tag, attrs):
        attrs = dict(attrs)
        if tag in ("script", "style"):
            self.ignore += 1
        if self.ignore:
            return
        if tag in ("p", "div", "br", "tr", "li", "h1", "h2", "h3"):
            self.parts.append("\n")
        if tag == "tr":
            self.row = {"parts": [], "links": []}
        if tag == "a":
            self.anchor = [attrs.get("href", ""), []]

    def handle_endtag(self, tag):
        if tag in ("script", "style"):
            self.ignore = max(0, self.ignore - 1)
            return
        if self.ignore:
            return
        if tag == "a" and self.anchor:
            link = (self.anchor[0], "".join(self.anchor[1]).strip())
            self.links.append(link)
            if self.row is not None:
                self.row["links"].append(link)
            self.anchor = None
        if tag == "tr" and self.row is not None:
            self.rows.append(self.row)
            self.row = None
        if tag in ("p", "div", "tr", "li"):
            self.parts.append("\n")

    def handle_data(self, text):
        if not self.ignore:
            self.parts.append(text)
            if self.anchor:
                self.anchor[1].append(text)
            if self.row is not None:
                self.row["parts"].append(text)

    @property
    def text(self):
        return "\n".join(line.strip() for line in "".join(self.parts).splitlines() if line.strip())


class MojPage(HTMLParser):
    """全國法規資料庫的 col-no／col-data 結構，不把選單與熱門詞當條文。"""
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.depth, self.active, self.parts = 0, {}, {}
        self.number, self.articles, self.name, self.in_name = "", [], "", False

    def handle_starttag(self, tag, attrs):
        attrs = dict(attrs)
        if tag == "a" and attrs.get("id") == "hlLawName":
            self.in_name = True
        if tag == "div":
            self.depth += 1
            classes = attrs.get("class", "").split()
            field = "number" if "col-no" in classes else "content" if "col-data" in classes else ""
            if field:
                self.active[field] = self.depth
                self.parts[field] = []
        if tag in ("br", "p", "li") and "content" in self.active:
            self.parts["content"].append("\n")

    def handle_endtag(self, tag):
        if tag == "a":
            self.in_name = False
        if tag == "div":
            for field in list(self.active):
                if self.active[field] == self.depth:
                    value = "".join(self.parts[field]).strip()
                    if field == "number":
                        self.number = value
                    elif self.number and "條" in self.number and value:
                        self.articles.append({"article_no": self.number, "new_text": value})
                    del self.active[field]
            self.depth = max(0, self.depth - 1)

    def handle_data(self, text):
        if self.in_name:
            self.name += text.strip()
        for field in self.active:
            self.parts[field].append(text)


def decode(raw):
    for encoding in ("utf-8-sig", "cp950"):
        try:
            return raw.decode(encoding)
        except UnicodeDecodeError:
            pass
    raise SourceError("資料不是 UTF-8 或 Big5，請轉碼後匯入")


def detect_format(raw, url, configured=""):
    if configured:
        return configured.lower()
    suffix = Path(urllib.parse.urlsplit(url).path).suffix.lower()
    if suffix == ".docx":
        return suffix
    if raw.startswith(b"PK\x03\x04"):
        return ".zip"
    if raw.startswith(b"%PDF"):
        return ".pdf"
    head = raw.lstrip(b"\xef\xbb\xbf \r\n\t")
    if head.startswith((b"{", b"[")):
        return ".json"
    if suffix in (".json", ".xml", ".zip", ".pdf"):
        return suffix
    if head.startswith(b"<?xml"):
        return ".xml"
    return ".html"


# 公告網頁上會一直變、跟法規內容無關的字（v1.8.1）：行政院公報資訊網「分享至：」前那一行純數字是瀏覽次數
# （昨天 119100、今天 120300），一變法規的指紋就跟著變、判過的答案全部對不上
_VOLATILE = [
    re.compile(r"\n\s*\d+\s*\n(?=\s*分享至)"),
    re.compile(r"(?:瀏覽人次|瀏覽次數|點閱次數|點閱人次|點閱數|瀏覽數|人氣)\s*[:：]?\s*[\d,，]+"),
]


def strip_volatile(text):
    """拿掉公告網頁上會一直變的數字（瀏覽、點閱次數）；其餘一字不動。"""
    for pattern in _VOLATILE:
        text = pattern.sub("\n" if pattern.pattern.startswith("\\n") else "", text)
    return text


def normalize(record, source, evidence):
    if not isinstance(record, dict):
        raise SourceError("每個法規事件必須是物件")
    name = str(record.get("law_name") or record.get("LawName") or "").strip()
    text = strip_volatile(str(record.get("new_text") or record.get("LawContent") or "")).strip()
    if not name or not text:
        raise SourceError("法規事件缺 law_name 或 new_text")
    out = {k: str(record.get(k) or "").strip() for k in
           ("article_no", "old_text", "source_url", "old_source_url", "effective_note", "version", "notes", "change_type")}
    out.update(law_name=name, new_text=text, event_date=date(record.get("event_date") or record.get("LawModifiedDate")),
               effective_date=date(record.get("effective_date") or record.get("LawEffectiveDate")),
               status=record.get("status") or "待確認", source_kind=source.get("kind", "檔案"),
               source_name=source.get("name", ""), retrieved_at=stamp(), evidence_path=evidence)
    if out["status"] not in STATUSES:
        raise SourceError("不支援的生效狀態：%s" % out["status"])
    if not out["source_url"]:
        out["source_url"] = source.get("official_url") or source.get("url") or ""
    # 不根據網址就宣稱文件的日期或現行效力已獲驗證。
    # v1.51.0：快照重讀時註記已經在了，不再接一次（不然每離線一輪 notes 多一段、指紋跟著變）
    out["notes"] = "；".join(filter(None, [out["notes"]] + [note for note in (
        "舊版缺少來源，差異待補" if out["old_text"] and not out["old_source_url"] else "",
        "缺少公布／修正日期" if not out["event_date"] else "") if note not in out["notes"]]))
    identity = {k: out[k] for k in ("law_name", "article_no", "event_date", "version", "old_text", "new_text", "source_url")}
    # v1.51.0：快照（上一輪存下來的事件）本來就有 id，照用。以前用去掉網站外框後的字重算，指紋全變、答案整輪重判
    saved_id = str(record.get("id") or "").strip()
    out["id"] = saved_id if re.fullmatch(r"L[0-9a-f]{20}", saved_id) else "L" + digest(identity)[:20]
    return out


def _official_law(record):
    from _common import tw_today
    raw_date = record.get("LawEffectiveDate") or record.get("生效日期") or ""
    note = str(record.get("LawEffectiveNote") or record.get("生效內容") or "")
    try:
        effective = date(raw_date)
    except SourceError:
        effective = ""
    abolished = str(record.get("LawAbandonNote") or record.get("廢止註記") or "").strip() not in ("", "False", "false", "0", "否")
    note = re.sub(r"\s+", "", note).strip("。．.")
    note = re.sub(r"^本(?:法|細則|規則|辦法|準則|標準|條例|要點)(?=自)", "", note)
    simple = not note or bool(re.fullmatch(r"自(?:公布日|發布日)施行", note))
    numerals = r"[0-9一二三四五六七八九零〇兩十百千]+"
    dated = re.fullmatch(r"自(西元|(?:(?:中華)?民國)?)(" + numerals + r")年(" + numerals +
                         r")月(" + numerals + r")日施行", note)
    if dated:
        from _common import cn_to_int

        def number(value):
            if "千" not in value:
                return cn_to_int(value)
            if value.count("千") != 1:
                return None
            thousands, rest = value.split("千")
            high = cn_to_int(thousands)
            low = cn_to_int(rest.lstrip("零〇")) if rest else 0
            return high * 1000 + low if high is not None and 1 <= high <= 9 and low is not None else None

        year, month, day = (number(value) for value in dated.group(2, 3, 4))
        try:
            if year is not None and month is not None and day is not None:
                parsed = (dt.date(year, month, day).isoformat() if dated.group(1) == "西元"
                          else date("%s%02d年%d月%d日" % (dated.group(1), year, month, day)))
                simple = parsed <= tw_today().isoformat()
        except (SourceError, ValueError):
            simple = False
    status = ("廢止" if abolished else "現行" if effective and effective <= tw_today().isoformat()
              and simple else "待確認")
    articles = record.get("LawArticles") or record.get("法規內容") or []
    if isinstance(articles, dict):
        articles = articles.get("條文") or articles.get("Articles") or []
    if isinstance(articles, dict):
        articles = [articles]
    for article in articles:
        if not isinstance(article, dict):
            continue
        content = article.get("ArticleContent") or article.get("條文內容")
        if content:
            yield {"law_name": record.get("LawName") or record.get("法規名稱"),
                   "article_no": article.get("ArticleNo") or article.get("條號", ""),
                   "new_text": content, "event_date": record.get("LawModifiedDate") or record.get("最新異動日期"),
                   "effective_date": effective,
                   "effective_note": record.get("LawEffectiveNote") or record.get("生效內容", ""),
                   "source_url": record.get("LawURL") or record.get("法規網址", ""),
                   "status": status,
                   "notes": "官方整編資料；整部法規修正日不代表本條有修正，須比對舊版確認"}


# 證據檔的中文欄名（v1.5.0 起 AI 寫證據檔用這一套，跟 AI 表一樣是中文）→ 程式內部用的鍵。英文鍵照樣收
_CHINESE_KEYS = {"法規名稱": "law_name", "條號": "article_no", "公布或修正日": "event_date", "施行日": "effective_date",
                 "施行說明": "effective_note", "效力": "status", "版本": "version", "舊條文": "old_text",
                 "新條文": "new_text", "官方來源": "source_url", "舊版來源": "old_source_url", "註記": "notes",
                 "異動性質": "change_type"}


def _english_keys(record):
    if not isinstance(record, dict):
        return record
    out = dict(record)
    for chinese, english in _CHINESE_KEYS.items():
        if chinese in out and english not in out:
            out[english] = out.pop(chinese)
    return out


def records_from_json(value):
    if isinstance(value, dict) and ("events" in value or "法規異動" in value):
        return [_english_keys(r) for r in value.get("events", value.get("法規異動")) or []]
    laws = value.get("Laws", value.get("法規", [])) if isinstance(value, dict) else value
    if isinstance(laws, dict):
        laws = [laws]
    if isinstance(laws, list):
        result = []
        for law in laws:
            if isinstance(law, dict) and ("LawArticles" in law or "法規內容" in law):
                result.extend(_official_law(law))
            else:
                result.append(law)
        return result
    raise SourceError("JSON 須有 events 或 Laws 陣列")


def _pdf_text_cache(raw):
    import batch
    return os.path.join(batch.cache_dir(), "法規追蹤", "PDF文字", digest(raw) + ".txt")


def _pdf_text(raw):
    """PDF 轉文字（v1.11.0 起照檔案指紋存在 memoization/法規追蹤/PDF文字/，同一個檔只轉一次：
    公告附件以前每一輪重轉 374 頁、約 40 秒）。"""
    path = _pdf_text_cache(raw)
    try:
        with io.open(path, encoding="utf-8") as f:
            return f.read()
    except OSError:
        pass
    state, text = _pymupdf_text(raw)
    if state != PDF_OK:
        try:
            text = _pypdf_text(raw)
        except PdfToolMissing:          # 只有 PyMuPDF：壞檔照壞檔算（要丟快取重抓），掃描檔照掃描檔算
            if state == PDF_BROKEN:
                raise BrokenFile("PDF 讀不出來（檔案壞了或不完整）") from None
            if state != PDF_EMPTY:
                raise
            text = ""
    try:
        os.makedirs(os.path.dirname(path), exist_ok=True)
        with io.open(path + ".tmp", "w", encoding="utf-8") as f:
            f.write(text)
        replace_file(path + ".tmp", path)
    except OSError:
        pass
    return text


PDF_OK, PDF_EMPTY, PDF_BROKEN, PDF_NO_TOOL = "讀到", "空的", "壞的", "沒裝"


class PdfToolMissing(SourceError):
    """兩種 PDF 工具都沒有。"""


def _pymupdf_text(raw):
    """PyMuPDF 讀 PDF（v1.60.4）：44 份實測 10.6 → 0.7 秒，標題不會抽兩次、條號不會被斷行切開。
    回傳 (狀態, 文字)，不是「讀到」就交給 pypdf。它會自己修壞檔：截斷或中段損毀的下載修好只剩一部分，
    修過、有警告的都不收，壞檔要丟掉快取重抓，不能當成完整的公告。"""
    try:
        import pymupdf
    except Exception:                   # 安裝壞掉不只丟 ImportError：一樣當沒裝
        return PDF_NO_TOOL, None
    try:
        pymupdf.TOOLS.mupdf_display_errors(False)
        pymupdf.TOOLS.reset_mupdf_warnings()
        with pymupdf.open(stream=raw, filetype="pdf") as document:
            text = "\n".join(page.get_text() for page in document)
            repaired = document.is_repaired
        warned = pymupdf.TOOLS.mupdf_warnings()
    except Exception:
        return PDF_BROKEN, None
    if repaired or warned:
        return PDF_BROKEN, None
    return (PDF_OK, text) if text.strip() else (PDF_EMPTY, "")


def _pypdf_text(raw):
    try:
        from pypdf import PdfReader
    except ImportError as exc:
        raise PdfToolMissing("PDF 需 pypdf；可改匯入已擷取文字及來源的 JSON／Word") from exc
    try:
        return "\n".join(p.extract_text() or "" for p in PdfReader(io.BytesIO(raw)).pages)
    except Exception as exc:
        # pypdf 的錯（PyPdfError、截斷的檔…）不是 ValueError，以前沒人接、整輪 traceback（v1.51.0）
        raise BrokenFile("PDF 讀不出來（%s：%s）" % (type(exc).__name__, str(exc)[:200])) from exc


def records_from_bytes(raw, suffix, source):
    suffix = suffix.lower()
    if suffix == ".zip":
        result = []
        try:
            archive = zipfile.ZipFile(io.BytesIO(raw))
        except zipfile.BadZipFile as exc:
            raise BrokenFile("ZIP 壞了讀不出來：%s" % exc) from exc
        with archive:
            total = 0
            for entry in archive.infolist():
                if Path(entry.filename).suffix.lower() not in (".xml", ".json"):
                    continue
                total += entry.file_size
                if total > MAX_BYTES * 5:
                    raise SourceError("ZIP 解壓資料過大，請分檔匯入")
                result.extend(records_from_bytes(archive.read(entry), Path(entry.filename).suffix, source))
        return result
    if suffix == ".json":
        return records_from_json(json.loads(decode(raw)))
    if suffix == ".xml":
        if b"<!DOCTYPE" in raw.upper() or b"<!ENTITY" in raw.upper():
            raise SourceError("不接受含外部實體的 XML")
        try:
            root = ET.fromstring(raw)
        except ET.ParseError as exc:
            raise BrokenFile("XML 壞了讀不出來：%s" % exc) from exc
        result = []
        for law in root.iter():
            fields = {c.tag.split("}")[-1]: "".join(c.itertext()).strip() for c in law}
            if not (fields.get("LawName") or fields.get("法規名稱")):
                continue
            articles = []
            for item in law.iter():
                bits = {c.tag.split("}")[-1]: "".join(c.itertext()).strip() for c in item}
                if "ArticleContent" in bits or "條文內容" in bits:
                    articles.append(bits)
            fields["LawArticles"] = articles
            result.extend(_official_law(fields))
        return result
    if suffix in (".html", ".htm"):
        content = decode(raw)
        page = Page()
        page.feed(content)
        text = page.text
        # 只擷取有明確欄位標籤的日期；不把頁尾更新時間當修法日期。
        if not source.get("event_date"):
            found = re.search(r"(?:公發布|發布|修正|公布|廢止)日期[：:\s|]*((?:(?:中華)?民國)?\s*\d{2,4}\s*[./年-]\s*\d{1,2}\s*[./月-]\s*\d{1,2}\s*日?)", text)
            if found:
                source = dict(source, event_date=date(found.group(1)))
        moj = MojPage()
        moj.feed(content)
        if moj.name and moj.articles:
            if source.get("law_name") and source["law_name"] != moj.name:
                raise SourceError("指定法規名稱與官網不符：%s／%s" % (source["law_name"], moj.name))
            abolished = bool(re.search(r"廢止日期[：:]", text))
            return [dict(article, law_name=moj.name, event_date=source.get("event_date", ""),
                         status="廢止" if abolished else source.get("status", "待確認"),
                         source_url=source.get("official_url") or source.get("url", ""),
                         notes="官網條文結構擷取；整部修正日不代表本條修正，施行與歷史版本須核對") for article in moj.articles]
    elif suffix == ".pdf":
        text = _pdf_text(raw)
        if len(text.strip()) < 20:
            raise SourceError("PDF 無可擷取文字，請由 AI／OCR 讀取後匯入證據 JSON；不可視為空法規")
    elif suffix == ".docx":
        # 使用暫存檔，既有讀檔器處理追蹤修訂與表格。
        import tempfile
        from _common import read_paragraphs
        with tempfile.TemporaryDirectory(prefix="law-document-") as temp:
            path = Path(temp) / "法規.docx"
            path.write_bytes(raw)
            text = "\n".join(read_paragraphs(str(path)))
    elif suffix in (".txt", ".md"):
        text = decode(raw)
    else:
        raise SourceError("不支援的法規資料格式：%s" % suffix)
    return [{"law_name": source.get("law_name") or source.get("name"), "new_text": text,
             "event_date": source.get("event_date", ""), "status": source.get("status", "待確認"),
             "effective_date": source.get("effective_date", ""), "effective_note": source.get("effective_note", ""),
             "source_url": source.get("official_url") or source.get("url", ""),
             "notes": "整份來源文件，需 AI 核對正文、附件與適用條件；未自動推定修正日期"}]


MCP_SWITCH = "REG_ALLOW_MCP"


def _require_mcp_allowed():
    """MCP 來源會執行 法規追蹤.json 寫的程式（mcp.command、mcp.python），這個檔 AI 寫得到：
    只有使用者自己設環境變數才啟動。本機請求只能帶參數，變不成環境變數。"""
    if os.environ.get(MCP_SWITCH) != "1":
        raise SourceError("這個來源沒有查（不代表沒有修法）：MCP 會執行 法規追蹤.json 裡寫的程式，這個檔 AI 也改得到，所以預設不啟動。"
                          "使用者確認裡面的程式可信之後，自己開命令列視窗先打 set %s=1，再從同一個視窗跑工作區裡的 執行下一步.cmd。"
                          "隔離區做不到這件事，AI 也不能代開" % MCP_SWITCH)


def mcp_call(config, tool, arguments):
    """獨立 Python 環境跑 MCP SDK，主程式不依賴 MCP。沒有 shell 字串拼接。"""
    _require_mcp_allowed()
    python = config.get("python") or sys.executable
    command = config.get("command")
    if not command or not isinstance(command, list) or not all(isinstance(x, str) for x in command):
        raise SourceError("未設定 MCP command 陣列，改用其他來源")
    payload = {"command": command, "tool": tool, "arguments": arguments}
    worker = str(Path(__file__).with_name("law_mcp_worker.py"))
    result = subprocess.run([python, "-B", "-X", "utf8", worker], input=json.dumps(payload, ensure_ascii=False),
                            text=True, encoding="utf-8", capture_output=True, timeout=90)
    if result.returncode:
        raise SourceError("MCP 無法執行：" + result.stderr[-800:])
    value = json.loads(result.stdout)
    if not isinstance(value, dict) or value.get("error") or value.get("isError") or value.get("success") is False:
        raise SourceError("MCP 查詢失敗：%s" % str(value)[:800])
    return value


class MCPBridge:
    """同一來源沿用一個 MCP session，避免每查一條就重啟伺服器。"""
    def __init__(self, config):
        self.config, self.process, self.lines = config, None, queue.Queue()

    def call(self, config, tool, arguments):
        _require_mcp_allowed()
        if self.process is None:
            command = self.config.get("command")
            if not isinstance(command, list) or not command or not all(isinstance(x, str) for x in command):
                raise SourceError("未設定 MCP command 陣列，改用其他來源")
            python = self.config.get("python") or sys.executable
            if os.path.normcase(os.path.abspath(python)) == os.path.normcase(os.path.abspath(sys.executable)):
                if importlib.util.find_spec("mcp") is None:
                    raise SourceError("目前 Python 未安裝 MCP SDK，直接改用其他來源；不自動安裝")
            self.process = subprocess.Popen([python, "-B", "-X", "utf8",
                str(Path(__file__).with_name("law_mcp_worker.py")), "--session"], stdin=subprocess.PIPE,
                stdout=subprocess.PIPE, stderr=subprocess.DEVNULL, text=True, encoding="utf-8")
            process = self.process
            def read():
                try:
                    for line in process.stdout:
                        self.lines.put(line)
                except (OSError, ValueError):
                    pass
                finally:
                    self.lines.put(None)
            threading.Thread(target=read, daemon=True).start()
            process.stdin.write(json.dumps({"command": command}) + "\n")
            process.stdin.flush()
        self.process.stdin.write(json.dumps({"tool": tool, "arguments": arguments}, ensure_ascii=False) + "\n")
        self.process.stdin.flush()
        try:
            line = self.lines.get(timeout=90)
        except queue.Empty as exc:
            raise SourceError("MCP 查詢逾時，改用其他來源") from exc
        if line is None:
            raise SourceError("MCP 程序已結束（請檢查 SDK、環境與啟動參數），改用其他來源")
        value = json.loads(line)
        if not isinstance(value, dict) or value.get("error") or value.get("isError") or value.get("success") is False:
            raise SourceError("MCP 查詢失敗：%s" % str(value)[:800])
        return value

    def close(self):
        if self.process is not None:
            try:
                self.process.stdin.close()
                self.process.wait(timeout=10)
            except (OSError, subprocess.TimeoutExpired):
                self.process.terminate()
                try:
                    self.process.wait(timeout=5)
                except subprocess.TimeoutExpired:
                    self.process.kill()
                    self.process.wait(timeout=5)
            finally:
                self.process.stdout.close()


def cached_fetcher(fetch_fn, folder):
    """照網址把抓到的內容存起來，下次同一個網址直接讀檔（v1.8.0）。只給公告內文與附件用：
    官方公告發布後內容不會變；清單頁會有新公告，不能用。抓失敗的不存（下次再試）。"""
    import json as _json
    index_path = os.path.join(folder, "索引.json")

    def load_index():
        try:
            with open(index_path, encoding="utf-8") as f:
                return _json.load(f)
        except (OSError, ValueError):
            return {}

    def fetch_cached(url):
        index = load_index()
        name = index.get(url)
        if name and os.path.isfile(os.path.join(folder, name)):
            with open(os.path.join(folder, name), "rb") as f:
                return f.read()
        raw = fetch_fn(url)
        os.makedirs(folder, exist_ok=True)
        name = digest(url.encode("utf-8"))[:32] + ".bin"
        with open(os.path.join(folder, name), "wb") as f:
            f.write(raw)
        index[url] = name
        with open(index_path + ".tmp", "w", encoding="utf-8") as f:
            _json.dump(index, f, ensure_ascii=False)
        replace_file(index_path + ".tmp", index_path)
        return raw

    def discard(url):
        """這個網址快取的那一份解析不了（壞檔、截斷的下載）：刪掉，下一輪重抓（v1.51.0）。回傳有沒有刪到。"""
        index = load_index()
        name = index.pop(url, None)
        if not name:
            return False
        try:
            os.remove(os.path.join(folder, name))
        except OSError:
            pass
        try:
            with open(index_path + ".tmp", "w", encoding="utf-8") as f:
                _json.dump(index, f, ensure_ascii=False)
            replace_file(index_path + ".tmp", index_path)
        except OSError:
            pass
        return True
    fetch_cached.discard = discard
    return fetch_cached


def row_day(row, source):
    """清單這一列的公告日；看不出來回 ""。"""
    found = re.search(r"\b\d{2,4}[./-]\d{1,2}[./-]\d{1,2}\b", " ".join(row["parts"]))
    if found:
        return date(found.group())
    if source.get("date_in_link"):
        return next(filter(None, (link_date(href) for href, _title in row["links"])), "")
    return ""


def row_links(row, source, base, early):
    """這一列要看的連結：(標題, 完整網址, 標題在範圍內)。只判斷，不動任何狀態。"""
    for href, title in row["links"]:
        if not title or href.startswith(("#", "javascript:")) or _BUNDLE_LINK_RE.search(title):
            continue
        if title.strip() in _GENERIC_LINK_TITLES:
            title = row_title(row, title)
        wanted = title_wanted(source, title)
        if wanted and early and not major_title(title):
            continue
        yield title, urllib.parse.urljoin(base, href), wanted


def _row_key(row):
    return json.dumps([row["parts"], [link[0] for link in row["links"]]], ensure_ascii=False)


def _list_row_ok(row):
    return (isinstance(row["day"], str) and isinstance(row["base"], str) and isinstance(row["parts"], list)
            and all(isinstance(p, str) for p in row["parts"]) and isinstance(row["links"], list)
            and all(len(link) == 2 and all(isinstance(x, str) for x in link) for link in row["links"]))


def read_list_memory(path, url):
    """上次讀清單留下的（v1.60.1）。壞掉、沒有都當沒有：多讀幾頁而已。"""
    try:
        with open(path, encoding="utf-8") as f:
            entry = json.load(f).get(url)
        rows = entry["rows"]
        good = (isinstance(entry["完整讀取日"], str) and isinstance(entry["涵蓋起日"], str)
                and isinstance(rows, list) and all(_list_row_ok(r) for r in rows))
        return entry if good else None
    except (OSError, ValueError, AttributeError, KeyError, TypeError):
        return None


def write_list_memory(path, url, entry):
    try:
        try:
            with open(path, encoding="utf-8") as f:
                table = json.load(f)
            table = table if isinstance(table, dict) else {}
        except (OSError, ValueError):
            table = {}
        table[url] = entry
        os.makedirs(os.path.dirname(path), exist_ok=True)
        with open(path + ".tmp", "w", encoding="utf-8") as f:
            json.dump(table, f, ensure_ascii=False)
        replace_file(path + ".tmp", path)
    except OSError:
        pass


def list_memory_usable(entry, scan_since, today):
    """這份清單還能用嗎：不能太舊，也要涵蓋到這次要讀的起日。"""
    try:
        age = (dt.date.fromisoformat(today) - dt.date.fromisoformat(entry["完整讀取日"])).days
    except (ValueError, TypeError):
        return False
    return 0 <= age < LIST_MEMORY_DAYS and entry["涵蓋起日"] <= scan_since


def list_rest(entry, rows, recheck_from, read):
    """這一頁整頁都讀過、也都不是最近的公告：回傳記憶裡這一輪還沒讀到的列。否則回 None，要繼續往下讀。
    不用「排在這頁後面」來切：網站同一天的列可能換順序，切位置會漏掉換過去的列。"""
    days = [row["day"] for row in rows]
    if not days or max(days) >= recheck_from:
        return None
    known = set(_row_key(row) for row in entry["rows"])
    if any(_row_key(row) not in known for row in rows):
        return None
    seen = set(_row_key(row) for row in read)
    return [row for row in entry["rows"] if _row_key(row) not in seen]


def _describe(exc):
    """失敗原因：自己判定的「不收」只寫原因；程式錯誤連類型一起寫（看得出是壞檔還是程式問題）。"""
    return str(exc) if isinstance(exc, SourceError) else "%s：%s" % (type(exc).__name__, exc)


def _discard_broken(fetcher, url, exc):
    """快取裡那一份是壞檔就丟掉（下一輪重抓）；我們自己認定的「不收」（掃描 PDF 沒有文字、格式不支援）不是壞檔，留著。"""
    discard = getattr(fetcher, "discard", None)
    if discard and (isinstance(exc, BrokenFile) or not isinstance(exc, SourceError)):
        try:
            discard(url)
        except OSError:
            pass


def listed_range_text(since, earliest, latest):
    """公告清單實際讀到的公告日範圍，寫給承辦看。起日比讀到的最早一天早：明白寫出哪一段沒讀到。"""
    if not earliest:
        return "清單上沒有讀到任何公告日期，整段期間都要另外補查"
    text = "清單實際讀到的公告日 %s～%s" % (earliest, latest)
    if since and since < earliest:
        last_missing = (dt.date.fromisoformat(earliest) - dt.timedelta(days=1)).isoformat()
        text += "，%s～%s 這段沒讀到，不代表沒有修法，要另外補查" % (since, last_missing)
    return text


def wider_list_covers(coverage, wide_name, wide_from):
    """v1.58.0：這個清單沒讀到的那段，別的清單（全國法規新訊）讀到了：不再喊「要另外補查」。回傳有沒有改。"""
    since, earliest, latest = coverage.get("since", ""), coverage.get("listed_from", ""), coverage.get("listed_to", "")
    if not (wide_from and earliest and since < earliest and wide_from <= since):
        return False
    old = listed_range_text(since, earliest, latest)
    new = old.replace("，不代表沒有修法，要另外補查", "；這段的令、公告由「%s」的清單涵蓋，函不在其中，要另外補查" % wide_name)
    if old not in coverage.get("detail", ""):
        return False
    coverage["detail"] = coverage["detail"].replace(old, new)
    coverage["gap_covered_by"] = wide_name
    return True


def _within(path, root):
    path, root = os.path.normcase(str(path)), os.path.normcase(str(root))
    return path == root or path.startswith(root.rstrip("\\/") + os.sep)


def local_source_file(base, value, extra_roots=()):
    """檔案、快照來源的實際位置。value 來自 法規追蹤.json、來源紀錄.json（AI 寫得到），讀到的內容會進倉庫送 AI，
    所以解析後一定要在 base 或 extra_roots（呼叫端給的，來源 JSON 改不到）裡面。
    先只看字面再碰檔案系統：網路路徑一解析就連到那台主機，Windows 還會自動送登入資訊。"""
    if not isinstance(value, str) or not value.strip() or any(c in value for c in "\x00\r\n"):
        raise SourceError("來源的 path 要是一個檔案路徑：%r" % (value,))
    roots = [str(base)] + [str(root) for root in extra_roots]
    refused = SourceError("來源只能讀 匯入/ 裡的檔，這個路徑跑到外面了：%s" % value[:300])
    target = os.path.abspath(os.path.join(str(base), value))
    if not any(_within(target, os.path.abspath(root)) for root in roots):
        raise refused
    path = Path(target).resolve()          # 連到外面的符號連結、junction 在這裡現形
    if not any(_within(path, Path(root).resolve()) for root in roots):
        raise refused
    return path


def collect(source, base, evidence_dir, since, until, fetcher=None, caller=None, item_fetcher=None, evidence_rel=None,
            extra_roots=(), shared_links=None, progress=None, list_memory=None):
    """回傳 events、coverage；每個來源獨立失敗。缺漏一律記錄，不回假成功。
    item_fetcher：公告清單裡每一則公告內文與附件用的抓法（v1.8.0 給快取用；清單頁照樣用 fetcher 每次重抓）。
    evidence_rel：證據檔存好之後，事件要記的相對路徑怎麼算（函式，收 Path 回字串）；沒給就是舊的「證據/<檔名>」。
    extra_roots：檔案來源除了 base 還讀得到的資料夾（見 local_source_file）。
    v1.51.0：一則公告或附件壞掉（pypdf 錯、ZIP／XML 壞檔）只記在 failures，其他公告照抓；壞檔的快取丟掉。
    shared_links：這一輪前面的來源已經抓過的公告（notice_key，v1.58.0）。金管會和全國法規新訊連到同一則公報，只算一次。
    progress：清單頁數多的來源，每 50 頁報一次進度（函式，收一句話）。
    list_memory：wide 來源記清單讀到哪裡的檔案路徑（v1.60.1）。清單新的在前：讀到整頁都讀過、也不是最近的公告就停，
                 後面照上次記的列跑一樣的判斷。不是跳過，那些列照舊算進查詢範圍；太舊、不夠遠就整份重讀。

    公告清單的來源可以多寫（v1.58.0）：
      title_keywords／title_exclude／title_always  先看標題：含 always 的一定要；含 exclude 的不要；
                                     有列 keywords 的要含其中一個。不合的不打開
      newest_first                   清單新的在前：整頁都早於要讀的起日就停
      major_lookback_days            起日前幾天內、標題看來是整部修正／訂定／廢止的也列入
      date_in_link                   清單沒有日期欄，日期在連結的檔名裡
      wide                           這份清單涵蓋金管會清單的令、公告（law_impact 用）。頁數多，清單頁不存證據
                                     （每輪新增一筆全部位移，存了只會撐大倉庫；匯入也不看清單頁）
    檔案來源可以多寫 early_days（法規補入用）：起日前幾天內的也收，註記同 major_lookback_days。"""
    bridge = MCPBridge(source.get("mcp", {})) if source.get("kind") == "MCP" and caller is None else None
    fetcher, caller = fetcher or fetch, caller or (bridge.call if bridge else mcp_call)
    item_fetcher = item_fetcher or fetcher
    name, kind = source.get("name", "未命名來源"), source.get("kind", "檔案")
    coverage = {"name": name, "kind": kind, "status": "待查", "detail": "", "since": since, "until": until,
                "checked_at": stamp(), "count": 0, "evidence": []}
    events = []
    listed_days = []         # 公告清單每一列的公告日（不管在不在查詢期間）：算實際讀到最早、最晚哪一天

    def note_listed():
        """公告清單實際讀到的範圍記進來源狀態，回傳給人看的那一句。"""
        coverage.update(listed_from=min(listed_days, default=""), listed_to=max(listed_days, default=""))
        return listed_range_text(since, coverage["listed_from"], coverage["listed_to"])

    rel_of = evidence_rel or (lambda p: "證據/" + p.name)
    foreign_skipped = []

    def save(raw, suffix):
        path = Path(evidence_dir) / evidence_name(raw, suffix)
        path.parent.mkdir(parents=True, exist_ok=True)
        if not path.is_file() or path.stat().st_size != len(raw):      # 同內容只存一份
            path.write_bytes(raw)
        rel = rel_of(path)
        coverage["evidence"].append({"path": rel, "sha256": digest(raw)})
        return rel

    early_from = days_before(since, int(source["early_days"])) if source.get("early_days") else ""

    def save_document(raw, suffix, records, url):
        """公告的 PDF、Word 留轉出來的文字，不留原檔（v1.58.1）：PDF 壓不小，一輪 30 MB 全進隔離區倉庫，上限只有 44 MB；
        檢查、AI 看的都是文字。原檔照來源網址重抓得到，檔頭記指紋可以核對。轉不出文字的照舊留原檔。"""
        text = records_text(records)
        if suffix not in (".pdf", ".docx") or not text.strip():
            return save(raw, suffix)
        head = "來源網址：%s\n原檔 SHA256：%s\n（留的是程式轉出的文字；原檔照來源網址取得）\n\n" % (url, digest(raw))
        return save((head + text).encode("utf-8"), ".txt")

    def read_document(raw, suffix, subsource):
        """掃描檔轉不出字時也要留原檔：失敗訊息叫 AI／OCR 去讀的就是這份。壞掉的檔另外處理（快取會丟掉）。"""
        try:
            return records_from_bytes(raw, suffix, subsource)
        except BrokenFile:
            raise
        except SourceError:
            save(raw, suffix)
            raise

    def accept(records, evidence, early=False):
        for record in records:
            item = normalize(record, source, evidence)
            names = source.get("law_names", [])
            keywords = source.get("keywords", [])
            if (names and item["law_name"] not in names) or (keywords and not any(k in item["law_name"] for k in keywords)):
                coverage["filtered_count"] = coverage.get("filtered_count", 0) + 1
                continue
            if early or (early_from and item["event_date"] and early_from <= item["event_date"] < since
                         and not source.get("baseline")):
                item["notes"] = "；".join(filter(None, [item["notes"], EARLY_NOTE]))
                events.append(item)
            elif not item["event_date"] or since <= item["event_date"] <= until or source.get("baseline"):
                events.append(item)

    try:
        for key in ("keywords", "law_names", "title_keywords", "title_exclude", "title_always"):
            if key in source and (not isinstance(source[key], list) or not all(isinstance(x, str) for x in source[key])):
                raise SourceError("來源的 %s 須為字串陣列" % key)
        if kind == "MCP":
            config = source.get("mcp", {})
            listed = []
            max_pages = max(1, int(source.get("max_pages", 20)))
            for offset in range(0, max_pages * 50, 50):
                response = caller(config, "search_regulations", {"keyword": source.get("keyword", ""),
                                  "amended_since": "" if source.get("baseline") else since,
                                  "category": source.get("category", ""), "offset": offset})
                save(json.dumps(response, ensure_ascii=False).encode("utf-8"), ".json")
                rows = response.get("results", response.get("regulations", []))
                if not isinstance(rows, list):
                    raise SourceError("MCP 法規清單格式不相容")
                listed.extend(rows)
                if not response.get("has_more") and len(rows) < 50:
                    break
            else:
                raise SourceError("MCP 清單超過頁數上限；請縮小期間，已取得資料保留於證據")
            law_errors = []
            for row in listed:
                try:
                    law_name = row.get("name") or row.get("law_name") or row.get("LawName")
                    pcode = row.get("pcode", "")
                    if not law_name and not pcode:
                        raise SourceError("MCP 清單缺法規名稱／代碼")
                    outline = caller(config, "query_regulation", {"law_name": law_name or "", "pcode": pcode})
                    save(json.dumps(outline, ensure_ascii=False).encode("utf-8"), ".json")
                    end = str(outline.get("last_article") or "10000")
                    start = str(outline.get("first_article") or "1")
                    visited = set()
                    while True:
                        if start in visited:
                            raise SourceError("MCP 條文分頁沒有前進；請補查")
                        visited.add(start)
                        block = caller(config, "query_regulation", {"law_name": law_name or "", "pcode": pcode,
                                                                   "article_no": "%s~%s" % (start, end)})
                        evidence = save(json.dumps(block, ensure_ascii=False).encode("utf-8"), ".json")
                        law = block.get("law") or {}
                        articles = block.get("articles") or []
                        if not articles:
                            raise SourceError("MCP 未回傳條文，不能視為沒有異動")
                        for article in articles:
                            number = str(article.get("article_no") or article.get("number") or article.get("no", ""))
                            record = {"law_name": law_name or law.get("name"), "article_no": number,
                                     "new_text": article.get("content") or article.get("text"),
                                     "event_date": law.get("last_amended") or row.get("last_amended"),
                                     "effective_date": law.get("effective_date", ""), "effective_note": law.get("effective_note", ""),
                                     "source_url": block.get("source_url") or law.get("url") or
                                         ("https://law.moj.gov.tw/LawClass/LawAll.aspx?pcode=" + pcode if pcode else ""),
                                     "notes": "整部修正日不代表本條修正；施行狀態須 AI 核對"}
                            # 上游僅在查單條時回 article_history，不能把區間查詢誤當有完整歷史。
                            try:
                                history_result = caller(config, "query_regulation", {"law_name": law_name or "", "pcode": pcode,
                                                                                    "article_no": number, "include_history": True})
                            except (OSError, ValueError, subprocess.SubprocessError) as exc:
                                record["notes"] += "；歷史查詢失敗：%s" % exc
                                accept([record], evidence)
                                law_errors.append("%s 第%s條歷史待補" % (law_name, number))
                                continue
                            history_evidence = save(json.dumps(history_result, ensure_ascii=False).encode("utf-8"), ".json")
                            history = history_result.get("article_history") or {}
                            revisions = history.get("revisions", []) if history.get("available") else []
                            if history.get("partial") or history.get("failed_versions") or not history.get("available"):
                                record["notes"] += "；歷史版本缺漏，已取得內容仍保留，不能宣稱差異完整"
                            if source.get("baseline") or not revisions:
                                accept([record], evidence)
                            previous = None
                            for revision in revisions:
                                day = date(revision.get("lnndate") or revision.get("date"))
                                if day and since <= day <= until:
                                    item = dict(record, new_text=revision.get("content") or "（刪除）", event_date=day,
                                                change_type=revision.get("action", ""),
                                                version=day, source_url=history.get("source_url") or record["source_url"],
                                                old_text=(previous or {}).get("content") or "",
                                                old_source_url=history.get("source_url", "") if previous else "")
                                    accept([item], history_evidence)
                                previous = revision
                        if not block.get("has_more"):
                            break
                        next_no = re.search(r"其餘從第\s*([0-9-]+)\s*條", block.get("note", ""))
                        if not next_no:
                            raise SourceError("MCP 有下一批但缺少續查條號，請補查；不可直接加50以免漏掉之條")
                        start = next_no.group(1)
                except (OSError, ValueError, KeyError, TypeError, subprocess.SubprocessError) as exc:
                    law_errors.append("%s：%s" % (row.get("law_name") or row.get("name") or row.get("pcode"), exc))
            coverage.update(status="部分完成", detail="已查 MCP 清單及條文；日期資料可能有更新延遲，歷史與公告須交叉核對。" + "；".join(law_errors))
        elif kind == "公告清單":
            url = source["url"]
            matched, pages, seen_links, failures = 0, set(), set(), []
            limit = max(1, int(source.get("max_pages", 30)))
            ended = ""
            lookback = max(0, int(source.get("major_lookback_days", 0)))
            scan_since = days_before(since, lookback) if lookback else since
            off_topic, repeated, early_count, undated = 0, 0, 0, []
            read_to_end = False
            today = stamp()[:10]
            remember = bool(list_memory and source.get("wide") and source.get("newest_first")
                            and not source.get("date_in_link"))
            old_list = read_list_memory(list_memory, url) if remember else None
            if old_list and not list_memory_usable(old_list, scan_since, today):
                old_list = None
            recheck_from = days_before(today, LIST_RECHECK_DAYS)
            first_url, kept_rows, list_done, reused, odd_page = url, [], False, None, False

            def read_rows(rows, base):
                """照一頁清單逐列處理，回傳這一頁有日期的列。"""
                nonlocal matched, off_topic, repeated, early_count
                dated = []
                for row in rows:
                    day = row_day(row, source)
                    if not day:
                        if source.get("date_in_link") and row["links"]:
                            undated.append(row_title(row, row["links"][0][1]))
                        continue
                    listed_days.append(day)
                    row_base = row.get("base") or base       # 記憶裡的列：當時那一頁的網址
                    dated.append(dict(row, day=day, base=row_base))
                    if not scan_since <= day <= until:
                        continue
                    early = day < since
                    for title, link, wanted in row_links(row, source, row_base, early):
                        if not wanted:
                            off_topic += 1
                            continue
                        if link in seen_links:
                            continue
                        seen_links.add(link)
                        if shared_links is not None and notice_key(link) in shared_links:
                            repeated += 1
                            continue
                        try:
                            item_raw = item_fetcher(link)
                            suffix = link_suffix(link)
                            suffix = suffix if suffix in (".pdf", ".docx", ".xml", ".json") else ".html"
                            subsource = dict(source, name=title, law_name=title, url=link, event_date=day,
                                             status=draft_status(title))
                            item_records = read_document(item_raw, suffix, subsource)
                            accept(item_records, save_document(item_raw, suffix, item_records, link), early)
                            matched += 1
                            early_count += 1 if early else 0
                            if shared_links is not None:
                                shared_links.add(notice_key(link))
                            if suffix == ".html":
                                details = Page()
                                details.feed(decode(item_raw))
                                chinese, foreign = 0, []
                                for attachment, label in details.links:
                                    attachment = urllib.parse.urljoin(link, attachment)
                                    ext = link_suffix(attachment)
                                    if (ext not in (".pdf", ".docx", ".xml", ".json", ".zip") or attachment in seen_links
                                            or site_link(attachment, label)):
                                        continue
                                    seen_links.add(attachment)
                                    try:
                                        blob = item_fetcher(attachment)
                                        sub = dict(subsource, name=title + "：" + label, url=attachment)
                                        records = read_document(blob, ext, sub)
                                        if foreign_text(records_text(records)):
                                            foreign.append((blob, ext, records, attachment, label))
                                            continue
                                        chinese = max(chinese, chinese_count(records_text(records)))
                                        accept(records, save_document(blob, ext, records, attachment), early)
                                    except Exception as exc:
                                        failures.append("附件 %s：%s" % (attachment, _describe(exc)))
                                        _discard_broken(item_fetcher, attachment, exc)
                                for blob, ext, records, attachment, label in foreign:
                                    if has_chinese_version(chinese, records_text(records)):
                                        foreign_skipped.append(label)   # 有中文版：內容一樣，不用再讀一次
                                    else:
                                        accept(records, save_document(blob, ext, records, attachment), early)
                        except Exception as exc:
                            failures.append("公告 %s：%s" % (link, _describe(exc)))
                            _discard_broken(item_fetcher, link, exc)
                return dated

            while url:
                if url in pages:
                    # 下一頁連回讀過的頁面：網站的清單到底了，不是漏讀
                    ended = "清單已讀到最後一頁（下一頁連回讀過的頁面）；"
                    read_to_end = list_done = True
                    break
                if len(pages) >= limit:
                    failures.append("清單讀到頁數上限（%d 頁），後面還有公告沒讀，須補查" % limit)
                    break
                pages.add(url)
                try:
                    raw = fetcher(url)
                except Exception:           # 連著讀上百頁難免一頁暫時失敗：再試一次，不然後面全部沒讀
                    raw = fetcher(url)
                if not source.get("wide"):
                    save(raw, ".html")
                if progress and len(pages) % 50 == 0:
                    progress("已讀 %d 頁，讀到 %s" % (len(pages), min(listed_days, default="（還沒有日期）")))
                page = Page()
                page.feed(decode(raw))
                dated = read_rows(page.rows, url)
                page_days = [row["day"] for row in dated]
                kept_rows += dated
                odd_page = odd_page or not dated      # 沒有一列有日期：可能是維護頁，這一輪不記
                if source.get("newest_first") and page_days and max(page_days) < scan_since:
                    ended = "清單已讀到起日之前；"
                    list_done = True
                    break
                rest = list_rest(old_list, dated, recheck_from, kept_rows) if old_list else None
                if rest is not None:
                    read_rows(rest, url)
                    kept_rows += rest
                    reused, list_done = len(rest), True
                    read_to_end = bool(old_list.get("讀到底"))
                    ended = "清單已讀到起日之前；" if not read_to_end else "清單已讀到最後一頁；"
                    break
                next_links = [href for href, title in page.links if re.sub(r"\s", "", title) in _NEXT_PAGE_LINKS
                              and not href.startswith(("#", "javascript:"))]
                url = urllib.parse.urljoin(url, next_links[0]) if next_links else ""
                read_to_end = not url
            coverage["read_to_end"] = read_to_end
            if reused:
                ended += "其中 %d 列沿用 %s 整份讀過的清單（新公告和最近 %d 天都重讀）；" % (reused, old_list["完整讀取日"], LIST_RECHECK_DAYS)
            if remember and kept_rows and (list_done or read_to_end) and not odd_page:
                full = reused is None           # 讀到底的清單沒有更早的列，涵蓋到任何起日
                write_list_memory(list_memory, first_url, {
                    "完整讀取日": today if full else old_list["完整讀取日"], "讀到底": read_to_end,
                    "涵蓋起日": ("" if read_to_end else scan_since) if full else old_list["涵蓋起日"], "rows": kept_rows})
            if undated:
                failures.append("%d 份文件的檔名看不出日期，無法判斷在不在期間內，須補查：%s"
                                % (len(undated), "、".join(undated[:5])))
            if off_topic:
                ended += "標題不在範圍略過 %d 筆（不代表不適用）；" % off_topic
            if repeated:
                ended += "%d 筆跟前面的來源是同一則公告，沒有重抓；" % repeated
            if early_count:
                ended += "起日前的整部修正列入 %d 筆；" % early_count
            if foreign_skipped:
                ended += "同一則公告有中文版的外文附件略過 %d 份（%s）；" % (len(foreign_skipped), "、".join(foreign_skipped[:6]))
            coverage["trouble"] = bool(failures) or not listed_days or min(listed_days) > since
            coverage.update(status="部分完成", detail="已讀取 %d 頁、%d 筆公告及可辨識附件；%s；%s網站未涵蓋的歷史期間、動態附件仍須 AI 補查。%s" %
                            (len(pages), matched, note_listed(), ended, "；".join(failures)))
        else:
            if kind in ("官方網頁", "開放資料"):
                raw = fetcher(source["url"])
                suffix = detect_format(raw, source["url"], source.get("format", ""))
            else:
                path = local_source_file(base, source.get("path"), extra_roots)
                if not path.is_file():
                    raise SourceError("找不到匯入檔案：%s" % path)
                if path.stat().st_size > MAX_BYTES:
                    raise SourceError("匯入檔案超過 40 MB，請分檔")
                raw, suffix = path.read_bytes(), path.suffix
            evidence = save(raw, suffix)
            accept(records_from_bytes(raw, suffix, source), evidence)
            coverage.update(status="部分完成", detail="已讀取指定來源；只涵蓋檔案／網頁內容，日期與期間完整性需核對")
        coverage["count"] = len(events)
    except Exception as exc:
        # 什麼例外都接（v1.51.0；以前漏了 pypdf 的錯）：來源失敗只記在 coverage，不讓整輪 traceback
        coverage.update(status="失敗" if not events else "部分完成", detail=_describe(exc), count=len(events))
        if listed_days:             # 清單讀到一半壞掉：已經讀到的範圍照寫，才知道缺哪一段
            coverage["detail"] += "；" + note_listed()
    finally:
        if bridge:
            bridge.close()
    if source.get("law_names") or source.get("keywords"):
        coverage["detail"] += "；名稱範圍 %s，另有 %d 筆未納入（不代表不適用）" % (
            json.dumps({"law_names": source.get("law_names", []), "keywords": source.get("keywords", [])}, ensure_ascii=False),
            coverage.get("filtered_count", 0))
    return events, coverage
