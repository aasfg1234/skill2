# -*- coding: utf-8 -*-
r"""
語意候選：用 BGE-M3 找「意思相近但字面不像」的條文，當連帶決定表的第四種來源。

用法（在有模型的電腦）：
    py semantic_candidates.py --交換包 語意交換包.zip --model <模型資料夾>      （批次：一個檔來回，見 semantic_exchange）
    py semantic_candidates.py 語意輸入.json 語意候選.csv --model <模型資料夾> [--threshold 0.70] [--top 10]

語意輸入.json 由 run_all.py compare 產生。算完把 語意候選.csv 交回去：
    py run_all.py semantic 連帶決定表.csv 語意候選.csv

離開代碼：0 成功；1 輸入有問題；2 模型載不起或算到一半失敗（缺套件、模型壞了、記憶體不足），算好的本留著，其他請改手動。

為什麼只當第四種來源、不取代同義詞表：
向量給分數但說不出哪個詞對上；法遵每一筆建議都要能講理由。
所以語意候選一樣列全文與分數，由 AI 在第 2 步逐筆寫理由，人來決定。
"""

import argparse
import codecs
import csv
import hashlib
import io
import json
import math
import os
os.environ.setdefault("TQDM_DISABLE", "1")
os.environ.setdefault("HF_HUB_DISABLE_PROGRESS_BARS", "1")
os.environ.setdefault("TRANSFORMERS_VERBOSITY", "error")
import random
import re
import sqlite3
import struct
import sys
import time
import unicodedata
import zipfile
import speed_memory

HERE = os.path.dirname(os.path.abspath(__file__))
for _path in (HERE, os.path.join(HERE, "regdiff")):
    if _path not in sys.path:
        sys.path.insert(0, _path)
from _common import AtomicWrites, strip_article_no, normalize_for_compare, diff_runs  # noqa: E402
import fuzzy_duplicate_finder as fuzzy  # noqa: E402

# 門檻依分數方式不同（真資料校準：手冊 1,347 段、五→七年一字之差）：
#   三分數合併：孿生條 0.86 以上、相鄰條 0.72、其餘 0.62 以下 → 0.70 中間有明顯的空隙
#   只有 dense：孿生條 0.91／0.97、相鄰條 0.79，但無關段也有 0.70～0.72 → 要 0.75 才擋得住
# 呼叫端沒指定（None）就用分數器自己的預設。
DEFAULT_THRESHOLD = 0.70
DENSE_ONLY_THRESHOLD = 0.75
DEFAULT_TOP = 10
# 這台電腦還沒量過速度時的預設：每個未快取的比對單位 0.5～1.5 秒。
# 實測 7 本 3,341 段向量全冷 3,531 秒（每段約 1.06 秒，16 執行緒、CPU 27,795 秒）；以前寫 0.2～0.6 少算一半以上。
ESTIMATE_SECONDS_PER_UNIT = (0.15, 1.5)   # v1.60.11：模擬實測每段約 0.13 秒（783 段 1.7 分）；以前 7 本 3,341 段 59 分（每段約 1.06 秒）


def estimate_cache(scorer, groups, say=print, partial=False):
    """依實際的正規化比對單位估算；groups 每項是一段的單位清單。
    partial：groups 只有第一本（批次在算第一本時才估），訊息要講，不然一本小的排第一就只印「1 分鐘」。"""
    more = "；這裡只算到第一本，好幾本時後面的本還要再加" if partial else ""
    try:
        groups = [set(group) for group in groups]
        units = set().union(*groups) if groups else set()
        cache = getattr(scorer, "cache", None)
        hits = getattr(cache, "hits", None)
        misses = getattr(cache, "misses", None)
        try:
            known = cache.get_many(list(units)) if cache is not None else {}
        finally:
            if hits is not None:
                cache.hits = hits
            if misses is not None:
                cache.misses = misses
        missing_units = units.difference(known)
        missing = sum(bool(group & missing_units) for group in groups)
        scorer._speed_remaining = set(missing_units)
        scorer._speed_total = len(missing_units)
        scorer._speed_count = 0
        scorer._speed_seconds = 0.0
        scorer._speed_finished = False
        scorer._speed_last = time.monotonic()
        scorer._bar_last = None
        scorer._bar_width = 0
        if not missing:
            say("段落都算過，不用重算；比對還要一段時間，段落多時可能超過半小時" + more)
        else:
            low, high = ESTIMATE_SECONDS_PER_UNIT
            minutes_low = max(1, math.ceil(len(missing_units) * low / 60))
            minutes_high = max(1, math.ceil(len(missing_units) * high / 60))
            minutes = str(minutes_low) if minutes_low == minutes_high else "%d～%d" % (minutes_low, minutes_high)
            previous = speed_memory.get("語意段落")
            if previous is not None:
                say("這台電腦上次每段約 %.2f 秒，這次 %d 段%s%s" %
                    (previous, len(missing_units), speed_memory.duration(len(missing_units) * previous), more))
            else:
                say("這次有 %d 段沒算過，第一次在這台電腦跑、還沒量過速度，先抓 %s 分鐘（實測每段約 0.13～1.1 秒，電腦較舊或同時開別的工作會更久，"
                    "算一陣子後會照實際速度更新%s）" % (missing, minutes, more))
    except Exception:
        cache = getattr(scorer, "cache", None)
        if cache is not None:
            try:
                cache.close()
            except Exception:
                pass
            scorer.cache = None
        say("依段落多寡，幾分鐘到半小時，段落很多時更久，算過的段落會記住；視窗一陣子沒有變化也還在跑，請不要關掉。")



def _bar_enabled():
    return os.environ.get("REG_PROGRESS_BAR") == "1"


def _display_width(text):
    return sum(2 if unicodedata.east_asian_width(c) in ("W", "F") else 1 for c in text)


def _bar_update(state, label, unit, count, total, seconds, now, force=False):
    if not _bar_enabled() or not total or getattr(state, "_progress_silent", False):
        return
    last = getattr(state, "_bar_last", None)
    if not force and last is not None and now - last < 1:
        return
    filled = min(10, max(0, count * 10 // total))
    duration = speed_memory.duration(seconds / count * (total - count)) if count >= 20 else ""
    if count < 20:
        remaining = "估算中"
    elif duration.startswith("約 "):
        remaining = "約再 " + duration[2:]
    elif duration == "不到 1 分鐘":
        remaining = "快好了（不到 1 分鐘）"
    else:
        remaining = duration                         # 「估不出來」照實寫
    # ■□ 是 Big5 也有的字（繁中 Windows 主控台舊編碼印得出來；以前用 ░ 會讓程式當掉）
    text = "%s %s%s  %d／%d %s，%s" % (label, "■" * filled, "□" * (10 - filled), count, total, unit, remaining)
    width = _display_width(text)
    padding = max(0, getattr(state, "_bar_width", 0) - width)
    _safe_write("\r" + text + " " * padding + "\r")
    state._bar_last = now
    state._bar_width = max(width, getattr(state, "_bar_width", 0))


def _safe_write(text):
    """進度條印不出來（主控台編碼不認得某個字）不能讓整個計算失敗：換成 #- 再印，還是不行就不畫。"""
    try:
        sys.stdout.write(text)
        sys.stdout.flush()
        return
    except UnicodeEncodeError:
        pass
    except (OSError, ValueError):
        return                                       # 主控台關了、輸出壞了：不畫，計算照常
    encoding = getattr(sys.stdout, "encoding", None) or "ascii"
    plain = text.replace("■", "#").replace("□", "-")
    try:
        sys.stdout.write(plain.encode(encoding, "replace").decode(encoding))
        sys.stdout.flush()
    except (UnicodeError, LookupError, OSError, ValueError):
        pass


def _bar_finish(state, text):
    if _bar_enabled() and getattr(state, "_bar_width", 0):
        padding = max(0, state._bar_width - _display_width(text))
        _safe_write("\r" + text + " " * padding + "\n")
        state._bar_width = 0
    else:
        print(text)


def _finish_speed(scorer):
    count = getattr(scorer, "_speed_count", 0)
    if not count or getattr(scorer, "_speed_remaining", None) or getattr(scorer, "_speed_finished", False):
        return
    scorer._speed_finished = True
    seconds = scorer._speed_seconds
    saved = count >= 20 and speed_memory.record("語意段落", seconds, count)
    suffix = "，已記下這台電腦的速度" if saved else ""
    if not getattr(scorer, "_progress_silent", False):
        _bar_finish(scorer, "語意比對：算完 %d 段，用了 %.1f 分鐘（每段約 %.2f 秒%s）" %
                    (count, seconds / 60, seconds / count, suffix))


def _timed_encode(scorer, function, texts, build_texts=()):
    remaining = getattr(scorer, "_speed_remaining", set())
    fresh = remaining.intersection(texts)
    build = set(build_texts).intersection(texts)
    if not fresh and not build:
        return function(texts)
    start = time.monotonic()
    result = function(texts)
    now = time.monotonic()
    if build:
        scorer._vector_build_seconds = getattr(scorer, "_vector_build_seconds", 0.0) + (now - start) * len(build) / len(texts)
    if not fresh:
        return result
    # 同一批混有其他文字時，按單位數分攤耗時。
    elapsed = (now - start) * len(fresh) / len(texts)
    remaining.difference_update(fresh)
    scorer._speed_count += len(fresh)
    scorer._speed_seconds += elapsed
    count, total = scorer._speed_count, scorer._speed_total
    if _bar_enabled():
        _bar_update(scorer, "語意比對", "段", count, total, scorer._speed_seconds, now, force=not remaining)
    if not remaining and not getattr(scorer, "_speed_defer_finish", False):
        _finish_speed(scorer)
    elif not _bar_enabled() and not getattr(scorer, "_progress_silent", False) and remaining and count >= 20 and now - scorer._speed_last >= 20:
        print("語意比對：已算 %d／%d 段，照目前速度再%s" %
              (count, total, speed_memory.duration(scorer._speed_seconds / count * len(remaining))))
        scorer._speed_last = now
    return result


def _timed_extra(scorer, function, texts, remaining_units=0):
    """細算候選段也屬於這輪模型工作；全命中時不計入新段速度。"""
    active = getattr(scorer, "_speed_total", 0) and not getattr(scorer, "_speed_finished", False)
    if not active:
        return function(texts)
    start = time.monotonic()
    result = function(texts)
    now = time.monotonic()
    scorer._speed_seconds += now - start
    if not _bar_enabled() and not getattr(scorer, "_progress_silent", False) and now - scorer._speed_last >= 20 and scorer._speed_count >= 20:
        remaining = "，照目前速度再%s" % speed_memory.duration((now - start) * remaining_units / len(texts)) if remaining_units else ""
        print("語意比對：已算 %d／%d 段，正在細算候選段%s" % (scorer._speed_count, scorer._speed_total, remaining))
        scorer._speed_last = now
    return result


def estimate_inputs(scorer, inputs, say=print):
    paragraphs = [text for data in inputs if data.get("異動") for text in data.get("段落", [])]
    estimate_cache(scorer, [[norm for norm, _ in _units_of(text)] for text in paragraphs], say)
    scorer._estimate_announced = True
# 三種分數對「全文每一個單位」都算（全排名），不先用 dense 篩。記憶體靠分批：
# 每次只把 DEFAULT_BATCH 個單位送進模型、算完分數就丟掉向量（逐字向量每字 1024 個數字，
# 全部留著 1,500 個單位要幾百 MB；分批之後不管書多大都只有一批的量）。
DEFAULT_BATCH = 64
# 粗篩：None（預設）＝全排名，每個單位都算三種分數，不會漏但慢（真資料 1,347 段 801 秒）；
# 給一個數字 N ＝先用純語意把全文排一遍、只對前 N 名算三種分數（N=40 時 402 秒，
# 同一份真資料結果一模一樣；理論上純語意排 N 名外的段會漏）。設定.html「語意粗篩」可改。
DEFAULT_RECALL_TOP = None
# BGE-M3 官方建議的三分數權重（dense／sparse／colbert）。
HYBRID_WEIGHTS = (0.4, 0.2, 0.4)
# 有向量快取時：dense＋sparse 全排名（都從快取來），每個查詢句只對前這麼多名現算 colbert。
# colbert 逐字向量太大不存（見 semantic_cache）；排在前幾名外的段，dense 與 sparse 都已經遠低於門檻。
FULL_MEMO_LIMIT = 400     # 一輪最多記幾段的逐字向量（一段約幾百 KB，400 段約 100～200 MB）
RERANK_TOP = 50          # 設定.html「語意取前幾名」可以改（見 run_all._semantic_rerank_top）
# 重排序（bge-reranker-v2-m3，設定.html「語意重排序」打勾才用，預設關）：BGE-M3 先把每處異動的候選
# 多抓一些（語意最多幾筆的 RERANKER_POOL 倍），重排序模型把「改動句、候選整段」一對一對讀過、給 0～1 的
# 相關分數。只加不刪：BGE-M3 原本的前幾筆全部留著，重排序排進前幾名、原本沒進來的再補上
# （以前是照重排分數只留前幾筆：真資料上重排分數擠在 0.98～1.00，把「新契約進件檢核表」那幾段擠掉了）。
# 重排序門檻：補進來的那幾筆，重排分數至少要多少；留空＝排進前幾名就補。
RERANKER_NAME = "bge-reranker-v2-m3"
RERANKER_POOL = 2
RERANKER_BATCH = 16
COLUMNS = ["異動段次", "異動全文", "候選段次", "候選全文", "語意分數", "異動條文ID", "語意依據", "重排分數"]
LEGACY_COLUMNS = COLUMNS[:6]


class SemanticError(ValueError):
    pass


# 語意套件自己會丟的錯（壞檔、記憶體、模型算不下去）。TypeError、KeyError、AttributeError 不在裡面：
# 那多半是這支程式呼叫錯了，要照原樣噴出來，不能當成「模型壞了」略過
_MODEL_FAILURES = (RuntimeError, MemoryError, OSError, ValueError, ImportError, EOFError)
_MEMORY_WORDS = ("out of memory", "not enough memory", "can't allocate", "cannot allocate", "allocate memory")


def _plain_failure(exc, what):
    """語意套件丟的例外換成白話一句（what 是「語意模型載不起來」這種開頭）。"""
    text = " ".join(str(exc).split())[:160]
    if isinstance(exc, MemoryError) or any(word in text.lower() for word in _MEMORY_WORDS):
        return "%s：記憶體不足（%s）" % (what, text or type(exc).__name__)
    if isinstance(exc, ImportError):
        return "%s：缺套件或套件裝壞了（%s）" % (what, getattr(exc, "name", "") or text)
    return "%s（%s：%s）" % (what, type(exc).__name__, text)


def _model_call(function, *args, **kwargs):
    """呼叫語意套件算東西：環境造成的失敗換成 SemanticError，呼叫端走「語意沒做、比對繼續」。"""
    try:
        return function(*args, **kwargs)
    except SemanticError:
        raise
    except _MODEL_FAILURES as exc:
        raise SemanticError(_plain_failure(exc, "語意模型算到一半失敗")) from exc


def write_input(path, draft_path, draft_sha, changes, paragraphs, target_name=""):
    data = {"格式版本": 1, "目標規章": target_name,
            "草稿": {"檔名": os.path.basename(draft_path), "SHA256": draft_sha},
            "異動": changes, "段落": list(paragraphs)}
    with AtomicWrites() as aw:
        with io.open(aw.path(path), "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=1)
            f.write("\n")
    return path


def read_input(path):
    if not os.path.isfile(path):
        raise SemanticError("找不到語意輸入檔：%s" % path)
    try:
        with io.open(path, encoding="utf-8-sig") as f:
            data = json.load(f)
    except ValueError:       # 半截的 JSON、半個字都是 ValueError
        raise SemanticError("語意輸入檔沒寫完或壞了：%s；重跑 開始 會重新產生" % path)
    if (not isinstance(data, dict) or data.get("格式版本") != 1 or "段落" not in data or "異動" not in data):
        raise SemanticError("語意輸入檔格式不對：%s" % path)
    return data


# ---------------------------------------------------------------------------
# 前處理：跟字面比對用同一套
# ---------------------------------------------------------------------------

# ---------------------------------------------------------------------------
# 分數器：dense-only（sentence_transformers 或任何向量函式）與 hybrid（FlagEmbedding）
# ---------------------------------------------------------------------------

def _cosine(a, b):
    dot = sum(x * y for x, y in zip(a, b))
    na = math.sqrt(sum(x * x for x in a))
    nb = math.sqrt(sum(x * x for x in b))
    return dot / (na * nb) if na and nb else 0.0


def _cosine_matrix(queries, docs):
    """查詢×全文的 cosine 矩陣（list of list）。有 numpy 就一次算完（幾萬段 × 1024 維，純 Python
    逐一乘要好幾分鐘）；沒有 numpy 回 None，呼叫端退回逐一算。"""
    try:
        import numpy as np
    except ImportError:
        return None
    if not queries or not docs:
        return [[] for _ in queries]
    q = np.asarray(queries, dtype="float32")
    d = np.asarray(docs, dtype="float32")
    q = q / np.maximum(np.linalg.norm(q, axis=1, keepdims=True), 1e-12)
    d = d / np.maximum(np.linalg.norm(d, axis=1, keepdims=True), 1e-12)
    return (q @ d.T).tolist()


class DenseScorer(object):
    """只有一種向量時的分數器：cosine。embed 是 list[str] -> 向量列表。
    cache（semantic_cache.VectorCache，選填）：算過的文字直接拿，只算沒算過的。"""
    default_threshold = DENSE_ONLY_THRESHOLD

    def __init__(self, embed, cache=None):
        self.embed = embed
        self.cache = cache

    def _vectors(self, texts):
        unique = list(dict.fromkeys(texts))
        known = dict((t, v["dense"]) for t, v in (self.cache.get_many(unique) if self.cache else {}).items())
        missing = [t for t in unique if t not in known]
        for start in range(0, len(missing), DEFAULT_BATCH):
            batch = missing[start:start + DEFAULT_BATCH]
            build = getattr(self, "_speed_remaining", set()) if self.cache else ()
            fresh = [[float(x) for x in v] for v in _timed_encode(self, self.embed, batch, build)]
            known.update(zip(batch, fresh))
            if self.cache:
                self.cache.put_many([(t, v, None) for t, v in zip(batch, fresh)])
        return [known[t] for t in texts]

    def score(self, queries, docs):
        if not queries or not docs:
            return [[0.0] * len(docs) for _ in queries]
        if not getattr(self, "_estimate_announced", False):
            estimate_cache(self, [[doc] for doc in dict.fromkeys(docs)], say=(lambda _: None) if getattr(self, "_progress_silent", False) else print, partial=True)
            self._estimate_announced = True
        vectors = self._vectors(list(docs) + list(queries))
        doc_vecs, query_vecs = vectors[:len(docs)], vectors[len(docs):]
        return [[_cosine(q, d) for d in doc_vecs] for q in query_vecs]


# 存過的三分數是用這套算法算的：改了 _hybrid、max_length、colbert 的算法就加一，舊分數才不會混進來
SCORE_RULES = "1"
# 查詢句跟段落分開存（鍵前面多這一段）：同樣的文字，段落用 encode_lite、查詢句用 encode_all，
# 混在一起時段落會被當成算過，速度紀錄和「沿用幾個」都不對
QUERY_PREFIX = "查詢句\x00"


class HybridScorer(object):
    """BGE-M3 三分數合併，全排名：每個查詢句對全文**每一個**單位都算
    dense／sparse／colbert，照 HYBRID_WEIGHTS 加總。

    以前先用 dense 召回前 40 名再細算，是因為誤以為逐字向量放不下；其實分批算、
    算完就丟就沒有這個問題，而且模型只要跑一遍（不用再對召回的那幾十個重跑），
    也不會有「dense 排 40 名外、細算永遠看不到」的漏抓。

    model 只要有四個方法：
        encode_all(texts) -> [{"dense": 向量, "sparse": 詞權重, "colbert": 逐字向量}, ...]
        dense_score(q, d) / sparse_score(q, d) / colbert_score(q, d) -> float
    真的模型用 _FlagM3 包起來；測試用假的。

    為什麼要三種：dense 抓「意思像」，sparse 抓「關鍵詞有沒有對上」，colbert 逐字細比。
    只用 dense 時「保險費」對「應繳金額」只有 0.742，跟無關句（0.667）拉不開；
    三種合起來是 BGE-M3 官方建議的用法。
    """
    default_threshold = DEFAULT_THRESHOLD

    def __init__(self, model, batch_size=DEFAULT_BATCH, weights=HYBRID_WEIGHTS,
                 recall_top=DEFAULT_RECALL_TOP, cache=None, rerank_top=RERANK_TOP):
        self.model = model
        self.batch_size = max(1, int(batch_size))
        self.weights = weights
        self.recall_top = int(recall_top) if recall_top else None
        self.cache = cache
        self.rerank_top = max(1, int(rerank_top))

    def _hybrid(self, q, d):
        wd, ws, wc = self.weights
        return (wd * float(self.model.dense_score(q["dense"], d["dense"]))
                + ws * float(self.model.sparse_score(q["sparse"], d["sparse"]))
                + wc * float(self.model.colbert_score(q["colbert"], d["colbert"])))

    def score(self, queries, docs):
        docs = list(docs)
        queries = list(queries)
        if not queries or not docs:
            return [[0.0] * len(docs) for _ in queries]
        if not getattr(self, "_estimate_announced", False):
            estimate_cache(self, [[doc] for doc in dict.fromkeys(docs)], say=(lambda _: None) if getattr(self, "_progress_silent", False) else print, partial=True)
            self._estimate_announced = True
        self._speed_defer_finish = True
        try:
            result = self._score(queries, docs)
        finally:
            self._speed_defer_finish = False
        _finish_speed(self)
        return result

    def _score(self, queries, docs):
        matrix = [[0.0] * len(docs) for _ in queries]
        if self.cache is not None:
            return self._score_cached(queries, self._query_vectors(queries), docs, matrix)
        # v1.50.0：law_impact 先把幾條法規的查詢句一批編好掛在 _query_parts（一句一句編每句都多跑一次試算）
        ready = getattr(self, "_query_parts", None)
        if ready and all(q in ready for q in queries):
            q_parts = [ready[q] for q in queries]
        else:
            q_parts = self._encode_queries(queries)
        if self.recall_top:
            return self._score_recall(q_parts, docs, matrix)
        for start in range(0, len(docs), self.batch_size):
            batch = docs[start:start + self.batch_size]
            d_parts = _timed_encode(self, self.model.encode_all, batch)
            for qi, q in enumerate(q_parts):
                row = matrix[qi]
                for k, d in enumerate(d_parts):
                    row[start + k] = self._hybrid(q, d)
            del d_parts          # 這一批的逐字向量到此為止，不留
        return matrix

    def _query_vectors(self, queries):
        """查詢句的向量：先編好的、存過的（只有 dense＋sparse，v1.60.3），都沒有才跑模型（存起來）。
        存過的不用載模型：內規改一個字時多半整輪都用不到逐字向量。"""
        ready = getattr(self, "_query_parts", None) or {}
        known = dict((q, ready[q]) for q in queries if q in ready)
        rest = [q for q in dict.fromkeys(queries) if q not in known]
        known.update(self.stored_queries(rest))
        rest = [q for q in rest if q not in known]
        if rest:
            known.update(zip(rest, self._encode_queries(rest)))
            self.remember_queries((q, known[q]) for q in rest)
        return [known[q] for q in queries]

    def stored_queries(self, queries):
        if self.cache is None or not queries or not hasattr(self.cache, "get_scores"):
            return {}
        hits, misses = self.cache.hits, self.cache.misses
        try:
            found = self.cache.get_many([QUERY_PREFIX + q for q in queries])
        except sqlite3.Error:
            return {}
        finally:
            self.cache.hits, self.cache.misses = hits, misses     # 這兩個數是段落的命中率，查詢句不算
        try:
            import numpy
            weight = numpy.float32       # 模型算出來的權重是 float32：型別不同，相乘的尾數就不同，排名邊界可能對調
        except ImportError:
            weight = float
        out = {}
        for key, part in found.items():
            out[key[len(QUERY_PREFIX):]] = {"dense": part["dense"],
                                            "sparse": dict((k, weight(v)) for k, v in (part["sparse"] or {}).items())}
        return out

    def remember_queries(self, items):
        """存不進去不影響結果，只是下次重編。"""
        if self.cache is None or not hasattr(self.cache, "get_scores"):
            return
        try:
            self.cache.put_many([(QUERY_PREFIX + q, part["dense"], part["sparse"]) for q, part in items])
        except sqlite3.Error:
            try:
                self.cache.db.rollback()     # 不留交易：同一個檔還有重排序那條連線，留著會一直鎖
            except sqlite3.Error:
                pass

    def _score_tag(self):
        return "hybrid%s|%s" % (SCORE_RULES, ",".join(repr(float(w)) for w in self.weights))

    def _encode_queries(self, queries):
        """查詢句編成向量。比對時每一本查的是同一批異動（v1.59.1）：只編上一次沒有的，別每本重編。
        只留這一批，不會越積越多；同一句文字重用同一份向量，結果不變。"""
        last = getattr(self, "_last_queries", None) or {}
        known = dict((q, last[q]) for q in queries if q in last)
        fresh = sorted((q for q in dict.fromkeys(queries) if q not in known), key=len, reverse=True)
        if fresh:
            known.update(zip(fresh, self.model.encode_all(fresh)))
        self._last_queries = known
        return [known[q] for q in queries]

    def _full_memo(self):
        """這一輪算過的完整向量（含逐字向量），照段落文字記住最近 FULL_MEMO_LIMIT 段（v1.11.0）。
        新法規一條一條找候選段，前 50 名常常是同幾段，以前每一條都重算一次（一條約 16 秒）。分數完全一樣。"""
        if getattr(self, "_memo", None) is None:
            import collections
            self._memo = collections.OrderedDict()
        return self._memo

    def _lite(self, docs):
        """每個單位的 dense＋sparse：快取有就拿，沒有才算（算完存回去）。"""
        unique = list(dict.fromkeys(docs))
        known = self.cache.get_many(unique)
        for batch in _length_chunks((t for t in unique if t not in known), len):
            parts = _timed_encode(self, self.model.encode_lite, batch, batch)
            self.cache.put_many([(t, p["dense"], p["sparse"]) for t, p in zip(batch, parts)])
            for t, p in zip(batch, parts):
                known[t] = {"dense": p["dense"], "sparse": p["sparse"]}
        return [known[t] for t in docs]

    def _score_cached(self, queries, q_parts, docs, matrix):
        """快取模式：dense＋sparse 全排名（都從快取來），每個查詢句只對前 rerank_top 名算 colbert
        （逐字向量不存，現算），得到三分數合併；其餘留 0（dense 與 sparse 都已經遠低於門檻）。"""
        wd, ws, _ = self.weights
        lite = self._lite(docs)
        dense = _cosine_matrix([q["dense"] for q in q_parts], [d["dense"] for d in lite])
        picked_by_q = []
        for qi, q in enumerate(q_parts):
            if dense is None:
                dense_row = [float(self.model.dense_score(q["dense"], d["dense"])) for d in lite]
            else:
                dense_row = dense[qi]
            partial = [wd * dense_row[j] + ws * float(self.model.sparse_score(q["sparse"], d["sparse"] or {}))
                       for j, d in enumerate(lite)]
            ranked = sorted(range(len(docs)), key=lambda j: partial[j], reverse=True)
            picked_by_q.append(ranked[:self.rerank_top])
        # v1.60.3：這一對算過就拿存的。分數只看這一對文字，跟排名怎麼變無關
        tag = self._score_tag()
        get_scores = getattr(self.cache, "get_scores", None)
        put_scores = getattr(self.cache, "put_scores", lambda *_: None)
        saved = get_scores(tag, [(queries[qi], docs[j]) for qi, picked in enumerate(picked_by_q)
                                 for j in picked]) if get_scores else {}
        asked = {}
        for qi, picked in enumerate(picked_by_q):
            for j in picked:
                score = saved.get((queries[qi], docs[j]))
                if score is None:
                    asked.setdefault(j, []).append(qi)
                else:
                    matrix[qi][j] = score
        missed = sum(len(owners) for owners in asked.values())
        self.pair_counts = [getattr(self, "pair_counts", (0, 0))[0] + sum(len(p) for p in picked_by_q) - missed,
                            getattr(self, "pair_counts", (0, 0))[1] + missed]
        if not asked:
            return matrix
        q_parts = list(q_parts)
        lacking = sorted(set(qi for owners in asked.values() for qi in owners if "colbert" not in q_parts[qi]))
        if lacking:                  # 空的也呼叫的話，上一批查詢句的記憶會被清掉
            for qi, part in zip(lacking, self._encode_queries([queries[qi] for qi in lacking])):
                q_parts[qi] = part
        fresh = []

        def fill(j, part):
            for qi in asked[j]:
                matrix[qi][j] = self._hybrid(q_parts[qi], part)
                fresh.append((queries[qi], docs[j], matrix[qi][j]))
        memo = self._full_memo()
        missing = []
        for j in sorted(asked):
            if docs[j] in memo:
                fill(j, memo[docs[j]])
                memo.move_to_end(docs[j])
            else:
                missing.append(j)
        chunks = _length_chunks(missing, lambda j: len(docs[j]))
        left = len(missing)
        for batch in chunks:
            left -= len(batch)
            for j, part in zip(batch, _timed_extra(self, self.model.encode_all, [docs[j] for j in batch], left)):
                fill(j, part)            # v1.59.2：算完這一批就評分、向量不留：多條法規一起算時記憶體不會跟著翻倍
                memo[docs[j]] = part
            while len(memo) > FULL_MEMO_LIMIT:
                memo.popitem(last=False)
            put_scores(tag, fresh)                 # 一批一存：中途停掉，算過的下次不用再算
            del fresh[:]
        put_scores(tag, fresh)                     # 全部在 memo 裡的那幾對
        return matrix

    def _score_recall(self, q_parts, docs, matrix):
        """粗篩模式：先只算純語意（便宜）把全文排一遍，每個查詢句只對前 recall_top 名
        算三種分數，其餘留 0（本來就遠低於門檻）。"""
        dense_all = []
        for start in range(0, len(docs), self.batch_size):
            batch = docs[start:start + self.batch_size]
            dense_all.extend(_timed_encode(self, self.model.encode_dense, batch))
        for qi, q in enumerate(q_parts):
            ranked = sorted(range(len(docs)),
                            key=lambda j: self.model.dense_score(q["dense"], dense_all[j]), reverse=True)
            picked = ranked[:self.recall_top]
            d_parts = _timed_extra(self, self.model.encode_all, [docs[j] for j in picked])
            for j, d in zip(picked, d_parts):
                matrix[qi][j] = self._hybrid(q, d)
        return matrix


class _LazyModel(object):
    """BGE-M3 等真的要算向量才載入（v1.11.0）：重跑時所有段落都在向量快取裡，以前照樣先花 10 秒載模型。"""

    def __init__(self, model_path):
        self.path = model_path
        self.loaded = None
        self.failed = ""

    def get(self):
        """載不起來丟 SemanticError。try 裡只有語意套件的 import 與載入，沒有這支程式的邏輯，所以接全部 Exception：
        套件的 import 鏈與壞檔丟什麼都有（safetensors 有自己的例外類別）。失敗記住，同一輪不重載。"""
        if self.failed:
            raise SemanticError(self.failed)
        if self.loaded is None:
            try:
                from FlagEmbedding import BGEM3FlagModel
                print("載入語意模型（BGE-M3，快取沒有的段落要算）……", flush=True)
                self.loaded = BGEM3FlagModel(self.path, use_fp16=False)
            except Exception as exc:
                self.failed = _plain_failure(exc, "語意模型載不起來")
                raise SemanticError(self.failed) from exc
            _quiet_package_bars()
        return self.loaded


def _quiet_package_bars():
    """v1.47.0：模型套件呼叫進度條時自己寫了 disable=…，蓋過 TQDM_DISABLE，畫面還是一堆英文進度條。
    把套件模組裡的 tqdm／trange 換成一律不顯示的（TQDM_DISABLE 被設成別的值就不動，給要看的人）。"""
    if os.environ.get("TQDM_DISABLE") != "1":
        return
    try:
        from tqdm import tqdm as _tqdm, trange as _trange
    except ImportError:
        return

    def quiet(*args, **kwargs):
        kwargs["disable"] = True
        return _tqdm(*args, **kwargs)

    def quiet_range(*args, **kwargs):
        kwargs["disable"] = True
        return _trange(*args, **kwargs)

    for name, module in list(sys.modules.items()):
        if module is None or not name.startswith("FlagEmbedding"):
            continue
        if getattr(module, "tqdm", None) is _tqdm:
            module.tqdm = quiet
        if getattr(module, "trange", None) is _trange:
            module.trange = quiet_range


# 快取模式一次送幾段進模型（v1.59.1，也是進度條多久動一次）。模型每次呼叫都先試跑一批，排序也只在
# 同一次呼叫裡有效：以前每 16 段呼叫一次，等於每段算兩次，短句還要陪同組最長的一句補齊長度。
# 先照長度排、一次送 128 段：實測新段落省 76%，向量差異在 1e-5 以內。模型內部的批次照舊，記憶體不會變多
ENCODE_CHUNK = 128


def _length_chunks(items, length):
    """照長度排好切塊，再打亂塊的順序（固定順序，重跑一樣）。不打亂的話最長的先算，
    前面看起來特別慢，剩餘時間會高估好幾倍。每塊裝什麼不變，省下的時間也不變。"""
    ordered = sorted(items, key=length, reverse=True)
    chunks = [ordered[start:start + ENCODE_CHUNK] for start in range(0, len(ordered), ENCODE_CHUNK)]
    random.Random(0).shuffle(chunks)
    return chunks


class _FlagM3(object):
    """把 FlagEmbedding 的 BGEM3FlagModel 包成 HybridScorer 要的四個方法。"""

    def __init__(self, model, batch_size=16):
        self._model = model
        self.batch_size = max(1, min(16, int(batch_size)))     # 一次送進模型幾句：記憶體少就小一點

    @property
    def model(self):
        return self._model.get() if isinstance(self._model, _LazyModel) else self._model

    def encode_dense(self, texts):
        """只要純語意向量（粗篩用，比三種一起要快一倍）。"""
        texts = list(texts)
        if not texts:
            return []
        return list(_model_call(self.model.encode, texts, batch_size=self.batch_size, max_length=512)["dense_vecs"])

    def encode_lite(self, texts):
        """dense＋sparse，不算 colbert（給快取用，逐字向量不存）。"""
        texts = list(texts)
        if not texts:
            return []
        out = _model_call(self.model.encode, texts, batch_size=self.batch_size, max_length=512,
                          return_dense=True, return_sparse=True, return_colbert_vecs=False)
        return [{"dense": out["dense_vecs"][i], "sparse": out["lexical_weights"][i]} for i in range(len(texts))]

    def encode_all(self, texts):
        texts = list(texts)
        if not texts:
            return []
        out = _model_call(self.model.encode, texts, batch_size=self.batch_size, max_length=512,
                          return_dense=True, return_sparse=True, return_colbert_vecs=True)
        return [{"dense": out["dense_vecs"][i], "sparse": out["lexical_weights"][i],
                 "colbert": out["colbert_vecs"][i]} for i in range(len(texts))]

    @staticmethod
    def dense_score(q, d):
        return _cosine([float(x) for x in q], [float(x) for x in d])

    def sparse_score(self, q, d):
        # 跟 BGEM3FlagModel.compute_lexical_matching_score 同一個算法（共同字的權重相乘再加總），
        # 自己算就不用為了比快取裡的向量去載模型
        return float(sum(weight * d[token] for token, weight in (q or {}).items() if token in (d or {})))

    def colbert_score(self, q, d):
        return float(_model_call(self.model.colbert_score, q, d))


def as_scorer(embed_or_scorer):
    """舊呼叫端傳的是向量函式，新的傳 scorer；兩種都收。"""
    if hasattr(embed_or_scorer, "score"):
        return embed_or_scorer
    return DenseScorer(embed_or_scorer)


# 設成 1 就不自動找模型（設定.html 有填的照用）。測試設這個，整套測試才不會每次去載真的模型
NO_AUTO_MODEL_ENV = "REG_NO_AUTO_MODEL"


def _looks_like_model(folder):
    """資料夾裡有沒有一份完整的模型（設定檔＋權重）。"""
    if not folder or not os.path.isfile(os.path.join(folder, "config.json")):
        return False
    return any(os.path.isfile(os.path.join(folder, name))
               for name in ("pytorch_model.bin", "model.safetensors"))


SMALLEST_PICKLE = 1024 * 1024      # 沒有結尾目錄的舊格式 .bin 只能看大小；比這小的不是權重（多半是 git-lfs 指標檔）


def _safetensors_problem(path):
    """safetensors 開頭記了每個權重在檔案哪裡：讀開頭就知道檔案該有多大，不用載模型。"""
    size = os.path.getsize(path)
    with open(path, "rb") as f:
        head = f.read(8)
        if len(head) < 8:
            return "只有 %d 位元組" % size
        length = struct.unpack("<Q", head)[0]
        if not length or length > size - 8:
            return "開頭的資料不對"
        header = json.loads(f.read(length).decode("utf-8"))
    ends = [item["data_offsets"][1] for key, item in header.items() if key != "__metadata__"]
    if not ends:
        return "裡面沒有權重"
    expected = 8 + length + max(ends)
    return "" if expected == size else "應有 %d 位元組、實際 %d" % (expected, size)


def _torch_file_problem(path, smallest=SMALLEST_PICKLE):
    """torch 存的檔是 zip，目錄在檔案最後面：截斷了就找不到（2 GB 也只讀結尾）。"""
    with open(path, "rb") as f:
        head = f.read(4)
    if head == b"PK\x03\x04":
        return "" if zipfile.is_zipfile(path) else "檔案結尾不見了"
    size = os.path.getsize(path)
    return "只有 %d 位元組" % size if size < smallest else ""


def weights_problem(folder):
    """不載模型，只看模型檔完不完整；有問題回白話一句（模型資料夾在哪由 _looks_like_model 判斷）。"""
    checks = [(name, check) for name, check in (("model.safetensors", _safetensors_problem),
                                                ("pytorch_model.bin", _torch_file_problem))
              if os.path.isfile(os.path.join(folder, name))][:1]      # 兩個都有時，載入用的是 safetensors
    checks += [(name, lambda path: _torch_file_problem(path, 1)) for name in ("colbert_linear.pt", "sparse_linear.pt")
               if os.path.isfile(os.path.join(folder, name))]
    try:
        with io.open(os.path.join(folder, "config.json"), encoding="utf-8-sig") as f:
            json.load(f)
    except (OSError, ValueError):
        return "模型設定檔 config.json 壞了：請重新下載或複製模型"
    for name, check in checks:
        try:
            why = check(os.path.join(folder, name))
        except (OSError, ValueError, KeyError, TypeError, IndexError, AttributeError) as exc:
            why = str(exc)[:80]
        if why:
            return "權重檔 %s 不完整或壞了（%s）：請重新下載或複製模型" % (name, why)
    return ""


def find_local_model(configured="", name="bge-m3"):
    """BGE-M3 模型（name 給 RERANKER_NAME 就是重排序模型）在這台電腦的哪裡。設定.html 有填而且真的有
    就用它；沒填（或填的路徑不在）就照順序找常見位置：skill 資料夾旁邊的 models/<name>、
    家目錄的 models/<name>、Hugging Face 下載快取（~/.cache/huggingface/hub/models--BAAI--<name>/snapshots/*）。
    找不到回空字串。

    以前只看設定.json：留空就一律當成「這台電腦沒有模型」，模型明明在家目錄的 models/bge-m3
    也找不到，語意比對整步被略過，還叫人帶去別台電腦算。"""
    if configured and _looks_like_model(configured):
        return configured
    if os.environ.get(NO_AUTO_MODEL_ENV, "") not in ("", "0"):
        return ""          # 測試用：不要自己去載 2 GB 的模型
    here = os.path.dirname(os.path.abspath(__file__))
    skill_root = os.path.dirname(here)
    home = os.path.expanduser("~")
    candidates = [os.path.join(os.path.dirname(skill_root), "models", name),
                  os.path.join(skill_root, "models", name),
                  os.path.join(home, "models", name)]
    hub = os.environ.get("HF_HOME") and os.path.join(os.environ["HF_HOME"], "hub")
    for root in [hub, os.path.join(home, ".cache", "huggingface", "hub")]:
        snapshots = os.path.join(root or "", "models--BAAI--%s" % name, "snapshots")
        if root and os.path.isdir(snapshots):
            candidates += [os.path.join(snapshots, name) for name in sorted(os.listdir(snapshots))]
    return next((path for path in candidates if _looks_like_model(path)), "")


def _importable(name):
    """套件找得到嗎（不真的 import）。已經載入的算有；sys.modules 裡是 None 表示被擋掉，算沒有。"""
    import importlib.util
    if name in sys.modules:
        return sys.modules[name] is not None
    try:
        return importlib.util.find_spec(name) is not None
    except (ImportError, ValueError, AttributeError):
        return False


_load_problem = [""]


def last_problem():
    """最近一次 load_model 回 None 的原因（白話）；載得起來或還沒載過是空字串。"""
    return _load_problem[0]


def load_model(model_path, recall_top=DEFAULT_RECALL_TOP, cache_dir=None, rerank_top=RERANK_TOP,
               batch_size=DEFAULT_BATCH):
    """先試 FlagEmbedding（三分數），再試 sentence_transformers（只有 dense）。
    都不行回 None，並印原因（last_problem() 拿得到）。回傳的是 scorer（有 .score(queries, docs)）。
    recall_top：None 全排名；數字 N 就先用純語意粗篩前 N 名（只影響三分數那一種）。
    cache_dir：skill 資料夾的 memoization/；給了就用向量快取（見 semantic_cache），沒改的段落不重算。"""
    import semantic_cache
    def safe_cache(mode):
        try:
            return semantic_cache.open_cache(cache_dir, model_path, mode)
        except (OSError, __import__("sqlite3").Error):
            print("依段落多寡，幾分鐘到半小時，段落很多時更久；快取讀不出來，這次不使用快取。", flush=True)
            return None
    def identified(scorer, mode):
        scorer.model_name = os.path.basename(os.path.normpath(model_path))
        scorer.model_fingerprint = semantic_cache.model_fingerprint(model_path)
        scorer.mode = mode
        return scorer

    reasons = []
    problems = []
    _load_problem[0] = ""
    broken = weights_problem(model_path) if _looks_like_model(model_path) else ""
    if broken:
        print("  " + broken, flush=True)
        _load_problem[0] = broken
        return None
    try:
        cache = safe_cache("m3")
        if (cache is not None and _importable("FlagEmbedding") and _importable("torch")
                and _looks_like_model(model_path)):
            # 有向量快取：模型等真的要算才載（v1.11.0）
            return identified(HybridScorer(_FlagM3(_LazyModel(model_path), batch_size), recall_top=recall_top,
                                rerank_top=rerank_top, batch_size=batch_size, cache=cache), "hybrid")
        from FlagEmbedding import BGEM3FlagModel
        model = BGEM3FlagModel(model_path, use_fp16=False)
        _quiet_package_bars()
        return identified(HybridScorer(_FlagM3(model, batch_size), recall_top=recall_top, rerank_top=rerank_top,
                            batch_size=batch_size, cache=cache), "hybrid")
    except Exception as exc:
        reasons.append("FlagEmbedding 載不起：%s" % exc)
        problems.append(_plain_failure(exc, "語意模型載不起來"))
    try:
        from sentence_transformers import SentenceTransformer
        model = SentenceTransformer(model_path)
        return identified(DenseScorer(lambda texts: _model_call(model.encode, list(texts), batch_size=16,
                                                                normalize_embeddings=True),
                           cache=safe_cache("dense")), "dense")
    except Exception as exc:
        reasons.append("sentence_transformers 載不起：%s" % exc)
        problems.append(_plain_failure(exc, "語意模型載不起來"))
    for reason in reasons:
        print("  " + reason[:200], flush=True)
    _load_problem[0] = problems[0]
    return None


class Reranker(object):
    """bge-reranker-v2-m3：一次讀一對（改動句, 候選整段），給 0～1 的相關分數。
    跟 BGE-M3 不同，它不是各自算向量再比，而是兩段一起讀，比較準、也比較慢，所以只用在已經篩過的候選上。
    cache：PairCache（見 semantic_cache），同一對算過就不再算。"""

    def __init__(self, model, cache=None, batch_size=RERANKER_BATCH):
        self.model = model
        self.cache = cache
        self.batch_size = batch_size

    def score(self, pairs):
        pairs = [(q or "", p or "") for q, p in pairs]
        known = self.cache.get_many(pairs) if self.cache is not None else {}
        todo, queued = [], set()
        for pair in pairs:
            if pair not in known and pair not in queued:      # 用 set 去重：幾千對時 list 的 in 要幾千萬次比較
                todo.append(pair)
                queued.add(pair)
        if todo:
            scores = _model_call(self.model.compute_score, [list(pair) for pair in todo],
                                 batch_size=self.batch_size, normalize=True)
            if not isinstance(scores, list):
                scores = [scores]
            fresh = dict(zip(todo, (float(s) for s in scores)))
            known.update(fresh)
            if self.cache is not None:
                self.cache.put_many([(q, p, s) for (q, p), s in fresh.items()])
        return [known[pair] for pair in pairs]


def load_reranker(model_path, cache_dir=None, batch_size=RERANKER_BATCH):
    """載 bge-reranker-v2-m3（FlagEmbedding 的 FlagReranker）。載不起回 None 並印原因。"""
    import semantic_cache
    try:
        from FlagEmbedding import FlagReranker
        model = FlagReranker(model_path, use_fp16=False)
    except Exception as exc:
        print("  重排序模型載不起：%s" % str(exc)[:200], flush=True)
        return None
    return Reranker(model, cache=semantic_cache.open_cache(cache_dir, model_path, "rerank"),
                    batch_size=max(1, int(batch_size)))


def _sentence_units(text):
    """一段文字拆成 (正規化後的比對字串, 原文) 的單位清單：每一句，再加整段。

    順序很重要：**先切句、再正規化**。normalize_for_compare 會把「；」折成「;」，
    而 split_sentences 只認全形「。」「；」，先正規化就永遠切不開分號句
    （真資料 1,347 段裡有 50 段是這樣）。字面比對那邊也是切完才正規化。

    單句段落：那一句去掉句末標點就等於整段，只留整段一個單位，不重複算
    （不去重的話 1,347 段裡有 563 個單位是重的，白跑一倍時間，而且哪一個贏是隨機的）。
    原文留著給「語意依據」用——寫進產出檔的原文一律保留原字。
    """
    raw = strip_article_no(text or "").strip()
    whole = normalize_for_compare(raw)
    if not whole:
        return []
    whole_core = whole.rstrip("。;；.")
    units = []
    seen = set()
    for sent in fuzzy.split_sentences(raw):
        norm = normalize_for_compare(sent)
        if not norm or norm in seen or norm.rstrip("。;；.") == whole_core:
            continue
        seen.add(norm)
        units.append((norm, sent.strip()))
    units.append((whole, raw))
    return units


def _units_of(text):
    """全文每一段的比對單位（見 _sentence_units）。"""
    return _sentence_units(text)


def _query_units(change):
    """這一處異動拿什麼去比：有舊全文就取「改到的那幾句」，沒有（新增段、舊格式輸入）
    就用整段。整段永遠也放進去當備援，改動句對不上時整段仍有機會。
    回傳 (正規化字串, 原文) 清單，跟 _sentence_units 同型。"""
    raw_new = strip_article_no(change.get("全文") or "").strip()
    raw_old = strip_article_no(change.get("舊全文") or "").strip()
    whole = normalize_for_compare(raw_new)
    if not whole:
        return []
    whole_core = whole.rstrip("。;；.")
    units = []
    seen = set()
    if raw_old and raw_new:
        for sent in fuzzy.changed_sentences(raw_old, raw_new, diff_runs):
            norm = normalize_for_compare(sent)
            if not norm or norm in seen or norm.rstrip("。;；.") == whole_core:
                continue
            seen.add(norm)
            units.append((norm, sent.strip()))
    units.append((whole, raw_new))
    return units


def _clip(text, limit=30):
    # 「；」是決定表證據欄的分隔符（decision_table._merge），原文裡有的話換成「、」，
    # 不然那一格會被拆成好幾段。
    text = (text or "").strip().replace("；", "、").replace(";", "、")
    return text if len(text) <= limit else text[:limit] + "…"


def _basis(query_raw, hit_raw, whole_query, whole_hit):
    """「語意依據」的字：改動句／整段 對 命中句／整段。兩邊前 30 字一樣（孿生句只差句尾）
    時把命中句放寬到 60 字，不然看表的人看不出差在哪。"""
    left = "整段" if whole_query else "改動句「%s」" % _clip(query_raw)
    if whole_hit:
        right = "整段"
    else:
        hit_clip = _clip(hit_raw)
        if not whole_query and hit_clip == _clip(query_raw):
            hit_clip = _clip(hit_raw, 60)
        right = "「%s」" % hit_clip
    return "%s對%s" % (left, right)


def find_candidates(embed, changes, paragraphs, threshold=None, top=DEFAULT_TOP,
                    target_name="", reranker=None, rerank_threshold=None):
    """embed：向量函式或 scorer（見 as_scorer）。每筆異動用「改到的那幾句」（沒有舊全文就整段）
    去比全文每一段的每一句與整段，取最高分當這一段的分數；「語意依據」寫是哪一句對上哪一句。
    只有同本（「規章」空白或等於 target_name）且「段次」有效時才排除自己那一段。
    回傳 dict 列，欄位同 COLUMNS。

    reranker（Reranker，選用）：每處異動先多抓 RERANKER_POOL 倍的候選、算重排分數。只加不刪：
    BGE-M3 的前 top 筆全部留著，重排分數排進前 top 名、原本沒進來的再補上（所以一處最多 2×top 筆）；
    rerank_threshold 有給，補進來的那幾筆重排分數要到它才補。

    為什麼改成句對句：整段對整段時，改動的那幾個字被沒改的兩百字稀釋；字面比對那邊的
    句子層級早就證明過這件事（36.6 分 → 90.3 分），語意這一路照同樣的結構做。
    """
    scorer = as_scorer(embed)
    if threshold is None:
        threshold = getattr(scorer, "default_threshold", DEFAULT_THRESHOLD)
    texts = list(paragraphs)
    changes = [c for c in changes if (c.get("全文") or "").strip()]
    if not texts or not changes:
        return []
    # 全文所有單位攤平（正規化字串給模型、原文給依據欄），記住每個單位屬於第幾段
    doc_units, doc_raw, owner = [], [], []
    for j, text in enumerate(texts):
        for norm, raw in _units_of(text):
            doc_units.append(norm)
            doc_raw.append(raw)
            owner.append(j)
    if not doc_units:
        return []
    saved_key = _result_key(scorer, reranker, changes, texts, threshold, top, target_name, rerank_threshold)
    if saved_key:
        saved = scorer.cache.get_result(saved_key)
        if saved is not None:
            if not getattr(scorer, "_progress_silent", False):
                print("語意候選：%s內容和設定都沒變，沿用上次算好的結果" % ((target_name + " ") if target_name else ""))
            return saved
    change_units = [_query_units(c) for c in changes]
    flat_queries = [norm for units in change_units for norm, _raw in units]
    try:
        matrix = scorer.score(flat_queries, doc_units) if flat_queries else []
    except sqlite3.Error as exc:           # 向量快取算到一半壞了（磁碟滿、檔案壞掉）
        raise SemanticError("語意向量快取讀寫失敗（%s）" % exc) from exc
    pool = top * RERANKER_POOL if reranker is not None else top
    picked = []        # 每處異動：(change, units, idx, label, [(段索引, (分數, 查詢單位, 命中單位)) ...])
    cursor = 0
    for change, units in zip(changes, change_units):
        doc = (change.get("規章") or "").strip()
        same_doc = (not doc) or (doc == (target_name or ""))
        idx = int(change.get("段次") or 0) - 1 if same_doc else -1
        best = {}          # 段索引 -> (分數, 查詢單位索引, 命中單位索引)
        for qi in range(len(units)):
            row = matrix[cursor + qi]
            for k, score in enumerate(row):
                j = owner[k]
                if j == idx or score < threshold:
                    continue
                if j not in best or score > best[j][0]:
                    best[j] = (score, qi, k)
        cursor += len(units)
        label = change.get("條文ID", "")
        if not same_doc:
            label = "%s：%s" % (doc, label or ("段次 %s" % change.get("段次", "")))
        ranked = sorted(best.items(), key=lambda kv: (-kv[1][0], kv[0]))
        picked.append((change, units, idx, label, ranked[:pool]))
    # 重排序：全部異動的候選一次送進模型（分批由模型自己切），比一處一處送快
    rerank = {}
    if reranker is not None:
        pairs = [(units[qi][1], texts[j]) for _c, units, _i, _l, ranked in picked for j, (_s, qi, _k) in ranked]
        try:
            rerank = dict(zip(pairs, reranker.score(pairs)))
        except sqlite3.Error as exc:
            raise SemanticError("語意向量快取讀寫失敗（%s）" % exc) from exc
    rows = []
    for change, units, idx, label, ranked in picked:
        if reranker is None:
            ranked = ranked[:top]
        else:
            rr_of = lambda j, hit: rerank[(units[hit[1]][1], texts[j])]
            kept = ranked[:top]
            by_rerank = sorted(ranked, key=lambda jh: (-rr_of(*jh), -jh[1][0], jh[0]))[:top]
            seen = set(j for j, _hit in kept)
            added = [(j, hit) for j, hit in by_rerank if j not in seen
                     and (rerank_threshold is None or rr_of(j, hit) >= rerank_threshold)]
            ranked = sorted(kept + added, key=lambda jh: (-rr_of(*jh), -jh[1][0], jh[0]))
        whole_query_norm = units[-1][0] if units else ""
        for j, (score, qi, k) in ranked:
            # 整段那一個單位永遠排在清單最後（見 _sentence_units／_query_units）
            whole_hit = (doc_units[k] == _units_of(texts[j])[-1][0])
            whole_query = (units[qi][0] == whole_query_norm)
            # 講清楚是哪一種對法：改動句／整段 對 命中句／整段。四種寫法都要看得出來，
            # 看表的人才知道這一列是「那一句對上了」還是「整段大致像」。
            basis = _basis(units[qi][1], doc_raw[k], whole_query, whole_hit)
            rr = rerank.get((units[qi][1], texts[j]))
            rows.append({"異動段次": str(idx + 1) if idx >= 0 else "",
                         "異動全文": change["全文"], "候選段次": str(j + 1),
                         "候選全文": texts[j], "語意分數": "%.3f" % score,
                         "異動條文ID": label, "語意依據": basis,
                         "重排分數": "%.3f" % rr if rr is not None else ""})
    cache = getattr(scorer, "cache", None)         # 快取中途壞掉時 score 會把它關掉
    if saved_key and cache is not None:
        cache.put_result(saved_key, rows)
    return rows


def _result_key(scorer, reranker, changes, texts, threshold, top, target_name, rerank_threshold):
    """一本的語意結果的指紋（v1.59.2）：異動、全文、模型、門檻、筆數、程式版本全部一樣才沿用。
    逐字向量不存，以前同內容重跑還是要算十分鐘。沒有向量快取、或重排序沒有快取（認不出是哪個模型）就不存。"""
    cache = getattr(scorer, "cache", None)
    if cache is None or not hasattr(cache, "get_result"):
        return ""
    rerank_id = ""
    if reranker is not None:
        rerank_id = getattr(getattr(reranker, "cache", None), "model_key", "")
        if not rerank_id:
            return ""
    try:
        from workspace import SKILL_VERSION
    except ImportError:
        return ""
    identity = [SKILL_VERSION, cache.model_key, getattr(scorer, "weights", None), getattr(scorer, "rerank_top", None),
                getattr(scorer, "recall_top", None), threshold, top, target_name or "", rerank_id, rerank_threshold,
                changes, texts]
    text = json.dumps(identity, ensure_ascii=False, sort_keys=True, default=str)
    return hashlib.sha256(text.encode("utf-8", "surrogatepass")).hexdigest()


COUNT_MARK = "筆數="


def results_text(rows, draft_sha):
    """語意候選檔的內容。第一列第三格記總筆數，讀的時候才認得出半截（舊程式只看前兩格，讀得了新檔）。"""
    buffer = io.StringIO(newline="")
    writer = csv.writer(buffer)
    writer.writerow(["#草稿SHA256", draft_sha, "%s%d" % (COUNT_MARK, len(rows))])
    writer.writerow(COLUMNS)
    for row in rows:
        writer.writerow([row.get(c, "") for c in COLUMNS])
    return buffer.getvalue()


def write_results(path, rows, draft_sha):
    text = results_text(rows, draft_sha)
    with AtomicWrites() as aw:
        with io.open(aw.path(path), "w", encoding="utf-8-sig", newline="") as f:
            f.write(text)


def _unfinished(path, why):
    return SemanticError("語意候選檔沒寫完（%s，%s）：這一本要重算語意，或這一輪不做就跑 語意併入 --略過"
                         % (os.path.basename(path), why))


def _cut_inside_a_character(path):
    """UTF-8 的檔斷在一個字中間：是沒寫完，不是編碼問題。"""
    with open(path, "rb") as f:
        raw = f.read()
    if not raw.startswith(codecs.BOM_UTF8):
        return False
    try:
        raw.decode("utf-8-sig")
    except UnicodeDecodeError as exc:
        return exc.reason == "unexpected end of data"
    return False


def read_results(path, expected_sha=None):
    if not os.path.isfile(path):
        raise SemanticError("找不到語意候選檔：%s" % path)
    # 以前寫死 utf-8-sig：人用 Excel 開過再存成「CSV（逗號分隔）」（Big5）就噴
    # UnicodeDecodeError 的 traceback（第三批）。改走 _common.read_csv_text（UTF-8／Big5 都認），
    # 認不出來一律轉成 SemanticError，呼叫端照樣印「[中止]」加一句怎麼修。
    from _common import InputError, read_csv_text
    try:
        if _cut_inside_a_character(path):
            raise _unfinished(path, "結尾斷在一個字中間")
        text, _ = read_csv_text(path)
    except InputError as exc:
        raise SemanticError("語意候選檔讀不出來：%s" % exc)
    except OSError as exc:
        raise SemanticError("語意候選檔打不開：%s（%s）" % (path, exc))
    reader = csv.reader(io.StringIO(text, newline=""))        # 結尾沒換行不算壞：有些工具另存就是這樣
    try:
        first = next(reader, None)
        if not first or first[0] != "#草稿SHA256" or len(first) < 2:
            raise SemanticError("語意候選.csv 第一列應為「#草稿SHA256,<指紋>」兩格")
        if expected_sha and first[1] != expected_sha:
            raise SemanticError("語意候選是對另一份草稿算的，指紋不符，不能併入")
        header = next(reader, None)
        if header not in (COLUMNS, COLUMNS[:7], LEGACY_COLUMNS):
            raise SemanticError("語意候選.csv 欄位不符，應為：%s" % "、".join(COLUMNS))
        rows = []
        last = header
        for r in reader:
            if not r:
                continue
            last = r
            row = dict(zip(COLUMNS, r))
            row.setdefault("語意依據", "")      # 六欄、七欄的舊檔補空
            row.setdefault("重排分數", "")
            rows.append(row)
    except csv.Error as exc:
        raise SemanticError("語意候選.csv 格式壞了（%s）：請重新產生，或用 Excel 另存成「CSV UTF-8（逗號分隔）」"
                            % exc)
    if len(last) < len(header):
        raise _unfinished(path, "最後一列少了幾欄")
    # 舊檔第一列只有兩格：沒有筆數可比，只靠上面兩項
    count = re.fullmatch(re.escape(COUNT_MARK) + r"(\d+)", first[2]) if len(first) > 2 else None
    if count and int(count.group(1)) != len(rows):
        # 少列也可能是人手動刪的、多列是人手動加的：只講對不上，不猜原因
        raise SemanticError("語意候選檔筆數對不上（%s，第一列記 %s 列、實際 %d 列）：這一本要重算語意，或這一輪不做就跑 語意併入 --略過"
                            % (os.path.basename(path), count.group(1), len(rows)))
    return rows


def check_environment(configured="", rerank_configured="", workspace="", folder="", exchange="", say=None):
    """SKILL.md「唯一等待例外」的第一階段：只檢查這台電腦能不能跑 BGE-M3（套件 import 得起來、模型在哪、模型檔完不完整），不載模型。
    能跑印出算語意的指令、回 0；不能跑講清楚缺什麼、回 2（呼叫端照 SKILL.md 說明本機無法執行）。
    以前 run_all 的人工待辦只寫「先檢查這台電腦能不能跑」，沒有任何指令，AI 只能用猜的。"""
    import importlib
    say = say or (lambda text: print(text, flush=True))
    have = {}
    for module in ("torch", "FlagEmbedding", "sentence_transformers"):
        try:
            importlib.import_module(module)
            have[module] = True
        except Exception:          # 套件裝壞時 import 可能丟各種例外，檢查本身不能掛
            have[module] = False
    mark = lambda ok: "✓ 有" if ok else "－ 無"
    say("BGE-M3 環境檢查（Python %s，只檢查、不載模型）" % sys.version.split()[0])
    say("  %s torch（PyTorch）" % mark(have["torch"]))
    say("  %s FlagEmbedding（三分數合併，建議）" % mark(have["FlagEmbedding"]))
    say("  %s sentence-transformers（只有 dense 的備援）" % mark(have["sentence_transformers"]))
    model = find_local_model(configured)
    rerank = find_local_model(rerank_configured, RERANKER_NAME)
    broken = weights_problem(model) if model else ""
    rerank_broken = weights_problem(rerank) if rerank else ""
    say("  %s BGE-M3 模型：%s" % ("✗ 壞了" if broken else mark(model), ("%s（%s）" % (model, broken)) if broken else model or
                                 "設定.html「語意模型路徑」沒填或路徑不在，常見位置也沒有（skill 旁邊或家目錄的 models/bge-m3、Hugging Face 快取）"))
    say("  %s %s 模型（選用，設定.html「語意重排序」有勾才用）：%s"
        % ("✗ 壞了" if rerank_broken else mark(rerank), RERANKER_NAME,
           ("%s（%s）" % (rerank, rerank_broken)) if rerank_broken else rerank or "沒有"))
    if rerank_broken:
        rerank = ""
    missing = []
    if not have["torch"]:
        missing.append("缺套件 torch")
    if not (have["FlagEmbedding"] or have["sentence_transformers"]):
        missing.append("缺套件 FlagEmbedding（或 sentence-transformers）")
    if not model:
        missing.append("找不到 BGE-M3 模型資料夾")
    if broken:
        missing.append(broken)
    import semantic_memory as sm
    if missing:
        say("結論：這台電腦無法執行 BGE-M3（%s）。" % "、".join(missing))
        say("      跟使用者說明本機無法執行；使用者說「繼續」就略過語意（run_all.py 語意併入 --略過），完成其餘流程。")
        if sm.remember("缺套件" if missing[0].startswith("缺套件") else "模型壞了" if broken else "沒有模型"):
            say("      已記住：下一個工作區不再試。模型裝好會自動恢復；要馬上重試就在 開始／繼續／體檢 加 --重試語意。")
        return 2
    sm.forget()
    if workspace:
        target = '--workspace "%s"' % workspace
    elif folder:
        target = '--folder "%s"' % folder
    elif exchange:
        target = '--交換包 "%s"' % exchange
    else:
        target = '--workspace "<工作區>"'
    say("結論：這台電腦可以執行 BGE-M3。算語意的指令：")
    say('  python scripts/semantic_candidates.py %s --model "%s"%s'
        % (target, model, (' --rerank --rerank-model "%s"' % rerank) if rerank else ""))
    if rerank:
        say("  （設定.html「語意重排序」沒勾就把 --rerank --rerank-model 拿掉）")
    say("  算完再跑 python scripts/run_all.py 繼續（會把語意候選併入）")
    return 0


def main(argv=None):
    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass
    parser = argparse.ArgumentParser(description="BGE-M3 語意候選")
    parser.add_argument("--交換包", "--exchange", dest="exchange", default=None,
                        help="批次的 語意交換包.zip：算完每一本，結果寫回同一個檔（門檻等參數照包裡記的）")
    parser.add_argument("input_json", nargs="?", help="一本的語意輸入.json（跟 output_csv 一起給）")
    parser.add_argument("output_csv", nargs="?")
    parser.add_argument("--workspace", default=None,
                        help="工作區資料夾：一次算完 產出/2_Log檔案/語意候選/ 裡的每一本，"
                             "向量快取自動用 skill 資料夾的 memoization/")
    parser.add_argument("--folder", default=None,
                        help="語意候選資料夾：一次算完裡面每一個 <規章名>_語意輸入.json，結果寫成同資料夾的 <規章名>.csv")
    parser.add_argument("--model", default="", help="BGE-M3 模型資料夾（--檢查 時可以不給：自動找）")
    parser.add_argument("--檢查", "--check", dest="check", action="store_true",
                        help="只檢查這台電腦能不能跑：套件 import 得起來、BGE-M3（與重排序）模型在哪、模型檔完不完整，不載模型；"
                             "能跑就印出算語意的指令（SKILL.md「唯一等待例外」的第一階段）")
    parser.add_argument("--threshold", type=float, default=None,
                        help="語意分數門檻；不給就依分數方式用預設（三分數 %.2f、只有 dense %.2f）"
                             % (DEFAULT_THRESHOLD, DENSE_ONLY_THRESHOLD))
    parser.add_argument("--top", type=int, default=None, help="每個異動最多幾筆（預設 %d）" % DEFAULT_TOP)
    parser.add_argument("--cache", default=None,
                        help="向量快取資料夾（預設 skill 資料夾的 memoization/）；給了就沿用算過的向量，沒改的段落不重算"
                             "（沒給就用這台 skill 的 memoization/）")
    parser.add_argument("--rerank", action="store_true",
                        help="用 %s 重排序（模型自動找，或用 --rerank-model 指定）" % RERANKER_NAME)
    parser.add_argument("--rerank-model", default="", help="重排序模型資料夾")
    parser.add_argument("--rerank-threshold", type=float, default=None,
                        help="重排序補進來的候選，重排分數至少要這麼多；不給就排進前幾名就補")
    parser.add_argument("--recall-top", type=int, default=None,
                        help="粗篩：先用純語意排一遍、只對前 N 名算三種分數（快一倍，理論上可能漏）；"
                             "不給就全排名（預設，不會漏）")
    args = parser.parse_args(argv)
    if args.check:
        return check_environment(args.model, args.rerank_model, workspace=args.workspace,
                                 folder=args.folder, exchange=args.exchange)
    if not args.model:
        parser.error("要給 --model <BGE-M3 模型資料夾>（先跑 --檢查 可以看這台電腦找得到哪一份）")
    if args.exchange:
        import semantic_exchange as se
        return se.compute(args.exchange, args.model, cache_dir=args.cache, threshold=args.threshold,
                          top=args.top, recall_top=args.recall_top,
                          say=lambda text: print(text, flush=True),
                          rerank=True if args.rerank else None, rerank_model=args.rerank_model,
                          rerank_threshold=args.rerank_threshold)
    args.top = args.top or DEFAULT_TOP
    cache_dir = args.cache
    folder = args.folder
    if args.workspace:
        # 一律用工作區裡的相對位置：指令裡不寫哪一台電腦的完整路徑，複製到別台照樣能跑
        import batch as bt
        import workspace as wsm
        # 跟 run_all 的各指令一樣：只給名稱（…/內規工作區）就用最新的 <名稱>yyyymmddnn
        # （以前直接拿名稱當資料夾，日期序號工作區一律回「沒有目前作業」）
        root = wsm.paths(wsm.resolve_root(args.workspace, {}))["產出"]
        if not root or not os.path.isdir(root):
            print("[中止] 工作區沒有目前作業；先跑 開始 建立 產出YYYYMMDDNNN", flush=True)
            return 1
        from _common import SYSTEM_DIR
        folder = os.path.join(root, SYSTEM_DIR, "語意候選")
        cache_dir = cache_dir or bt.cache_dir(root) or None
    if folder:
        if not os.path.isdir(folder):
            print("[中止] 找不到語意候選資料夾：%s" % folder, flush=True)
            return 1
        suffix = "_語意輸入.json"
        jobs = [(os.path.join(folder, name), os.path.join(folder, name[:-len(suffix)] + ".csv"))
                for name in sorted(os.listdir(folder)) if name.endswith(suffix)]
        if not jobs:
            print("[中止] %s 裡沒有任何 <規章名>_語意輸入.json" % folder, flush=True)
            return 1
    elif args.input_json and args.output_csv:
        jobs = [(args.input_json, args.output_csv)]
    else:
        parser.error("要給 --交換包、--workspace、--folder，或 語意輸入.json 與 語意候選.csv 兩個檔名")
    inputs = []
    for input_path, output_path in jobs:
        try:
            inputs.append((read_input(input_path), output_path))
        except SemanticError as exc:
            print("[中止] %s" % exc, flush=True)
            return 1
    print("載入模型：%s" % args.model, flush=True)
    scorer = load_model(args.model, recall_top=args.recall_top, cache_dir=cache_dir)
    import semantic_memory as sm
    if scorer is None:
        print("[跳過] 這個環境載不起 BGE-M3。請在有模型的電腦執行這支程式，再把結果交回。", flush=True)
        sm.remember(sm.classify(last_problem() or "語意模型載不起來"))
        return 2
    if isinstance(scorer, HybridScorer):
        mode = "三分數合併（dense／sparse／colbert），%s" % (
            "全排名" if not scorer.recall_top else "先用純語意粗篩前 %d 名" % scorer.recall_top)
    else:
        mode = "只有 dense（sentence_transformers）"
    print("分數方式：%s" % mode, flush=True)
    estimate_inputs(scorer, [data for data, _ in inputs])
    used = args.threshold if args.threshold is not None else getattr(scorer, "default_threshold", DEFAULT_THRESHOLD)
    reranker = None
    if args.rerank:
        rerank_path = find_local_model(args.rerank_model, RERANKER_NAME)
        reranker = load_reranker(rerank_path, cache_dir) if rerank_path else None
        if reranker is None:
            print("[中止] 要重排序，但這台電腦找不到或載不起 %s" % RERANKER_NAME, flush=True)
            return 2
        print("重排序：%s" % rerank_path, flush=True)
    finished = 0
    for data, output_path in inputs:
        try:
            rows = find_candidates(scorer, data["異動"], data["段落"], args.threshold, args.top,
                                   data.get("目標規章", ""), reranker=reranker,
                                   rerank_threshold=args.rerank_threshold)
        except SemanticError as exc:
            print("[跳過] %s。算好的 %d 本留著；其他本修好再跑一次這個指令，或這一輪不做就跑 語意併入 --略過"
                  % (exc, finished), flush=True)
            sm.remember(sm.classify(str(exc)))
            return 2
        write_results(output_path, rows, data["草稿"]["SHA256"])
        finished += 1
        print("%s語意候選 %d 列（門檻 %.2f）：%s"
              % (("%s：" % data["目標規章"]) if data.get("目標規章") else "", len(rows), used, output_path),
              flush=True)
    sm.forget()                          # 算得起來：這台不再算失敗
    if folder:
        if os.environ.get("REG_WAREHOUSE_RELAY") == "1":
            print("算完 %d 本。回到隔離區送 執行 繼續" % len(inputs), flush=True)
        else:
            print("算完 %d 本。把結果帶回原本那台電腦（放回同一個位置），跑 語意併入" % len(inputs), flush=True)
    cache = getattr(scorer, "cache", None)
    if cache is not None:
        print("向量快取：沿用 %d 個、新算 %d 個（%s）" % (cache.hits, cache.misses, cache.path), flush=True)
    return 0


if __name__ == "__main__":
    sys.exit(main())
