# -*- coding: utf-8 -*-
"""
跨工作區的 AI 答案庫（v1.20.0）：memoization/內部知識/AI答案庫.json。

本來 AI 判過的答案只沿用「同一個工作區的上一輪」。同一本手冊換一個工作區再比對、再體檢，
一模一樣的字又要 AI 重判一次。這裡把匯入過的答案照「審的內容指紋」（每張 AI 表最後那一欄）存起來，
任何工作區打包時，這一列在本工作區找不到答案，就從答案庫帶：指紋一樣＝審的字一模一樣。

安全規則：
- 只帶同單位的：讀答案庫的路（比對、錯漏字、一致性）都走 get，倉庫過濾也用同一個 readable（v1.54.0）。
- 只存匯入驗過、整份沒有過期列的答案。
- 理由裡寫了段次（段732）而這一列段次不一樣的不帶：段次換了，理由指的那一段可能不是同一段。
- 外部引用不走這裡（查證有有效天數，見 verify_cache）。

答案庫是本單位資料：打包分享時照使用者選擇決定要不要包。
"""

import datetime
import io
import json
import os
import re
from file_replace import replace_file

FILE = "AI答案庫.json"
LIMIT = 20000                     # 每張表最多記幾則，超過丟最舊的
# v1.22.0：理由指到別處的寫法。「段次45」「第45段」「序號13」以前沒認出來；C3、R5 這種編號每一輪重編，
# 跨輪、跨工作區帶回去會被報告換成這一輪另一處的段次（審查 比對#1、共用#6、體檢#8）
_LINE_RE = re.compile(r"段次?\s*[0-9０-９]+|第\s*[0-9０-９]+\s*段|序號\s*[0-9０-９]+")
_ID_RE = re.compile(r"(?<![A-Za-z0-9])[CRKEPT][0-9]+(?:-[0-9]+)?(?![0-9])")


def _texts(answers):
    return [v for v in (answers or {}).values() if isinstance(v, str)]


def points_elsewhere(answers, spot, old_spot, ids=True):
    """理由寫了段次（而這一列段次跟當時不一樣），或寫了每一輪會重編的編號（ids）：帶回去會指錯地方。"""
    texts = _texts(answers)
    if ids and any(_ID_RE.search(v) for v in texts):
        return True
    return str(spot or "").strip() != str(old_spot or "").strip() and any(_LINE_RE.search(v) for v in texts)


_cache = {}
KEEP_DAYS = 365                   # v1.22.0：存了超過一年的答案不帶（上位法規、本單位作法都可能變了）


def path():
    import precedents as pc
    return os.path.join(pc.folder(), FILE)


def _load():
    import precedents as pc
    key = path()
    if key not in _cache:
        _cache[key] = pc.read_json(key, {})       # 記事本存的 BOM 也收；壞檔改名留著，不蓋掉
    return _cache[key]


def _flush(changed=None):
    """寫回答案庫。changed＝{表: {指紋: 列}}：先重讀檔案再把這一次記的併進去——兩個視窗同時跑
    （兩個工作區），以前後存的整份蓋掉先存的（審查 共用#9）。"""
    import precedents as pc
    key = path()
    data = _cache.get(key)
    if data is None:
        return
    if changed:
        latest = pc.read_json(key, {})
        for table, items in changed.items():
            latest.setdefault(table, {}).update(items)
        data = _cache[key] = latest
    os.makedirs(os.path.dirname(key), exist_ok=True)
    with io.open(key + ".tmp", "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, separators=(",", ":"))
    replace_file(key + ".tmp", key)


def reset_cache():
    _cache.clear()


SETTING = "跨工作區沿用AI答案"
SKIP_ENV = "REG_NO_ANSWER_BANK"       # 測試用：舊測試共用一個快取資料夾，不能互相帶答案


def enabled(settings=None):
    """設定.html「跨工作區沿用AI答案」：沒寫（舊版設定頁）＝開。"""
    if os.environ.get(SKIP_ENV) == "1":
        return False
    if settings is None:
        try:
            from _common import config_section
            settings = config_section("設定")
        except Exception:
            settings = {}
    value = (settings or {}).get(SETTING)
    if isinstance(value, str):
        return value.strip().lower() not in ("false", "0", "否", "關", "no", "off")
    return value is None or bool(value)


def unit_tag(settings=None, workspace=None):
    """單位類型、業務範圍及工作區已回答事實的指紋；讀不到事實回 None。workspace 沒給用目前工作區。
    v1.54.0：單位類型或業務範圍空白＝不確定是哪個單位，回 None（不存也不帶）。
    以前兩邊都空白算出同一個指紋，別單位的「沒問題」就這樣帶過來，而沒問題的列報告預設收起來。"""
    import hashlib
    if settings is None:
        try:
            from _common import config_section
            settings = config_section("設定")
        except Exception:
            settings = {}
    kind, scope = (settings or {}).get("法規機構類型") or "", (settings or {}).get("法規業務範圍") or ""
    if not str(kind).strip() or not str(scope).strip():
        return None
    text = "%s|%s" % (kind, scope)
    import law_impact as li
    import unit_facts as uf
    try:
        facts = li.facts_tag(uf.current_workspace() if workspace is None else workspace)
    except li.ImpactError:
        return None
    if facts:
        text += "|" + facts
    return ("facts:" if facts else "") + hashlib.sha1(text.encode("utf-8")).hexdigest()[:8]


_REMINDED = set()


def _remind_blank():
    """單位沒填完時答案庫停用：同一支程式只講一次，不要靜靜停掉。"""
    try:
        from _common import config_section
        settings = config_section("設定")
    except Exception:
        settings = {}
    missing = [name for key, name in (("法規機構類型", "單位類型"), ("法規業務範圍", "業務範圍"))
               if not str((settings or {}).get(key) or "").strip()]
    if missing and "空白" not in _REMINDED:
        _REMINDED.add("空白")
        print("提醒：設定頁的%s還沒填，分不出是哪個單位，AI 答案庫這一輪不存也不帶（別的工作區判過的要重判）；填好就恢復"
              % "、".join(missing), flush=True)


def readable(entry, unit):
    """答案庫這一筆能不能給這個單位（unit_tag 的結果）用。要嚴過判例：判例只是參考，
    這裡的答案會直接當成結果，沒標單位（很舊）、單位不確定的都不帶，AI 重判就好。"""
    return bool(unit) and isinstance(entry, dict) and entry.get("單位") == unit


def _own_slot(sha, unit):
    """同一個指紋別的單位已經占著時，這個單位的答案放的鍵（帶回時 memo_merge 也用這個寫法）。"""
    return "%s@%s" % (sha, unit)


def save(table, items):
    """items＝[(指紋, 段次, {欄: 答案})]。回傳新記幾則。"""
    from _common import tw_now, tw_today
    if not enabled():
        return 0
    unit = unit_tag()
    if unit is None:
        _remind_blank()
        return 0
    data = _load()
    shelf = data.setdefault(table, {})
    today = tw_today().isoformat()
    added, changed = 0, {}
    for sha, spot, answers in items:
        sha = (sha or "").strip()
        answers = dict((k, v) for k, v in (answers or {}).items() if isinstance(v, (str, list)))
        if not sha or not any((v if isinstance(v, str) else v) for v in answers.values()):
            continue
        # v1.54.0：同一段字別的單位也判過：那一筆不能蓋掉，這個單位的另外放
        if shelf.get(sha, {}).get("單位") not in (None, unit) or _own_slot(sha, unit) in shelf:
            sha = _own_slot(sha, unit)
        added += (shelf.get(sha, {}).get("答案") != answers or shelf.get(sha, {}).get("單位") != unit)
        shelf[sha] = changed.setdefault(table, {})[sha] = {"段次": str(spot or "").strip(), "答案": answers,
                                                         "日期": today, "單位": unit}
    if added:
        _flush(changed)
        shelf = _load().setdefault(table, {})
    if len(shelf) > LIMIT:
        for sha, _entry in sorted(shelf.items(), key=lambda kv: kv[1].get("日期", ""))[:len(shelf) - LIMIT]:
            del shelf[sha]
        _flush()
    return added


def get(table, sha, spot=""):
    """答案庫裡這個指紋的答案（dict），沒有或不能帶回 None。"""
    from _common import tw_now, tw_today
    if not enabled():
        return None
    unit = unit_tag()
    if unit is None:
        return None
    shelf = _load().get(table, {})
    sha = (sha or "").strip()
    entry = shelf.get(_own_slot(sha, unit)) or shelf.get(sha)
    if not entry or not readable(entry, unit):
        return None                               # 別單位，或基本資料、承辦回答改過了
    try:
        age = (tw_today() - datetime.date.fromisoformat(entry.get("日期", "")[:10])).days
    except ValueError:
        age = 0
    if age > KEEP_DAYS:
        return None
    answers = entry.get("答案") or {}
    if points_elsewhere(answers, spot, entry.get("段次", "")):
        return None
    return dict(answers)


def count(table=None):
    data = _load()
    return sum(len(v) for k, v in data.items() if table in (None, k))


# ---------------------------------------------------------------------------
# 從匯入完的表收答案
# ---------------------------------------------------------------------------

def _read_csv(file_path):
    import csv
    from _common import open_csv
    if not file_path or not os.path.isfile(file_path):
        return []
    try:
        with open_csv(file_path) as f:
            return [dict(((k or "").strip(), v or "") for k, v in row.items()) for row in csv.DictReader(f)]
    except (OSError, UnicodeDecodeError, csv.Error, ValueError):
        return []


def harvest_compare(outdir):
    """比對每一本匯入完：AI候選判斷、AI異動審查、AI條文檢查 三張表的答案進答案庫。"""
    import review_pack as rp
    from _common import locate
    tables = [("AI候選判斷.csv", rp.CAND_SHA_COLUMN, "候選段次", rp.AI_ANSWER_COLUMNS),
              ("AI異動審查.csv", rp.CHANGE_SHA_COLUMN, "新版段次", rp.AI_ANSWER_COLUMNS + ("查證來源",)),
              (rp.RULECHECK_FILE, rp.RULECHECK_HEADER[-1], rp.RULECHECK_HEADER[1], ("AI判斷", "AI理由", "查證來源"))]
    added = 0
    for name, sha_column, spot_column, columns in tables:
        items = []
        for row in _read_csv(locate(outdir, name)[0]):
            if row.get("沿用查證", "").strip():
                continue
            answers = dict((c, row.get(c, "").strip()) for c in columns)
            if answers.get("AI判斷"):
                items.append((row.get(sha_column, ""), row.get(spot_column, ""), answers))
        added += save(name, items)
    return added
