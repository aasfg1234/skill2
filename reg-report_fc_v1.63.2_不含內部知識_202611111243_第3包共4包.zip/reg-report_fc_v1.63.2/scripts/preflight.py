"""隔離環境開跑前檢查，及開發用的程式檔清單。"""
import csv
import json
import os
from pathlib import Path

import workspace
import workspace_transfer as transfer

LIST = "scripts/程式清單.json"
CHECKED = {"cmd_start", "cmd_continue", "cmd_health", "cmd_law_start",
           "cmd_batch_review_pack", "cmd_batch_review_import", "cmd_batch_semantic",
           "cmd_law_changed", "cmd_feedback", "cmd_unit_profile", "cmd_library"}


def should_check(args):
    return getattr(args.func, "__name__", "") in CHECKED or getattr(args, "law_action", "") in {
        "start", "supplement", "import", "continue", "report"}


def program_list():
    paths, _, _ = transfer._program_files()
    return sorted(name for name in paths if not name.startswith("資料庫/")
                  or name == "資料庫/（說明）怎麼放.txt")


def update_command(args, settings):
    path = transfer._program_dir() / LIST
    names = sorted(set(program_list()) | {LIST})
    path.write_text(json.dumps(names, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print("更新程式清單：%d 個檔" % len(names))
    return 0


def collect(args, settings, check_manifest=False):
    root = Path(workspace.resolve_root(getattr(args, "workspace", ""), settings))
    skill = transfer._program_dir()
    missing = {"程式": [], "累積資料": [], "工作區": []}
    path = skill / LIST
    if not path.is_file():
        missing["程式"].append(LIST)
    else:
        names = json.loads(path.read_text(encoding="utf-8"))
        if not isinstance(names, list) or any(not isinstance(n, str) or not transfer._safe(n) for n in names):
            raise ValueError("程式清單格式不正確")
        missing["程式"].extend(n for n in names if not (skill / n).is_file())
    baseline = transfer._baseline(root) or {}
    first = {name[len(transfer.MEMO):].split("/", 1)[0] for name in baseline if name.startswith(transfer.MEMO)}
    # SQLite 自動清除交易期間的暫存檔，不能把它當成必備的累積資料。
    transient = (".sqlite-journal", ".sqlite-wal", ".sqlite-shm")
    missing["累積資料"].extend(sorted(n for n in first if n and not n.casefold().endswith(transient)
                                    and not (transfer._memo_dir() / n).exists()))
    for filename, field in (("目前作業.json", "目前作業"), ("法規作業.json", "目前法規作業")):
        path = root / filename
        if path.is_file():
            value = json.loads(path.read_text(encoding="utf-8"))
            folder = value.get(field, "")
            if isinstance(folder, str) and folder and not (root / folder).is_dir():
                missing["工作區"].append(folder)
    manifest = root / "匯入" / "規章清單.csv"
    if check_manifest and manifest.is_file():
        from _common import open_csv
        with open_csv(str(manifest)) as f:
            for row in csv.DictReader(f):
                for field in ("舊版", "新版草稿"):
                    name = (row.get(field) or "").strip()
                    if name and not (manifest.parent / name).is_file():
                        missing["工作區"].append("匯入/" + name)
    for category in missing:
        missing[category] = sorted(set(missing[category]))
    return missing


def print_missing(missing):
    count = sum(map(len, missing.values()))
    details = "；".join("%s %s%s" % (key, "、".join(values[:10]), "…" if len(values) > 10 else "")
                       for key, values in missing.items() if values)
    print("[缺檔] 少了 %d 個，還沒開始做：%s。不要手動補單一檔案：照 references/隔離環境.md 同步一輪（這邊給清單時會把缺的寫進去，對方打包會補送）；打包加 --連同程式 --連同累積資料；要略過這個檢查設 REG_NO_PREFLIGHT=1。" % (count, details))


def check_command(args, settings):
    missing = collect(args, settings, getattr(args, "check_manifest", False))
    if any(missing.values()):
        print_missing(missing)
        return 1
    print("[帶齊了] 檢查的檔案都在。")
    return 0
