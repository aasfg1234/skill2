"""三方合併本機及倉庫的累積資料；呼叫端須確保同時只有一個合併作業。"""
import csv
import datetime
import fnmatch
import hashlib
import io
import json
import os
import re
from pathlib import Path
import tempfile
from file_replace import replace_file


# 格式表的值依序為：類型、清單或 CSV 的鍵欄位、可信日期欄位。
FORMATS = {
    "設定已問過.json": ("whole", None, "時間"),
    "AI查證紀錄.json": ("object", None, "日期"),
    "法規追蹤/候選快取.json": ("object", None, None),
    "法規追蹤/適用判斷.json": ("object", None, None),
    "法規追蹤/重複公告.json": ("object", None, None),
    "內部知識/套語.json": ("object", None, None),
    "法規追蹤/法規版本表.json": ("object", None, "最新修正日"),
    "法規追蹤/追蹤期間.json": ("object", None, "迄日"),
    "法規追蹤/網頁快取/索引.json": ("object", None, None),
    "法規追蹤/清單快取.json": ("object", None, "完整讀取日"),
    "內部知識/AI答案庫.json": ("nested", None, "日期"),
    "內部知識/法規適用經驗.json": ("history", "事件指紋", None),
    "內部知識/判例.json": ("list", "鍵", "記錄時間"),
    "內部知識/錯漏字白名單.json": ("list", "詞", None),
    "內部知識/報告審查經驗.json": ("list", "鍵", None),
    "法規追蹤/補查紀錄.json": ("list", "查了什麼", "查詢日期"),
    "內部知識/判斷準則.json": ("rules", "代號", "更新時間"),
    "S8_外部規章表.csv": ("csv", "規章名", None),
    "外部規章排除表.csv": ("csv", "名稱", None),
    "法規追蹤/*/已審查.json": ("reviewed", None, None),
}
# 抓得回來的快取：兩邊都變了選較新的就好，不留原文（一份上千列，每次合併多寫好幾 MB）
NO_CONFLICT_NOTE = ("法規追蹤/清單快取.json",)
BASE_NAME = "_同步基準.json"
CONFLICT_NAME = "_合併衝突.jsonl"       # v1.54.0：只放本機。裡面是兩邊的原文，放倉庫 AI 就看得到別單位的內容
JOURNAL_NAME = "_同步交易.json"
LOCK_NAME = "_累積資料合併.lock"
_MISSING = object()
_WHOLE = "$whole"
# v1.54.0：這幾個檔的條目有單位。倉庫濾掉別單位的條目後，隔離區可能用同一個鍵寫自己的；兩筆是不同單位的東西，
# 不能當成衝突二選一。判斷看條目的「單位」不看鍵：業務範圍微調還是同單位，不會多一筆。
_WORDS = "內部知識/錯漏字白名單.json"
_BANK = "內部知識/AI答案庫.json"
_RULES = "內部知識/判斷準則.json"
_CASES = {"內部知識/判例.json": "鍵", "內部知識/報告審查經驗.json": "鍵"}


def vector_file(name):
    """語意向量快取和它的改名副本（「語意向量 - 複製.sqlite」、-journal）。v1.59.2 起裡面有規章全文，
    不分工作區、單位，一律不進倉庫。累積資料裡沒有別的 sqlite 檔。"""
    return ".sqlite" in name.replace("\\", "/").rsplit("/", 1)[-1].casefold()


def _excluded(name):
    # 語意速度.json（v1.47.1）：每台電腦各記各的速度，本機和隔離區各留一份，不合併
    # （以前不認得它，兩邊不同就在本機視窗印「累積資料不認得」，新手看不懂）
    return any(vector_file(p) or p == "語意速度.json" or p.endswith("備份")
               or re.search(r"（收回前本機版\d*）(?:\.[^.]*)?$", p)
               or p in (BASE_NAME, CONFLICT_NAME, JOURNAL_NAME, LOCK_NAME) for p in name.split("/"))


def _review_key(section, key):
    return json.dumps([section, key], ensure_ascii=False, separators=(",", ":"))


def _files(root):
    if not root.exists():
        return {}
    result = {}
    for path in root.rglob("*"):
        if path.is_symlink():
            raise ValueError("不支援連結：" + str(path))
        if path.is_file():
            name = path.relative_to(root).as_posix()
            if not _excluded(name):
                result[name] = path
    return result


def _format(name):
    return next((spec for pattern, spec in FORMATS.items()
                 if fnmatch.fnmatchcase(name, pattern)), None)


def _encoded(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False).encode("utf-8")


def _fingerprint(value):
    return hashlib.sha256(_encoded(value)).hexdigest()


def _read(path, spec):
    if path is None:
        return {}
    kind, key_field, _ = spec
    if kind == "csv":
        raw = path.read_bytes()
        try:
            text = raw.decode("utf-8-sig")
        except UnicodeDecodeError:
            text = raw.decode("cp950")
        reader = csv.DictReader(io.StringIO(text, newline=""), strict=True)
        if not reader.fieldnames or key_field not in reader.fieldnames or len(set(reader.fieldnames)) != len(reader.fieldnames):
            raise ValueError("CSV 欄位錯誤")
        result = {}
        for row in reader:
            key = row.get(key_field)
            if not key or None in row or any(v is None for v in row.values()):
                raise ValueError("CSV 列缺少鍵或欄位不符")
            if key in result and result[key] != row:
                raise ValueError("CSV 的鍵重複：" + key)
            result[key] = row
        return result
    value = json.loads(path.read_text(encoding="utf-8-sig"),
                       parse_constant=lambda x: (_ for _ in ()).throw(ValueError("不合法數字：" + x)))
    if kind == "rules":
        import precedents
        if not isinstance(value, dict) or not isinstance(value.get("準則"), list):
            raise ValueError("判斷準則格式錯誤")
        result = {}
        for item in value["準則"]:
            if not isinstance(item, dict) or not isinstance(item.get("編號"), str):
                raise ValueError("準則缺少編號")
            item = dict(item)
            item["代號"] = item.get("代號") or precedents.rule_id(item)
            if item["代號"] in result:
                raise ValueError("準則代號重複")
            result[item["代號"]] = item
        return result
    if kind in ("nested", "history"):
        if not isinstance(value, dict):
            raise ValueError("巢狀資料須為物件")
        result = {}
        for section, entries in value.items():
            if kind == "nested" and isinstance(entries, dict):
                pairs = entries.items()
            elif kind == "history" and isinstance(entries, list):
                if any(not isinstance(row, dict) or not isinstance(row.get(key_field), str) for row in entries):
                    raise ValueError("適用經驗缺少事件指紋")
                pairs = ((row[key_field], row) for row in entries)
            else:
                raise ValueError("巢狀資料格式錯誤")
            for key, item in pairs:
                composite = _review_key(section, key)
                if composite in result:
                    raise ValueError("巢狀資料鍵重複")
                result[composite] = item
        return result
    if kind == "reviewed":
        if not isinstance(value, dict):
            raise ValueError("已審查資料須為物件")
        result = {}
        for section, entries in value.items():
            if section == "events":
                if not isinstance(entries, list):
                    raise ValueError("events 須為清單")
                for item in entries:
                    if not isinstance(item, dict) or not isinstance(item.get("id"), str) or not item["id"]:
                        raise ValueError("事件缺少 id")
                    key = _review_key(section, item["id"])
                    if key in result:
                        raise ValueError("事件 id 重複")
                    result[key] = item
            elif section in ("適用", "影響", "影響段次", "新增"):
                if not isinstance(entries, dict):
                    raise ValueError(section + " 須為物件")
                for key, item in entries.items():
                    result[_review_key(section, key)] = item
                # 空區段也須保留。
                result[_review_key("$section", section)] = True
            else:
                result[_review_key("$meta", section)] = entries
        result[_review_key("$section", "events")] = True
        return result
    if kind == "whole":
        return {_WHOLE: value}
    if kind == "object" and isinstance(value, dict):
        return value
    if kind == "list" and isinstance(value, list):
        result = {}
        for item in value:
            if not isinstance(item, dict) or not isinstance(item.get(key_field), str) or not item[key_field]:
                raise ValueError("清單項目缺少有效鍵")
            key = item[key_field]
            if key in result:
                raise ValueError("清單的鍵重複：" + key)
            result[key] = item
        return result
    raise ValueError("JSON 格式不符 " + kind)


def _date(value, field):
    if not field or not isinstance(value, dict):
        return None
    raw = value.get(field)
    if not isinstance(raw, str):
        return None
    try:
        # 同一天視為平手。
        return datetime.datetime.fromisoformat(raw.replace("Z", "+00:00")).date()
    except ValueError:
        return None


def _winner(local, warehouse, field):
    a, b = _date(local, field), _date(warehouse, field)
    if a is not None and b is not None:
        if a > b:
            return local
    return warehouse


def _note(name, key, av, bv, action=None):
    item = {"時間": datetime.datetime.now().astimezone().isoformat(), "檔": name, "鑰匙": key,
            "本機": None if av is _MISSING else av, "倉庫": None if bv is _MISSING else bv,
            "本機存在": av is not _MISSING, "倉庫存在": bv is not _MISSING}
    if action:
        item["處理"] = action
    return item


def _other_units(name, a, b, old, renamed):
    """同一個鍵、兩邊是不同單位的條目：本機那筆不動，倉庫那筆換地方留著。a、b、old 就地改，回傳要記的紀錄。
    判例、審查經驗：倉庫那筆改用帶單位的新鍵。白名單：一個詞一筆，單位併進「其他單位」。
    答案庫：倉庫那筆存到「指紋@單位」，answer_bank.get 找得到。倉庫沒改過的（等於基準）不用處理，本機版本來就會贏。"""
    import precedents as pc
    notes = []
    for key in sorted(set(a) & set(b)):
        av, bv = a[key], b[key]
        if not isinstance(av, dict) or not isinstance(bv, dict):
            continue
        fingerprint = _fingerprint(bv)
        if fingerprint == _fingerprint(av) or fingerprint == old.get(key):
            continue
        if name == _WORDS:
            joined = pc.join_word(av, bv)
            if joined is None:
                continue
            a[key] = b[key] = joined
            if joined != av:
                notes.append(_note(name, key, av, bv, "同一個詞別的單位也記了：單位併進其他單位"))
            continue
        if name == _BANK:
            if av.get("單位") == bv.get("單位"):
                continue
            section, inner = json.loads(key)
            target = _review_key(section, "%s@%s" % (inner, bv.get("單位") or "未標單位"))
            moved = bv
            action = "同指紋不同單位：本機那筆不動，倉庫那筆存到 %s" % target
        else:
            if pc.unit_visible(av, bv.get(pc.UNIT) or {}):
                continue
            target = pc.split_key(key, bv.get(pc.UNIT))
            moved = dict(bv, **{_CASES[name]: target})
            renamed[key] = (target, bv.get("承辦意見"))
            action = "同鍵不同單位：本機那筆不動，倉庫那筆改用新鍵 %s" % target
        b[target] = moved
        del b[key]
        old.pop(key, None)
        notes.append(_note(name, key, av, bv, action))
    return notes


def _rules_follow(b, renamed):
    """判例改了鍵：倉庫裡接著這則判例整理的準則跟著改，不然準則會以為來源不見了。"""
    for key, item in list(b.items()):
        cases = item.get("判例") if isinstance(item, dict) else None
        if not isinstance(cases, dict):
            continue
        moved = dict((renamed[k][0] if k in renamed and renamed[k][1] == said else k, said) for k, said in cases.items())
        if moved != cases:
            b[key] = dict(item, 判例=moved)


def _take_old_log(local, warehouse):
    """舊版把衝突紀錄寫在倉庫：搬到本機，倉庫不留原文。"""
    source = warehouse / CONFLICT_NAME
    if source.is_file():
        target = local / CONFLICT_NAME
        previous = target.read_bytes() if target.exists() else b""
        joiner = b"\n" if previous and not previous.endswith(b"\n") else b""
        _write(target, previous + joiner + source.read_bytes())
        source.unlink()


def _write(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp = tempfile.mkstemp(prefix=".memo-", suffix=".tmp", dir=str(path.parent))
    try:
        with os.fdopen(fd, "wb") as f:
            f.write(data)
        replace_file(tmp, path)
    finally:
        if os.path.exists(tmp):
            os.unlink(tmp)


def _put(path, data):
    if not path.is_file() or path.read_bytes() != data:
        _write(path, data)
        return True
    return False


def _validate_unknown(path):
    if path is None:
        return
    if path.suffix.lower() == ".json":
        json.loads(path.read_text(encoding="utf-8-sig"))
    elif path.suffix.lower() == ".csv":
        # Excel 儲存的 CSV 可能是 Big5。
        data = path.read_bytes()
        try:
            text = data.decode("utf-8-sig")
        except UnicodeDecodeError:
            text = data.decode("cp950")
        list(csv.reader(io.StringIO(text, newline=""), strict=True))


def _load_base(path):
    if not path.exists():
        return {}
    data = json.loads(path.read_text(encoding="utf-8-sig"))
    if not isinstance(data, dict) or data.get("version") != 1 or not isinstance(data.get("files"), dict):
        raise ValueError("同步基準格式錯誤")
    for name, keys in data["files"].items():
        if not isinstance(name, str) or not isinstance(keys, dict) or any(
                not isinstance(k, str) or not isinstance(v, str) or len(v) != 64
                or any(c not in "0123456789abcdef" for c in v) for k, v in keys.items()):
            raise ValueError("同步基準指紋格式錯誤")
    return data["files"]


def _save_base(path, base):
    _put(path, (json.dumps({"version": 1, "files": base}, ensure_ascii=False, sort_keys=True, indent=1) + "\n").encode("utf-8"))


def _file_hash(path):
    return hashlib.sha256(path.read_bytes()).hexdigest() if path.is_file() else None


def _recover(local, warehouse, base_path, base):
    journal_path = base_path.parent / JOURNAL_NAME
    if not journal_path.exists():
        return
    journal = json.loads(journal_path.read_text(encoding="utf-8"))
    name = journal["name"]
    if not isinstance(name, str) or Path(name).is_absolute() or ".." in Path(name).parts or _format(name) is None:
        raise ValueError("同步交易紀錄路徑不正確")
    if journal["phase"] == "prepared":
        current = [_file_hash(local / name), _file_hash(warehouse / name)]
        if current == journal["before"]:
            journal_path.unlink()
            return
        if current != [journal["target"], journal["target"]]:
            raise RuntimeError("同步交易中斷且資料已變動，保留原狀，請檢查：" + name)
    elif journal["phase"] != "written":
        raise ValueError("同步交易紀錄狀態不正確")
    if journal["exists"]:
        base[name] = journal["base"]
    else:
        base.pop(name, None)
    _save_base(base_path, base)
    journal_path.unlink()


def _review_value(merged):
    result = {}
    for encoded, item in merged.items():
        section, key = json.loads(encoded)
        if section == "$section":
            result.setdefault(key, [] if key == "events" else {})
        elif section == "$meta":
            result[key] = item
        elif section == "events":
            result.setdefault(section, []).append(item)
        else:
            result.setdefault(section, {})[key] = item
    return result


def _csv_header(path):
    if path is None:
        return []
    raw = path.read_bytes()
    try:
        text = raw.decode("utf-8-sig")
    except UnicodeDecodeError:
        text = raw.decode("cp950")
    return next(csv.reader(io.StringIO(text, newline=""), strict=True))


def _serialize(kind, merged, a_path, b_path):
    if kind == "csv":
        fields = list(dict.fromkeys(_csv_header(b_path) + _csv_header(a_path)))
        output = io.StringIO(newline="")
        writer = csv.DictWriter(output, fieldnames=fields, extrasaction="raise", lineterminator="\r\n")
        writer.writeheader()
        writer.writerows(merged.values())
        return output.getvalue().encode("utf-8-sig")
    if kind in ("nested", "history"):
        value = {}
        for key, item in merged.items():
            section, inner = json.loads(key)
            if kind == "nested":
                value.setdefault(section, {})[inner] = item
            else:
                value.setdefault(section, []).append(item)
    elif kind == "rules":
        value = {"準則": list(merged.values())}
    elif kind == "whole":
        value = merged.get(_WHOLE)
    elif kind == "reviewed":
        value = _review_value(merged)
    else:
        value = list(merged.values()) if kind == "list" else merged
    return (json.dumps(value, ensure_ascii=False, indent=1, allow_nan=False) + "\n").encode("utf-8")


def _renumber(merged, warehouse):
    # 優先保留倉庫準則的編號，包括已停用的準則。
    used = {v.get("編號") for v in merged.values() if isinstance(v.get("編號"), str)}
    seen = set()
    for key in sorted(merged, key=lambda k: (k not in warehouse, k)):
        entry = merged[key]
        number = entry.get("編號")
        if number in seen:
            serial = 1
            while "R%d" % serial in used:
                serial += 1
            number = "R%d" % serial
            entry = merged[key] = dict(entry, 編號=number)
            used.add(number)
        seen.add(number)


_WEB = "法規追蹤/網頁快取/"
_WEB_INDEX = _WEB + "索引.json"
_PDF = "法規追蹤/PDF文字/"


def _web_plan(left, right, base):
    """先驗證整組索引及目標，回傳各快取應採用的原始檔。"""
    a = _read(left.get(_WEB_INDEX), FORMATS[_WEB_INDEX])
    b = _read(right.get(_WEB_INDEX), FORMATS[_WEB_INDEX])
    old = base.get(_WEB_INDEX, {})
    targets = {}
    for url in sorted(set(a) | set(b) | set(old)):
        av, bv = a.get(url, _MISSING), b.get(url, _MISSING)
        af = _fingerprint(av) if av is not _MISSING else None
        bf = _fingerprint(bv) if bv is not _MISSING else None
        prior = old.get(url)
        if af == bf:
            chosen, preferred = bv, right
        elif af == prior:
            chosen, preferred = bv, right
        elif bf == prior:
            chosen, preferred = av, left
        else:
            chosen, preferred = bv, right
        if chosen is _MISSING:
            continue
        if not isinstance(chosen, str) or not re.fullmatch(r"[0-9a-f]{32}\.bin", chosen):
            raise ValueError("網頁索引的快取檔名不正確")
        name = _WEB + chosen
        source = preferred.get(name) or left.get(name) or right.get(name)
        if source is None:
            raise ValueError("網頁索引找不到快取：" + chosen)
        if name in targets and _file_hash(targets[name]) != _file_hash(source):
            raise ValueError("網頁索引指向同一檔名但內容不同：" + chosen)
        targets[name] = source
    return targets


def merge(skill_dir, warehouse_dir, base_path, return_local=False):
    """合併兩側並回傳統計；基準壞檔時中止，呼叫端須防止並行寫入。"""
    local, warehouse, base_path = Path(skill_dir), Path(warehouse_dir), Path(base_path)
    if local.resolve() == warehouse.resolve():
        raise ValueError("兩個累積資料夾不能相同")
    _take_old_log(local, warehouse)
    base = _load_base(base_path)
    _recover(local, warehouse, base_path, base)
    left, right = _files(local), _files(warehouse)
    report = {"補檔": 0, "改檔": 0, "刪除鍵": 0, "衝突": 0, "別單位": 0, "壞檔": [], "不認得": []}
    renamed = {}
    try:
        web = _web_plan(left, right, base)
        web_error = False
    except (OSError, ValueError, UnicodeError, TypeError) as exc:
        report["壞檔"].append("網頁快取：%s" % exc)
        web, web_error = {}, True
    for name in sorted(set(left) | set(right) | set(base)):
        if _excluded(name):
            continue
        a_path, b_path = left.get(name), right.get(name)
        if name.startswith(_WEB) and (web_error or name != _WEB_INDEX):
            continue
        if name.startswith(_PDF) and name.endswith(".txt"):
            if bool(a_path) != bool(b_path):
                source, dest = (a_path, warehouse / name) if a_path else (b_path, local / name)
                _write(dest, source.read_bytes())
                report["補檔"] += 1
            elif a_path and a_path.read_bytes() != b_path.read_bytes():
                # 同一份 PDF 兩邊用不同工具轉過（v1.60.4）：固定用倉庫那份，不然兩邊的文字一直不同，
                # 換邊跑就是另一條法規，答案全部要重判
                _write(local / name, b_path.read_bytes())
                report["補檔"] += 1
            continue
        spec = _format(name)
        if spec is None:
            try:
                _validate_unknown(a_path)
                _validate_unknown(b_path)
            except (OSError, ValueError, UnicodeError, csv.Error) as exc:
                report["壞檔"].append(f"{name}: {exc}")
                continue
            if a_path and b_path:
                if a_path.read_bytes() != b_path.read_bytes():
                    if return_local:
                        index = 1
                        while True:
                            suffix = "（收回前本機版）" if index == 1 else "（收回前本機版%d）" % index
                            backup = a_path.with_name(a_path.stem + suffix + a_path.suffix)
                            if not backup.exists():
                                break
                            index += 1
                        _write(backup, a_path.read_bytes())
                        _write(a_path, b_path.read_bytes())
                        report["改檔"] += 1
                        report["不認得"].append(name + "：已採倉庫版，本機版另存 " + backup.name)
                    else:
                        report["不認得"].append(name + "：兩邊不同，未修改")
            elif a_path or b_path:
                source, dest = (a_path, warehouse / name) if a_path else (b_path, local / name)
                _write(dest, source.read_bytes())
                report["補檔"] += 1
            continue
        try:
            a, b = _read(a_path, spec), _read(b_path, spec)
            facts = _review_key("$meta", "單位事實指紋")
            # 寫入前先驗證兩側資料。
            for item in list(a.values()) + list(b.values()):
                _fingerprint(item)
        except (OSError, ValueError, UnicodeError, TypeError, csv.Error) as exc:
            report["壞檔"].append(f"{name}: {exc}")
            continue
        conflicts = []
        old = dict(base.get(name, {}))
        # 舊版整檔基準無法代表各筆紀錄。
        if spec[0] == "reviewed" and _WHOLE in old:
            old = {}
        if name in _CASES or name in (_WORDS, _BANK):
            separated = _other_units(name, a, b, old, renamed)
            conflicts += separated
            report["別單位"] += len(separated)
        elif name == _RULES:
            _rules_follow(b, renamed)
        merged = {}
        facts_differ = spec[0] == "reviewed" and a_path and b_path and a.get(facts, "") != b.get(facts, "")
        if facts_differ:
            a_same = {k: _fingerprint(v) for k, v in a.items()} == old
            b_same = {k: _fingerprint(v) for k, v in b.items()} == old
            merged = dict(a if b_same and not a_same else b)
            if not a_same and not b_same:
                conflicts.append(_note(name, "$whole", _review_value(a), _review_value(b)))
        for key in ([] if facts_differ else sorted(set(a) | set(b) | set(old))):
            av, bv = a.get(key, _MISSING), b.get(key, _MISSING)
            af = _fingerprint(av) if av is not _MISSING else None
            bf = _fingerprint(bv) if bv is not _MISSING else None
            prior = old.get(key)
            if af == bf:
                chosen = av
            elif af == prior:
                chosen = bv
            elif bf == prior:
                chosen = av
            else:
                chosen = _winner(av, bv, spec[2])
                if name not in NO_CONFLICT_NOTE:
                    conflicts.append(_note(name, key, av, bv))
            if chosen is not _MISSING:
                merged[key] = chosen
            elif prior is not None:
                report["刪除鍵"] += 1
        kind = spec[0]
        if kind == "rules":
            _renumber(merged, b)
        # 保留既有空物件及清單。
        exists = bool(merged) if kind == "whole" else bool(merged) or bool(a_path or b_path)
        data = _serialize(kind, merged, a_path, b_path) if exists else None
        # 更換檔案前先保留衝突內容。
        if conflicts:
            path = local / CONFLICT_NAME
            previous = path.read_bytes() if path.exists() else b""
            lines = b"".join(_encoded(item) + b"\n" for item in conflicts)
            _write(path, previous + (b"\n" if previous and not previous.endswith(b"\n") else b"") + lines)
            report["衝突"] += len(conflicts) - sum(1 for item in conflicts if "處理" in item)
        target_hash = hashlib.sha256(data).hexdigest() if data is not None else None
        journal_path = base_path.parent / JOURNAL_NAME
        journal = {"name": name, "phase": "prepared", "before": [_file_hash(local / name), _file_hash(warehouse / name)],
                   "target": target_hash, "exists": exists, "base": {k: _fingerprint(v) for k, v in merged.items()}}
        _write(journal_path, _encoded(journal))
        for path, present in ((local / name, a_path), (warehouse / name, b_path)):
            if data is None:
                if present:
                    path.unlink()
                    report["改檔"] += 1
            elif _put(path, data):
                report["改檔" if present else "補檔"] += 1
        journal["phase"] = "written"
        _write(journal_path, _encoded(journal))
        base[name] = journal["base"]
        if not exists:
            base.pop(name, None)
        _save_base(base_path, base)
        journal_path.unlink()
        if name == _WEB_INDEX:
            for filename, source in web.items():
                content = source.read_bytes()
                for root in (local, warehouse):
                    target = root / filename
                    was_present = target.is_file()
                    if _put(target, content):
                        report["改檔" if was_present else "補檔"] += 1
    _save_base(base_path, base)
    return report
