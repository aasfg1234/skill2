"""在每次重建的隔離暫存目錄中執行工作區流程。"""
import argparse
import copy
import contextlib
import datetime
import glob
import hashlib
import json
import os
import re
from pathlib import Path, PureWindowsPath
import shutil
import struct
import subprocess
import sys
import tempfile
import threading
import time
import zipfile
import zlib
import uuid

STARTED = time.monotonic()
HEALTH_NEEDS_LOCAL = 6       # run_all.HEALTH_NEEDS_LOCAL：體檢要到本機跑（隔離區沒有語意模型）
ORIGINALS_NEED_LOCAL = 7     # novice_tools.ORIGINALS_NEED_LOCAL：核對原始在隔離區讀不到原始資料夾，轉本機（v1.50.0）

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
sys.path.insert(0, str(HERE / "regdiff"))
import workspace_transfer as transfer
import workspace
from file_replace import move_path, replace_file

MAX_ARCHIVE_ENTRIES = transfer.MAX_ARCHIVE_ENTRIES       # v1.51.0：上限只留一份，搬移封包用同一組
MAX_ARCHIVE_FILE_BYTES = transfer.MAX_ARCHIVE_FILE_BYTES
MAX_ARCHIVE_TOTAL_BYTES = transfer.MAX_ARCHIVE_TOTAL_BYTES

PUBLIC_PATHS = ("1_結果彙整", "2_Log檔案/AI審查", "匯入/規章清單.csv", "單位資料建議")
PUBLIC_NAMES = frozenset(("LLM異動清單.md", "LLM外部引用清單.md", "LLM條文檢查清單.md", "人工待辦.txt"))
STATE = "_隔離狀態.json"
MEMO = "_skill累積/memoization/"
LIBRARY = "_skill資料庫/"
# 不含 PDF文字：隔離區有 PyMuPDF、本機不一定有，省略後重轉文字會變，判過的答案全部要重判（v1.60.4）。整包才幾百 KB
LAW_CACHES = ("法規追蹤/網頁快取/", "法規追蹤/清單快取.json")
# 衝突時被換下來的版本也存進倉庫（工作區那份沒帶回也不會丟）；資料夾名第一層是日期，30 天後清掉
KEEP = "_衝突留底"
KEEP_DAYS = 30
# 子程序輸出太長時，螢幕只留頭尾，全文另存（隔離平台會截斷很長的輸出）
OUTPUT_LIMIT = 40000
OUTPUT_LINES = 30           # 正文最多幾行：平台 stdout 只留最後 50 行，還要留位子給照抄清單（v1.60.0）
OUTPUT_HEAD_LINES = 8        # 超過時留頭尾：開頭常是自動略過這類提醒，結尾是下一步要做什麼
OUTPUT_TAIL_LINES = 20
# skill 資料夾常在使用者找不到的地方：本機請求改請使用者雙擊工作區裡的捷徑，捷徑再切到 skill 資料夾
LAUNCHER = "執行下一步.cmd"
# v1.51.0（第二次審查 H2）：捷徑內容固定、不含任何 AI 給的路徑。以前 cd 的目標由 AI 決定（建捷徑 --skill資料夾、
# 倉庫狀態的 skill資料夾 鍵都是 AI 可寫），AI 把目標指到它寫得到的工作區、放 python.bat 或自己的 scripts\run_all.py，
# 使用者雙擊就跑任意程式。現在程式位置只從「使用者自己在真正的 skill 資料夾啟動程式」時寫的本機登記檔讀：
# %LOCALAPPDATA%\reg-report\skill路徑.cmd（內容 set "SKILL=<絕對路徑>"），AI 寫不到那裡。
REGISTRY_DIR = "reg-report"
REGISTRY_FILE = "skill路徑.cmd"
REGISTRY_REL = REGISTRY_DIR + "\\" + REGISTRY_FILE
# v1.56.0：python 叫不起來（沒裝、只有 Store 的假指令）就試 py；都沒有時講中文，請求單旁邊也留結果檔，AI 才知道發生什麼事
NO_PYTHON = ("這台電腦找不到 Python，這一步還沒開始。請安裝 Python 3.13（安裝時勾 Add python.exe to PATH）"
             "或請資訊單位協助，裝好再雙擊一次。")
# 開頭叫自己一次：新開的視窗是系統字碼頁，同一個 cmd 裡 chcp 之後，後面含中文的語法行還是解錯
#（實測：寫結果檔那行在新視窗每次都失敗）；已經是 UTF-8 的 cmd 才解得對。先設 NoDefault…：工作區 AI 寫得到，
# 不能讓那裡的 chcp.bat 被叫到。
LAUNCHER_LINES = (
    "@echo off",
    "set NoDefaultCurrentDirectoryInExePath=1",
    "if defined REG_UTF8 goto start",
    "set REG_UTF8=1",
    "chcp 65001 >nul",
    '"%ComSpec%" /c ^""%~f0"^"',       # 路徑要在引號裡：資料夾名稱有 & 時才不會被當成指令（Explorer 雙擊也是這樣解）
    "exit /b %errorlevel%",
    ":start",
    'if not exist "%%LOCALAPPDATA%%\\%s" (echo 還沒登記程式位置：請先到程式資料夾雙擊一次 打開設定.cmd，再回來雙擊這個捷徑。 & pause & exit /b 1)' % REGISTRY_REL,
    'call "%%LOCALAPPDATA%%\\%s"' % REGISTRY_REL,
    'cd /d "%SKILL%" || (echo 程式資料夾搬走了，請到新資料夾雙擊 打開設定.cmd & pause & exit /b 1)',
    "call python --version >nul 2>nul || goto nopython",
    'python -B "%SKILL%\\scripts\\run_all.py" run-request',
    "goto done",
    ":nopython",
    "call py -3 --version >nul 2>nul || goto nothing",
    'py -3 -B "%SKILL%\\scripts\\run_all.py" run-request',
    "goto done",
    ":nothing",
    "echo " + NO_PYTHON,
    'for %%f in ("_請求\\請求_*.json") do (echo ' + NO_PYTHON + ' & echo [結束碼] 1)> "%%~f.結果.txt"',
    ":done",
    "echo 看完上面的訊息後，按任意鍵關掉這個視窗。",
    "pause",
)


def launcher_bytes():
    """捷徑的固定內容（CRLF、UTF-8 無 BOM）。"""
    return ("\r\n".join(LAUNCHER_LINES) + "\r\n").encode("utf-8")


def launcher_lines(root_rel):
    return ["請使用者雙擊工作區裡的捷徑：<AI工作區根目錄>/%s/%s；視窗會先列出這次要做的事，請使用者看過後按 Enter 才會開始。" % (root_rel, LAUNCHER),
            "捷徑還不存在時，先用啟動腳本送 args=[\"建捷徑\"] 由程式建立（捷徑內容固定、不含任何路徑）；"
            "不要用檔案工具自己寫（換行格式不對，雙擊會跑出亂碼指令）。",
            "捷徑不含程式位置：第一次用這台電腦（或程式搬家後）要先登記。回覆使用者時講出 skill 資料夾的本機完整路徑，"
            "請使用者貼到檔案總管的網址列，雙擊裡面的 打開設定.cmd；捷徑說「還沒登記程式位置」就是還沒做這一步。"]


SKILL_DIR_KEY = "skill資料夾"      # v1.50.0 倉庫狀態記的本機 skill 資料夾；v1.51.0 起不再寫、不再用（捷徑不含路徑），留著只為相容


def auto_launcher_lines(folder, root_rel, skill_dir=""):
    """v1.50.0：印本機請求時順便把捷徑建好。v1.51.0：捷徑內容固定，不再需要倉庫記的 skill 資料夾（參數留著相容、不用）。"""
    try:
        write_launcher(Path(folder))
    except (ValueError, OSError):
        return launcher_lines(root_rel)
    lines = launcher_lines(root_rel)
    return [lines[0], "捷徑已建好（不含程式位置）。" + lines[2]]


def write_launcher(folder, skill_dir=None):
    """在工作區寫雙擊用的捷徑。命令列視窗讀 LF 換行加 chcp 的批次檔會錯位，一定寫 CRLF。
    v1.51.0：內容固定；skill_dir 只為舊呼叫相容，內容不會寫進捷徑。"""
    folder = Path(folder)
    transfer._reject_links(folder / LAUNCHER)
    folder.mkdir(parents=True, exist_ok=True)
    (folder / LAUNCHER).write_bytes(launcher_bytes())
    return folder / LAUNCHER


def launcher_is_current(folder):
    """工作區的捷徑是不是新格式（固定內容）。"""
    path = Path(folder) / LAUNCHER
    try:
        return path.read_bytes() == launcher_bytes()
    except OSError:
        return False


def _old_launcher(folder):
    """工作區裡有舊格式捷徑。skill 資料夾自己的 執行下一步.cmd 內容本來就不同（用 %~dp0），不算，也不能換。"""
    folder = Path(folder)
    if folder.resolve() == transfer._program_dir().resolve():
        return False
    return (folder / LAUNCHER).is_file() and not launcher_is_current(folder)


def old_launcher_note(folder):
    """本機請求途中發現舊捷徑時給 AI 看的一句。這時不能當場換：cmd 照位元組位置讀批次檔，正在跑的捷徑被換掉，
    回來會從新檔中間接著執行。"""
    if not _old_launcher(folder):
        return ""
    return ("（給 AI 看：工作區的 %s 還是舊版、含程式路徑；把它列進 input_files 再送一次 建捷徑，換成不含路徑的新版）" % LAUNCHER)


def refresh_launcher(folder, say=print):
    """本機啟動（不是本機請求）時：工作區裡的捷徑是舊格式（含 AI 給的路徑）就換成新的。回傳有沒有換。"""
    if not _old_launcher(folder):
        return False
    try:
        write_launcher(folder)
    except (ValueError, OSError) as exc:
        say("工作區的 %s 是舊格式但換不掉（%s）；請刪掉它，下一次本機請求會重建" % (LAUNCHER, exc))
        return False
    say("已把工作區的 %s 換成新格式（不含程式位置；程式位置由這台電腦的登記檔決定）" % LAUNCHER)
    return True


def registry_path():
    """本機登記檔位置：%LOCALAPPDATA%\\reg-report\\skill路徑.cmd；沒有 LOCALAPPDATA（非 Windows）回 None。"""
    base = os.environ.get("LOCALAPPDATA", "")
    if not base:
        return None
    return Path(base) / REGISTRY_DIR / REGISTRY_FILE


def registry_text(skill_dir):
    """登記檔內容。路徑只收本機磁碟的絕對路徑、不能含引號或換行（會破壞 cmd 的 set）。"""
    text = str(skill_dir)
    win = PureWindowsPath(text)
    if (not win.is_absolute() or not re.fullmatch(r"[A-Za-z]:", win.drive)
            or any(c in text for c in '"\r\n\x00')):
        raise ValueError("程式位置要是本機磁碟的絕對路徑：" + text)
    return 'set "SKILL=%s"\r\n' % str(win).replace("%", "%%")


def _registration_allowed():
    """隔離區（REG_ISOLATED）、本機請求（REG_RUN_REQUEST：內容是 AI 寫的）不碰登記檔和捷徑。"""
    return os.environ.get("REG_ISOLATED") != "1" and os.environ.get("REG_RUN_REQUEST") != "1"


def register_skill_dir(skill_dir=None, say=print):
    """把這台電腦的 skill 資料夾寫進本機登記檔（UTF-8 無 BOM、CRLF）。路徑跟登記的一樣就不重寫。
    路徑一律用正在跑的這支程式的 __file__ 算，不收 AI 給的值。回傳有沒有寫。"""
    if not _registration_allowed():
        return False
    path = registry_path()
    if path is None:
        return False
    skill_dir = Path(skill_dir) if skill_dir else HERE.parent
    skill_dir = Path(os.path.abspath(str(skill_dir)))
    text = registry_text(skill_dir)
    try:
        if path.is_file() and path.read_bytes() == text.encode("utf-8"):
            return False
        for part in (path, path.parent):
            if part.is_symlink() or (hasattr(part, "is_junction") and part.is_junction()):
                raise ValueError("登記檔位置是連結：%s" % part)
        path.parent.mkdir(parents=True, exist_ok=True)
        tmp = path.with_name(path.name + ".%s.tmp" % uuid.uuid4().hex[:8])
        tmp.write_bytes(text.encode("utf-8"))
        replace_file(tmp, path)
    except (OSError, ValueError) as exc:
        say("程式位置登記不了（%s）：工作區捷徑會說「還沒登記程式位置」" % exc)
        return False
    say("已登記程式位置：%s（寫在 %s；工作區的 %s 捷徑靠它找到程式）" % (skill_dir, path, LAUNCHER))
    return True


def local_start(workspace_root=None, say=print):
    """使用者自己在本機啟動程式時呼叫（打開設定、本機 run_all）：登記程式位置、把目前工作區的舊捷徑換掉。"""
    if not _registration_allowed():
        return
    register_skill_dir(say=say)
    if workspace_root:
        refresh_launcher(workspace_root, say=say)


def display_output(text, root, workspace_label, program_root=None, extra=()):
    # extra：暫存資料夾裡其實對應本機別處的路徑（本機接力的累積資料、資料庫），照實際位置顯示
    replacements = [(str(path), str(label)) for path, label in extra] + [(str(root), workspace_label)]
    if program_root is not None:
        replacements.append((str(program_root), "<skill資料夾>"))
    variants = []
    for path, label in replacements:
        variants.extend(((path, label), (path.replace("\\", "/"), label),
                         (path.replace("\\", "\\\\"), label)))
    for path, label in sorted(set(variants), key=lambda item: -len(item[0])):
        text = text.replace(path, label)
    return text


# v1.51.0：相對路徑總長、單一名稱長度上限（Windows 路徑 260 字限制；AI 工作區根目錄本身也佔長度）
MAX_PATH_CHARS = 240
MAX_NAME_CHARS = 200


def safe(name):
    name = str(name).replace(os.sep, "/")
    if not transfer._safe(name):
        raise ValueError("不安全的相對路徑：" + name)
    if len(name) > MAX_PATH_CHARS:
        raise ValueError("相對路徑太長（%d 字，上限 %d）：%s…" % (len(name), MAX_PATH_CHARS, name[:60]))
    if any(len(part) > MAX_NAME_CHARS for part in name.split("/")):
        raise ValueError("檔案或資料夾名稱太長（上限 %d 字）：%s…" % (MAX_NAME_CHARS, name[:60]))
    return name


def files(root):
    if not root.is_dir():
        return {}
    return transfer._files(root, excluded_roots=("_隔離區", "_skill累積", "_skill資料庫", KEEP))[0]


def keep_conflict(root, name, source, workspace_dir=None):
    """把被換下來的版本存進倉庫的衝突留底；有本機工作區時也放一份到 _隔離區/衝突/。回傳工作區那份的相對路徑。"""
    p = Path(safe(name))
    stamp = datetime.datetime.now().strftime("%Y%m%d")
    renamed = p.with_name(p.stem + "_" + uuid.uuid4().hex[:8] + p.suffix).as_posix()
    kept = root / KEEP / stamp / renamed
    kept.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(source, kept)
    if workspace_dir is None:
        return renamed
    dest = workspace_dir / "_隔離區" / "衝突" / renamed
    transfer._reject_links(dest)
    dest.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(source, dest)
    return dest.relative_to(workspace_dir).as_posix()


def kept_conflicts(root):
    """倉庫裡還在保留期限內的衝突留底。"""
    folder = root / KEEP
    if not folder.is_dir():
        return {}
    oldest = (datetime.datetime.now() - datetime.timedelta(days=KEEP_DAYS)).strftime("%Y%m%d")
    return {n: p for n, p in transfer._files(folder)[0].items()
            if not re.fullmatch(r"\d{8}", n.split("/", 1)[0]) or n.split("/", 1)[0] >= oldest}


def atomic_write(source, dest):
    """先寫同資料夾的暫存檔再整個換上：寫到一半失敗時，原檔不會變成半套。"""
    transfer._reject_links(dest)
    dest.parent.mkdir(parents=True, exist_ok=True)
    fd, temp_name = tempfile.mkstemp(prefix=".寫回_", suffix=".tmp", dir=str(dest.parent))
    os.close(fd)
    tmp = Path(temp_name)
    try:
        shutil.copyfile(source, tmp)
        replace_file(tmp, dest)
    finally:
        if tmp.exists():
            tmp.unlink()


def public(name):
    parts = name.split("/")
    if (len(parts) == 4 and parts[0].startswith("產出")
            and parts[1:3] == ["2_Log檔案", "法規分析"]
            and ((parts[3].startswith("法規追蹤明細_") and parts[3].endswith(".xlsx"))
                 or (parts[3].startswith("內規全文_") and parts[3].endswith(".md"))     # v1.56.0：先讀我叫 AI 看這兩種，
                 or parts[3] == "外部引用索引.json")):                                  # 以前留在倉庫裡隔離區讀不到
        return True
    # 報告上寫「全文見 2_Log檔案/…理由全文.csv」：接力時要寫回工作區，承辦才找得到
    if (len(parts) == 3 and parts[0].startswith("產出") and parts[1] == "2_Log檔案"
            and (parts[2] in ("批次摘要.txt", "報告整理紀錄.txt") or parts[2].endswith("理由全文.csv"))):
        return True
    if name == workspace.LAYOUT_FILE:
        return True
    if len(parts) == 1 and name.endswith((".txt", ".md")):
        return True
    if name in ("匯入/規章清單.csv", "匯入/單位事實.csv", "匯入/排除的檔.json", "匯入/法規資料/來源紀錄.json") or name.startswith("單位資料建議/"):
        return True
    if parts[-1] in PUBLIC_NAMES and parts[0].startswith("產出"):
        return True
    if (parts[0].startswith("產出") and "2_Log檔案" in parts[1:-1]
            and parts[-1].startswith("LLM") and parts[-1].endswith(".md")):
        return True
    return any("/" + p + "/" in "/" + name for p in PUBLIC_PATHS[:2])


IMPORT_TITLE = "倉庫匯入目錄："
LOCAL_COMMAND_HINT = ("上面若寫 `python scripts/run_all.py <子指令> …`，在隔離區改送 `執行 <子指令> …`（不要帶 --workspace）；"
                      "寫 `semantic_candidates.py` 的照本機請求做")


def same_imports(status, imports):
    """這份清單跟上一次的 下一步.txt 一樣嗎。跟 AI 手上那份比（不是倉庫記的）：還原備份、逾時之後才不會誤報沒變。"""
    try:
        previous = status.read_text(encoding="utf-8")
    except (OSError, UnicodeError):
        return False
    _, found, rest = previous.partition("\n" + IMPORT_TITLE + "\n")
    listed = []
    for row in rest.split("\n"):
        if not row.startswith("匯入/"):
            break
        listed.append(row)
    return bool(found) and listed == imports


def quiet_tail(lines, tail, imports, imports_same):
    """畫面要印的（v1.60.0）：下一步.txt 還是完整的，畫面的固定尾巴只留這一步要動作的。
    以前一步 45 行有 29 行是固定尾巴，48 步累積 129 KB 留在對話裡；stdout 又只留最後 50 行，尾巴把正文擠掉。"""
    drop = {"還在排隊的取回數量：0", "要覆寫的公開檔：無", "可刪除的本機殘留檔：無", "待覆寫檔留待後續批次：0"}
    body = "\n".join(lines[:tail])
    if "scripts/run_all.py" not in body and "semantic_candidates.py" not in body:
        drop.add(LOCAL_COMMAND_HINT)
    shown = lines[:tail]
    skip = 0
    for line in lines[tail:]:
        if skip:
            skip -= 1
        elif line == IMPORT_TITLE and imports_same:
            shown.append("倉庫匯入目錄沒變（%d 個檔，清單在 _隔離區/下一步.txt）" % len(imports))
            skip = len(imports)
        elif line not in drop:
            shown.append(line)
    return shown


_SHA_MEMO = {}


def sha(path):
    """同一支程式對同一個沒動過的檔只算一次（v1.59.2：一步要比對好幾輪，同一檔算好多次）。"""
    stat = os.stat(path)
    key = (str(path), stat.st_size, stat.st_mtime_ns)
    if key not in _SHA_MEMO:
        _SHA_MEMO[key] = transfer._metadata(path)["sha256"]
    return _SHA_MEMO[key]


# v1.49.0：照抄清單 4 個固定檔＋最多 5 個待覆寫檔＝9，留一格給這一步要帶的答案檔、證據檔
# （以前 6 個，10 格全滿，AI 只好自己拿掉清單上的檔，拿掉的審查包一直沒更新）
OVERWRITE_SLOTS = 5
# 這幾個指令讀的答案檔一定要這次帶進來；倉庫裡同名的是上次帶的舊版（本機刪了倉庫也還在）
FRESH_FILE_COMMANDS = ("填表", "fill-answers", "記準則", "準則", "save-rules")
FEEDBACK_COMMANDS = ("收回饋", "回饋寫完了", "回饋", "feedback")
# 要寫這台電腦的 skill 資料夾（設定頁、分享用 zip）：隔離區寫在暫存區、跑完就丟，改成本機請求
LOCAL_ONLY_COMMANDS = ("打開設定", "設定頁", "open-settings", "打包分享", "分享", "share", "改設定", "set-setting")
SHOW_SETTINGS_COMMANDS = ("看設定", "設定清單", "show-settings")     # 只讀帶進來的 設定.html：不用倉庫
SET_SETTING_COMMANDS = ("改設定", "set-setting")
_SETTING_PREVIEW = []           # 改前改後：印在輸出最後面（平台只留最後 50 行，工作區檔案多時前面會被擠掉）


def select_overwrites(names, paths, fixed_size, status_size, limit=52428800, proactive=()):
    selected = []
    remaining = limit - fixed_size - status_size
    # v1.60.17：先讀我排第一（模擬時待覆寫 35 檔、一次帶 5 個，先讀我照檔名排在最後幾輪才帶到）
    first = lambda n: (not n.replace("\\", "/").rsplit("/", 1)[-1] == "先讀我.md", n)
    for name in sorted(names, key=first) + sorted(set(proactive) - set(names), key=first):
        path = paths.get(name)
        if path is not None and (isinstance(path, int) or path.is_file()) and len(selected) < OVERWRITE_SLOTS:
            size = path if isinstance(path, int) else path.stat().st_size
            if size <= remaining:
                selected.append(name)
                remaining -= size
    return selected


def find_one(pattern, label, required=True):
    found = sorted(Path(p) for p in glob.glob(pattern, recursive=True) if Path(p).is_file())
    if len(found) != 1 and (required or found):
        raise ValueError("%s 應有一個，找到 %d 個" % (label, len(found)))
    return found[0] if found else None


def extract(archive, destination):
    with zipfile.ZipFile(archive) as z:
        infos = z.infolist()
        if len(infos) > MAX_ARCHIVE_ENTRIES:
            raise ValueError("倉庫檔案數超過上限（%d 項）" % MAX_ARCHIVE_ENTRIES)
        total = 0
        for info in infos:
            if info.file_size > MAX_ARCHIVE_FILE_BYTES:
                raise ValueError("倉庫單一檔案解壓後超過大小上限：" + info.filename)
            total += info.file_size
            if total > MAX_ARCHIVE_TOTAL_BYTES:
                raise ValueError("倉庫解壓後總大小超過上限（%d GB）" % (MAX_ARCHIVE_TOTAL_BYTES // 1024 ** 3))
        seen = set()
        for info in infos:
            name = safe(info.filename.rstrip("/"))
            if name.casefold() in seen or any(transfer._suspicious(p) for p in name.split("/")):
                raise ValueError("倉庫含重複或不安全的路徑")
            seen.add(name.casefold())
            if (info.external_attr >> 16) & 0o170000 == 0o120000:
                raise ValueError("倉庫含符號連結")
        try:
            z.extractall(destination)            # 解的時候就會驗每個檔的 CRC，不用先多讀一次
        except (zipfile.BadZipFile, zlib.error, EOFError) as exc:
            raise ValueError("倉庫損壞") from exc
        stamps = {}
        for info in infos:
            if not info.is_dir():
                stamp = time.mktime(info.date_time + (0, 0, -1))
                path = destination / info.filename
                os.utime(path, (stamp, stamp))
                stat = path.stat()
                stamps[info.filename] = (stat.st_size, stat.st_mtime_ns, info.CRC)
    return stamps


def read_archive_state(root):
    state_path = root / STATE
    if not state_path.exists():
        return {"公開": {}, "排隊": [], "待覆寫": []}
    state = json.loads(state_path.read_text(encoding="utf-8"))
    state_path.unlink()
    if not isinstance(state, dict):
        raise ValueError("倉庫狀態不正確")
    for key in ("公開", "前一版", "排隊", "待覆寫", "衝突檔"):
        mapping = key in ("公開", "前一版")
        values = state.get(key, {} if mapping else [])
        if not isinstance(values, dict if mapping else list):
            raise ValueError("倉庫狀態不正確")
        for name in values:
            safe(name)
    return state


def prune(root):
    keep = set()
    for filename in ("目前作業.json", "法規作業.json"):
        p = root / filename
        if p.is_file():
            value = json.loads(p.read_text(encoding="utf-8-sig"))
            for key in ("目前作業", "前一輪作業", "目前法規作業"):
                name = value.get(key, "")
                if name:
                    safe(name)
                    if "/" in name:
                        raise ValueError("作業指標不是資料夾名稱")
                    keep.add(name)
    for p in root.iterdir():
        if p.is_dir() and workspace.is_output_dir(str(root), str(p)) and p.name not in keep:
            shutil.rmtree(p)


# v1.54.0：倉庫會送進隔離區，AI 看得到。別的工作區、別的單位的條目不進倉庫（只在本機那一步過濾：
# 隔離區沒有本機資料可以核對，這邊濾掉的條目可能還沒帶回本機）。分不出來的檔維持原樣，見 累積資料.md。
WORD_MEMO = "內部知識/錯漏字白名單.json"
UNIT_MEMO = ("內部知識/判例.json", "內部知識/判斷準則.json", WORD_MEMO, "內部知識/報告審查經驗.json")
BANK_MEMO = "內部知識/AI答案庫.json"
REVIEWED_MEMO = re.compile(r"法規追蹤/([0-9a-f]{20})/")


def workspace_folders(real):
    """這個工作區在 memoization/法規追蹤/ 的資料夾名（law_impact.cache_path 的幾種算法都算進來）。
    隔離區可能在別的系統跑，大小寫不一定被 normcase 改過：原樣、小寫都算。"""
    import law_sources as ls
    from _common import SKILL_DIR, to_record
    keys = ["倉庫:" + real.name, to_record(str(real), SKILL_DIR)]
    keys += [key.lower() for key in keys] + [os.path.abspath(str(real))]
    return {ls.digest(variant)[:20] for key in keys for variant in (key, os.path.normcase(key))}


def _memo_filter(memo, memo_real, root, real, skill, folder):
    """回傳 (不進倉庫的檔, {檔: 過濾後的暫存副本})，原檔不動。
    只有本機也有一模一樣內容的條目才能不帶：還沒合併回本機的（隔離區新增、改過的）留著，不然就丟了。
    不帶的條目也從同步基準拿掉：三方合併才會當成「倉庫沒看過」，不會當成「倉庫刪了」而刪掉本機那一筆。"""
    import answer_bank as ab
    import memo_merge
    import precedents as pc
    from _common import load_config
    settings = load_config(str(skill / "設定.html")).get("設定") or {}
    unit = pc.current_unit(settings)
    tag = ab.unit_tag(settings, str(root))
    held = transfer._files(memo)[0]
    home = transfer._files(memo_real)[0] if memo_real.is_dir() else {}
    mine = workspace_folders(real)
    skipped, copies, withheld = set(), {}, {}
    for name, path in held.items():
        found = REVIEWED_MEMO.match(name)
        if found and found.group(1) not in mine and name in home and sha(path) == sha(home[name]):
            skipped.add(name)
            withheld[name] = None
    keep_rules = {name: (lambda entry: pc.unit_visible(entry, unit)) for name in UNIT_MEMO}
    keep_rules[BANK_MEMO] = lambda entry: ab.readable(entry, tag)
    folder.mkdir(parents=True, exist_ok=True)
    for name, keep in keep_rules.items():
        if name not in held or name not in home:
            continue
        spec = memo_merge._format(name)
        try:
            local = memo_merge._read(home[name], spec)
        except (OSError, ValueError, UnicodeError, TypeError):
            continue                                 # 本機這份壞了：不知道本機有什麼，一筆都不能不帶
        try:
            entries = memo_merge._read(held[name], spec)
        except (OSError, ValueError, UnicodeError, TypeError):
            skipped.add(name)                        # 倉庫這份壞了：本機有好的，壞的不帶
            withheld[name] = None
            continue
        same = {key for key, entry in entries.items() if key in local
                and memo_merge._fingerprint(local[key]) == memo_merge._fingerprint(entry)}
        out = {key for key in same if not keep(entries[key])}
        # 白名單一個詞一筆，別單位也記過時裡面有別單位的標記、說明：拿掉再帶
        cleaned = {key: pc.visible_word(entries[key], unit) for key in same - out} if name == WORD_MEMO else {}
        cleaned = {key: entry for key, entry in cleaned.items() if entry != entries[key]}
        if out or cleaned:
            kept = {key: cleaned.get(key, entry) for key, entry in entries.items() if key not in out}
            copy = folder / ("%s.json" % hashlib.sha256(name.encode("utf-8")).hexdigest()[:16])
            copy.write_bytes(memo_merge._serialize(spec[0], kept, None, None))
            copies[name] = copy
            withheld[name] = out | set(cleaned)
    base_path = held.get(memo_merge.BASE_NAME)
    if withheld and base_path:
        try:
            base = memo_merge._load_base(base_path)
        except (OSError, ValueError, UnicodeError):
            base = None                              # 基準壞了合併本來就做不了，不會誤刪
        if base is not None:
            for name, keys in withheld.items():
                if keys is None:
                    base.pop(name, None)
                elif name in base:
                    base[name] = {key: value for key, value in base[name].items() if key not in keys}
            copy = folder / memo_merge.BASE_NAME
            memo_merge._save_base(copy, base)
            copies[memo_merge.BASE_NAME] = copy
    return skipped, copies


def memo_scope(memo, memo_real, root, real, skill, folder):
    """_memo_filter 出事不擋工作：照舊整包（只是這一次沒過濾），條目不會少。"""
    try:
        return _memo_filter(memo, memo_real, root, real, skill, folder)
    except Exception as exc:
        print("提醒：累積資料這次沒過濾（%s），別的單位、別的工作區的條目會跟著進倉庫" % exc, flush=True)
        return None


def _base_without_caches(memo, copies, target):
    """法規快取這次不進倉庫：同步基準也要拿掉那幾個鍵，不然下一輪會判成「倉庫刪了」，本機的索引被清空。"""
    import memo_merge
    path = copies.get(memo_merge.BASE_NAME) or memo / memo_merge.BASE_NAME
    try:
        base = memo_merge._load_base(path)
    except (OSError, ValueError, UnicodeError):
        return {}                                    # 基準壞了合併本來就做不了，不會誤刪
    kept = {name: keys for name, keys in base.items() if not name.startswith(LAW_CACHES)}
    if len(kept) == len(base):
        return {}
    copy = target.with_name(target.name + ".基準")
    memo_merge._save_base(copy, kept)
    return {memo_merge.BASE_NAME: copy}


def _copy_entry(raw, info, z):
    """舊倉庫裡壓好的這一項原樣搬到新倉庫。"""
    raw.seek(info.header_offset)
    head = raw.read(30)
    name_size, extra_size = struct.unpack("<HH", head[26:30])
    body = raw.read(name_size + extra_size + info.compress_size)
    entry = copy.copy(info)
    entry.header_offset = z.start_dir
    z.fp.seek(z.start_dir)
    z.fp.write(head)
    z.fp.write(body)
    z.filelist.append(entry)
    z.NameToInfo[entry.filename] = entry
    z.start_dir = z.fp.tell()
    z._didModify = True


def _untouched(name, path, root, stamps, old):
    """解開之後這個檔完全沒動過：同一個位置、一樣大、修改時間跟解開時一模一樣，才能搬舊的。"""
    info = old.get(name)
    if info is None or name not in stamps or info.flag_bits & 0x08 or Path(path) != root / name:
        return None
    stat = os.stat(path)
    return info if stamps[name] == (stat.st_size, stat.st_mtime_ns, info.CRC) else None


def _write_archive(items, state, target, root=None, reuse=None):
    previous, stamps = reuse or (None, {})
    with zipfile.ZipFile(target, "w", zipfile.ZIP_DEFLATED) as z:
        with zipfile.ZipFile(previous) if previous else contextlib.nullcontext() as old_zip:
            with open(previous, "rb") if previous else contextlib.nullcontext() as raw:
                old = dict((i.filename, i) for i in old_zip.infolist()) if old_zip else {}
                for name, path in sorted(items.items()):
                    info = _untouched(safe(name), path, root, stamps, old) if old else None
                    if info is not None:
                        _copy_entry(raw, info, z)
                    else:
                        z.write(path, safe(name))
        z.writestr(STATE, json.dumps(state, ensure_ascii=False, indent=2))
    with zipfile.ZipFile(target) as z:
        if z.testzip():
            raise ValueError("新倉庫驗證失敗")


def make_archive(root, memo, state, target, omit_law_cache=False, scope=None, reuse=None):
    """scope＝memo_scope 的結果；沒給（隔離區那邊）累積資料整份照帶。
    reuse＝(舊倉庫, extract 回傳的修改時間)：沒動過的檔不重壓（v1.59.2，每步從幾秒降到零點幾秒）。
    搬不成（Python 改版、舊倉庫怪怪的）就照舊整包重壓，結果一樣、只是慢。"""
    import memo_merge
    prune(root)
    items = files(root)
    skipped, copies = scope or ((), {})
    if omit_law_cache and memo.is_dir():
        copies = dict(copies, **_base_without_caches(memo, copies, target))
    if memo.is_dir():
        for n, p in transfer._files(memo)[0].items():
            if (not memo_merge.vector_file(n) and not (omit_law_cache and n.startswith(LAW_CACHES))
                    and n not in skipped):
                items[MEMO + n] = copies.get(n, p)
    library = root / "_skill資料庫"
    if library.is_dir():
        items.update({LIBRARY + n: p for n, p in transfer._files(library)[0].items()})
    items.update({KEEP + "/" + n: p for n, p in kept_conflicts(root).items()})
    if reuse:
        try:
            _write_archive(items, state, target, root, reuse)
            return
        except (AttributeError, KeyError, TypeError, ValueError, OSError, struct.error, zipfile.BadZipFile,
                zlib.error, EOFError):
            target.unlink(missing_ok=True)
    _write_archive(items, state, target)


def archive_for_isolation(root, memo, state, target, program, setting, report, scope=None, reuse=None):
    """超出輸入預算時，先只從封包省略可重抓的法規快取。"""
    make_archive(root, memo, state, target, scope=scope, reuse=reuse)
    limit_mb = float(os.environ.get("REG_ISOLATED_MAX_MB", "44"))
    limit = limit_mb * 1024 * 1024
    fixed = sum(path.stat().st_size for path in (program, setting) if path.is_file())
    if target.stat().st_size + fixed > limit and memo.is_dir():
        cache = {n: p for n, p in transfer._files(memo)[0].items() if n.startswith(LAW_CACHES)}
        if cache:
            saved = sum(p.stat().st_size for p in cache.values()) / (1024 * 1024)
            make_archive(root, memo, state, target, omit_law_cache=True, scope=scope, reuse=reuse)
            report("已省略可重抓的法規網頁快取 %.2f MB" % saved)
    return target.stat().st_size + fixed <= limit, limit_mb


def skip_unavailable_semantic(skill, env, root, real, shown):
    """本機也算不了語意：不算整輪失敗。記住了（semantic_candidates 記的）就略過這一輪語意、回 0，下一站照走；
    沒記住（算到一半失敗）維持 2，讓人決定要重跑還是略過。"""
    import semantic_memory as sm
    known = sm.blocked()
    if not known:
        return 2
    call = [sys.executable, "-B", str(skill / "scripts/run_all.py"), "--workspace", str(root), "語意併入", "--略過"]
    rc = stream_process(call, skill, env, root, str(real), extra=shown)
    if rc == 0:
        print(sm.local_done_text(known))
    return rc


WORD_OUTPUT_COMMANDS = ("開始", "繼續", "continue", "重新比對", "重跑開始", "體檢", "檢查現有文件", "health-check")


def missing_package_note():
    """隔離區缺 python-docx 不擋：裝不了套件的隔離環境擋下來就什麼都做不了，報告 xlsx 與 CSV 照出。
    但少了哪些東西要在一開始講，不能等人找不到 Word 檔才發現。"""
    try:
        import docx  # noqa: F401
    except Exception as exc:
        return ("[注意] 隔離區的 Python 缺 python-docx（%s）：比對和報告 xlsx 照做，但 Word 修正對照表、標註版全文不會產生。"
                "隔離區裝得了就 python -m pip install python-docx；裝不了要 Word 版，請到本機跑（見 references/環境與套件.md）。" % exc)
    return ""


WORKSPACE_NAME_SPECIAL = "&^%!"


def workspace_name_problem(name):
    """AI 給的新工作區名稱不能有批次檔的特殊字：捷徑會放在這個資料夾裡（捷徑本身已經擋住注入，這是第二道）。
    只管新建的工作區名稱：資料夾裡的規章檔名、使用者自己取好的上層資料夾（R&D）不受影響。"""
    found = sorted(set(c for c in name if c in WORKSPACE_NAME_SPECIAL))
    if found:
        return "工作區名稱不能有 %s（雙擊捷徑時這些字有特殊意義）：%s。換一個名稱再送一次" % (" ".join(found), name)
    return ""


def semantic_options(skill, params):
    """使用既有模型搜尋規則，不載入模型。"""
    if any(p in ("--檢查", "--check", "--model") or p.startswith("--model=") for p in params):
        return list(params), False
    from _common import from_record, load_config
    import semantic_candidates as sc
    import local_request
    settings = load_config(str(skill / "設定.html")).get("設定") or {}
    configured = from_record(str(skill), settings.get("語意模型路徑", ""))
    if configured:
        local_request._local_path(configured, skill)
    model = sc.find_local_model(configured)
    if not model:
        return list(params) + ["--檢查"], True
    result = list(params) + ["--model", model]
    if settings.get("語意重排序") and not any(p == "--rerank-model" or p.startswith("--rerank-model=") for p in result):
        configured_rerank = from_record(str(skill), settings.get("重排序模型路徑", ""))
        if configured_rerank:
            local_request._local_path(configured_rerank, skill)
        rerank = sc.find_local_model(configured_rerank, sc.RERANKER_NAME)
        if rerank:
            if "--rerank" not in result:
                result.append("--rerank")
            result.extend(["--rerank-model", rerank])
    return result, False


def copy_entries(entries, destination, preserve_conflicts=False, missing_only=False, backup_local=False):
    for name, source in entries.items():
        dest = destination / safe(name)
        transfer._reject_links(dest)
        if dest.exists():
            if not dest.is_file():
                raise ValueError("目的地不是檔案：" + str(dest))
            if missing_only or sha(source) == sha(dest):
                continue
            if backup_local:
                # 倉庫版為準（隔離區學到的要收得回來），本機原本那份另存，不默默丟掉
                index = 1
                while True:
                    suffix = "（收回前本機版）" if index == 1 else "（收回前本機版%d）" % index
                    kept = dest.with_name(dest.stem + suffix + dest.suffix)
                    transfer._reject_links(kept)
                    if not kept.exists():
                        break
                    index += 1
                shutil.copy2(dest, kept)
                print("累積資料：本機 %s 跟倉庫不同，以倉庫版為準，本機版另存 %s" % (dest, kept.name))
            if preserve_conflicts:
                original = dest
                index = 1
                while True:
                    suffix = "（倉庫版）" if index == 1 else "（倉庫版%d）" % index
                    dest = original.with_name(original.stem + suffix + original.suffix)
                    transfer._reject_links(dest)
                    if not dest.exists():
                        break
                    if dest.is_file() and sha(source) == sha(dest):
                        dest = None
                        break
                    index += 1
                if dest is None:
                    continue
                print("累積資料衝突：保留本機 %s，倉庫版另存 %s" % (original, dest))
        dest.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(source, dest)


def atomic_archive_copy(source, destination, validate=True, require_workspace=False):
    """同資料夾完成複製與驗證，最後原子替換。"""
    destination.parent.mkdir(parents=True, exist_ok=True)
    transfer._reject_links(destination)
    fd, temp_name = tempfile.mkstemp(prefix=".倉庫_", suffix=".tmp", dir=str(destination.parent))
    os.close(fd)
    tmp = Path(temp_name)
    try:
        shutil.copyfile(source, tmp)
        if validate:
            with tempfile.TemporaryDirectory(prefix="reg-verify-") as folder:
                extract(tmp, Path(folder))
                read_archive_state(Path(folder))
                if require_workspace and not workspace.is_workspace(folder):
                    raise ValueError("備份沒有工作區標記檔")
        replace_file(tmp, destination)
    finally:
        if tmp.exists():
            tmp.unlink()


def backup_name(folder, now=None):
    now = now or datetime.datetime.now()
    return folder / ("倉庫_" + now.strftime("%Y%m%d_%H%M%S") + ".zip")


def request_name_lines(request):
    """v1.50.1：請求檔名、請求內容、跑完要讀的結果檔名一起印。
    第二、三次模擬 AI 讀結果都先漏掉 .json（讀 請求_X.結果.txt）→ 失敗 → tree → 再讀，各白走 2 步。"""
    name = "請求_隔離區_%s.json" % datetime.datetime.now().strftime("%Y%m%d_%H%M%S_%f")
    return ["本機請求檔名：%s；把 <AI工作區根目錄> 換成本機絕對路徑。" % name,
            json.dumps(request, ensure_ascii=False, indent=2),
            "使用者說好了之後讀 <skill資料夾>/_請求/%s.結果.txt（請求檔全名再加 .結果.txt，.json 要留著）。" % name]


def timeout_request(root_rel, archive, action, command=None, args=()):
    if archive:
        request = {"倉庫": "<AI工作區根目錄>/" + root_rel + "/_隔離區/倉庫.zip"}
        if action == "執行":
            request.update({"指令": command, "參數": list(args)})
        else:
            request["操作"] = "取回"
        return request
    if action != "執行":
        command, args = "建工作區", ()
    return {"指令": command, "參數": list(args) + ["--workspace", "<AI工作區根目錄>/" + root_rel]}



def shorten_output(text, iso):
    """子程序輸出太長時只留頭尾（隔離平台會截斷很長的輸出，排在後面的照抄清單會看不到），全文另存。
    v1.60.0：行數也算。平台只留最後 50 行，以前 114 行的輸出前面默默不見（看報告 --全部 只看到後半），AI 不知道少了。"""
    rows = text.splitlines()
    if len(text) <= OUTPUT_LIMIT and len(rows) <= OUTPUT_LINES:
        return text
    iso.mkdir(parents=True, exist_ok=True)
    # 每次用新檔名：隔離平台不覆寫沒列進 input_files 的既有檔
    full = iso / ("程式輸出_%s.txt" % datetime.datetime.now().strftime("%Y%m%d_%H%M%S_%f"))
    with open(full, "w", encoding="utf-8", newline="") as f:     # 原樣存：Windows 不把 \r\n 再轉成 \r\r\n
        f.write(text)
    # v1.60.6：字數超過時也照行數留頭尾。以前只照字數切前後各 2 萬字，一行一列的報告還是一兩百行，
    # 平台只留最後 50 行，「全文在哪」那行被切掉，AI 只看到後半段、也不知道有全文檔（看報告 --全部 --欄 全部）
    half = OUTPUT_LIMIT // 2
    if len(rows) > OUTPUT_HEAD_LINES + OUTPUT_TAIL_LINES:
        head, tail = "\n".join(rows[:OUTPUT_HEAD_LINES]), "\n".join(rows[-OUTPUT_TAIL_LINES:])
    else:                                   # 行數少、字數多（很長的幾行）：照字數各留一半
        head, tail = text, text
    cut = len(head) > half or len(tail) > half
    # 字數切完再限行數：尾巴最多 20 行，提示後面加上照抄清單才不會被擠出平台留的 50 行
    head = "\n".join(head[:half].splitlines()[:OUTPUT_HEAD_LINES])
    tail = "\n".join(tail[-half:].splitlines()[-OUTPUT_TAIL_LINES:])
    note = "……（程式輸出 %d 行、%d 字，中間省略%s；全文在 _隔離區/%s，要看全部就讀那個檔）……" % (
        len(rows), len(text), "，太長的行也截掉一段" if cut else "", full.name)
    return "\n".join(part for part in (head, note, tail) if part)


def stream_process(call, cwd, env, root, workspace_label, extra=()):
    read_fd, write_fd = os.pipe()
    def forward():
        with os.fdopen(read_fd, "rb") as output:
            pending = b""
            while True:
                chunk = output.read1(4096)
                if not chunk:
                    break
                pending += chunk
                while b"\n" in pending or b"\r" in pending:
                    positions = [i for i in (pending.find(b"\n"), pending.find(b"\r")) if i >= 0]
                    end = min(positions) + 1
                    part, pending = pending[:end], pending[end:]
                    print(display_output(part.decode("utf-8", "replace"), root, workspace_label, extra=extra), end="", flush=True)
            if pending:
                print(display_output(pending.decode("utf-8", "replace"), root, workspace_label, extra=extra), end="", flush=True)
    reader = threading.Thread(target=forward)
    reader.start()
    try:
        run = subprocess.run(call, cwd=str(cwd), env=env, stdout=write_fd, stderr=subprocess.STDOUT)
    finally:
        os.close(write_fd)
        reader.join()
    if run.stdout:
        print(display_output(run.stdout.decode("utf-8", "replace"), root, workspace_label, extra=extra), end="", flush=True)
    return run.returncode


@contextlib.contextmanager
def memo_lock(folder, timeout=120, stale=600):
    """跨工作區保護累積資料合併；程式執行期間不持鎖。"""
    import memo_merge
    folder.mkdir(parents=True, exist_ok=True)
    path = folder / memo_merge.LOCK_NAME
    transfer._reject_links(path)
    token = uuid.uuid4().hex
    deadline = time.monotonic() + timeout
    announced = False
    while True:
        try:
            fd = os.open(str(path), os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
            try:
                with os.fdopen(fd, "w", encoding="utf-8") as f:
                    json.dump({"pid": os.getpid(), "時間": datetime.datetime.now().astimezone().isoformat(),
                               "代號": token}, f, ensure_ascii=False)
            except BaseException:
                path.unlink(missing_ok=True)
                raise
            break
        except FileExistsError:
            transfer._reject_links(path)
            try:
                if time.time() - path.stat().st_mtime > stale:
                    path.unlink()
                    continue
            except FileNotFoundError:
                continue
            if time.monotonic() >= deadline:
                raise TimeoutError("等待累積資料合併鎖超過兩分鐘")
            if not announced:
                print("另一個工作區正在合併累積資料，等它做完", flush=True)
                announced = True
            time.sleep(min(1, max(0, deadline - time.monotonic())))
    try:
        yield
    finally:
        try:
            current = json.loads(path.read_text(encoding="utf-8"))
            if current.get("代號") == token:
                path.unlink()
        except FileNotFoundError:
            pass


def _memo_for_warehouse(memo_real):
    """本機累積資料裡要複製進倉庫的檔：語意向量只放本機，衝突紀錄有兩邊的原文，也只放本機。"""
    import memo_merge
    return {n: p for n, p in transfer._files(memo_real)[0].items()
            if not memo_merge.vector_file(n)
            and Path(n).name not in (memo_merge.LOCK_NAME, memo_merge.CONFLICT_NAME)}


def merge_memo(memo_real, memo, prepare=False, return_local=False):
    """在鎖內合併累積資料，準備新倉庫時先複製完整本機資料。"""
    import memo_merge
    with memo_lock(memo_real):
        if prepare and memo_real.is_dir():
            copy_entries(_memo_for_warehouse(memo_real), memo)
        report = memo_merge.merge(memo_real, memo, memo / memo_merge.BASE_NAME, return_local=return_local)
    print("累積資料：跟本機合併（補 %d 檔、改 %d 檔、刪 %d 筆、衝突 %d 筆）" %
          (report["補檔"], report["改檔"], report["刪除鍵"], report["衝突"]))
    if report.get("別單位"):
        print("累積資料：%d 筆是別的單位用了同一個鍵，兩邊都留著（紀錄在本機 %s）" % (report["別單位"], memo_merge.CONFLICT_NAME))
    for kind in ("壞檔", "不認得"):
        if report[kind]:
            print("累積資料%s：%s" % (kind, "；".join(report[kind])))
    return report


def try_merge_memo(memo_real, memo, **options):
    """合併有問題時回報並繼續主要作業。"""
    try:
        return merge_memo(memo_real, memo, **options)
    except Exception as exc:
        print("累積資料這次沒合併（%s），下次本機那一步會再合" % exc, flush=True)
        if options.get("prepare") and memo_real.is_dir():
            # 建新倉庫時合併失敗（例如等鎖逾時）：至少照以前把本機累積資料補進去，不讓新倉庫空空的
            copy_entries(_memo_for_warehouse(memo_real), memo, missing_only=True)
        return None

def set_aside_half_round(real, root):
    """收回本機之前：本機中斷的那一輪跟倉庫做完的一輪同名時（準備 退回之後，倉庫開新一輪會用到同一個號碼），
    半輪的檔不能跟倉庫的檔混在一起：搬到 _隔離區/中斷留底/，不刪。"""
    import todo
    mark = todo.unfinished_round(str(real)) or {}
    name = mark.get("本輪") or ""
    if not name or not (root / name).is_dir() or not (real / name).is_dir():
        return
    keep = real / "_隔離區" / "中斷留底"
    keep.mkdir(parents=True, exist_ok=True)
    target = keep / ("%s_%s" % (name, datetime.datetime.now().strftime("%Y%m%d_%H%M%S_%f")))
    try:
        move_path(real / name, target)
    except OSError as exc:
        raise ValueError("本機中斷的那一輪 %s 有檔案開著，搬不開（%s）：關掉後再跑一次 收回本機。沒有檔案不見，已搬的留在 %s"
                         % (name, exc.strerror or exc, keep.relative_to(real).as_posix())) from exc
    print("本機中斷的那一輪 %s 跟倉庫的同名，半輪的檔搬到 %s" % (name, target.relative_to(real).as_posix()))


def recall_order(entries):
    """收回本機的複製順序：跑完記號和指標檔最後才寫。中途被中斷時，本機還指著原本那一輪，
    不會指到只複製一半的倉庫那一輪、又被當成跑完（跟解開工作區的 MARKERS 同一個想法）。"""
    import todo

    def rank(item):
        name = item[0]
        if name in transfer.MARKERS:
            return 2
        return 1 if name.rsplit("/", 1)[-1] == todo.ROUND_DONE else 0
    return sorted(entries.items(), key=rank)


def forget_local_round(real):
    """收回本機之後倉庫才是權威：目前作業已經換成倉庫的，本機中斷的標記不算數，留著會把倉庫做完的一輪退掉。"""
    import todo
    try:
        todo.clear_round(str(real))
    except OSError as exc:
        print("提醒：%s 刪不掉（%s）：關掉占用它的程式再跑一次 收回本機" % (todo.ROUND_MARK, exc))


def local_relay(data, skill):
    """本機請求入口；倉庫仍是權威資料，本機既有多餘檔案保留。"""
    status_sink = getattr(sys.stdout, "relay_status", lambda text: print(text, end=""))
    import local_request
    if not Path(data.get("倉庫", "")).is_absolute():
        raise ValueError("倉庫必須是工作區/_隔離區/倉庫.zip 的絕對路徑")
    archive = local_request._local_path(data.get("倉庫", ""), skill)
    if not archive.is_absolute() or archive.name != "倉庫.zip" or archive.parent.name != "_隔離區":
        raise ValueError("倉庫必須是工作區/_隔離區/倉庫.zip 的絕對路徑")
    transfer._reject_links(archive)
    real = archive.parent.parent
    if not real.is_dir():
        raise ValueError("找不到工作區")
    if not workspace.is_workspace(str(real)):
        raise ValueError("不是工作區：找不到工作區標記檔")
    # v1.54.0：每一種倉庫操作都要過，以前只有「執行」經過 validate_parameters
    local_request.check_workspace_outside_skill(real, skill)
    transfer._reject_links(real / workspace.LAYOUT_FILE)
    local_request._local_path(str(real / workspace.LAYOUT_FILE), real)
    local_request._reject_workspace_links(real)
    note = old_launcher_note(real)
    if note:
        print(note)
    action = data.get("操作", "執行")
    if action not in ("準備", "收回本機", "取回", "還原備份", "執行"):
        raise ValueError("不允許的倉庫操作")
    if action == "執行":
        request_name = data.get("程式") or data.get("指令")
        if request_name not in local_request._RULES or request_name in local_request.NO_WAREHOUSE:
            raise ValueError("不允許的倉庫指令")
        local_request.validate_parameters(request_name, data.get("參數", []), skill, real)
    elif data.get("參數"):
        raise ValueError("倉庫操作不接受參數")
    memo_real = transfer._memo_dir()
    library_real = Path(os.environ.get("REG_LIBRARY_DIR") or (skill / "資料庫"))
    # 寫回前要確認倉庫沒在這段時間被別的動作換掉（隔離區或另一個對話），不然後完成的會蓋掉先完成的
    archive_sha = sha(archive) if archive.is_file() else None
    start_real = {}
    with tempfile.TemporaryDirectory(prefix="reg-local-") as tmp:
        temp = Path(tmp)
        root = temp / real.name
        root.mkdir()
        state = {"公開": {}, "排隊": [], "待覆寫": []}
        if action == "還原備份":
            backups = sorted(p for p in (archive.parent / "備份").glob("倉庫_*.zip")
                             if re.fullmatch(r"倉庫_\d{8}(?:_\d{6})?\.zip", p.name) and p.is_file())
            if not backups:
                raise ValueError("找不到倉庫備份；本機工作區還在的話，改送「準備」從本機工作區重建倉庫")
            # v1.49.0：最新的備份壞了就往前找（以前只試最新一份）
            backup, failures = None, []
            for candidate in reversed(backups):
                transfer._reject_links(candidate)
                try:
                    with tempfile.TemporaryDirectory(prefix="reg-restore-verify-") as folder:
                        extract(candidate, Path(folder))
                        read_archive_state(Path(folder))
                        if not workspace.is_workspace(folder):
                            raise ValueError("備份沒有工作區標記檔")
                except (OSError, ValueError, zipfile.BadZipFile, EOFError, RuntimeError) as exc:
                    failures.append("%s（%s）" % (candidate.name, exc))
                    continue
                backup = candidate
                break
            if backup is None:
                raise ValueError("備份都損壞或無法安全解開：%s。本機工作區還在的話，改送「準備」從本機工作區重建倉庫"
                                 % "；".join(failures)) from None
            for failure in failures:
                print("這份備份不能用，改用更早的：%s" % failure)
            if archive.exists():
                damaged = archive.with_name("倉庫_損壞_%s_%s.zip" % (datetime.datetime.now().strftime("%Y%m%d_%H%M%S"), uuid.uuid4().hex[:8]))
                atomic_archive_copy(archive, damaged, validate=False)
                print("原倉庫保留：%s" % damaged)
            atomic_archive_copy(backup, archive, require_workspace=True)
            print("已還原備份：%s" % backup)
            status_text = ("執行時間：%s 流水號：%s\n已還原倉庫。接下來可執行取回。\n"
                           "下一次 input_files 照抄清單：\n<skill資料夾>/隔離區/reg-report程式.zip\n"
                           "<skill資料夾>/設定.html\n%s\n%s\n" %
                           (datetime.datetime.now().isoformat(timespec="microseconds"), uuid.uuid4().hex,
                            archive, archive.parent / "下一步.txt"))
            (archive.parent / "下一步.txt").write_text(status_text, encoding="utf-8")
            status_sink(status_text)
            return 0
        if action == "準備":
            if (real / transfer.ROUND_MARK).is_file():
                # 沒跑完的那一輪不能當倉庫的目前作業：標記不進倉庫，隔離區認不出來，前一輪會接到半輪上
                with transfer._transfer_lock(real):
                    transfer._settle_round(real)
                print("本機上一次沒跑完的那一輪沒有帶進倉庫，倉庫的目前作業是上一輪：隔離區跑 繼續 時，檔案改過就會重做；"
                      "檔案沒改、只是要重跑，請明確說要重新比對或體檢")
            if archive.is_file():
                # 已有倉庫時，舊倉庫先留一份（誤送準備時，隔離區做過但還沒帶回的成果還找得回來）
                old = archive.parent / "備份" / ("倉庫_準備前_%s.zip" % datetime.datetime.now().strftime("%Y%m%d_%H%M%S_%f"))
                atomic_archive_copy(archive, old, validate=False)
                print("已經有倉庫：舊倉庫先另存 %s，再用本機工作區重建。" % old.relative_to(real).as_posix())
            copy_entries(files(real), root)
            memo = root / "_skill累積/memoization"
            try_merge_memo(memo_real, memo, prepare=True)
            if library_real.is_dir():
                copy_entries(transfer._files(library_real)[0], root / "_skill資料庫")
            prune(root)
            state["公開"] = {n: sha(p) for n, p in files(root).items() if public(n)}
            state.pop(SKILL_DIR_KEY, None)         # v1.51.0：本機路徑不再進倉庫狀態（捷徑不含路徑；倉庫會送到 AI 端）
        else:
            if not archive.is_file():
                raise ValueError("找不到倉庫")
            extract(archive, root)
            state = read_archive_state(root)
            state.pop(SKILL_DIR_KEY, None)         # v1.51.0：舊倉庫記的本機路徑順手拿掉
            if action != "執行" or data.get("程式"):
                note = workspace.program_version_note(root)    # 這幾條不經過 run_all，版本提醒在這裡印
                if note:
                    print(note)
            memo = root / "_skill累積/memoization"
            if action == "收回本機":
                available = files(root)
                set_aside_half_round(real, root)
                extra = sorted(set(files(real)) - set(available))
                for name, source in recall_order(available):
                    dest = real / safe(name)
                    transfer._reject_links(dest)
                    if name.startswith("匯入/") and dest.is_file() and sha(dest) != sha(source):
                        alternate = dest.with_name(dest.stem + "（倉庫版）" + dest.suffix)
                        index = 2
                        while alternate.exists():
                            alternate = dest.with_name(dest.stem + "（倉庫版%d）" % index + dest.suffix)
                            index += 1
                        transfer._reject_links(alternate)
                        alternate.parent.mkdir(parents=True, exist_ok=True)
                        shutil.copy2(source, alternate)
                        print("匯入衝突：保留本機 %s，倉庫版另存 %s" % (name, alternate.relative_to(real).as_posix()))
                    elif (public(name) and dest.is_file() and sha(dest) != sha(source)
                          and sha(dest) != state.get("公開", {}).get(name)):
                        # 本機這份是使用者改過、還沒帶進倉庫的版本：保留本機，倉庫版放衝突
                        kept = keep_conflict(root, name, source, real)
                        print("衝突：%s 本機改過，保留本機版本；倉庫版另存在 %s" % (name, kept))
                    else:
                        copy_entries({name: source}, real)
                for name, source in kept_conflicts(root).items():
                    copy_entries({name.split("/", 1)[-1]: source}, real / "_隔離區" / "衝突", missing_only=True)
                forget_local_round(real)
                try_merge_memo(memo_real, memo, return_local=True)
                library = root / "_skill資料庫"
                if library.is_dir():
                    copy_entries(transfer._files(library)[0], library_real, backup_local=True)
                print("收回本機完成；本機多出來的檔案（保留）：")
                for name in extra:
                    print(name)
                candidate = temp / "收回後倉庫.zip"
                fits, _ = archive_for_isolation(root, memo, state, candidate,
                                                 skill / "隔離區/reg-report程式.zip", skill / "設定.html", print,
                                                 memo_scope(memo, memo_real, root, real, skill, temp / "累積過濾"))
                if archive_sha is not None and (not archive.is_file() or sha(archive) != archive_sha):
                    kept = archive.parent / ("倉庫_候選_%s.zip" % datetime.datetime.now().strftime("%Y%m%d_%H%M%S_%f"))
                    atomic_archive_copy(candidate, kept, validate=False)
                    print("收回期間倉庫被更新，合併結果另存：%s" % kept)
                    return 4
                folder = archive.parent / "備份"
                today = datetime.datetime.now().strftime("%Y%m%d")
                if not any(folder.glob("倉庫_" + today + "*.zip")):
                    atomic_archive_copy(archive, backup_name(folder))
                atomic_archive_copy(candidate, archive)
                if not fits:
                    # v1.49.0：收回本機就是要改用本機模式，做完了就回 0；以前回 3，AI 照說明又送一次收回本機，一直重送
                    print("倉庫超過隔離區上限：收回本機已經做完、倉庫也存好了。之後請用本機模式（設定頁「執行方式」選本機），不要再送進隔離區。")
                return 0
            if library_real.is_dir():
                # v1.49.0：使用者後來放進 skill 資料庫的規範、AI 看圖打的 .txt，以前只有「準備」才進倉庫，
                # 隔離區一直看不到、下一輪還列在待轉文字。本機接力時把新的、改過的帶進去（不刪倉庫那份）
                held = transfer._files(root / "_skill資料庫")[0] if (root / "_skill資料庫").is_dir() else {}
                fresh = {n: p for n, p in transfer._files(library_real)[0].items()
                         if n not in held or sha(p) != sha(held[n])}
                if fresh:
                    copy_entries(fresh, root / "_skill資料庫")
                    print("規範資料庫帶進倉庫：%d 份" % len(fresh))
            current = files(root)
            for name, src in files(real).items():
                imported = name.startswith(("匯入/", "_AI答案/"))
                if imported:
                    if name in current and sha(src) == sha(current[name]):
                        continue
                elif not public(name) or sha(src) == state.get("公開", {}).get(name):
                    continue
                first = name.split("/", 1)[0]
                if workspace.is_output_dir(str(root), str(root / first)) and not (root / first).is_dir():
                    continue
                copy_entries({name: src}, root)
                print("帶入：" + name)
            # 開始時本機公開檔的樣子；寫回前再比一次，執行期間使用者改過的不覆蓋
            start_real = {n: sha(p) for n, p in files(real).items() if public(n)}
            if action == "執行":
                import semantic_memory
                state["本機電腦"] = semantic_memory.computer_id()     # 隔離區用它認設定.html 裡哪一筆語意紀錄算數
                try_merge_memo(memo_real, memo)
                # 語意向量快取只放本機（不進倉庫）：帶進暫存累積資料，跑完再存回，不然每次都要從頭重算
                vector_cache = {n: p for n, p in (transfer._files(memo_real)[0].items() if memo_real.is_dir() else ())
                                if Path(n).name.startswith("語意向量.sqlite")}
                copy_entries(vector_cache, memo)
                _, converted = local_request.validate_parameters(
                    request_name, data.get("參數", []), skill, real, root)
                if data.get("程式") == "semantic_candidates":
                    converted, missing_model = semantic_options(skill, converted)
                    for i, arg in enumerate(converted):
                        if arg in ("--model", "--rerank-model"):
                            local_request.validate_model_path(converted[i + 1], skill, (real, root))
                        elif arg.startswith(("--model=", "--rerank-model=")):
                            local_request.validate_model_path(arg.split("=", 1)[1], skill, (real, root))
                    call = [sys.executable, "-B", str(skill / "scripts/semantic_candidates.py"), "--workspace", str(root), *converted]
                else:
                    missing_model = False
                    call = [sys.executable, "-B", str(skill / "scripts/run_all.py"), "--workspace", str(root), data["指令"], *converted]
                # REG_RELAY_REAL_ROOT：核對原始 的「../原始資料夾」要從真正的工作區算，不是暫存區（v1.50.0）
                env = dict(os.environ, REG_ACCUMULATED_DIR=str(memo), REG_LIBRARY_DIR=str(root / "_skill資料庫"), REG_NO_HW_RECORD="1",
                           REG_WAREHOUSE_RELAY="1", REG_RELAY_REAL_ROOT=str(real), REG_RUN_REQUEST="1", PYTHONIOENCODING="utf-8")
                env["PYTHONUNBUFFERED"] = "1"
                shown = ((memo, memo_real), (root / "_skill資料庫", library_real))
                try:
                    rc = stream_process(call, skill, env, root, str(real), extra=shown) or (2 if missing_model else 0)
                    if rc == 2 and data.get("程式") == "semantic_candidates":
                        rc = skip_unavailable_semantic(skill, env, root, real, shown)
                finally:
                    try_merge_memo(memo_real, memo)
                if memo.is_dir():
                    memo_real.mkdir(parents=True, exist_ok=True)
                    copy_entries({n: p for n, p in transfer._files(memo)[0].items()
                                  if Path(n).name.startswith("語意向量.sqlite")}, memo_real)
            else:
                rc = 0
        if action == "準備":
            rc = 0
        prune(root)
        published = {n: p for n, p in files(root).items() if public(n)}
        visible = {n: sha(p) for n, p in published.items()}
        pending, overwrite = [], []

        def changed_meanwhile():
            return action != "準備" and archive_sha is not None and (not archive.is_file() or sha(archive) != archive_sha)

        def save_candidate(reason):
            kept = archive.parent / ("倉庫_候選_%s.zip" % datetime.datetime.now().strftime("%Y%m%d_%H%M%S_%f"))
            state.update({"公開": visible, "排隊": [], "待覆寫": [], "前一版": {}})
            make_archive(root, memo, state, temp / "候選.zip",
                         scope=memo_scope(memo, memo_real, root, real, skill, temp / "累積過濾"))
            atomic_archive_copy(temp / "候選.zip", kept, validate=False)
            text = ("%s倉庫沒有被換掉，這次的結果另存成 %s。\n"
                    "同一個工作區一次只跑一件；請先確認另一個動作做完，再重新送一次這個本機請求。\n" % (reason, kept))
            print(text, end="")
            status_sink(text)
            return 4

        if changed_meanwhile():
            return save_candidate("執行期間倉庫被別的動作更新過（隔離區或另一個對話）：這次結果沒有寫回工作區，")
        if action != "準備":
            for name, src in sorted(published.items()):
                dest = real / safe(name)
                try:
                    transfer._reject_links(dest)
                    if dest.is_file():
                        now = sha(dest)
                        if now == visible[name]:
                            continue
                        if now != start_real.get(name):
                            kept = keep_conflict(root, name, src, real)
                            print("衝突：%s 在執行期間被改過，保留你的版本；這次算出的版本另存在 %s" % (name, kept))
                            continue
                    atomic_write(src, dest)
                except OSError as exc:
                    # 寫不進去（多半是檔案開著）：本機還是舊的，記回待送，下次取回再送
                    print("沒寫回：%s（%s；可能檔案開著）。關掉檔案後送 取回 會再送一次。" % (name, exc))
                    if start_real.get(name) is None:
                        visible.pop(name)
                        pending.append(name)
                    else:
                        visible[name] = start_real[name]
                        overwrite.append(name)
        state.update({"公開": visible, "排隊": pending, "待覆寫": overwrite, "前一版": {}})
        backup = None
        if archive.exists():
            folder = archive.parent / "備份"
            today = datetime.datetime.now().strftime("%Y%m%d")
            if not any(folder.glob("倉庫_" + today + "*.zip")):
                backup = backup_name(folder)
            state["備份日"] = today
        candidate = temp / "新倉庫.zip"
        fits, limit_mb = archive_for_isolation(root, memo, state, candidate,
                                                skill / "隔離區/reg-report程式.zip", skill / "設定.html", print,
                                                memo_scope(memo, memo_real, root, real, skill, temp / "累積過濾"))
        size_mb = candidate.stat().st_size / (1024 * 1024)
        print("倉庫大小：%.2f MB" % size_mb)
        warning = ""
        if not fits:
            # v1.49.0：講清楚這一步本身有沒有做完；這一步失敗時留它自己的結束碼，不要被 3 蓋掉
            warning = ("倉庫 %.2f MB 超過隔離區上限，隔離區已不能用；請改本機模式（設定頁改執行方式後送 收回本機）。"
                       "這一步本身：%s" % (size_mb, "做完了，結果已存進倉庫" if rc == 0 else "沒做完（結束碼 %d），照上面的訊息處理" % rc))
            print(warning)
            if rc == 0:
                rc = 3
        archive.parent.mkdir(parents=True, exist_ok=True)
        if changed_meanwhile():
            return save_candidate("寫回工作區後發現倉庫剛被別的動作更新過（隔離區或另一個對話）：")
        if backup:
            atomic_archive_copy(archive, backup)
        atomic_archive_copy(candidate, archive)
        status_text = ("執行時間：%s 流水號：%s\n本機已更新倉庫；以下兩個代號請換成本機絕對路徑。\n"
                       "下一次 input_files 照抄清單：\n<skill資料夾>/隔離區/reg-report程式.zip\n"
                       "<skill資料夾>/設定.html\n%s\n%s\n還在排隊的取回數量：%d\n"
                       "要覆寫的公開檔：%s\n可刪除的本機殘留檔：無\n"
                       % (datetime.datetime.now().isoformat(timespec="microseconds"), uuid.uuid4().hex,
                          archive, archive.parent / "下一步.txt", len(pending) + len(overwrite),
                          "、".join(overwrite) or "無"))
        if warning:
            status_text = warning + "\n" + "執行時間：%s 流水號：%s\n" % (datetime.datetime.now().isoformat(timespec="microseconds"), uuid.uuid4().hex)
        (archive.parent / "下一步.txt").write_text(status_text, encoding="utf-8")
        status_sink(status_text)
        print("倉庫已更新：%s" % archive)
        return rc


def settings_in_isolation(command, args, setting, has_workspace=True):
    """v1.59.0：看設定直接讀帶進來的 設定.html，不用倉庫、什麼都不寫（輸出只留最後 50 行，所以分頁）。
    改設定只檢查、不寫檔：印出 before、after，AI 用 edit 工具改 skill 資料夾的 設定.html（這裡的 Python 寫不到，檔案工具寫得到）。
    算不出要換哪一行（舊版設定頁）才走本機請求：有工作區回 None 走平常的路，沒有就在這裡印請求單。"""
    import settings_view
    if command in SHOW_SETTINGS_COMMANDS:
        try:
            find, full, page = settings_view.parse_show_args(args)
            print("\n".join(settings_view.page_lines(settings_view.show_lines(str(setting), find, full), page)))
        except ValueError as exc:
            print("[中止] %s" % exc)
            return 1
        print("[結束碼] 0")
        print("看設定沒有動到任何檔。下一次 input_files 跟這次一樣。")
        return 0
    try:
        changes = settings_view.plan_changes(args, str(setting))
    except ValueError as exc:
        print("[中止] %s（沒有改任何設定）" % exc)
        return 1
    edits = settings_view.edit_plan(changes, str(setting))
    if edits is not None:
        print("\n".join(settings_view.edit_lines(changes, edits) + ["[結束碼] 0"]))
        return 0
    _SETTING_PREVIEW[:] = ["要改的設定（使用者雙擊、看過按 Enter 才生效）："] + settings_view.change_lines(changes)
    if has_workspace:
        return None
    print("\n".join(["需要在本機執行。"] + request_name_lines({"指令": command, "參數": args})
                    + ["請使用者雙擊 <skill資料夾>/執行下一步.cmd（改設定用不到工作區）。"] + _SETTING_PREVIEW + ["[結束碼] 0"]))
    return 0


def main(argv=None):
    # v1.47.0：隔離區的輸出是給 AI 讀的，不畫會回到行首覆寫的進度條（外面環境帶了也不要）
    os.environ.pop("REG_PROGRESS_BAR", None)
    parser = argparse.ArgumentParser()
    parser.add_argument("action", choices=("執行", "帶入", "取回", "路徑檢查", "準備", "收回本機", "建捷徑"))
    parser.add_argument("args", nargs=argparse.REMAINDER)
    opts = parser.parse_args(argv)
    if opts.action == "收回本機":
        raise ValueError("收回本機只能透過本機請求執行")
    args = list(opts.args)
    supplements = []
    supplement_all = False
    if opts.action == "取回":
        # 要補寫的檔很多時一個個列會超過參數長度上限：--補寫全部 = 沒列進 input_files 的待覆寫檔全部補寫
        while "--補寫全部" in args:
            args.remove("--補寫全部")
            supplement_all = True
        while "--補寫" in args:
            index = args.index("--補寫")
            if index + 1 >= len(args):
                raise ValueError("--補寫 後面要給相對工作區路徑")
            supplements.append(safe(args[index + 1]))
            del args[index:index + 2]
        if len(set(supplements)) != len(supplements):
            raise ValueError("--補寫 路徑重複")
    root_arg = None
    for flag in ("--工作區", "--workspace"):
        if flag in args:
            i = args.index(flag)
            if i + 1 >= len(args) or root_arg is not None:
                raise ValueError("工作區參數不正確")
            root_arg = safe(args[i + 1]); del args[i:i + 2]
    cwd = Path.cwd()
    program = find_one("**/reg-report程式.zip", "程式包")
    setting = find_one("**/設定.html", "設定.html")
    archive = find_one("**/_隔離區/倉庫.zip", "倉庫", required=False)
    command = args[0] if opts.action == "執行" and args else ""
    _SETTING_PREVIEW.clear()
    if command in SHOW_SETTINGS_COMMANDS or command in SET_SETTING_COMMANDS:
        answer = settings_in_isolation(command, args[1:], setting, bool(archive or root_arg))
        if answer is not None:
            return answer
    if archive:
        root_rel = safe(archive.parent.parent.as_posix())
        if root_arg and root_arg != root_rel:
            raise ValueError("工作區與倉庫位置不一致")
    elif root_arg:
        root_rel = root_arg
    else:
        raise ValueError("找不到倉庫（_隔離區/倉庫.zip）。已有工作區：把它的 倉庫.zip 和 下一步.txt 列進 input_files 再送一次；"
                         "新案子還沒有工作區：送 執行 --工作區 <名稱> 建工作區 --現行 <現行版資料夾> --修訂 <修訂版資料夾>，"
                         "兩個資料夾裡的規章檔都要列進 input_files")
    output_root = cwd / root_rel
    transfer._reject_links(output_root)
    if not archive and not workspace.is_workspace(str(output_root)) and workspace_name_problem(root_rel):
        raise ValueError(workspace_name_problem(root_rel))
    if opts.action == "建捷徑":
        # v1.51.0：--skill資料夾 保留相容，但內容不再寫進捷徑（捷徑固定、不含路徑）
        if args and (args[:1] != ["--skill資料夾"] or len(args) != 2):
            raise ValueError("建捷徑 不用參數（舊寫法 --skill資料夾 <路徑> 可以給，但不會寫進捷徑）")
        path = write_launcher(output_root)
        print("已建立捷徑：" + path.relative_to(cwd).as_posix())
        if args:
            print("捷徑不再含路徑，程式位置由本機登記（使用者在程式資料夾雙擊 打開設定.cmd 時登記），--skill資料夾 的值沒有用到。")
        print("請使用者雙擊工作區裡的 %s；第一次用這台電腦（或程式搬家後）請使用者先到程式資料夾雙擊一次 打開設定.cmd 登記程式位置。" % LAUNCHER)
        print("[結束碼] 0")
        return 0
    iso = output_root / "_隔離區"
    status = iso / "下一步.txt"
    lines = ["執行時間：%s 流水號：%s" % (datetime.datetime.now().isoformat(timespec="microseconds"), uuid.uuid4().hex),
             "以下清單的 <skill資料夾> 和 <AI工作區根目錄> 請換成本機絕對路徑；以工具回傳的 stdout 為準。"]
    request = None
    rc = 0
    with tempfile.TemporaryDirectory(prefix="reg-work-") as tmp:
        temp = Path(tmp)
        root = temp / Path(root_rel).name
        root.mkdir()
        state = {"公開": {}, "排隊": [], "待覆寫": []}
        reuse = None
        if archive:
            try:
                reuse = (archive, extract(archive, root))
                state = read_archive_state(root)
            except (OSError, ValueError, zipfile.BadZipFile, EOFError, RuntimeError) as exc:
                request = {"倉庫": "<AI工作區根目錄>/" + root_rel + "/_隔離區/倉庫.zip", "操作": "還原備份"}
                lines += ["[中止] 倉庫損壞或無法安全解開：%s。請在本機還原備份。" % exc,
                          *request_name_lines(request), *launcher_lines(root_rel), "[結束碼] 1"]
                iso.mkdir(parents=True, exist_ok=True)
                status.write_text("\n".join(lines) + "\n", encoding="utf-8")
                print("\n".join(lines))
                return 1
        original_state = copy.deepcopy(state)
        if opts.action != "執行":
            note = workspace.program_version_note(root)        # 帶入、取回不經過 run_all，版本提醒在這裡印
            if note:
                lines.append(note)
        memo = root / "_skill累積" / "memoization"
        (HERE.parent / "設定.html").write_bytes(setting.read_bytes())
        incoming = files(output_root)
        if opts.action == "準備" and (archive or incoming):
            raise ValueError("準備已有資料的工作區只能透過本機請求執行")
        visible = state.setdefault("公開", {})
        visible_sizes = state.setdefault("公開大小", {})
        before = {n: sha(p) for n, p in files(root).items() if public(n)}
        conflicts = []
        imported_public = set()
        conflict_names = set(state.get("衝突檔", []))
        for item in conflict_names:
            safe(item)
        for name in supplements:
            if name not in state.get("待覆寫", []):
                raise ValueError("--補寫 只接受待覆寫的檔案：" + name)
            if name in incoming:
                raise ValueError("--補寫 的檔案不要列進 input_files：" + name)
        if supplement_all:
            supplements += [n for n in state.get("待覆寫", []) if n not in incoming and n not in supplements]
        # 送出時本機原本的版本。檔案真的送到前就記成已公開，送不到（檔案開著）時本機舊版會被當成使用者修改，
        # 反過來蓋掉倉庫新版；本機還是這一版就當成「沒送到」，不帶入、重新排隊
        previous = state.setdefault("前一版", {})
        undelivered = set()
        for name, src in incoming.items():
            safe(name)
            dst = root / name
            if name in previous and name not in state.get("待覆寫", []):
                digest = sha(src)
                if digest == previous[name] and digest != visible.get(name):
                    undelivered.add(name)
                    lines.append("沒送到：%s（本機還是送出前的版本，可能當時檔案開著）；不當成修改，重新排隊再送" % name)
                    continue
                del previous[name]
            if name in state.get("待覆寫", []):
                if sha(src) == visible.get(name):
                    continue
                if dst.is_file() and sha(dst) != visible.get(name):
                    p = Path(name)
                    conflict_name = p.with_name(p.stem + "_" + uuid.uuid4().hex + p.suffix).as_posix()
                    safe(conflict_name)
                    # 換下來的倉庫版也存進倉庫：工作區那份沒帶回也不會永久遺失
                    conflict_file = root / KEEP / datetime.datetime.now().strftime("%Y%m%d") / conflict_name
                    conflict_file.parent.mkdir(parents=True, exist_ok=True)
                    shutil.copy2(dst, conflict_file)
                    conflicts.append((name, conflict_name, conflict_file))
                    conflict_names.add(conflict_name)
                    state["待覆寫"].remove(name)
            if not dst.is_file() or sha(dst) != sha(src):
                dst.parent.mkdir(parents=True, exist_ok=True)
                shutil.copyfile(src, dst)
                lines.append("帶入：" + name)
                if public(name):
                    imported_public.add(name)
            if public(name):
                visible[name] = sha(src)
                visible_sizes[name] = src.stat().st_size
        if opts.action == "路徑檢查":
            iso.mkdir(parents=True, exist_ok=True)
            mark = iso / ("路徑檢查_" + datetime.datetime.now().strftime("%Y%m%d_%H%M%S_%f") + ".txt")
            mark.write_text(mark.relative_to(cwd).as_posix() + "\n", encoding="utf-8")
            lines.append("請確認本機同一位置有檔案：" + mark.relative_to(cwd).as_posix())
        elif opts.action == "執行":
            if not args:
                raise ValueError("執行後面要給子指令")
            command = args.pop(0)
            if command in ("建工作區", "init-workspace"):
                # v1.56.0：這裡看不到使用者那邊有哪些工作區。同一天同名的序號會撞，新倉庫帶回去就蓋掉舊的，
                # 所以 AI 一定要先看過同一層、講清楚：有的列 --已有，沒有的寫 --沒有同名
                # 先 準備 建的空倉庫一樣會開新工作區，也要問；已經是工作區的只是補資料夾，不用問
                unseen = ((not archive or not workspace.is_workspace(str(root)))
                          and "--沒有同名" not in args and os.environ.get("REG_SKIP_SAME_NAME_ASK") != "1"      # 測試用，跟 REG_SKIP_REPORT_REVIEW 一樣
                          and not any(a == "--已有" or a.startswith("--已有=") for a in args))
                args = [a for a in args if a != "--沒有同名"]
                if unseen:
                    lines += ["[中止] 建工作區之前要先看同一層有沒有同名的工作區（隔離區看不到別的工作區；同一天同名會蓋掉舊工作區的倉庫）。",
                              "用檔案工具列出 AI 工作區根目錄：名稱是「%s」加 10 位數字的資料夾，每個都加一組 --已有 <資料夾名>；"
                              "一個都沒有就加 --沒有同名，再送一次。" % os.path.basename(workspace.workspace_base(Path(root_rel).name)),
                              "[結束碼] 1", "這次沒有建倉庫、沒有寫 下一步.txt。"]
                    print("\n".join(lines))
                    return 1
            original_values = set()
            text_options = ()
            if command in ("原始資料夾", "找工作區", "建工作區", "init-workspace"):
                # v1.50.0：建工作區 --現行／--修訂 也是原始資料夾（相對工作區，常帶 ..），只記文字、不當路徑檢查
                text_options = ("--原始",) if command == "找工作區" else ("--現行", "--修訂")
                original_values = {i + 1 for i, arg in enumerate(args[:-1]) if arg in text_options}
            for i, arg in enumerate(args):
                if i in original_values:
                    continue  # 只記文字，不在隔離區存取這些路徑
                if text_options and arg.startswith(tuple(option + "=" for option in text_options)):
                    continue
                if arg.startswith(("--workspace=", "--工作區=")) or arg in ("--workspace", "--工作區"):
                    raise ValueError("工作區參數重複或格式不正確")
                value = arg.split("=", 1)[-1]
                if not value.startswith(("http://", "https://")):
                    win = PureWindowsPath(value)
                    if win.is_absolute() or win.drive or Path(value).is_absolute() or ".." in value.replace("\\", "/").split("/"):
                        raise ValueError("參數含不安全路徑：" + arg)
            if command in LOCAL_ONLY_COMMANDS:
                # 設定頁只改 skill 的 設定.html，用不到倉庫；帶倉庫的話還沒建倉庫時會「找不到倉庫」
                # v1.49.0：打包分享也一樣——zip 要出在這台電腦的 skill 資料夾，隔離區做的跑完就丟了
                request = {"指令": command, "參數": args}
                lines.append("需要在本機執行。")
                if not archive:
                    # v1.50.2：沒帶倉庫時只印請求單，不在那個資料夾留空倉庫、下一步.txt（以前跟 v1.50.1 第 4 件一樣會留）
                    lines += ["[結束碼] 0", "這次沒有帶倉庫（_隔離區/倉庫.zip）：只印本機請求，沒有建倉庫、沒有寫 下一步.txt。"]
                    lines += request_name_lines(request)
                    lines += launcher_lines(root_rel)      # 沒有倉庫＝那裡不一定是工作區，不留檔
                    print("\n".join(lines + _SETTING_PREVIEW))
                    return 0
            else:
                # REG_SOURCE_ROOT：建工作區 --現行／--修訂 的相對路徑從暫存區解不到時，改從帶進來的檔實際所在算（v1.50.0）
                env = dict(os.environ, REG_ACCUMULATED_DIR=str(memo), REG_LIBRARY_DIR=str(root / "_skill資料庫"), REG_NO_HW_RECORD="1",
                           REG_ISOLATED="1", REG_SOURCE_ROOT=str(cwd / root_rel), PYTHONIOENCODING="utf-8",
                           REG_LOCAL_COMPUTER=str(state.get("本機電腦", "")))
                if command in WORD_OUTPUT_COMMANDS:
                    note = missing_package_note()
                    if note:
                        lines.append(note)
                converted = []
                for i, arg in enumerate(args):
                    if i in original_values or (text_options and arg.startswith(tuple(option + "=" for option in text_options))):
                        converted.append(arg)
                        continue
                    prefix = ""
                    value = arg
                    if arg.startswith("--") and "=" in arg:
                        prefix, value = arg.split("=", 1)
                        prefix += "="
                    rel = value.replace("\\", "/")
                    workspace_path = rel.startswith(root_rel + "/") or rel.startswith("匯入/")
                    if rel.startswith(root_rel + "/"):
                        rel = rel[len(root_rel) + 1:]
                    candidate = root / rel
                    if workspace_path and (not transfer._safe(rel) or not candidate.exists()):
                        raise ValueError("工作區檔案不存在或路徑不安全：" + arg)
                    # v1.50.2：以前只檢查「工作區名/…」「匯入/…」開頭的路徑，說明書教的 `填表 _AI答案/a.json` 寫法永遠不會被擋，
                    # 倉庫裡上次帶進去的舊答案就悄悄拿去填。改成：這一步要讀的檔只要在倉庫裡、這次又沒帶進來，一律擋
                    if (command in FRESH_FILE_COMMANDS and not arg.startswith("-") and not prefix
                            and transfer._safe(rel) and rel not in incoming and candidate.is_file()):
                        stamp = datetime.datetime.fromtimestamp(candidate.stat().st_mtime).strftime("%Y-%m-%d %H:%M")
                        raise ValueError("答案檔這次沒帶進來：%s（倉庫裡那份是 %s 帶進來的舊版，不能拿來填）；"
                                         "把它列進 input_files 再送一次" % (rel, stamp))
                    if (prefix or not arg.startswith("-")) and transfer._safe(rel) and candidate.exists():
                        transfer._reject_links(candidate)
                        converted.append(prefix + str(candidate))
                    else:
                        converted.append(arg)
                call = [sys.executable, "-B", str(HERE / "run_all.py"), "--workspace", str(root), command, *converted]
                try:
                    run = subprocess.run(call, cwd=str(HERE.parent), env=env, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                                         timeout=float(os.environ.get("REG_ISOLATED_BUDGET", "780")))
                    lines.append(shorten_output(display_output(run.stdout.decode("utf-8", "replace"), root,
                                                "<AI工作區根目錄>/" + root_rel, HERE.parent), iso)); rc = run.returncode
                except subprocess.TimeoutExpired as exc:
                    lines.append(shorten_output(display_output((exc.stdout or b"").decode("utf-8", "replace"), root,
                                                "<AI工作區根目錄>/" + root_rel, HERE.parent), iso))
                    lines.append("執行逾時，倉庫不動；本次帶入也未保存，請在本機執行。")
                    request = timeout_request(root_rel, archive, opts.action, command, args)
                    rc = 124
                if rc == 0 and command in ("開始", "繼續", "continue", "重新比對", "重跑開始",
                                           "體檢", "檢查現有文件", "health-check"):
                    import todo
                    current = workspace.current_output(str(root))
                    if current and todo.semantic_pending(current) and not todo._semantic_back(current)[0]:
                        request = {"倉庫": "<AI工作區根目錄>/" + root_rel + "/_隔離區/倉庫.zip", "程式": "semantic_candidates", "參數": []}
                        lines.append("下一站需要在本機計算語意。先存好以下本機請求並建好捷徑，再同一次請使用者選擇雙擊執行或回覆不執行；選不執行時刪掉請求單並送語意併入 --略過。")
                if command in FEEDBACK_COMMANDS or (command == "看報告" and "--有意見" in args):
                    brought = [n for n in incoming if n.endswith(".xlsx") and "/1_結果彙整/" in "/" + n]
                    if not brought:
                        lines.append("[注意] 這次沒帶任何報告 xlsx：程式讀的是倉庫裡的報告，承辦在 Excel 寫的意見讀不到。"
                                     "把寫了意見的報告（產出…/1_結果彙整/*.xlsx）列進 input_files 再送一次；"
                                     "名額不夠就先拿掉清單上的待覆寫檔（下次再帶）。")
                if (rc == 0 and command in ("單位建議", "單位資料建議", "unit-profile")
                        and (HERE.parent / "設定.html").read_bytes() != setting.read_bytes()):
                    # v1.49.0：第二次跑會把 AI 建議寫進設定頁；隔離區寫的是暫存區那份，跑完就丟了
                    request = {"倉庫": "<AI工作區根目錄>/" + root_rel + "/_隔離區/倉庫.zip", "指令": command, "參數": args}
                    lines.append("AI 建議核對過了，但要寫進這台電腦的設定頁，隔離區寫不到：先存好以下本機請求並建好捷徑，"
                                 "請使用者雙擊執行；跑完再請使用者打開設定頁看建議、按採用。")
                if rc == ORIGINALS_NEED_LOCAL and command == "核對原始":
                    # v1.50.0：隔離區讀不到原始資料夾，核對原始改到本機跑（以前只叫 AI 用檔案工具比大小）
                    request = {"倉庫": "<AI工作區根目錄>/" + root_rel + "/_隔離區/倉庫.zip", "指令": command, "參數": args}
                    lines.append("核對原始要在本機跑（隔離區讀不到原始資料夾）。先存好以下本機請求，請使用者雙擊捷徑執行；"
                                 "本機跑完說「好了」之後再送下一步。不要把原始檔帶進隔離區自己比。")
                    rc = 0
                if rc == HEALTH_NEEDS_LOCAL:
                    # 體檢的語意在 health_check 裡直接載模型算，沒辦法像比對那樣只把語意送去本機：整個體檢到本機跑
                    request = timeout_request(root_rel, archive, opts.action, command, args)
                    lines.append("體檢要在本機跑（隔離區沒有語意模型）。先存好以下本機請求並建好捷徑，再同一次請使用者選擇雙擊執行或回覆不執行；"
                                 "選不執行時刪掉請求單，改送 執行 %s --只比對文字（只比對文字）。本機跑完後送 執行 繼續 看下一站（審查資料已在本機打包好）。"
                                 % (" ".join([command] + [a for a in args if a not in ("--只比對文字", "--text-only")])
                                    if command in ("體檢", "檢查現有文件", "health-check") else "體檢 --設定已確認"))
                init_command = command in ("建工作區", "init-workspace")
                if not archive and (not init_command or rc != 0) and (request is None or "倉庫" not in request):
                    # v1.50.1：沒帶倉庫、也不是建工作區（例如 執行 執行方式 --workspace 指到原始資料夾）：只印結果。
                    # 以前照樣從空的暫存區打包一個空倉庫、在那個資料夾留 _隔離區/倉庫.zip 和 下一步.txt（第三次模擬 AI 之後自己去刪）
                    # v1.50.2：建工作區沒成功（資料夾找不到、逾時）也一樣——以前留下空倉庫還叫 AI 下次帶著它，AI 帶著重送
                    # 正確的建工作區時暫存區的資料夾被改名、整支程式炸掉、剛建好的工作區丟掉；打包分享／打開設定
                    # （本機請求用不到倉庫）也一樣只印請求單
                    lines.append("[結束碼] %d" % rc)
                    if init_command:
                        lines.append("建工作區沒成功：沒有建倉庫、沒有寫 下一步.txt。照上面的 [中止] 修正後再送一次 執行 建工作區 …（一樣不用帶倉庫）。")
                    else:
                        lines.append("這次沒有帶倉庫（_隔離區/倉庫.zip）、也不是建工作區：只印結果，沒有建倉庫、沒有寫 下一步.txt。"
                                     "要接著做某個工作區的步驟，把 <AI工作區根目錄>/<工作區>/_隔離區/倉庫.zip 和 下一步.txt 列進 input_files。"
                                     "新案子還沒有工作區：先送 執行 --工作區 <名稱> 建工作區 --現行 <現行版資料夾> --修訂 <修訂版資料夾>，"
                                     "兩個資料夾裡的規章檔都要列進 input_files。")
                    if request:
                        lines += request_name_lines(request)
                        lines += launcher_lines(root_rel)  # 沒有倉庫＝那裡不一定是工作區，不留檔
                    print("\n".join(lines))
                    return rc
                if init_command and rc == 0 and (not archive or not root.exists()):
                    # v1.56.0：照說明先 準備 --工作區 建了空倉庫、再送 建工作區：資料夾被加上日期序號，
                    # 以前往下做會印「[WinError 3] …暫存路徑…」。跟沒帶倉庫時一樣接到新資料夾，空倉庫收掉
                    empty_archive = archive if archive and not original_state.get("公開") else None
                    candidates = workspace.dated_workspaces(str(root))
                    if len(candidates) != 1:
                        raise ValueError("無法確定新工作區位置")
                    created = Path(candidates[0]); root = created
                    root_rel = safe(str(Path(root_rel).with_name(created.name)).replace(os.sep, "/"))
                    output_root = cwd / root_rel; iso = output_root / "_隔離區"; status = iso / "下一步.txt"
                    if output_root.exists():
                        raise ValueError("新工作區已存在，停止以免混入：" + root_rel)
                    if archive:
                        lines.append("工作區建在 <AI工作區根目錄>/%s；原本的空資料夾不用了，之後都用新的這個。" % root_rel)
                        if empty_archive:
                            shutil.rmtree(empty_archive.parent, ignore_errors=True)
                        archive = None
                    memo = root / "_skill累積" / "memoization"
        if opts.action != "路徑檢查" and rc != 124:
            prune(root)
        after_files = files(root)
        after = {n: sha(p) for n, p in after_files.items() if public(n)}
        for name in supplements:
            if name not in after:
                raise ValueError("待補寫的倉庫檔案不存在：" + name)
        pending = set(state.get("排隊", [])); overwrite = set(state.get("待覆寫", []))
        pending.update(n for n in undelivered if n in after)
        for name, digest in after.items():
            if before.get(name) != digest and visible.get(name) != digest:
                (overwrite if name in visible else pending).add(name)
        deleted = []
        for name in list(visible):
            if name in after:
                continue
            first = name.split("/", 1)[0]
            if not (workspace.is_output_dir(str(root), str(root / first)) and not (root / first).is_dir()):
                deleted.append(name)
            del visible[name]
            visible_sizes.pop(name, None)
        deleted.sort()
        pending.intersection_update(after); overwrite.intersection_update(after)
        # 升版後才變公開的檔（批次摘要、審查包）：倉庫有、從沒帶回過；只補這一輪的，舊輪次不倒回工作區
        current_round = workspace.current_output(str(root))
        if current_round:
            prefix = Path(current_round).name + "/"
            pending.update(n for n in after if n.startswith(prefix) and n not in visible and n not in overwrite)
        emit = []
        too_many_conflicts = False
        if opts.action != "路徑檢查" and rc != 124:
            maximum = max(0, min(90, int(os.environ.get("REG_ISOLATED_MAX_OUT", "90"))))
            if len(conflicts) > maximum:
                too_many_conflicts = True
                rc = 1
                lines.append("衝突檔超過本次帶回上限，倉庫不動；請減少本次帶入的檔案後重試。")
            maximum = max(0, maximum - len(conflicts))
            for name in sorted(overwrite):
                if ((name in incoming and (sha(incoming[name]) == visible.get(name) or name in imported_public))
                        or (opts.action == "取回" and name in supplements)) and len(emit) < maximum:
                    emit.append(name)
            for name in sorted(pending):
                if len(emit) >= maximum:
                    break
                emit.append(name)
            pending.difference_update(emit); overwrite.difference_update(emit)
            for name in emit:
                if visible.get(name) and visible[name] != after[name]:
                    previous.setdefault(name, visible[name])
                visible[name] = after[name]
                visible_sizes[name] = after_files[name].stat().st_size
                # Windows 路徑太長存不了；AI 工作區根目錄本身也佔長度，相對路徑超過 200 字先提醒
                if len(root_rel + "/" + name) > 200:
                    lines.append("提醒：%s 路徑很長，Windows 可能存不了；帶不回來時請把工作區放淺一點的資料夾" % name)
        import_lines = ["%s %d %s" % (name, path.stat().st_size, sha(path)[:12])
                        for name, path in sorted(after_files.items()) if name.startswith("匯入/")]
        state.update({"公開": visible, "排隊": sorted(pending), "待覆寫": sorted(overwrite)})
        if conflicts:
            state["衝突檔"] = sorted(conflict_names)
        too_big = False
        if opts.action != "路徑檢查" and rc != 124 and not too_many_conflicts:
            today = datetime.datetime.now().strftime("%Y%m%d")
            backup_needed = bool(archive and state.get("備份日") != today)
            if backup_needed:
                state["備份日"] = today
            candidate = temp / "新倉庫.zip"
            # 打包大倉庫也要時間：剩不到 100 秒就不打包，免得撐到 900 秒被砍
            in_time = time.monotonic() - STARTED <= 800
            if in_time:
                fits, _ = archive_for_isolation(root, memo, state, candidate, program, setting, lines.append,
                                                reuse=reuse)
            if not in_time or time.monotonic() - STARTED > 850:
                lines.append("執行逾時，倉庫不動；請在本機執行。")
                rc = 124; emit = []
                request = timeout_request(root_rel, archive, opts.action, command if opts.action == "執行" else None, args)
            elif not fits:
                too_big = True
                lines.append("倉庫太大（超過隔離區上限）：這次帶入的檔案和執行結果都沒有存進倉庫，倉庫維持原樣。"
                             "請用下面的本機請求在本機重做這一步，之後改用本機模式（設定頁改執行方式，再送 收回本機）。")
                rc = 1; emit = []
                request = timeout_request(root_rel, archive, opts.action, command if opts.action == "執行" else None, args)
            else:
                iso.mkdir(parents=True, exist_ok=True)
                if backup_needed:
                    backup = backup_name(iso / "備份")
                    if not backup.exists():
                        atomic_archive_copy(archive, backup, validate=False)
                for name, conflict_name, conflict_file in conflicts:
                    dest = iso / "衝突" / safe(conflict_name)
                    transfer._reject_links(dest)
                    dest.parent.mkdir(parents=True, exist_ok=True)
                    shutil.copy2(conflict_file, dest)
                    lines.append("衝突：%s 保留本機版本，倉庫版另存在 %s（倉庫裡也留一份）" % (name, dest.relative_to(cwd).as_posix()))
                # 先寫暫存檔再整個換上：寫到一半被砍時，帶回的不會是壞倉庫
                atomic_archive_copy(candidate, iso / "倉庫.zip", validate=False)
                for name in emit:
                    dest = output_root / safe(name)
                    dest.parent.mkdir(parents=True, exist_ok=True); shutil.copyfile(after_files[name], dest)
        if rc == 124 or too_many_conflicts or too_big:
            pending = set(original_state.get("排隊", []))
            overwrite = set(original_state.get("待覆寫", []))
            deleted = []
        fixed = ["<skill資料夾>/隔離區/reg-report程式.zip", "<skill資料夾>/設定.html"]
        if (iso / "倉庫.zip").is_file():
            fixed.append("<AI工作區根目錄>/" + (Path(root_rel) / "_隔離區/倉庫.zip").as_posix())
        fixed.append("<AI工作區根目錄>/" + (Path(root_rel) / "_隔離區/下一步.txt").as_posix())
        tail_index = len(lines)
        lines += ["[結束碼] %d" % rc, "下一次 input_files 照抄清單："]
        list_index = len(lines)
        lines.extend(fixed)
        lines.append("還在排隊的取回數量：%d" % (len(pending) + len(overwrite)))
        lines.append("要覆寫的公開檔：" + ("、".join(sorted(overwrite)) or "無"))
        if overwrite:
            lines.append("本機沒有這個檔就在取回加 --補寫 <路徑>（很多個時改加 --補寫全部），不要把它列進 input_files。")
        lines.append("可刪除的本機殘留檔：" + ("、".join(deleted) or "無"))
        lines.append(IMPORT_TITLE)
        lines.extend(import_lines)
        if request:
            lines += request_name_lines(request)
            # v1.50.2：逾時時倉庫不動、只帶回 _隔離區，捷徑也不自動寫到工作區根目錄（照舊請 AI 送 建捷徑）
            lines += (launcher_lines(root_rel) if rc == 124
                      else auto_launcher_lines(output_root, root_rel))
        if pending or overwrite:
            lines.append("若仍有排隊，請執行取回；也可先執行下一步，帶入清單上的待覆寫檔。")
        lines.append(LOCAL_COMMAND_HINT)
        fixed_size = program.stat().st_size + setting.stat().st_size
        if (iso / "倉庫.zip").is_file():
            fixed_size += (iso / "倉庫.zip").stat().st_size
        current = workspace.current_output(str(root))
        current_name = Path(current).name if current else None
        proactive = {n for n in visible if n in after_files and n.split("/", 1)[0] == current_name
                     and ((len(n.split("/")) == 3 and n.split("/")[1] == "1_結果彙整" and n.endswith(".xlsx"))
                          or n.split("/", 1)[1] in ("2_Log檔案/人工待辦.txt", "2_Log檔案/AI審查/LLM報告審查.md"))}
        sizes = {n: (incoming.get(n) or after_files.get(n)) for n in overwrite | proactive}
        # 上次公開大小與倉庫目前大小可能不同；選擇較大的估算。
        for n in overwrite | proactive:
            if n in visible_sizes and sizes.get(n) is not None:
                sizes[n] = max(visible_sizes[n], sizes[n].stat().st_size)
        # 單檔連空批次也放不下時，改由本機取回，避免無限重試。
        too_large = set()
        while True:
            suffix = ["待覆寫檔留待後續批次：%d" % len(overwrite)]
            if too_large:
                suffix += ["檔案太大，放不進隔離區：" + n + "；不要在隔離區反覆取回，請改用本機請求取回。" for n in sorted(too_large)]
                suffix += request_name_lines({"倉庫": "<AI工作區根目錄>/" + root_rel + "/_隔離區/倉庫.zip", "操作": "取回"})
            available = 52428800 - fixed_size - len(("\n".join(lines + suffix) + "\n").encode('utf-8'))
            found = set()
            for n, path in sizes.items():
                if n not in overwrite:
                    continue
                if path is not None and (isinstance(path, int) or path.is_file()):
                    if (path if isinstance(path, int) else path.stat().st_size) > available:
                        found.add(n)
            if found <= too_large:
                break
            too_large.update(found)
        if too_large:
            lines += suffix[1:]
        # 清單與剩餘數本身也在下一步.txt 中；反覆計算到大小穩定。
        selected = []
        for _ in range(12):
            additions = ["<AI工作區根目錄>/" + (Path(root_rel) / n).as_posix() for n in selected]
            candidate_lines = lines[:list_index + len(fixed)] + additions + lines[list_index + len(fixed):]
            candidate_lines.append("待覆寫檔留待後續批次：%d" % (len(overwrite - set(selected))))
            status_size = len(("\n".join(candidate_lines) + "\n").encode("utf-8"))
            new = select_overwrites(overwrite, sizes, fixed_size, status_size, proactive=proactive)
            if new == selected:
                break
            selected = new
        lines[list_index + len(fixed):list_index + len(fixed)] = ["<AI工作區根目錄>/" + (Path(root_rel) / n).as_posix() for n in selected]
        lines.append("待覆寫檔留待後續批次：%d" % (len(overwrite - set(selected))))
        iso.mkdir(parents=True, exist_ok=True)
        imports_same = same_imports(status, import_lines)
        status.write_text("\n".join(lines) + "\n", encoding="utf-8")
        screen = quiet_tail(lines, tail_index, import_lines, imports_same)
        print("\n".join(screen + (_SETTING_PREVIEW + ["[結束碼] %d" % rc] if _SETTING_PREVIEW else [])))
        return rc


if __name__ == "__main__":
    try:
        sys.exit(main())
    except (OSError, ValueError, zipfile.BadZipFile) as exc:
        print("[中止] %s" % exc)
        sys.exit(1)
