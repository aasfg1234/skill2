# -*- coding: utf-8 -*-
"""
人工待辦清單：每跑完一個批次指令，列出這一輪走到哪、接下來是誰的事。

人不用記得流程走到哪：打開 目前產出/2_Log檔案/人工待辦.txt（畫面最後也印一份）就知道；
程式能接著做的站一律寫「跑 繼續」（next_step 用同一套判斷決定 繼續 要跑哪一個指令）。
各本走到哪一站用檔案狀態判斷，不另外記狀態，一共三站：
    開始之後現行版或修訂版被換過、改過   → 重新比對（使用者說「重新比對」，底下跑 繼續）
    語意比對、AI 審查還沒做完            → AI 審查（AI 自動完成，不用人填表）
    AI 審查做完、檢視報告產出            → 報告完成（這一輪的最後一站）
"""

import csv
import io
import json
import os
import re
import sys
import datetime
import hashlib

HERE = os.path.dirname(os.path.abspath(__file__))
REGDIFF = os.path.join(HERE, "regdiff")
for _path in (HERE, REGDIFF):
    if _path not in sys.path:
        sys.path.insert(0, _path)

from _common import book_dir, from_record, locate, place

FILE = "人工待辦.txt"
# 批次指令畫面最後印的這一段，是那個指令唯一的「下一步」（各指令自己不再另外印一組，見第四批 26）
SCREEN_HEADER = "下一步（人工待辦，完整清單在 目前產出/2_Log檔案/人工待辦.txt）："
SCREEN_DONE_HEADER = "這一輪的結果（完整清單在 目前產出/2_Log檔案/人工待辦.txt）："
# 「報告完成」：AI 審查做完、檢視報告產出，這一輪的最後一站（不填決定表、不套用、不驗收）
STAGES = ("重新比對", "AI審查", "報告完成")
AI_REVIEW_SKIP = "AI審查略過.txt"        # batch-review-pack --略過 寫在 產出/2_Log檔案/
SEMANTIC_SKIP = "略過.txt"                # batch-semantic --略過 寫在 產出/2_Log檔案/語意候選/


# v1.55.x 中斷復原用的標記：動手前寫、做完才清，所以沒有標記＝沒有中斷（舊工作區也是這樣，照舊走）。
# 只看「這個檔在不在」會假完成：審查打包寫到一半，AI 表在；匯入寫到一半，報告還是舊的那一份。
ROUND_MARK = ".本輪進行中.json"           # 工作區根目錄：開新一輪之前寫，比對／體檢整輪跑完才清
PACK_MARK = "審查打包進行中.json"          # 產出/2_Log檔案/：審查打包開始前寫，全部寫完才清
REPORT_MARK = "報告待更新.json"            # 產出/2_Log檔案/：審查匯入開始前寫，新報告寫成功才清
REPORT_IMPORTING = "匯入中"                # REPORT_MARK 的狀態：匯入還沒做完，要重新匯入
REPORT_WAITING = "待出報告"                # REPORT_MARK 的狀態：匯入做完了，只差出報告
REPORT_REBUILD = "重出報告"                # next_step 的「指令」：不是子命令，繼續 自己做（不用重新驗表）
ROUND_DONE = "本輪跑完.json"               # 產出/2_Log檔案/：整輪跑完才寫。批次摘要寫完之後還有語意交換包，不能拿它當跑完


def _read_mark(path):
    """標記的內容（dict）；沒有標記回 None。讀壞了還是算有標記：寧可多重做一步。"""
    try:
        with io.open(path, encoding="utf-8-sig") as f:
            data = json.load(f)
    except FileNotFoundError:
        return None
    except OSError:
        return None
    except ValueError:
        return {}
    return data if isinstance(data, dict) else {}


def _write_mark(path, value):
    from _common import write_generated
    write_generated(path, value)


def _drop_mark(path):
    """清標記。防毒短暫占用時等一下（跟換檔同一套重試）；真的刪不掉就丟例外，呼叫端決定怎麼講。"""
    from file_replace import remove_file
    try:
        remove_file(path)
    except FileNotFoundError:
        pass


def _system_mark(root, name):
    from _common import SYSTEM_DIR
    return os.path.join(root, SYSTEM_DIR, name)


def mark_round(workspace, kind, previous, opened=""):
    """要開新一輪了（kind：比對、體檢）。previous＝這一輪沒跑完時要退回哪一輪。
    開新資料夾之前先寫一次（那時還不知道名字），開好再補寫 opened＝新一輪：之後只退這一輪，別輪不碰。"""
    from _common import tw_now
    value = {"流程": kind, "前一輪": os.path.basename(previous or ""),
             "開始": tw_now().isoformat(timespec="seconds")}
    if opened:
        value["本輪"] = os.path.basename(opened)
    _write_mark(os.path.join(workspace, ROUND_MARK), value)


def unfinished_round(workspace):
    """上一次開新一輪沒跑完（被殺、斷電、出錯）：回傳 mark_round 寫的內容；沒有回 None。
    標記刪不掉留著、但那一輪其實跑完了（finish_round），不算沒跑完。"""
    import workspace as wsm
    mark = _read_mark(os.path.join(workspace, ROUND_MARK))
    if mark and mark.get("本輪"):
        current = wsm.current_output(workspace)
        if (current and os.path.basename(current) == mark["本輪"]
                and os.path.isfile(_system_mark(current, ROUND_DONE))):
            return None
    return mark


def clear_round(workspace):
    _drop_mark(os.path.join(workspace, ROUND_MARK))


def finish_round(workspace, outdir):
    """這一輪整輪跑完：先記「跑完了」再清標記。標記刪不掉時，下一個指令看得出這一輪是做完的，不會退回。"""
    from _common import tw_now
    _write_mark(_system_mark(outdir, ROUND_DONE), {"完成": tw_now().isoformat(timespec="seconds")})
    clear_round(workspace)


def _forget_round(workspace):
    """過期的標記清掉；刪不掉不能擋住這個指令，只回一句話。"""
    try:
        clear_round(workspace)
    except OSError as exc:
        return "[提醒] %s 刪不掉（%s）：標記已經過期，不影響目前作業，關掉占用它的程式後下一個指令會再清" % (ROUND_MARK, exc)
    return ""


def settle_round(workspace):
    """標記跟目前作業對一次（要先拿到工作區的鎖，上一個指令才一定不在跑了）。回傳要印的一句話，沒事回 ""。
    目前作業還是標記裡那一輪：沒跑完，退回上一輪，標記留著給 繼續 判斷要重做哪一種。
    已經是上一輪：退過了。都不是：指標是別的動作換過的（別台做完搬回來、收回本機），標記過期，清掉、不動指標。
    標記讀壞了看不出來，不動指標。"""
    import batch as bt
    import workspace as ws
    mark = _read_mark(os.path.join(workspace, ROUND_MARK))
    if mark is None or ws.uses_legacy_layout(workspace):
        return ""
    current = ws.current_output(workspace)
    if not mark:
        return ("[提醒] %s 壞了，看不出上一次開新一輪有沒有跑完：目前作業沒有動。"
                "跑 繼續 會重新%s；確定上一輪沒問題就刪掉這個檔"
                % (ROUND_MARK, "體檢" if current and bt.is_health_round(current) else "比對"))
    name = os.path.basename(current or "")
    before, opened = mark.get("前一輪") or "", mark.get("本輪") or ""
    if not current or name == before:
        return ""
    done = os.path.isfile(_system_mark(current, ROUND_DONE))
    # 沒記到新一輪的名字＝開新資料夾的當下被殺：那一輪什麼都還沒做，不會有批次摘要（別台做完的才有）
    if (done or name != opened) if opened else (done or os.path.isfile(_system_mark(current, "批次摘要.txt"))):
        return _forget_round(workspace)
    if not ws.abandon_output(workspace, current, os.path.join(workspace, before) if before else ""):
        return ""
    return ("上一次的%s沒跑完（被中斷）：%s 不算數，目前作業退回%s；跑 繼續 會重做，AI 判過的答案和承辦意見會接回來"
            % (mark.get("流程") or "比對", name, "上一輪（%s）" % before if before else "「還沒有作業」"))


def mark_pack(root):
    _write_mark(_system_mark(root, PACK_MARK), {"狀態": "打包中"})


def pack_unfinished(root):
    return _read_mark(_system_mark(root, PACK_MARK)) is not None


def clear_pack(root):
    _drop_mark(_system_mark(root, PACK_MARK))


def mark_report(root, state):
    _write_mark(_system_mark(root, REPORT_MARK), {"狀態": state})


def report_state(root):
    """REPORT_IMPORTING、REPORT_WAITING，或 ""（沒有待辦）。"""
    mark = _read_mark(_system_mark(root, REPORT_MARK))
    if mark is None:
        return ""
    return REPORT_WAITING if mark.get("狀態") == REPORT_WAITING else REPORT_IMPORTING


def clear_report(root):
    _drop_mark(_system_mark(root, REPORT_MARK))


def report_problem(root):
    """報告要不要重出：回傳一句原因，不用回 ""。比對、體檢 AI 審查都做完之後才問這個。"""
    import precedents as pc
    if report_state(root) == REPORT_WAITING:
        return "上一次匯入之後報告沒有更新"
    found = pc.report_files(root)
    if not found:
        return ""                          # 沒有標記又沒有報告：舊工作區、略過 AI 審查都可能這樣，照舊不判斷
    # 只看當時真的讀不到的那幾份（可能在前一輪）：還讀不到就等人處理，重出也沒用，只留提醒
    if pc.opinions_recoverable(root):
        return "之前讀不到的舊報告現在讀得到了"
    if not pc.report_readable(found[0]) and not pc.known_unreadable(root, found[0]):
        return "最新的報告打不開（%s）" % os.path.basename(found[0])
    if pc.copies_to_merge(root):
        return "有另存的副本，正式報告現在寫得進去了"
    return ""


def report_busy(root, again="繼續"):
    """這一輪有另存的副本，但正式報告或副本還開著：併不回去，也不能說做完（新答案可能只在副本）。回傳一句話，沒事回 ""。
    again：要叫人跑哪個指令（法規追蹤是 法規繼續）。"""
    import precedents as pc
    busy = pc.reports_open(root)
    if not busy:
        return ""
    return ("%s 還開著（或被設成唯讀），這一輪的結果分在正式報告和另存的副本裡，還沒併起來：先在 Excel 存檔、關掉，唯讀的話取消唯讀，再跑 %s（會把兩邊的承辦意見和新的 AI 答案併成一份）"
            % ("、".join(busy), again))


def _mtime(path):
    return os.path.getmtime(path) if path and os.path.isfile(path) else 0


def _warnings(folder):
    count = 0
    for name in ("提醒.txt",):
        path = locate(folder, name)[0]
        if os.path.isfile(path):
            with io.open(path, encoding="utf-8-sig") as f:
                count += sum(1 for line in f if line.startswith("警告｜"))
    return count


def _sources_from_workspace(folder):
    """沒有 輸入來源.json（這個功能之前跑的「開始」）：從工作區的 匯入/規章清單.csv 找這一本的檔。
    folder 是 <工作區>/產出/2_Log檔案/<規章名>。找不到就回 None（不判斷）。"""
    import batch as bt
    name = os.path.basename(os.path.normpath(folder))
    workspace = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(folder))))
    manifest = os.path.join(workspace, "匯入", "規章清單.csv")
    if not os.path.isfile(manifest):
        return None
    try:
        docs = bt.read_manifest(manifest)
    except bt.BatchError:
        return None
    for doc in docs:
        if doc["規章名"] == name:
            return {"舊版": doc["舊版"], "草稿": doc["草稿"]}
    return None


def semantic_pending(root):
    """這台電腦算不了語意、要到別台算，還沒帶回來併入的本（語意候選資料夾裡有輸入、沒有結果）。
    設定.html 關了「使用 BGE-M3」就一本都不算（開始之後才關的，留下來的語意輸入也不再提醒）。"""
    from _common import SYSTEM_DIR, config_section
    if config_section("設定").get("使用BGE-M3", True) is False:
        return []
    folder = os.path.join(root, SYSTEM_DIR, "語意候選")
    if not os.path.isdir(folder) or os.path.isfile(os.path.join(folder, SEMANTIC_SKIP)):
        return []
    suffix = "_語意輸入.json"
    return sorted(n[:-len(suffix)] for n in os.listdir(folder)
                  if n.endswith(suffix) and not os.path.isfile(os.path.join(folder, n[:-len(suffix)] + ".csv")))



def semantic_hash(path):
    with open(path, "rb") as f:
        return hashlib.sha256(f.read()).hexdigest()


def semantic_records(root):
    from _common import SYSTEM_DIR
    path = os.path.join(root, SYSTEM_DIR, "語意候選", "併入紀錄.json")
    try:
        with io.open(path, encoding="utf-8") as f:
            data = json.load(f)
        return data if isinstance(data, dict) else {}
    except (OSError, ValueError):
        return {}


def semantic_unmerged(root):
    from _common import SYSTEM_DIR, config_section
    if config_section("設定").get("使用BGE-M3", True) is False:
        return []
    folder = os.path.join(root, SYSTEM_DIR, "語意候選")
    if not os.path.isdir(folder) or os.path.isfile(os.path.join(folder, SEMANTIC_SKIP)):
        return []
    records = semantic_records(root)
    names = (n[:-4] for n in os.listdir(folder) if n.endswith(".csv"))
    return sorted(n for n in names if os.path.isfile(os.path.join(folder, n + ".csv"))
                  and records.get(n) != semantic_hash(os.path.join(folder, n + ".csv")))

def _ai_review_state(root, folder, table, rows):
    """"done"：這一輪的列都審過了（或這一輪說好不做）；"packed"：審查包已經產生、等 AI 填表匯入；
    "todo"：還沒打包，或上一次匯入有 AI 答案過期（判的不是這一輪的字），要重新打包讓 AI 重判；
    "mismatch"：上一次匯入發現決定表的候選全文被手改過，重新打包也沒用，要人還原決定表或重新比對。
    審過沒有看 AI審查紀錄.json 記的列與異動跟現在一不一樣（補了語意就要再審新列）；
    有過期、原文不符時匯入不寫這份紀錄（review_import.import_review）。"""
    import decision_table as dt
    import review_import as ri
    from _common import SYSTEM_DIR
    if os.path.isfile(os.path.join(root, SYSTEM_DIR, AI_REVIEW_SKIP)):
        return "done"
    changes = []
    changes_path = locate(folder, "異動清單.json")[0]
    if os.path.isfile(changes_path):
        try:
            with io.open(changes_path, encoding="utf-8") as f:
                changes = json.load(f)
        except (OSError, ValueError) as exc:
            # v1.51.0：檔壞了（寫到一半斷電、手改壞）以前整個 traceback；講清楚是哪一本、怎麼處理
            from _common import InputError
            raise InputError("%s 的 異動清單.json 壞了（%s），重跑 開始"
                             % (os.path.basename(os.path.normpath(folder)), exc))
    record = locate(folder, ri.AI_REVIEW_RECORD)[0]
    if os.path.isfile(record):
        try:
            with io.open(record, encoding="utf-8") as f:
                if json.load(f) == ri.ai_review_signature(rows, changes):
                    return "done"
        except (OSError, ValueError):
            pass
    ai_csv = locate(folder, "AI候選判斷.csv")[0]
    # 上一次匯入在最後一次打包之後（打包會重寫 AI 表）：照它講的結果走
    status_path = locate(folder, ri.AI_IMPORT_STATUS)[0]
    status = ri.read_import_status(folder)
    if status and _import_status_current(status, folder, status_path, ai_csv):
        if status.get("原文不符"):
            return "mismatch"
        if status.get("需重新打包") or status.get("AI過期"):
            return "todo"
    side = dt.sidecar_path_for(table)
    if os.path.isfile(ai_csv) and os.path.isfile(side) and _mtime(ai_csv) >= _mtime(side):
        return "packed"
    return "todo"


def _import_status_current(status, folder, status_path, ai_csv):
    """上一次匯入的狀態還算不算數（審查打包會重寫 AI 表，表變了狀態就不算數）。
    先比匯入時記的 AI 表指紋（review_import.ai_table_prints）：內容不一樣一定是重新打包過了，
    不管檔案時間怎麼說——FAT／exFAT 隨身碟時間粒度 2 秒，匯入、打包落在同一秒時以前會判錯（審查 A7）。
    內容一樣再看時間（重新打包也可能寫出一模一樣的表）：表比狀態檔新就不算數。"""
    prints = status.get("AI表指紋")
    if isinstance(prints, dict) and prints:
        import decision_table as dt
        for filename, want in prints.items():
            path = locate(folder, filename)[0]
            if not os.path.isfile(path) or dt.file_sha256(path) != want:
                return False
    return not os.path.isfile(ai_csv) or _mtime(status_path) >= _mtime(ai_csv)


def _inputs_moved(folder, table):
    """這一本的現行規章或修訂版，在「開始」之後被改過、換過或拿走了嗎？回傳說明，沒有回 ""。
    決定表的指紋檔記著「開始」當時兩份檔的 SHA-256，輸入來源.json 記著檔在哪裡。"""
    import decision_table as dt
    path = locate(folder, "輸入來源.json")[0]
    try:
        if os.path.isfile(path):
            with io.open(path, encoding="utf-8") as f:
                sources = json.load(f)
            # v1.15.0 起存相對這個檔的位置；舊的完整路徑照用
            base = os.path.dirname(os.path.abspath(path))
            sources = dict((k, from_record(base, v) if isinstance(v, str) else v) for k, v in sources.items())
        else:
            sources = _sources_from_workspace(folder)
        side = dt.read_sidecar(dt.sidecar_path_for(table))
    except (OSError, ValueError, dt.DecisionTableError):
        return ""
    if not sources:
        return ""
    for key, label in (("草稿", "修訂版"), ("舊版", "現行規章")):
        file_path, want = sources.get(key), (side.get(key) or {}).get("SHA256")
        if not file_path or not want:
            continue
        if not os.path.isfile(file_path):
            return "%s不見了（%s）" % (label, os.path.basename(file_path))
        if dt.file_sha256(file_path) != want:
            return "%s在「開始」之後改過了（%s）" % (label, os.path.basename(file_path))
    return ""


def book_status(root, name):
    """一本走到哪一站。沒有決定表（還沒比對）回 None。
    必要檔缺了（決定表、異動清單、輸入指紋任一個）算「重新比對」：多半是「開始」跑到一半被中斷，
    或檔被刪掉；以前回 None 被濾掉，其他本在 AI 審查站，繼續就派去審查打包、打包又說不完整請跑繼續，卡死。"""
    import batch as bt
    import decision_table as dt
    import review_import as ri
    folder = book_dir(root, name)
    missing = bt.missing_book_files(folder)
    if missing:
        return {"規章": name, "警告": 0, "階段": "重新比對",
                "問題": "產出不完整（缺 %s），多半是「開始」跑到一半被中斷或檔被刪掉" % "、".join(missing)}
    table = locate(folder, "連帶決定表.csv")[0]
    if not os.path.isfile(table):
        return None
    info = {"規章": name, "警告": _warnings(folder), "問題": ""}
    moved = _inputs_moved(folder, table)
    if moved:
        info.update(階段="重新比對", 問題=moved)
        return info
    try:
        rows = dt.read_table(table)
    except dt.DecisionTableError as exc:
        info.update(階段="重新比對", 問題="連帶決定表讀不出來（%s）" % exc)
        return info
    info["AI審查"] = _ai_review_state(root, folder, table, rows)
    if info["AI審查"] == "mismatch":
        bad = (ri.read_import_status(folder) or {}).get("原文不符") or []
        info["問題"] = ("決定表有 %d 列候選全文跟「開始」時不一樣（列ID %s），AI 判斷沒有匯入；"
                      "請說「重新比對」（會開新的一輪，沒變的答案沿用），不要自己改決定表" % (len(bad), "、".join(bad)))
    # AI 審查做完，檢視報告就是完整版：到此結束
    info["階段"] = "AI審查" if info["AI審查"] != "done" else "報告完成"
    return info


def _plain_cmd(name, *parts):
    return " ".join(["python scripts/run_all.py", name] + [p for p in parts if p])


def unaffected_moved(root):
    """沒進流程的本（只讀過全文當別本的被查對象）：它的現行規章在「開始」之後被換過、改過或拿走了嗎。
    回傳 [(規章名, 說明)]。這些本沒有決定表、沒有指紋檔，靠 未受影響規章.json 記的 SHA-256 比；
    這個功能之前跑的「開始」沒記指紋，那幾本就不判斷。"""
    import batch as bt
    import decision_table as dt
    out = []
    for name, doc in sorted(bt.unaffected_docs(root).items()):
        path, want = doc.get("舊版"), doc.get("舊版SHA256")
        if not path or not want:
            continue
        if not os.path.isfile(path):
            out.append((name, "現行規章不見了（%s）" % os.path.basename(path)))
        elif dt.file_sha256(path) != want:
            out.append((name, "現行規章在「開始」之後改過了（%s）" % os.path.basename(path)))
    # 讀不出來沒比的新訂：檔換好了就要重新比對；檔拿掉了清單會過期，由過期檢查接手
    for name, item in sorted(bt.broken_new_rules(root).items()):
        path = item.get("檔")
        if path and os.path.isfile(path) and dt.file_sha256(path) != item.get("SHA256"):
            out.append((name, "新訂規章的檔換過了（%s），這一輪沒比到" % os.path.basename(path)))
    return out


def statuses_of(root):
    import batch as bt
    statuses = [s for s in (book_status(root, n) for n in bt.book_names(root)) if s]
    # 沒進流程的本換了現行規章也要重新比對：別本的跨本連帶、引用都是拿它的舊文找的
    statuses += [{"規章": name, "警告": 0, "階段": "重新比對", "問題": reason}
                 for name, reason in unaffected_moved(root)]
    return statuses


def workspace_of(root):
    """從舊產出或日期序號作業目錄回推工作區根目錄。"""
    parent = os.path.dirname(os.path.abspath(root))
    try:
        import workspace as wsm
        if os.path.isdir(os.path.join(parent, "匯入")) and wsm.is_output_dir(parent, root):
            return parent
    except Exception:
        pass
    return None


def _semantic_back(root):
    """語意交換包帶回來了嗎：(算好的規章 list, 錯誤訊息)。"""
    import semantic_exchange as se
    from _common import SYSTEM_DIR
    try:
        found = se.returned(os.path.join(root, SYSTEM_DIR, "語意候選"), workspace_of(root))
    except se.ExchangeError as exc:
        return [], str(exc)
    return (found[1] if found else []), ""


IDLE = ("匯入/2_修訂文件 裡沒有修訂版：這一輪沒有要比對的。"
        "要比對時把現行版放進 匯入/1_現行文件、修訂版放進 匯入/2_修訂文件，再跑 繼續；"
        "只想檢查現有文件（不比對）就說「體檢」")
# 「這一輪做完了」那幾句共有的字：呼叫端用它認出「報告完成」
ROUND_DONE_MARK = "這一輪到此結束"
REPORT_DONE = ("比對報告完成，這一輪到此結束：打開 產出/1_結果彙整/比對報告.xlsx，先看「條文比對報告」。"
               "同一處修改收成一列，每一段的判定寫在「同一處修改」欄，完整內容在「各段明細」。需要核對全文時，點段次到「段次總表」。")
# 體檢那一輪的最後一站（next_step 回的仍是 REPORT_DONE，呼叫端用它判「做完了」；只有印給人看的字不同）
HEALTH_DONE = ("體檢報告完成，這一輪到此結束：打開 產出/1_結果彙整/體檢報告.xlsx，"
               "先看「條文比對報告」（重複／矛盾、錯漏字）「條文檢查報告」「引用檢查報告」。需要核對全文時，點段次到「段次總表」。")
def done_text(root, health=False):
    return _done_text(root, health) + broken_new_rule_note(root) + _semantic_skip_note(root)


def broken_new_rule_note(root):
    """新訂讀不出來、這一輪沒比的本：講「做完了」的地方都要帶上，不能讓人以為整批都比了。"""
    import batch as bt
    broken = bt.broken_new_rules(root)
    if not broken:
        return ""
    return "（但少比了 %d 本：%s，報告裡沒有這幾本；檔修好後說「重新比對」）" % (len(broken), "、".join(sorted(broken)))


def _semantic_skip_note(root):
    """選了略過語意的那一輪，做完時要講：用字不同的段落可能沒列出，不能當成語意也查過。"""
    from _common import SYSTEM_DIR
    if os.path.isfile(os.path.join(root, SYSTEM_DIR, "語意候選", SEMANTIC_SKIP)):
        return "\n（這一輪略過語意比對：意思相近但用字不同的段落可能沒有列出。）"
    return ""


def _done_text(root, health=False):
    """「報告完成」那一句，寫實際寫出的那一份報告（Excel 開著時另存的 _HHMMSS）和產出資料夾名稱（v1.24.0）。"""
    import precedents as pc
    want = "體檢報告" if health else "比對報告"
    # v1.26.0：報告叫 比對報告_20261026003.xlsx；改名前的舊資料夾是 檢視報告.xlsx：寫最新的那一份
    found = pc.report_files(root)
    name = os.path.basename(found[0]) if found else want + ".xlsx"
    text = HEALTH_DONE if health else REPORT_DONE
    return text.replace("產出/1_結果彙整/%s.xlsx" % want, "%s/1_結果彙整/%s" % (os.path.basename(os.path.normpath(root)), name))


CONSISTENCY_TODO = ("AI 一致性審查（由 AI 自動完成，不用人填表）：AI 照 產出/2_Log檔案/AI審查/先讀我.md 填好 "
                    "AI一致性.csv（有家族的還有 AI一致性家族.csv；全文在同資料夾的 LLM一致性審查_NN.md，一份讀完就填）後跑 %s")
TYPO_TODO = ("AI 錯漏字檢查（由 AI 自動完成，不用人填表）：AI 照 產出/2_Log檔案/AI審查/先讀我.md 的「錯漏字檢查」"
             "逐段讀 LLM錯漏字審查_T*.md，填好 AI錯漏字.csv 後跑 %s")
LAW_TODO = ("AI 法規更新檢視（由 AI 自動完成，不用人填表）：AI 照 產出/2_Log檔案/AI審查/先讀我.md 的「法規更新檢視」"
            "先填 AI法規適用.csv（讀 LLM法規適用一覽_*.md，沒有一覽表就讀 LLM法規適用審查_*.md），跑一次繼續，程式再把適用的法規打包成 LLM法規審查包_*.md，"
            "填好 AI法規影響.csv 後跑 %s")


TABLES_EDITED = "AI 表在報告出來之後改過：重新匯入，再重出報告"


def tables_edited_after_report(root):
    """v1.25.0：產出/2_Log檔案/AI審查/ 的四張 AI 表，有沒有一張比這一輪最新的報告（和最近一次匯入）還新。
    以前只有法規追蹤會發現；比對、體檢在報告審查那一站改了表，繼續 只說「做完了」，改的東西進不了報告。
    也比各本的 AI審查匯入狀態.json：同一次 繼續 裡剛匯入完、報告整串跑完才重建，不能再判一次「改過」。"""
    import glob
    import ai_tables as at
    import precedents as pc
    from _common import SYSTEM_DIR
    reports = pc.report_files(root)
    if not reports:
        return False
    stamps = reports + glob.glob(os.path.join(glob.escape(os.path.join(root, SYSTEM_DIR)), "*", SYSTEM_DIR,
                                              "AI審查匯入狀態.json"))
    newest = max(os.path.getmtime(p) for p in stamps)
    for filename, _id, _columns in at.SPECS:
        path = os.path.join(at.folder(root), filename)
        if os.path.isfile(path) and os.path.getmtime(path) > newest + 1:
            return True
    return False


def _health(root):
    import batch as bt
    return bt.is_health_round(root)


def _consistency_pending(root):
    """體檢的整批表那一站還沒收：重複／矛盾（AI一致性.csv）或法規更新檢視（v1.6.0 的兩張表）還沒匯入，
    或匯入之後 AI 又改了表。"""
    if not _health(root):
        return False
    import health_check as hc
    import health_law
    import health_typo
    return hc.pending(root) or health_law.pending(root) or health_typo.pending(root)


def _batch_table_todo(root, go):
    """體檢整批表那一站要印的幾行（重複／矛盾、法規更新檢視，哪個還沒收印哪個）。"""
    import health_check as hc
    import health_law
    lines = []
    if hc.pending(root):
        lines.append(CONSISTENCY_TODO % go)
    import health_typo
    if health_typo.pending(root):
        lines.append(TYPO_TODO % go)
    if health_law.pending(root):
        lines.append(LAW_TODO % go)
    return lines
# AI 審查是 AI 的事（SKILL.md：不可要求使用者填 AI 審查表）：人工待辦講清楚不用人動手
AI_REVIEW_TODO = ("AI 審查（由 AI 自動完成，不用人填表）：跑 %s 產審查包；"
                  "AI 照 產出/2_Log檔案/AI審查/先讀我.md 把列出的 AI 表填好，再跑 %s")
AI_REVIEW_PACKED = ("AI 審查（由 AI 自動完成，不用人填表）：審查包已經產生（%s），"
                    "AI 照 產出/2_Log檔案/AI審查/先讀我.md 把列出的 AI 表填好，再跑 %s")


def build(root, ws="", cmd=None, statuses=None):
    """回傳 (清單全文, 畫面要印的幾行)。ws：印出來的指令要不要帶 --workspace。
    cmd：印指令的那一支（run_all._cmd，由呼叫端傳進來——這裡 import run_all 會拿到
    regdiff 底下同名的那一支）。"""
    from _common import tw_now, tw_today
    _cmd = cmd or _plain_cmd
    if statuses is None:
        statuses = statuses_of(root)
    workspace = workspace_of(root)
    health = _health(root)
    if workspace and not health:
        import workspace as wsm
        if not wsm.list_role_inputs(workspace, wsm.ROLE_DRAFT):
            lines = ["人工待辦（%s）" % tw_now().strftime("%Y-%m-%d %H:%M"), "", IDLE, "",
                     "所有產出都是輔助，最終仍需人工複核後才能送出。"]
            return "\n".join(lines) + "\n", ["", SCREEN_HEADER, "  1. " + IDLE]
    if not statuses:
        return "", []
    go = _cmd("繼續", ws)
    now = []
    interrupted = unfinished_round(workspace) if workspace else None
    if interrupted is not None:
        now.append("上一次的%s沒跑完（被中斷或出錯），目前看到的是上一輪：跑 %s 會重做，AI 判過的答案和承辦意見會接回來"
                   % (interrupted.get("流程") or "比對", go))
    moved = [s for s in statuses if s["階段"] == "重新比對"]
    for s in moved:
        now.append("%s：%s：要重新比對（跑 %s：開新一輪重新比對，AI 判過的答案會依內容帶回來）"
                   % (s["規章"], s["問題"], go))
    unmerged = [] if moved else semantic_unmerged(root)
    semantic = [] if moved else semantic_pending(root)
    if unmerged:
        now.append("語意結果已經算好（%s）：跑 %s 併入" % ("、".join(unmerged), go))
    elif semantic:
        # 語意比對要在 AI 審查之前：語意找到的新列也要 AI 判
        back, _problem = _semantic_back(root)
        if back:
            now.append("語意交換包已經算好帶回來了（%s）：跑 %s 併入" % ("、".join(back), go))
        elif os.environ.get("REG_ISOLATED") == "1":
            now.append("語意比對還沒做（%d 本）：照隔離區輸出的本機請求流程處理。" % len(semantic))
        else:
            # 只問使用者執行／不執行，不把別台電腦當預設解法（見 SKILL.md）
            now.append("語意比對還沒做（這台電腦的 BGE-M3 模型沒設定或不能用，%d 本）：請使用者選「執行」或「不執行」；"
                       "不執行就跑 %s，要執行先檢查這台電腦能不能跑（見 SKILL.md）"
                       % (len(semantic), _cmd("語意併入", ws, "--略過")))
    reviewing = [] if (moved or semantic or unmerged) else [s for s in statuses if s["階段"] == "AI審查"]
    # 原文不符的本：重新打包也沒用，要人還原決定表或重新比對（問題寫在 book_status）
    for s in reviewing:
        if s["AI審查"] == "mismatch":
            now.append("%s：%s" % (s["規章"], s["問題"]))
    waiting = [s for s in reviewing if s["AI審查"] != "mismatch"]
    if any(s["AI審查"] == "todo" for s in waiting):
        now.append(AI_REVIEW_TODO % (go, go))
    elif waiting:
        now.append(AI_REVIEW_PACKED % ("、".join(s["規章"] for s in waiting), go))
    consistency = not (moved or semantic or unmerged or reviewing) and _consistency_pending(root)
    if consistency:
        now += _batch_table_todo(root, go)
    done = not (moved or semantic or unmerged or reviewing or consistency or interrupted is not None)
    rebuild = ""
    if done:
        rebuild = ("上一次審查匯入沒跑完" if report_state(root) == REPORT_IMPORTING else report_problem(root))
        if rebuild:
            done = False
            now.append("%s：跑 %s 重出報告" % (rebuild, go))
        else:
            rebuild = report_busy(root)
            if rebuild:
                done = False
                now.append(rebuild)
    import report_review as rv
    if rebuild or interrupted is not None:
        pass
    elif done and rv.pending(root):
        # v1.18.0：表都匯入了、報告出了，最後一站 AI 報告審查
        done = False
        now.append(rv.todo_line(go, "體檢報告" if health else "比對報告"))
        if rv.read_rows(root):
            now += ["  " + line for line in rv.errors(root)[:10]]
    elif done:
        now.append(done_text(root, health))
    later = []
    import precedents as pc
    pending = pc.opinions_pending(root)
    if pending:
        later.append("舊報告 %s 讀不到，裡面的承辦意見還沒接回來（現在這份報告的空白不代表承辦沒意見）："
                     "關掉占用它的程式或修好檔案後跑 %s；救不回來就刪掉它再跑一次" % ("、".join(pending), go))
    if health:
        import health_law
        law_state = health_law.load(root)
        if law_state is not None:
            later += ["法規來源「%s」%s：%s（不等於沒有修法；體檢報告的引用檢查報告有一列）"
                      % (c.get("name"), c.get("status"), health_law._short_detail(c.get("detail") or ""))  # v1.24.1：不列幾十個附件網址
                      for c in health_law._coverage_problems(law_state)]
            if not law_state.get("events"):
                later.append("法規更新檢視這一輪沒抓到任何法規異動：不代表沒有修法")
    import unit_facts as uf
    waiting = uf.todo_line(workspace_of(root))
    if waiting:
        later.append(waiting)
    import batch as bt
    new_rules = bt.new_rule_books(root)
    if new_rules:
        later.append(("新訂 %d 本還沒有現行版，這一輪體檢沒有檢查：%s" % (len(new_rules), "、".join(new_rules))) if health else
                     (bt.new_rule_warning(new_rules) + "（報告的「使用說明」也有寫）"))
    broken = bt.broken_new_rules(root)
    if broken:
        later.append(bt.broken_new_rule_line(broken))
    warned = sum(s["警告"] for s in statuses)
    if warned:
        # v1.51.0：以前寫「警告 N 則…內容在批次摘要.txt」，承辦不知道要不要處理
        later.append("程式處理時有 %d 則警告（%s）：看報告前先看一眼有沒有影響，不一定要處理；"
                     "內容在 產出/2_Log檔案/批次摘要.txt 最後的「提醒彙整」"
                     % (warned, "、".join("%s %d" % (s["規章"], s["警告"]) for s in statuses if s["警告"])))
    lines = ["人工待辦（%s）" % tw_now().strftime("%Y-%m-%d %H:%M"), ""]

    def where(s):
        # 語意比對是整批一站、排在 AI 審查前面：還沒做時各本也寫「語意比對」，跟「現在要做」對得上
        return "語意比對" if (semantic or unmerged) and s["階段"] != "重新比對" else s["階段"]
    lines.append("各本走到哪：" + "、".join("%s（%s）" % (s["規章"], where(s)) for s in statuses))
    lines.append("")
    if now:
        lines.append(("這一輪的結果" if done else "現在要做") + "：")
        lines += ["  %d. %s" % (i, x) for i, x in enumerate(now, 1)]
        lines.append("")
    if later:
        lines.append("看報告時留意：")
        lines += ["  - " + x for x in later]
    kind = "體檢" if health else "比對"
    feedback = pc.feedback_lines(kind=kind) if done else []       # v1.21.0：報告出來了，請承辦寫回饋
    if feedback:
        lines += [""] + feedback
    lines += ["", "所有產出都是輔助，最終仍需人工複核後才能送出。"]
    screen = ["", SCREEN_DONE_HEADER if done else SCREEN_HEADER]
    screen += ["  %d. %s" % (i, x) for i, x in enumerate(now or later[:1], 1)]
    if done and later:
        # v1.24.0：報告完成時「看報告時留意」也印在畫面上（以前只寫在人工待辦.txt：來源失敗、0 條法規、警告幾則，人和 AI 都看不到）
        screen += ["", "看報告時留意："] + ["  - " + x for x in later]
    if feedback:
        screen += [""] + pc.screen_feedback(root, kind)
    if done:
        import novice_tools
        screen += [""] + novice_tools.summary_lines(root)        # v1.50.0：報告的數字直接印，AI 不用自己讀報告去數
    return "\n".join(lines) + "\n", screen


def refresh(root, ws="", cmd=None):
    """重寫 目前產出/2_Log檔案/人工待辦.txt，回傳畫面要印的幾行。"""
    statuses = statuses_of(root)
    text, screen = build(root, ws, cmd, statuses)
    if not text:
        return []
    from _common import write_generated
    write_generated(place(root, FILE), for_people(text), first_line=True, encoding="utf-8-sig")
    return screen


_COMMAND_RE = re.compile(r'python (?:-B )?scripts/run_all\.py ([^\s，。；：）]+)(?:\s+(?:"[^"]*"|<[^<>\s]*>|--[^\s，。；）]+))*')
_AI_STEP_RE = re.compile(r'^(\s*\d+\. .*?（(?:由 )?AI 自動完成，不用人(?:填表|做)）)：.*$', re.M)


def _spoken_command(match):
    """指令換成口語：工作區路徑拿掉，--略過 這種旗標留著（少了它就是另一件事）。"""
    rest = re.sub(r'"[^"]*"|<[^<>\s]*>', "", match.group(0))
    flags = [flag for flag in re.findall(r"--[^\s，。；）]+", rest) if flag not in ("--workspace", "--工作區")]
    return "「%s」" % " ".join([match.group(1)] + flags)


def for_people(text):
    """人工待辦.txt 是承辦會打開的檔：畫面照舊印指令給 AI，檔案裡把指令換成口語、AI 自己的步驟只講「不用動手」
    （v1.56.0：以前寫滿 python scripts/run_all.py，隔離區連暫存路徑都寫進去，人照抄也跑不了）。"""
    text = _AI_STEP_RE.sub(r"\1：AI 做完會告訴你。", text)
    text = _COMMAND_RE.sub(_spoken_command, text)
    text = text.replace("照隔離區輸出的本機請求流程處理。", "AI 會請你選要不要做（要做就雙擊捷徑）。")
    return text.replace("（見 SKILL.md）", "").replace("請使用者", "請")


def _manifest_key(path):
    """清單的內容（規章名、舊版、新版草稿、發布根目錄；配對方式、備註不算）：比「人改過清單沒有」用。"""
    from _common import open_csv
    try:
        with open_csv(path) as f:
            return sorted(tuple((r.get(k) or "").strip() for k in ("規章名", "舊版", "新版草稿", "發布根目錄"))
                          for r in csv.DictReader(f))
    except (OSError, UnicodeDecodeError, csv.Error, ValueError):
        return None


def order_problem(root, command):
    """這個批次指令現在跑，是不是跑錯站：回傳 (擋不擋, 一句話) 或 None。
    會出錯、會誤導的才擋（還沒打包就匯入）；只是順序不理想的講一聲照跑（語意還沒併入就打包）。"""
    statuses = statuses_of(root)
    if not statuses:
        return True, "還沒有這一輪的比對結果：先跑 繼續（或 開始）"
    moved = [s for s in statuses if s["階段"] == "重新比對"]
    if moved:
        return True, "%s：%s，這一輪的結果已經過期：先重新比對（跑 繼續）" % (moved[0]["規章"], moved[0]["問題"])
    if command == "batch-review-import" and pack_unfinished(root):
        return True, "上一次審查打包沒跑完，AI 表不完整：先跑 繼續（會重新打包），AI 填好再匯入"
    stage = STAGES[min(STAGES.index(s["階段"]) for s in statuses)]
    semantic = semantic_pending(root)
    if command == "batch-review-pack" and semantic:
        return False, "語意比對還沒併入（%d 本）：語意找到的列這次不會進審查包，併入之後要再打包一次" % len(semantic)
    if command == "batch-review-import" and stage == "AI審查" and all(
            s.get("AI審查") == "todo" for s in statuses if s["階段"] == "AI審查"):
        return True, "還沒產審查包：先跑 繼續（會產審查包），AI 填好 產出/2_Log檔案/AI審查/ 的表再匯入"
    return None


def next_step(root, workspace_root=None):
    """「繼續」下一步跑什麼（跟人工待辦同一套判斷）：{"指令": 子命令名或 None, "說明": 一句話}。
    指令是 None＝這一站要人（或 AI）動手；說明講停在哪一站，細節照人工待辦。
    batch-review-import 那一站多帶 "先看AI"：呼叫端要先確認 AI 把表填完了才匯入。"""
    import batch as bt
    # 體檢那一輪（沒有修訂版）：要重跑的站是「體檢」不是「開始」，修訂版空的也不算閒置
    health = _health(root)
    restart = "體檢" if health else "開始"
    if workspace_root:
        import workspace as wsm
        p = wsm.paths(workspace_root)
        # v1.55.x：開新一輪沒跑完：目前作業已經退回上一輪，那一輪看起來是做完的，不能照它說「做完了」
        mark = unfinished_round(workspace_root)
        if mark is not None:
            again = mark.get("流程") == "體檢" or (not mark and health)       # 標記讀壞了就看目前這一輪
            again = "體檢" if again else "開始"
            if again == "體檢" or wsm.list_role_inputs(workspace_root, wsm.ROLE_DRAFT):
                return {"指令": again, "說明": "上一次沒跑完"}
        if not wsm.list_role_inputs(workspace_root, wsm.ROLE_DRAFT) and not health:
            # 沒有發布這一站之後，「這一輪結束了」就看修訂規章是不是空的（簽核回來、修訂版拿掉了）。
            # 以前這裡會回「開始」，開始跑完還是沒有比對結果，繼續就一直重跑開始、一直歸檔
            return {"指令": None, "說明": IDLE}
        if not os.path.isfile(p["清單"]):
            if (wsm.list_role_inputs(workspace_root, wsm.ROLE_CURRENT)
                    or wsm.list_role_inputs(workspace_root, wsm.ROLE_DRAFT)):
                return {"指令": restart, "說明": "第一次跑：配對、初比對"}
            return {"指令": None, "說明": "匯入/1_現行文件、匯入/2_修訂文件 還沒有規章檔：先把檔放進去"}
        try:
            reasons = wsm.stale_reasons(wsm.read_manifest_rows(p["清單"]), workspace_root)
        except wsm.WorkspaceError as exc:
            reasons = [str(exc)]
        if reasons:
            return {"指令": restart, "說明": "匯入/ 的檔跟清單不一樣（%s）：重新配對、初比對" % reasons[0]}
        # 人改了清單（修正配對、補發布根目錄）但檔沒動：跟上一次開始用的那一份比
        from _common import SYSTEM_DIR
        staged = os.path.join(root, SYSTEM_DIR, "輸入", "規章清單.csv")
        if os.path.isfile(staged) and _manifest_key(p["清單"]) != _manifest_key(staged):
            return {"指令": restart, "說明": "匯入/規章清單.csv 改過了：照新的清單重新%s" % ("體檢" if health else "比對")}
    statuses = statuses_of(root) if bt.is_batch_root(root) else []
    if not statuses:
        return {"指令": restart if workspace_root else None, "說明": "還沒有這一輪的比對結果"}
    moved = [s for s in statuses if s["階段"] == "重新比對"]
    if moved:
        return {"指令": restart, "說明": "%s：%s：重新%s" % (moved[0]["規章"], moved[0]["問題"], "體檢" if health else "比對")}
    if semantic_unmerged(root):
        return {"指令": "batch-semantic", "說明": "語意結果已算好：併入"}
    if semantic_pending(root):
        back, problem = _semantic_back(root)
        if back:
            return {"指令": "batch-semantic", "說明": "語意交換包帶回來了：併入"}
        if os.environ.get("REG_ISOLATED") == "1":
            return {"指令": None, "說明": problem or "語意比對還沒做：照隔離區輸出的本機請求流程處理。"}
        # 只問使用者執行／不執行，不把別台電腦當預設解法（SKILL.md）；怎麼檢查、怎麼略過寫在人工待辦
        return {"指令": None, "說明": problem or "語意比對還沒做（這台電腦的 BGE-M3 模型沒設定或不能用）："
                                              "請使用者選「執行」或「不執行」（見人工待辦）"}
    if pack_unfinished(root):
        return {"指令": "batch-review-pack", "說明": "上一次審查打包沒跑完：重新打包"}
    stage = STAGES[min(STAGES.index(s["階段"]) for s in statuses)]
    if stage == "AI審查":
        blocked = [s for s in statuses if s["階段"] == "AI審查" and s["AI審查"] == "mismatch"]
        if blocked:
            return {"指令": None, "說明": "%s：%s" % (blocked[0]["規章"], blocked[0]["問題"])}
        if any(s["AI審查"] == "todo" for s in statuses if s["階段"] == "AI審查"):
            return {"指令": "batch-review-pack", "說明": "AI 審查：產審查包"}
        import ai_tables as at
        if not os.path.isfile(os.path.join(at.folder(root), at.INDEX)):
            # 舊工作區沒有 PACK_MARK：先讀我.md 是打包最後才寫的，它不在就是沒打包完，不能叫 AI 照它填表
            return {"指令": "batch-review-pack", "說明": "審查包不完整（沒有 %s）：重新打包" % at.INDEX}
        return {"指令": "batch-review-import", "說明": "AI 審查：匯入 AI 填好的表", "先看AI": True}
    if _consistency_pending(root):
        # 體檢：各本都審完了，重複／矛盾那一張（整批一張）還沒匯入：匯入會連它一起收（先看 AI 填完沒）
        return {"指令": "batch-review-import", "說明": "AI 一致性審查／法規更新檢視：匯入 AI 填好的表", "先看AI": True}
    if tables_edited_after_report(root):
        # v1.25.0：報告出了之後 AI 又改了四張 AI 表（報告審查發現資料錯了、直接改表）：重新匯入再出報告
        return {"指令": "batch-review-import", "說明": TABLES_EDITED, "先看AI": True}
    if report_state(root) == REPORT_IMPORTING:
        return {"指令": "batch-review-import", "說明": "上一次審查匯入沒跑完：重新匯入，再重出報告", "先看AI": True}
    problem = report_problem(root)
    if problem:
        return {"指令": REPORT_REBUILD, "說明": problem}
    busy = report_busy(root)
    if busy:
        return {"指令": None, "說明": busy}
    import report_review as rv
    if rv.pending(root):
        # v1.18.0 最後一站：AI 把整份報告看一遍（設定.html「AI報告審查」可以關）
        return {"指令": None, "說明": rv.todo_line("繼續", "體檢報告" if health else "比對報告"), "報告審查": True}
    return {"指令": None, "說明": REPORT_DONE}
