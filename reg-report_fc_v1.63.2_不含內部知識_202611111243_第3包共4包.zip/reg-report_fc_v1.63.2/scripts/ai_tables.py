# -*- coding: utf-8 -*-
"""
批次的 AI 表：每一種一張、全部規章合在一起（第一欄是規章），放 產出/2_Log檔案/AI審查/。

以前 AI 要到 產出/2_Log檔案/<規章名>/2_Log檔案/ 逐本填四張表：二十本就是八十個檔，漏一本整批退件。
現在 batch-review-pack 逐本寫完之後合成四張，另寫一份 先讀我.md（這一批還要讀哪幾份審查資料、
四張表各有幾列要填）與整批共用的 評分標準.md。AI 只填這四張。

程式內部照舊一本一份（review-import 的驗證、指紋、報告都靠各本那一份）。合一表寫回各本時
只寫 AI 這次改過的格：打包當時每一列的答案記在 合一表紀錄.json，跟那時候不一樣的格才算 AI 填的。
所以 AI 照舊直接填各本那一份也照樣算——合一表沒動，就不會去蓋各本。
"""

import csv
import glob
import io
import json
import os
import re
import sys
import tempfile
import shutil
import unicodedata

HERE = os.path.dirname(os.path.abspath(__file__))
REGDIFF = os.path.join(HERE, "regdiff")
for _path in (HERE, REGDIFF):
    if _path not in sys.path:
        sys.path.insert(0, _path)

from _common import SYSTEM_DIR, locate, open_csv, read_csv_text
from file_replace import replace_file

FOLDER = "AI審查"
BOOK = "規章"
INDEX = "先讀我.md"
RECORD = "合一表紀錄.json"
NEW_ID = "新增"
REUSED = "沿用查證"
# (檔名, 編號欄, AI 填的欄)
SPECS = (
    ("AI候選判斷.csv", "列ID", ("AI判斷", "AI分數", "AI理由")),
    ("AI異動審查.csv", "異動ID", ("AI判斷", "AI分數", "AI理由", "查證來源")),
    ("AI條文檢查.csv", "檢查ID", ("AI判斷", "AI理由", "查證來源")),
    ("AI外部引用.csv", "引用ID", ("AI判斷", "AI理由", "AI更正", "查證來源", "類別")),
)
# 填表另外支援體檢、法規追蹤的表：(檔名, 編號欄, AI 填的欄, 有沒有規章欄, 新增列另外可填的欄；None＝不能新增)
OTHER_SPECS = (
    ("AI一致性.csv", "配對ID", ("AI判斷", "AI理由"), False, None),
    ("AI一致性家族.csv", "家族ID", ("AI判斷", "有問題的段", "對照段", "AI理由"), False, None),
    ("AI錯漏字.csv", "列ID", ("原文", "改成", "AI判斷", "AI理由"), True, {"段次"}),
    ("AI法規適用.csv", "事件ID", ("AI判斷", "AI理由"), False, None),
    ("AI法規影響.csv", "列ID", ("法規原文", "AI判斷", "AI分數", "AI理由", "建議改法", "法定期限", "期限依據", "查證範圍"),
     True, {"事件ID", "段次"}),
)
LAW_TABLES = ("AI法規適用.csv", "AI法規影響.csv")
# 行式答案（v1.60.0）每張表預設的欄：編號在最前面，比對的四張表前面多一欄規章；要別的欄就寫 #欄。
# 選填欄盡量不放預設：文字裡忘了跳脫 | 時，多出來的格才會被擋，不會靜默跑進別的欄
LINE_COLUMNS = {
    "AI候選判斷.csv": (BOOK, "列ID", "AI判斷", "AI分數", "AI理由"),
    "AI異動審查.csv": (BOOK, "異動ID", "AI判斷", "AI分數", "AI理由"),
    "AI條文檢查.csv": (BOOK, "檢查ID", "AI判斷", "AI理由"),
    "AI外部引用.csv": (BOOK, "引用ID", "AI判斷", "AI理由", "AI更正"),
    "AI一致性.csv": ("配對ID", "AI判斷", "AI理由"),
    "AI一致性家族.csv": ("家族ID", "AI判斷", "有問題的段", "對照段", "AI理由"),
    "AI錯漏字.csv": (BOOK, "列ID", "原文", "改成", "AI判斷", "AI理由"),
    "AI法規適用.csv": ("事件ID", "AI判斷", "AI理由"),
    "AI法規影響.csv": ("列ID", "AI判斷", "AI分數", "AI理由", "法規原文", "建議改法"),
    "AI報告審查.csv": ("序號", "頁", "位置", "問題類型", "問題", "處理", "說明"),
}
# 預設欄的這種判斷不該有後面這幾欄：有就是理由裡的 | 沒跳脫，文字跑進別的欄了
LINE_CONFLICTS = {"AI法規影響.csv": ("不用改", ("法規原文", "建議改法")), "AI外部引用.csv": ("沒問題", ("AI更正",))}
LINE_TABLE = "#表"
LINE_FIELDS = "#欄"
LINE_COMMENT = "##"
ID_ALIAS = "列編號"
# 最近一次 fill_answers 略過的筆數說明（呼叫端印給 AI 看）
LAST_NOTICES = []
LAST_WRITTEN = 0
# 新增列一定要指定規章的表（法規影響的新增列可以是內規沒寫到的義務，不一定有規章）
NEW_NEEDS_BOOK = {"AI外部引用.csv": "外部引用", "AI錯漏字.csv": "錯漏字"}
DELETE_HELP = ('自己加的新增列不要了，用填表刪：`{"表":"AI法規影響.csv","規章":"","列編號":"新增","刪除":true,'
               '"欄位":{"事件ID":"L12","AI理由":"那一列的理由"}}`（「欄位」寫認得出那一列的值，要剛好對到一列）；不要自己改 CSV。')


def natural_id_key(value):
    import re
    return tuple((1, int(part)) if part.isdigit() else (0, part.casefold())
                 for part in re.split(r'(\d+)', str(value)))


def folder(root):
    return os.path.join(root, SYSTEM_DIR, FOLDER)


def _s(value):
    return "" if value is None else str(value).strip()


def repeated_text_warnings(rows, columns=("AI理由", "建議改法"), min_rows=8):
    """找不同段次大量使用相同文字的列，只回提醒、不改表。"""
    warnings = []
    for column in columns:
        groups = {}
        for row in rows or []:
            value = _s(row.get(column))
            if not value or (column == "建議改法" and _s(row.get("AI判斷")) not in ("需再檢查", "建議修改")):
                continue
            position = tuple(_s(row.get(key)) for key in
                             ("段次", "候選段次", "新版段次", "段次A", "段次B", "成員"))
            groups.setdefault(value, []).append(position)
        for value, positions in groups.items():
            threshold = 3 if column == "建議改法" else min_rows
            if len(positions) >= threshold and len(set(positions)) > 1:
                preview = value[:30] + ("…" if len(value) > 30 else "")
                warnings.append("%d 列的 %s 一字不差（「%s」）：確認每一列都看過那一段" %
                                (len(positions), column, preview))
    return warnings


def _read(path):
    with open_csv(path) as f:
        reader = csv.DictReader(f)
        return list(reader.fieldnames or []), list(reader)


def _write(path, fields, rows):
    tmp = path + ".tmp"
    with io.open(tmp, "w", encoding="utf-8-sig", newline="") as f:
        writer = csv.writer(f, quoting=csv.QUOTE_ALL)
        writer.writerow(fields)
        for row in rows:
            writer.writerow([row.get(c, "") for c in fields])
    if os.path.isfile(path):
        with open(path, 'rb') as old, open(tmp, 'rb') as new:
            same = old.read() == new.read()
        if same:
            os.remove(tmp)
            return
    replace_file(tmp, path)


def _csv_spans(text):
    """CSV 每格的原始文字位置，含引號；保留原有換行與未改動的格。"""
    rows, row, start, i, quoted = [], [], 0, 0, False
    while i < len(text):
        c = text[i]
        if c == '"' and (quoted or i == start):
            if quoted and i + 1 < len(text) and text[i + 1] == '"':
                i += 2
                continue
            quoted = not quoted
        if not quoted and c in ',\r\n':
            row.append((start, i))
            if c != ',':
                rows.append(row)
                row = []
                if c == '\r' and i + 1 < len(text) and text[i + 1] == '\n':
                    i += 1
            start = i + 1
        i += 1
    if quoted:
        raise ValueError("CSV 引號未閉合")
    if start < len(text) or row:
        row.append((start, len(text)))
        rows.append(row)
    return rows


def _row_lookup(rows, fields, idcol):
    """一張表的查列索引：({編號: [列]}, {(規章, 編號): [列]})，只收欄數對的列，同一鍵照表上順序。
    v1.55.1：以前每筆答案逐列掃，100 本約 15,000 列要 196 秒。"""
    plain, booked = {}, {}
    at_id = fields.index(idcol)
    at_book = fields.index(BOOK) if BOOK in fields else None
    for i, row in enumerate(rows[1:], 1):
        if len(row) == len(fields):
            plain.setdefault(row[at_id], []).append(i)
            if at_book is not None:
                booked.setdefault((row[at_book], row[at_id]), []).append(i)
    return plain, booked


def is_line_answers(text):
    """答案檔是行式（第一個不是空白的字元是 #）還是 JSON。"""
    return text.lstrip().startswith("#")


def _line_cells(line):
    """用 | 切一行；文字裡的 | 寫成 \\|，換行寫成 \\n。"""
    cells, cell, i = [], [], 0
    while i < len(line):
        if line[i] == "\\" and line[i + 1:i + 2] in ("|", "n"):
            cell.append("|" if line[i + 1] == "|" else "\n")
            i += 2
            continue
        if line[i] == "|":
            cells.append("".join(cell))
            cell = []
        else:
            cell.append(line[i])
        i += 1
    return [c.strip() for c in cells + ["".join(cell)]]


def _line_id_column(table, columns):
    """這張表的編號欄在 columns 的哪一格；沒有回 None。法規影響表的 事件ID 不是編號，只有它自己的編號欄算。"""
    own = next(c for c in LINE_COLUMNS[table] if c != BOOK)
    for name in (own, ID_ALIAS):
        if name in columns:
            return list(columns).index(name)
    return None


def _line_conflict(table, filled):
    verdict, columns = LINE_CONFLICTS.get(table, ("", ()))
    spilled = [c for c in columns if filled.get(c)]
    return spilled if spilled and filled.get("AI判斷") == verdict else []


def parse_line_answers(text):
    """行式答案（v1.60.0）。模擬時 AI 35 次寫行內 python 只為了組 JSON，這裡一列一行就好：
        #表 AI法規影響.csv
        L78-1|不用改|0|〔無關〕這段講外匯業務
    #欄 可以換欄（例如 #欄 列ID|事件ID|AI判斷），下一個 #表 換表，## 開頭的行是註解。
    其他 # 開頭的行一律報錯（多半是理由換行，靜默略過答案就少一截），資料真的以 # 開頭寫 \\#。
    空的格不填（要清掉一格用 JSON）。回傳 (答案, 每筆在第幾行, 錯誤)，答案跟 JSON 答案檔同一種格式。"""
    answers, line_numbers, errors = [], [], []
    table, columns, id_at, custom = None, None, None, False
    # 只認換行符：splitlines 連 \\x0c、\\u2028 也切，理由裡有這些字元會斷成兩行
    for number, raw in enumerate(text.split("\n"), 1):
        line = raw.strip()
        if not line:
            continue
        tag = "第 %d 行" % number
        if line.startswith(LINE_TABLE):
            table = line[len(LINE_TABLE):].strip()
            columns, custom = LINE_COLUMNS.get(table), False
            id_at = _line_id_column(table, columns) if columns else None
            if table not in LINE_COLUMNS:
                errors.append("%s：找不到表 %s" % (tag, table))
            continue
        if line.startswith(LINE_FIELDS):
            if table not in LINE_COLUMNS:
                errors.append("%s：%s 要寫在 %s 下面" % (tag, LINE_FIELDS, LINE_TABLE))
                continue
            columns, custom = _line_cells(line[len(LINE_FIELDS):]), True
            id_at = _line_id_column(table, columns)
            if id_at is None:
                errors.append("%s：#欄 要有編號欄（%s）" % (tag, ID_ALIAS))
            continue
        if line.startswith(LINE_COMMENT):
            continue
        if line.startswith("#"):
            errors.append("%s：看不懂 # 開頭的這一行。註解寫 ##；一格只能一行，要換行寫 \\n；資料真的以 # 開頭寫 \\#" % tag)
            continue
        if line.startswith("\\#"):
            line = line[1:]
        if not table:
            errors.append("%s：前面要先寫一行 %s <表名>" % (tag, LINE_TABLE))
            continue
        if not columns or id_at is None:
            continue                        # 表名或 #欄 寫錯：上面已經報過，不用每一行再報一次
        cells = _line_cells(line)
        book_at = columns.index(BOOK) if BOOK in columns else None
        # 規章那格寫成列編號（R12、C3）＝漏寫規章欄、整行往前錯位；只少後面幾欄是合法的（一行最多幾欄，後面可省）
        if (book_at is not None and book_at < len(cells)
                and re.fullmatch(r"[RCK]\d+(?:-\d+)?", cells[book_at], re.I)):
            errors.append("%s：這張表每行要寫：規章｜列編號｜判斷｜…；例如：內規名稱｜R12｜不用改｜理由" % tag)
            continue
        if len(cells) < 2 or len(cells) > len(columns):
            errors.append("%s：%s 這張表一行最多 %d 欄（%s），這行 %d 欄；文字裡的 | 寫成 \\|"
                          % (tag, table, len(columns), "|".join(columns), len(cells)))
            continue
        filled = dict((column, cell) for column, cell in zip(columns, cells) if cell)
        rid = cells[id_at] if id_at < len(cells) else ""
        if not rid:
            errors.append("%s：編號是空的" % tag)
            continue
        filled.pop(columns[id_at])
        spilled = _line_conflict(table, filled) if not custom else []
        if spilled:
            errors.append("%s：判「%s」不會有 %s：多半是理由裡的 | 沒寫成 \\|，文字跑進別的欄了"
                          "（真的要填就用 %s 寫明欄位）" % (tag, filled["AI判斷"], "、".join(spilled), LINE_FIELDS))
            continue
        item = {"表": table, "列編號": rid, "欄位": filled}
        if BOOK in filled:
            item["規章"] = filled.pop(BOOK)
        answers.append(item)
        line_numbers.append(number)
    if not answers and not errors:
        errors.append("這個答案檔沒有任何一列答案")
    return answers, line_numbers, errors


def fill_answers(root, answers, check_only=False):
    """驗證整批後才寫入；回傳所有錯誤。root 為目前這輪產出。check_only 只驗不寫（v1.48.0）。"""
    errors, tables, edits, additions, removals, skipped = [], {}, {}, {}, {}, []
    lookups = {}
    specs = {name: (idcol, set(cols), True, {"段次", "程式抓到"} if name == "AI外部引用.csv" else None)
             for name, idcol, cols in SPECS}
    specs["AI報告審查.csv"] = ("序號", {"頁", "位置", "問題類型", "問題", "處理", "說明"}, False, set())
    specs.update((name, (idcol, set(cols), has_book, extra)) for name, idcol, cols, has_book, extra in OTHER_SPECS)
    strict = set(name for name, _, _ in SPECS)
    if not isinstance(answers, list):
        return ["答案檔必須是陣列"]
    for index, item in enumerate(answers, 1):
        tag = "第 %d 筆" % index
        if not isinstance(item, dict):
            errors.append(tag + "：必須是物件")
            continue
        name, book, rid, values = (item.get("表"), item.get("規章", ""), item.get("列編號"), item.get("欄位"))
        if isinstance(values, dict) and BOOK in values and "規章" not in item:
            values = dict(values)
            book = values.pop(BOOK)
        if not isinstance(name, str) or name not in specs:
            errors.append(tag + "：找不到表 " + str(name))
            continue
        if not isinstance(book, str) or not isinstance(rid, str) or not isinstance(values, dict) or not values:
            errors.append(tag + "：規章、列編號須為字串，欄位須為非空物件")
            continue
        path = os.path.join(folder(root), name)
        if name not in tables:
            try:
                with open(path, 'rb') as source:
                    raw = source.read()
                text, encoding = read_csv_text(path)
                if encoding == 'utf-8-sig' and not raw.startswith(b'\xef\xbb\xbf'):
                    encoding = 'utf-8'
                rows = list(csv.reader(io.StringIO(text, newline=''), strict=True))
                spans = _csv_spans(text)
                if not rows or len(rows) != len(spans) or any(len(r) != len(s) for r, s in zip(rows, spans)):
                    raise ValueError("CSV 格式不正確")
                tables[name] = (path, text, encoding, rows, spans)
            except (OSError, ValueError, csv.Error) as exc:
                errors.append(tag + "：無法讀取表 %s：%s" % (name, exc))
                continue
        path, text, encoding, rows, spans = tables[name]
        fields = rows[0]
        idcol, allowed, has_book, extra_new = specs[name]
        report = name == "AI報告審查.csv"
        if (has_book and BOOK not in fields) or idcol not in fields or len(set(fields)) != len(fields):
            errors.append(tag + "：表頭缺少規章或列編號，或欄名重複")
            continue
        if name not in lookups:
            lookups[name] = _row_lookup(rows, fields, idcol)
        plain, booked = lookups[name]
        if item.get("刪除") is not None:
            # v1.45.0：刪掉 AI 自己加的「新增」列。以前沒有辦法刪，被擋的新增列 AI 只好寫程式直接改 CSV
            if report:
                errors.append(tag + "：報告審查的列不能刪：用序號改那一列（例如「處理」寫不用改、說明寫原因）")
                continue
            if item.get("刪除") is not True or rid != NEW_ID or extra_new is None:
                errors.append(tag + "：「刪除」只能寫 true，而且只能刪自己加的列（列編號寫「新增」）")
                continue
            hits = [i for i, row in enumerate(rows[1:], 1) if len(row) == len(fields)
                    and row[fields.index(idcol)] == NEW_ID and (not has_book or not book or row[fields.index(BOOK)] == book)
                    and all(col in fields and isinstance(value, str) and row[fields.index(col)].strip() == value.strip()
                            for col, value in values.items())]
            # v1.49.0：同一份答案送兩次會有一模一樣的兩列，怎麼多寫值都對到 2 列；整列一字不差就一起刪
            identical = len(hits) > 1 and len(set(tuple(rows[i]) for i in hits)) == 1
            if len(hits) != 1 and not identical:
                errors.append(tag + "：要刪的新增列要剛好對到一列（現在對到 %d 列）：「欄位」多寫幾個那一列的值（例如事件ID、段次、AI理由）"
                              % len(hits))
            elif any(i in removals.setdefault(name, set()) for i in hits):
                errors.append(tag + "：同一列刪了兩次")
            else:
                removals[name].update(hits)
            continue
        if rid == NEW_ID:
            if extra_new is None:
                errors.append(tag + "：此表不允許新增列")
                continue
            if name in NEW_NEEDS_BOOK and not book:
                errors.append(tag + "：新增%s須指定規章%s" % (NEW_NEEDS_BOOK[name], "（「規章」寫在外層，不是「欄位」裡）"
                                                         if BOOK in values else ""))
                continue
            if name == "AI法規影響.csv" and not values.get("事件ID"):
                errors.append(tag + "：新增法規影響列要在欄位給「事件ID」")
                continue
            permitted = allowed | extra_new
            valid = True
            for col, value in values.items():
                if col == BOOK and has_book:
                    # 模擬時 AI 把規章放進「欄位」裡；它在外層，跟「表」「列編號」同一層
                    errors.append(tag + "：「規章」要寫在外層（跟「表」「列編號」同一層），不是寫在「欄位」裡")
                    valid = False
                elif col not in fields or col not in permitted or not isinstance(value, str):
                    errors.append(tag + "：找不到或不可填的欄，或欄位值不是字串 " + str(col))
                    valid = False
            if valid and not report:
                # v1.49.0：同一份答案送兩次（先填表、再填表 --接著匯入；本機視窗中途關掉又雙擊）
                # 不要再加一列一模一樣的
                wanted = dict((c, v.strip()) for c, v in values.items())
                if has_book:
                    wanted[BOOK] = book
                same = [i for i in plain.get(NEW_ID, ())
                        if all(rows[i][fields.index(c)].strip() == v for c, v in wanted.items())]
                twice = any(all(_s(r.get(c)) == v for c, v in wanted.items()) for r in additions.get(name, []))
                if same or twice:
                    skipped.append("%s：%s 已經有一模一樣的新增列，這一筆不再加" % (tag, name))
                    continue
            if valid:
                new = dict(values)
                if report:
                    nums = [int(r[fields.index(idcol)]) for r in rows[1:] if len(r) == len(fields) and r[fields.index(idcol)].isdigit()]
                    nums += [int(r[idcol]) for r in additions.get(name, [])]
                    new[idcol] = str(max(nums, default=0) + 1)
                else:
                    new[idcol] = NEW_ID
                    if has_book:
                        new[BOOK] = book
                additions.setdefault(name, []).append(new)
            continue
        # 比對的四張表要規章＋編號；體檢、法規、報告審查的表沒有規章欄，或沒給規章時只看編號（要唯一）
        # 報告審查已有的列用序號改（模擬時 AI 要補「問題」欄，填表擋下就改用檔案工具直接改 CSV）
        by_book = has_book and (book or name in strict)
        matches = booked.get((book, rid), ()) if by_book else plain.get(rid, ())
        if len(matches) != 1:
            errors.append(tag + "：找不到唯一的列 %s／%s" % (book, rid))
        for col, value in values.items():
            if col not in fields or col not in allowed:
                errors.append(tag + "：找不到或不可填的欄 " + str(col))
            elif not isinstance(value, str):
                errors.append(tag + "：欄位值須為字串 " + str(col))
            elif len(matches) == 1:
                key = (name, matches[0], fields.index(col))
                if key in edits:
                    errors.append(tag + "：同一格重複指定 " + col)
                else:
                    edits[key] = value
    global LAST_NOTICES, LAST_WRITTEN
    LAST_NOTICES = list(skipped)
    LAST_WRITTEN = 0
    for (table, row, col) in edits:
        if row in removals.get(table, ()):
            errors.append("%s：同一批又改又刪同一列（列 %d）" % (table, row + 1))
    prepared = {}
    if not errors:
        try:
            for name, (path, text, encoding, rows, spans) in tables.items():
                changes = []
                for (table, row, col), value in edits.items():
                    if table == name:
                        start, end = spans[row][col]
                        old = text[start:end]
                        quote = old.startswith('"') or any(c in value for c in ',"\r\n')
                        rendered = '"' + value.replace('"', '""') + '"' if quote else value
                        changes.append((start, end, rendered))
                for row in removals.get(name, ()):
                    # 整列連換行一起拿掉：從這一列第一格到下一列第一格
                    end = spans[row + 1][0][0] if row + 1 < len(spans) else len(text)
                    changes.append((spans[row][0][0], end, ""))
                # 從後面往前拼（改的位置不會重疊）；以前每一格都整份字串重組，大表很慢
                pieces, cursor = [], len(text)
                for start, end, rendered in sorted(changes, reverse=True):
                    pieces += [text[end:cursor], rendered]
                    cursor = start
                pieces.append(text[:cursor])
                text = "".join(reversed(pieces))
                if additions.get(name):
                    newline = '\r\n' if '\r\n' in text else '\n'
                    if text and not text.endswith(('\n', '\r')):
                        text += newline
                    buf = io.StringIO(newline='')
                    writer = csv.writer(buf, lineterminator=newline)
                    for row in additions[name]:
                        writer.writerow([row.get(c, '') for c in rows[0]])
                    text += buf.getvalue()
                data = text.encode(encoding)
                with open(path, 'rb') as original:
                    if original.read() != data:
                        prepared[path] = data
        except UnicodeEncodeError as exc:
            errors.append("答案無法以原編碼寫入：%s" % exc)
    if errors or check_only:
        return errors
    staged, backups, replaced = {}, {}, []
    try:
        for path, data in prepared.items():
            fd, tmp = tempfile.mkstemp(prefix='.填表_', suffix='.tmp', dir=os.path.dirname(path))
            staged[path] = tmp
            with os.fdopen(fd, 'wb') as out:
                out.write(data)
            fd, backup = tempfile.mkstemp(prefix='.填表原檔_', suffix='.bak', dir=os.path.dirname(path))
            os.close(fd)
            backups[path] = backup
            shutil.copy2(path, backup)
        for path in prepared:
            replace_file(staged[path], path)
            replaced.append(path)
    except OSError as exc:
        failures = []
        for path in reversed(replaced):
            try:
                replace_file(backups[path], path)
            except OSError as restore_error:
                failures.append('還原失敗：%s；原檔留在 %s（%s）' % (path, backups[path], restore_error))
        errors.append('填表寫入失敗：%s' % exc)
        errors.extend(failures)
    finally:
        for tmp in staged.values():
            if os.path.exists(tmp):
                os.unlink(tmp)
        for path, backup in backups.items():
            if os.path.exists(backup) and not any(backup in failure for failure in errors):
                os.unlink(backup)
    if not errors:
        LAST_WRITTEN = sum(1 for (table, row, col), value in edits.items()
                           if tables[table][3][row][col] != value)
        LAST_WRITTEN += sum(len(row) for rows in additions.values() for row in rows)
    return errors


def _key(book, rid):
    return "%s\x00%s" % (book, rid)


def _answers(row, columns):
    return dict((c, _s(row.get(c))) for c in columns)


_FLOAT_INT_RE = re.compile(r"^-?\d+\.0+$")


def _cell_key(value):
    """指紋用的格子值：去頭尾空白、全形轉半形、「12.0」當成「12」。
    AI 用 pandas 或 Excel 轉存 CSV，數字欄常變成 12.0、罕用字變成全形／半形的另一種寫法，
    以前每一列都退件還說「AI 不該動的欄被改過了」（審查 C10）。"""
    text = unicodedata.normalize("NFKC", _s(value))
    if _FLOAT_INT_RE.match(text):
        text = text.split(".")[0]
    return text


def _fingerprint(row, columns):
    """一列「AI 不填的欄」的指紋：寫回時拿來確認各本那一列還是打包時的同一列（A11）。"""
    import hashlib
    skip = set(columns) | {BOOK}
    # 空欄不算：合一表的欄是各本欄位的聯集，某一本沒有的欄讀回來是空字串
    text = "\x1f".join("%s=%s" % (k, _cell_key(v)) for k, v in sorted(row.items())
                       if k and k not in skip and _cell_key(v))
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def line_answer_help(tables):
    """先讀我.md「填表」一節的行式答案說明（v1.60.9）。模擬時先讀我只教 JSON、行式只寫在 執行方式.md，
    AI 比對那輪異動、條文檢查、外部引用、報告審查都回去組 JSON。tables：這一輪有的表（依 LINE_COLUMNS 的順序列欄）。"""
    shown = [name for name in LINE_COLUMNS if name in tables]
    example = shown[0] if shown else "AI候選判斷.csv"
    cells = ["R1" if c.endswith("ID") or c == "序號" else "<%s>" % c.replace("AI", "") for c in LINE_COLUMNS[example]]
    lines = ["**先用行式答案**（一列一行，不用組 JSON、不用寫程式產生）：建 `_AI答案/a.txt`，送 `填表 _AI答案/a.txt`。", "",
             "```text", LINE_TABLE + " " + example, "|".join(cells).rstrip("|"), "```", "",
             "這一輪各表的欄（照順序；後面的格可以省略）："]
    lines += ["- %s 的欄：%s" % (name, "|".join(LINE_COLUMNS[name])) for name in shown]
    lines += ["", "要填上面沒有的欄（查證來源、類別…）：`%s` 下一行寫 `%s 規章|引用ID|AI判斷|AI理由|查證來源` 換欄。"
              "一格只能一行：換行寫 `\\n`，文字裡的 `|` 寫 `\\|`；`##` 開頭是註解。一個檔可以好幾段 `%s`。"
              "細節見 references/執行方式.md。" % (LINE_TABLE, LINE_FIELDS, LINE_TABLE), ""]
    return lines


def merge(root, books):
    """batch-review-pack 逐本寫完之後呼叫：各本的四張 AI 表合成四張放 AI審查/，
    記下打包當時的答案（合一表紀錄.json），寫 先讀我.md。回傳 {檔名: (列數, 還沒填的列數)}。"""
    out = folder(root)
    os.makedirs(out, exist_ok=True)
    record, counts, waiting = {}, {}, {}
    for filename, id_col, columns in SPECS:
        fields, merged, answers, new_rows, prints = [], [], {}, {}, {}
        for name, outdir_doc in books:
            path = locate(outdir_doc, filename)[0]
            if not os.path.isfile(path):
                continue
            book_fields, rows = _read(path)
            for c in book_fields:
                if c not in fields:
                    fields.append(c)
            for row in rows:
                rid = _s(row.get(id_col))
                merged.append(dict(row, **{BOOK: name}))
                if rid == NEW_ID:
                    new_rows.setdefault(name, []).append(dict(row))
                elif rid:
                    answers[_key(name, rid)] = _answers(row, columns)
                    prints[_key(name, rid)] = _fingerprint(row, columns)
        path = os.path.join(out, filename)
        if not fields:
            if os.path.isfile(path):
                os.remove(path)          # 這一批沒有這種表：不留上一次的
            continue
        _write(path, [BOOK] + fields, merged)
        record[filename] = {"列": answers, "新增": new_rows, "指紋": prints}
        open_rows = [r for r in merged if not _s(r.get(REUSED)) and not _s(r.get("AI判斷"))]
        counts[filename] = (len(merged), len(open_rows))
        for r in open_rows:
            waiting.setdefault(filename, {}).setdefault(_s(r.get(BOOK)), set()).add(_s(r.get(id_col)))
    # 先寫 .tmp 再換名：寫到一半被中斷（Ctrl+C、磁碟滿）留下半個 json，之後每一站 split 都 traceback（審查 C6）
    record_path = os.path.join(out, RECORD)
    from _common import write_generated
    write_generated(record_path, json.dumps(record, ensure_ascii=False))
    import scoring_rubric as sr
    import health_law
    import health_typo
    law_lines = health_law.readme_lines(root)
    typo_lines = health_typo.readme_lines(root)
    import batch as bt
    health = bt.is_health_round(root)
    rubric = sr.render_all(law=bool(law_lines), typo=bool(typo_lines))
    if health:
        start, end = rubric.index("# 候選\n"), rubric.index("# 條文檢查\n")
        health_candidate = ("# 候選\n\n內部引用：核對這個引用指的是不是正確的那一處，依實際問題填判斷、分數與理由。"
                            "7–10 分寫「建議修改」、4–6 分寫「需再檢查」、0–3 分寫「不用改」；理由開頭寫對應標籤。\n\n"
                            "引用指不到或指錯時，給 10 分〔引用換號〕，理由寫正確指向及改法；無法確定時給 4 分〔有疑點〕，寫明疑點並請確認；指向正確時給 0 分〔無關〕，說明指向。\n\n"
                            "可用分數與標籤：" + sr.labels("候選") + "。\n\n")
        rubric = rubric[:start] + health_candidate + rubric[end:]
        rubric = rubric.replace("引用的是這一批一起比對的本行規章，程式已經核對過條號、點號存在（程式先填好，AI 不用管）；這一處要不要跟著改，看連帶決定表的跨本引用列", "引用的是這一批體檢的本行規章，程式已核對條號、點號存在。")
    write_generated(os.path.join(out, sr.RUBRIC_FILE), rubric)
    import review_import
    lines = ["# AI 審查：這一批要做的事", "",
             "只填這個資料夾裡下面列的表（第一欄是規章；「沿用查證」有值的列程式已經填好，不用管）。"
             "全部填完、報告出來才回覆使用者，中途不要停下來叫使用者說「繼續」（進度寫進 _工作/進度.md 後接著做）；"
             "「您不用操作，接下來還要做 XX」也不是停點，直接做 XX。每一列看過那一段再判，不要寫程式把同一句理由、分數整批套上去。",
             "先讀同一個資料夾的 `%s`（每一種表怎麼判、怎麼打分，整批只有這一份）；" % sr.RUBRIC_FILE
             + "外部引用先看各本清單第零節的官方原文；未附原文及條文檢查仍要上網查證。",
               ("審查包的內部引用要核對指的是不是正確的那一處。" if health else "審查包裡的候選只寫異動編號（C3），那一處的新舊文與前後文在該本的 LLM異動清單.md：先讀異動清單再讀審查包。可用 `看列 <規章> R12` 一次看候選和對應異動。"),
             "填完依目前的執行方式送 `繼續`（或 審查匯入）：隔離區送 `執行 繼續`；本機在 reg-report 的 skill 資料夾"
             "（有 scripts/ 的那一層）跑 `python scripts/run_all.py 繼續`。", "",
             "## 匯入會擋下的規則", ""] + ["- " + rule for rule in review_import.blocking_rules()] + ["",
             "## 填表", ""] + line_answer_help(counts) + [
             "新增列、刪除列、要清掉一格，才用 JSON 答案檔：在工作區建立 UTF-8 JSON 答案檔，一筆指定一張表、規章、列編號與要填的欄位；未指定的格不動。", "",
             '```json', '[{"表":"AI候選判斷.csv","規章":"範例","列編號":"R1","欄位":{"AI判斷":"建議修改","AI分數":"7","AI理由":"〔範例〕改成…"}}]', '```', "",
              '新增外部引用：`{"表":"AI外部引用.csv","規章":"範例","列編號":"新增","欄位":{"段次":"1","AI判斷":"漏抓","AI理由":"〔未指明條號〕請查證","AI更正":"法規全銜","類別":"法律","查證來源":"實際打開的官方網址"}}`；'
              '新增的列跟原有的列一樣要過上面「匯入會擋下的規則」（例如漏抓的法律、主管機關法規要填查證來源網址）。',
              '新增報告審查：`{"表":"AI報告審查.csv","列編號":"新增","欄位":{"問題類型":"無問題","處理":"不用改"}}`；序號自動接續。已有的列用序號改：`"列編號":"1"`。',
              "列編號是表中的列ID、異動ID、檢查ID 或引用ID，欄位值須為字串。只有外部引用及報告審查可以新增列。每批執行 `填表 <答案檔>`；最後一批才加 `--接著匯入`。",
              "體檢、法規追蹤的表（AI一致性、AI一致性家族、AI錯漏字、AI法規適用、AI法規影響）也能用填表；沒有規章欄的表「規章」給空字串，"
              "列編號是配對ID、家族ID、列ID 或事件ID。AI錯漏字、AI法規影響也可以新增列（法規影響的新增列要給事件ID）。"
              + DELETE_HELP +
              "一個答案檔只填一輪：法規追蹤的表跟這一輪的表要分開寫；`AI報告審查.csv` 跟哪一輪的表寫在一起就填那一輪，單獨寫時填剛出報告的那一輪。", "",
             "## 這一輪要填的表（只列還有空格的）", "",
             # v1.50.1：第三次模擬 AI 自己寫了 6 支讀 CSV 的程式找「還沒填的列」，因為先讀我沒說有 查表
             "還有哪些格沒填、某個事件的列：`查表 <表名> --空白`、`查表 AI法規影響.csv --事件 L33`"
             "（隔離區送 `執行 查表 …`；省略 --欄 用精簡欄位），不用自己寫程式讀 CSV。", ""]
    done = []
    for filename, _, _ in SPECS:
        if filename in counts:
            total, left = counts[filename]
            if left:
                lines.append("- `%s`：%d 列，要填 %d 列" % (filename, total, left))
                for book_name, ids in sorted(waiting.get(filename, {}).items()):
                    lines.append("  - %s：%s" % (book_name, "、".join(sorted(ids, key=natural_id_key))))
                if filename == "AI外部引用.csv":
                    import review_pack as rp
                    attached = 0
                    for book_name, outdir_doc in books:
                        path = rp.place(outdir_doc, "LLM外部引用清單.md")
                        if os.path.isfile(path):
                            with io.open(path, encoding="utf-8") as source:
                                text = source.read()
                            for rid in waiting.get(filename, {}).get(book_name, set()):
                                start = text.find("## " + rid + "　段次")
                                end = text.find("\n## ", start + 1) if start >= 0 else -1
                                if start >= 0 and "官方原文：見〈零〉" in text[start:end if end >= 0 else None]:
                                    attached += 1
                    lines.append("  其中 %d 列程式已附官方原文（見 LLM外部引用清單.md 第零節）。" % attached)
                    # v1.50.1：清單在各本的資料夾、不在 AI審查/；第一、三次模擬各 find 了 2～3 次才找到。直接列路徑
                    workspace_dir = os.path.dirname(os.path.abspath(root))
                    for book_name, outdir_doc in books:
                        path = rp.place(outdir_doc, "LLM外部引用清單.md")
                        if os.path.isfile(path) and book_name in waiting.get(filename, {}):
                            lines.append("  %s 的清單：%s" % (book_name, os.path.relpath(path, workspace_dir).replace(os.sep, "/")))
            elif total:
                done.append(filename)
    import health_check as hc
    if os.path.isfile(os.path.join(out, hc.TABLE_FILE)):
        # 體檢：重複／矛盾候選整批一張表，放在同一個資料夾
        _, pair_rows = _read(os.path.join(out, hc.TABLE_FILE))
        left = hc.unanswered(root)
        if left:
            lines.append("- `%s`：%d 對，要填 %d 對（兩段全文與前後文在同資料夾的 `%s`；判法見評分標準「一致性」）"
                         % (hc.TABLE_FILE, len(pair_rows), left, hc.pack_list(root)))
        elif pair_rows:
            done.append(hc.TABLE_FILE)
    if os.path.isfile(os.path.join(out, hc.FAMILY_TABLE_FILE)):
        # v1.31.0：3 段以上、同一個範本改出來的好幾段，一個家族一列
        _, family_rows = _read(os.path.join(out, hc.FAMILY_TABLE_FILE))
        left = hc.unanswered(root, hc.FAMILY_TABLE_FILE)
        if left:
            lines.append("- `%s`：%d 個家族，要填 %d 個（各段全文與前後文在同資料夾的 `%s`；"
                         "矛盾、錯漏字、重複要填「有問題的段」，矛盾、錯漏字還要填「對照段」）"
                         % (hc.FAMILY_TABLE_FILE, len(family_rows), left, hc.pack_list(root)))
        elif family_rows:
            done.append(hc.FAMILY_TABLE_FILE)
    for name, left in sorted(health_law.unanswered(root).items()):
        lines.append("- `%s`：要填 %d 列（見下面「法規更新檢視」）" % (name, left))
    typo_left = health_typo.unanswered(root)
    if typo_left:
        lines.append("- `%s`：要讀 %d 份（見下面「錯漏字檢查」）" % (health_typo.TABLE_FILE, typo_left))
    if done:
        lines.append("- 已經全部填好（沿用判過的答案），不用動：%s" % "、".join("`%s`" % n for n in done))
    lines += typo_lines + law_lines
    import learned
    learned.ensure_synonym_template(root)      # v1.20.0：AI 順手提的同義詞（選填）
    lines += learned.synonym_readme_lines()
    import precedents as pc
    todo = pc.rules_todo_lines()               # v1.40.0：自動收進來、還沒整理成準則的承辦回饋
    if todo:
        lines += [""] + todo
    import rule_library
    lines += rule_library.readme_lines()       # v1.9.0：資料庫有圖片電腦轉不出字，請 AI 看圖打字
    lines += ["", "## 要讀的審查資料（已經全部填好的不列）", ""]
    listed = _files_to_read(books, waiting)
    for name, outdir_doc in books:
        if not listed.get(name):
            continue
        rel = "%s/%s/%s/%s/" % (os.path.basename(os.path.normpath(root)), SYSTEM_DIR, name, SYSTEM_DIR)
        lines.append("- %s：%s" % (name, "、".join("`%s%s`" % (rel, f) for f in listed[name])))
    if not any(listed.values()):
        lines.append("（沒有要 AI 判的列：直接跑 繼續）")
    write_generated(os.path.join(out, INDEX), "\n".join(lines) + "\n")
    return counts


# 每種清單對哪一張 AI 表：那一本在那張表還有列要填，才叫 AI 讀那份清單
_LIST_FOR_TABLE = (("LLM條文檢查清單.md", "AI條文檢查.csv"), ("LLM外部引用清單.md", "AI外部引用.csv"))


def _files_to_read(books, waiting):
    """{規章: [要讀的檔名...]}。以前每一本的每一份都列，AI 已經判過、內容沒變而沿用答案的也照讀一次。
    審查包：裡面有還沒填的候選列才列。異動清單：這本還有異動要審，或是要讀的審查包裡有候選掛它的異動。
    條文檢查、外部引用清單：那張表這本還有列要填才列。"""
    import review_pack as rp
    listed, change_lists = {}, set()
    for name, outdir_doc in books:
        open_cands = waiting.get("AI候選判斷.csv", {}).get(name, set())
        try:
            with io.open(locate(outdir_doc, rp.PACK_INDEX)[0], encoding="utf-8") as f:
                index = json.load(f)
        except (OSError, ValueError):
            index = None
        packs = []
        if index is None:
            # 沒有索引（舊產出）：有列要填就整本的審查包都列
            if open_cands:
                system = os.path.join(outdir_doc, SYSTEM_DIR)
                packs = sorted(os.path.basename(p) for p in glob.glob(os.path.join(system, "LLM審查包_*.md")))
                change_lists.add(name)
        else:
            for pack, ids in sorted(index.get("審查包", {}).items()):
                hit = [rid for rid in ids if rid in open_cands]
                if hit:
                    packs.append(pack)
                    change_lists.add(name)
                    for rid in hit:
                        change_lists.update(index.get("跨本異動清單", {}).get(rid) or [])
        if waiting.get("AI異動審查.csv", {}).get(name):
            change_lists.add(name)
        listed[name] = packs
    for name, outdir_doc in books:
        files = (["LLM異動清單.md"] if name in change_lists else []) + listed[name]
        for list_file, table in _LIST_FOR_TABLE:
            if waiting.get(table, {}).get(name):
                files.append(list_file)
        listed[name] = files
    return listed


def _plain(row):
    return dict((k, _s(v)) for k, v in row.items() if k != BOOK)


SKIP_NOTE = "：這一列的答案沒寫回；重新打包後合一表會照各本重建，AI 重填這一列"


def split(root, books, lenient=False):
    """合一表上 AI 改過的格寫回各本（batch-review-pack 重新打包前、batch-review-import 驗證前呼叫）。
    lenient（v1.49.0，審查打包用）：合一表被改壞的列（不該動的欄被改、編號被改、打包後各本變過、紀錄檔壞了）
    不擋，跳過那幾列、寫成提醒——打包本來就會照各本重建合一表。以前打包也先撞到同一個錯，永遠過不去。
    回傳 (錯誤 list, {規章: 寫回的格數}, 提醒 list)；有錯誤就一格都不寫。
    沒有合一表（還沒打包、或不是這一版打包的）回 ([], {}, [])。
    打包時有、這次不在 books 裡的本（產出不完整被略過）：AI 沒動的列不管；AI 填過的列講一聲、先不寫回。"""
    out = folder(root)
    record_path = os.path.join(out, RECORD)
    if not os.path.isfile(record_path):
        return [], {}, []
    try:
        with io.open(record_path, encoding="utf-8") as f:
            record = json.load(f)
        if not isinstance(record, dict):
            raise ValueError("內容不是一組對照表")
    except (OSError, ValueError) as exc:
        # 壞檔不要 traceback：講清楚怎麼修（重新打包會重寫這個檔）
        message = "%s 讀不出來（%s）：請重跑審查打包（會重寫它）" % (RECORD, exc)
        if lenient:
            return [], {}, ["%s 讀不出來（%s）：合一表上還沒寫回的答案沒辦法寫回，這次打包會重建它" % (RECORD, exc)]
        return [message], {}, []
    known = dict(books)
    errors, plans, notes = [], [], []
    broken = notes if lenient else errors
    for filename, id_col, columns in SPECS:
        path = os.path.join(out, filename)
        if filename not in record or not os.path.isfile(path):
            continue
        before = record[filename]
        try:
            _, rows = _read(path)
        except (OSError, UnicodeDecodeError, csv.Error, ValueError) as exc:
            errors.append("%s/%s 讀不出來：%s" % (FOLDER, filename, exc))
            continue
        changes, new_rows, seen = {}, {}, set()
        recorded = set(k.split("\x00")[0] for k in before["列"]) | set(before["新增"])
        for line, row in enumerate(rows, 2):
            book, rid = _s(row.get(BOOK)), _s(row.get(id_col))
            if not book and not rid:
                continue
            tag = "%s/%s 第 %d 列（%s %s）" % (FOLDER, filename, line, book or "沒寫規章", rid or "沒有編號")
            if book not in known:
                if book not in recorded:
                    errors.append("%s：規章「%s」不在這一批" % (tag, book))
                    continue
                old = before["列"].get(_key(book, rid))
                touched = (_plain(row) not in [_plain(r) for r in before["新增"].get(book, [])] if rid == NEW_ID
                           else old is None or any(_s(row.get(c)) != old.get(c, "") for c in columns))
                if touched:
                    notes.append("%s：%s 這次沒有進批次（產出不完整？），AI 填的這一列先沒寫回" % (tag, book))
                continue
            if rid == NEW_ID:
                new_rows.setdefault(book, []).append(dict((k, v) for k, v in row.items() if k != BOOK))
                continue
            old = before["列"].get(_key(book, rid))
            if old is None:
                broken.append("%s：這一本打包時沒有這一列（編號不要改）%s" % (tag, SKIP_NOTE if lenient else ""))
                continue
            if (book, rid) in seen:
                errors.append("%s：同一列出現兩次" % tag)
                continue
            seen.add((book, rid))
            fingerprint = before.get("指紋", {}).get(_key(book, rid))
            if fingerprint and _fingerprint(row, columns) != fingerprint:
                broken.append("%s：AI 不該動的欄（全文、段次、編號…）被改過了；只填 %s%s"
                              % (tag, "、".join(columns), SKIP_NOTE if lenient else
                                 "（被 Excel 存過也會這樣：跑 審查打包 會照各本重建合一表，AI 再填這幾列）"))
                continue
            cells = dict((c, _s(row.get(c))) for c in columns if _s(row.get(c)) != old.get(c, ""))
            if cells:
                changes.setdefault(book, {})[rid] = cells
        for book in sorted((set(changes) | set(new_rows) | set(before["新增"])) & set(known)):
            merged_new = new_rows.get(book, [])
            new_changed = ([dict((k, _s(v)) for k, v in r.items()) for r in merged_new]
                           != [dict((k, _s(v)) for k, v in r.items()) for r in before["新增"].get(book, [])])
            if not changes.get(book) and not new_changed:
                continue
            book_path = locate(known[book], filename)[0]
            if not os.path.isfile(book_path):
                errors.append("%s：找不到 %s 的 %s" % (FOLDER, book, filename))
                continue
            # 各本那一張在打包之後變過（例如語意併入後重寫，列ID 位移）：照列ID 寫回會把答案
            # 掛到別的候選上，review-import 也驗不出來（A11）。這時候不寫，請重新打包
            prints = before.get("指紋", {})
            if prints and changes.get(book):
                try:
                    _, current = _read(book_path)
                except (OSError, UnicodeDecodeError, csv.Error, ValueError) as exc:
                    errors.append("%s 的 %s 讀不出來：%s" % (book, filename, exc))
                    continue
                now = dict((_s(r.get(id_col)), _fingerprint(r, columns)) for r in current)
                moved = [rid for rid in changes[book] if prints.get(_key(book, rid)) not in (None, now.get(rid))]
                if moved:
                    broken.append("%s 的 %s 在打包之後變過（%s 已經不是打包時的那一列）：AI 的答案不能照編號寫回，"
                                  "請重跑 審查打包，AI 照新的表再填"
                                  % (book, filename, "、".join(moved[:5])))
                    if not lenient:
                        continue
                    for rid in moved:
                        changes[book].pop(rid, None)
            plans.append((filename, book, book_path, id_col, changes.get(book, {}), merged_new if new_changed else None))
    if errors:
        return errors, {}, notes          # 有錯就一格都不寫：不留一半寫回、一半沒寫的各本
    written = {}
    for filename, book, book_path, id_col, cells_by_id, merged_new in plans:
        fields, book_rows = _read(book_path)
        count = 0
        for row in book_rows:
            cells = cells_by_id.get(_s(row.get(id_col)))
            if cells:
                row.update(cells)
                count += len(cells)
        if merged_new is not None:
            book_rows = [r for r in book_rows if _s(r.get(id_col)) != NEW_ID] + merged_new
            count += len(merged_new)
        _write(book_path, fields, book_rows)
        written[book] = written.get(book, 0) + count
        # v1.47.1：寫回之後紀錄改成「各本現在的樣子」。以前一直跟打包當時比：AI 加了新增列（寫回了）
        # 又用填表刪掉，合一表變回跟打包時一樣，就以為沒改、不寫回，各本那一列一直留著、驗表一直擋
        before = record[filename]
        for rid, cells in cells_by_id.items():
            before["列"].setdefault(_key(book, rid), {}).update(cells)
        if merged_new is not None:
            before["新增"][book] = [dict((k, _s(v)) for k, v in r.items()) for r in merged_new]
    if plans:
        from _common import write_generated
        write_generated(record_path, json.dumps(record, ensure_ascii=False))
    return errors, written, notes


def unanswered(books, root=None):
    """各本的四張 AI 表還有幾列沒填「AI判斷」（程式先填好的「沿用查證」列不算）：{檔名: 列數}，只列有缺的。
    root（產出根目錄）有給就連體檢的 AI一致性.csv（整批一張、放 AI審查/）一起算。"""
    missing = {}
    if root:
        import health_check as hc
        import health_law
        count = hc.unanswered(root)
        if count:
            missing[hc.TABLE_FILE] = count
        count = hc.unanswered(root, hc.FAMILY_TABLE_FILE)
        if count:
            missing[hc.FAMILY_TABLE_FILE] = count
        missing.update(health_law.unanswered(root))     # 體檢的法規更新檢視（v1.6.0）
        import health_typo
        count = health_typo.unanswered(root)                # 體檢的錯漏字檢查（v1.7.0）：還沒讀完的份數
        if count:
            missing[health_typo.TABLE_FILE] = count
    for filename, _, _ in SPECS:
        for _, outdir_doc in books:
            path = locate(outdir_doc, filename)[0]
            if not os.path.isfile(path):
                continue
            try:
                _, rows = _read(path)
            except (OSError, UnicodeDecodeError, csv.Error, ValueError):
                continue
            count = sum(1 for r in rows if not _s(r.get(REUSED)) and not _s(r.get("AI判斷")))
            if count:
                missing[filename] = missing.get(filename, 0) + count
    return missing
