# -*- coding: utf-8 -*-
"""體檢的「法規更新檢視」（v1.6.0）：外部法規最近改了，現行內規哪幾段要跟著改。

法規追蹤（law_impact，v1.5.0）本來是另開一輪、自己一份檢視報告。v1.6.0 起「體檢」（檢查現有文件）
那一輪也順便做，零件全部借 law_impact，只是寄住在體檢的產出資料夾裡：

    體檢     抓法規異動、找候選段（law_impact.collect，embedded="體檢"；不寫 法規作業.json）
    審查打包 兩張 AI 表 AI法規適用.csv、AI法規影響.csv 跟體檢的其他表放同一個 2_Log檔案/AI審查/；
             先讀我.md、評分標準.md 由體檢合寫一份（ai_tables.merge 讀 readme_lines、render_all(law=True)）
    審查匯入 跟其他表一起驗，一張有錯整批不寫（validate）；過了才 law_impact.import_reviews
    報告     結果列進 體檢報告.xlsx 的「引用檢查報告」頁（report_rows），引用欄開頭寫【法規更新】

抓不到法規、來源失敗都照實寫進引用檢查報告：抓不到不等於沒有修法。
"""

import datetime
import io
import os
import re
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
for _path in (HERE, os.path.join(HERE, "regdiff")):
    if _path not in sys.path:
        sys.path.insert(0, _path)

import law_impact as li  # noqa: E402

EMBED = "體檢"
DEFAULT_DAYS = 180
TAG = "【法規更新】"
APPLY_FILE, IMPACT_FILE = li.APPLY_FILE, li.IMPACT_FILE
# 分數 → 引用檢查報告上的判定（跟外部引用同一套說法：要改內文、要人確認、沒問題）
_SHOWN = {"建議修改": "內文要改", "需再檢查": "需人工確認", "不用改": "沒問題"}


def load(root):
    """這一輪體檢的法規更新檢視狀態；沒做（舊版產出、加了 --不查法規、做失敗）回 None。"""
    path = li.state_path(root)
    if not os.path.isfile(path):
        return None
    try:
        state = li.read_state(root)
    except (li.ImpactError, OSError, ValueError, TypeError, AttributeError) as exc:
        from _common import warn_read_failure
        warn_read_failure(path, exc, "法規更新檢視的狀態檔讀不到，這一輪報告沒有法規更新那幾列", "法規更新檢視")
        return None
    return state if state.get("embedded") == EMBED else None


def period(since="", until="", today=None, days=None, workspace=""):
    """法規更新檢視的期間：沒給起日就從迄日往回推 days 天（設定.html「體檢法規天數」，留空 180）。"""
    from _common import tw_now, tw_today
    today = today or tw_today()
    until = until or today.isoformat()
    days = int(days or DEFAULT_DAYS)
    if not since:
        import law_memory as lm
        default = (datetime.date.fromisoformat(until) - datetime.timedelta(days=days)).isoformat()
        since = lm.first_unchecked_day(default, workspace) if workspace else default
    return since, until


def prepare(root, workspace, settings, since="", until="", mode="異動", scorer=None, days=None):
    """體檢初比對之後呼叫：抓法規異動、找候選段（還不打包）。回傳 state。
    scorer：體檢已經載好的語意模型（帶向量快取）；None＝這一輪不用語意，只用關鍵詞與直接引用。"""
    since, until = period(since, until, days=days, workspace=workspace)
    state, _cached = li.collect(workspace, root, settings, since, until, mode, embedded=EMBED, scorer=scorer)
    return state


def pack(root):
    """審查打包：寫兩張 AI 表與 LLM法規審查包_*.md（內容沒變的列答案帶回來）。沒做法規更新檢視回 None。"""
    state = load(root)
    if state is None:
        return None
    li.pack(root, state, li._load_cache(state["workspace"], state, root))
    return load(root)


LAST_CARRY = [""]        # v1.32.1：repack_if_needed 這一次是為了帶入別處判過的空白列：畫面要印的說明


def repack_if_needed(root):
    """v1.11.0 兩階段：AI 判好（或改了）適不適用，就重新打包，把適用的法規連候選段給 AI 判影響。
    回傳打包了幾份影響審查包（沒重新打包回 None）。"""
    state = load(root)
    if state is None or not state["events"] or not os.path.isfile(os.path.join(li.ai_dir(root), APPLY_FILE)):
        return None
    LAST_CARRY[0] = "" if li.needs_repack(root, state) else li.carry_reason(root, state)
    if not li.needs_repack(root, state) and not LAST_CARRY[0]:
        return None
    li.pack(root, state, li._load_cache(state["workspace"], state, root))
    state = load(root)
    return sum(1 for name in state.get("packs") or [] if name.startswith("LLM法規審查包_"))


def unanswered(root):
    """{表名: 還沒填的列數}，只列有缺的；判「不適用」的法規，它的候選列不用填。"""
    state = load(root)
    if state is None or not state["events"]:
        return {}
    if not os.path.isfile(os.path.join(li.ai_dir(root), APPLY_FILE)):
        return {}
    open_apply, open_impact = li.unanswered(root, state)
    return dict((name, n) for name, n in ((APPLY_FILE, open_apply), (IMPACT_FILE, open_impact)) if n)


def validate(root):
    """驗兩張表（不寫任何東西）。回傳錯誤 list；一條法規都沒抓到時沒有表可驗，回 []。"""
    state = load(root)
    if state is None:
        return []
    try:
        li.assert_fresh(state)
        li.assert_evidence(root, state)
    except li.ImpactError as exc:
        return ["法規更新檢視：%s：重新體檢（跑 體檢）" % exc]
    if not state["events"]:
        return []
    errors, _apply, _impact = li.validate(root, state)
    return ["法規更新檢視：" + e for e in errors]


def import_results(root):
    """驗過之後匯入；回傳 (錯誤 list, 統計 dict)。"""
    state = load(root)
    if state is None:
        return [], {}
    errors = li.import_reviews(root, state)
    if errors:
        return ["法規更新檢視：" + e for e in errors], {}
    state = load(root)
    counts = {}
    for row in (state.get("accepted") or {}).get("影響") or []:
        verdict = (row.get("AI判斷") or "").strip()
        if verdict:
            counts[verdict] = counts.get(verdict, 0) + 1
    counts["法規"] = len(state["events"])
    return [], counts


def pending(root):
    """法規更新檢視這一站還沒收：還沒匯入，或匯入之後 AI 又改了表。"""
    state = load(root)
    if state is None or not os.path.isfile(os.path.join(li.ai_dir(root), APPLY_FILE)):
        return False
    if state.get("phase") != "報告完成":
        return True
    return li.prints_changed(state, root)


def _coverage_problems(state):
    return [item for item in state.get("coverage") or [] if li.ls.coverage_problem(item)]


def summary_line(state):
    """批次摘要、畫面印的那一行。"""
    if state is None:
        return ""
    candidates = sum(len(v) for v in (state.get("candidates") or {}).values())
    problems = _coverage_problems(state)
    text = ("法規更新檢視（%s 至 %s）：程式抓到法規異動 %d 條、內規候選段 %d 段；審查打包時交給 AI 判"
            % (state["since"], state["until"], len(state["events"]), candidates))
    if problems:
        text += "；來源 %d 個沒抓完整（%s），AI 要上網補查" % (
            len(problems), "、".join("%s：%s" % (p.get("name"), p.get("status")) for p in problems))
    if not state["events"]:
        text += "；一條都沒抓到不代表沒有修法"
    return text


def readme_lines(root, ws_flag=""):
    """寫進 AI審查/先讀我.md 的一節。"""
    state = load(root)
    if state is None:
        return []
    open_counts = unanswered(root)
    apply_total = len(state["events"])
    impact_rows = li.read_ai_table(os.path.join(li.ai_dir(root), IMPACT_FILE)) or []
    profile = state["config"].get("profile") or {}
    supplement = li._cmd("法規補入", state["workspace"], '"<證據檔>"', '--outdir "%s"' % os.path.basename(os.path.normpath(root)))
    lines = ["", "## 法規更新檢視（外部法規最近改了，現行內規哪幾段要跟著改）", "",
             li.EFFECT_USAGE,
             "分兩階段：先讀 `LLM法規適用一覽_*.md`（沒有一覽表就讀 `LLM法規適用審查_*.md`），"
             "填 `%s`（每一條法規適不適用本行）；填完跑 `繼續`，"
             "程式只把判「適用」「待確認」的法規連候選段打包成 `LLM法規審查包_*.md`，再判 `%s`。"
             "判「不適用」的法規不用看候選段。" % (APPLY_FILE, IMPACT_FILE), "",
             "期間 %s 至 %s；程式抓到法規異動 %d 條。判法見 `評分標準.md` 的「法規更新檢視」一節。"
             % (state["since"], state["until"], apply_total)]
    import law_memory as lm
    lines += lm.unknown_readme_lines(state.get("books") or [], root)
    lines += [""] + li.rejudge_readme_lines(state)
    if state["events"]:
        lines += ["- `%s`：%d 列，要填 %d 列（每一條法規適不適用本行）"
                  % (APPLY_FILE, apply_total, open_counts.get(APPLY_FILE, 0)),
                  "- `%s`：%d 列，要填 %d 列（每一條法規 × 每一個候選段；判「不適用」或「重複」的法規，它的候選列可以不填）"
                  % (IMPACT_FILE, len(impact_rows), open_counts.get(IMPACT_FILE, 0))]
        packs = state.get("packs") or []
        if packs:
            lines.append("- 下一份讀：%s" % li.next_pack(packs, state.get(li.PACK_LEFT_KEY)))
            lines.append("- 要讀的審查包（同一個資料夾；括號是還沒判的列數，審查檔分配固定，判過的列留在原檔）："
                         + "、".join("`%s`" % p for p in li.pack_names(packs, state.get(li.PACK_LEFT_KEY))))
    else:
        lines.append("- 這一輪一條法規異動都沒抓到（來源狀態見下）：照內規引用與業務主題上網查官方來源，"
                     "查到的存成證據檔補進來；查不到也不能寫成沒有修法")
    problems = _coverage_problems(state)
    for item in problems:
        lines.append("- 來源「%s」%s：%s" % (item.get("name"), item.get("status"),
                                         _short_detail(item.get("detail") or "沒有說明")))
    if problems:
        # v1.11.0：讀不到的附件網址一個一個列在這裡（以前全部塞在先讀我.md 同一行，一行幾千字）
        full = os.path.join(li.law_dir(root), "來源狀態.txt")
        with io.open(full, "w", encoding="utf-8") as f:
            f.write("\n\n".join("來源「%s」%s：\n%s" % (p.get("name"), p.get("status"),
                                                   (p.get("detail") or "").replace("；", "\n"))
                                for p in problems) + "\n")
        lines.append("  （讀不到的附件、公告網址完整清單：`2_Log檔案/法規分析/來源狀態.txt`；要補查時再看）")
    lines += ["- 適用資料（匯入/%s 的 profile；空白＝待確認，不要自己假設機構類型）：%s"
              % (li.CONFIG, "；".join("%s：%s" % (k, "、".join(map(str, v)) if isinstance(v, list) else (v or "空白"))
                                     for k, v in profile.items()) or "（沒有）"),
              "- 程式抓到的只是一部分：照 `2_Log檔案/法規分析/外部引用索引.json`（內規引用了哪些法規）與追蹤主題"
              "（%s）到官方網站補查；讀到官方原文才引用。查到的存成證據檔（格式見 references/法規影響分析.md 第四節），"
              "在 skill 資料夾跑：" % "、".join(state["config"].get("themes") or []),
              "      " + supplement,
              "  補入後再跑 `繼續`：會重新打包（已判的答案依內容帶回），AI 把新列判完再匯入。",
              "- 結果會列在體檢報告的「引用檢查報告」頁（引用欄開頭是「%s」）。" % TAG]
    return lines


def render_rubric():
    """評分標準.md 的「法規更新檢視」一節（law_impact 的評分標準，拿掉它自己的大標）。"""
    import scoring_rubric as sr
    text = sr.render_law()
    lines = text.splitlines()
    if lines and lines[0].startswith("# "):
        lines = lines[1:]
    return "\n".join(lines).strip() + "\n"


def _short_detail(detail):
    """來源說明只留前面那幾句；讀不到的附件不一個一個列網址，只講幾個（以前一列五千多字）。"""
    head = re.split(r"[；;]?\s*附件 https?://", detail, maxsplit=1)[0].strip("；; ")
    if head and not head.endswith("。"):
        head += "。"
    attachments = len(re.findall(r"附件 https?://", detail))
    pdf = detail.count("需 pypdf")
    if attachments:
        head += "另有 %d 個附件讀不到%s。" % (attachments, "（其中 %d 個是 PDF，這台電腦沒裝 pypdf 讀不了）" % pdf if pdf else "")
    for extra in dict.fromkeys(re.findall(r"公告 https?://\S+?：HTTP Error \d+[^；。]*", detail)):
        if extra not in head:              # v1.25.0：沒有附件時前面那幾句已經含這一句，不再接一次
            head += extra + "。"
    return head


# 程式內部的法規編號（L1、L69–L78）：前面不能是英數字（「HTML69」不算）；中文字後面直接接 L 也要認得
_L_ID = r"(?<![A-Za-z0-9])L\d+(?:\s*[–\-~～至、]\s*L?\d+)*"


def _no_ids(text):
    """理由裡的程式內部編號（L69–L78）承辦看不懂：括號裡提到的整段拿掉，其餘換成「相關條文」。"""
    text = re.sub(r"[（(][^（）()]*" + _L_ID + r"[^（）()]*[)）]", "", text or "")
    return re.sub(_L_ID, "相關條文", text)


def _nearest_line(paragraphs, text, line):
    """law_impact 讀的段次與體檢報告段次總表的段次照理一樣；保險起見用文字對回去（找不到就照原段次）。"""
    if not text or not paragraphs:
        return line
    if 1 <= line <= len(paragraphs) and paragraphs[line - 1] == text:
        return line
    hits = [i + 1 for i, p in enumerate(paragraphs) if p == text]
    return min(hits, key=lambda n: abs(n - line)) if hits else line


def _citation(event):
    date = event.get("event_date") or "日期待補"
    status = event.get("status") or ""
    return "%s%s%s（%s 修正%s）" % (TAG, event["law_name"], event.get("article_no") or "", date,
                                 "，%s" % status if status and status != "現行" else "")


def report_rows(root, books=None):
    """引用檢查報告要加的列：[序號, AI判定, 判定理由, 規章, 段次, 原文, 引用, 建議處理, 查證來源]。
    books：{規章名: review_pack.load_book 的結果}（段次對回段次總表用）。"""
    state = load(root)
    if state is None:
        return []
    import human_report as hr
    import law_report as lr
    books = books or {}
    rows = []
    since, until = state["since"], state["until"]
    if not state["events"]:
        problems = _coverage_problems(state)
        rows.append(["", "需人工確認",
                     "這一輪（%s 至 %s）沒有抓到任何法規異動證據%s；不代表這段期間沒有修法。"
                     % (since, until, "（%s）" % "；".join("%s %s：%s" % (p.get("name"), p.get("status"), p.get("detail") or "")
                                                         for p in problems) if problems else ""),
                     "（全部）", "", "", "%s期間 %s 至 %s" % (TAG, since, until),
                     "請確認法規來源（匯入/%s）能連上，或由 AI 上網查官方來源、用「法規補入」補進來後重新匯入" % li.CONFIG, ""])
        return rows
    for item in _coverage_problems(state):
        if item.get("kind") in ("檔案", "資料庫") and state["events"]:
            continue        # AI 補入的證據檔：刻意只放查到的那幾部法規，不是「沒抓完整」（v1.7.7）
        rows.append(["", "需人工確認",
                     "法規來源「%s」%s：%s。這個來源沒抓完整，這段期間的修法可能有漏。"
                     % (item.get("name"), item.get("status"), _short_detail(item.get("detail") or "沒有說明").rstrip("。")),
                     "（全部）", "", "", "%s來源：%s" % (TAG, item.get("name")),
                     "請確認來源能連上，或由 AI 上網補查、用「法規補入」補進來", ""])
    apply_by, impact_rows = lr._answers(root, state)
    events = li._events_by_number(state)
    titles = li._book_by_title(state)
    # 已經補進逐條官方原文的法規，原本那一條公告摘要（效力待確認）不再列：同一件事逐條那幾列已經講了（v1.7.7）
    articles = [e for e in state["events"] if e.get("status") == "現行" and e.get("source_kind") in ("檔案", "資料庫")]
    superseded = set(state["numbers"][e["id"]] for e in state["events"]
                     if e.get("status") == "待確認" and any(a["law_name"] in e["law_name"] for a in articles))
    grouped = []
    for row in impact_rows:
        event = events.get(row.get("事件ID"))
        if not event or row.get("事件ID") in superseded:
            continue
        title = row.get("規章", "")
        line_text = str(row.get("段次", "") or "")
        book = titles.get(title)
        text, line = "", ""
        if book and line_text.isdigit() and 1 <= int(line_text) <= len(book["paragraphs"]):
            text = book["paragraphs"][int(line_text) - 1]
            shown = books.get(title) or {}
            line = str(_nearest_line(shown.get("new_paragraphs") or [], text, int(line_text)))
            display = shown.get("new_shown") or []
            if len(display) == len(shown.get("new_paragraphs") or []) and 1 <= int(line) <= len(display):
                text = display[int(line) - 1]          # 補回 Word 自動編號（v1.7.1）
        applicability = (apply_by.get(row["事件ID"]) or {}).get("AI判斷", "")
        verdict = (row.get("AI判斷") or "").strip()
        reason = row.get("AI理由", "")
        if verdict:
            shown_verdict = _SHOWN.get(verdict, verdict)
            action = lr._suggestion(row, event)
        elif applicability in li.SKIP_IMPACT:
            # v1.7.6：判不適用本行的法規不列（只是用字相同被配進來，寫「沒問題」會被讀成「查過、符合」）；
            # 改在最後加一列總結（見下面 not_applicable）
            continue
        else:
            shown_verdict = "無法判斷"
            reason = "AI 審查尚未完成：這一列還沒有 AI 判定。"
            action = "等 AI 審查"
        reason = hr._friendly_reason(reason) if reason else reason
        quote = (row.get("法規原文") or "").strip()
        if quote:
            reason = "%s\n法規原文：%s" % (reason, quote)
        if row.get("列ID") == li.NEW_ROW and not title:
            title, text = "（各本都沒寫）", "（內規沒有寫到這項義務；查證範圍：%s）" % (row.get("查證範圍") or "未寫")
        grouped.append((event, ["", shown_verdict, _no_ids(reason), title, line, text, _citation(event),
                                _no_ids(re.sub(r"\s{2,}", " ", action or "請確認後處理")), event.get("source_url") or ""]))
    # 同一段、同一部法規、判斷與改法都一樣的幾條（合作推廣規範第一點到第十點）合成一列（以前同一句寫十次）
    merged, index = [], {}
    for event, row in grouped:
        key = (row[3], row[4], event["law_name"], row[1], row[7])
        if key in index and row[4]:
            first = merged[index[key]]
            first[1].append(event)
            first[0][8] = "\n".join(dict.fromkeys(str(first[0][8]).splitlines() + [row[8]]))
            continue
        index[key] = len(merged)
        merged.append((row, [event]))
    for row, group in merged:
        if len(group) > 1:
            numbers = "、".join(e.get("article_no") or "" for e in group)
            row[6] = "%s%s%s（%s 修正）" % (TAG, group[0]["law_name"], numbers, group[0].get("event_date") or "日期待補")
            row[2] = "%s\n（%s 判斷與改法相同，只列一次）" % (row[2], numbers)
        rows.append(row)
    not_applicable = [e for e in state["events"]
                      if (apply_by.get(state["numbers"][e["id"]]) or {}).get("AI判斷") == "不適用"]
    if not_applicable:
        names = list(dict.fromkeys("%s%s" % (e["law_name"], e.get("article_no") or "") for e in not_applicable))
        rows.append(["", "沒問題",
                     # v1.23.1：不把程式內部的檔名（AI審查/AI法規適用.csv）寫給承辦看
                     "本期抓到 %d 條法規異動，其中 %d 條 AI 判不適用本行，沒有逐段比對：%s"
                     % (len(state["events"]), len(not_applicable),
                        "、".join("「%s」" % (n if len(n) <= 40 else n[:40] + "…") for n in names[:12])
                        + ("等 %d 條" % len(names) if len(names) > 12 else "")),
                     "（全部）", "", "", "%s不適用本行的 %d 條" % (TAG, len(not_applicable)), "不用改", ""])
    # 要人處理的在前（內文要改 → 需人工確認 → 還沒判），同一種照法規編號、段次
    order = {"內文要改": 0, "需人工確認": 1, "無法判斷": 2, "沒問題": 3}
    head = [r for r in rows if r[3] == "（全部）"]
    body = [r for r in rows if r[3] != "（全部）"]
    body.sort(key=lambda r: order.get(r[1], 9))
    return head + body
