# -*- coding: utf-8 -*-
"""
法規追蹤越做越準（v1.19.0）：存進 memoization/法規追蹤/ 的四樣東西。

    穩定代號      存起來的 AI 理由裡，事件ID（L12）、列ID（L1-14）、範圍（L26–L35）換成「法規名稱｜條號｜日期」代號，
                  帶回時再換成這一輪的編號（以前直接存 L9，下一輪的 L9 是別條法規，理由指錯）
    法規版本表    每部法規已知的最新修正日（這一輪抓到的、公告標題裡「修正「xx」」、AI 補查記下的），
                  拿來檢查手冊裡寫的版本是不是過時了——不限這一輪的查詢期間
    重複公告      AI 判過「重複」的（同一則公告的網頁版與附件 PDF）：下一輪同一則公告直接先填「重複」（逐條版不帶，v1.51.0）
    補查紀錄      AI 上網補查過的（查了什麼、哪天、結果）：最近查過的帶回 AI補查紀錄.csv，AI 不用從頭再查

這四樣都只放公開的法規資訊（法規名稱、日期、官方網址、補查結果）。
"""

import collections
import datetime
import os
import re
import urllib.parse

TOKEN_RE = re.compile(r"⟦([ER]):([^⟧]*)⟧")
SEP = "‖"
# L12、L1-14、L26–L35（範圍用 – ~ ～ 連）
_ID_RE = re.compile(r"(?<![A-Za-z0-9])L(\d+)(?:-(\d+))?(?:\s*[–~～]\s*L?(\d+))?(?![\d])")
VERSIONS = "法規版本表.json"
DUPLICATES = "重複公告.json"
SEARCHES = "補查紀錄.json"
PERIODS = "追蹤期間.json"     # 每個工作區法規追蹤查到哪一天（v1.58.0）：{工作區代號: {"迄日": YYYY-MM-DD}}
SEARCH_DAYS = 90            # 補查紀錄帶回幾天內的（跟「查證沿用天數」預設一樣）
_READ_FAILURES = set()      # 以完整路徑隔離不同工作區；讀成功才解除保護


def read_failed(name):
    return os.path.abspath(_path(name)) in _READ_FAILURES


def folder():
    import batch
    return os.path.join(batch.cache_dir(), "法規追蹤")


def _path(name):
    return os.path.join(folder(), name)


def _read(name, default):
    import law_impact as li
    path = _path(name)
    if not os.path.isfile(path):
        return default
    try:
        value = li.read_json(path)
        if not isinstance(value, type(default)):
            raise li.ImpactError("資料格式錯誤，預期 %s" % type(default).__name__)
    except li.ImpactError as exc:
        from _common import warn_read_failure
        _READ_FAILURES.add(os.path.abspath(path))
        warn_read_failure(path, exc, "記憶讀不出來，相關檢查未完成；本輪保留原檔、不更新此表", "法規記憶")
        return default
    _READ_FAILURES.discard(os.path.abspath(path))
    return value


def _write(name, value):
    import law_impact as li
    if read_failed(name):
        return
    os.makedirs(folder(), exist_ok=True)
    li.write_json(_path(name), value)


def norm_name(text):
    """法規名稱比對用：去空白、全半形括號統一、去引號。"""
    text = re.sub(r"\s+", "", text or "")
    text = text.replace("(", "（").replace(")", "）")
    return text.strip("「」『』\"'")


# ---------------------------------------------------------------------------
# 穩定代號
# ---------------------------------------------------------------------------

def event_key(event):
    return "%s｜%s｜%s" % (event.get("law_name", ""), event.get("article_no") or "", event.get("event_date") or "")


def _url_tag(event):
    import hashlib
    return "u" + hashlib.sha1((event.get("source_url") or event.get("id") or "").encode("utf-8")).hexdigest()[:8]


def _maps(state, impact_rows):
    import law_impact as li
    numbers = li.numbers_of(state)
    # v1.22.0：同一則公告的網頁版和附件 PDF「名稱｜條號｜日期」一模一樣，以前兩條共用一個代號，
    # 「L64 同 L63」存起來再換回來變成「同 L64」。撞名的那幾條代號後面加來源網址的短指紋
    base = collections.Counter(event_key(e) for e in state["events"])
    key_by_number = dict((numbers[e["id"]], event_key(e) + ("｜" + _url_tag(e) if base[event_key(e)] > 1 else ""))
                         for e in state["events"])
    number_by_key = dict((v, k) for k, v in key_by_number.items())
    # 沒帶網址的舊代號：只有對得到唯一一條才換；撞名的就不換（寫成法規名稱），不要隨便指給其中一條
    by_base = collections.defaultdict(list)
    for number, key in key_by_number.items():
        by_base["｜".join(key.split("｜")[:3])].append(number)
    number_by_key.update(dict((k, v[0]) for k, v in by_base.items() if len(v) == 1 and k not in number_by_key))
    row_key = {}
    row_by_key = {}
    for row in impact_rows or []:
        rid, number = row.get("列ID", ""), row.get("事件ID", "")
        if re.fullmatch(r"L\d+-\d+", rid) and number in key_by_number:
            key = SEP.join([key_by_number[number], row.get("規章", ""), str(row.get("段次", ""))])
            row_key[rid] = key
            row_by_key[key] = rid
    return key_by_number, number_by_key, row_key, row_by_key


class IdMaps(object):
    """同一輪同一批列的編號對照表（v1.59.1）：整張表換編號時共用一份，用到才建。
    以前每一格重建一次，體檢要建兩千多次。state 或列的編號變了要另外建一個，不能跨步驟留著。"""

    def __init__(self, state, impact_rows):
        self._source, self._value = (state, impact_rows), None

    def get(self):
        if self._value is None:
            self._value = _maps(*self._source)
        return self._value


def stabilize(text, state, impact_rows, maps=None):
    """理由裡這一輪的編號 → 穩定代號（對不到的照原樣留）。"""
    if not text or "L" not in text:
        return text
    key_by_number, _n, row_key, _r = maps.get() if maps else _maps(state, impact_rows)

    def swap(m):
        first, row, last = m.group(1), m.group(2), m.group(3)
        if row:
            key = row_key.get("L%s-%s" % (first, row))
            return "⟦R:%s⟧" % key if key else m.group(0)
        numbers = ["L%d" % n for n in range(int(first), int(last) + 1)] if last and int(last) > int(first) else ["L" + first]
        keys = [key_by_number[n] for n in numbers if n in key_by_number]
        if len(keys) != len(numbers):
            return m.group(0)
        return "⟦E:%s⟧" % SEP.join(keys)
    return _ID_RE.sub(swap, text)


def _render(numbers):
    numbers = sorted(set(numbers), key=lambda n: int(n[1:]))
    if len(numbers) >= 3 and int(numbers[-1][1:]) - int(numbers[0][1:]) == len(numbers) - 1:
        return "%s–%s" % (numbers[0], numbers[-1])
    return "、".join(numbers)


def restore(text, state, impact_rows, maps=None):
    """穩定代號 → 這一輪的編號；這一輪沒有的寫成「法規名稱 條號（日期）」。"""
    if not text or "⟦" not in text:
        return text
    _k, number_by_key, _rk, row_by_key = maps.get() if maps else _maps(state, impact_rows)

    def readable(key):
        name, article, day = (key.split("｜") + ["", "", ""])[:3]
        return "%s%s（%s）" % (name, (" " + article) if article else "", day or "日期不明")

    def swap(m):
        kind, body = m.group(1), m.group(2)
        if kind == "R":
            rid = row_by_key.get(body)
            if rid:
                return rid
            parts = body.split(SEP)
            return "%s %s段%s" % (readable(parts[0]), parts[1] if len(parts) > 1 else "", parts[2] if len(parts) > 2 else "")
        keys = body.split(SEP)
        found = [number_by_key[k] for k in keys if k in number_by_key]
        if len(found) == len(keys):
            return _render(found)
        return "、".join(number_by_key.get(k) or readable(k) for k in keys)
    return TOKEN_RE.sub(swap, text)


ANSWER_COLUMNS = ("AI理由", "建議改法", "查證範圍")


def stabilize_row(row, state, impact_rows, columns=ANSWER_COLUMNS, maps=None):
    return dict(row, **dict((c, stabilize(row.get(c, ""), state, impact_rows, maps)) for c in columns if row.get(c)))


def restore_row(row, state, impact_rows, columns=ANSWER_COLUMNS, maps=None):
    for column in columns:
        if row.get(column):
            row[column] = restore(row[column], state, impact_rows, maps)
    return row


# ---------------------------------------------------------------------------
# 法規版本表
# ---------------------------------------------------------------------------

_TITLE_RE = re.compile(r"(?:修正|訂定|增訂)「([^」]{4,60})」")


def versions():
    return _read(VERSIONS, {})


def _remember_version(table, name, day, source, basis):
    from _common import tw_now, tw_today
    if not name or not re.fullmatch(r"\d{4}-\d{2}-\d{2}", day or ""):
        return
    try:
        when = datetime.date.fromisoformat(day)
    except ValueError:
        return                                  # v1.23.0：不存在的日期（2026-02-30）不收
    if when > tw_today():
        return                                  # 還沒到的日期（打錯成 2062）不收：表只往新的日期更新，收了就永遠誤報
    key = norm_name(name)
    old = table.get(key)
    if old and old.get("最新修正日", "") > day:
        return
    if old and old.get("最新修正日", "") == day:
        import law_sources
        old_source = old.get("來源") or ""
        if not source or not source.strip() or source == old_source:
            return
        new_official = law_sources.official_source(source)
        old_official = law_sources.official_source(old_source)
        both_ai = (basis or "").startswith("AI 補查") and (old.get("依據") or "").startswith("AI 補查")
        if not ((new_official and not old_official) or (both_ai and new_official == old_official)):
            return
    table[key] = {"法規名稱": name, "最新修正日": day, "來源": source or "", "依據": basis,
                  "記錄日": tw_today().isoformat()}


def update_versions(state, search_rows=()):
    """這一輪抓到的法規異動、公告標題、AI 補查紀錄 → 法規版本表（只會往新的日期更新）。回傳表。"""
    table = versions()
    for event in state["events"]:
        if event.get("status") == "草案":
            continue
        day = event.get("event_date") or ""
        name = event.get("law_name", "")
        if event.get("article_no"):
            _remember_version(table, name, day, event.get("source_url"), "法規異動（%s）" % event.get("article_no"))
        for found in _TITLE_RE.findall(name):
            _remember_version(table, found, day, event.get("source_url"), "公告標題")
    for row in search_rows or ():
        name = (row.get("法規名稱") or "").strip()
        day = (row.get("最新修正日") or "").strip()
        url = (row.get("來源網址") or "").strip()
        if url and urllib.parse.urlsplit(url).path in ("", "/"):
            continue                            # 來源只寫網站首頁（例：https://law.moj.gov.tw/）不算依據，不寫進版本表
        if name and day:
            for one in re.split(r"[、,，;；]", name):
                _remember_version(table, one.strip(), day, row.get("來源網址", ""), "AI 補查（%s）" % (row.get("查詢日期") or ""))
    _write(VERSIONS, table)
    return table


def remember_external_versions(rows, items):
    """只記已匯入、來源為官方網址且明確寫出最新修正日的外部引用。"""
    import law_sources
    table = versions()
    before = dict(table)
    by_id = {item.get("引用ID"): item for item in items}
    pattern = r"最新修正日(?:期)?\s*(?:為|是|[:：])\s*(?:民國)?\s*(\d{2,4})\s*[.．/年-]\s*(\d{1,2})\s*[.．/月-]\s*(\d{1,2})"
    for row in rows:
        url = (row.get("查證來源") or "").strip()
        match = re.search(pattern, row.get("AI理由") or "")
        if not match or not law_sources.official_source(url):
            continue
        year, month, day = map(int, match.groups())
        year = year + 1911 if year < 1912 else year
        item = by_id.get(row.get("引用ID")) or {}
        name = ((row.get("AI更正") or "").strip() if any(label in (row.get("AI理由") or "") for label in ("〔名稱錯誤〕", "〔本文名稱錯誤〕")) else "") or item.get("名稱") or ""
        _remember_version(table, name, "%04d-%02d-%02d" % (year, month, day), url, "AI 外部引用查證")
    if table != before:
        _write(VERSIONS, table)
    return table


def attached_versions(output, books):
    """讀取本輪外部引用清單第零節，回傳附有最新日期的法規名稱。"""
    result = []
    from _common import book_dir, locate
    for book in books:
        name = book.get("title") or os.path.splitext(book.get("name") or "")[0]
        if not name:
            continue
        path = locate(book_dir(output, name), "LLM外部引用清單.md")[0]
        try:
            with open(path, encoding="utf-8-sig") as source:
                text = source.read()
        except (OSError, UnicodeError):
            continue
        section = text.partition("# 零、程式先抓好的官方原文")[2].split("## 要自己上網查的", 1)[0]
        for block in re.split(r"(?m)^## ", section)[1:]:
            if re.search(r"(?m)^最新修正日期：\s*(?:民國)?\d", block):
                result.append(block.splitlines()[0].split(" ", 1)[0].strip())
    return result


_ROC_DATE_RE = re.compile(r"[（(]\s*(?:民國)?\s*(\d{2,4})\s*[.．/年]\s*(\d{1,2})\s*[.．/月]\s*(\d{1,2})\s*日?")
# 名稱和日期之間夾的條號（「保險代理人管理規則第33條之1(113.07.22修正)」）
_TRAILING_ARTICLE_RE = re.compile(r"(?:第[0-9０-９一二三四五六七八九十百千]+條(?:之[0-9０-９一二三四五六七八九十]+)?"
                                  r"(?:第[0-9０-９一二三四五六七八九十]+[項款目])*)+$")
# 名稱前面可以接的字：不是漢字（句首、標點、數字），或「依」「及」這類連接詞——
# 「金融消費者保護法」不能當成「消費者保護法」（以前只看字尾）
_NAME_LEFT_OK = set("依及與和暨並或之「『《〈（(、，,；;：:　 ")


def _name_hit(prefix, name):
    if not prefix.endswith(name):
        return False
    before = prefix[-len(name) - 1] if len(prefix) > len(name) else ""
    return not before or before in _NAME_LEFT_OK or not ("一" <= before <= "鿿")


def version_lag(paragraphs, table=None):
    """手冊裡「法規名稱(113.07.22…修正)」寫的版本比版本表舊的：
    paragraphs＝[(規章, 段次, 全文)]。回傳 [{規章, 段次, 全文, 法規名稱, 手冊寫的版本, 已知最新版, 來源, 依據}]。"""
    table = versions() if table is None else table
    if not table:
        return []
    names = sorted(table.values(), key=lambda v: -len(norm_name(v["法規名稱"])))
    found = []
    for title, line, text in paragraphs:
        for m in _ROC_DATE_RE.finditer(text or ""):
            year, month, day = int(m.group(1)), int(m.group(2)), int(m.group(3))
            if not (1 <= month <= 12 and 1 <= day <= 31):
                continue
            cited = "%04d-%02d-%02d" % (year if year > 1911 else year + 1911, month, day)
            prefix = _TRAILING_ARTICLE_RE.sub("", norm_name(text[:m.start()]))
            hit = next((v for v in names if _name_hit(prefix, norm_name(v["法規名稱"]))), None)
            if hit and cited < hit["最新修正日"]:
                found.append({"規章": title, "段次": str(line), "全文": text, "法規名稱": hit["法規名稱"],
                              "手冊寫的版本": cited, "已知最新版": hit["最新修正日"], "來源": hit.get("來源", ""),
                              "依據": hit.get("依據", "")})
    return found


_VERSION_SAID_RE = re.compile(r"版[本次][^。；\n]{0,12}(?:過時|非最新|不是最新|較舊|已修正)|最新版")


def version_said(text, latest):
    """理由或改法已經講到版本過時，或已經寫了最新版的日期（「改成…(115.09.30…修正)」「最新修正日為114.11.11」）。"""
    numbers = re.findall(r"\d+", latest or "")
    dates = []
    if len(numbers) == 3:
        year, month, day = map(int, numbers)
        dates = [r"(?<!\d)%d\s*[./\-年]\s*0?%d\s*[./\-月]\s*0?%d(?!\d)" % (y, month, day)
                 for y in (year, year - 1911)]
    for clause in re.split(r"[，,。；;\n]", text or ""):
        if re.search(r"尚未|還未|未能|未確認|不確定|無法|不能|尚待|待確認|是否|未知", clause) or re.search(
                r"(?:尚未|並未|沒有|未|不曾|不)(?:曾經|曾|已經|已)?(?:過時|較舊|修正)", clause):
            continue
        if _VERSION_SAID_RE.search(clause) or any(re.search(pattern, clause) for pattern in dates):
            return True
    return False


def lag_note(hit):
    """審查包裡講版本過時的那一句（v1.60.18）。以前只在出報告時併進引用頁，AI 判的時候看不到，
    同一段比對判沒問題、引用頁卻寫內文要改；法規影響也只給 4 分。"""
    return ("**程式查到版本過時**：本段寫的「%s」是 %s 的版本，法規版本表記的最新是 %s 修正（依據：%s）"
            % (hit["法規名稱"], hit["手冊寫的版本"], hit["已知最新版"], hit.get("依據") or "版本表"))


def version_unknown(paragraphs, table=None, searches=None):
    """列出手冊引用版本但尚無已知最新版、近期也沒補查的法規。"""
    import unicodedata
    table = versions() if table is None else table
    searches = recent_searches() if searches is None else searches
    normalize = lambda value: norm_name(unicodedata.normalize("NFKC", value or ""))
    names = [normalize(v.get("法規名稱", "")) for v in table.values() if v.get("法規名稱")]
    searched = {normalize(row.get("法規名稱", "")) for row in searches}
    found, seen = [], set()
    for title, line, text in paragraphs:
        for match in _ROC_DATE_RE.finditer(text or ""):
            try:
                year = int(match.group(1))
                cited = datetime.date(year if year > 1911 else year + 1911, int(match.group(2)), int(match.group(3))).isoformat()
            except ValueError:
                continue
            prefix = _TRAILING_ARTICLE_RE.sub("", norm_name(text[:match.start()]))
            if any(_name_hit(normalize(prefix), name) for name in names):
                continue
            extracted = re.search(r"[\u3400-\u9fffA-Za-z0-9Ａ-Ｚａ-ｚ０-９（）]+$", prefix)
            if not extracted:
                continue
            name = extracted.group().lstrip("依及")
            # 「本公司應遵循保險法(…)」：動詞前面是句子，不是法規名稱
            name = re.split(r"應遵循|遵循|遵守|依據|依照|參照|按照|根據|符合", name)[-1].lstrip("依及")
            key = normalize(name)
            if len(key) < 4 or key in seen or key in searched:
                continue
            seen.add(key)
            found.append({"法規名稱": name, "手冊寫的版本": cited, "規章": title, "段次": str(line)})
    return found


def unknown_readme_lines(books, output=None):
    """先讀我共用的待補查清單。"""
    paragraphs = ((book["title"], i, text) for book in books
                  for i, text in enumerate(book.get("paragraphs", []), 1))
    table = dict(versions())
    for name in attached_versions(output, books) if output else ():
        table[norm_name(name)] = {"法規名稱": name}
    unknown = version_unknown(paragraphs, table=table)
    if not unknown:
        return []
    lines = ["", "## 手冊有寫版本、但還不知道最新版的法規（%d 部）" % len(unknown), "",
             "逐一到官方或公會網站查最新修正日，查到的（含期間外的）寫進 AI補查紀錄.csv 的「法規名稱」「最新修正日」；查不到也記一列寫查不到。"]
    lines += ["- %(法規名稱)s（手冊寫 %(手冊寫的版本)s，%(規章)s 段%(段次)s）" % row for row in unknown[:40]]
    if len(unknown) > 40:
        lines.append("另有 %d 部" % (len(unknown) - 40))
    return lines


# ---------------------------------------------------------------------------
# 重複公告
# ---------------------------------------------------------------------------

def _content_key(event):
    return SEP.join([event.get("law_name", ""), event.get("article_no") or "", event.get("event_date") or "",
                     event.get("source_url") or ""])


def save_duplicates(state, apply_rows, impact_rows):
    """AI 判「重複」的：記下它跟哪幾條重複（用穩定代號，不受編號影響）。"""
    from _common import tw_now, tw_today
    from _common import generated_content_equal, write_generated
    import law_impact as li
    table = _read(DUPLICATES, {})
    events = li._events_by_number(state)
    maps = IdMaps(state, impact_rows)
    for row in apply_rows:
        event = events.get(row.get("事件ID"))
        if not event:
            continue
        key = _content_key(event)
        if (row.get("AI判斷") or "").strip() == "重複":
            value = {"理由": stabilize(row.get("AI理由", ""), state, impact_rows, maps),
                     "記錄日": tw_today().isoformat()}
            if not generated_content_equal(table.get(key), value, ("記錄日",)):
                table[key] = value
        else:
            table.pop(key, None)        # 改判了：不再當重複
    if not read_failed(DUPLICATES):
        write_generated(_path(DUPLICATES), table)


def prefill_duplicates(state, apply_rows, impact_rows):
    """還沒判的法規，上一次判過重複、指到的法規這一輪也在：先填「重複」。回傳填了幾條。
    v1.51.0：逐條版（有條號）各自判適用，以前記的「重複」不帶。"""
    import law_impact as li
    table = _read(DUPLICATES, {})
    if not table:
        return 0
    events = li._events_by_number(state)
    maps = IdMaps(state, impact_rows)
    count = 0
    for row in apply_rows:
        if (row.get("AI判斷") or "").strip() or (row.get("條號") or "").strip():
            continue
        saved = table.get(_content_key(events.get(row.get("事件ID")) or {}))
        if not saved:
            continue
        reason = restore(saved.get("理由", ""), state, impact_rows, maps)
        if "⟦" in reason or not re.search(r"(?<![A-Za-z0-9])L\d+", reason):
            continue                    # 指到的法規這一輪沒有：讓 AI 重判
        row["AI判斷"] = "重複"
        row["AI理由"] = "%s（沿用 %s 判過的同一則公告）" % (reason, saved.get("記錄日", ""))
        count += 1
    return count


# ---------------------------------------------------------------------------
# 補查紀錄
# ---------------------------------------------------------------------------

SEARCH_COLUMNS = ["查了什麼", "法規名稱", "最新修正日", "來源網址", "查詢日期", "結果", "處理"]


def save_searches(rows):
    """AI補查紀錄.csv 的列存起來（同一個「查了什麼」留最新的）。回傳存了幾筆。"""
    table = dict((r.get("查了什麼"), r) for r in _read(SEARCHES, []) if r.get("查了什麼"))
    count = 0
    for row in rows:
        what = (row.get("查了什麼") or "").strip()
        if not what or "（沿用" in (row.get("結果") or ""):
            continue
        old = table.get(what)
        if old and (old.get("查詢日期") or "") > (row.get("查詢日期") or ""):
            continue
        table[what] = dict((c, (row.get(c) or "").strip()) for c in SEARCH_COLUMNS)
        count += 1
    _write(SEARCHES, sorted(table.values(), key=lambda r: r.get("查詢日期", ""), reverse=True))
    return count


def _workspace_key(root):
    import law_impact as li
    return os.path.basename(os.path.dirname(li.cache_path(root)))


def _period_end(table, key):
    """這個工作區查到哪一天；沒紀錄、內容壞掉回 ""（手改壞的不能讓整輪出錯）。"""
    entry = table.get(key)
    until = entry.get("迄日", "") if isinstance(entry, dict) else ""
    return until if isinstance(until, str) and re.fullmatch(r"\d{4}-\d{2}-\d{2}", until) else ""


def _next_day(day):
    return (datetime.date.fromisoformat(day) + datetime.timedelta(days=1)).isoformat()


def _period_was_read(state):
    """這一輪真的把期間讀過了才算數：有公告清單、不是靠快照，主要清單（金管會、全國法規新訊；設定裡沒有就看全部）
    都沒失敗，而且讀到起日或讀到網站的最後一頁。讀到最後一頁還沒到起日，是網站沒有更舊的（那一輪的來源狀態會寫缺口），
    不算：不然上次太久以前的工作區，起日早於清單能回溯的範圍，就永遠不前進。
    中途壞掉、頁數用完的不能記成查過，不然缺口反而被藏起來。公會失敗只記在來源狀態，不擋期間。"""
    coverage = state.get("coverage") or []
    lists = [item for item in coverage if item.get("kind") == "公告清單"]
    if not lists or any(item.get("kind") == "快照" for item in coverage):
        return False
    return not any(item.get("status") == "失敗" or not item.get("listed_from")
                   or (item["listed_from"] > state.get("since", "") and not item.get("read_to_end"))
                   for item in [i for i in lists if i.get("core")] or lists)


def save_period(state):
    """這一輪判完了：記下這個工作區查到哪一天，只往後。盤點查的是全部現行法規，不算追到哪一天；
    跟上次中間有空檔的（使用者只查 10 月）也不算，不然空檔會被蓋掉。"""
    since, until = state.get("since", ""), state.get("until", "")
    if state.get("mode") != "異動" or not re.fullmatch(r"\d{4}-\d{2}-\d{2}", until or "") or not _period_was_read(state):
        return
    table = _read(PERIODS, {})
    key = _workspace_key(state.get("workspace", ""))
    known = _period_end(table, key)
    if known and (known >= until or since > _next_day(known)):
        return
    _write(PERIODS, dict(table, **{key: {"迄日": until}}))


def first_unchecked_day(default, root):
    """預設起日（往回 180 天）和這個工作區上一輪迄日之間有空檔時，從空檔開始（v1.58.0）。
    半年跑一次：5/5 跑完、11/6 再跑，往回 180 天是 5/10，中間 5/6 那幾天兩輪都沒查到。"""
    until = _period_end(_read(PERIODS, {}), _workspace_key(root))
    if not until:
        return default
    following = _next_day(until)
    if following >= default:
        return default
    import law_impact as li
    li.say("[法規期間] 上一輪查到 %s：起日從 %s 開始，不留空檔" % (until, following))
    return following


def recent_searches(days=SEARCH_DAYS, today=None):
    """最近 days 天內查過的（帶回 AI補查紀錄.csv，結果後面註明沿用）。"""
    from _common import tw_now, tw_today
    today = today or tw_today()
    rows = []
    for row in _read(SEARCHES, []):
        try:
            when = datetime.date.fromisoformat((row.get("查詢日期") or "")[:10])
        except ValueError:
            continue
        if (today - when).days <= days:
            rows.append(dict(row, 結果="%s（沿用 %s 的查詢：只代表查到那天為止，之後的要補查）"
                                       % (row.get("結果", ""), row.get("查詢日期", ""))))
    return rows


# ---------------------------------------------------------------------------
# 同一部法規以前怎麼判適用（v1.20.0）：memoization/內部知識/法規適用經驗.json
# ---------------------------------------------------------------------------

APPLY_HISTORY = "法規適用經驗.json"
APPLY_HISTORY_KEEP = 6            # 每部法規留最近幾次


def _history_path():
    import precedents as pc
    return os.path.join(pc.folder(), APPLY_HISTORY)


def _plain_tokens(text):
    """⟦E:名稱｜條號｜日期⟧ 這種穩定代號換成看得懂的字（給 AI 參考用，不必對回編號）。"""
    def one(key):
        parts = (key.split("｜") + ["", "", ""])[:3]
        return "%s%s（%s）" % (parts[0], parts[1], parts[2] or "日期不明")

    def show(match):
        kind, body = match.group(1), match.group(2)
        if kind == "E":
            return "、".join(one(k) for k in body.split(SEP))
        parts = body.split(SEP)
        return "%s %s段%s" % (one(parts[0]), parts[1] if len(parts) > 1 else "", parts[2] if len(parts) > 2 else "")
    return TOKEN_RE.sub(show, text or "")


def readable_ids(text, state, impact_rows, maps=None):
    """理由、問題裡這一輪的 L12、L1-14 換成「法規名稱 條號（日期）」（v1.23.0）：要長期存的文字
    （補查紀錄、單位事實的問題）不能留編號，下一輪編號重排就指錯法規。"""
    return _plain_tokens(stabilize(text, state, impact_rows, maps))


def save_apply_history(apply_rows):
    """匯入過的適用判斷照法規名稱存（同一條修正只記一次）。apply_rows 是穩定代號版的列。"""
    from _common import tw_now, tw_today
    import law_impact as li
    path = _history_path()
    try:
        table = li.read_json(path) if os.path.isfile(path) else {}
    except li.ImpactError:
        table = {}
    table = table if isinstance(table, dict) else {}
    from _common import generated_content_equal, write_generated
    today = tw_today().isoformat()
    for row in apply_rows:
        verdict = (row.get("AI判斷") or "").strip()
        name = norm_name(row.get("法規名稱"))
        if not name or not verdict or verdict == "重複":
            continue
        previous = next((e for e in table.get(name, []) if e.get("事件指紋") == row.get("事件指紋")), None)
        entries = [e for e in table.get(name, []) if e.get("事件指紋") != row.get("事件指紋")]
        value = {"事件指紋": row.get("事件指紋", ""), "條號": row.get("條號", ""),
                 "公布或修正日": row.get("公布或修正日", ""), "判斷": verdict,
                 "理由": _plain_tokens(row.get("AI理由"))[:160], "記錄日": today}
        entries.append(previous if generated_content_equal(previous, value, ("記錄日",)) else value)
        table[name] = entries[-APPLY_HISTORY_KEEP:]
    os.makedirs(os.path.dirname(path), exist_ok=True)
    write_generated(path, table)


def apply_hint(law_name, fingerprint=""):
    """適用審查包的一行：這部法規以前判過幾次、怎麼判。沒有紀錄回 ""。"""
    import law_impact as li
    if os.environ.get("REG_NO_ANSWER_BANK") == "1":      # 測試用：舊測試共用快取資料夾，審查包不能多出這一行
        return ""
    path = _history_path()
    try:
        table = li.read_json(path) if os.path.isfile(path) else {}
    except li.ImpactError:
        return ""
    entries = [e for e in (table or {}).get(norm_name(law_name), []) if e.get("事件指紋") != fingerprint]
    if not entries:
        return ""
    counts = {}
    for e in entries:
        counts[e["判斷"]] = counts.get(e["判斷"], 0) + 1
    last = entries[-1]
    return ("- 本單位以前判過這部法規 %d 次（%s）；最近一次（%s %s）判「%s」：%s。只當參考，照這一條的內容判"
            % (len(entries), "、".join("%s %d" % kv for kv in sorted(counts.items())), last.get("公布或修正日", ""),
               last.get("條號", ""), last["判斷"], last.get("理由", "") or "（沒寫理由）"))
