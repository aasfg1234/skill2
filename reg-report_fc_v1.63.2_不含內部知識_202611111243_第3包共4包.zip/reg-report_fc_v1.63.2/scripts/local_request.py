"""使用者在本機執行的請求與開發用程式包。"""
import codecs
import json
import os
os.environ.setdefault("TQDM_DISABLE", "1")
os.environ.setdefault("HF_HUB_DISABLE_PROGRESS_BARS", "1")
os.environ.setdefault("TRANSFORMERS_VERBOSITY", "error")
from pathlib import Path, PureWindowsPath
import subprocess
import sys
import zipfile
import datetime
import time
import uuid
import contextlib
import io

import workspace_transfer as transfer
from file_replace import rename_file

COMMANDS = frozenset((
    "原始資料夾", "找工作區", "查表", "看條文", "看報告", "核對原始", "排除檔案", "exclude-file",
    "執行方式", "run-mode", "建工作區", "init-workspace", "配對", "開始", "繼續", "continue", "重新比對", "重跑開始",
    "語意併入", "batch-semantic", "審查打包", "batch-review-pack", "審查匯入", "batch-review-import", "填表", "fill-answers",
    "體檢", "檢查現有文件", "health-check", "法規設定", "law-config", "法規追蹤", "law-impact", "追蹤法規",
    "法規補入", "law-supplement", "法規效力", "法規審查匯入", "law-review-import", "法規繼續", "law-continue", "法規報告", "law-report",
    "法規更動", "law-changed", "重查法規", "收回饋", "回饋寫完了", "回饋", "feedback", "記準則", "準則", "save-rules", "單位建議", "單位資料建議", "unit-profile", "記事實", "單位事實", "save-fact",
    "資料庫", "整理資料庫", "rule-library", "打包分享", "分享", "share", "打開設定", "設定頁", "open-settings", "看設定", "設定清單", "show-settings", "改設定", "set-setting",
    "查法條", "讀官方頁", "fetch-law", "檢查帶齊", "check-files", "打包工作區", "pack-workspace", "解開工作區", "unpack-workspace", "核對工作區", "verify-workspace", "打包程式", "build-program-zip"))

NO_WAREHOUSE = frozenset(("打包工作區", "pack-workspace", "解開工作區", "unpack-workspace", "核對工作區", "verify-workspace"))

# 各類參數只在所屬指令放行；p 是工作區路徑、t 是搬移位置、v 是普通值。
_RULES = {}
def _rules(names, flags=(), values=None, positional=()):
    for name in names.split():
        _RULES[name] = (set(flags), dict(values or {}), positional)

_ws = {"--workspace": "w", "--工作區": "w"}
_settings = ("--設定已確認", "--settings-ok")
_batch = {"--semantic-dir": "p", "--threshold": "v", "--top": "v", "--changed-top": "v", "--sentence-threshold": "v"}
_dates = {"--since": "v", "--起日": "v", "--until": "v", "--迄日": "v", "--mode": "v", "--模式": "v"}
_rules("執行方式 run-mode 打包程式 build-program-zip")
_rules("原始資料夾", values={**_ws, "--現行": "o", "--修訂": "o"})      # v1.51.0：o＝原始資料夾（見 _origin_path）
_rules("找工作區", values={**_ws, "--原始": "v"})
_rules("查表", ("--空白", "--統計", "--全部", "--全文"), {**_ws, "--事件": "v", "--規章": "v", "--段次": "v", "--欄": "v", "--列": "v", "--上限": "v", "--起": "v"}, ("v?",))
_rules("看報告", ("--有意見", "--全部", "--全文", "--核對"), {**_ws, "--檔": "v", "--流程": "v", "--頁": "v", "--找": "v", "--段次": "v", "--判定": "v", "--欄": "v", "--上限": "v"})
_rules("核對原始", ("--帶入",), _ws)
_rules("排除檔案 exclude-file", ("--取消", "--cancel", "--列出", "--list"), _ws, ("names",))      # 只記檔名、不動檔案
_rules("看條文", ("--待判",), _ws, ("v?",))
_rules("打開設定 設定頁 open-settings", ("--不開瀏覽器", "--no-browser"))
_rules("看設定 設定清單 show-settings", ("--全部", "--all"), {"--找": "v", "--find": "v", "--頁": "v", "--page": "v"})
_rules("改設定 set-setting", positional=("names",))      # 名稱=值；路徑類 settings_view 會擋
_rules("打包分享 分享 share", values={"--內部知識": "v", "--internal": "v"})
_rules("配對 收回饋 回饋寫完了 回饋 feedback 資料庫 整理資料庫 rule-library", values=_ws)
_rules("法規設定 law-config", ("--清外框記憶",), _ws)
_rules("檢查帶齊 check-files", ("--檢查規章清單", "--check-manifest"), _ws)
_rules("單位建議 單位資料建議 unit-profile", ("--重做", "--redo"), _ws)
_rules("記事實 單位事實 save-fact", values=_ws, positional=("v", "v"))
_retry = ("--重試語意", "--retry-semantic")
_rules("繼續 continue 重新比對 重跑開始", _settings + _retry + ("--到報告", "--report-only", "--不核對原始"), _ws)
_rules("開始", _settings + _retry + ("--詳細", "--verbose", "--不核對原始"), {**_ws, **_batch})
_rules("體檢 檢查現有文件 health-check", _settings + _retry + ("--詳細", "--verbose", "--不查法規", "--skip-law", "--只比對文字", "--text-only", "--不核對原始"), {**_ws, **_batch, **_dates})
_rules("法規追蹤 law-impact 追蹤法規", _settings, {**_ws, **_dates})
_rules("法規審查匯入 law-review-import 法規繼續 law-continue 法規報告 law-report", values={**_ws, "--outdir": "p"})
_rules("法規補入 law-supplement", values={**_ws, "--outdir": "p"}, positional=("p",))
_rules("法規效力", values={**_ws, "--outdir": "p", "--施行日": "v", "--來源": "v"}, positional=("v", "v"))
_rules("法規更動 law-changed 重查法規", ("--全部", "--all"), _ws, ("names",))
_rules("審查打包 batch-review-pack", ("--略過", "--skip"), {**_ws, "--per-file": "v", "--max-chars": "v"}, ("p?",))
_rules("審查匯入 batch-review-import", values=_ws, positional=("p?",))
_rules("填表 fill-answers", ("--接著匯入", "--只檢查"), {**_ws, "--輪": "v"}, ("p+",))      # v1.50.0：答案檔可以好幾個
_rules("記準則 準則 save-rules", ("--列出", "--list"), _ws, ("p?",))
_rules("語意併入 batch-semantic", ("--略過", "--skip"), {**_ws, "--dir": "p"}, ("p?",))
_rules("建工作區 init-workspace", values={**_ws, "--已有": "name", "--現行": "o", "--修訂": "o"})
_rules("查法條 讀官方頁 fetch-law", values={**_ws, "--輸出": "p", "--最多字": "v"}, positional=("urls",))
_rules("打包工作區 pack-workspace", ("--只要產出", "--只要清單", "--連同累積資料", "--連同程式"), {**_ws, "--輸出": "t", "--上次清單": "t", "--以我為準": "r"})
_rules("解開工作區 unpack-workspace", ("--套用刪除",), {**_ws, "--到": "p"}, ("t",))
_rules("核對工作區 verify-workspace", values={**_ws, "--清單": "t"}, positional=("t",))
_rules("semantic_candidates", ("--檢查", "--check", "--rerank"), {**_ws, "--交換包": "p", "--exchange": "p", "--folder": "p", "--model": "s", "--rerank-model": "s", "--cache": "p", "--threshold": "v", "--top": "v", "--rerank-threshold": "v", "--recall-top": "v"}, ("p?", "p?"))


# 這兩個選項會用封包覆寫程式、累積資料，封包可能是 AI 做的：不收請求，只能使用者自己在命令列打。
# argparse 收前綴縮寫，所以照前綴認，才會給同一句清楚的拒絕。
_COMMAND_LINE_ONLY = ("套用程式", "套用累積資料")


def _command_line_only(name, option):
    head = option.lstrip('-')
    return bool(head) and name in ("解開工作區", "unpack-workspace") and any(flag.startswith(head) for flag in _COMMAND_LINE_ONLY)


def _local_path(value, base):
    if not value or any(c in value for c in '\x00\r\n'):
        raise ValueError("路徑不能空白或包含換行")
    win = PureWindowsPath(value)
    if value.replace('/', '\\').startswith('\\\\') or (win.drive and not win.is_absolute()):
        raise ValueError("不能使用網路、裝置或磁碟相對路徑：" + value)
    if '..' in value.replace('\\', '/').split('/'):
        raise ValueError("路徑不能包含 ..：" + value)
    path = Path(value)
    path = path if path.is_absolute() else base / path
    path = Path(os.path.abspath(path))
    for part in (path, *path.parents):
        try:
            stat = part.lstat()
        except FileNotFoundError:
            continue
        if part.is_symlink() or getattr(stat, 'st_file_attributes', 0) & 0x400:
            raise ValueError("路徑不能經過連結或重解析點：" + str(part))
    if os.name == 'nt':
        import ctypes
        if not path.drive or ctypes.windll.kernel32.GetDriveTypeW(path.drive + '\\') not in (2, 3):
            raise ValueError("只能使用本機磁碟路徑：" + value)
    return path.resolve()


def _inside(path, root):
    return path == root or root in path.parents


def check_workspace_outside_skill(root, skill):
    """檔案參數、倉庫操作都只限制在工作區內；工作區包住程式資料夾，等於程式也寫得到。本機請求的每一條路共用這一道。"""
    root, skill = Path(os.path.abspath(root)).resolve(), Path(os.path.abspath(skill)).resolve()
    if _inside(skill, root):
        raise ValueError("工作區不能包住程式資料夾：" + str(root))


def _check_pack_output(path, skill):
    """打包工作區 --輸出 可以放工作區上一層，程式資料夾常常就在那裡。蓋掉 run_all.py 的 ZIP，
    python 照樣會執行裡面的 __main__.py，所以程式資料夾、累積資料都不能當輸出位置。"""
    if _inside(path, skill):
        raise ValueError("打包的輸出位置不能在程式資料夾內：%s。工作區放在程式資料夾底下（舊式 skill\\工作區）時，"
                         "把 --輸出 省略就好，封包會放在預設位置" % path)
    if _inside(path, Path(os.path.abspath(transfer._memo_dir())).resolve()):
        raise ValueError("打包的輸出位置不能在累積資料資料夾內：" + str(path))


def _origin_path(value, root, skill):
    """v1.51.0：建工作區／原始資料夾的 --現行、--修訂。內容會複製進工作區、進倉庫送 AI，不能是任意資料夾：
    只准「工作區的上一層」或「設定頁工作區根目錄」底下（相對路徑從工作區算，常見 ../新手測試/現行）。回傳實際路徑。"""
    from _common import load_config, skill_path
    if not value or any(c in value for c in '\x00\r\n'):
        raise ValueError("原始資料夾不能空白或包含換行")
    win = PureWindowsPath(value)
    if value.replace('/', '\\').startswith('\\\\') or (win.drive and not win.is_absolute()):
        raise ValueError("原始資料夾不能使用網路、裝置或磁碟相對路徑：" + value)
    if win.is_absolute() and '..' in value.replace('\\', '/').split('/'):
        raise ValueError("原始資料夾的完整路徑不能包含 ..：" + value)
    path = _local_path(os.path.normpath(os.path.join(str(root), value)), root)
    boundaries = [root.parent]
    configured = (load_config(str(skill / '設定.html')).get('設定') or {}).get('工作區根目錄', '')
    if configured:
        try:
            boundaries.append(_local_path(skill_path(configured), skill))
        except (ValueError, TypeError, OSError):
            pass
    # 工作區直接放在磁碟根目錄時，上一層就是整顆磁碟，不算範圍
    boundaries = [b for b in boundaries if b.parent != b]
    if (path.drive.lower() != root.drive.lower()
            or not any(path != boundary and _inside(path, boundary) for boundary in boundaries)):
        raise ValueError("原始資料夾要放在工作區的上一層或設定頁的工作區根目錄底下：" + str(path))
    return path


# 這些副檔名載入時會執行內容（pickle）或本身就是程式；工作區是 AI 寫得到的地方，模型只收 safetensors
_UNSAFE_MODEL_SUFFIXES = ('.bin', '.pt', '.pth', '.pkl', '.pickle', '.ckpt', '.joblib', '.npy', '.npz', '.py', '.pyc')


def _check_workspace_model(path):
    """工作區裡的模型：不能有可執行內容、要有 safetensors 權重。還不存在時不擋（載入時才會失敗，沒有東西會被執行）。"""
    if not path.exists():
        return
    if not path.is_dir():
        raise ValueError("工作區裡的模型要是資料夾：" + str(path))
    names = [item for item in path.rglob('*') if item.is_file()]
    bad = [item.name for item in names if item.suffix.lower() in _UNSAFE_MODEL_SUFFIXES]
    if bad:
        raise ValueError("工作區裡的模型不能有 %s（載入時可能執行裡面的程式），只收 safetensors：%s" % ('、'.join(sorted(set(bad))[:5]), path))
    if not any(item.suffix.lower() == '.safetensors' for item in names):
        raise ValueError("工作區裡的模型要有 safetensors 權重檔：" + str(path))
    for item in names:
        if item.name == 'modules.json':
            # sentence_transformers 照這個檔的 type 匯入類別：只准它自己的模組
            try:
                modules = json.loads(item.read_text(encoding='utf-8-sig'))
                custom = [m.get('type') for m in modules if not str(m.get('type', '')).startswith('sentence_transformers.')]
            except (ValueError, AttributeError, TypeError, OSError):
                raise ValueError("工作區裡的模型 modules.json 看不懂：" + str(item)) from None
            if custom:
                raise ValueError("工作區裡的模型不能載入自訂模組：" + str(item))


def validate_model_path(value, skill, workspaces):
    """模型只能來自程式資料夾、Hugging Face 快取、程式自己會找的 models 資料夾或設定頁指定的位置；
    工作區（AI 寫得到）裡的只收 safetensors（v1.51.0；.bin 是 pickle，載入就會執行內容）。"""
    from _common import from_record, load_config
    skill = _local_path(str(skill), Path.cwd())
    path = _local_path(value, skill)
    # 請求單資料夾也在 skill 裡，AI 寫得到
    if _inside(path, skill / '_請求'):
        raise ValueError("模型路徑不能在請求資料夾內：" + str(path))
    roots = [_local_path(str(root), skill) for root in workspaces]
    if any(_inside(path, root) for root in roots):
        _check_workspace_model(path)
        return path
    allowed = [skill]
    # 沒設定模型路徑時程式自己找的那幾個位置（semantic_candidates.find_local_model）也要准，
    # 不然下載到 Hugging Face 快取的模型每次都被擋
    home = Path(os.path.expanduser('~'))
    auto = [skill.parent / 'models', home / 'models', home / '.cache' / 'huggingface' / 'hub']
    if os.environ.get('HF_HOME'):
        auto.append(Path(os.environ['HF_HOME']) / 'hub')
    for root in auto:
        try:
            allowed.append(_local_path(str(root), skill))
        except (ValueError, TypeError, OSError):
            continue
    settings_file = skill / '設定.html'
    if settings_file.is_file():
        _local_path(str(settings_file), skill)
        settings = load_config(str(settings_file)).get('設定') or {}
        for key in ('語意模型路徑', '重排序模型路徑'):
            configured = settings.get(key, '')
            if configured:
                try:
                    allowed.append(_local_path(from_record(str(skill), configured), skill))
                except (ValueError, TypeError):
                    continue
    if not any(_inside(path, root) for root in allowed):
        raise ValueError("模型路徑不在 skill、Hugging Face 快取或設定頁指定的模型資料夾內：" + str(path))
    return path


def _reject_workspace_links(root):
    """連預設讀取的檔案也不能透過工作區內的連結離開工作區。"""
    def failed(exc):
        raise ValueError("無法檢查工作區路徑：%s" % exc)
    def private(name):
        name = name.lower()
        return (name.startswith(('.env', 'sinopac', 'shioaji')) or '.secret' in name
                or ('keys' in name and name.endswith('.json')) or name.endswith(('.pem', '.key'))
                or name == 'auth.json')
    for folder, dirs, files in os.walk(root, followlinks=False, onerror=failed):
        dirs[:] = [name for name in dirs if not private(name)]
        for name in dirs + [name for name in files if not private(name)]:
            path = Path(folder) / name
            try:
                info = path.lstat()
            except OSError as exc:
                raise ValueError("無法檢查工作區路徑：%s" % exc) from None
            if path.is_symlink() or getattr(info, 'st_file_attributes', 0) & 0x400:
                raise ValueError("工作區含連結或重解析點：" + str(path))


def validate_parameters(name, params, skill, relay_workspace=None, relay_root=None):
    """驗證不可信的請求；回傳固定工作區與可直接執行的參數。"""
    import workspace
    flags, values, positional = _RULES[name]
    tokens = []
    workspace_value = None
    positions = 0
    i = 0
    while i < len(params):
        arg = params[i]
        if arg.startswith('-'):
            key, sep, value = arg.partition('=')
            if key in flags:
                if sep:
                    raise ValueError("這個選項不需要值：" + key)
                tokens.append((key, None, None))
            elif key in values:
                if not sep:
                    i += 1
                    if i >= len(params) or params[i].startswith('--'):
                        raise ValueError("選項缺少值：" + key)
                    value = params[i]
                kind = values[key]
                if kind == 'w':
                    if workspace_value is not None:
                        raise ValueError("工作區只能指定一次")
                    workspace_value = value
                else:
                    tokens.append((key, kind, value))
                    if kind == 'r':
                        while i + 1 < len(params) and not params[i + 1].startswith('-'):
                            i += 1
                            tokens.append((None, 'r', params[i]))
            elif _command_line_only(name, key):
                raise ValueError("本機請求不接受 %s：這個選項會用封包覆寫程式或累積資料，封包可能是 AI 做的。"
                                 "本機請求解開時只套用工作區的檔；要套用的話，請使用者確認封包來源後自己開命令列打（見 references/隔離環境.md）" % key)
            else:
                raise ValueError("這個指令不允許選項：" + key)
        else:
            # 最後一個位置參數是 names／urls，或結尾帶 +（例如 p+：一個以上的路徑，v1.50.0 填表多檔），可以重複
            if not positional or (positions >= len(positional) and positional[-1] not in ('names', 'urls') and not positional[-1].endswith('+')):
                raise ValueError("這個指令不允許多餘參數：" + arg)
            kind = positional[min(positions, len(positional)-1)].rstrip('?+')
            positions += 1
            tokens.append((None, kind, arg))
        i += 1
    required = sum(1 for p in positional if not p.endswith('?') and p not in ('names',))
    if positions < required:
        raise ValueError("指令缺少必要參數")
    skill = _local_path(str(skill), Path.cwd())
    _reject_workspace_links(skill)
    needs_workspace = name not in ('執行方式', 'run-mode', '打開設定', '設定頁', 'open-settings', '看設定', '設定清單', 'show-settings', '改設定', 'set-setting', '打包程式', 'build-program-zip', '打包分享', '分享', 'share') or workspace_value is not None or relay_workspace is not None
    if relay_workspace is not None:
        if name == '找工作區':
            raise ValueError('找工作區請使用不帶倉庫的本機請求，才能搜尋實際工作區')
        root = _local_path(str(relay_workspace), skill)
        if workspace_value and _local_path(workspace_value, skill) != root:
            raise ValueError("工作區與倉庫所在的工作區不同")
    elif workspace_value:
        root = _local_path(workspace_value, skill)
    elif needs_workspace:
        from _common import load_config
        settings = load_config(str(skill / '設定.html')).get('設定') or {}
        root = _local_path(workspace.resolve_root('', settings), skill)
    else:
        root = skill
    if name in ('打包分享', '分享', 'share'):
        share_dir = _local_path(str(skill.parent / '分享'), skill)
        if share_dir.is_dir():
            _reject_workspace_links(share_dir)
    if name in ('打包程式', 'build-program-zip'):
        _local_path(str(skill / '隔離區' / 'reg-report程式.zip'), skill)
    if name in ('打開設定', '設定頁', 'open-settings', '打包分享', '分享', 'share'):
        _local_path(str(skill / '設定.html'), skill)
    if needs_workspace:
        _local_path(str(root / workspace.LAYOUT_FILE), root)
        if name == '找工作區':
            if not root.parent.is_dir():
                raise ValueError('找不到工作區上一層資料夾：' + str(root.parent))
            if root.exists() and not root.is_dir():
                raise ValueError('工作區路徑不是資料夾：' + str(root))
        elif not workspace.is_workspace(str(root)):
            raise ValueError("指定的資料夾不是工作區，找不到工作區標記檔：" + str(root))
        else:
            check_workspace_outside_skill(root, skill)
        if name != '找工作區' and relay_workspace is None and Path(workspace.newest_workspace(str(root))).resolve() != root:
            raise ValueError("工作區名稱會指向另一個工作區，請指定實際的工作區資料夾：" + str(root))
        if name in ('建工作區', 'init-workspace') and workspace.workspace_base(str(root)) == str(root):
            raise ValueError("本機請求只能補建已存在的日期序號工作區；建立新工作區請使用隔離區")
        if root.is_dir():
            _reject_workspace_links(root)
    result = []
    for key, kind, value in tokens:
        if kind in ('p', 's', 't', 'r'):
            base = skill if kind == 's' else root
            if relay_root is not None and kind == 'p' and not Path(value).is_absolute():
                parts = value.replace('\\', '/').split('/')
                if '..' not in parts and root.name in parts[:-1]:
                    value = '/'.join(parts[len(parts) - 1 - parts[::-1].index(root.name) + 1:])
            path = validate_model_path(value, skill, (root,)) if kind == 's' else _local_path(value, base)
            boundary = skill if kind == 's' else root.parent if kind == 't' else root
            if (kind != 's' and not _inside(path, boundary)) or (kind == 't' and path.drive.lower() != root.drive.lower()):
                raise ValueError("路徑不在允許的資料夾內：" + str(path))
            if kind == 't' and key == '--輸出':
                _check_pack_output(path, skill)
            if relay_root is not None and (kind == 'p' or (kind == 's' and _inside(path, root))):
                path = relay_root / path.relative_to(root)
                _local_path(str(path), relay_root)
            value = path.relative_to(root).as_posix() if kind == 'r' else str(path)
        elif kind == 'o':
            # 通過檢查後照原字串往下傳：相對路徑要照舊記在工作區標記裡
            _origin_path(value, root, skill)
        elif kind == 'name' and (Path(value).name != value or any(c in value for c in '\\/:')):
            raise ValueError("已有工作區只能填資料夾名稱")
        elif kind == 'urls' and not value.startswith(('https://', 'http://')):
            raise ValueError("查法條只能填網址")
        if key is not None:
            result.append(key)
        if value is not None:
            result.append(value)
    return root, result


def python_advice(problem):
    """這個 Python 為什麼不能跑、要怎麼處理（缺套件不是用錯 Python，不要叫人換）。"""
    if "docx" in str(problem):
        return ("這台電腦的 Python 缺 python-docx（%s）：Word 修正對照表、標註版全文要用它，所以這一步沒有開始。"
                "安裝：在命令提示字元打 python -m pip install python-docx；不能連外見 references/環境與套件.md。"
                "裝好再雙擊一次就好，AI 交辦的工作還留著。目前用的 Python：%s" % (problem, sys.executable))
    return ("用錯 Python（%s；%s），請用一般版 python（CMD 打 python --version 確認不是 3.13t）；"
            "請執行 python -B scripts\\run_all.py 執行請求" % (sys.executable, problem))


def python_problem():
    if hasattr(sys, "_is_gil_enabled") and not sys._is_gil_enabled():
        return "自由執行緒版"
    try:
        import docx  # noqa: F401
    except Exception as exc:
        return "docx 載不起（%s）" % exc
    return ""


def _printable(text, limit):
    """AI 寫的字印到使用者視窗前：換行、控制字元、零寬字元都換成空白，再截長度（免得偽造別的行、把畫面推走）。"""
    return ''.join(c if c.isprintable() else ' ' for c in str(text))[:limit]


# 視窗上給承辦看的動作名稱（v1.51.0 改白話）
_LABELS = {'看設定': '看設定', '設定清單': '看設定', 'show-settings': '看設定', '改設定': '改設定', 'set-setting': '改設定',
           'semantic_candidates': '找意思相近的段落（會比較久）', 'continue': '繼續', '看報告': '看報告', '核對原始': '核對原始資料夾', 'open-settings': '打開設定',
           'run-mode': '查看執行方式', 'build-program-zip': '打包程式', 'init-workspace': '建工作區',
           'batch-semantic': '把相近段落併進比對結果', '語意併入': '把相近段落併進比對結果',
           'batch-review-pack': '整理給 AI 審查的資料', '審查打包': '整理給 AI 審查的資料',
           'batch-review-import': '把 AI 審查結果做成報告', '審查匯入': '把 AI 審查結果做成報告',
           'fill-answers': 'AI 填寫判斷', '填表': 'AI 填寫判斷', 'health-check': '體檢', 'law-config': '法規設定', 'law-impact': '法規追蹤',
           'law-supplement': '法規補入', 'law-review-import': '把 AI 法規審查結果收進來', '法規審查匯入': '把 AI 法規審查結果收進來', 'law-continue': '法規繼續',
           'law-report': '法規報告', 'law-changed': '法規更動', 'feedback': '收回饋', 'unit-profile': '單位建議',
           'rule-library': '整理法規資料庫', '整理資料庫': '整理法規資料庫', '資料庫': '整理法規資料庫', 'share': '打包分享', 'fetch-law': '查法條', 'check-files': '檢查帶齊',
           'pack-workspace': '把資料夾打包', '打包工作區': '把資料夾打包', 'unpack-workspace': '解開打包的資料夾', '解開工作區': '解開打包的資料夾',
           'verify-workspace': '檢查資料夾內容有沒有被改', '核對工作區': '檢查資料夾內容有沒有被改'}


def _wait_note(data):
    """按 Enter 之後大約要等多久（v1.56.0；數字來自 7 本手冊實測，只講大概）。語意另有 SEMANTIC_NOTE。"""
    name = _request_name(data) or ''
    if name == 'semantic_candidates':
        return ''
    if name in ('體檢', '檢查現有文件', 'health-check'):
        return '大約要等：幾分鐘到半小時（第一次算語意比對比較久，視窗會顯示進度與剩餘時間）。\n'
    if name in ('法規追蹤', '追蹤法規', 'law-impact'):
        return '大約要等：10～30 分鐘（要連官方網站、找候選段）。\n'
    if name in ('開始', '繼續', 'continue', '重新比對', '重跑開始', '收回本機', '準備'):
        return '大約要等：幾分鐘，規章本數多會更久。\n'
    return '大約要等：通常一兩分鐘。\n'


def _request_name(data):
    """這張請求實際會做的事。「操作」只有帶倉庫時才算數：畫面要跟真正執行的一樣，AI 寫得出請求單。"""
    operation = data.get('操作') if '倉庫' in data else None
    return operation or data.get('指令') or data.get('程式')


def _request_label(data):
    name = _request_name(data) or '未指定'
    name = _printable(name, 200)
    return name, _LABELS.get(name, name)


def _action_name(path):
    """請求單的動作名稱（視窗不印 json 檔名）；讀不出來回通稱。"""
    try:
        data = json.loads(path.read_text(encoding='utf-8-sig'))
        return _request_label(data)[1][:80] if isinstance(data, dict) else '上一個動作'
    except (OSError, ValueError):
        return '上一個動作'


def _option_values(params, options):
    """參數裡這些選項的值：[(選項, 值)]；`--x 值`、`--x=值` 兩種寫法都算。"""
    found = []
    if isinstance(params, list):
        for i, arg in enumerate(params):
            if not isinstance(arg, str):
                continue
            if arg in options and i + 1 < len(params) and isinstance(params[i + 1], str):
                found.append((arg, params[i + 1]))
            elif arg.startswith(tuple(option + '=' for option in options)):
                found.append(tuple(arg.split('=', 1)))
    return found


def _setting_preview(params, skill):
    """改設定：按 Enter 前要看到改什麼。AI 寫得出請求單，不能只看 AI 在對話裡怎麼說。"""
    try:
        import settings_view
        lines = settings_view.change_lines(settings_view.plan_changes(list(params), str(skill / '設定.html')))
        width = 700                 # 值最多 500 字，改前改後都要看得完
    except Exception:           # 內容不對的照原樣列，執行時會被擋
        lines = ['- %s' % _printable(str(item), 300) for item in (params if isinstance(params, list) else [params])]
        width = 400
    return '要改的設定：\n%s\n' % '\n'.join(_printable(line, width) for line in lines)


def describe_request(data, skill):
    """顯示請求的動作和工作區，不執行請求內容。"""
    name, description = _request_label(data)
    folder = ''
    if isinstance(data.get('倉庫'), str):
        folder = str(Path(data['倉庫']).parent.parent)
    else:
        params = data.get('參數', [])
        if isinstance(params, list):
            for i, arg in enumerate(params):
                if not isinstance(arg, str):
                    continue
                if arg in ('--workspace', '--工作區') and i + 1 < len(params):
                    folder = str(params[i + 1])
                    break
                if arg.startswith(('--workspace=', '--工作區=')):
                    folder = arg.split('=', 1)[1]
                    break
        if not folder and name not in ('執行方式', 'run-mode', '打開設定', '設定頁', 'open-settings', '看設定', '設定清單', 'show-settings', '改設定', 'set-setting', '打包程式', 'build-program-zip', '打包分享', '分享', 'share'):
            try:
                import workspace
                from _common import load_config
                settings = load_config(str(skill / '設定.html')).get('設定') or {}
                folder = workspace.resolve_root('', settings)
            except (OSError, ValueError, TypeError, AttributeError):
                folder = '依設定決定（尚未確認）'
    if folder and folder != '依設定決定（尚未確認）':
        try:
            folder = str(_local_path(folder, skill))
        except (OSError, ValueError, TypeError):
            pass
    folder = _printable(folder, 1000)
    # v1.50.2：建工作區 --現行／--修訂 會把那個資料夾的檔複製進工作區，按 Enter 前要看得到是哪裡
    params = data.get('參數', [])
    shown = ['%s=%s' % (key[2:], _printable(value, 300)) for key, value in _option_values(params, ('--現行', '--修訂'))]
    extra = ('要複製進工作區的原始資料夾：%s\n' % '；'.join(shown)) if shown else ''
    # v1.51.0：模型載入時會讀裡面的檔，一樣要在按 Enter 前看得到
    models = [_printable(value, 300) for _key, value in _option_values(params, ('--model', '--rerank-model'))]
    if models:
        extra += '模型位置：%s\n' % '；'.join(models)
    if name in ('改設定', 'set-setting'):
        extra += _setting_preview(params, skill)
    return '這次要做：%s\n內規資料夾：%s\n%s' % (description, folder or '這個動作不用內規資料夾', extra)


def _running_tests():
    if os.environ.get('PYTEST_CURRENT_TEST'):
        return True
    frame = sys._getframe()
    while frame is not None:
        if frame.f_globals.get('__name__', '').startswith(('unittest.', '_pytest.', 'pytest.')):
            return True
        frame = frame.f_back
    return False


def build_program(args=None, settings=None):
    root = transfer._program_dir()
    names = json.loads((root / "scripts/程式清單.json").read_text(encoding="utf-8"))
    if not isinstance(names, list) or any(not isinstance(n, str) or not transfer._safe(n) for n in names):
        raise ValueError("程式清單格式不正確")
    names = sorted(n for n in set(names) if n != "設定.html" and n.split('/')[0] not in
                   ("memoization", "models", "_請求", "隔離區"))
    output = root / "隔離區" / "reg-report程式.zip"
    output.parent.mkdir(parents=True, exist_ok=True)
    from _common import stable_zip_info
    with zipfile.ZipFile(output, "w") as archive:
        for name in names:
            path = root / name
            if not path.is_file() or path.is_symlink():
                raise ValueError("程式檔不存在或為連結：" + name)
            archive.writestr(stable_zip_info(name), path.read_bytes())
    print("程式包：" + str(output))
    return 0


class _ResultStream:
    """把覆蓋同一行的畫面收斂成最後內容，支援跨區塊的 CRLF。"""
    def __init__(self, out):
        self.out = out
        self.line = []
        self.pending_cr = False

    def write(self, text):
        for char in text:
            if self.pending_cr:
                if char == '\n':
                    self.out.write(''.join(self.line) + '\r\n')
                    self.line.clear()
                    self.pending_cr = False
                    continue
                self.line.clear()
                self.pending_cr = False
            if char == '\r':
                self.pending_cr = True
            elif char == '\n':
                self.out.write(''.join(self.line) + '\n')
                self.line.clear()
            else:
                self.line.append(char)
        self.out.flush()

    def finish(self, newline=False):
        if self.line:
            # 後面還要接狀態行時補一個換行，不然最後一行沒換行的輸出會跟「執行時間：…」黏在一起
            self.out.write(''.join(self.line) + ('\n' if newline else ''))
        self.line.clear()
        self.pending_cr = False
        self.out.flush()


@contextlib.contextmanager
def _progress_environment(enabled):
    previous = os.environ.get('REG_PROGRESS_BAR')
    if enabled:
        os.environ['REG_PROGRESS_BAR'] = '1'
    else:
        os.environ.pop('REG_PROGRESS_BAR', None)
    try:
        yield
    finally:
        if previous is None:
            os.environ.pop('REG_PROGRESS_BAR', None)
        else:
            os.environ['REG_PROGRESS_BAR'] = previous


# 請求單寫好超過這麼久還沒做，雙擊時先提醒：多半是之前取消或忘了做的，不是 AI 剛剛請你雙擊的那張
STALE_HOURS = 6
ABORT_HINT = "程式無法開始，請把下面這行貼給 AI：\n"
NOTHING_TO_DO = "現在沒有 AI 交辦的工作；請先回對話請 AI 安排下一步。"
SEMANTIC_NOTE = "正在準備語意比對，視窗一陣子沒有變化也還在跑，請不要關掉。（第一次算比較久，之後會出現進度條與剩餘時間）\n"


def _retire(request, prefix):
    """請求單做完或作廢後改名，名字撞到就加時間和亂數。"""
    target = request.with_name(prefix + request.name)
    if target.exists():
        target = request.with_name(prefix + request.stem + "_" + datetime.datetime.now().strftime("%Y%m%d_%H%M%S_%f") + "_" + uuid.uuid4().hex[:8] + request.suffix)
    rename_file(request, target)
    return target


RUNNING = "執行中_"


def _finish_request(request, original_name):
    """跑完（成功或失敗）改名成 已完成_<原名>；執行中被別的視窗當成中斷收走了就算了。"""
    if not request.exists():
        return None
    _pid_path(request).unlink(missing_ok=True)
    target = request.with_name("已完成_" + original_name)
    if target.exists():
        stem, suffix = os.path.splitext(original_name)
        target = request.with_name("已完成_" + stem + "_" + datetime.datetime.now().strftime("%Y%m%d_%H%M%S_%f") + "_" + uuid.uuid4().hex[:8] + suffix)
    rename_file(request, target)
    return target


def _pid_path(request):
    return request.with_name(request.name + ".pid")


def _process_info(pid):
    """這個 pid 的 (啟動時間, 程式檔名小寫)；Windows 以外或查不到的欄位回 None。"""
    if os.name != "nt":
        return None, None
    import ctypes
    from ctypes import wintypes
    kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
    kernel32.OpenProcess.restype = wintypes.HANDLE
    kernel32.OpenProcess.argtypes = (wintypes.DWORD, wintypes.BOOL, wintypes.DWORD)
    kernel32.GetProcessTimes.argtypes = (wintypes.HANDLE,) + (ctypes.POINTER(wintypes.FILETIME),) * 4
    kernel32.QueryFullProcessImageNameW.argtypes = (wintypes.HANDLE, wintypes.DWORD, wintypes.LPWSTR, ctypes.POINTER(wintypes.DWORD))
    kernel32.CloseHandle.argtypes = (wintypes.HANDLE,)
    try:
        handle = kernel32.OpenProcess(0x1000, False, int(pid))      # PROCESS_QUERY_LIMITED_INFORMATION
    except (OverflowError, ctypes.ArgumentError, ValueError):
        return None, None
    if not handle:
        return None, None
    try:
        start = image = None
        created, exited, kernel, user = (wintypes.FILETIME() for _ in range(4))
        if kernel32.GetProcessTimes(handle, ctypes.byref(created), ctypes.byref(exited), ctypes.byref(kernel), ctypes.byref(user)):
            start = (created.dwHighDateTime << 32) | created.dwLowDateTime
        size = wintypes.DWORD(32768)
        buffer = ctypes.create_unicode_buffer(size.value)
        if kernel32.QueryFullProcessImageNameW(handle, 0, buffer, ctypes.byref(size)):
            image = os.path.basename(buffer.value).lower()
        return start, image
    finally:
        kernel32.CloseHandle(handle)


def _write_pid(request):
    """v1.50.2：改名「執行中」時順便記下是哪個程式在跑；別的視窗看到還在跑就知道不是中斷。
    v1.51.0：連程式啟動時間一起記（pid 會被別的程式重用）；取不到就只寫 pid。"""
    start = _process_info(os.getpid())[0]
    try:
        _pid_path(request).write_text("%d %d" % (os.getpid(), start) if start else str(os.getpid()), encoding="utf-8")
    except OSError:
        pass


def _still_running(path):
    """v1.51.0：pid 活著還不夠。.pid 檔 AI 寫得到，填別的程式的 pid 就能讓本機永遠「另一個視窗還在跑」，
    所以那個 pid 要是 python、有記啟動時間時還要一樣。"""
    try:
        parts = _pid_path(path).read_text(encoding="utf-8").split()
        pid = int(parts[0])
        recorded = int(parts[1]) if len(parts) > 1 else None
    except (OSError, ValueError, IndexError):
        return False
    # 檔案內容不可信：填超大的數字時 OpenProcess 會丟例外，整個視窗當掉
    if not 0 < pid <= 0xFFFFFFFF or not transfer._pid_alive(pid):
        return False
    if os.name != "nt":
        return True
    start, image = _process_info(pid)
    if not image or not image.startswith("python"):
        return False
    return recorded is None or start == recorded


def _running_requests(folder):
    """還在別的視窗跑的請求單（原名）。"""
    return [p.name[len(RUNNING):] for p in sorted(folder.glob(RUNNING + "請求_*.json")) if p.is_file() and _still_running(p)]


def _collect_interrupted(folder):
    """v1.49.0：上次按了 Enter、還沒跑完視窗就被關掉的請求單（還叫 執行中_…）改名 已中斷_，不要再自動重做。
    v1.50.2：還在別的視窗跑的（pid 活著）不算中斷——使用者等不及多雙擊一次，以前會把正在跑的那張判成中斷、誘導 AI 重做。"""
    names = []
    for path in sorted(folder.glob(RUNNING + "請求_*.json")):
        if not path.is_file() or _still_running(path):
            continue
        _pid_path(path).unlink(missing_ok=True)
        original = path.name[len(RUNNING):]
        target = path.with_name("已中斷_" + original)
        if target.exists():
            stem, suffix = os.path.splitext(original)
            target = path.with_name("已中斷_" + stem + "_" + uuid.uuid4().hex[:8] + suffix)
        rename_file(path, target)
        names.append(original)
    return names


def _age_text(seconds):
    hours = seconds / 3600.0
    if hours < 48:
        return "%d 小時前" % int(hours)
    return "%d 天前" % int(hours // 24)


def run(args=None, settings=None):
    root = transfer._program_dir()
    folder = root / "_請求"
    import semantic_memory
    semantic_memory.sync()               # 打開設定以外，雙擊捷徑也算「這台重新看一次」
    try:
        _reject_workspace_links(_local_path(str(root), root))
        _local_path(str(folder), root)
    except ValueError as exc:
        print("%s[中止] %s" % (ABORT_HINT, exc))
        return 1
    if not folder.is_dir():
        print(NOTHING_TO_DO)
        return 0
    running = _running_requests(folder)
    if running:
        print("另一個視窗還在跑（%s），請等它說『做完了』再回對話，不要再雙擊。"
              % "、".join(_action_name(folder / (RUNNING + name)) for name in running))
        return 0
    # 先記下動作名稱：下一行會把請求單改名 已中斷_
    actions = {p.name[len(RUNNING):]: _action_name(p) for p in folder.glob(RUNNING + "請求_*.json") if p.is_file()}
    interrupted = _collect_interrupted(folder)
    interrupted_note = ("上一次執行（%s）做到一半視窗被關掉了，沒有完成，也不會自動重做。"
                        "請回對話跟 AI 說『上次被關掉了』，AI 會重新安排那一步。\n"
                        % "、".join(actions.get(name, "上一個動作") for name in interrupted) if interrupted else "")
    requests = sorted((p for p in folder.glob("請求_*.json") if p.is_file()), key=lambda p: (p.stat().st_mtime_ns, p.name))
    if not requests:
        print(interrupted_note + NOTHING_TO_DO)
        return 0
    request = requests[-1]
    original_name = request.name
    older = requests[:-1]
    age = time.time() - request.stat().st_mtime
    result = folder / (request.name + ".結果.txt")
    try:
        _local_path(str(request), root)
        _local_path(str(result), root)
    except ValueError as exc:
        print("%s[中止] %s" % (ABORT_HINT, exc))
        return 1
    rc = 1
    started = False
    console = sys.stdout
    with result.open("w+", encoding="utf-8", newline="\n") as out:
        result_stream = _ResultStream(out)
        def emit(s):
            console.write(s)
            console.flush()
            result_stream.write(s)
        def finish(code):
            # 最後一行 `[結束碼] N` 的格式不能改：AI 和程式靠它判斷；白話那行放它前面
            status = "\n（給 AI 看的代號：結束碼 %d）\n[結束碼] %d\n" % (code, code)
            if code == 3:
                # v1.49.0：3＝這一步做完了、倉庫也存了，只是倉庫太大，隔離區不能再用；以前跟失敗講同一句
                message = ("做完了，結果已存好。另外：累積的資料已經太多，以後每一步都要在這台電腦雙擊執行（AI 會告訴你怎麼切換）。"
                           "請關掉這個視窗，回到 AI 對話說『好了』。\n")
            else:
                # v1.56.0：結果檔 AI 自己讀得到，不用叫人貼
                message = (("做完了。按任意鍵關掉這個視窗，回到 AI 對話說『好了』。" if code == 0 else
                            "沒有做完。不用貼任何東西：回到 AI 對話說『出錯了』，AI 會自己去看（結果存在 _請求/%s）。不要說『好了』。"
                            % result.name) + "\n")
            emit(message + status)
        try:
            data = json.loads(request.read_text(encoding="utf-8-sig"))
            if not isinstance(data, dict):
                raise ValueError("請求格式不正確")
            params = data.get("參數", [])
            if not isinstance(params, list) or any(not isinstance(v, str) for v in params):
                raise ValueError("參數必須是字串陣列")
            if interrupted_note:
                emit(interrupted_note)
            emit(describe_request(data, root))
            emit("AI 交辦的時間：%s\n" % datetime.datetime.fromtimestamp(request.stat().st_mtime).strftime("%Y-%m-%d %H:%M"))
            # v1.56.0：環境不對在按 Enter 之前就講：請求單留原名，裝好再雙擊一次就能做（以前按了 Enter 才擋，單子已經用掉）
            problem = python_problem()
            if problem:
                raise ValueError(python_advice(problem))
            if age >= STALE_HOURS * 3600:
                emit("這個指令是 %s準備的。如果你現在就是要做 AI 最近交辦的這一步，直接按 Enter；"
                     "如果不確定，關掉視窗、回對話跟 AI 說『指令太舊了，請重新準備』。\n" % _age_text(age))
            if sys.stdin.isatty() and not _running_tests():
                emit("按 Enter 才開始；關閉視窗可取消。\n")
                if not sys.stdin.readline():
                    # 取消時請求單留著：使用者再雙擊一次就能重來，不用請 AI 重寫
                    emit("[已取消] 沒有執行。要做的時候再雙擊一次就可以，不用跟 AI 說。\n")
                    return 1
            if older:
                # 只做最新的一張；較舊的是之前取消或沒做的，留著會在下次雙擊時被誤做
                retired = [_retire(p, "已作廢_").name for p in older]
                emit("另有 %d 件較舊的 AI 交辦工作沒做，已作廢、不會再執行：%s\n" % (len(retired), "、".join(retired)))
            emit(_wait_note(data) + "接下來畫面上的字多半是給 AI 看的，不用看懂；等最後一行寫「做完了」或「沒有做完」。\n")
            # 按了 Enter 就先改名「執行中」：視窗中途被關掉，下次雙擊不會整件重做（結果檔也不會有結束碼）
            request = _retire(request, RUNNING)
            started = True
            _write_pid(request)
            if "倉庫" not in data and ("操作" in data or ("指令" in data and "程式" in data)):
                raise ValueError("請求單的寫法不對：畫面顯示的和實際要做的不一樣，這張不執行")
            if "倉庫" in data:
                operation = data.get("操作")
                if operation is not None:
                    if operation not in ("準備", "收回本機", "取回", "還原備份") or "指令" in data or "程式" in data:
                        raise ValueError("不允許的倉庫操作")
                elif "程式" in data:
                    if data["程式"] != "semantic_candidates" or "指令" in data:
                        raise ValueError("不允許的程式")
                elif data.get("指令") not in COMMANDS:
                    raise ValueError("不允許的指令：%s" % data.get("指令"))
                elif data.get("指令") in NO_WAREHOUSE:
                    raise ValueError("工作區搬移指令不支援倉庫接力")
                import isolated_runner
                if data.get("程式") == "semantic_candidates":
                    emit(SEMANTIC_NOTE)
                class Tee:
                    def relay_status(self, text):
                        result_stream.finish(newline=True)
                        out.write(text)
                        out.flush()
                    def write(self, text):
                        emit(text)
                        return len(text)
                    def flush(self):
                        console.flush()
                        out.flush()
                with _progress_environment(console.isatty()), contextlib.redirect_stdout(Tee()):
                    rc = isolated_runner.local_relay(data, root)
                if rc == 3:
                    result_stream.finish()
                    out.seek(0)
                    lines = out.readlines()
                    warning = next((line for line in lines if line.startswith("倉庫 ") and "超過隔離區上限" in line), "")
                    if warning:
                        lines.remove(warning)
                        out.seek(0)
                        out.write(warning + "".join(lines))
                        out.truncate()
                    out.seek(0, os.SEEK_END)
                finish(rc)
                _finish_request(request, original_name)
                return rc
            if "程式" in data:
                if data["程式"] != "semantic_candidates" or "指令" in data:
                    raise ValueError("不允許的程式")
                ws, params = validate_parameters("semantic_candidates", params, root)
                command = [sys.executable, "-B", str(root / "scripts/semantic_candidates.py"), "--workspace", str(ws), *params]
            else:
                name = data.get("指令")
                if name not in COMMANDS:
                    raise ValueError("不允許的指令：%s" % name)
                ws, params = validate_parameters(name, params, root)
                command = [sys.executable, "-B", str(root / "scripts/run_all.py"), "--workspace", str(ws), name, *params]
                if name in NO_WAREHOUSE:
                    emit("工作區實際路徑：%s\n" % ws)
                    for item in params:
                        if os.path.isabs(item):
                            emit("搬移使用的實際路徑：%s\n" % item)
            import isolated_runner
            note = isolated_runner.old_launcher_note(ws)
            if note:
                emit(note + "\n")
            note = isolated_runner.workspace.program_version_note(ws) if "程式" in data else ""
            if note:
                emit(note + "\n")          # 語意計算不經過 run_all，版本提醒在這裡印
            if data.get("說明"):
                # v1.51.0：說明是 AI 寫的，開頭固定加字，塞不出一行假的 [結束碼] 0
                emit("AI 的說明：%s\n" % _printable(data["說明"], 300))
            if data.get("程式") == "semantic_candidates":
                emit(SEMANTIC_NOTE)
            env = dict(os.environ, PYTHONIOENCODING="utf-8", PYTHONUNBUFFERED="1", REG_RUN_REQUEST="1")
            if console.isatty():
                env['REG_PROGRESS_BAR'] = '1'
            else:
                env.pop('REG_PROGRESS_BAR', None)
            def stream(call):
                process = subprocess.Popen(call, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, cwd=str(root), env=env)
                decoder = codecs.getincrementaldecoder("utf-8")("replace")
                while True:
                    chunk = process.stdout.read1(4096)
                    if not chunk:
                        break
                    emit(decoder.decode(chunk))
                emit(decoder.decode(b"", final=True))
                return process.wait()
            rc = stream(command)
            if rc == 2 and data.get("程式") == "semantic_candidates":
                # 本機算不了語意不算整輪失敗（isolated_runner.skip_unavailable_semantic 是倉庫接力的那一份）
                known = semantic_memory.blocked()
                if known:
                    rc = stream([sys.executable, "-B", str(root / "scripts/run_all.py"), "--workspace", str(ws), "語意併入", "--略過"])
                    if rc == 0:
                        emit(semantic_memory.local_done_text(known) + "\n")
        except (ValueError, OSError, TypeError, zipfile.BadZipFile, EOFError, RuntimeError) as exc:
            emit("%s[中止] %s\n" % (ABORT_HINT, exc))
        finish(rc)
        result_stream.finish()
    if started:
        _finish_request(request, original_name)
    # v1.50.2：按 Enter 之前就失敗（例如作廢舊單時檔案被鎖住）的，請求單留原名，不標「已完成」
    return rc
