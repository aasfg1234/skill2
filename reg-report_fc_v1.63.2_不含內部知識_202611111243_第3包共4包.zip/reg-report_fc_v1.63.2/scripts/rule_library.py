# -*- coding: utf-8 -*-
"""規範資料庫（v1.9.0）：skill 資料夾的 資料庫/外部規範/、資料庫/內部規範/。

使用者自己放網路上找不到的規範全文（公會規範、函令、本行內規）。兩個用途：

一、引用查證（review_pack._external_pack）
    內規引用的規範名稱在資料庫找得到：
      內部規範 → 程式核對條號（點號）存在，就直接判「沒問題〔資料庫規章〕」，不用 AI、不用人；
      外部規範 → 把那一條條文放進審查包給 AI 對內容，查證來源寫「資料庫：外部規範/檔名」。
二、法規更新檢視（law_impact.collect）
    外部規範同一個名稱放了新舊兩版：程式逐條比出改了哪幾條，每一條當成一筆法規異動，
    去找哪些內規段落要跟著改。只有一版、檔名有日期而且在檢視期間內的，整份當一筆新規範。
    內部規範不算（那是我們自己的）。

檔名常帶版本號、日期、編號（「PL-012 個資管理要點(115.09.30修正)_v3.pdf」）：
parse_filename 把它們拆開，規範名稱才對得上內規裡的引用。拆的結果寫進 資料庫/目錄.csv，
程式猜錯的格子人直接改；改過的格子程式不再動，清空的格子程式重猜。
"""
import csv
import datetime
import hashlib
import io
import json
import math
import os
import re
import time
import unicodedata
from file_replace import QUICK_WAIT, replace_file

FOLDERS = ("外部規範", "內部規範")
EXTERNAL, INTERNAL = FOLDERS
CATALOG = "目錄.csv"
CATALOG_READ_WAITS = (0.02, 0.05, 0.1, None)        # 目錄被占用時等幾秒再讀；None＝不再等
README = "（說明）怎麼放.txt"
CATALOG_HEADER = ["資料夾", "檔名", "規範名稱", "版本", "日期", "編號", "別名", "狀態"]
EDITABLE = ("規範名稱", "版本", "日期", "編號", "別名")
IMAGE_SUFFIXES = (".png", ".jpg", ".jpeg", ".tif", ".tiff", ".bmp", ".gif")
SUFFIXES = (".pdf", ".docx", ".txt", ".md") + IMAGE_SUFFIXES
CONVERTED = "轉文字"                  # 圖片轉出來的文字，人看得到、可以改
PENDING_FILE = "待轉文字.txt"          # 電腦 OCR 轉不出來、要 AI 看圖打字的清單
_HEADER_SHA = "＃來源檔指紋："
_HEADER_HOW = "＃轉法："
SOURCE_PREFIX = "資料庫："
SOURCE_KIND = "資料庫"
CURRENT, OLD = "現行", "舊版"
TEXT_CACHE = "資料庫快取"

_CN = "零〇一二三四五六七八九十百千兩"
_NUM = r"[%s\d０-９]+" % _CN

README_TEXT = """這裡放網路上找不到的規範全文，程式會拿來查證內規裡的引用、追蹤規範修正。

外部規範／  公會自律規範、主管機關函令、作業規範……（別人訂的）
內部規範／  本行自己的規章、要點、作業程序（我們自己訂的）

能讀的格式：PDF、Word（.docx）、TXT、MD、圖片（PNG、JPG、TIF、BMP、GIF）。可以再分子資料夾。
掃描的 PDF 和圖片：程式用電腦內建的文字辨識（OCR）轉成文字，存在 轉文字/ 底下（跟原檔同名、多一個 .txt）。
OCR 可能有錯字：直接改那個 .txt，下次就照改過的讀（前兩行「＃」開頭的不要刪）。
電腦轉不出來的會列在 待轉文字.txt，下一次 AI 審查時由 AI 看圖把字打出來。

檔名：一定要有規範的正式名稱（跟內規引用時寫的一樣）。版本號、日期、編號可以一起寫在檔名裡，
程式會自己拆開，例如：
    保險代理人公會招攬作業自律規範_v3.pdf
    PL-012 個人資料保護管理要點(115.09.30修正).docx
    01_招攬作業要點_第5版_20260930.pdf

同一個規範的新舊版本可以都留著，不用刪：程式照日期（沒日期照版本號）認哪一份是現行版。
同一個規範有新舊兩版時（外部、內部規範都算），程式會逐條比出改了哪幾條，
在體檢的「法規更新檢視」看現行內規哪些段落要跟著改。

目錄.csv 是程式每次自動整理的清單：規範名稱、版本、日期、編號是程式從檔名猜的。
猜錯了直接改那一格（改過的程式不再動；清空那一格，程式下次會重猜）。
「別名」可以填內規裡常用的簡稱，好幾個用頓號隔開。「狀態」是程式寫的，改了也會被蓋掉。
"""


def library_dir():
    """資料庫資料夾：skill 資料夾（scripts/ 的上一層）的 資料庫/。REG_LIBRARY_DIR 有設就用那個（測試用）。"""
    return os.environ.get("REG_LIBRARY_DIR") or os.path.join(
        os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "資料庫")


def ensure_dirs(root=None):
    root = root or library_dir()
    for folder in FOLDERS:
        os.makedirs(os.path.join(root, folder), exist_ok=True)
    readme = os.path.join(root, README)
    if not os.path.isfile(readme):
        with io.open(readme, "w", encoding="utf-8") as f:
            f.write(README_TEXT)
    return root


# ---------------------------------------------------------------------------
# 檔名 → 規範名稱、版本、日期、編號
# ---------------------------------------------------------------------------

_DATE_RES = [
    # 2026-09-30、2026.9.30、2026年9月30日、2026_09_30
    re.compile(r"(?<!\d)((?:19|20)\d{2})\s*[-./_年]\s*(\d{1,2})\s*[-./_月]\s*(\d{1,2})\s*日?(?!\d)"),
    # 20260930
    re.compile(r"(?<!\d)((?:19|20)\d{2})(\d{2})(\d{2})(?!\d)"),
    # 民國 115.09.30、115年9月30日、115-9-30
    re.compile(r"(?:中華)?(?:民國)?(?<![\d.])((?:[5-9]\d|1[0-4]\d))\s*[-./年]\s*(\d{1,2})\s*[-./月]\s*(\d{1,2})\s*日?(?![\d.])"),
    # 1150930（民國年 7 碼）
    re.compile(r"(?<!\d)(1\d{2})(\d{2})(\d{2})(?!\d)"),
]
_VERSION_RES = [
    re.compile(r"(?i)(?<![A-Za-z])(?:ver|rev|v)\.?\s*(\d+(?:\.\d+){0,3})(?![\d.])"),
    re.compile(r"第\s*(%s)\s*版" % _NUM),
    re.compile(r"版\s*[本次]\s*[:：]?\s*(%s(?:\.\d+)*)" % _NUM),
    re.compile(r"(?<![\d.])(\d+(?:\.\d+){0,3})\s*版(?![本次權])"),
]
# 開頭的編號：「PL-012 」「A01_」「3-1-2_」「01_」（第一個分隔字前全是英數字、而且有數字）
_CODE_LEAD = re.compile(r"^\s*([A-Za-z0-9][A-Za-z0-9.\-]*\d[A-Za-z0-9.\-]*|\d)(?:[\s_、]+|(?=[^\x00-\x7f]))")
# 括號裡的編號：「(編號 PL-012)」「【A01】」
_CODE_BRACKET = re.compile(r"[（(【\[]\s*(?:編號\s*[:：]?\s*)?([A-Za-z]{0,8}[-_]?\d[A-Za-z0-9.\-]*)\s*[)）】\]]")
_CODE_WORD = re.compile(r"編號\s*[:：]?\s*([A-Za-z0-9][A-Za-z0-9.\-]*)")
# 只是在講版本狀態的字：括號裡只剩這些就整個括號拿掉，檔名頭尾的也拿掉
_TAG_WORDS = r"(?:修正|修訂|最新版?|新版|舊版|定稿|公告|發布|發佈|公布|核定|核准|現行|全文|生效|施行|更新|正式|版)"
_TAG_BRACKET = re.compile(r"[（(【\[〔]\s*(?:%s\s*)*[)）】\]〕]" % _TAG_WORDS)
_TAG_EDGE = re.compile(r"^(?:[\s_\-、.]*%s)+|(?:[\s_\-、.]*%s)+$" % (_TAG_WORDS, _TAG_WORDS))
# 這幾種多半不是正式全文：狀態欄提醒
_NOT_FULL = re.compile(r"草案|對照表|總說明|簡報|說明會")


def _iso(year, month, day):
    year, month, day = int(year), int(month), int(day)
    if year < 1911:
        year += 1911
    try:
        return datetime.date(year, month, day).isoformat()
    except ValueError:
        return ""


def parse_date(text):
    """把一格日期（目錄裡人填的「115/9/30」也收）轉成 YYYY-MM-DD；認不得回 ""。"""
    text = unicodedata.normalize("NFKC", str(text or "")).strip()
    for pattern in _DATE_RES:
        hit = pattern.search(text)
        if hit:
            value = _iso(*hit.groups())
            if value:
                return value
    return ""


def _cn_int(text):
    from _common import cn_to_int
    return cn_to_int(unicodedata.normalize("NFKC", text or ""))


def _version_value(text):
    text = unicodedata.normalize("NFKC", text or "").strip()
    if re.fullmatch(r"[%s]+" % _CN, text):
        value = _cn_int(text)
        return str(value) if value is not None else text
    return text


def parse_filename(filename):
    """「PL-012 個人資料保護管理要點(115.09.30修正)_v3.pdf」→
    {規範名稱: 個人資料保護管理要點, 版本: 3, 日期: 2026-09-30, 編號: PL-012, 不是全文: False}。"""
    stem = os.path.splitext(os.path.basename(filename))[0]
    text = unicodedata.normalize("NFKC", stem)
    found = {"規範名稱": "", "版本": "", "日期": "", "編號": ""}
    # 先拿掉有標記的版本號（v10.1.2、第5版），不然「10.1.2」會被當成民國 10 年 1 月 2 日
    for pattern in _VERSION_RES[:3]:
        hit = pattern.search(text)
        if hit:
            found["版本"] = _version_value(hit.group(1))
            text = text[:hit.start()] + " " + text[hit.end():]
            break
    for pattern in _DATE_RES:
        hit = pattern.search(text)
        if hit and _iso(*hit.groups()):
            found["日期"] = _iso(*hit.groups())
            text = text[:hit.start()] + " " + text[hit.end():]
            break
    if not found["版本"]:
        hit = _VERSION_RES[3].search(text)
        if hit:
            found["版本"] = _version_value(hit.group(1))
            text = text[:hit.start()] + " " + text[hit.end():]
    for pattern in (_CODE_BRACKET, _CODE_WORD):
        hit = pattern.search(text)
        if hit:
            found["編號"] = hit.group(1)
            text = text[:hit.start()] + " " + text[hit.end():]
            break
    if not found["編號"]:
        hit = _CODE_LEAD.match(text)
        if hit:
            found["編號"] = hit.group(1).strip(".-")
            text = text[hit.end():]
    for _ in range(3):
        text = _TAG_BRACKET.sub(" ", text)
        text = re.sub(r"[（(【\[〔]\s*[)）】\]〕]", " ", text)
        text = _TAG_EDGE.sub("", text.strip())
    name = re.sub(r"[\s_]+", "", text).strip("-–—.、,，:：")
    name = name.strip("「」『』《》〈〉\"'")
    found["規範名稱"] = name or re.sub(r"\s+", "", stem)
    found["不是全文"] = bool(_NOT_FULL.search(stem))
    return found


def norm_name(text):
    """比對名稱用：全形半形統一、拿掉空白與引號、「台」當「臺」。"""
    text = unicodedata.normalize("NFKC", str(text or ""))
    text = re.sub(r"[\s「」『』《》〈〉\"'“”‘’]", "", text)
    return text.replace("台", "臺")


def _version_key(version):
    parts = re.findall(r"\d+", version or "")
    return tuple(int(p) for p in parts)


# ---------------------------------------------------------------------------
# 讀全文（照檔案指紋快取在 memoization/資料庫快取/）
# ---------------------------------------------------------------------------

def _sha(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for block in iter(lambda: f.read(1 << 20), b""):
            h.update(block)
    return h.hexdigest()


def _cache_folder():
    import batch
    return os.path.join(batch.cache_dir(), TEXT_CACHE)


def _extract(path):
    """回傳段落 list。讀不到文字回 []。"""
    suffix = os.path.splitext(path)[1].lower()
    if suffix == ".pdf":
        from pypdf import PdfReader
        lines = []
        for page in PdfReader(path).pages:
            lines.extend((page.extract_text() or "").splitlines())
        return [line.strip() for line in lines if line.strip()]
    if suffix == ".docx":
        from _common import read_paragraphs_with_metadata
        paragraphs, _kinds, meta = read_paragraphs_with_metadata(path)
        out = []
        for text, info in zip(paragraphs, meta):
            label = (info or {}).get("list_label") or ""
            # Word 自動編號（「一、」「第一條」）不在字裡：補回去才切得出條號、點號
            out.append(label + text if label and not text.startswith(label) else text)
        return [p for p in out if p.strip()]
    from _common import read_paragraphs
    return [p for p in read_paragraphs(path) if p.strip()]


def read_text(path, sha=None):
    """(段落 list, 錯誤說明)。同一個檔（指紋一樣）只讀一次。"""
    sha = sha or _sha(path)
    cache = os.path.join(_cache_folder(), sha + ".json")
    try:
        with io.open(cache, encoding="utf-8") as f:
            data = json.load(f)
        if data.get("段落") and not data.get("錯誤"):
            return data["段落"], ""
    except (OSError, ValueError, AttributeError):
        pass
    error = ""
    try:
        paragraphs = _extract(path)
    except ImportError:
        return [], "PDF 要 pypdf 套件才讀得到"       # 不快取：裝好之後就讀得到
    except (Exception, SystemExit) as exc:   # 壞檔、加密 PDF、亂碼純文字檔
        paragraphs, error = [], "讀不出來（%s）" % (str(exc).splitlines()[0] if str(exc) else type(exc).__name__)
    if not error and len("".join(paragraphs).strip()) < 20:
        paragraphs, error = [], "讀不到文字（掃描圖檔？要能選取文字的 PDF）"
    if paragraphs and not error:
        try:
            os.makedirs(os.path.dirname(cache), exist_ok=True)
            with io.open(cache, "w", encoding="utf-8") as f:
                json.dump({"段落": paragraphs, "錯誤": error}, f, ensure_ascii=False)
        except OSError:
            pass
    return paragraphs, error


def converted_path(root, doc):
    return os.path.join(root, CONVERTED, doc["資料夾"], doc["檔名"] + ".txt")


def converted_header(doc, how):
    return ["%s%s" % (_HEADER_SHA, doc["sha"]),
            "%s%s；有錯字直接改這個檔，下次就照改過的讀（這兩行不要刪）" % (_HEADER_HOW, how)]


def _read_converted(path):
    """(段落, 來源指紋, 轉法)。"""
    with io.open(path, encoding="utf-8-sig") as f:
        lines = f.read().splitlines()
    sha, how, body = "", "", []
    for line in lines:
        if line.startswith(_HEADER_SHA):
            sha = line[len(_HEADER_SHA):].strip()
        elif line.startswith(_HEADER_HOW):
            how = line[len(_HEADER_HOW):].split("；")[0].strip()
        elif line.strip() and not line.startswith("＃"):
            body.append(line.strip())
    return body, sha, how


def _write_converted(path, doc, how, paragraphs):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with io.open(path, "w", encoding="utf-8") as f:
        f.write("\n".join(converted_header(doc, how) + list(paragraphs)) + "\n")


_OCR_SPACE = re.compile(r"\s+(?=[^\x00-\x7f])|(?<=[^\x00-\x7f])\s+")
_OCR_ONE = re.compile(r"第[-—–─_~]([條點章節項款目])")
_OCR_PUNCT = {",": "，", "(": "（", ")": "）", ":": "：", ";": "；", "?": "？", "!": "！"}


def clean_ocr_line(line):
    """Windows OCR 的中文一字一空格（「第 二 條 招 攬」）：中文字旁邊的空格拿掉；
    「第 - 條」是「一」被認成橫線；中文旁邊的半形標點換全形。"""
    line = _OCR_SPACE.sub("", (line or "").strip())
    line = _OCR_ONE.sub(r"第一\1", line)
    for half, full in _OCR_PUNCT.items():
        line = re.sub(r"(?<=[^\x00-\x7f])%s|%s(?=[^\x00-\x7f])" % (re.escape(half), re.escape(half)), full, line)
    return line


def _page_images(path, folder):
    """掃描 PDF 每一頁（或圖片檔本身）轉成 PNG，回傳路徑 list。"""
    from PIL import Image
    suffix = os.path.splitext(path)[1].lower()
    out = []
    if suffix != ".pdf":
        images = [Image.open(path)]
    else:
        images = []
        try:
            import pymupdf as fitz
        except ImportError:
            try:
                import fitz
            except ImportError:
                fitz = None
        if fitz is not None:
            with fitz.open(path) as pdf:
                for number, page in enumerate(pdf, 1):
                    target = os.path.join(folder, "p%04d.png" % number)
                    page.get_pixmap(dpi=250).save(target)
                    out.append(target)
            return out
        from pypdf import PdfReader          # 沒有 PyMuPDF：拿每一頁嵌的圖（掃描檔一頁一張）
        for page in PdfReader(path).pages:
            for image in page.images:
                images.append(image.image)
    for number, image in enumerate(images, 1):
        image = image.convert("RGB")
        if max(image.size) > 9000:
            ratio = 9000.0 / max(image.size)
            image = image.resize((int(image.size[0] * ratio), int(image.size[1] * ratio)))
        target = os.path.join(folder, "p%04d.png" % number)
        image.save(target)
        out.append(target)
    return out


def ocr_images(paths):
    """Windows 內建文字辨識：{圖片路徑: [一行一行]}。不能跑（不是 Windows、沒有繁中語言）丟 OSError。"""
    import subprocess
    import tempfile
    if os.name != "nt":
        raise OSError("不是 Windows，沒有內建文字辨識")
    script = os.path.join(os.path.dirname(os.path.abspath(__file__)), "ocr_windows.ps1")
    with tempfile.TemporaryDirectory(prefix="reg-ocr-list-") as temp:
        listing, result = os.path.join(temp, "list.txt"), os.path.join(temp, "out.json")
        with io.open(listing, "w", encoding="utf-8") as f:
            f.write("\n".join(os.path.normpath(p) for p in paths) + "\n")
        done = subprocess.run(["powershell", "-NoProfile", "-ExecutionPolicy", "Bypass", "-File", script,
                               "-ListFile", listing, "-OutFile", result],
                              capture_output=True, timeout=120 + 30 * len(paths))
        if done.returncode != 0 or not os.path.isfile(result):
            message = (done.stderr or done.stdout or b"").decode("utf-8", "replace").strip().splitlines()
            raise OSError("文字辨識失敗：%s（公司政策不准跑 PowerShell 腳本時會這樣：請資訊單位放行，"
                          "或把圖片的字打成 .txt 放進 資料庫/轉文字/）" % (message[0] if message else "沒有結果"))
        with io.open(result, encoding="utf-8-sig") as f:
            data = json.load(f)
    out = {}
    for path in paths:
        value = data.get(os.path.normpath(path))
        out[path] = value if isinstance(value, list) else []
    return out


def _ocr_document(doc):
    """(段落, 錯誤)。同一個檔 OCR 失敗過就記在快取，不每一輪重跑（檔換了才重試）。"""
    import tempfile
    if os.environ.get("REG_NO_OCR") == "1":
        return [], "這個環境不跑文字辨識（REG_NO_OCR=1）"
    failed = os.path.join(_cache_folder(), doc["sha"] + ".ocr失敗.json")
    if os.path.isfile(failed):
        try:
            with io.open(failed, encoding="utf-8") as f:
                return [], json.load(f).get("錯誤") or "文字辨識轉不出字"
        except (OSError, ValueError):
            pass
    try:
        with tempfile.TemporaryDirectory(prefix="reg-ocr-") as temp:
            pages = _page_images(doc["path"], temp)
            texts = ocr_images(pages) if pages else {}
            paragraphs = [clean_ocr_line(line) for page in pages for line in texts.get(page, [])]
            paragraphs = [p for p in paragraphs if p]
    except ImportError as exc:
        return [], "要轉圖片缺套件（%s）" % exc
    except Exception as exc:
        paragraphs, error = [], "文字辨識失敗（%s）" % (str(exc).splitlines()[0] if str(exc) else type(exc).__name__)
    else:
        error = "" if len("".join(paragraphs)) >= 20 else "文字辨識轉不出字"
    if error:
        try:
            os.makedirs(os.path.dirname(failed), exist_ok=True)
            with io.open(failed, "w", encoding="utf-8") as f:
                json.dump({"錯誤": error}, f, ensure_ascii=False)
        except OSError:
            pass
        return [], error
    return paragraphs, ""


def load_text(root, doc, write=True):
    """(段落, 錯誤, 轉法)。轉法：「文字」（檔案本身有字）、「OCR」「AI」（從圖片轉的，存在 轉文字/）、「待轉」。
    轉文字/ 底下有這一份、指紋對得上就照它讀（人改過錯字的也是）；檔換了就重轉。"""
    converted = converted_path(root, doc)
    if os.path.isfile(converted):
        paragraphs, sha, how = _read_converted(converted)
        if sha == doc["sha"] and len("".join(paragraphs)) >= 20:
            return paragraphs, "", ("AI" if "AI" in how else "OCR")
    suffix = os.path.splitext(doc["path"])[1].lower()
    if suffix not in IMAGE_SUFFIXES:
        paragraphs, error = read_text(doc["path"], doc["sha"])
        if paragraphs or suffix != ".pdf" or "pypdf" in error:
            return paragraphs, error, "文字"
    paragraphs, error = _ocr_document(doc)
    if paragraphs:
        if write:
            _write_converted(converted, doc, "Windows 文字辨識（OCR），可能有錯字", paragraphs)
        return paragraphs, "", "OCR"
    return [], "要 AI 看圖轉文字（%s；見 %s）" % (error, PENDING_FILE), "待轉"


# ---------------------------------------------------------------------------
# 條號、點號
# ---------------------------------------------------------------------------

_ARTICLE_HEAD = re.compile(r"^\s*第\s*(%s)\s*(?:[-－]\s*(%s)\s*)?條(?:\s*之\s*(%s))?(?P<rest>.*)$" % (_NUM, _NUM, _NUM), re.S)
_POINT_HEAD = re.compile(r"^\s*第\s*(%s)\s*點(?P<rest>.*)$" % _NUM, re.S)
_CN_POINT_HEAD = re.compile(r"^\s*([%s]+)\s*[、．.]" % _CN.replace("零〇", ""))
# 條號後面接這些字，是句子裡提到別條（PDF 一行一斷時「依\n第三條規定」），不是條文開頭
_NOT_HEAD_AFTER = re.compile(r"^\s*(?:規定|之規定|所|及|或|、|至|第|前|後|中|但書|準用|辦理)")


def _head(text, mode):
    if mode == "條":
        hit = _ARTICLE_HEAD.match(text)
        if hit and not _NOT_HEAD_AFTER.match(hit.group("rest")):
            main = _cn_int(hit.group(1))
            sub = _cn_int(hit.group(2) or hit.group(3) or "") or 0
            return ("條", main, sub) if main is not None else None
        return None
    if mode == "點":
        hit = _POINT_HEAD.match(text)
        if hit and not _NOT_HEAD_AFTER.match(hit.group("rest")):
            value = _cn_int(hit.group(1))
            return ("點", value, 0) if value is not None else None
        return None
    hit = _CN_POINT_HEAD.match(text)
    if hit:
        value = _cn_int(hit.group(1))
        return ("點", value, 0) if value is not None else None
    return None


def articles(paragraphs):
    """{(條/點, 號, 之幾): 條文全文}，照文件順序。分不出條號回 {}。
    號碼要一路往上（第三條之後又出現「第二條」是句子裡提到的，不是條文開頭）。"""
    for mode in ("條", "點", "一、"):
        heads = []
        last = None
        for i, text in enumerate(paragraphs):
            key = _head(text, mode)
            if key and (last is None or key[1:] > last[1:]):
                heads.append((i, key))
                last = key
        if len(heads) >= 2:
            out = {}
            for n, (i, key) in enumerate(heads):
                end = heads[n + 1][0] if n + 1 < len(heads) else len(paragraphs)
                out[key] = "\n".join(paragraphs[i:end]).strip()
            return out
    return {}


def article_label(key):
    kind, number, sub = key
    return "第%d%s%s" % (number, kind, "之%d" % sub if sub else "")


_CITE_RE = re.compile(r"第\s*(%s)\s*(?:[-－‐]\s*(%s)\s*)?(條|點)(?:\s*之\s*(%s))?" % (_NUM, _NUM, _NUM))
_SECTION_RE = re.compile(r"§\s*(%s)(?:\s*(?:之|[-－‐])\s*(%s))?" % (_NUM, _NUM))


def cite_key(number):
    """引用裡的條號（「第一百四十六條之一」「第146-1條」「§146-1」「第三點」）→ (條/點, 號, 之幾)。"""
    text = unicodedata.normalize("NFKC", number or "")
    hit = _CITE_RE.search(text)
    if hit:
        main = _cn_int(hit.group(1))
        sub = _cn_int(hit.group(2) or hit.group(4) or "") or 0
        return (hit.group(3), main, sub) if main is not None else None
    hit = _SECTION_RE.search(text)
    if hit:
        main = _cn_int(hit.group(1))
        sub = _cn_int(hit.group(2) or "") or 0
        return ("條", main, sub) if main is not None else None
    return None


# ---------------------------------------------------------------------------
# 目錄
# ---------------------------------------------------------------------------

def _scan(root):
    files = []
    for folder in FOLDERS:
        base = os.path.join(root, folder)
        for dirpath, dirnames, names in os.walk(base):
            dirnames.sort()
            for name in sorted(names):
                if name.startswith(("~$", ".")) or name.lower() in ("desktop.ini", "thumbs.db"):
                    continue
                path = os.path.join(dirpath, name)
                rel = os.path.relpath(path, base).replace(os.sep, "/")
                files.append((folder, rel, path))
    return files


def _read_catalog(path):
    if not os.path.isfile(path):
        return {}
    from _common import open_csv
    for wait in CATALOG_READ_WAITS:
        try:
            with open_csv(path) as f:
                rows = list(csv.DictReader(f))
            break
        except PermissionError:      # 別的行程換檔的那一瞬間：等一下再讀，不然這一輪都只能照檔名猜
            if wait is None:
                return _catalog_unreadable(path, PermissionError("檔案被占用"))
            time.sleep(wait)
        except (OSError, ValueError, SystemExit, UnicodeDecodeError, csv.Error) as exc:
            return _catalog_unreadable(path, exc)
    return dict((((row.get("資料夾") or "").strip(), (row.get("檔名") or "").strip()), row) for row in rows)


def _catalog_unreadable(path, exc):
    from _common import warn_read_failure
    warn_read_failure(path, exc, "目錄讀不出來，本次不重寫目錄；名稱、日期與版本暫依檔名推測，請修復目錄後重跑", "規範資料庫")
    return None


class Library(object):
    """整理好的資料庫：docs（每一份檔）、groups（同一個規範的各版本，新的在前）。"""

    def __init__(self, root, docs, warnings):
        self.root, self.docs, self.warnings = root, docs, warnings
        self.groups = {}
        for doc in docs:
            if doc["readable"]:
                self.groups.setdefault((doc["資料夾"], norm_name(doc["規範名稱"])), []).append(doc)
        self.names = {}
        for (folder, key), versions in self.groups.items():
            versions.sort(key=_sort_key, reverse=True)
            ambiguous = len(versions) > 1 and _sort_key(versions[0])[:2] == _sort_key(versions[1])[:2]
            for i, doc in enumerate(versions):
                doc["current"] = i == 0
                doc["ambiguous"] = ambiguous
            # 名稱、別名、編號都可以對（同名的內部、外部各一份時，內部規範優先：引用的多半是本行的）
            for alias in [versions[0]["規範名稱"]] + versions[0]["別名"] + [versions[0]["編號"]]:
                alias = norm_name(alias)
                if len(alias) >= 2 and (alias not in self.names or folder == INTERNAL):
                    self.names[alias] = (folder, key)

    def find(self, name):
        """引用寫的規範名稱 → 現行那一份（doc dict）；對不到回 None。"""
        hit = self.names.get(norm_name(name))
        return self.groups[hit][0] if hit else None

    def versions(self, doc):
        return self.groups.get((doc["資料夾"], norm_name(doc["規範名稱"]))) or [doc]

    def has_source(self, source):
        """查證來源寫的「資料庫：外部規範/檔名」是不是資料庫裡真的有的一份。"""
        text = (source or "").strip()
        return any(text.startswith(source_text(doc)) for doc in self.docs)

    def citation(self, name, number):
        """內規裡的一處引用到資料庫核對。對不到這個規範回 None；對到回 dict：
        doc、key（條號，認不得 None）、text（那一條條文，沒有這一條或分不出條號是 ""）、
        exists（True 有這一條／False 確定沒有／None 判不了）、note（給人看的一句話）。"""
        doc = self.find(name)
        if not doc:
            return None
        where = source_text(doc)
        key = cite_key(number) if number else None
        if not number:
            return {"doc": doc, "key": None, "text": "", "exists": True, "note": "%s有這一份規範" % where}
        if key is None:
            return {"doc": doc, "key": None, "text": "", "exists": None,
                    "note": "%s有這一份規範，條號寫法認不得" % where}
        table = doc_articles(doc)
        if not table:
            return {"doc": doc, "key": key, "text": "", "exists": None,
                    "note": "%s有這一份規範，但分不出條號、點號（要看全文）" % where}
        if key in table:
            return {"doc": doc, "key": key, "text": table[key], "exists": True,
                    "note": "%s，%s存在" % (where, article_label(key))}
        return {"doc": doc, "key": key, "text": "", "exists": False,
                "note": "%s那一份沒有%s" % (where, article_label(key))}


_NOT_CJK = re.compile(r"[^\u3400-\u9fff]")
RELATED_LIMIT = 3            # 一段最多附幾條
RELATED_MIN_SCORE = 0.30     # 內容相近：雙字詞（照罕見程度加權）的餘弦相似度；用真的手冊段落調過，0.3 以上多半真的相關
RELATED_MIN_SHARED = 8       # 而且至少共用這麼多個雙字詞
RELATED_MIN_ARTICLE = 25     # 太短的條文（「本要點適用於本行人員」，雙字詞不到 25 個）什麼段都像，不拿來比相似
RELATED_CHARS = 1500         # 每一條最多附幾個字


def _grams(text):
    plain = _NOT_CJK.sub("", unicodedata.normalize("NFKC", text or ""))
    return set(plain[i:i + 2] for i in range(len(plain) - 1))


def _related_index(library):
    """現行那幾份的每一條：[(doc, key, 條文, 雙字詞)]，與每個雙字詞的權重（越少條用到越重）。"""
    if getattr(library, "_index", None) is None:
        entries, df = [], {}
        for (_folder, _key), versions in sorted(library.groups.items()):
            doc = versions[0]
            table = doc_articles(doc)
            items = list(table.items()) or [(None, "\n".join(doc_paragraphs(doc)))]
            for key, text in items:
                grams = _grams(text)
                entries.append((doc, key, text, grams))
                for gram in grams:
                    df[gram] = df.get(gram, 0) + 1
        total = max(len(entries), 1)
        weight = dict((gram, math.log(1.0 + float(total) / count)) for gram, count in df.items())
        library._index = (entries, weight)
    return library._index


def _best(library, text, docs=None, limit=3, min_score=0.0, min_shared=1, min_article=0):
    entries, weight = _related_index(library)
    query = _grams(text)
    if not query:
        return []
    default = math.log(2.0)
    total = sum(weight.get(g, default) ** 2 for g in query)
    scored = []
    for doc, key, article, grams in entries:
        if docs is not None and doc not in docs:
            continue
        if len(grams) < min_article:
            continue
        shared = query & grams
        if len(shared) < min_shared:
            continue
        # 兩邊長度都算（餘弦）：長條文字多，只看「本段的字有幾成在那一條」的話什麼段都配得上
        score = sum(weight.get(g, default) ** 2 for g in shared) / math.sqrt(
            total * sum(weight.get(g, default) ** 2 for g in grams))
        if score >= min_score:
            scored.append((score, doc, key, article))
    scored.sort(key=lambda x: -x[0])
    return scored[:limit]


def related_articles(text, limit=RELATED_LIMIT, exclude_names=()):
    """這一段（條文檢查、異動審查要判的那一段）在規範資料庫裡的相關條文：
    [{doc, key, text, why, source}]。先放本段直接引用的（有條號就那一條；沒條號放那一份內容最接近的），
    不夠再找內容相近的（雙字詞重疊）。exclude_names：正在檢查的那一本自己（不拿自己對照自己）。"""
    try:
        library = load()
    except Exception as exc:
        from _common import warn_read_failure
        warn_read_failure(library_dir(), exc, "規範資料庫讀不到，審查包沒附相關規範", "規範資料庫")
        return []
    if not library.groups or not (text or "").strip():
        return []
    skip = set(norm_name(n) for n in exclude_names if n)
    out, seen = [], set()

    def add(doc, key, article, why):
        mark = (doc["path"], key)
        if mark in seen or norm_name(doc["規範名稱"]) in skip or len(out) >= limit:
            return
        seen.add(mark)
        out.append({"doc": doc, "key": key, "text": article, "why": why, "source": source_text(doc)})

    try:
        import rule_checks
        mentions = rule_checks.external_mentions([text])
    except Exception:
        mentions = []
    for mention in mentions:
        found = library.citation(mention.get("名稱") or "", mention.get("條號") or "")
        if not found:
            continue
        doc = found["doc"]
        if found["text"]:
            add(doc, found["key"], found["text"], "本段引用%s%s" % (doc["規範名稱"], article_label(found["key"])))
        else:
            for _score, hit, key, article in _best(library, text, docs=[doc], limit=2):
                add(hit, key, article, "本段提到%s，這是那一份裡內容最接近的條文" % doc["規範名稱"])
    if len(out) < limit:
        for score, doc, key, article in _best(library, text, limit=limit + len(seen),
                                              min_score=RELATED_MIN_SCORE, min_shared=RELATED_MIN_SHARED,
                                              min_article=RELATED_MIN_ARTICLE):
            add(doc, key, article, "內容相近（本段用字約 %d%% 出現在這一條）" % round(score * 100))
    return out


def related_lines(text, exclude_names=()):
    """審查包用的幾行 markdown；沒有相關條文回 []。"""
    found = related_articles(text, exclude_names=exclude_names)
    if not found:
        return []
    lines = ["規範資料庫的相關條文（使用者放的全文；先拿它對照。法律、主管機關法規網路查得到的，仍要上網確認現行條文）：", ""]
    for item in found:
        doc = item["doc"]
        label = article_label(item["key"]) if item["key"] else "全文"
        lines.append("- %s　%s（%s%s）" % (item["source"], label, item["why"],
                                          "；從圖片轉的文字，可能有錯字" if doc.get("轉法") in ("OCR", "AI") else ""))
        body = item["text"] if len(item["text"]) <= RELATED_CHARS else item["text"][:RELATED_CHARS] + "…（後略）"
        lines.append("  > " + body.replace("\n", "\n  > "))
    lines.append("")
    return lines


def related_digest(text, exclude_names=()):
    """附的相關條文的指紋（沒有回 ""）：資料庫換了條文，AI 判過的答案就不沿用。"""
    found = related_articles(text, exclude_names=exclude_names)
    if not found:
        return ""
    raw = "\n".join("%s|%s|%s" % (item["source"], item["key"], item["text"]) for item in found)
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()


def _sort_key(doc):
    return (doc["日期"] or "", _version_key(doc["版本"]), doc["mtime"])


def source_text(doc):
    return "%s%s/%s" % (SOURCE_PREFIX, doc["資料夾"], doc["檔名"])


def doc_articles(doc):
    if "_articles" not in doc:
        doc["_articles"] = articles(doc_paragraphs(doc))
    return doc["_articles"]


def doc_paragraphs(doc):
    if "_paragraphs" not in doc:
        doc["_paragraphs"], _error = read_text(doc["path"], doc["sha"])
    return doc["_paragraphs"]


_LOADED = {}


def load(write=True, refresh=False):
    """掃資料庫、整理目錄（寫回 目錄.csv）。同一個執行只整理一次。"""
    root = library_dir()
    if root in _LOADED and not refresh:
        return _LOADED[root]
    warnings = []
    if not os.path.isdir(root):
        library = Library(root, [], warnings)
        _LOADED[root] = library
        return library
    if write:
        try:
            ensure_dirs(root)
        except OSError:
            write = False         # 資料庫唯讀（例如共用磁碟）：照樣讀，只是不整理目錄、不存轉好的文字
    catalog_path = os.path.join(root, CATALOG)
    catalog_stamp = _file_stamp(catalog_path)
    old = _read_catalog(catalog_path)
    if old is None:
        warnings.append("%s 讀不出來，本次不重寫目錄；名稱、日期與版本暫依檔名推測，請修復後重跑" % catalog_path)
        old, write = {}, False
    docs, rows = [], []
    for folder, rel, path in _scan(root):
        guess = parse_filename(rel)
        row = old.get((folder, rel)) or {}
        doc = {"資料夾": folder, "檔名": rel, "path": path, "mtime": os.path.getmtime(path)}
        for column in EDITABLE:
            typed = (row.get(column) or "").strip()
            doc[column] = typed if typed else (guess.get(column, "") if column != "別名" else "")
        typed_date = doc["日期"]
        doc["日期"] = parse_date(typed_date) if typed_date else ""
        status = []
        if typed_date and not doc["日期"]:
            status.append("日期看不懂（寫成 2026-09-30 或 115.09.30）")
        doc["別名"] = [a.strip() for a in re.split(r"[、,，;；\n]", doc["別名"]) if a.strip()]
        doc["readable"] = False
        doc["轉法"] = ""
        if os.path.splitext(rel)[1].lower() not in SUFFIXES:
            status.append("不支援的格式（只收 PDF、Word .docx、TXT、MD、圖片）")
        else:
            doc["sha"] = _sha(path)
            paragraphs, error, how = load_text(root, doc, write=write)
            doc["_paragraphs"], doc["轉法"] = paragraphs, how
            if error:
                status.append(error)
                message = "%s 讀不出來：%s；本次無法使用此份規範，請確認檔案完整、解除加密或補上可讀文字後重跑" % (path, error)
                warnings.append(message)
                from _common import warn_read_failure
                warn_read_failure(path, ValueError(error), "缺少此份規範內容，請確認檔案完整、解除加密或補上可讀文字", "規範資料庫")
            else:
                doc["readable"] = True
                if how in ("OCR", "AI"):
                    status.append("%s從圖片轉的文字（可能有錯字，可改 %s/%s/%s.txt）"
                                  % ("電腦" if how == "OCR" else "AI ", CONVERTED, folder, rel))
        if guess["不是全文"]:
            status.append("檔名看起來不是正式全文（草案、對照表、說明）")
        doc["_status"] = status
        docs.append(doc)
    library = Library(root, docs, warnings)
    for doc in docs:
        if doc["readable"]:
            continue
        versions = library.groups.get((doc["資料夾"], norm_name(doc["規範名稱"]))) or []
        if versions and _sort_key(doc) > _sort_key(versions[0]):
            message = "新版 %s 讀不出來，現在用的是 %s；請修復新版後重跑" % (doc["path"], versions[0]["path"])
            warnings.append(message)
            import notices as nt
            nt.notice(nt.WARNING, message, "規範資料庫")
    for doc in docs:
        status = list(doc.pop("_status"))
        if doc["readable"]:
            many = len(library.versions(doc)) > 1
            if doc.get("ambiguous"):
                status.insert(0, "同名有好幾份、分不出新舊（請在目錄填日期或版本）；暫用最近存檔的那份"
                              if doc.get("current") else "同名有好幾份、分不出新舊（請在目錄填日期或版本）")
            elif many:
                status.insert(0, CURRENT if doc.get("current") else OLD)
            else:
                status.insert(0, CURRENT)
        doc["狀態"] = "；".join(status)
        rows.append([doc["資料夾"], doc["檔名"], doc["規範名稱"], doc["版本"], doc["日期"] or "",
                     doc["編號"], "、".join(doc["別名"]), doc["狀態"]])
    if write:
        _write_pending(root, [d for d in docs if d.get("轉法") == "待轉"])
        try:
            _write_catalog(catalog_path, rows, catalog_stamp, docs)
        except OSError:
            warnings.append("資料庫/目錄.csv 寫不進去（Excel 開著，或資料夾不能寫？），這一次照記憶體裡的整理結果用")
    _LOADED[root] = library
    return library


def _file_stamp(path):
    try:
        stat = os.stat(path)
        return stat.st_mtime_ns, stat.st_size
    except OSError:
        return None


def _write_catalog(path, rows, read_stamp, docs):
    """寫 目錄.csv（v1.60.2）。比對時好幾個行程同時整理，以前直接清空重寫：別的行程剛好讀到空檔，
    就照檔名重猜，把人填的別名、日期蓋掉。現在寫好暫存檔才整個換上，讀到的不會是清空或寫一半的檔。
    讀過之後檔案被改了（人存檔、別的行程整理）就不寫：手上那份是舊的，蓋上去會把剛填的字弄丟，下次再整理。
    內容一樣也不寫，不然每跑一次修改時間都變；只有資料庫裡的檔比目錄新時碰一下時間（設定頁靠它判斷整理過了沒）。"""
    if _file_stamp(path) != read_stamp:
        return
    text = io.StringIO(newline="")
    writer = csv.writer(text)
    writer.writerow(CATALOG_HEADER)
    writer.writerows(rows)
    raw = text.getvalue().encode("utf-8-sig")
    try:
        with open(path, "rb") as f:
            same = f.read() == raw
    except OSError:
        same = False
    if same:
        organized = os.path.getmtime(path)
        if any(doc["mtime"] > organized for doc in docs):
            os.utime(path)
        return
    temp = "%s.%d.tmp" % (path, os.getpid())
    try:
        with open(temp, "wb") as f:
            f.write(raw)
        replace_file(temp, path, max_wait=QUICK_WAIT)    # 真的開在 Excel 裡不用等滿
    finally:
        if os.path.exists(temp):
            os.remove(temp)


# ---------------------------------------------------------------------------
# v1.16.0 設定頁「規範資料」：看目錄、存檔（經「打開設定」的本機程式）
# ---------------------------------------------------------------------------

UPLOAD_LIMIT = 200 * 1024 * 1024          # 一份最大 200 MB
_BAD_NAME = re.compile(r'[\\/:*?"<>|\x00-\x1f]')


def quick_list():
    """設定頁的資料庫目錄：只看檔名與 目錄.csv，不讀內容、不跑文字辨識，馬上回來。
    檔案比 目錄.csv 新（剛存進來、換過）的狀態寫「還沒整理」。"""
    root = library_dir()
    catalog_path = os.path.join(root, CATALOG)
    catalog = _read_catalog(catalog_path) or {}
    organized = os.path.getmtime(catalog_path) if os.path.isfile(catalog_path) else 0
    files = []
    if os.path.isdir(root):
        for folder, rel, path in _scan(root):
            stat = os.stat(path)
            row = catalog.get((folder, rel)) or {}
            guess = parse_filename(rel)
            item = {"資料夾": folder, "檔名": rel, "大小": stat.st_size,
                    "存檔時間": datetime.datetime.fromtimestamp(stat.st_mtime).strftime("%Y-%m-%d %H:%M")}
            for column in ("規範名稱", "版本", "日期", "編號"):
                item[column] = (row.get(column) or "").strip() or guess.get(column, "")
            if row and stat.st_mtime <= organized:
                item["狀態"] = (row.get("狀態") or "").strip()
            else:
                item["狀態"] = "還沒整理（按「整理目錄」，或下次比對、體檢時自動整理）"
            files.append(item)
    return {"folders": list(FOLDERS), "files": files,
            "整理時間": datetime.datetime.fromtimestamp(organized).strftime("%Y-%m-%d %H:%M") if organized else ""}


def store(folder, name, raw, replace=False):
    """存一份檔進 資料庫/<folder>/<name>。回傳 dict：saved（存成的檔名）、same（同名而且內容一模一樣，沒重寫）、
    exists（同名但內容不一樣、沒說要取代：沒存）。不另取「_2」之類的名字：程式從檔名認版本，
    兩份都要留就請人在檔名加上版本或日期（例如 _v2、(115.09.30修正)）。"""
    name = (name or "").strip()
    if folder not in FOLDERS:
        raise ValueError("資料夾只能是 %s" % "或".join(FOLDERS))
    if not name or name in (".", "..") or name.startswith(("~$", ".")) or _BAD_NAME.search(name):
        raise ValueError('檔名不能有 \\ / : * ? " < > |，也不能用 . 或 ~$ 開頭')
    if os.path.splitext(name)[1].lower() not in SUFFIXES:
        raise ValueError("只收 PDF、Word .docx、TXT、MD、圖片")
    if len(raw) > UPLOAD_LIMIT:
        raise ValueError("檔案超過 %d MB" % (UPLOAD_LIMIT // 1024 // 1024))
    root = ensure_dirs()
    path = os.path.join(root, folder, name)
    if os.path.isfile(path):
        if _sha(path) == hashlib.sha256(raw).hexdigest():
            return {"saved": name, "same": True}
        if not replace:
            return {"saved": "", "exists": True}
    with open(path + ".tmp", "wb") as f:
        f.write(raw)
    replace_file(path + ".tmp", path)
    return {"saved": name}


def _write_pending(root, docs):
    """電腦 OCR 轉不出來的：列給 AI 看圖打字。沒有就刪掉清單。"""
    path = os.path.join(root, PENDING_FILE)
    if not docs:
        if os.path.isfile(path):
            try:
                os.remove(path)
            except OSError:
                pass
        return
    lines = ["這幾份是圖片（或掃描的 PDF），電腦的文字辨識轉不出字。請 AI 打開原檔、看圖把全文一字不漏打出來，",
             "存成下面寫的 .txt（UTF-8）。檔案開頭兩行照抄，下一行起是全文，一段一行；條號、點號照原文寫。",
             "存好之後下一次跑程式就會讀它（這份清單會自動更新）。", ""]
    for doc in docs:
        lines += ["■ 原檔：%s" % doc["path"], "  存成：%s" % converted_path(root, doc), "  開頭兩行："]
        lines += ["    " + line for line in converted_header(doc, "AI 看圖打字")]
        lines.append("")
    try:
        with io.open(path, "w", encoding="utf-8") as f:
            f.write("\n".join(lines))
    except OSError:
        pass


def pending_ai():
    """要 AI 看圖轉文字的那幾份（doc list）。"""
    return [d for d in load().docs if d.get("轉法") == "待轉"]


def readme_lines():
    """寫進 AI審查/先讀我.md：資料庫有圖片要 AI 看圖打字時才有這一節。"""
    try:
        docs = pending_ai()
    except Exception:
        return []
    if not docs:
        return []
    root = library_dir()
    lines = ["", "## 規範資料庫：要你看圖轉文字的檔（%d 份）" % len(docs), "",
             "電腦的文字辨識轉不出字。請打開原檔、看圖把全文一字不漏打出來，存成「存成」那個 .txt（UTF-8），"
             "開頭兩行照抄。存好下一次跑程式就會讀到（引用查證、法規更新檢視都會用）。不影響這一次的 AI 表。"]
    for doc in docs:
        head = converted_header(doc, "AI 看圖打字")
        lines.append("- 原檔 `%s` → 存成 `%s`，開頭兩行：`%s`／`%s`"
                     % (doc["path"], converted_path(root, doc), head[0], head[1]))
    return lines


def reset():
    """測試用：清掉這一次執行整理過的結果。"""
    _LOADED.clear()


def registry_names():
    """給外部規章登錄表加名稱用：[(名稱, 類別)]。內部規範的類別是「本行內規」，外部規範留空（AI 補）。"""
    try:
        library = load()
    except Exception:
        return []
    out = []
    for (folder, _key), versions in library.groups.items():
        doc = versions[0]
        for name in [doc["規範名稱"]] + doc["別名"]:
            name = re.sub(r"\s+", "", unicodedata.normalize("NFKC", name or ""))
            if len(name) >= 4:
                out.append((name, "本行內規" if folder == INTERNAL else ""))
    return out


# ---------------------------------------------------------------------------
# 法規更新檢視：外部規範的新舊版逐條比
# ---------------------------------------------------------------------------

def _same(a, b):
    return re.sub(r"\s+", "", a or "") == re.sub(r"\s+", "", b or "")


def law_records(since, until, mode="異動", skip_names=()):
    """外部規範產生的法規異動（law_sources.normalize 吃的 record），以及一段來源說明。

    有新舊兩版（分得出新舊）：逐條比，改過、新增、刪除的每一條一筆，日期用新版的日期；
    分不出條號就整份一筆。只有一版：檔名有日期、在期間內的整份當一筆新規範；沒日期的只拿來查證引用。
    盤點模式不看期間。"""
    library = load()
    skip = set(norm_name(n) for n in skip_names if n)
    records, compared, single_in, single_skip, ambiguous = [], 0, 0, 0, 0
    internal_compared, internal_records = 0, 0
    for (folder, _key), versions in sorted(library.groups.items()):
        new = versions[0]
        if folder == INTERNAL and (len(versions) < 2 or norm_name(new["規範名稱"]) in skip):
            continue        # 內部規範只有新舊兩版才比；這一批正在檢查的本身不比（那是「比對」的事）
        if new.get("ambiguous"):
            ambiguous += 1
            continue
        date = new["日期"] or ""
        in_period = mode == "盤點" or not date or since <= date <= until
        base = {"law_name": new["規範名稱"], "event_date": date, "status": "現行" if date else "待確認",
                "version": new["版本"] or date, "source_url": source_text(new), "_file": new["path"]}
        if len(versions) >= 2:
            if not in_period:
                continue
            old = versions[1]
            base["old_source_url"] = source_text(old)
            before_count = len(records)
            if folder == INTERNAL:
                internal_compared += 1
            else:
                compared += 1
            note = "規範資料庫（%s）逐條比對：舊版 %s → 新版 %s" % (folder, old["檔名"], new["檔名"])
            new_table, old_table = doc_articles(new), doc_articles(old)
            if new_table and old_table:
                for key in sorted(set(new_table) | set(old_table), key=lambda k: (k[0] != "條", k[1], k[2])):
                    before, after = old_table.get(key, ""), new_table.get(key, "")
                    if _same(before, after):
                        continue
                    kind = "增訂" if not before else ("刪除" if not after else "修正")
                    records.append(dict(base, article_no=article_label(key), old_text=before,
                                        new_text=after or "（刪除）", change_type=kind,
                                        notes="%s；本條%s" % (note, kind)))
            else:
                before, after = "\n".join(doc_paragraphs(old)), "\n".join(doc_paragraphs(new))
                if not _same(before, after):
                    records.append(dict(base, article_no="", old_text=before, new_text=after, change_type="修正",
                                        notes="%s；分不出條號，整份比對" % note))
            if folder == INTERNAL:
                internal_records += len(records) - before_count
        elif date and in_period:
            single_in += 1
            records.append(dict(base, article_no="", old_text="", new_text="\n".join(doc_paragraphs(new)),
                                change_type="新訂", notes="規範資料庫：只有這一版（%s），整份當新規範看" % new["檔名"]))
        else:
            single_skip += 1
    parts = ["外部規範 %d 份" % len([g for g in library.groups if g[0] == EXTERNAL])]
    if compared:
        parts.append("%d 份有新舊版、逐條比出 %d 筆異動" % (compared, len(records) - single_in - internal_records))
    if single_in:
        parts.append("%d 份只有一版、日期在期間內，整份當新規範" % single_in)
    if single_skip:
        parts.append("%d 份只有一版（沒日期或不在期間內），只拿來查證引用" % single_skip)
    if ambiguous:
        parts.append("%d 份同名分不出新舊，沒有比（請在 資料庫/目錄.csv 填日期或版本）" % ambiguous)
    if internal_compared:
        parts.append("內部規範 %d 份有新舊版、逐條比出 %d 筆異動" % (internal_compared, internal_records))
    return records, "；".join(parts), library.warnings
