# -*- coding: utf-8 -*-
"""
AI 報告審查（v1.18.0）：比對、體檢、法規追蹤每一輪的最後一站，AI 把檢視報告整份看一遍。

為什麼：AI 判每一列時只看得到那一列，看不到整份報告。同一段被好幾條法規各判一次、說法互相打架，
總表寫「適用」理由卻還說「待確認」，理由裡寫了報告上查不到的編號，明明查得到的事丟給人確認……
這些只有站在整份報告的高度才看得出來。

流程（設定.html「AI報告審查」可以關，預設開）：
    報告產出 → 程式打包 2_Log檔案/AI審查/LLM報告審查.md（檢查清單＋程式先掃出來的疑點）與空白的 AI報告審查.csv
    v1.60.0 起不放報告內容摘錄：模擬時 53 KB 從沒被讀過（AI 都用 看報告），還佔帶回額度。
    → AI 查到問題就直接改：資料錯在 AI 表就改 AI 表（報告上那一列跟著改）；AI報告審查.csv 只記審查紀錄
    → 跑「繼續」（法規追蹤是「法規繼續」）：程式檢查紀錄表填好了沒；AI 表改過就重新匯入、重出報告
    v1.27.0 起報告不再多一頁「AI報告審查」：承辦看到的就是改好的報告。
"""

import csv
import datetime
import io
import os
import re
from file_replace import replace_file

FOLDER = "AI審查"
FILE = "AI報告審查.csv"
PACK = "LLM報告審查.md"
SHEET = "AI報告審查"
SETTING = "AI報告審查"
HEADER = ["序號", "頁", "位置", "問題類型", "問題", "處理", "說明"]
TYPES = ("錯誤", "難懂", "重複", "缺漏", "無問題")
ACTIONS = ("已修改", "請人確認", "不用改")
WIDTHS = [6, 16, 14, 10, 50, 10, 50]
SKIP_SHEETS = ("段次總表", "使用說明", SHEET)
TODO_PREFIX = "AI 報告審查"


SKIP_ENV = "REG_SKIP_REPORT_REVIEW"     # 測試用：跟 REG_SKIP_FIRST_SETTINGS_ASK 一樣，舊測試不停在這一站


def enabled(settings=None):
    """設定.html「AI報告審查」：沒寫（舊版設定頁）＝開。"""
    if os.environ.get(SKIP_ENV) == "1":
        return False
    if settings is None:
        try:
            from _common import config_section
            settings = config_section("設定")
        except Exception:
            settings = {}
    value = (settings or {}).get(SETTING)
    if value is None or value == "":
        return True
    if isinstance(value, str):
        return value.strip().lower() not in ("false", "0", "否", "關", "no", "off")
    return bool(value)


def folder(output):
    from _common import SYSTEM_DIR
    return os.path.join(output, SYSTEM_DIR, FOLDER)


def table_path(output):
    return os.path.join(folder(output), FILE)


def pack_path(output):
    return os.path.join(folder(output), PACK)


def read_rows(output):
    """AI報告審查.csv 的列（空白列略過）。沒有這個檔回 None。"""
    path = table_path(output)
    if not os.path.isfile(path):
        return None
    # v1.49.0：以前只用 UTF-8 讀，承辦用 Excel 存成 Big5 就當成空表，填表照 Big5 寫回、越填越多還是說「空的」
    from _common import open_csv
    try:
        with open_csv(path) as f:
            rows = list(csv.DictReader(f))
    except (OSError, UnicodeError, csv.Error, ValueError):
        return []
    return [r for r in rows if any((v or "").strip() for k, v in r.items() if k and k != "序號")]


def _known_questions(output):
    """單位事實.csv 已有的問句；讀不到回空集合。"""
    import unit_facts as uf
    try:
        return set((r.get("問題") or "").strip() for r in uf.read(os.path.dirname(os.path.abspath(output))))
    except (uf.FactsReadError, OSError):
        return set()


def errors(output):
    """表填得對不對：回傳要改的地方（空 list＝填好了）。"""
    rows = read_rows(output)
    if rows is None:
        return ["還沒有 %s（重跑繼續會打包）" % FILE]
    if not rows:
        return ["%s 還是空的：一列一個發現；看完沒發現問題也要填一列（問題類型「無問題」、處理「不用改」）" % FILE]
    found = []
    for number, row in enumerate(rows, 1):
        tag = "%s 第 %d 列" % (FILE, number)
        kind = (row.get("問題類型") or "").strip()
        action = (row.get("處理") or "").strip()
        if kind not in TYPES:
            found.append("%s：問題類型 只能寫 %s：「%s」" % (tag, "、".join(TYPES), kind))
        if action not in ACTIONS:
            found.append("%s：處理 只能寫 %s：「%s」" % (tag, "、".join(ACTIONS), action))
        if kind != "無問題" and not ((row.get("頁") or "").strip() and (row.get("問題") or "").strip()):
            found.append("%s：要寫是哪一頁、什麼問題" % tag)
        if action == "已修改" and not (row.get("說明") or "").strip():
            found.append("%s：已修改要在「說明」寫改了哪個檔、哪幾列、改成什麼" % tag)
        if action == "請人確認":
            # v1.51.0：這一句會進 單位事實.csv 給承辦回答：一題一句、照固定格式（法規追蹤也擋同一條）。
            # 已經收進單位事實的問句不再驗：舊輪做完了不能被新規則卡住（實跑真實工作區時，舊列全被擋下）
            import unit_facts as uf
            question = (row.get("問題") or "").strip()
            if question not in _known_questions(output):
                found += ["%s：%s" % (tag, problem) for problem in uf.question_problems(question)]
    return found


def done(output):
    return not errors(output)


def pending(output, settings=None):
    """這一輪還要做 AI 報告審查嗎（設定開著、表還沒填好）。"""
    return enabled(settings) and not done(output)


def export_questions(output, workspace, convert=None):
    """處理寫「請人確認」的發現 → 工作區 匯入/單位事實.csv 加一列等承辦回答（v1.19.0）。回傳加了幾列。"""
    import unit_facts as uf
    questions = []
    for row in read_rows(output) or []:
        if (row.get("處理") or "").strip() == "請人確認":
            where = "／".join(filter(None, [(row.get("頁") or "").strip(), (row.get("位置") or "").strip()]))
            text = (row.get("問題") or "").strip()
            questions.append((convert(text) if convert else text,
                              "AI報告審查 %s %s" % (os.path.basename(os.path.normpath(output)), where)))
    return uf.add_questions(workspace, questions)


EXPERIENCE = "報告審查經驗.json"
EXPERIENCE_LIMIT = 15


def _experience_path():
    import precedents as pc
    return os.path.join(pc.folder(), EXPERIENCE)


def remember_findings(output, kind):
    """審查填好之後：有問題的發現（不是「無問題」）累積進 memoization/內部知識/報告審查經驗.json（v1.20.0）。
    同一流程、同一類、同一句問題算同一則，記在哪幾輪出現過；同一輪重跑不重複算。回傳這一輪記了幾則。"""
    from _common import tw_now, tw_today
    import json
    path = _experience_path()
    import precedents as pc
    table = pc.read_json(path, [])              # BOM 也收；壞檔改名留著，不蓋掉
    by_key = dict((r.get("鍵"), r) for r in table if isinstance(r, dict) and r.get("鍵"))
    round_name = os.path.basename(os.path.normpath(output))
    unit = pc.current_unit()
    today = tw_today().isoformat()
    count = 0
    for row in read_rows(output) or []:
        problem_type = (row.get("問題類型") or "").strip()
        problem = re.sub(r"\s+", " ", (row.get("問題") or "").strip())
        if problem_type in ("", "無問題") or not problem:
            continue
        # 鍵不含編號、段次、數字：「段115 引用舊版」跟「段121 引用舊版」是同一種問題
        general = re.sub(r"[A-Za-z]*\d+(?:[-–]\d+)?", "#", problem)[:80]
        key = pc.own_key(by_key, "%s｜%s｜%s" % (kind, problem_type, general), unit)      # v1.54.0：不混進別單位那一則
        entry = by_key.setdefault(key, {"鍵": key, "流程": kind, "頁": (row.get("頁") or "").strip(),
                                        "問題類型": problem_type, "問題": problem[:200], "處理": "",
                                        "出現輪次": [], "第一次": today, pc.UNIT: unit})
        if round_name not in entry["出現輪次"]:
            entry["出現輪次"] = (entry["出現輪次"] + [round_name])[-20:]
            count += 1
        entry["最後一次"] = today
        entry["處理"] = (row.get("處理") or "").strip()
    if count:
        os.makedirs(os.path.dirname(path), exist_ok=True)
        rows = sorted(by_key.values(), key=lambda r: (-len(r["出現輪次"]), r.get("最後一次", "")), reverse=False)
        with io.open(path + ".tmp", "w", encoding="utf-8") as f:
            json.dump(rows, f, ensure_ascii=False, indent=1)
        replace_file(path + ".tmp", path)
    return count


def experience_lines(kind, limit=EXPERIENCE_LIMIT):
    """以前這個流程審查發現過的問題（出現越多輪的排越前面）：審查包、評分標準附給 AI 先避開。"""
    import json
    import precedents as pc
    table = pc.read_json(_experience_path(), [])
    unit = pc.current_unit()
    rows = [r for r in table if isinstance(r, dict) and r.get("流程") == kind and pc.unit_visible(r, unit)]
    rows.sort(key=lambda r: (-len(r.get("出現輪次") or []), r.get("最後一次", "")))
    return ["- 〔%s〕%s（%s；出現過 %d 輪）" % (r.get("問題類型", ""), r.get("問題", ""), r.get("頁", ""),
                                          len(r.get("出現輪次") or [])) for r in rows[:limit]]


def todo_line(command, report="比對報告"):
    return ("%s（由 AI 自動完成，不用人填表）：AI 照 產出/2_Log檔案/%s/%s 把%s整份看一遍，"
            "發現的問題填進 %s（資料錯了就直接改 AI 表），再跑 %s" % (TODO_PREFIX, FOLDER, PACK, report, FILE, command))


# ---------------------------------------------------------------------------
# 審查包
# ---------------------------------------------------------------------------

_CHECKS = [
    "判定、分數、標籤、理由說的是同一件事；理由沒有前後矛盾（例如總表寫「適用」，理由卻還說「要確認適不適用」）。",
    "同一段被好幾列各判一次時，說法有沒有互相打架（一列「建議修改」、一列「需再檢查」講同一件事）；可以合併的有沒有重複列。",
    "理由、建議處理裡寫了報告上查不到的編號或程式用語（例如事件ID、列ID、C3），讀的人對不回去。",
    "建議處理具不具體：要改的寫了改成什麼、改哪一段；要確認的寫了問誰、確認什麼。",
    "明明 AI 自己查得到、核對得了的事，卻寫成「請確認」丟給人（例如兩則公告是不是同一份令，字號一比就知道）。",
    "法規原文、規章、段次、段落原文對得上；引用的條號、日期、字號沒有抄錯。",
    "該出現的有沒有漏：來源失敗或查不到有沒有交代、明顯相關的段落或規定有沒有沒列到。",
    "讀的人看不懂的用語、太長或繞口的句子、只有程式看得懂的寫法。",
]

_HINTS = {
    "法規追蹤": [
        "報告只有「依段落彙整」「段次總表」兩頁；法規適用總表、法規影響報告、來源查詢狀態在法規追蹤明細，"
        "核對時用 `看報告 --檔 法規追蹤明細 --頁 <頁名> --全部` 看。",
        "「法規適用總表」的適用判斷跟「法規影響報告」各列的理由要一致；同一則公告底下同一份文件的不同格式（沒有條號）"
        "只留一條判，其他判「重複」（理由寫「同 Lxx」）；內容不同的文件（範本、問答集）可以各自判適用，不是錯；逐條版（有條號）各自判適用，不判重複。",
        "「依段落彙整」一段一列（引用版本過時的段也在這裡）：看每一段的建議改法合起來是不是一個人照著就能改，"
        "理由有沒有同一句寫好幾次。",
        "「來源查詢狀態」的缺口（抓不到、被擋、期間外）有沒有在 AI補查紀錄.csv 交代查了什麼、結果如何。",
    ],
    "比對": [
        "「條文比對報告」：修改處與候選段的判定、改法要對得上；同一段被好幾處修改各判一次時說法要一致。"
        "同一處修改收成一列，判定和分數是最高的那一段；每一段原本那一列在「各段明細」，核對時兩頁都要看。",
        "「條文檢查報告」「引用檢查報告」：查證來源、法規名稱與條號要對得上。",
    ],
    "體檢": [
        "「條文比對報告」的重複／矛盾、錯漏字：兩段原文與判定要對得上，改法要具體。",
        "「引用檢查報告」：引用的法規名稱、條號、查證來源要對得上；法規更新檢視的列跟適用判斷一致。",
    ],
}

_FIX_WHERE = {
    "法規追蹤": "AI法規適用.csv、AI法規影響.csv（規則照 評分標準.md）",
    "比對": "各本的 AI 表（見 先讀我.md 列的那幾張，規則照 評分標準.md）",
    "體檢": "各本的 AI 表與整批的 AI一致性.csv、AI錯漏字.csv、AI法規適用.csv、AI法規影響.csv（規則照 評分標準.md）",
}


def _sheets_with_hidden(report_path):
    """[(頁名, 列 list[list[str]], 收起來的列號 set)]。不靠套件（.xlsx 是 zip 裡幾個 XML，跟 _common.read_xlsx_rows 同一套）。"""
    import xml.etree.ElementTree as ET
    import zipfile
    import _common as cm
    found = []
    with zipfile.ZipFile(report_path) as archive:
        shared = cm._xlsx_shared_strings(archive)
        workbook = ET.fromstring(archive.read("xl/workbook.xml"))
        for node in workbook.findall("m:sheets/m:sheet", cm._XLSX_NS):
            name = node.get("name")
            tree = ET.fromstring(archive.read(cm._xlsx_sheet_part(archive, name)))
            rows, hidden = [], set()
            for row in tree.findall(".//m:sheetData/m:row", cm._XLSX_NS):
                if row.get("hidden") in ("1", "true"):
                    hidden.add(int(row.get("r") or len(rows) + 1))
                cells = {}
                for position, cell in enumerate(row.findall("m:c", cm._XLSX_NS)):
                    ref = cell.get("r") or ""
                    index = cm._xlsx_col_index(ref) if ref else position
                    kind = cell.get("t")
                    if kind == "s":
                        value = cell.find("m:v", cm._XLSX_NS)
                        text = shared[int(value.text)] if value is not None and value.text else ""
                    elif kind == "inlineStr":
                        inline = cell.find("m:is", cm._XLSX_NS)
                        text = "".join(t.text or "" for t in inline.findall(".//m:t", cm._XLSX_NS)) if inline is not None else ""
                    else:
                        value = cell.find("m:v", cm._XLSX_NS)
                        text = value.text if value is not None and value.text is not None else ""
                    cells[index] = text
                rows.append([cells.get(i, "") for i in range((max(cells) + 1) if cells else 0)])
            found.append((name, rows, hidden))
    return found


_ID_IN_TEXT = re.compile(r"(?<![A-Za-z0-9])(?:[CLRK]\d+(?:-\d+)?)(?![\d])")


def auto_findings(report_path, limit=40):
    """v1.19.0：程式先把整份報告掃一遍，列出可疑的地方給 AI 確認（三條流程的報告都適用）：
    1. 同一頁、同一條法規（或同一處修改）底下，文字幾乎一樣的段落，判定卻不同
    2. 判定理由、建議處理裡出現讀的人對不回去的程式編號（C3、L12、L1-14）"""
    import difflib
    try:
        sheets = _sheets_with_hidden(report_path)
    except Exception:
        return []
    found = []
    for title, rows, hidden in sheets:
        if title in SKIP_SHEETS or len(rows) < 2:
            continue
        header = rows[0]

        def col(*names):
            # v1.23.0：照名字的先後找，先找一模一樣的欄名，再找「包含」：以前照表頭順序找包含的，
            # 法規影響報告挑到「法規原文」（同一條法規都一樣，整個檢查被跳過）、條文比對報告挑到「修改前原文」
            for n in names:
                if n in header:
                    return header.index(n)
            for n in names:
                hit = next((i for i, h in enumerate(header) if n in h), None)
                if hit is not None:
                    return hit
            return None
        spots = [(col(b), col(s)) for b, s in (("規章A", "段次A"), ("規章B", "段次B"), ("修改規章", "修改段次"),
                                              ("候選規章", "候選段次"), ("規章", "段次"))]
        spots = [(b, s) for b, s in spots if s is not None and "段次" in header[s]]

        def where(row):
            # v1.25.0：疑點寫 規章＋段次（以前寫「第 72 列」：那是 Excel 的列號，跟報告的序號差一，讀的人對不回去）
            parts = []
            for b, s in spots:
                line = row[s] if s < len(row) else ""
                name = _short_book(row[b] if b is not None and b < len(row) else "")
                if line and (name, line) not in parts:
                    parts.append((name, line))
            books = {}
            for name, line in parts:                 # 同一本的段次寫在一起：「07.陸-風險管理篇 段511、段535」
                books.setdefault(name, []).append("段%s" % line)
            return ("；".join(("%s %s" % (name, "、".join(lines))).strip() for name, lines in books.items())
                    or "序號 %s" % (row[0] if row else ""))
        verdict = col("AI判定", "最高判定", "判定")
        text = col("段落原文", "候選段落原文", "原文A", "原文")
        group = col("法規名稱", "相關法規", "修改段次", "修改處", "異動")
        book = col("規章")          # 只比同一本（不同本的同一句話背景不同）
        reason_cols = [i for i, h in enumerate(header) if any(n in h for n in ("理由", "建議處理", "建議改法"))]
        id_cols = [i for i, h in enumerate(header) if h in ("事件ID", "列ID", "法規異動編號")]
        shown = [(n, r) for n, r in enumerate(rows[1:], 2) if n not in hidden]
        for n, row in shown:
            for i in reason_cols:
                cell = row[i] if i < len(row) else ""
                hits = sorted(set(_ID_IN_TEXT.findall(cell or "")))
                if hits and not id_cols:
                    found.append("「%s」%s 的「%s」寫了程式編號 %s：這一頁沒有編號欄，讀的人對不回去" % (
                        title, where(row), header[i], "、".join(hits[:5])))
        if verdict is None or text is None:
            continue
        groups = {}
        for n, row in shown:
            body = re.sub(r"\s", "", row[text] if text < len(row) else "")
            if len(body) >= 20:
                key = tuple(row[c] if c is not None and c < len(row) else "" for c in (group, book))
                groups.setdefault(key, []).append((where(row), row[verdict] if verdict < len(row) else "", body))
        for items in groups.values():
            for i, (na, va, ta) in enumerate(items):
                for nb, vb, tb in items[i + 1:]:
                    if va == vb or ta == tb:
                        continue
                    matcher = difflib.SequenceMatcher(None, ta, tb, autojunk=False)
                    if matcher.real_quick_ratio() >= 0.9 and matcher.quick_ratio() >= 0.9 and matcher.ratio() >= 0.9:
                        found.append("「%s」%s（%s）跟 %s（%s）段落文字幾乎一樣，判定卻不同：確認是不是該一致"
                                     % (title, na, va, nb, vb))
        if len(found) >= limit:
            break
    return found[:limit]


def _short_book(name):
    """「07.保險代理業務手冊_陸-風險管理篇202508」→「07.陸-風險管理篇」：規章名太長，疑點裡只留編號和篇名。"""
    name = str(name or "").strip()
    head = re.match(r"^(\d+\.)", name)
    tail = re.sub(r"\d{6,8}$", "", name.rsplit("_", 1)[-1])
    return (head.group(1) if head and not tail.startswith(head.group(1)) else "") + tail if "_" in name else name


def pack(output, report_path, kind):
    """寫 LLM報告審查.md；AI報告審查.csv 沒有就建一張空表（已經有的不動）。回傳審查包路徑。"""
    os.makedirs(folder(output), exist_ok=True)
    name = os.path.basename(report_path)
    lines = ["# AI 報告審查：把這一輪的報告整份看一遍", "",
             "這一步由 AI 自動完成，不用人做。報告是：產出/1_結果彙整/%s（%s，%s 產出）。"
             % (name, kind, datetime.datetime.fromtimestamp(os.path.getmtime(report_path)).strftime("%Y-%m-%d %H:%M")
                if os.path.isfile(report_path) else "還沒產出"),
             "看報告內容用 `看報告`：先看各頁概況，再 `看報告 --頁 <頁名> --全部 --欄 全部` 看每一列每一欄、不截斷"
             "（幾頁一起看用逗號分開）；「段次總表」和「使用說明」不用審。隔離區輸出太長時畫面只留尾巴，全文在 `_隔離區/程式輸出_*.txt`，要讀那個檔才算看完。", "",
             "## 要看什麼", ""]
    lines += ["%d. %s" % (i, text) for i, text in enumerate(_CHECKS + _HINTS.get(kind, []), 1)]
    lines += ["", "以前實際發生過的錯誤整理在 skill 的 references/審查常見錯誤.md：先看一遍再審。"]
    seen = experience_lines(kind)
    if seen:
        lines += ["", "本單位以前的報告審查發現過這些問題（memoization/內部知識/報告審查經驗.json），這一輪特別看有沒有再發生："]
        lines += seen
    lines += ["", "## 查到就直接改", "",
              "這一步的目的是把報告改對，不是另外寫一份問題清單：報告不會多一頁列你的發現，承辦看到的就是改好的報告。",
              "- 判斷、分數、理由、建議改法錯了、說法打架、該列沒列：直接改 %s，"
              "跑「%s」後程式重新匯入、重出報告，改好的內容就在報告原本那一列。"
              % (_FIX_WHERE.get(kind, "AI 表"), "法規繼續" if kind == "法規追蹤" else "繼續"),
              "- 承辦要改內規的事（例如原文多一個頓號、名稱要改成全銜）：寫進那一段那一列的理由或建議改法（改 AI 表），"
              "不要只記在審查紀錄裡——紀錄承辦不會看。",
              "- 只有本行業務事實（有沒有辦某項業務、採不採用某種做法）AI 決定不了，才寫「請人確認」：會進 匯入/單位事實.csv 問承辦。",
              "- AI 表改不了的（報告格式、程式的問題）：記「不用改」、說明寫建議程式怎麼改（給開發的人看）。",
              "",
              "## 審查紀錄 %s 怎麼填" % FILE, "",
              "放在 2_Log檔案/AI審查/，是這一輪 AI 看過報告的紀錄，不會出現在報告上。"
              "一列一個發現；看完沒發現問題，也要填一列（問題類型「無問題」、處理「不用改」）。",
              "- 頁：工作表名稱；位置：寫規章＋段次（例：壹篇 段115），或法規名稱＋條號。"
              "不要只寫序號、L12 這種編號：報告重出序號會重排、下一輪 L 編號會重編，記下來的問題會指錯。",
              "- 問題類型：%s。" % "、".join(TYPES),
              "- 處理：",
              "  - 已修改：已經直接改了 %s，「說明」寫改了哪個檔、哪幾列、改成什麼。" % _FIX_WHERE.get(kind, "AI 表"),
              "  - 請人確認：AI 決定不了的（要問承辦、要看內部文件）。「問題」要寫成一句只問一件事：請問本行是否…？（是／否／說明）；AI 自己的備忘不要寫在這裡。",
              "  - 不用改：只是記錄，例如報告格式、程式的建議（「說明」寫建議怎麼改）。",
              "",
              "填完跑「%s」：程式檢查這張表；AI 表改過就重新匯入，再重出報告。"
              % ("法規繼續" if kind == "法規追蹤" else "繼續"), "",
              ]
    flagged = auto_findings(report_path)
    if flagged:
        lines += ["## 程式先掃出來的疑點（每一個都要看：真的有問題就照上面處理，沒問題也在表上記一列「不用改」說明為什麼）", ""]
        lines += ["- " + item for item in flagged] + [""]
    path = pack_path(output)
    with io.open(path, "w", encoding="utf-8") as f:
        f.write("\n".join(lines) + "\n")
    if not os.path.isfile(table_path(output)):
        with io.open(table_path(output), "w", encoding="utf-8-sig", newline="") as f:
            csv.writer(f, quoting=csv.QUOTE_ALL).writerow(HEADER)
    return path


def sheet(output):
    """審查紀錄整理成 (頁名, 表頭, 列)；這一輪沒做（或關掉、還沒填）回 None。
    v1.27.0 起報告不再放這一頁（查到直接改）；留著給要另外看紀錄的人用。"""
    rows = read_rows(output)
    if not rows:
        return None
    body = []
    for number, row in enumerate(rows, 1):
        body.append([str(number)] + [(row.get(column) or "").strip() for column in HEADER[1:]])
    return SHEET, list(HEADER), body


def sheet_options():
    return {"freeze_header": True, "freeze_columns": 0, "auto_filter": True, "row_styles": {}, "hidden_rows": [],
            "links": [], "column_widths": list(WIDTHS)}
