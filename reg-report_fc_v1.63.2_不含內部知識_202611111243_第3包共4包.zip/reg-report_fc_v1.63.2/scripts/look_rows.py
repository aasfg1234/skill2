"""唯讀查看審查列；資料缺漏時顯示可讀部分，絕不猜測來源文件。"""
import csv
import glob
import json
import os
import re

import decision_table as dt
import review_pack as rp
import workspace
from _common import BATCH_RESERVED, SYSTEM_DIR, locate, open_csv


def _json(path, default):
    try:
        with open(path, encoding="utf-8-sig") as source:
            return json.load(source)
    except (OSError, ValueError, UnicodeError):
        return default


def _csv(path):
    try:
        with open_csv(path) as source:
            return list(csv.DictReader(source))
    except (OSError, UnicodeError, csv.Error):
        return []


def _pack_blocks(outdir):
    """保留審查包記下的實際 C 編號，包括定義連動及跨本來源。"""
    paths = set(glob.glob(os.path.join(outdir, "LLM審查包_*.md")))
    paths.update(glob.glob(os.path.join(outdir, SYSTEM_DIR, "LLM審查包_*.md")))
    blocks = {}
    for path in sorted(paths):
        try:
            with open(path, encoding="utf-8-sig") as source:
                content = source.read()
        except (OSError, UnicodeError):
            continue
        matches = list(re.finditer(r"(?m)^## (R[1-9]\d*)\b[^\n]*", content))
        for i, match in enumerate(matches):
            text = content[match.start():matches[i + 1].start() if i + 1 < len(matches) else len(content)].strip()
            blocks.setdefault(match.group(1), []).append((os.path.basename(path), text))
    return blocks


def _list_blocks(outdir, filename, prefix):
    path = locate(outdir, filename)[0]
    try:
        with open(path, encoding="utf-8-sig") as source:
            content = source.read()
    except (OSError, UnicodeError):
        return {}
    matches = list(re.finditer(r"(?m)^## (" + prefix + r"[1-9]\d*)\b[^\n]*", content))
    return {m.group(1): content[m.start():matches[i + 1].start() if i + 1 < len(matches) else len(content)].strip()
            for i, m in enumerate(matches)}


def _books(output):
    found = {}
    for parent in (os.path.join(output, SYSTEM_DIR), output):
        if not os.path.isdir(parent):
            continue
        for name in os.listdir(parent):
            path = os.path.join(parent, name)
            if name in BATCH_RESERVED or not os.path.isdir(path) or name in found:
                continue
            probes = ("連帶決定表.csv", "異動清單.json", "LLM異動清單.md", "條文檢查待查證.json",
                      "LLM條文檢查清單.md", "AI候選判斷.csv", "AI異動審查.csv", "AI條文檢查.csv")
            if any(os.path.isfile(locate(path, filename)[0]) for filename in probes) or _pack_blocks(path):
                found[name] = path
    return found


def _allowed_document(name):
    return (isinstance(name, str) and os.path.basename(name) == name
            and os.path.splitext(name)[1].lower() in rp.SUPPORTED_EXTS
            and not re.search(r"(?i)(^\.env|\.secret|keys.*\.json$|\.pem$|\.key$|^auth\.json$|sinopac|shioaji)", name))


def _paragraphs(outdir, sidecar, version):
    """只讀指紋指明的留底；不以檔名相似或段次猜一份文件。"""
    inputs = locate(outdir, "輸入")[0]
    fingerprint = _json(os.path.join(inputs, "輸入指紋.json"), {})
    if not isinstance(fingerprint, dict):
        return [], ""
    roles = fingerprint.get("角色") or {}
    anchor = sidecar.get("草稿" if version == "new" else "舊版") or {}
    roles = roles if isinstance(roles, dict) else {}
    anchor = anchor if isinstance(anchor, dict) else {}
    name = anchor.get("檔名") or ""
    if roles:
        staged = ("新版_" + name) if version == "new" and name else ""
        name = staged if staged and staged in fingerprint else (roles.get("新版" if version == "new" else "舊版") or "")
    elif version == "old":
        # 舊版指紋沒有角色，檔名無法唯一確定時不能把別的文件當現行版。
        draft = (sidecar.get("草稿") or {}).get("檔名") or ""
        names = [n for n in fingerprint if _allowed_document(n) and n != draft]
        name = names[0] if len(names) == 1 else ""
    if name and not _allowed_document(name):
        return [], ""
    path = os.path.join(inputs, name) if name else ""
    expected = anchor.get("SHA256") or fingerprint.get(name)
    if not os.path.isfile(path) or (isinstance(expected, str) and expected and dt.file_sha256(path) != expected):
        # 留底改名後只按內容指紋找回；沒有指紋則絕不猜。
        if not isinstance(expected, str) or not expected or not os.path.isdir(inputs):
            return [], ""
        path = ""
        for candidate in sorted(os.listdir(inputs)):
            if not _allowed_document(candidate):
                continue
            proposed = os.path.join(inputs, candidate)
            if os.path.isfile(proposed) and dt.file_sha256(proposed) == expected:
                path, name = proposed, candidate
                break
        if not path:
            return [], ""
    # 讀檔提醒（追蹤修訂、內容控制項…）比對時已經印過；查詢只要段落，不再重印。
    # 跨本引用要靠新舊段落找改號的異動，所以 Word 留底照讀（v1.62.0）。
    from _common import quiet_read_notices
    quiet = quiet_read_notices(True)
    try:
        paragraphs, kinds = rp.read_paragraphs_with_kinds(path)
        return rp.structure_paragraphs(paragraphs, kinds), name
    except (OSError, UnicodeError, ValueError, SystemExit):
        return [], ""
    finally:
        quiet_read_notices(quiet)


def _load(outdir):
    rows_path = locate(outdir, "連帶決定表.csv")[0]
    rows = _csv(rows_path)
    changes = _json(locate(outdir, "異動清單.json")[0], None)
    checks = _json(locate(outdir, "條文檢查待查證.json")[0], None)
    sidecar = _json(dt.sidecar_path_for(locate(outdir, "連帶決定表.csv")[0]), {})
    if not isinstance(sidecar, dict):
        sidecar = {}
    definitions = {(str(x.get("候選段次") or ""), x.get("候選全文SHA256") or ""): x.get("來源") or []
                   for x in sidecar.get("定義來源") or [] if isinstance(x, dict)}
    for row in rows:
        key = (str(row.get("候選段次") or ""), dt.text_sha256(row.get("候選全文") or ""))
        if key in definitions:
            row["_定義來源異動"] = definitions[key]
    new, new_name = _paragraphs(outdir, sidecar, "new")
    old, old_name = _paragraphs(outdir, sidecar, "old")
    return {"outdir": outdir, "rows": rows, "rows_missing": not os.path.isfile(rows_path), "changes": changes if isinstance(changes, list) else [],
            "changes_missing": not isinstance(changes, list), "checks": checks if isinstance(checks, list) else [],
            "checks_missing": not isinstance(checks, list), "new": new, "old": old,
            "new_paragraphs": new, "old_paragraphs": old,
            "new_name": new_name, "old_name": old_name, "packs": _pack_blocks(outdir),
            "change_blocks": _list_blocks(outdir, "LLM異動清單.md", "C"),
            "check_blocks": _list_blocks(outdir, "LLM條文檢查清單.md", "K")}


def _short(text, filename, number):
    text = str(text or "")
    return text if len(text) <= 1500 else text[:1500] + "…（全文見 %s 段 %s）" % (filename or "來源檔案", number or "未知")


def _number(value):
    try:
        return int(value)
    except (TypeError, ValueError):
        return 0


def _context(book, version, number, fallback="", filename=""):
    paragraphs = book[version]
    if not 1 <= number <= len(paragraphs):
        # 早期工作區有時只保留審查包；印包內實際記下的鄰段，不把別份留底當成原文。
        context = fallback.split("前後文", 1)[-1] if "前後文" in fallback else ""
        found = []
        for match in re.finditer(r"(?m)^\s*(\d+)　([^\n]*)", context):
            n = int(match.group(1))
            if n in (number - 1, number + 1):
                found.append("段 %d：%s" % (n, _short(match.group(2), filename, n)))
        if found:
            print("前後文（取自 %s）：" % filename)
            print("\n".join(found))
        else:
            print("前後文：無法取得對應的%s留底或段次" % ("新版" if version == "new" else "舊版"))
        return
    filename = book[version + "_name"]
    print("前後文（%s）：" % ("新版" if version == "new" else "舊版"))
    for n in (number - 1, number + 1):
        if 1 <= n <= len(paragraphs):
            print("段 %d：%s" % (n, _short(paragraphs[n - 1], filename, n)))


def _pack_refs(book, rid):
    refs = []
    in_changes = False
    pending = ""

    def add(line):
        match = re.match(r"^- (?:(.+?) )?(C[1-9]\d*)\b", line)
        if match:
            pair = (match.group(1) or "", match.group(2))
            if pair not in refs:
                refs.append(pair)
        return bool(match)

    for _, block in book["packs"].get(rid, []):
        # 續篇重複候選標題，不重複「對應異動」標題；區段狀態須跨篇保留。
        for line in block.splitlines()[1:]:
            if line.startswith("### 對應異動"):
                if pending:
                    add(pending)
                in_changes = True
                pending = ""
            elif line.startswith("### "):
                if pending:
                    add(pending)
                in_changes = False
                pending = ""
            elif in_changes:
                if line.startswith("- "):
                    if pending:
                        add(pending)
                    pending = line
                elif pending and line:
                    # _split_block 也可能把一個過長的來源本名稱切在行中間。
                    pending += line
    if pending:
        add(pending)
    return refs


def _refs(book, rid, books):
    refs = _pack_refs(book, rid)
    if refs:
        n = _number(rid[1:])
        row = book["rows"][n - 1] if 1 <= n <= len(book["rows"]) else {}
        pieces = [p.strip() for p in (row.get("異動條文ID") or "").split("；") if p.strip()]
        if "跨本引用" in (row.get("來源") or "") and pieces:
            # 舊審查包可能只印 C9；若決定表只指向別本，絕不能把它當成候選本的 C9。
            named = [p.split("：", 1)[0] for p in pieces if "：" in p]
            if len(named) == len(pieces):
                unique = set(named)
                refs = [(source or next(iter(unique)), cid) if source or len(unique) == 1 else (None, cid)
                        for source, cid in refs]
                refs = [(source, cid) for source, cid in refs if source is not None]
        return refs
    n = _number(rid[1:])
    if not 1 <= n <= len(book["rows"]):
        return []
    refs = []
    for name, change in rp.changes_for_row(book["rows"][n - 1], book, books):
        data = books[name] if name else book
        idx = rp.change_number(change, data)
        if idx:
            refs.append((name, "C%d" % idx))
    return refs


def _answer(output, name, book, filename, key, rid):
    import ai_tables
    merged = os.path.join(output, SYSTEM_DIR, "AI審查", filename)
    combined = next((r for r in _csv(merged) if r.get("規章") == name and r.get(key) == rid), None)
    local = next((r for r in _csv(locate(book["outdir"], filename)[0]) if r.get(key) == rid), None)
    columns = next((cols for file, _, cols in ai_tables.SPECS if file == filename), ())

    def display(row):
        values = ["%s：%s" % (k, _short(v, filename, rid)) for k, v in (row or {}).items()
                  if k in columns + ("沿用查證",) and v]
        return "；".join(values) if values else "（尚無）"

    if combined is None or local is None:
        print("目前表上答案：" + display(local if combined is None else combined))
        return
    record = _json(os.path.join(output, SYSTEM_DIR, "AI審查", ai_tables.RECORD), {})
    before = record.get(filename, {}) if isinstance(record, dict) else {}
    recorded = before.get("列", {}).get(ai_tables._key(name, rid)) if isinstance(before, dict) and isinstance(before.get("列"), dict) else None
    fingerprints = before.get("指紋", {}) if isinstance(before, dict) else {}
    fingerprint = fingerprints.get(ai_tables._key(name, rid)) if isinstance(fingerprints, dict) else None
    valid = (isinstance(recorded, dict) and
             (not fingerprint or (ai_tables._fingerprint(combined, columns) == fingerprint and
                                  ai_tables._fingerprint(local, columns) == fingerprint)))
    if not valid:
        if all(ai_tables._s(combined.get(c)) == ai_tables._s(local.get(c)) for c in columns):
            print("目前表上答案：" + display(local))
        else:
            print("目前表上答案：合一表紀錄缺漏或列指紋不符，無法確認有效答案")
            print("各本表：" + display(local))
            print("合一表：" + display(combined))
        return
    effective = dict(local)
    for column in columns:
        value = ai_tables._s(combined.get(column))
        if value != recorded.get(column, ""):
            effective[column] = value
    print("目前表上答案：" + display(effective))


def _change(name, rid, book, books, output, reverse=True):
    n = _number(rid[1:])
    block = book["change_blocks"].get(rid, "")
    if not 1 <= n <= len(book["changes"]):
        if not block:
            print("%s %s：異動清單.json 缺少此編號，無法取得新舊文與前後文" % (name, rid))
            return
        print("\n%s %s（取自 LLM異動清單.md；異動清單.json 缺少）" % (name, rid))
        position = re.search(r"(?:新版段次|舊版段次)\s*(\d+)", block.splitlines()[0])
        for line in block.splitlines():
            print(_short(line, "LLM異動清單.md", position.group(1) if position else "未知"))
        _answer(output, name, book, "AI異動審查.csv", "異動ID", rid)
    else:
        change = book["changes"][n - 1]
        old, new = _number(change.get("old_index")), _number(change.get("new_index"))
        print("\n%s %s　%s　%s" % (name, rid, change.get("修改類型") or "", change.get("ref") or change.get("scope") or ""))
        print("舊文：" + _short(change.get("old_text") or "（無）", book["old_name"] or "LLM異動清單.md", old))
        print("新文：" + _short(change.get("new_text") or "（無）", book["new_name"] or "LLM異動清單.md", new))
        if block:
            for line in block.splitlines():
                if line.startswith("- 程式提醒"):
                    print(line)
        elif (book.get("old_paragraphs") and book.get("new_paragraphs") and not book.get("changes_missing")
              and all(not c.get(key) or (isinstance(c[key], int) and 0 < c[key] <= len(book[paragraphs]))
                      for c in book["changes"] for key, paragraphs in
                      (("old_index", "old_paragraphs"), ("new_index", "new_paragraphs")))):
            if "old_contexts" not in book:
                book["old_contexts"] = rp.build_hierarchy(book["old_paragraphs"])
            if "new_contexts" not in book:
                book["new_contexts"] = rp.build_hierarchy(book["new_paragraphs"])
            for reminder in rp._change_reminders(change, book):
                print(reminder)
        else:
            print("無法確認是否有程式提醒")
        move = change.get("移列") or {}
        if isinstance(move, dict) and move:
            note = move.get("說明") or "；".join("%s：%s" % (key, move[key]) for key in
                                                 ("方向", "對應條號", "對應段次", "內容相同") if key in move)
            if note:
                print("移列資訊：" + _short(note, "LLM異動清單.md", new or old))
        focus = rp._focus_line(change)
        if focus:
            print("異動重點：" + _short(focus, "LLM異動清單.md", new or old))
        if old:
            _context(book, "old", old, block if not new else "", "LLM異動清單.md")
        if new:
            _context(book, "new", new, block, "LLM異動清單.md")
        _answer(output, name, book, "AI異動審查.csv", "異動ID", rid)
    if reverse:
        related = []
        incomplete = []
        for other_name, other in books.items():
            if other["rows_missing"]:
                incomplete.append(other_name)
            ids = set(other["packs"]) | {"R%d" % i for i in range(1, len(other["rows"]) + 1)}
            for other_rid in sorted(ids, key=lambda x: _number(x[1:])):
                if any((source or other_name) == name and cid == rid for source, cid in _refs(other, other_rid, books)):
                    related.append("%s %s（對應 %s %s）" % (other_name, other_rid, name, rid))
        print("牽連候選：" + ("、".join(related) if related else "（無）"))
        if incomplete:
            print("候選資料缺漏，無法確認：" + "、".join(incomplete))


def _candidate(name, rid, book, books, output):
    n = _number(rid[1:])
    if 1 <= n <= len(book["rows"]):
        row = book["rows"][n - 1]
        line = _number(row.get("候選段次"))
        print("\n%s %s　候選段 %s" % (name, rid, line or "未知"))
        pack = book["packs"].get(rid, [])
        source = book["new_name"] or (pack[0][0] if pack else "連帶決定表.csv")
        print("候選全文：" + _short(row.get("候選全文") or "（缺少）", source, line))
        _context(book, "new", line, "\n".join(b for _, b in pack), pack[0][0] if pack else "LLM審查包")
    else:
        print("\n%s %s：連帶決定表缺少此列，以下為審查包內容" % (name, rid))
        for filename, block in book["packs"].get(rid, []):
            position = re.search(r"候選段次\s*(\d+)", block.splitlines()[0])
            for text in block.splitlines():
                print(_short(text, filename, position.group(1) if position else "未知"))
    _answer(output, name, book, "AI候選判斷.csv", "列ID", rid)
    refs = _refs(book, rid, books)
    if not refs:
        print("對應異動：無法取得（請核對審查包或異動清單）")
    for source, cid in refs:
        source = source or name
        if source not in books:
            print("來源本缺少：%s %s" % (source, cid))
        else:
            _change(source, cid, books[source], books, output, reverse=False)


def _check(name, rid, book, output):
    n = _number(rid[1:])
    if not 1 <= n <= len(book["checks"]):
        print("\n%s %s（取自 LLM條文檢查清單.md；條文檢查待查證.json 缺少）" % (name, rid))
        for line in book["check_blocks"][rid].splitlines():
            print(_short(line, "LLM條文檢查清單.md", "未知"))
        _answer(output, name, book, "AI條文檢查.csv", "檢查ID", rid)
        return
    item = book["checks"][n - 1]
    line = _number(item.get("index"))
    print("\n%s %s　段 %s" % (name, rid, line or "未知"))
    for label, key in (("檢查項目", "check"), ("程式發現", "detail"), ("相關原文", "quote"), ("程式建議", "action")):
        print(label + "：" + _short(item.get(key) or "（無）", book["new_name"] or "LLM條文檢查清單.md", line))
    if 1 <= line <= len(book["new"]):
        print("原文：" + _short(book["new"][line - 1], book["new_name"], line))
    else:
        block = book["check_blocks"].get(rid, "")
        match = re.search(r"(?m)^新版這一段：\s*\n(?:\s*\n)*((?:>[^\n]*(?:\n|$))+)", block)
        if match:
            original = "\n".join(re.sub(r"^> ?", "", text) for text in match.group(1).splitlines())
            print("原文（取自 LLM條文檢查清單.md）：" + _short(original, "LLM條文檢查清單.md", line))
        else:
            print("原文缺漏：找不到新版留底及條文檢查清單中的完整原文")
    _answer(output, name, book, "AI條文檢查.csv", "檢查ID", rid)


def look_rows(args, settings):
    try:
        if len(args.rows) > 20:
            print("[中止] 一次最多 20 個編號")
            return 1
        ids = [value.upper() for value in args.rows]
        invalid = [value for value in ids if not re.fullmatch(r"[RCK][1-9]\d*", value)]
        if invalid:
            print("[中止] 編號格式不對：" + "、".join(invalid))
            return 1
        root = workspace.resolve_root(args.workspace, settings)
        output = workspace.current_output(root)
        if not output or not os.path.isdir(output):
            print("[中止] 找不到目前作業的產出資料夾")
            return 1
        paths = _books(output)
        names = [name for name in paths if args.book.casefold() in name.casefold()]
        if args.book in paths:
            names = [args.book]
        if len(names) != 1:
            print("[中止] 規章%s：%s" % ("不唯一" if names else "找不到", "、".join(names) if names else args.book))
            return 1
        name = names[0]
        books = {key: _load(path) for key, path in paths.items()}
        book = books[name]
        for rid in ids:
            kind, n = rid[0], _number(rid[1:])
            count = len(book["rows"]) if kind == "R" else len(book["changes"] if kind == "C" else book["checks"])
            known = book["packs"] if kind == "R" else book["change_blocks"] if kind == "C" else book["check_blocks"]
            total = max([count] + [_number(x[1:]) for x in known])
            exists = 1 <= n <= count or rid in known
            if not exists:
                missing = (kind == "C" and book["changes_missing"]) or (kind == "K" and book["checks_missing"])
                print("找不到：%s（%s）" % (rid, "來源檔缺少，無法確認編號範圍" if missing else "這本的 %s 編號到 %s%d" % (kind, kind, total)))
            elif kind == "R":
                _candidate(name, rid, book, books, output)
            elif kind == "C":
                _change(name, rid, book, books, output)
            else:
                _check(name, rid, book, output)
        return 0
    except Exception as exc:
        # 不交給總入口的中止通知：那條路會把提醒寫進工作區。
        print("[中止] 無法讀取審查資料（%s）：%s" % (type(exc).__name__, exc))
        return 1
