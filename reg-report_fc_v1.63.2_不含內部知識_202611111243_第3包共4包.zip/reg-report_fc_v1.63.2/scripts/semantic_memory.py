# -*- coding: utf-8 -*-
"""這台電腦不能算語意的記憶（v1.56.0，審查三 H2）。

語意預設開；沒模型或模型壞掉時，第一次失敗要記住，下個工作區不再白走一輪。記兩個地方：

  本機紀錄  %LOCALAPPDATA%\\reg-report\\語意狀態.json（跟 skill路徑.cmd 同一處，不會被打包）。
            以它為準，簽章綁這台的套件與模型檔狀態：裝好、換檔就對不上，自動恢復。
  設定.html 最上層「語意本機狀態」：{電腦碼: {狀態, 原因, 時間}}，給隔離區看。隔離區看不到本機，
            每次帶入的只有設定.html。不放路徑；電腦碼是隨機碼（存在本機，算不回電腦名稱）；分享、打包都不帶（share.py）。

只有這一支知道記憶的格式；run_all、isolated_runner、local_request、semantic_candidates 都呼叫這裡。
算到一半失敗、記憶體不足不記：那是這一輪的狀況，下一輪可能就好了。
"""
import datetime
import hashlib
import importlib.metadata
import importlib.util
import io
import json
import os
import re
import secrets
import sys

KEY = "語意本機狀態"
LOCAL_DIR, LOCAL_FILE = "reg-report", "語意狀態.json"
COMPUTER_FILE = "電腦代號.txt"           # 同一個資料夾：隨機碼，第一次要用時才建
OFF_ENV = "REG_NO_SEMANTIC_MEMORY"       # 測試用：全部不讀不寫（見 tests/_test_env.py）
COMPUTER_ENV = "REG_LOCAL_COMPUTER"      # 隔離區用：倉庫記的本機電腦碼（isolated_runner 帶進來）
CANNOT, CAN = "不能用", "能用"
RECHECK_DAYS = 30                        # 簽章抓不到的修復（例如補裝系統元件）：過期就再試一次，不會永遠略過
PACKAGES = ("torch", "FlagEmbedding", "sentence_transformers")
MODEL_FILES = ("config.json", "model.safetensors", "pytorch_model.bin", "colbert_linear.pt", "sparse_linear.pt")
TIME_FORMAT = "%Y-%m-%d %H:%M"
KINDS = {"缺套件": "缺語意比對要用的套件", "沒有模型": "找不到語意模型",
         "模型壞了": "語意模型檔不完整", "載入失敗": "語意模型載不起來"}


def enabled():
    return os.environ.get(OFF_ENV) != "1"


def _isolated():
    return os.environ.get("REG_ISOLATED") == "1"


def _can_write():
    """本機紀錄寫得了嗎。隔離區看不到本機；沒有 LOCALAPPDATA 的環境沒地方記，就當沒有記憶。"""
    return enabled() and not _isolated() and bool(_local_path())


def computer_id():
    """這台電腦的代號：只拿來分辨電腦。隨機產生、存在 %LOCALAPPDATA%，跟電腦名稱無關
    （以前是電腦名稱的雜湊，公司電腦名稱有規律，列舉一遍就反推得出來）。
    本機資料被清掉會換一個新的：舊代號那筆在 設定.html 留到 30 天失效，這段時間只算「另一台電腦」。"""
    path = _local_path()
    if not path:
        return ""
    folder = os.path.dirname(path)
    target = os.path.join(folder, COMPUTER_FILE)
    try:
        with io.open(target, encoding="utf-8") as f:
            value = f.read().strip()
        if re.fullmatch(r"[0-9a-f]{16}", value):
            return value
    except (OSError, UnicodeError):
        pass
    value = secrets.token_hex(8)
    from _common import write_generated
    try:
        write_generated(target, value)
    except OSError:
        pass                             # 記不住就只有這次用這個代號，不擋這一輪
    return value


def _now():
    from _common import tw_now
    return tw_now().strftime(TIME_FORMAT)


def _expired(text):
    from _common import tw_now
    try:
        then = datetime.datetime.strptime(text, TIME_FORMAT)
    except (TypeError, ValueError):
        return True
    now = tw_now().replace(tzinfo=None)
    return now - then > datetime.timedelta(days=RECHECK_DAYS)


def _local_path():
    base = os.environ.get("LOCALAPPDATA", "")
    return os.path.join(base, LOCAL_DIR, LOCAL_FILE) if base else ""


def read_local():
    path = _local_path()
    if not path:
        return None
    try:
        with io.open(path, encoding="utf-8") as f:
            data = json.load(f)
    except (OSError, ValueError):
        return None
    return data if isinstance(data, dict) and data.get("狀態") == CANNOT else None


def _write_local(record):
    from _common import write_generated
    path = _local_path()
    if path:
        try:
            write_generated(path, record)
        except OSError:
            pass                         # 記不住只是下次再白走一次，不擋這一輪


def _remove_local():
    path = _local_path()
    if path:
        try:
            os.remove(path)
        except OSError:
            pass


def _configured():
    from _common import config_section, skill_path
    return skill_path(config_section("設定").get("語意模型路徑")) or ""


def _package_stamp(name):
    """套件在不在、哪一版、什麼時候裝的。只看檔案，不 import（torch 一次要好幾秒）。"""
    try:
        spec = importlib.util.find_spec(name)
    except (ImportError, ValueError, AttributeError):
        spec = None
    if spec is None:
        return [name, ""]
    try:
        version = importlib.metadata.version(name)
    except importlib.metadata.PackageNotFoundError:
        version = "?"
    try:
        stamp = os.stat(spec.origin).st_mtime_ns
    except (OSError, TypeError, ValueError):
        stamp = 0
    return [name, version, stamp]


def signature():
    """這台電腦語意環境的指紋：Python、套件、模型路徑與模型檔大小時間。只存雜湊，看不出路徑。"""
    import semantic_candidates as sc
    configured = _configured()
    model = sc.find_local_model(configured)
    parts = [list(sys.version_info[:2]), [_package_stamp(name) for name in PACKAGES], configured, model]
    for name in MODEL_FILES if model else ():
        try:
            info = os.stat(os.path.join(model, name))
            parts.append([name, info.st_size, info.st_mtime_ns])
        except OSError:
            parts.append([name])
    return hashlib.sha256(json.dumps(parts, ensure_ascii=False).encode("utf-8")).hexdigest()[:24]


def classify(reason):
    """失敗原因的白話字串 → 分類；不該記住的（算到一半、記憶體不足）回空字串。"""
    if "算到一半" in reason or "記憶體不足" in reason:
        return ""
    if "缺套件" in reason:
        return "缺套件"
    if "權重檔" in reason or "模型設定檔" in reason:
        return "模型壞了"
    if "載不起" in reason:
        return "載入失敗"
    return ""


def diagnose():
    """沒有具體失敗訊息時（根本沒試著載）判斷是哪一類。"""
    import semantic_candidates as sc
    if not sc._importable("torch") or not (sc._importable("FlagEmbedding") or sc._importable("sentence_transformers")):
        return "缺套件"
    return "沒有模型"


def _marker_entries():
    from _common import load_config
    entries = load_config().get(KEY)
    return dict(entries) if isinstance(entries, dict) else {}


def _write_marker(entries):
    from _common import write_config_key
    try:
        write_config_key(KEY, entries)
    except (OSError, ValueError):
        pass                             # 設定.html 被鎖、不在：下次 sync 再補


def _set_own_marker(entry):
    entries = _marker_entries()
    entries[computer_id()] = entry
    _write_marker(entries)


def _clear_own_marker():
    """這台能用了：一台電腦的情況拿掉就好；別台還記著失敗時要留「能用」，隔離區才不會把別台的失敗算到這台。"""
    entries = _marker_entries()
    mine = entries.pop(computer_id(), None)
    if entries:
        if isinstance(mine, dict) and mine.get("狀態") == CAN:
            return
        entries[computer_id()] = {"狀態": CAN, "時間": _now()}
    elif mine is None:
        return
    _write_marker(entries)


def remember(kind):
    """記住這台不能算（只在本機；隔離區看不到本機，它的失敗不算數）。回傳有沒有記。"""
    if not _can_write() or kind not in KINDS:
        return False
    now = _now()
    _write_local({"狀態": CANNOT, "原因": kind, "時間": now, "簽章": signature()})
    _set_own_marker({"狀態": CANNOT, "原因": kind, "時間": now})
    return True


def forget():
    """語意算得起來了、或使用者要強制重試：這台不再算失敗。"""
    if not _can_write():
        return
    _remove_local()
    _clear_own_marker()


def _stale(record):
    return record.get("簽章") != signature() or _expired(record.get("時間"))


def sync():
    """本機每次執行先對一次：環境變了就恢復；本機有紀錄、設定.html 沒有（別的 skill 資料夾記的）就補上。
    回傳有沒有因為環境變了而恢復。沒有任何紀錄時不碰模型資料夾，也不寫檔。"""
    if not _can_write():
        return False
    record = read_local()
    if record is None:
        entries = _marker_entries()
        mine = entries.get(computer_id()) if entries else None
        if isinstance(mine, dict) and mine.get("狀態") == CANNOT:
            _clear_own_marker()          # 本機紀錄被清掉了：以本機為準，重新試
        return False
    if _stale(record):
        forget()
        return True
    mine = _marker_entries().get(computer_id())
    if not isinstance(mine, dict) or mine.get("時間") != record.get("時間"):
        _set_own_marker({"狀態": CANNOT, "原因": record.get("原因"), "時間": record.get("時間")})
    return False


def _valid(entry):
    return (isinstance(entry, dict) and entry.get("狀態") == CANNOT and entry.get("原因") in KINDS
            and not _expired(entry.get("時間")))


def _isolated_entry():
    """隔離區：設定.html 哪一筆算數。倉庫知道上次在哪台跑過就只看那一台；新工作區不知道是哪一台，
    只有全部記的都是「不能用」才算（有一台能用就照舊請人雙擊，不把別台的失敗套上來）。"""
    entries = _marker_entries()
    computer = os.environ.get(COMPUTER_ENV, "")
    if computer:
        entry = entries.get(computer)
        return entry if _valid(entry) else None
    if not entries or not all(_valid(entry) for entry in entries.values()):
        return None
    return max(entries.values(), key=lambda entry: entry["時間"])


def blocked():
    """這台記住過不能算、而且還算數：回 {原因, 時間}；要照常試就回 None。"""
    if not enabled():
        return None
    if _isolated():
        return _isolated_entry()
    record = read_local()
    if record is None or record.get("原因") not in KINDS:
        return None
    if _stale(record):
        forget()
        return None
    return record


def reason_text(known):
    return "這台電腦%s，%s 記下的" % (KINDS.get(known.get("原因"), "不能算語意"), str(known.get("時間", ""))[:10])


def skip_line(known, retry_command):
    """自動略過時畫面與批次摘要的那一行：為什麼略過、怎麼重新啟用。"""
    head = ("語意候選（BGE-M3）：這一輪自動略過語意比對（%s），結果只有文字比對，不用再雙擊或等它。"
            % reason_text(known))
    if _isolated():
        return head + ("隔離區看不到本機：模型裝好後請使用者雙擊一次 打開設定.cmd 重新檢查，"
                       "或使用者說要語意時送 " + retry_command)
    return head + "模型裝好後會自動恢復；要馬上重試：" + retry_command


def local_done_text(known):
    """本機雙擊視窗：算不了不是出錯，講清楚之後會怎樣。"""
    return ("語意比對這次算不了（%s）。這不算出錯：已記住，這一輪略過語意，比對照常往下做，以後不會再請你為它雙擊。"
            "模型裝好後雙擊一次 打開設定.cmd 就會恢復。" % reason_text(known))


def report_note(root):
    """報告「使用說明」第一列的字；這一輪語意有做就回空字串（報告不變）。"""
    import todo
    from _common import SYSTEM_DIR
    marker = os.path.join(root, SYSTEM_DIR, "語意候選", todo.SEMANTIC_SKIP)
    effect = "這份報告只有文字比對的結果：意思相近但用字不同的段落可能沒有列出，不能當成語意也查過。"
    if os.path.isfile(marker):
        reason = ""
        try:
            with io.open(marker, encoding="utf-8") as f:
                reason = next((line.strip()[3:] for line in f if line.startswith("原因：")), "")
        except OSError:
            pass
        return "這一輪略過語意比對%s。%s" % ("（%s）" % reason if reason else "", effect)
    missing = todo.semantic_pending(root)
    if missing:
        return "這一輪還有 %d 本沒做語意比對。%s" % (len(missing), effect)
    return ""
