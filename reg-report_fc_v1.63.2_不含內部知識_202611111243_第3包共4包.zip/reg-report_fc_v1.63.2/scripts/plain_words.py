# -*- coding: utf-8 -*-
import sys, io
try:
    sys.stdout.reconfigure(encoding="utf-8")
except Exception:
    if getattr(sys.stdout, "buffer", None) is not None:
        sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8")

"""把審查資料換成人看得懂文字的純函式。

本模組不讀檔、不寫檔、不改傳入資料，也不依賴專案其他模組。呼叫端可以把
決定表或審查表的一列 dict 直接傳入，再把回傳文字放到人看頁。
分數只供原流程判斷；本模組不會把分數寫進白話文字。
"""

import difflib
import re


# ---------------------------------------------------------------------------
# 程式用語 → 給承辦看的字
# ---------------------------------------------------------------------------

_TERM_WORDS = {
    "AI工作區根目錄": "內規資料夾位置",
    "工作區根目錄": "內規資料夾位置",
    "工作區": "內規資料夾",
    "本機請求單": "AI 交辦的工作",
    "請求單": "AI 交辦的工作",
    "skill 資料夾": "程式資料夾",
    "skill資料夾": "程式資料夾",
    "隔離區": "AI 的環境",
    "本機模式": "這台電腦做",
    "結束碼": "程式回報的狀態",
}
_TERM_RE = re.compile("|".join(re.escape(word) for word in sorted(_TERM_WORDS, key=len, reverse=True)))


def plain_terms(text):
    """給人看的提示句裡的程式用語換成白話（長的詞先比對，「工作區根目錄」不會只換到「工作區」）。
    只用在程式自己寫的句子；條文原文、AI 理由不要過這一支（內規裡的「工作區」可能是真的工作區）。"""
    return _TERM_RE.sub(lambda match: _TERM_WORDS[match.group(0)], _text(text))


# ---------------------------------------------------------------------------
# 判斷字與理由
# ---------------------------------------------------------------------------

_KIND_ALIASES = {
    "候選": "候選",
    "候選判斷": "候選",
    "ai候選": "候選",
    "ai候選判斷": "候選",
    "candidate": "候選",
    "異動": "異動",
    "修改": "異動",
    "異動審查": "異動",
    "ai異動": "異動",
    "ai異動審查": "異動",
    "change": "異動",
    "外部引用": "外部引用",
    "外部規章": "外部引用",
    "ai外部引用": "外部引用",
    "external": "外部引用",
    "條文檢查": "條文檢查",
    "ai條文檢查": "條文檢查",
    "檢查": "條文檢查",
    "rulecheck": "條文檢查",
}

_VERDICT_WORDS = {
    "候選": {
        "建議修改": "建議跟著改",
        "需再檢查": "請你決定",
        "不用改": "不用改",
        "沒問題": "不用改",
    },
    "異動": {
        "建議修改": "這處修改可能有問題",
        "需再檢查": "請你確認",
        "沒問題": "沒問題",
    },
    "外部引用": {
        "有誤": "這個引用可能有問題",
        "無法查證": "請你確認",
        "沒問題": "沒問題",
        "漏抓": "請你確認",
    },
    "條文檢查": {
        "有問題": "這處修改可能有問題",
        "需人確認": "請你確認",
        "沒問題": "沒問題",
    },
}

_EXTERNAL_LABEL_WORDS = {
    "引用過時": "引用要更新",
    "條號錯誤": "引用要更新",
    "本文名稱錯誤": "內文的法規名稱要更正",
    "名稱錯誤": "程式抓錯名稱，手冊不用改",
    "非外部法規": "這個引用不是外部規定",
    "正確": "沒問題",
    "未指明條號": "沒問題",
    "本批規章": "沒問題",
    "資料庫規章": "沒問題",
    "本行內規": "請你確認",
    "查無資料": "請你確認",
    "無法連網": "請你確認",
    "漏抓": "請你確認",
}

_LABEL_INTROS = {
    "候選": {
        "引用換號": "文中的引用可能已經指到別處。",
        "同義務舊值": "同一件事的舊寫法還留在別處。",
        "同義務改寫": "別處可能也在說同一件事。",
        "平行規定": "另一段有相近的規定。",
        "傾向要改": "內容看起來有關，但還需要你判斷。",
        "各半": "兩段可能有關，也可能本來就要不同。",
        "有疑點": "這段有一個需要確認的地方。",
        "事項不同": "這段說的是另一件事。",
        "對象不同": "這段適用的人或情況不同。",
        "套語命中": "這段只是剛好用了相同的常見說法。",
        "無關": "這段和這次修改無關。",
    },
    "異動": {
        "無法執行": "改完後可能無法照做。",
        "明顯錯誤": "這處文字看起來有明顯問題。",
        "改變原意": "這處打錯的字可能改變了條文的意思。",
        "文書瑕疵": "這處有文書上的錯誤，但看得出原意。",
        "同條矛盾": "同一條裡的內容可能互相打架。",
        "前後不一致": "前後內容可能不一致。",
        "可能越界": "這處修改可能超出原本可用的範圍。",
        "牴觸規定": "這處修改查證後確定超出或牴觸上位法規、主管機關規定。",
        "疑似牴觸": "這處修改可能超出或牴觸上位法規、主管機關規定，還要再確認。",
        "刪除控管": "這處修改刪掉了核准、覆核這類控管，要確認是否仍有規定要求。",
        "需查依據": "需要先查清楚依據。",
        "影響他處": "這處修改可能也影響別的作業或文件。",
        "可能的影響": "這處修改可能影響表單、系統、作業流程或其他規章，但還沒找到具體的段落。",
        "實質無疑": "這處修改看起來沒有問題。",
        "文字調整": "這是文字上的調整。",
        "更正筆誤": "這是在改正文字錯誤。",
        "純形式": "這只是格式上的調整。",
    },
    "外部引用": {
        "名稱錯誤": "程式抓錯了引用名稱，手冊原文不用改。",
        "本文名稱錯誤": "手冊本文的法規名稱需要更正。",
        "非外部法規": "程式誤把它當成外部規定，手冊不用改。",
        "引用過時": "引用可能已經不是最新版本。",
        "條號錯誤": "引用的條號可能不對。",
        "正確": "引用看起來沒有問題。",
        "未指明條號": "引用看起來沒有問題。",
        "本批規章": "引用已經核對過。",
        "資料庫規章": "引用已經用規範資料庫核對過。",
        "本行內規": "這個引用需要由內部確認。",
        "查無資料": "找不到可核對的資料。",
        "無法連網": "目前無法查資料。",
        "漏抓": "程式漏抓了這個引用，AI 已補查。",
    },
    "條文檢查": {
        "違反上位規定": "這處修改可能和上位規定不一致。",
        "需補正": "這處修改需要補正。",
        "查無依據": "上位法規裡查不到直接相關的規定。",
        "業務決定": "這件事要由業務單位決定。",
        "無法連網": "目前無法查資料。",
        "上位相符": "這處修改和上位規定相符。",
        "前後一致": "前後內容看起來一致。",
        "程式誤報": "程式誤報，這處沒有問題。",
    },
}

_FALLBACK_INTROS = {
    "候選": "這段可能和剛改的內容有關。",
    "異動": "這處修改需要再看一次。",
    "外部引用": "這個引用需要再確認。",
    "條文檢查": "這處規定需要再確認。",
}

_LABEL_PREFIX_RE = re.compile(r"^\s*〔\s*([^〕]+?)\s*〕\s*")
_SCORE_PREFIX_RE = re.compile(
    r"^\s*(?:AI\s*分數|分數)\s*[:：]?\s*(?:10|[0-9])\s*(?:分)?\s*[,，、;；:：-]*\s*",
    re.IGNORECASE,
)


def _text(value):
    """把 None 安全地轉成文字。"""
    return "" if value is None else str(value)


def _normalise_kind(kind):
    """把常見的表名或類型名收斂成四種審查類型。"""
    value = _text(kind).strip().lower()
    value = re.sub(r"\.csv$", "", value)
    value = value.replace(" ", "").replace("_", "").replace("-", "")
    if value in _KIND_ALIASES:
        return _KIND_ALIASES[value]
    if "外部" in value or "external" in value:
        return "外部引用"
    if "條文" in value or "rule" in value:
        return "條文檢查"
    if "異動" in value or "修改" in value or "change" in value:
        return "異動"
    if "候選" in value or "candidate" in value:
        return "候選"
    return ""


def _clean_label(label):
    """去掉標籤周邊的空白與全形方括號。"""
    value = _text(label).strip()
    if value.startswith("〔") and value.endswith("〕"):
        value = value[1:-1].strip()
    return value


def plain_verdict(kind, verdict, label=""):
    """把審查判斷字換成短而清楚的白話。

    ``kind`` 可用「候選」「異動」「外部引用」「條文檢查」，也可用常見表名。
    外部引用的「有誤」要看標籤；引用過時與條號錯誤會明確說「引用要更新」。
    不認得的值不會原樣露出，會安全地請人確認。
    """
    category = _normalise_kind(kind)
    value = _text(verdict).strip().replace(" ", "")
    clean_label = _clean_label(label)

    if category == "外部引用" and clean_label in _EXTERNAL_LABEL_WORDS:
        return _EXTERNAL_LABEL_WORDS[clean_label]
    if category and value in _VERDICT_WORDS[category]:
        return _VERDICT_WORDS[category][value]
    if category == "候選":
        return "請你決定"
    return "請你確認"


def _split_reason(reason):
    """回傳（前端標籤、去標籤後理由）。"""
    body = _text(reason).strip()
    match = _LABEL_PREFIX_RE.match(body)
    label = ""
    if match:
        label = match.group(1).strip()
        body = body[match.end():].strip()
    # 原因裡若還有方括號，換成一般引號，保留其中的文字。
    body = _SCORE_PREFIX_RE.sub("", body)
    body = body.replace("〔", "「").replace("〕", "」")
    return label, body


def plain_reason(kind, reason, verdict=None, score=None):
    """把 AI 理由換成白話說明。

    前端的 ``〔標籤〕`` 會拿掉，並在前面加一個依標籤而定的白話句子。
    ``verdict`` 與 ``score`` 可直接傳入原欄位值，但只用來相容呼叫端；回傳值絕不
    顯示分數。原理由文字會保留，只會去掉前端標籤與方括號符號。
    """
    del score  # 分數不屬於人看頁。
    category = _normalise_kind(kind)
    label, body = _split_reason(reason)
    intro = _LABEL_INTROS.get(category, {}).get(label)
    if not intro:
        intro = _FALLBACK_INTROS.get(category)
    if not intro and verdict:
        intro = plain_verdict(category, verdict, label) + "。"
    if not intro:
        intro = "請你確認這段說明。"
    return intro if not body else intro + " " + body


# 舊名稱保留為明確的公開入口，讓呼叫端不必知道內部實作名稱。
def verdict_to_plain(kind, verdict, label=""):
    """``plain_verdict`` 的別名。"""
    return plain_verdict(kind, verdict, label)


def reason_to_plain(kind, reason, verdict=None, score=None):
    """``plain_reason`` 的別名。"""
    return plain_reason(kind, reason, verdict, score)


# ---------------------------------------------------------------------------
# 修改內容
# ---------------------------------------------------------------------------

_EMPTY_CHANGE_PARTS = {"", "（無）", "(無)"}


def _without_outer_quotes(value):
    value = _text(value).strip()
    if len(value) >= 2 and value[0] in "「『\"" and value[-1] in "」』\"":
        return value[1:-1].strip()
    return value


def _quote(value):
    return "「%s」" % _without_outer_quotes(value)


def _is_empty_change_part(value):
    return _without_outer_quotes(value) in _EMPTY_CHANGE_PARTS


def _plain_arrow_piece(piece):
    """把一個 A→B 小片段換成白話。"""
    value = _text(piece).strip()
    if "→" not in value:
        return ""
    old, new = value.split("→", 1)
    old, new = _without_outer_quotes(old), _without_outer_quotes(new)
    if _is_empty_change_part(old):
        return "加了%s" % _quote(new) if not _is_empty_change_part(new) else "加了一段內容"
    if _is_empty_change_part(new):
        return "刪了%s" % _quote(old)
    return "%s改成%s" % (_quote(old), _quote(new))


def _plain_change_summary(summary):
    """處理 row_assist.describe 類型的文字摘要。"""
    text = _text(summary).strip()
    if not text:
        return ""
    if "新增整段" in text:
        return "加了一段內容"
    if "刪除整段" in text or "整條刪除" in text:
        return "刪了一段內容"

    pieces = []
    for group in re.split(r"[；;]", text):
        # row_assist.describe 用「、」接多個 A→B；只在右側還有箭頭時才拆，
        # 避免把原文中的一般頓號拆壞。
        for piece in re.split(r"、(?=[^、]*→)", group):
            plain = _plain_arrow_piece(piece)
            if plain:
                pieces.append(plain)
    return "；".join(pieces)


def _change_type(change):
    value = _text(change.get("修改類型") or change.get("type") or "").strip().lower()
    if value in ("新增", "added", "add"):
        return "新增"
    if value in ("刪除", "deleted", "delete"):
        return "刪除"
    if value in ("修改", "modified", "modify", "changed"):
        return "修改"
    return ""


def _first_value(change, names):
    for name in names:
        value = change.get(name)
        if value not in (None, ""):
            return _text(value)
    return ""


def _diff_to_plain(old, new):
    """用標準函式庫找出最小的文字差異，回傳數個白話片段。"""
    if old == new:
        return "文字沒有改動"
    matcher = difflib.SequenceMatcher(None, old, new, autojunk=False)
    pieces = []
    for tag, i1, i2, j1, j2 in matcher.get_opcodes():
        if tag == "equal":
            continue
        before, after = old[i1:i2], new[j1:j2]
        if tag == "insert":
            pieces.append("加了%s" % _quote(after))
        elif tag == "delete":
            pieces.append("刪了%s" % _quote(before))
        else:
            # 單一字或短詞替換時，把後面共同的一個字也帶上。
            # 例如「三日」改「五日」，只說「三」改「五」看不出改的是期限。
            if max(len(before), len(after)) <= 2 and i2 < len(old) and j2 < len(new) and old[i2] == new[j2]:
                before += old[i2]
                after += new[j2]
            pieces.append("%s改成%s" % (_quote(before), _quote(after)))
    if len(pieces) > 4:
        pieces = pieces[:4] + ["另外還有%d處文字調整" % (len(pieces) - 4)]
    return "；".join(pieces) or "文字有調整，請你確認"


def plain_change(change):
    """把修改摘要或原始 change dict 換成白話。

    字串輸入可直接給 ``三日→五日`` 這類摘要；dict 輸入可給
    ``修改類型``、``old_text``、``new_text`` 等欄位。新增與刪除會說「加了」或
    「刪了」，取代則說「「舊字」改成「新字」」。
    """
    if not isinstance(change, dict):
        plain = _plain_change_summary(change)
        return plain or "文字有調整，請你確認"

    change_type = _change_type(change)
    old = _first_value(change, ("old_text", "舊文", "原文", "old"))
    new = _first_value(change, ("new_text", "新文", "修正後文字", "new"))
    summary = _first_value(change, ("異動內容", "摘要", "description", "describe"))

    if change_type == "新增":
        return "加了%s" % _quote(new) if new else "加了一段內容"
    if change_type == "刪除":
        return "刪了%s" % _quote(old) if old else "刪了一段內容"
    if "→" in summary:
        plain = _plain_change_summary(summary)
        if plain:
            return plain
    if old or new:
        return _diff_to_plain(old, new)
    plain = _plain_change_summary(summary)
    return plain or "文字有調整，請你確認"


def change_to_plain(change):
    """``plain_change`` 的別名。"""
    return plain_change(change)


# ---------------------------------------------------------------------------
# 來源與關係
# ---------------------------------------------------------------------------


def _source_key(source):
    value = _text(source).strip()
    compact = value.replace(" ", "")
    if "外部引用" in compact:
        return "外部引用"
    if "章節引用" in compact:
        return "章節引用"
    if "條文引用" in compact:
        return "條文引用"
    if "定義連動" in compact:
        return "定義連動"
    if "同層連帶" in compact:
        return "同層連帶"
    if "封面連帶" in compact:
        return "封面連帶"
    if "關鍵詞（舊值）" in compact or "關鍵詞(舊值)" in compact:
        return "舊值"
    if "關鍵詞（定義）" in compact or "關鍵詞(定義)" in compact:
        return "關鍵詞定義"
    if "關鍵詞（文脈）" in compact or "關鍵詞(文脈)" in compact:
        return "關鍵詞文脈"
    if "關鍵詞" in compact:
        return "關鍵詞"
    if "相似（句）" in compact or "相似(句)" in compact:
        return "句子相似"
    if "跨本（舊值）" in compact or "跨本(舊值)" in compact:
        return "跨本舊值"
    if "跨本（定義）" in compact or "跨本(定義)" in compact:
        return "跨本定義"
    if "跨本" in compact:
        return "另一份文件"
    if compact in ("相似", "相似條文") or "相似" in compact:
        return "相似"
    if "語意" in compact:
        return "語意"
    if "規格包" in compact:
        return "已知關聯"
    return ""


def _reference_replacement(relation):
    """只從明確的「A」→「B」關係取出可讀的換字資訊。"""
    text = _text(relation)
    match = re.search(r"「([^」]+)」\s*→\s*「([^」]+)」", text)
    if not match:
        return ""
    return "%s改成%s" % (_quote(match.group(1)), _quote(match.group(2)))


def _source_sentence(key, relation):
    replacement = _reference_replacement(relation)
    if key == "相似":
        return "這段和剛改的內容很像。"
    if key == "句子相似":
        return "這段裡有一句和剛改的內容很像。"
    if key == "關鍵詞":
        return "這段用了和剛改內容相同的字。"
    if key == "關鍵詞文脈":
        return "這段前後的說法和剛改內容接近。"
    if key == "舊值":
        return "這段還保留原來的寫法。"
    if key == "關鍵詞定義":
        return "這段還用了剛改名的用詞。"
    if key == "定義連動":
        return "這段用了剛調整定義的用詞。"
    if key == "同層連帶":
        return "同一層增刪了項目，這段寫的項數或相對引用可能要跟著改。"
    if key == "封面連帶":
        return "這次改的條文日期跟封面核定日對不上。"
    if key in ("章節引用", "條文引用"):
        if replacement:
            return "這段引用要更新：%s。" % replacement
        return "這段引用的地方可能要跟著更新。"
    if key == "跨本舊值":
        return "另一份文件還保留這次改掉的舊寫法。"
    if key == "跨本定義":
        return "另一份文件還用了這次改名的用詞。"
    if key == "另一份文件":
        return "另一份文件也有相關內容，請一起確認。"
    if key == "外部引用":
        if replacement:
            return "外部規定的引用要更新：%s。" % replacement
        return "這段引用外部規定，可能需要更新。"
    if key == "語意":
        return "這段的意思和剛改內容接近。"
    if key == "已知關聯":
        return "這段和已知的相關內容有關。"
    return "這段可能和剛改的內容有關，請你確認。"


def plain_source(source, relation=""):
    """把來源與關係換成白話理由。

    ``source`` 可以是來源文字，也可以是含「來源」與「關係／分數」的 dict。分數不會
    出現在回傳文字。未知來源使用安全的確認句，不會直接露出內部名稱。
    """
    if isinstance(source, dict):
        row = source
        relation = relation or row.get("關係／分數") or row.get("關係") or ""
        source = row.get("來源") or ""
    raw_sources = [part.strip() for part in re.split(r"[；;]", _text(source)) if part.strip()]
    if not raw_sources:
        raw_sources = [""]
    sentences = []
    for raw in raw_sources:
        sentence = _source_sentence(_source_key(raw), relation)
        if sentence not in sentences:
            sentences.append(sentence)
    return " ".join(sentences)


def source_to_plain(source, relation=""):
    """``plain_source`` 的別名。"""
    return plain_source(source, relation)


# ---------------------------------------------------------------------------
# 條文檢查名稱
# ---------------------------------------------------------------------------

_RULE_ITEM_WORDS = {
    "責任用語變更": "責任要求是否改變",
    "數值期間變更": "數字、日期或期限是否改變",
    "數值／期間變更": "數字、日期或期限是否改變",
    "施行日期": "開始生效時間是否清楚",
    "條號健全性": "條號是否完整",
    "定義用語": "定義用詞是否一致",
    "定義變更連動": "定義改動是否影響其他條文",
    "外部法規引用": "外部規定引用是否正確",
    "待補殘留": "是否還有待補內容",
    "格式一致性": "格式是否一致",
    "用語混用": "用詞是否一致",
    "附表引用": "附表引用是否正確",
    "未指定候選段落": "候選段落是否完整",
}
_STEP_PREFIX_RE = re.compile(r"^\s*(?:step\s*\d+(?:\.\d+)?\s*[-：:／/]?\s*)+", re.IGNORECASE)


def plain_rule_item(value):
    """把程式檢查名稱換成人看得懂的短句，不露出流程編號。"""
    text = _text(value).strip()
    text = _STEP_PREFIX_RE.sub("", text)
    return _RULE_ITEM_WORDS.get(text, text or "條文內容是否需要確認")


# ---------------------------------------------------------------------------
# 人工確認
# ---------------------------------------------------------------------------


def _confirmation_kind(item):
    if isinstance(item, dict):
        value = item.get("類別") or item.get("type") or item.get("kind") or ""
    else:
        value = item
    value = _text(value).strip().lower().replace(" ", "")
    if "外部" in value or "external" in value:
        return "外部"
    if "條文" in value or "rule" in value:
        return "規定"
    if "警告" in value or "提醒" in value or "warning" in value:
        return "提醒"
    if "異動" in value or "修改" in value or "change" in value:
        return "文字"
    return "一般"


def plain_confirmation_question(item):
    """產生人工確認要回答的白話問題。"""
    kind = _confirmation_kind(item)
    questions = {
        "文字": "這處文字修改是否可以照現在的寫法保留？",
        "規定": "這處規定是否符合要採用的做法？",
        "外部": "這個外部規定的引用是否正確且仍可用？",
        "提醒": "這個提醒是否已經處理？",
        "一般": "請確認這件事是否已經處理。",
    }
    return questions[kind]


def plain_confirmation_next_step(item):
    """產生人工確認後要做的下一步文字。"""
    kind = _confirmation_kind(item)
    steps = {
        "文字": "核對原文和改後文字；確認後寫下處理方式，並標記為已確認。",
        "規定": "查閱適用規定或向承辦確認；確認後寫下處理方式，並標記為已確認。",
        "外部": "查閱最新的外部規定；確認後寫下處理方式，並標記為已確認。",
        "提醒": "查看提醒內容；確認後寫下處理方式，並標記為已確認。",
        "一般": "確認處理方式；確認後寫下說明，並標記為已確認。",
    }
    return steps[kind]


def plain_confirmation(item):
    """回傳人看頁可直接使用的「問題」與「下一步」。"""
    return {
        "問題": plain_confirmation_question(item),
        "下一步": plain_confirmation_next_step(item),
    }


# ---------------------------------------------------------------------------
# 禁用術語掃描
# ---------------------------------------------------------------------------

# 原文欄位裡的字是法規內容，不是介面文字；掃描 dict 時必須略過，避免把原文本身的
# 「ID」或方括號誤判成人看頁的程式語。
_RAW_TEXT_FIELDS = {
    "原文", "新文", "舊文", "全文", "候選全文", "異動全文", "條文全文", "草稿全文",
    "old_text", "new_text", "original_text", "source_text",
}

_FORBIDDEN_PATTERNS = (
    ("ID", re.compile(r"(?<![A-Za-z0-9_])id(?![A-Za-z0-9_])", re.IGNORECASE)),
    ("指紋", re.compile(r"指紋")),
    ("〔", re.compile(r"〔")),
    ("〕", re.compile(r"〕")),
    ("AI分數", re.compile(r"(?<![A-Za-z0-9_])ai\s*分數", re.IGNORECASE)),
    ("Step", re.compile(r"(?<![A-Za-z0-9_])step(?![A-Za-z0-9_])", re.IGNORECASE)),
    ("review-import", re.compile(r"(?<![A-Za-z0-9_])review-import(?![A-Za-z0-9_])", re.IGNORECASE)),
    ("batch-", re.compile(r"(?<![A-Za-z0-9_])batch-", re.IGNORECASE)),
    ("找不到對應異動", re.compile(r"找不到對應異動")),
)


def _is_raw_text_field(name):
    key = _text(name).strip()
    return key in _RAW_TEXT_FIELDS or key.endswith("全文")


def _visible_text(value):
    """把可顯示內容攤平成文字；dict 的原文欄位不算人看頁。"""
    if isinstance(value, dict):
        pieces = []
        for key, item in value.items():
            if _is_raw_text_field(key):
                continue
            pieces.append(_text(key))
            pieces.append(_visible_text(item))
        return "\n".join(pieces)
    if isinstance(value, (list, tuple, set)):
        return "\n".join(_visible_text(item) for item in value)
    return _text(value)


def _original_texts(value):
    if isinstance(value, dict):
        for item in value.values():
            yield from _original_texts(item)
    elif isinstance(value, (list, tuple, set)):
        for item in value:
            yield from _original_texts(item)
    else:
        text = _text(value)
        if text:
            yield text


def forbidden_terms(text, original_texts=()):
    """找出人看頁不該出現的程式術語。

    回傳依固定順序排列、且不重複的術語清單。若頁面同時顯示法規原文，請把原文字串
    傳入 ``original_texts``；或直接傳入含「原文」「新文」「old_text」等欄位的 dict。
    這些原文內容會被排除，不會因法規本身出現 ``ID`` 等字而誤報。
    """
    visible = _visible_text(text)
    for original in _original_texts(original_texts):
        visible = visible.replace(original, "")
    return [name for name, pattern in _FORBIDDEN_PATTERNS if pattern.search(visible)]


def scan_forbidden_terms(text, original_texts=()):
    """``forbidden_terms`` 的別名。"""
    return forbidden_terms(text, original_texts)


__all__ = [
    "plain_verdict", "verdict_to_plain", "plain_reason", "reason_to_plain",
    "plain_change", "change_to_plain", "plain_source", "source_to_plain", "plain_rule_item",
    "plain_confirmation_question", "plain_confirmation_next_step", "plain_confirmation",
    "forbidden_terms", "scan_forbidden_terms",
]
