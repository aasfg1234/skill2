# -*- coding: utf-8 -*-
"""看設定、改設定（v1.59.0）：在對話裡看全部設定，不用開設定頁；使用者說要改什麼，AI 用「改設定」改。

欄位定義只有一份，在 設定.html 的 SETTINGS：這裡照它讀，設定頁加一格，這裡自動跟上。
改設定用白名單：只收開關、數字、單位資料（EDITABLE_KINDS）。位置（程式會去那裡載模型、找工作區）、網站清單、
執行方式（切換前要先搬資料）都不開放，新種類的欄位預設也不開放。
設定.html 在 skill 資料夾：隔離區的 Python 寫不到，但 AI 的檔案工具寫得到。所以隔離區的改設定只檢查、算出要換的那一行
（edit_plan），AI 用 edit 工具照抄，改完用看設定確認，不用使用者雙擊。少數找不到那一行時才走本機請求（按 Enter 前列改前改後）。

隔離區的輸出只看得到最後 50 行（平台實測）：預設一項一行，全部值擠得進去；完整內容 --全部 分頁。"""
import json
import math
import re
import unicodedata

from _common import CONFIG_HTML, load_config, write_config_key

EDITABLE_KINDS = ("bool", "int", "float", "select", "checks")
BLOCK_REASONS = {"text": "是位置", "sources": "是網站清單", "mode": "切換前要先把資料搬回來（見執行方式）"}
MODE_LABELS = {"隔離區": "AI 自己做", "本機": "這台電腦做"}
TRUE_WORDS = ("是", "開", "開啟", "打開", "勾", "勾選", "要", "true", "1", "on", "yes")
FALSE_WORDS = ("否", "關", "關閉", "不勾", "取消", "不要", "false", "0", "off", "no")
MAX_TEXT = 500
PAGE_LINES = 44                 # 隔離區一次印幾行（平台只留最後 50 行，後面還有結束碼那幾行）
_SPLIT_RE = re.compile(r"[,，、;；]")       # 跟設定頁的 splitValues 一樣
_DATA_BLOCK_RE = re.compile(r'<script\b[^>]*\bid="reg-data"[^>]*>.*?</script>', re.S)
HOW_TO_CHANGE = ["怎麼改設定（兩種都可以）：",
                 "1. 跟 AI 說就好，例如「把語意門檻改成 0.75」「關掉 AI 報告審查」。AI 會改好並告訴你改前改後"
                 "（這台電腦做的模式要請你雙擊一次確認）。",
                 "2. 自己開畫面改：跟 AI 說「打開設定」，或雙擊程式資料夾的「打開設定.cmd」，改了自動存。",
                 "執行方式、位置類的欄位、法規資料庫、修正對照表版面、同義詞表只能用第 2 種。"]


class SettingError(ValueError):
    pass


def _script_value(text, name):
    """設定.html 裡 const NAME = … 的值：掃到括號配對為止，去掉註解和結尾逗號後照 JSON 讀。找不到回 None。
    從 reg-data 區塊後面找：使用者填的值裡可能有一樣的字。"""
    block = _DATA_BLOCK_RE.search(text)
    start = re.compile(r"const %s = (?=[\[{])" % name).search(text, block.end() if block else 0)
    if not start:
        return None
    out, depth, index, quoted = [], 0, start.end(), False
    while index < len(text):
        char = text[index]
        if quoted:
            out.append(char)
            if char == "\\":
                out.append(text[index + 1])
                index += 1
            elif char == '"':
                quoted = False
        elif text.startswith("//", index):
            index = text.find("\n", index)
            continue
        else:
            out.append(char)
            quoted = char == '"'
            depth += (char in "[{") - (char in "]}")
            if depth == 0:
                break
        index += 1
    return json.loads(re.sub(r",(\s*[\]}])", r"\1", "".join(out)))


def schema(path=None):
    """回傳 (欄位 list, 預設值, 單位選項)。欄位：{鍵, 名稱, 種類, 說明, 預設說明, 最小, 最大, 分組}。"""
    with open(path or CONFIG_HTML, encoding="utf-8-sig") as f:
        text = f.read()
    try:
        rows = _script_value(text, "SETTINGS")
        defaults = _script_value(text, "SETTINGS_DEFAULTS")
        options = _script_value(text, "PROFILE_OPTIONS")
    except (ValueError, IndexError) as exc:
        raise SettingError("設定頁的欄位定義讀不出來（%s）：請用「打開設定」" % exc) from exc
    if not rows:
        raise SettingError("這份設定頁太舊，沒有欄位定義：請用「打開設定」")
    fields, group = [], ""
    for row in rows:
        if len(row) >= 2 and row[1] is None:
            group = row[0]
            continue
        row = list(row) + [None] * (7 - len(row))
        fields.append({"鍵": row[0], "名稱": row[1], "種類": row[2], "說明": row[3] or "", "預設說明": row[4] or "",
                       "最小": row[5], "最大": row[6], "分組": group})
    return fields, defaults or {}, options or {}


def _option_words(field, options):
    """這一格的選項，順序跟設定頁一樣。選項表是 [[分組名, [選項…]], …]，分組名不是選項。"""
    key = {"法規機構類型": "單位類型", "法規業務範圍": "業務範圍", "法規追蹤主題": "追蹤主題"}.get(field["鍵"], "")
    words = []
    for item in options.get(key) or []:
        group = item[1] if isinstance(item, list) and len(item) == 2 and isinstance(item[1], list) else [item]
        words += [word for word in group if isinstance(word, str) and word and word not in words]
    return words


def editable(field):
    return field["種類"] in EDITABLE_KINDS


def _block_reason(field):
    return BLOCK_REASONS.get(field["種類"], "不能在對話裡改")


def _show_value(field, value):
    kind = field["種類"]
    if kind == "bool":
        return "開" if value else "關" if value is not None else ""
    if kind == "mode":
        return MODE_LABELS.get(value, value or "")
    if kind == "sources":
        return "；".join("%s %s" % (item.get("名稱", ""), item.get("網址", "")) for item in value or [] if isinstance(item, dict))
    if isinstance(value, (list, dict)):
        return json.dumps(value, ensure_ascii=False)
    return "" if value is None else str(value)


def _state(field, current, defaults):
    value = _show_value(field, current.get(field["鍵"]))
    return value or "（沒填，用預設：%s）" % (_show_value(field, defaults.get(field["鍵"])) or field["預設說明"] or "空白")


def _range_text(field):
    parts = ["整數" if field["種類"] == "int" else "數字"]
    if field["最小"] is not None and field["最大"] is not None:
        parts.append("%s～%s" % (field["最小"], field["最大"]))
    return " ".join(parts)


def _short_fill(field):
    if not editable(field):
        return "設定頁改"
    if field["種類"] == "bool":
        return "開／關"
    return _range_text(field) if field["種類"] in ("int", "float") else "文字"


def _how_to_fill(field, options):
    if not editable(field):
        return "只能在設定頁改（%s）" % _block_reason(field)
    if field["種類"] == "bool":
        return "開／關"
    if field["種類"] in ("int", "float"):
        return _range_text(field)
    words = _option_words(field, options)
    if words:
        return ("可複選，用逗號隔開：" if field["種類"] == "checks" else "可選：") + "、".join(words) + "；其他的直接寫"
    return "文字"


def _section_lines(value, indent="  "):
    """對照版面、同義詞這種巢狀資料攤平成一行一項。"""
    lines = []
    if isinstance(value, dict):
        for key, item in value.items():
            if isinstance(item, dict):
                lines.append("%s%s：" % (indent, key))
                lines += _section_lines(item, indent + "  ")
            elif isinstance(item, list) and item and all(isinstance(x, dict) for x in item):
                lines.append("%s%s：" % (indent, key))
                lines += ["%s  %s" % (indent, "、".join("%s %s" % (k, v) for k, v in x.items())) for x in item]
            elif isinstance(item, list):
                lines.append("%s%s：%s" % (indent, key, "、".join(str(x) for x in item)))
            else:
                lines.append("%s%s：%s" % (indent, key, item))
    return lines


def _dict_section(data, key):
    value = data.get(key)
    return value if isinstance(value, dict) else {}


def show_lines(path=None, find="", full=False):
    """看設定要印的字。預設一項一行（隔離區只看得到最後 50 行）；find：只列含這個字的欄位，帶說明；full：全部帶說明。"""
    fields, defaults, options = schema(path)
    data = load_config(path or CONFIG_HTML)
    current = _dict_section(data, "設定")
    layout, synonyms = _dict_section(data, "對照表格式"), _dict_section(data, "同義詞")
    lines = ["目前的設定（只看不改）："]
    if not find and not full:
        group = None
        for field in fields:
            head = "【%s】" % field["分組"] if field["分組"] != group else ""
            group = field["分組"]
            lines.append("%s%s：%s（%s）" % (head, field["名稱"], _state(field, current, defaults), _short_fill(field)))
        if layout:
            lines.append("【修正對照表版面】%d 大項（設定頁改）" % len(layout))
        if synonyms:
            lines.append("【同義詞表】%d 組（設定頁改）" % len(_dict_section(synonyms, "詞組")))
        return lines + ["每一格的說明：看設定 --找 關鍵字。全部內容：看設定 --全部。"] + HOW_TO_CHANGE
    group, shown = None, 0
    for field in fields:
        if find and not any(find in word for word in (field["鍵"], field["名稱"], field["分組"], field["說明"])):
            continue
        shown += 1
        if field["分組"] != group:
            group = field["分組"]
            lines.append("【%s】" % group)
        lines.append("- %s：%s" % (field["名稱"], _state(field, current, defaults)))
        lines.append("  可填：%s。預設：%s" % (_how_to_fill(field, options),
                                          _show_value(field, defaults.get(field["鍵"])) or field["預設說明"] or "空白"))
        lines.append("  說明：%s" % field["說明"])
    if not shown:
        lines.append("沒有名稱或說明含「%s」的設定。" % find)
    if full and not find:
        if layout:
            lines += ["【修正對照表版面】（要在設定頁改）"] + _section_lines(layout)
        if synonyms:
            lines += ["【同義詞表】（要在設定頁改）"] + _section_lines(synonyms)
    return lines + HOW_TO_CHANGE


def page_lines(lines, page=0, size=PAGE_LINES):
    """分頁：page 0＝第一頁。放得下就原樣。超出範圍丟 SettingError。"""
    total = max(1, math.ceil(len(lines) / float(size)))
    page = page or 1
    if not 1 <= page <= total:
        raise SettingError("只有 %d 頁" % total)
    if total == 1:
        return lines
    chunk = lines[(page - 1) * size:page * size]
    return chunk + ["（第 %d／%d 頁%s）" % (page, total, "，下一頁加 --頁 %d" % (page + 1) if page < total else "，看完了")]


def parse_show_args(args):
    """隔離區的 看設定 參數（本機走 run_all 的 argparse，寫法要一樣）。回傳 (find, full, page)。"""
    find, full, page, index = "", False, 0, 0
    while index < len(args):
        arg, value = args[index], None
        if "=" in arg and arg.startswith("--"):
            arg, value = arg.split("=", 1)
        if arg in ("--全部", "--all") and value is None:
            full = True
        elif arg in ("--找", "--find", "--頁", "--page"):
            if value is None:
                index += 1
                if index >= len(args):
                    raise SettingError("%s 後面要寫值" % arg)
                value = args[index]
            if arg in ("--找", "--find"):
                find = value
            else:
                if not re.fullmatch(r"\d{1,4}", value):
                    raise SettingError("--頁 要寫數字")
                page = int(value)
        else:
            raise SettingError("看設定不認得「%s」：可以加 --找 關鍵字、--全部、--頁 數字" % arg)
        index += 1
    return find, full, page


def _resolve(name, fields):
    clean = re.sub(r"\s+", "", name)
    found = [f for f in fields if clean in (re.sub(r"\s+", "", f["鍵"]), re.sub(r"\s+", "", f["名稱"]))]
    return found[0] if found else None


def _suggest(name, fields):
    clean = re.sub(r"\s+", "", name)
    near = [f["名稱"] for f in fields if clean and (clean in f["名稱"] or f["名稱"] in clean
                                                    or len(set(clean) & set(f["名稱"])) >= max(2, len(clean) - 1))]
    return "；你是不是要：%s" % "、".join(near[:5]) if near else "；可以跑「看設定」看全部名稱"


def _plain_text(field, value):
    """select、checks 的字：會寫進設定頁，也會進 AI 提示，不收控制字元和角括號。"""
    bad = [c for c in value if unicodedata.category(c) in ("Cc", "Cf", "Cs", "Co", "Cn", "Zl", "Zp")]
    if bad or any(c in value for c in '<>"\\') or len(value) > MAX_TEXT:      # 引號和反斜線：AI 要照抄 before、after，抄錯 JSON 就壞
        raise SettingError("%s：值不能有換行、特殊符號、引號、反斜線或角括號，也不能超過 %d 字" % (field["名稱"], MAX_TEXT))


def _convert(field, value, defaults, options):
    """回傳要存的值；空白＝回到預設。值不合規定丟 SettingError。"""
    kind, name = field["種類"], field["名稱"]
    value = value.strip()
    if not value:
        return defaults.get(field["鍵"])
    if kind == "bool":
        word = value.lower()
        if word in TRUE_WORDS:
            return True
        if word in FALSE_WORDS:
            return False
        raise SettingError("%s：要填 開 或 關，不是「%s」" % (name, value))
    if kind in ("int", "float"):
        plain = unicodedata.normalize("NFKC", value)
        pattern = r"[+-]?[0-9]+" if kind == "int" else r"[+-]?[0-9]+(?:\.[0-9]+)?"
        if not re.fullmatch(pattern, plain):
            raise SettingError("%s：要填%s，不是「%s」" % (name, "整數" if kind == "int" else "數字", value))
        number = int(plain) if kind == "int" else float(plain)
        low, high = field["最小"], field["最大"]
        if (low is not None and number < low) or (high is not None and number > high):
            raise SettingError("%s：要在 %s～%s 之間，不是 %s" % (name, low, high, value))
        return number
    _plain_text(field, value)
    if kind == "checks":                    # 跟設定頁的 joinValues 一樣：去重、選項照順序、其他接後面
        items = [x.strip() for x in _SPLIT_RE.split(value) if x.strip()]
        if not items:
            return defaults.get(field["鍵"])
        unique = list(dict.fromkeys(items))
        order = _option_words(field, options)
        return ",".join([x for x in order if x in unique] + [x for x in unique if x not in order])
    return value


def plan_changes(pairs, path=None):
    """pairs：["名稱=值", …]。全部檢查過才回傳 [(欄位, 舊值, 新值)]，有一個不對就全部不改。"""
    if not pairs:
        raise SettingError("要寫成 改設定 名稱=值，例如 改設定 語意門檻=0.75")
    fields, defaults, options = schema(path)
    current = _dict_section(load_config(path or CONFIG_HTML), "設定")
    changes, problems, seen = [], [], set()
    for pair in pairs:
        pair = pair.replace("＝", "=")
        if "=" not in pair:
            problems.append("「%s」要寫成 名稱=值" % pair)
            continue
        name, value = pair.split("=", 1)
        field = _resolve(name, fields)
        if field is None:
            problems.append("沒有「%s」這個設定%s" % (name.strip(), _suggest(name, fields)))
            continue
        if not editable(field):
            problems.append("%s%s，只能在設定頁改（跟 AI 說「打開設定」）" % (field["名稱"], _block_reason(field)))
            continue
        if field["鍵"] in seen:
            problems.append("%s寫了兩次" % field["名稱"])
            continue
        seen.add(field["鍵"])
        try:
            changes.append((field, current.get(field["鍵"]), _convert(field, value, defaults, options)))
        except SettingError as exc:
            problems.append(str(exc))
    if problems:
        raise SettingError("；".join(problems))
    return changes


def change_lines(changes):
    return ["- %s：%s → %s" % (field["名稱"], _show_value(field, old) or "（沒填）", _show_value(field, new) or "（回到預設）")
            for field, old, new in changes]


def _settings_section(block):
    """reg-data 區塊裡「設定」那一段的字（從 { 到配對的 }）。找不到回 ""。同名的鍵可能在同義詞、單位資料建議裡。"""
    start = block.find('"設定": {')
    if start < 0:
        return ""
    depth, quoted, index = 0, False, block.index("{", start)
    first = index
    while index < len(block):
        char = block[index]
        if quoted:
            if char == "\\":
                index += 1
            elif char == '"':
                quoted = False
        elif char == '"':
            quoted = True
        elif char in "{[":
            depth += 1
        elif char in "}]":
            depth -= 1
            if depth == 0:
                return block[first:index + 1]
        index += 1
    return ""


def _edits_work(text, edits, changes):
    """試算：照 edit 工具的規矩全部換一遍，解開來看 設定 是不是只有這幾格變了、別段都沒動。"""
    result = text
    for before, after in edits:
        if result.count(before) != 1:
            return False
        result = result.replace(before, after)

    def data_of(page):
        return json.loads(re.search(r"<script\b[^>]*>(.*?)</script>", _DATA_BLOCK_RE.search(page).group(), re.S).group(1))
    try:
        was, now = data_of(text), data_of(result)
    except (ValueError, AttributeError):
        return False
    wanted = dict(was.get("設定") or {})
    wanted.update((field["鍵"], new) for field, _old, new in changes)
    settings = now.pop("設定", None)
    was.pop("設定", None)
    return settings == wanted and now == was


def edit_plan(changes, path=None):
    """隔離區改設定：每一項要換的字 [(before, after)]。before 是 設定.html「設定」段裡那一行，要剛好出現一次（edit 工具的規定）。
    先試算過才給：換完 JSON 要讀得出來、只有這幾格變。做不到（舊版設定頁、那一格還沒存過）回 None，走本機請求。值沒變的不列。"""
    with open(path or CONFIG_HTML, encoding="utf-8-sig") as f:
        text = f.read()
    block = _DATA_BLOCK_RE.search(text)
    section = _settings_section(block.group()) if block else ""
    if not section:
        return None
    edits = []
    for field, old, new in changes:
        if old == new:
            continue
        found = re.search(r'^[ \t]*("%s": .*?)(,?)[ \t]*\r?$' % re.escape(field["鍵"]), section, re.M)
        if not found:
            return None
        before = found.group(1) + found.group(2)
        after = '"%s": %s%s' % (field["鍵"], json.dumps(new, ensure_ascii=False).replace("<", "\\u003c"), found.group(2))
        edits.append((before, after))
    return edits if _edits_work(text, edits, changes) else None


def edit_lines(changes, edits, path_text="<skill資料夾>/設定.html"):
    """隔離區改設定印的字：最後幾行，平台只留最後 50 行。"""
    if not edits:
        return ["設定跟要改的一樣，不用改。"] + change_lines(changes)
    lines = ["要改的設定（還沒改）："] + change_lines(changes)
    lines.append("用 edit 工具改 %s，一項一次，before、after 整行照抄，不要自己組字串：" % path_text)
    for before, after in edits:
        lines += ["before: " + before, "after: " + after]
    return lines + ["全部改完送 看設定 --找 <名稱> 確認值對了，才跟使用者說改好了。"]


def apply_changes(changes, path=None):
    """寫進 設定.html。回傳真的有變的欄位數。"""
    target = path or CONFIG_HTML
    settings = dict(_dict_section(load_config(target), "設定"))
    changed = 0
    for field, _old, new in changes:
        if settings.get(field["鍵"]) != new:
            changed += 1
        if new is None:
            settings.pop(field["鍵"], None)
        else:
            settings[field["鍵"]] = new
    if changed:
        write_config_key("設定", settings, target)
    return changed


def set_lines(pairs, path=None):
    """改設定：檢查、寫入，回傳要印的字。"""
    changes = plan_changes(pairs, path)
    changed = apply_changes(changes, path)
    if not changed:
        return ["設定跟你要改的一樣，沒有改。"] + change_lines(changes)
    return ["已改好 %d 個設定：" % changed] + change_lines(changes) + ["下一次執行就會用新的值。"]
