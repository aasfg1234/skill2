"""工作區原始位置與本輪審查資料的唯讀查詢。"""
import csv
import json
import os
import re
from pathlib import PureWindowsPath

import law_impact
import workspace


def original_folders(args, settings):
    root = workspace.resolve_root(args.workspace, settings)
    marker = workspace._layout_path(root)
    if not os.path.isfile(marker):
        print('[中止] 找不到工作區標記檔')
        return 1
    with open(marker, encoding='utf-8-sig') as f:
        data = json.load(f)
    if args.現行 is not None or args.修訂 is not None:
        if not args.現行:
            print('[中止] 要給 --現行（只有現行版就只給 --現行，有修訂版再加 --修訂）')     # v1.56.0：以前體檢用的工作區記不了
            return 1
        try:
            record_originals(root, args.現行, args.修訂, data)     # v1.56.0：data 就地更新；以前接回傳值，記好了卻印 {}
        except ValueError as exc:
            print('[中止] %s' % exc)
            return 1
    # v1.51.0：印之前檢查資料夾還在不在；相對路徑超過 3 層 ..（印出來 11 層的 ../../..）改印絕對路徑
    found = data.get('原始資料夾', {}) or {}
    shown, missing = {}, []
    for key, value in found.items():
        full = os.path.normpath(os.path.join(root, value)) if isinstance(value, str) and not os.path.isabs(value) else value
        if not isinstance(value, str) or not os.path.isdir(full):
            shown[key] = value
            missing.append('%s=%s' % (key, value))
            continue
        shown[key] = os.path.abspath(full) if value.replace('\\', '/').split('/').count('..') > 3 else value
    print(json.dumps(shown, ensure_ascii=False, indent=2))
    if missing:
        print('[提醒] 原始資料夾現在不存在（搬走或改名了）：%s；要改用 原始資料夾 --現行 --修訂 重記' % '；'.join(missing))
    return 0


def record_originals(root, current, draft=None, data=None):
    """把原始資料夾（相對工作區）寫進標記檔；回傳寫好的標記資料。draft 可以不給（只做體檢）。
    隔離區只收相對路徑。v1.50.0 從 original_folders 抽出來給 建工作區 --現行 --修訂 共用。"""
    marker = workspace._layout_path(root)
    if data is None:
        with open(marker, encoding='utf-8-sig') as f:
            data = json.load(f)
    isolated = os.environ.get('REG_ISOLATED') == '1'
    pairs = ([('現行', current)] if current else []) + ([('修訂', draft)] if draft else [])
    if isolated and any(PureWindowsPath(value).drive or PureWindowsPath(value).root or os.path.isabs(value)
                        for _, value in pairs):
        raise ValueError('隔離區請將原始資料夾換算成相對工作區的路徑，例如 ../新手測試/現行')
    try:
        data['原始資料夾'] = {key: os.path.relpath(os.path.abspath(os.path.join(root, value.replace('\\', '/') if isolated else value)), root)
                          for key, value in pairs}
    except ValueError as exc:
        raise ValueError('無法記錄不同磁碟的相對路徑：%s' % exc)
    workspace._write_json_atomic(marker, data)
    return data['原始資料夾']


def find_workspaces(args, settings):
    value = args.原始
    if os.environ.get('REG_ISOLATED') == '1' and (PureWindowsPath(value).drive or PureWindowsPath(value).root or os.path.isabs(value)):
        print('[中止] 隔離區請將原始資料夾換算成相對工作區的路徑，例如 ../新手測試/現行')
        return 1
    if os.environ.get('REG_ISOLATED') == '1':
        print('[中止] 隔離區無法完整搜尋其他工作區；請用不帶倉庫的本機請求「找工作區」搜尋。')
        return 1
    root = os.path.abspath(args.workspace) if args.workspace else workspace.resolve_root('', settings)

    def normalized(base, path):
        path = path.replace('\\', os.sep).replace('/', os.sep)
        return os.path.normpath(os.path.abspath(os.path.join(base, path))).casefold()

    target = normalized(root, value)
    parent = os.path.dirname(root)
    found = []
    for name in sorted(os.listdir(parent)) if os.path.isdir(parent) else []:
        candidate = os.path.join(parent, name)
        marker = workspace._layout_path(candidate)
        # 搜尋同層工作區時，也要拒絕目錄或標記檔經由連結跳出搜尋範圍。
        import local_request
        try:
            local_request._local_path(candidate, parent)
            if not os.path.isdir(candidate):
                continue
            local_request._local_path(marker, parent)
        except (ValueError, OSError) as exc:
            print('[中止] 無法安全搜尋工作區：%s' % exc)
            return 1
        if not os.path.isfile(marker):
            continue
        try:
            with open(marker, encoding='utf-8-sig') as f:
                folders = json.load(f).get('原始資料夾', {})
            if not isinstance(folders, dict) or not any(isinstance(v, str) and v and normalized(candidate, v) == target for v in folders.values()):
                continue
        except (OSError, ValueError, AttributeError):
            continue
        outputs = [os.path.join(candidate, n) for n in os.listdir(candidate)
                   if os.path.isdir(os.path.join(candidate, n)) and workspace.is_output_dir(candidate, os.path.join(candidate, n))]
        kinds = {workspace.output_kind(p) or workspace._guess_kind(p) for p in outputs}
        if os.path.isfile(os.path.join(candidate, '法規作業.json')):
            kinds.add('法規追蹤')
        latest = _newest_round(outputs)
        match = workspace._OUTPUT_RE.fullmatch(os.path.basename(latest)) if latest else None
        date = match.group(1) + match.group(2) if match else ''
        found.append((name, kinds, latest, date, bool(outputs)))
    found.sort(key=lambda item: item[0])
    found.sort(key=lambda item: (item[4], item[3]), reverse=True)
    for index, (name, kinds, latest, date, has_output) in enumerate(found):
        print('工作區：%s；流程：%s；最新一輪：%s%s' % (
            name, '、'.join(k for k in workspace.OUTPUT_KINDS if k in kinds) or '無',
            os.path.basename(latest) if latest else '無', '；建議沿用' if index == 0 else ''))
    if not found:
        print('沒有，可以建新的')
    return 0


def _outputs(root):
    outputs = [workspace.current_output(root)]
    try:
        outputs.append(law_impact.current(root))
    except law_impact.ImpactError:
        pass
    return list(dict.fromkeys(p for p in outputs if p))


def _newest_round(outputs):
    """以工作區分配的日期序號決定輪次，不受表格或狀態的修改時間影響。"""
    def key(output):
        name = os.path.basename(os.path.normpath(output))
        match = workspace._OUTPUT_RE.fullmatch(name)
        return (match.group(1) + match.group(2) if match else '', name)
    return max(outputs, key=key) if outputs else ''


def _law_round(root):
    return _newest_round([p for p in _outputs(root) if os.path.isfile(law_impact.state_path(p))])


_ID_COLUMNS = ('列編號', '列ID', '事件ID', '配對ID', '家族ID', '異動ID', '檢查ID', '引用ID', '序號')
# 查表 --段次 比對的欄（v1.51.0：以前寫死比 段次，候選表、異動表永遠 0 列）
_LINE_COLUMNS = ('段次', '候選段次', '新版段次', '舊版段次')
# 隔離區 查表 --全部 一頁最多幾個字（隔離工具 4 萬字截頭尾之前先自己分頁，v1.51.0）
ISOLATED_PAGE_CHARS = 35000


def _paginate(body, start, budget=ISOLATED_PAGE_CHARS):
    """body 從第 start 列（1 起）切一頁，累計字數不超過 budget（至少給一列）。回 (這一頁的列, 第一列, 最後一列)。"""
    used, end = 0, start - 1
    for line in body[start - 1:]:
        if end >= start and used + len(line) + 1 > budget:
            break
        used += len(line) + 1
        end += 1
    return body[start - 1:end], start, end


def _read_table(path):
    for encoding in ('utf-8-sig', 'big5'):
        try:
            with open(path, encoding=encoding, newline='') as f:
                reader = csv.DictReader(f)
                return list(reader), reader.fieldnames or []
        except UnicodeDecodeError:
            if encoding == 'big5':
                raise


def _split(value):
    return [v.strip() for v in (value or '').split(',') if v.strip()]


def _counts(rows, column):
    counts = {}
    for row in rows:
        value = (row.get(column) or '').strip() or '（空白）'
        counts[value] = counts.get(value, 0) + 1
    return counts


def _counts_text(counts):
    return '、'.join('%s %d' % kv for kv in sorted(counts.items(), key=lambda kv: -kv[1]))


def _table_stats(root):
    """v1.48.0：這一輪每張 AI 表幾列、還有幾列沒判、判斷分布（模擬時 AI 每次都自己寫程式數）。"""
    seen, found = set(), []
    for output in _outputs(root):
        ai_dir = os.path.join(output, '2_Log檔案', 'AI審查')
        if not os.path.isdir(ai_dir):
            continue
        for name in sorted(os.listdir(ai_dir)):
            if not (name.startswith('AI') and name.endswith('.csv')) or name in seen:
                continue
            seen.add(name)
            found.append((output, os.path.join(ai_dir, name)))
    if not found:
        print('[中止] 目前這一輪沒有 AI 表')
        return 1
    for output, path in found:
        try:
            rows, fields = _read_table(path)
        except (OSError, UnicodeError, csv.Error) as exc:
            print('%s：讀不到（%s）' % (os.path.basename(path), exc))
            continue
        line = '%s（%s）：%d 列' % (os.path.basename(path), os.path.basename(os.path.normpath(output)), len(rows))
        if 'AI判斷' in fields and rows:
            counts = _counts(rows, 'AI判斷')
            line += '；還沒判 %d 列；%s' % (counts.get('（空白）', 0), _counts_text(counts))
        print(line)
    print('（哪幾列這一輪要判，以「先讀我.md」和繼續時的驗表為準；空白不一定都要填）')
    return 0


def query_table(args, settings):
    root = workspace.resolve_root(args.workspace, settings)
    if getattr(args, '統計', False):
        return _table_stats(root)
    if not args.table:
        print('[中止] 請給表名，或用 --統計 看全部的表')
        return 1
    if os.path.basename(args.table) != args.table or '/' in args.table or '\\' in args.table:
        print('[中止] 表名只能是檔名')
        return 1
    import ai_tables
    if args.table in ai_tables.LAW_TABLES:
        output = _law_round(root)
    else:
        output = _newest_round([p for p in _outputs(root)
                                if os.path.isfile(os.path.join(p, '2_Log檔案', 'AI審查', args.table))])
    path = os.path.join(output, '2_Log檔案', 'AI審查', args.table) if output else ''
    if not path or not os.path.isfile(path):
        # v1.51.0：目前這一輪沒有這張表（體檢上一輪獨有的表）：到最近一輪體檢找，說是哪一輪。
        # 法規表不找：法規追蹤那一輪的表不見了，不能拿體檢那一輪的答案頂替
        health = '' if args.table in ai_tables.LAW_TABLES else _newest_round(
            [p for p in _round_dirs(root) if os.path.basename(p).endswith('_體檢')
             and os.path.isfile(os.path.join(p, '2_Log檔案', 'AI審查', args.table))])
        if not health:
            print('[中止] 目前這一輪找不到表：%s（最近的體檢輪也沒有）' % args.table)
            return 1
        output, path = health, os.path.join(health, '2_Log檔案', 'AI審查', args.table)
        print('目前這一輪沒有這張表，改讀最近一輪體檢：%s' % os.path.basename(health))
    try:
        rows, fields = _read_table(path)
    except (OSError, UnicodeError, csv.Error) as exc:
        print('[中止] 讀表失敗：%s' % exc)
        return 1
    cols = _split(args.欄)
    unknown = [c for c in cols if c not in fields]
    if unknown:
        # v1.50.1：以前猜錯一個欄名整個中止（第二次模擬 3 次 × 5 秒白跑）；不認得的略過，其餘照印
        print('[提醒] 沒有這些欄，已略過：%s；可用欄名：%s' % ('、'.join(unknown), '、'.join(fields)))
        cols = [c for c in cols if c in fields]
    identifier = next((c for c in _ID_COLUMNS if c in fields), None)
    custom = bool(cols)             # v1.51.0：--欄 全部打錯就照沒帶 --欄 處理（預設欄、理由截 60 字）
    if not cols:
        cols = [c for c in (identifier, '規章', '段次', 'AI判斷', 'AI理由') if c and c in fields]
        if not any(c in fields for c in ('規章', '段次', 'AI判斷')):
            cols = list(fields)     # v1.51.0：報告審查、補查紀錄這種表以前只印「序號」
    blank_col = 'AI判斷' if 'AI判斷' in fields else ('處理' if '處理' in fields else None)
    if args.空白 and not blank_col:
        print('[提醒] 這張表沒有 AI判斷 或 處理 欄，--空白 不篩，照全部列印')
    requested = _split(args.事件)
    missing = [v for v in requested if v not in {r.get('事件ID') for r in rows}]
    if missing:
        print('找不到事件：' + '、'.join(missing))
    wanted = _split(getattr(args, '列', ''))
    if wanted:
        present = {r.get(c) for r in rows for c in _ID_COLUMNS if r.get(c)}
        lost = [v for v in wanted if v not in present]
        if lost:
            print('找不到列：' + '、'.join(lost))
    # 規章只要包含就算（模擬時 AI 打不出完整規章名，只好自己寫程式篩）
    rows = [r for r in rows if (not requested or r.get('事件ID') in requested)
            and (not wanted or any((r.get(c) or '') in wanted for c in _ID_COLUMNS if r.get(c)))
            and (not args.規章 or args.規章 in (r.get('規章') or ''))
            and (not args.段次 or args.段次.strip() in [(r.get(c) or '').strip() for c in _LINE_COLUMNS if c in fields])
            and (not args.空白 or not blank_col or not (r.get(blank_col) or '').strip())]
    limit = None if getattr(args, '全部', False) else (getattr(args, '上限', None) or 50)
    shown = rows if limit is None else rows[:limit]
    print('表：%s；符合 %d 列%s' % (path, len(rows), '，只顯示前 %d 列（--全部 看全部）' % limit if len(rows) > len(shown) else ''))
    print(' | '.join(cols))
    clip = not custom and not getattr(args, '全文', False)
    body = [' | '.join(((row.get(c) or '')[:60] if c == 'AI理由' and clip else (row.get(c) or '')).replace('\n', ' ') for c in cols)
            for row in shown]
    start = max(1, int(getattr(args, '起', 1) or 1))
    if limit is None and os.environ.get('REG_ISOLATED') == '1' and (start > 1 or sum(len(l) + 1 for l in body) > ISOLATED_PAGE_CHARS):
        # v1.51.0：隔離區大表（實測 23 萬字）以前被隔離工具截頭尾；超過一頁的字數就分頁，用 --起 看下一頁
        if start > len(body):
            print('（--起 %d 超過最後一列 %d）' % (start, len(body)))
            return 1
        lines, first, last = _paginate(body, start)
        for line in lines:
            print(line)
        if last < len(body):
            print('（第 %d～%d 列，共 %d 列；下一頁加 --起 %d）' % (first, last, len(body), last + 1))
        else:
            print('（第 %d～%d 列，共 %d 列，到底了）' % (first, last, len(body)))
        return 0
    for line in body:
        print(line)
    return 0


_JUDGE_COLUMNS = ('AI判定', 'AI判斷', '判定')
_SHOW_COLUMNS = ('序號', 'AI判定', 'AI判斷', '判定分數(0-10)', '影響程度(0-10)', '規章', '修改規章', '段次', '修改段次', '判定理由', '建議處理', '建議改法', '承辦意見')
_NOT_DATA_SHEETS = ('段次總表', '使用說明')      # 查東西、數列數都不算這兩頁
_EMPTY_REPORT_ROW = '（沒有要處理的段落）'       # 法規追蹤報告沒東西時的佔位列


def _round_dirs(root):
    try:
        names = os.listdir(root)
    except OSError:
        return []
    return [os.path.join(root, n) for n in names
            if workspace._OUTPUT_RE.fullmatch(n) and os.path.isdir(os.path.join(root, n))]


def _report_files(root, kind=''):
    """最新那一輪（照日期序號）的報告；給了流程就找那個流程最新的一輪。"""
    rounds = {}
    for output in _outputs(root) + _round_dirs(root):
        if kind and kind not in os.path.basename(os.path.normpath(output)):
            continue
        folder = os.path.join(output, '1_結果彙整')
        if os.path.isdir(folder):
            files = [os.path.join(folder, n) for n in sorted(os.listdir(folder))
                     if n.endswith('.xlsx') and not n.startswith('~$')]
            if files:
                rounds[os.path.normpath(output)] = files
    if not rounds:
        return []
    return rounds[_newest_round(list(rounds))]


def _detail_files(root):
    """最新一輪法規追蹤的明細 xlsx（2_Log檔案/法規分析/法規追蹤明細_*.xlsx）。"""
    rounds = [os.path.normpath(p) for p in _outputs(root) + _round_dirs(root) if '法規追蹤' in os.path.basename(os.path.normpath(p))]
    if not rounds:
        return []
    folder = os.path.join(_newest_round(rounds), '2_Log檔案', '法規分析')
    if not os.path.isdir(folder):
        return []
    return [os.path.join(folder, n) for n in sorted(os.listdir(folder))
            if n.startswith('法規追蹤明細_') and n.endswith('.xlsx')]


def _report_sheets(path):
    from _common import read_xlsx_rows, xlsx_sheet_names
    sheets = []
    for name in xlsx_sheet_names(path):
        cells = read_xlsx_rows(path, name)
        # v1.51.0：報告的表頭是「承辦意見（空白＝同意；…）」，讀回來一律當「承辦意見」
        header = ['承辦意見' if str(c).startswith('承辦意見') else c for c in cells[0]] if cells else []
        rows = [{h: (r[i] if i < len(r) else '') for i, h in enumerate(header)} for r in cells[1:]
                if any((v or '').strip() for v in r)]
        sheets.append((name, header, rows))
    return sheets


def _real_rows(rows):
    """去掉佔位列（v1.51.0：判定欄改名 AI判定 之後，佔位列也會被當成「沒有 AI判定」）。"""
    return [r for r in rows if not any((v or '').strip() == _EMPTY_REPORT_ROW for v in r.values())]


# 程式自己寫的「本行自訂的規章，網路查不到」列：判定是無法查證、有原因、有人工複核需求，但本來就沒有網址可填
_INTERNAL_RULE = re.compile(r'本行|內規|網路查不到|沒有公開|無公開')


def _check_report(path, sheets):
    """照 SKILL.md「交付前檢查」核對；只回問題，不改檔。"""
    problems = []
    output = os.path.dirname(os.path.dirname(path))
    # 「（說明）這裡放什麼.txt」是程式自己放的說明，不算多出來的東西
    extra = [n for n in os.listdir(output) if n not in ('1_結果彙整', '2_Log檔案') and not n.startswith(('.', '（說明）'))]
    if extra:
        problems.append('產出根目錄除了 1_結果彙整、2_Log檔案 還有：' + '、'.join(sorted(extra)))
    names = [name for name, _, _ in sheets]
    if os.path.basename(path).startswith('比對報告'):
        lost = [n for n in ('條文比對報告', '條文檢查報告', '引用檢查報告', '段次總表') if n not in names]
        if lost:
            problems.append('比對報告少了工作表：' + '、'.join(lost))
    for name, header, rows in sheets:
        judge = next((c for c in _JUDGE_COLUMNS if c in header), None)
        if not judge:
            continue
        rows = _real_rows(rows)
        blank = [r.get('序號') or str(i) for i, r in enumerate(rows, 2) if not (r.get(judge) or '').strip()]
        if blank:
            problems.append('%s：%d 列沒有%s（序號 %s）' % (name, len(blank), judge, '、'.join(blank[:10])))
        for i, row in enumerate(rows, 2):
            if '無法查證' in (row.get(judge) or ''):
                # v1.50.2：本行內規那種列查證來源一定是空的，不算問題（真實報告每份 17～21 列全被列成要處理）
                internal = bool(_INTERNAL_RULE.search((row.get('判定理由') or '')))
                lost = [c for c in ('判定理由', '查證來源') if c in header and not (row.get(c) or '').strip()
                        and not (c == '查證來源' and internal)]
                if lost:
                    problems.append('%s 序號 %s：無法查證但沒有%s' % (name, row.get('序號') or i, '、'.join(lost)))
    review = os.path.join(output, '2_Log檔案', 'AI審查', 'AI報告審查.csv')
    if os.path.isfile(review):
        try:
            import report_review
            rows = report_review.read_rows(output)      # v1.50.2：跟 繼續 同一套標準（只有序號、其他全空的列不算）
        except (OSError, UnicodeError, ValueError, csv.Error):
            rows = None
        if rows is not None and not rows:
            problems.append('AI報告審查.csv 還沒有任何一列（沒發現問題也要填一列「無問題」）')
    return problems


def show_report(args, settings):
    """v1.48.0：看報告 xlsx（模擬時 AI 每次都自己寫程式讀，還常踩到 openpyxl 唯讀模式列數是 None）。"""
    root = workspace.resolve_root(args.workspace, settings)
    files = _report_files(root, args.流程)
    if args.檔:
        def named(paths):
            return [p for p in paths if args.檔 in (os.path.basename(p), os.path.splitext(os.path.basename(p))[0])]
        # v1.56.0：法規追蹤明細在 2_Log檔案/法規分析/，以前沒有指令讀得到；`--檔 法規追蹤明細` 拿最新那一份
        files = named(files) or named(_detail_files(root)) or (_detail_files(root) if args.檔 == '法規追蹤明細' else [])
    if not files:
        print('[中止] 目前這一輪找不到報告%s' % ('：' + args.檔 if args.檔 else ''))
        return 1
    path = max(files, key=os.path.getmtime)
    try:
        sheets = _report_sheets(path)
    except Exception as exc:
        print('[中止] 讀不到報告（%s）：%s' % (type(exc).__name__, exc))
        return 1
    print('報告：%s' % path)
    others = sorted(os.path.basename(p) for p in files if p != path)
    if others:
        print('（另外還有：%s；要看別份加 --檔 <檔名>）' % '、'.join(others[:6]))
    # v1.60.0：--頁 A,B 一次看幾頁（隔離區每看一頁要跑一步）
    pages = _split(args.頁)
    missing = [p for p in pages if p not in [n for n, _, _ in sheets]]
    if missing:
        print('[中止] 沒有工作表「%s」；有的是：%s' % ('、'.join(missing), '、'.join(n for n, _, _ in sheets)))
        return 1
    for name, header, rows in sheets:
        if (pages and name not in pages) or (not pages and name in _NOT_DATA_SHEETS):
            continue
        line = '【%s】%d 列' % (name, len(rows))
        judge = next((c for c in _JUDGE_COLUMNS if c in header), None)
        if judge:
            line += '；%s：%s' % (judge, _counts_text(_counts(rows, judge)))
        if '承辦意見' in header:
            line += '；承辦意見有字 %d 格' % sum(1 for r in rows if (r.get('承辦意見') or '').strip())
        filtering = args.頁 or args.找 or args.段次 or args.判定 or args.有意見
        if filtering and not args.頁 and name in _NOT_DATA_SHEETS:
            continue
        print(line)
        if not filtering or args.頁:
            print('  欄：' + '、'.join(h for h in header if h))
    if args.頁 or args.找 or args.段次 or args.判定 or args.有意見:
        segments = _split(args.段次)
        picked = []
        for name, header, rows in sheets:
            if (pages and name not in pages) or (not pages and name in _NOT_DATA_SHEETS):
                continue
            judge = next((c for c in _JUDGE_COLUMNS if c in header), None)
            for row in rows:
                if args.找 and not any(args.找 in (v or '') for v in row.values()):
                    continue
                # v1.51.0：法規追蹤合併的列段次寫「3、5」，拆開比
                if segments and not any(set(_split((row.get(c) or '').replace('、', ','))) & set(segments)
                                        for c in header if c.endswith('段次')):
                    continue
                if args.判定 and not (judge and args.判定 in (row.get(judge) or '')):
                    continue
                if args.有意見 and not (row.get('承辦意見') or '').strip():
                    continue
                picked.append((name, header, row))
        limit = None if args.全部 else (args.上限 or 50)
        shown = picked if limit is None else picked[:limit]
        print('符合 %d 列%s' % (len(picked), '，只顯示前 %d 列（--全部 看全部）' % limit if len(picked) > len(shown) else ''))
        chosen = _split(args.欄)
        for name, header, row in shown:
            if chosen == ['全部']:           # v1.60.0：--欄 全部，每一欄都看、不截斷（報告審查要整份看）
                cols = [c for c in header if c]
            else:
                cols = [c for c in chosen if c in header] if chosen else ([c for c in _SHOW_COLUMNS if c in header] or header[:6])
            cells = []
            for c in cols:
                value = (row.get(c) or '').replace('\n', ' ')
                if not chosen and not args.全文 and len(value) > 80:
                    value = value[:80] + '…'
                cells.append('%s=%s' % (c, value))
            print('[%s] %s' % (name, ' | '.join(cells)))
    if args.核對:
        problems = _check_report(path, sheets)
        print('核對：' + ('沒發現問題' if not problems else '有 %d 件要處理' % len(problems)))
        for problem in problems:
            print('  - ' + problem)
    return 0


ORIGINALS_NEED_LOCAL = 7      # 核對原始 在隔離區讀不到原始資料夾：隔離工具看到就附本機請求（v1.50.0）


def summary_lines(output, prefix='  '):
    """v1.50.0：報告出來時自動印「每頁幾列、判定分布、承辦意見幾格、交付前核對」——給使用者的話要的數字直接抄。
    以前 AI 每站都自己寫程式讀報告去數（三次模擬 23 支）。讀不到報告只印一行，不擋流程。"""
    folder = os.path.join(output, '1_結果彙整')
    try:
        files = [os.path.join(folder, n) for n in os.listdir(folder) if n.endswith('.xlsx') and not n.startswith('~$')]
    except OSError:
        return []
    if not files:
        return []
    path = max(files, key=os.path.getmtime)
    try:
        sheets = _report_sheets(path)
    except Exception as exc:
        return [prefix + '報告數字：讀不到 %s（%s：%s）' % (os.path.basename(path), type(exc).__name__, exc)]
    lines = [prefix + '報告數字（%s；回覆使用者直接抄這幾行，不用自己寫程式數）：' % os.path.basename(path)]
    for name, header, rows in sheets:
        if name in _NOT_DATA_SHEETS:
            continue
        rows = _real_rows(rows)         # v1.51.0：法規追蹤報告沒東西時的佔位列不算 1 列
        line = '%s：%d 列' % (name, len(rows))
        judge = next((c for c in _JUDGE_COLUMNS if c in header), None)
        if judge and rows:
            line += '；%s：%s' % (judge, _counts_text(_counts(rows, judge)))
        if '承辦意見' in header:
            line += '；承辦意見有字 %d 格' % sum(1 for r in rows if (r.get('承辦意見') or '').strip())
        lines.append(prefix + '  ' + line)
    try:
        problems = _check_report(path, sheets)
    except Exception as exc:
        problems = ['核對時出錯：%s' % exc]
    lines.append(prefix + '  核對：' + ('沒發現問題' if not problems else '有 %d 件要處理' % len(problems)))
    lines += [prefix + '    - ' + p for p in problems]
    return lines


def _digest(path):
    import hashlib
    h = hashlib.sha256()
    with open(path, 'rb') as f:
        for chunk in iter(lambda: f.read(1 << 20), b''):
            h.update(chunk)
    return h.hexdigest()


def _documents(folder):
    """資料夾裡的規章檔（v1.50.2：程式放的說明檔、不是規章的檔不算，不然每次都列「只在 匯入/」、--帶入 還會把備忘錄複製進來）。"""
    from _common import SUPPORTED_EXTS
    try:
        return {n: os.path.join(folder, n) for n in os.listdir(folder)
                if os.path.isfile(os.path.join(folder, n)) and not n.startswith(('~$', '.'))
                and n != workspace.GUIDE_NAME and os.path.splitext(n)[1].lower() in SUPPORTED_EXTS}
    except OSError:
        return None


def _compare_documents(sources, targets):
    same, changed, only_source, only_target = [], [], [], []
    for name in sorted(set(sources) | set(targets)):
        if name not in targets:
            only_source.append(name)
        elif name not in sources:
            only_target.append(name)
        elif (os.path.getsize(sources[name]) == os.path.getsize(targets[name])
              and _digest(sources[name]) == _digest(targets[name])):
            same.append(name)
        else:
            changed.append((name, os.path.getmtime(sources[name]) > os.path.getmtime(targets[name])))
    return same, changed, only_source, only_target


def auto_check_originals(root):
    """本機請求開新一輪前唯讀核對；無法安全讀取的資料夾不擋流程。"""
    import local_request
    import workspace_transfer as transfer
    from pathlib import Path
    try:
        with open(workspace._layout_path(root), encoding='utf-8-sig') as f:
            folders = json.load(f).get('原始資料夾') or {}
    except (OSError, ValueError, AttributeError):
        folders = {}
    if not isinstance(folders, dict) or not folders:
        print('自動核對原始：還沒記原始資料夾，繼續執行。')
        return 0
    base = Path(os.environ.get('REG_RELAY_REAL_ROOT') or root).resolve()
    skill = transfer._program_dir().resolve()
    differences, unreadable, checked = [], [], 0
    for key, sub in (('現行', workspace.CURRENT_DIR), ('修訂', workspace.DRAFT_DIR)):
        value = folders.get(key)
        if not value:
            continue
        try:
            if not isinstance(value, str):
                raise ValueError('路徑格式不合法')
            source = local_request._origin_path(value, base, skill)
            sources = _documents(str(source))
            target = os.path.join(root, workspace.IMPORT_DIR, sub)
            targets = _documents(target) if os.path.exists(target) else {}
            if sources is None or targets is None:
                raise OSError('資料夾讀不到')
            _, changed, only_source, _ = _compare_documents(sources, targets)
        except (OSError, ValueError, TypeError) as exc:
            unreadable.append('%s（%s）' % (key, exc))
            continue
        checked += 1
        differences += ['%s：%s（原始較新）' % (key, name) for name, newer in changed if newer]
        differences += ['%s：%s（只在原始資料夾）' % (key, name) for name in only_source]
    if unreadable:
        print('自動核對原始：無法核對 %s，繼續處理其他資料夾。' % '、'.join(unreadable))
    if differences:
        print('自動核對原始：發現要確認的檔案：')
        for item in differences:
            print('  ' + item)
        print('要用原始那份：跑 核對原始 --帶入 再送一次；要照 匯入/ 那份做：同一個指令加 --不核對原始')
        return 1
    if checked:
        print('自動核對原始：沒有較新的原始檔或只在原始資料夾的檔案，繼續執行。')
    elif not unreadable:
        print('自動核對原始：還沒記原始資料夾，繼續執行。')
    return 0


def check_originals(args, settings):
    """v1.48.0：原始資料夾和 匯入/ 的同名檔一不一樣（模擬時 AI 每次都自己寫程式算指紋）。--帶入 先備份再複製。"""
    import datetime
    import shutil
    root = workspace.resolve_root(args.workspace, settings)
    try:
        with open(workspace._layout_path(root), encoding='utf-8-sig') as f:
            folders = json.load(f).get('原始資料夾') or {}
    except (OSError, ValueError):
        print('[中止] 找不到工作區標記檔')
        return 1
    if not isinstance(folders, dict) or not folders:
        print('[中止] 還沒記原始資料夾：先跑 原始資料夾 --現行 "<原始現行資料夾>" --修訂 "<原始修訂資料夾>"')
        return 1
    plan, unreadable = [], []
    # v1.50.0：本機請求接力時程式跑在暫存區解開的倉庫裡，「../原始資料夾」要從真正的工作區算
    base = os.environ.get('REG_RELAY_REAL_ROOT') or root
    for key, sub in (('現行', workspace.CURRENT_DIR), ('修訂', workspace.DRAFT_DIR)):
        value = folders.get(key)
        if not isinstance(value, str) or not value:
            continue
        source_dir = os.path.normpath(os.path.join(base, value))
        target_dir = os.path.join(root, workspace.IMPORT_DIR, sub)
        sources = _documents(source_dir)
        if sources is None:
            unreadable.append('%s（%s）' % (key, value))
            continue
        targets = _documents(target_dir) or {}
        same, changed, only_source, only_target = _compare_documents(sources, targets)
        print('【%s】原始：%s' % (key, value))
        print('  一樣 %d 份%s' % (len(same), '：' + '、'.join(same) if same and len(same) <= 10 else ''))
        for name, newer in changed:
            print('  不一樣：%s（%s）' % (name, '原始較新' if newer else '匯入那份較新，不會蓋掉'))
        for name in only_source:
            print('  只在原始資料夾：%s' % name)
        for name in only_target:
            print('  只在 匯入/%s：%s（不會刪）' % (sub, name))
        plan += [(sources[n], os.path.join(target_dir, n)) for n, newer in changed if newer]
        plan += [(sources[n], os.path.join(target_dir, n)) for n in only_source]
    if unreadable:
        if os.environ.get('REG_ISOLATED') == '1':
            # v1.50.0：以前只印「改用檔案工具比大小」，但 AI 要的是內容一不一樣，三次模擬都把原始檔和匯入檔各帶進隔離區
            # 自己算指紋（白佔名額）。改成跟打包分享一樣直接轉本機請求（隔離工具看到這個結束碼就附請求單）
            print('[本機] 隔離區讀不到原始資料夾（%s）：核對原始要在本機跑，程式已附本機請求，請使用者雙擊捷徑；'
                  '不要把原始檔帶進隔離區自己比。' % '、'.join(unreadable))
            return ORIGINALS_NEED_LOCAL
        print('讀不到原始資料夾：%s。' % '、'.join(unreadable))
    if not plan:
        if not unreadable:
            print('不用帶入')
        return 1 if unreadable else 0
    if args.帶入 and os.environ.get('REG_RUN_REQUEST') == '1':
        # v1.51.0：工作區標記記的原始資料夾隔離區也寫得到，本機請求帶入前照 建工作區 --現行 同一道檢查，
        # 不然 AI 記一個任意資料夾、再請本機帶入，就繞過了那道限制
        import local_request
        import workspace_transfer as transfer
        from pathlib import Path
        try:
            for value in folders.values():
                if isinstance(value, str) and value:
                    local_request._origin_path(value, Path(base).resolve(), transfer._program_dir().resolve())
        except ValueError as exc:
            print('[中止] %s' % exc)
            return 1
    if not args.帶入:
        print('要帶入 %d 份（原始較新、或匯入還沒有的）：同一行加 --帶入，會先備份 匯入/ 原本那份' % len(plan))
        return 0
    backup = os.path.join(root, '_工作', '帶入前備份', datetime.datetime.now().strftime('%Y%m%d_%H%M%S'))
    for source, target in plan:
        os.makedirs(os.path.dirname(target), exist_ok=True)
        if os.path.isfile(target):
            keep = os.path.join(backup, os.path.basename(os.path.dirname(target)), os.path.basename(target))
            os.makedirs(os.path.dirname(keep), exist_ok=True)
            shutil.copy2(target, keep)
        shutil.copy2(source, target)
        print('帶入：%s → 匯入/%s/' % (os.path.basename(source), os.path.basename(os.path.dirname(target))))
    if os.path.isdir(backup):
        print('原本那幾份備份在：%s' % os.path.relpath(backup, root))
    return 0


def show_event(args, settings):
    root = workspace.resolve_root(args.workspace, settings)
    output = _law_round(root)
    if not output:
        print('[中止] 沒有法規分析狀態')
        return 1
    state = law_impact.read_state(output)
    numbers = state.get('numbers') or {}
    events = {numbers.get(event.get('id')): event for event in state.get('events') or []}
    if getattr(args, '待判', False):
        path = os.path.join(law_impact.ai_dir(output), law_impact.APPLY_FILE)
        rows = law_impact.read_ai_table(path)
        if rows is None:
            print('[中止] 目前這一輪找不到表：%s' % law_impact.APPLY_FILE)
            return 1
        requested = list(dict.fromkeys(r.get('事件ID') for r in rows if not (r.get('AI判斷') or '').strip() and r.get('事件ID')))
        if not requested:
            print('都判完了')
            return 0
        remaining = max(0, len(requested) - 30)
        requested = requested[:30]
    else:
        requested = [v.strip() for v in (args.event or '').split(',') if v.strip()]
        remaining = 0
    if not requested:
        print('[中止] 請指定事件或 --待判')
        return 1
    missing = [n for n in requested if n not in events]
    if missing:
        print('找不到事件：%s；現有事件：%s' % ('、'.join(missing), '、'.join(list(numbers.values())[:10]) or '（無）'))
    for number in requested:
        event = events.get(number)
        if not event:
            continue
        print('輪次：%s；事件：%s' % (os.path.basename(os.path.normpath(output)), number))
        for label, key in (('法規名稱', 'law_name'), ('條號', 'article_no'), ('公布或修正日', 'event_date'), ('施行日', 'effective_date'), ('官方來源', 'source_url'), ('新條文', 'new_text'), ('舊條文', 'old_text')):
            print('%s：%s' % (label, event.get(key) or '（無）'))
    if remaining:
        print('還有 %d 條' % remaining)
    return 0 if any(n in events for n in requested) else 1
