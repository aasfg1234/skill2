# -*- coding: utf-8 -*-
"""reg 工作區：匯入資料夾（現行、修訂各一個子資料夾）與日期序號作業資料夾。

    工作區/
      匯入/
        1_現行文件/<規章名>.docx
        2_修訂文件/<規章名>.docx
        規格包/<規章名>/LATEST.json
        規章清單.csv
      產出YYYYMMDDNNN/
        1_結果彙整/ 2_Log檔案/

「建工作區」只建立固定結構（舊版工作區順便遷移）；「開始」才建立新的日期序號作業目錄。
「繼續」永遠使用目前作業指標，不會另開輸出資料夾。
"""
import csv
import datetime
import io
import json
import os
import re
import shutil
import sys
import unicodedata

HERE = os.path.dirname(os.path.abspath(__file__))
REG = os.path.dirname(HERE)
REGDIFF = os.path.join(HERE, "regdiff")
if REGDIFF not in sys.path:
    sys.path.insert(0, REGDIFF)

# 白名單只有一份：_common.SUPPORTED_EXTS。工作區這邊自己抄一份的話，
# 「配對認得的格式」跟「讀檔認得的格式」遲早會走鐘（no 14 就是這樣來的：
# compare 早就吃得下 .txt／.md，匯入夾卻只認 .docx）。
from _common import SUPPORTED_EXTS, SYSTEM_DIR, book_dir, home_of, skill_path
from file_replace import QUICK_WAIT, move_path, rename_file, replace_file

MANIFEST_COLUMNS = ["規章名", "舊版", "新版草稿", "發布根目錄", "配對方式", "備註"]
# 現行版、修訂版各放 匯入/ 底下一個資料夾，檔名就是規章名，不加任何角色前綴。
IMPORT_DIR = "匯入"
CURRENT_DIR = "1_現行文件"
DRAFT_DIR = "2_修訂文件"
SPEC_DIR = "規格包"
CACHE_DIR = "系統快取"      # 舊版工作區放快取的資料夾（現在快取在 skill 的 memoization/）：讀規章時跳過它
LAYOUT_MARK = {"格式版本": 3, "輸入模式": "分資料夾"}
# 匯入/ 最上層有規章檔時，配對與過期檢查的說明尾巴（呼叫端靠它認出「放錯層」）
UNSORTED_NOTE = "（沒放進 %s 或 %s）" % (CURRENT_DIR, DRAFT_DIR)
# v1.56.0：放檔時就講清楚收什麼：.doc、PDF 放進來只會被略過，以前到配對才看得到一行「略過」
FORMAT_NOTE = "規章要是 Word .docx（純文字 .txt、.md 也收）；舊式 .doc 先用 Word 另存成 .docx，PDF 不能比對，要拿原始 Word 檔。"
# list_role_inputs 指定角色用的字
ROLE_CURRENT = "現行"
ROLE_DRAFT = "修訂"
# 前一版工作區（格式 2）把檔都放 匯入/ 最上層、用檔名前綴分角色。只給「建工作區」遷移用：
# 遷移時複製進兩個資料夾、拿掉前綴，原檔搬到 匯入/遷移前備份/。
CURRENT_PREFIX = "現行_"
DRAFT_PREFIX = "修訂_"
PREFIX_BACKUP_DIR = "遷移前備份"
# 更早的分類資料夾（沒有工作區標記檔）：照舊可讀，「建工作區」時複製進兩個新資料夾，舊資料夾保留。
LEGACY_OLD_DIR = "現行規章"
LEGACY_NEW_DIR = "修訂規章"
OLDER_OLD_DIR = "舊版"
OLDER_NEW_DIR = "新版"
LEGACY_ROLE_DIRS = ((LEGACY_OLD_DIR, CURRENT_DIR), (LEGACY_NEW_DIR, DRAFT_DIR),
                    (OLDER_OLD_DIR, CURRENT_DIR), (OLDER_NEW_DIR, DRAFT_DIR))
NEW_RULE = "新訂"            # 修訂版沒有對應的現行版：當新訂規章，舊版當空的、整本算新增
METHODS = ("檔名相同", "去版本字", "未配對", NEW_RULE, "手動")

# 程式版本：每次升版都要改這一行。工作區記「用過的最高版本」：換了新版、舊資料夾還在、捷徑還指著舊版時，
# 舊程式一碰到新版用過的工作區就看得出來（只提醒，不中止）
SKILL_VERSION = "1.63.2"
VERSION_FILE = "_程式版本.json"
_VERSION_RE = re.compile(r"\d{1,4}\.\d{1,4}\.\d{1,4}")

# 作業指標放在工作區根目錄。每次「開始」才建立新輸出；「繼續」只讀這個指標，
# 絕不能自己換到另一個日期資料夾。
LAYOUT_FILE = ".內規工作區.json"
ACTIVE_OUTPUT_FILE = "目前作業.json"
PREVIOUS_OUTPUT_FILE = "前一輪作業.txt"
OUTPUT_PREFIX = "產出"
# v1.26.0：資料夾名後面接是哪一條流程（產出20261026003_比對）；以前沒有後綴的舊資料夾照樣認得
OUTPUT_KINDS = ("比對", "體檢", "法規追蹤")
_OUTPUT_RE = re.compile(r"^產出(\d{8})(\d{3})(?:_(比對|體檢|法規追蹤))?$")


class WorkspaceError(ValueError):
    pass


# ---------------------------------------------------------------------------
# 路徑與作業指標
# ---------------------------------------------------------------------------

# 三個 skill（比對報告、修改文本、建基準）各自帶一份完整程式，放在同一層資料夾；
# 工作區要三個共用，預設放在它們旁邊，不放在任何一個 skill 裡面
SHARED_WORKSPACE = "內規工作區"


def resolve_root(workspace_arg, settings):
    """--workspace 優先；其次設定.html 的工作區根目錄；都沒有就用共享工作區。
    給的是名稱（例如 …/內規工作區）時，用它旁邊最新的 <名稱>yyyymmddnn（見 newest_workspace）。"""
    if workspace_arg:
        return newest_workspace(workspace_arg)
    root = skill_path((settings or {}).get("工作區根目錄", ""))     # v1.15.0：相對位置從 skill 資料夾算起
    if root:
        return newest_workspace(root)
    legacy = os.path.join(REG, "工作區")
    if os.path.isdir(legacy):
        return legacy
    return newest_workspace(os.path.join(os.path.dirname(REG), SHARED_WORKSPACE))


# 工作區資料夾名稱最後的日期序號：「建工作區」每次開一個新的 <名稱>yyyymmddnn（一個新案子一個工作區），
# 舊的留著不動；其他指令沒指定哪一個時用最新的那一個。沒有日期序號的舊工作區（內規工作區）照樣能用，算最舊。
_WORKSPACE_STAMP_RE = re.compile(r"^(.+?)(\d{8})(\d{2})$")


def workspace_base(path):
    """去掉資料夾名稱最後的 yyyymmddnn：…/內規工作區2026102301 → …/內規工作區；沒有就原樣。"""
    path = os.path.abspath(path)
    match = _WORKSPACE_STAMP_RE.match(os.path.basename(path))
    return os.path.join(os.path.dirname(path), match.group(1)) if match else path


def dated_workspaces(base):
    """base 旁邊的 <名稱>yyyymmddnn 工作區資料夾，舊到新。"""
    parent, name = os.path.split(workspace_base(base))
    if not os.path.isdir(parent):
        return []
    # Windows 的檔名不分大小寫：reg2026102301 與 Reg… 是同一個資料夾，比對也要不分，
    # 不然 `建工作區 --workspace …\Reg` 找不到既有的 reg…01、序號永遠算成 01、makedirs 落回同一個資料夾（審查 A6）
    pattern = re.compile(r"^%s\d{10}$" % re.escape(name), re.IGNORECASE if os.name == "nt" else 0)
    return [os.path.join(parent, n) for n in sorted(os.listdir(parent))
            if pattern.match(n) and os.path.isdir(os.path.join(parent, n))]


def newest_workspace(path):
    """path 帶了日期序號（指定哪一個）就照用；只給名稱就用最新的 <名稱>yyyymmddnn，一個都沒有才用名稱本身。"""
    path = os.path.abspath(path)
    if workspace_base(path) != path:
        return path
    dated = dated_workspaces(path)
    return dated[-1] if dated else path


def is_workspace(root):
    """這個資料夾已經是工作區了嗎（有工作區標記檔）。"""
    return os.path.isfile(_layout_path(root))


def _version_key(text):
    return tuple(int(part) for part in text.split("."))


def _recorded_version(root):
    """工作區記的版本。沒有、壞了、不是純版本號都回空字串（這個檔 AI 寫得到，別的字不印給使用者看）。"""
    try:
        with io.open(os.path.join(str(root), VERSION_FILE), encoding="utf-8-sig") as f:
            return _version_in(json.load(f))
    except (OSError, ValueError):
        return ""


def _version_in(value):
    text = value.get("用過的最高版本") if isinstance(value, dict) else ""
    return text if isinstance(text, str) and _VERSION_RE.fullmatch(text) else ""


def incoming_version_is_higher(data, root):
    """搬移帶來的版本紀錄（檔案內容 bytes）比 root 記的高嗎。兩邊不同不算衝突：紀錄只往上記，留高的。"""
    try:
        text = _version_in(json.loads(data.decode("utf-8-sig")))
    except ValueError:
        return False
    recorded = _recorded_version(root)
    return bool(text) and (not recorded or _version_key(text) > _version_key(recorded))


def program_version_note(root):
    """這支程式比工作區記的版本舊：回給使用者看的提醒，否則回空字串。只讀不寫。"""
    recorded = _recorded_version(root)
    if not recorded or _version_key(recorded) <= _version_key(SKILL_VERSION):
        return ""
    return ("[版本提醒] 這次跑的程式是 v%s，但這個工作區已經用 v%s 跑過：多半是換了新版、舊資料夾還在，捷徑還指著舊版。"
            "請到新版的程式資料夾雙擊一次 打開設定.cmd 重新登記，再回來跑。這次照跑，不中止。"
            "（AI：把這段原樣告訴使用者）" % (SKILL_VERSION, recorded))


def check_program_version(root):
    """開跑時呼叫：程式比工作區記的舊回提醒；比較新就更新紀錄（只往上記：舊程式跑過也不會蓋掉）。不是工作區回空字串。"""
    if not is_workspace(root):
        return ""
    note = program_version_note(root)
    if note or _recorded_version(root) == SKILL_VERSION:
        return note
    path = os.path.join(str(root), VERSION_FILE)
    try:
        with io.open(path + ".tmp", "w", encoding="utf-8") as f:
            json.dump({"用過的最高版本": SKILL_VERSION}, f, ensure_ascii=False)
        replace_file(path + ".tmp", path)
    except OSError:
        pass                # 記不下來只是少一次提醒，不擋流程
    return ""


def dated_if_missing(root):
    """工作區還不存在、給的又是沒有日期序號的名稱：改成新的 <名稱>yyyymmddnn（第一次建就照新規則）。"""
    root = os.path.abspath(root)
    if not os.path.exists(root) and workspace_base(root) == root:
        return new_workspace_root(root)
    return root


def new_workspace_root(path, date_text=None, existing=()):
    """「建工作區」要開的新資料夾：<名稱>yyyymmddnn，同一天第幾個就是 nn（01 起）。"""
    from _common import tw_now, tw_today
    base = workspace_base(path)
    today = date_text or tw_now().strftime("%Y%m%d")
    if not re.fullmatch(r"\d{8}", today):
        raise WorkspaceError("工作區日期必須是 YYYYMMDD：%s" % today)
    used = [int(os.path.basename(p)[-2:]) for p in dated_workspaces(base)
            if os.path.basename(p)[-10:-2] == today]
    pattern = re.compile(r"^%s%s(\d{2})$" % (re.escape(os.path.basename(base)), today), re.IGNORECASE)
    for name in existing:
        if os.path.basename(name) != name or not re.fullmatch(re.escape(os.path.basename(base)) + r"\d{10}", name, re.IGNORECASE):
            raise WorkspaceError("已有工作區名稱格式不正確：%s" % name)
        match = pattern.fullmatch(name)
        if match:
            used.append(int(match.group(1)))
    serial = max(used) + 1 if used else 1
    if serial > 99:
        raise WorkspaceError("同一天已經建了 99 個工作區：%s" % base)
    return "%s%s%02d" % (base, today, serial)


def _layout_path(root):
    return os.path.join(os.path.abspath(root), LAYOUT_FILE)


def _active_path(root):
    return os.path.join(os.path.abspath(root), ACTIVE_OUTPUT_FILE)


def _read_json(path):
    try:
        with io.open(path, encoding="utf-8") as source:
            value = json.load(source)
        return value if isinstance(value, dict) else {}
    except (OSError, ValueError, TypeError):
        return {}


def _write_json_atomic(path, value):
    folder = os.path.dirname(path)
    if folder:
        os.makedirs(folder, exist_ok=True)
    temp = path + ".tmp"
    with io.open(temp, "w", encoding="utf-8") as target:
        json.dump(value, target, ensure_ascii=False, indent=2)
    replace_file(temp, path)


def _legacy_layout(root):
    """沒有新版標記、且仍有舊輸入分類資料夾時，照舊讀取，不自動搬資料。"""
    root = os.path.abspath(root)
    if os.path.isfile(_layout_path(root)):
        return False
    imported = os.path.join(root, IMPORT_DIR)
    return any(os.path.isdir(os.path.join(imported, name))
               for name, _folder in LEGACY_ROLE_DIRS)


def uses_legacy_layout(root):
    """公開的舊工作區判定，供流程保留既有資料而不自動搬移。"""
    return _legacy_layout(root)


def uses_prefix_layout(root):
    """前一版（格式 2）的工作區：標記寫「檔名前綴」，或沒有標記但 匯入/ 最上層放著 現行_／修訂_ 檔。
    這種工作區要先跑「建工作區」轉成兩個資料夾，配對與開始不能直接用。"""
    root = os.path.abspath(root)
    if _legacy_layout(root):
        return False
    data = _read_json(_layout_path(root))
    if data:
        return data.get("輸入模式") == "檔名前綴"
    return any(name.startswith((CURRENT_PREFIX, DRAFT_PREFIX))
               for name in _input_files(os.path.join(root, IMPORT_DIR)))


def role_dirs(root):
    """規章清單裡現行、修訂兩邊的路徑前面接哪一個資料夾（相對 匯入/）。"""
    if _legacy_layout(root):
        return LEGACY_OLD_DIR, LEGACY_NEW_DIR
    return CURRENT_DIR, DRAFT_DIR


def is_output_dir(root, outdir):
    """outdir 是此工作區的舊或新版作業目錄嗎。"""
    root = os.path.abspath(root)
    outdir = os.path.abspath(outdir or "")
    if os.path.dirname(outdir) != root:
        return False
    name = os.path.basename(outdir)
    return name == OUTPUT_PREFIX or bool(_OUTPUT_RE.match(name))


def _output_from_name(root, name):
    """作業指標只能指向工作區第一層的舊／新版產出資料夾。"""
    if not isinstance(name, str) or not name:
        return ""
    root = os.path.abspath(root)
    target = os.path.abspath(os.path.join(root, name))
    return target if is_output_dir(root, target) and os.path.isdir(target) else ""


def current_output(root):
    """讀目前作業指標，不建立資料夾，也不猜多個日期資料夾的最新者。"""
    root = os.path.abspath(root)
    if _legacy_layout(root):
        return os.path.join(root, OUTPUT_PREFIX)
    data = _read_json(_active_path(root))
    return _output_from_name(root, data.get("目前作業", ""))


def previous_output(root, outdir=None):
    """回傳指定作業的前一輪資料夾；沒有就回空字串。"""
    root = os.path.abspath(root)
    outdir = os.path.abspath(outdir or current_output(root) or "")
    if not is_output_dir(root, outdir):
        return ""
    pointer = os.path.join(outdir, SYSTEM_DIR, PREVIOUS_OUTPUT_FILE)
    try:
        with io.open(pointer, encoding="utf-8") as source:
            name = source.read().strip()
    except OSError:
        name = ""
    return _output_from_name(root, name)


def abandon_output(root, outdir, previous=""):
    """「開始」沒跑完（某本讀不出來、Ctrl+C）：目前作業指標退回前一輪 previous（沒有就清空），
    回傳有沒有退。這一輪的資料夾留著給人看紀錄，但不再是「目前作業」，下一次「開始」也不會拿它當前一輪。
    以前半套的產出被記成前一輪：裡面沒有資料夾的本找不到上一輪，AI 判過的答案、人填的決定從此不沿用，整本重判。"""
    root = os.path.abspath(root)
    current = current_output(root)
    if not current or os.path.normcase(current) != os.path.normcase(os.path.abspath(outdir)):
        return False
    prior = _output_from_name(root, os.path.basename(previous)) if previous else ""
    _write_active_output(root, prior, previous_output(root, prior) if prior else "")
    return True


def _write_active_output(root, current, previous=""):
    from _common import tw_now, tw_today
    data = {
        "格式版本": 1,
        "目前作業": os.path.basename(current),
        "前一輪作業": os.path.basename(previous) if previous else "",
        "建立時間": tw_now().strftime("%Y-%m-%d %H:%M:%S"),
    }
    _write_json_atomic(_active_path(root), data)


def output_name(today, serial, kind=""):
    """產出YYYYMMDDNNN_<流程>（kind 空白就不接後綴）。"""
    return "%s%s%03d%s" % (OUTPUT_PREFIX, today, serial, "_" + kind if kind else "")


def make_output_dir(root, kind, today=None):
    """建這一輪的資料夾 產出YYYYMMDDNNN_<流程>（v1.26.0）。序號三條流程共用：同一天同一個序號、不管後綴是什麼，
    接在今天最大的序號後面（v1.39.0：不補空號——隔離區倉庫只帶目前、前一輪，本機解開後 001、003 不在，
    以前會補成 001，跟真的工作區裡的 001_比對 撞號，照名字排也排到 004 前面）。回傳路徑。"""
    from _common import tw_now, tw_today
    if kind not in OUTPUT_KINDS:
        raise WorkspaceError("不認得的流程：%s" % kind)
    today = today or tw_now().strftime("%Y%m%d")
    if not re.fullmatch(r"\d{8}", today):
        raise WorkspaceError("產出日期必須是 YYYYMMDD：%s" % today)
    try:
        taken = set(int(m.group(2)) for m in (_OUTPUT_RE.match(n) for n in os.listdir(root))
                    if m and m.group(1) == today)
    except OSError:
        taken = set()
    for serial in range(max(taken, default=0) + 1, 1000):
        folder = os.path.join(root, output_name(today, serial, kind))
        try:
            os.mkdir(folder)
            return folder
        except FileExistsError:
            continue
        except OSError as exc:
            raise WorkspaceError("建立作業資料夾失敗：%s（%s）" % (folder, exc))
    raise WorkspaceError("今天的產出序號已超過 999：%s" % today)


def output_kind(outdir):
    """資料夾名後綴寫的流程（產出20261026003_比對 → 比對）；舊的沒有後綴回 ""。"""
    hit = _OUTPUT_RE.match(os.path.basename(os.path.normpath(outdir or "")))
    return (hit.group(3) or "") if hit else ""


def output_serial(outdir):
    """資料夾名的日期序號（產出20261026003_比對 → 20261026003）；不是產出資料夾回 ""。"""
    hit = _OUTPUT_RE.match(os.path.basename(os.path.normpath(outdir or "")))
    return hit.group(1) + hit.group(2) if hit else ""


_REPORT_STEMS = {"比對": "比對報告", "體檢": "體檢報告", "法規追蹤": "法規追蹤報告"}
# 改名前的報告檔名開頭（比對、法規追蹤都叫 檢視報告；體檢叫 體檢報告、沒接日期序號）
_LEGACY_REPORT_RE = re.compile(r"^(檢視報告|體檢報告)(.*)$")
# 指標檔：裡面寫的是產出資料夾的名字，資料夾改名後要跟著改
_POINTER_FILES = ("目前作業.json", "法規作業.json")


def _guess_kind(folder):
    """舊資料夾（名字沒有流程）是哪一條流程：體檢有 體檢.json、比對有規章清單留底、法規追蹤只有 法規分析/。
    認不出來回 ""（不改名）。"""
    system = os.path.join(folder, SYSTEM_DIR)
    if os.path.isfile(os.path.join(system, "輸入", "體檢.json")):
        return "體檢"
    if os.path.isfile(os.path.join(system, "輸入", "規章清單.csv")):
        return "比對"
    if os.path.isfile(os.path.join(system, "法規分析", "法規分析狀態.json")):
        return "法規追蹤"
    return ""


def _rename_reports(folder, kind, serial):
    """1_結果彙整/ 裡改名前的報告（檢視報告.xlsx、體檢報告_101500.xlsx）改成 比對報告_20261026003.xlsx 這種名字。
    開在 Excel 裡改不了的跳過、回傳在 problems。"""
    renamed, problems = [], []
    results = os.path.join(folder, "1_結果彙整")
    if not os.path.isdir(results):
        return renamed, problems
    stem = "%s_%s" % (_REPORT_STEMS[kind], serial)
    for name in sorted(os.listdir(results)):
        hit = _LEGACY_REPORT_RE.match(name)
        if not hit or name.startswith("~$") or name.startswith(stem):
            continue
        target = os.path.join(results, stem + hit.group(2))
        if os.path.exists(target):
            continue
        try:
            os.rename(os.path.join(results, name), target)
            renamed.append((name, os.path.basename(target)))
        except OSError as exc:
            problems.append("%s/1_結果彙整/%s（%s）" % (os.path.basename(folder), name, exc.strerror or exc))
    return renamed, problems


def _replace_names(path, mapping):
    """純文字檔裡的舊資料夾名換成新的（只換完整的名字：產出20261023001 後面不能再接數字或 _）。"""
    try:
        with io.open(path, encoding="utf-8-sig" if path.endswith(".csv") else "utf-8", newline="") as f:
            text = f.read()
    except (OSError, UnicodeDecodeError):
        return False
    new = re.sub(r"產出\d{11}(?![\d_])", lambda m: mapping.get(m.group(0), m.group(0)), text)
    if new == text:
        return False
    with io.open(path, "w", encoding="utf-8-sig" if path.endswith(".csv") else "utf-8", newline="") as f:
        f.write(new)
    return True


def migrate_output_names(root):
    """v1.26.0：工作區裡舊的 產出YYYYMMDDNNN 加上流程名（產出20261023001_比對），裡面的報告改成
    比對報告_20261023001.xlsx 這種名字，指標檔（目前作業、法規作業、各輪的前一輪作業）跟著改。
    每次指令開始時跑一次（冪等：都改過就什麼都不做）。認不出流程、開著改不了的資料夾跳過，舊名字照樣認得。
    回傳 {"資料夾": [(舊, 新)], "報告": 幾份, "沒改": [說明]}。"""
    root = os.path.abspath(root)
    done = {"資料夾": [], "報告": 0, "沒改": []}
    try:
        names = sorted(os.listdir(root))
    except OSError:
        return done
    mapping = {}
    for name in names:
        hit = _OUTPUT_RE.match(name)
        folder = os.path.join(root, name)
        if not hit or not os.path.isdir(folder):
            continue
        kind = hit.group(3) or _guess_kind(folder)
        if not kind:
            continue
        if not hit.group(3):
            target = os.path.join(root, output_name(hit.group(1), int(hit.group(2)), kind))
            if os.path.exists(target):
                continue
            try:
                os.rename(folder, target)
            except OSError as exc:
                done["沒改"].append("%s（%s：裡面有檔案開著就改不了，關掉後下一次指令會再改）"
                                   % (name, exc.strerror or exc))
                continue
            mapping[name] = os.path.basename(target)
            done["資料夾"].append((name, mapping[name]))
            folder = target
        renamed, problems = _rename_reports(folder, kind, hit.group(1) + hit.group(2))
        done["報告"] += len(renamed)
        done["沒改"] += problems
    if mapping:
        pointers = [os.path.join(root, n) for n in _POINTER_FILES]
        pointers.append(os.path.join(root, IMPORT_DIR, "單位事實.csv"))
        for name in os.listdir(root):
            if _OUTPUT_RE.match(name):
                system = os.path.join(root, name, SYSTEM_DIR)
                pointers.append(os.path.join(system, PREVIOUS_OUTPUT_FILE))
                pointers.append(os.path.join(system, "語意候選", "交換包紀錄.json"))
        for path in pointers:
            if os.path.isfile(path):
                _replace_names(path, mapping)
    return done


def begin_output(root, date_text=None, kind="比對"):
    """開始一個新作業，建立 產出YYYYMMDDNNN_<流程> 並更新目前作業指標（kind：比對、體檢）。"""
    root = os.path.abspath(root)
    if _legacy_layout(root) or uses_prefix_layout(root):
        raise WorkspaceError("這是舊版工作區。先執行「建工作區」轉成 匯入/%s、匯入/%s 兩個資料夾後再開始新作業"
                             % (CURRENT_DIR, DRAFT_DIR))
    ensure_layout(root)
    previous = current_output(root)
    folder = make_output_dir(root, kind, date_text)
    _write_active_output(root, folder, previous)
    if previous:
        system = os.path.join(folder, SYSTEM_DIR)
        os.makedirs(system, exist_ok=True)
        with io.open(os.path.join(system, PREVIOUS_OUTPUT_FILE), "w", encoding="utf-8") as target:
            target.write(os.path.basename(previous) + "\n")
    _write_output_guide(folder)
    return folder


def paths(root, outdir=None):
    """回傳工作區固定資料與目前作業路徑；新版輸入檔都在同一個匯入資料夾。"""
    root = os.path.abspath(root)
    imported = os.path.join(root, IMPORT_DIR)
    if _legacy_layout(root):
        return {
            "根": root, "匯入": imported,
            "舊版": os.path.join(imported, LEGACY_OLD_DIR),
            "新版": os.path.join(imported, LEGACY_NEW_DIR),
            "規格包": os.path.join(imported, SPEC_DIR),
            "清單": os.path.join(imported, "規章清單.csv"),
            "產出": os.path.abspath(outdir) if outdir else os.path.join(root, OUTPUT_PREFIX),
        }
    current = os.path.abspath(outdir) if outdir else current_output(root)
    return {
        "根": root, "匯入": imported,
        "舊版": os.path.join(imported, CURRENT_DIR), "新版": os.path.join(imported, DRAFT_DIR),
        "規格包": os.path.join(imported, SPEC_DIR),
        "清單": os.path.join(imported, "規章清單.csv"),
        "產出": current,
    }


# 工作區每個資料夾裡的說明檔。讀規章時一律跳過這個檔名。
GUIDE_NAME = "（說明）這裡放什麼.txt"
GUIDES = {
    "根": (
        "這是 reg-report 的工作區。\n\n"
        "先執行「建工作區」，再把規章檔放進 匯入/ 底下的兩個資料夾：\n"
        "現行版放 匯入/%s/，修訂版放 匯入/%s/。\n"
        "檔名就是規章名，不用加任何前綴；同一本規章兩邊的檔名要一樣，例如都叫 業務手冊.docx。\n"
        "每次開始新一輪時，程式會建立 產出YYYYMMDDNNN_<流程>/；繼續同一輪不會換資料夾。\n" % (CURRENT_DIR, DRAFT_DIR)),
    "匯入": (
        "現行版放 %s/，修訂版放 %s/；這一層不要直接放規章檔。\n"
        "規章清單.csv 由「配對」寫在這一層；規格包放 規格包/<規章名>/。\n"
        % (CURRENT_DIR, DRAFT_DIR)),
    "現行": "現行版（目前有效的那一份）放這裡，檔名就是規章名，例如 業務手冊.docx。\n" + FORMAT_NOTE + "\n",
    "修訂": "修訂版（這次要改成的樣子）放這裡，檔名跟現行版同一本取一樣的名字，例如 業務手冊.docx。\n" + FORMAT_NOTE + "\n",
    "規格包": "有正式規格包的本放 規格包/<規章名>/，裡面要有 LATEST.json。\n",
}


def _write_output_guide(outdir):
    path = os.path.join(outdir, GUIDE_NAME)
    if not os.path.isfile(path):
        with io.open(path, "w", encoding="utf-8-sig", newline="\r\n") as target:
            target.write("這是本輪產出。報告在 1_結果彙整/，AI 表與過程紀錄在 2_Log檔案/。\n")


def ensure_layout(root):
    """建新工作區的固定結構；不建立產出，避免配對或繼續時誤開新一輪。
    舊版工作區（分類資料夾、檔名前綴）什麼都不動：那要「建工作區」遷移，不能在這裡默默改。"""
    root = os.path.abspath(root)
    if _legacy_layout(root) or uses_prefix_layout(root):
        return []
    p = paths(root)
    created = []
    for folder in (root, p["匯入"], p["舊版"], p["新版"], p["規格包"]):
        if not os.path.isdir(folder):
            os.makedirs(folder, exist_ok=True)
            created.append(folder)
    if not os.path.isfile(_layout_path(root)):
        _write_json_atomic(_layout_path(root), dict(LAYOUT_MARK))
    return created


def write_guides(root, refresh=False):
    """建立新版工作區的說明檔；不覆寫已有的檔案。
    refresh=True（遷移舊版工作區時）：說明檔是程式寫的，舊版寫著「檔名加 現行_」這種已經不對的話，換成新的。"""
    p = paths(root)
    ensure_layout(root)
    written = []
    folders = {"根": p["根"], "匯入": p["匯入"], "現行": p["舊版"], "修訂": p["新版"], "規格包": p["規格包"]}
    for key in ("根", "匯入", "現行", "修訂", "規格包"):
        folder = folders[key]
        if not os.path.isdir(folder):
            continue
        path = os.path.join(folder, GUIDE_NAME)
        if refresh or not os.path.isfile(path):
            with io.open(path, "w", encoding="utf-8-sig", newline="\r\n") as target:
                target.write(GUIDES[key])
            written.append(path)
    if p["產出"] and os.path.isdir(p["產出"]):
        _write_output_guide(p["產出"])
    return written


def format_hint(names):
    """這批檔裡有 .doc、PDF 時要加的那句話；沒有回 ""。"""
    return "。" + FORMAT_NOTE if re.search(r"\.(?:doc|pdf)(?![A-Za-z0-9])", "\n".join(names), re.I) else ""


def _input_files(folder):
    if not os.path.isdir(folder):
        return []
    return sorted(name for name in os.listdir(folder)
                  if name != GUIDE_NAME and not name.startswith("~$")
                  and os.path.isfile(os.path.join(folder, name)))


EXCLUDE_FILE = "排除的檔.json"


def _exclude_path(root):
    return os.path.join(paths(root)["匯入"], EXCLUDE_FILE)


def excluded_files(root):
    """人說這個工作區不比對的檔（相對 匯入/ 的路徑）。檔案本身留在原地：見 run_all.cmd_exclude。"""
    files = _read_json(_exclude_path(root)).get("檔")
    return [value for value in files if isinstance(value, str)] if isinstance(files, list) else []


def without_excluded(root, role, names):
    skip = set(_rel_key(value) for value in excluded_files(root))
    return [name for name in names if _rel_key(_role_rel(root, role, name)) not in skip] if skip else names


def set_excluded(root, values, cancel=False):
    """排除或恢復。只認兩個角色資料夾裡的檔名（或 資料夾/檔名），不解析路徑、不碰檔案：
    給什麼路徑都只取最後兩段，比到角色資料夾的檔才算，所以指不到別的地方。回傳改了的相對路徑。"""
    current = excluded_files(root)
    known = list(current)
    if not cancel:
        for role in (ROLE_CURRENT, ROLE_DRAFT):
            folder = paths(root)["舊版" if role == ROLE_CURRENT else "新版"]
            known += [_role_rel(root, role, name) for name in list_inputs(folder)[0]]
    changed = []
    for value in values:
        parts = (value or "").replace("\\", "/").split("/")
        name, folder = parts[-1], parts[-2] if len(parts) > 1 else ""
        hits = sorted(set(rel for rel in known
                          if (not folder or _rel_key(rel.split("/")[0]) == _rel_key(folder))
                          and _rel_key(name) in (_rel_key(rel.split("/")[-1]), _rel_key(_stem(rel.split("/")[-1])))))
        if not hits:
            old_dir, new_dir = role_dirs(root)
            raise WorkspaceError(("%s 不在排除清單裡" if cancel else "找不到 %s：只能排除 匯入/%s、匯入/%s 裡的規章檔")
                                 % ((value,) if cancel else (value, old_dir, new_dir)))
        if len(hits) > 1:
            raise WorkspaceError("%s 不只一個（%s）：寫 資料夾/檔名" % (value, "、".join(hits)))
        changed.append(hits[0])
    if cancel:
        drop = set(_rel_key(rel) for rel in changed)
        current = [rel for rel in current if _rel_key(rel) not in drop]
    else:
        current += [rel for rel in changed if rel not in current]
    _write_json_atomic(_exclude_path(root), {"格式版本": 1, "檔": current})
    return changed


def list_import_files(root):
    """掃描兩個角色資料夾，回傳（現行檔、修訂檔、需處理檔）。

    需處理檔：兩個資料夾裡不支援的副檔名（前面帶資料夾名），以及直接放在 匯入/ 最上層的
    規章檔（尾巴帶 UNSORTED_NOTE）。匯入/ 最上層本來就有的 規章清單.csv、遷移備份這些不算。"""
    p = paths(root)
    current, current_skipped = list_inputs(p["舊版"])
    draft, draft_skipped = list_inputs(p["新版"])
    current = without_excluded(root, ROLE_CURRENT, current)
    draft = without_excluded(root, ROLE_DRAFT, draft)
    skipped = (["%s/%s" % (CURRENT_DIR, name) for name in current_skipped]
               + ["%s/%s" % (DRAFT_DIR, name) for name in draft_skipped])
    for name in _input_files(p["匯入"]):
        if os.path.splitext(name)[1].lower() in SUPPORTED_EXTS:
            skipped.append(name + UNSORTED_NOTE)
    return current, draft, sorted(skipped)


def list_role_inputs(root, role):
    """某一個角色資料夾裡的規章檔名。role 用 ROLE_CURRENT／ROLE_DRAFT（舊呼叫端寫的
    CURRENT_PREFIX／DRAFT_PREFIX、「舊版」「新版」也認）。"""
    if role not in (ROLE_CURRENT, ROLE_DRAFT, CURRENT_PREFIX, DRAFT_PREFIX, "舊版", "新版"):
        raise WorkspaceError("不支援的匯入角色：%s" % role)
    is_current = role in (ROLE_CURRENT, CURRENT_PREFIX, "舊版")
    p = paths(root)
    return without_excluded(root, ROLE_CURRENT if is_current else ROLE_DRAFT,
                            list_inputs(p["舊版"] if is_current else p["新版"])[0])


def _role_rel(root, role, filename):
    """角色資料夾裡的一個檔，寫進規章清單的相對路徑（相對 匯入/）。"""
    old_dir, new_dir = role_dirs(root)
    folder = old_dir if role in (ROLE_CURRENT, CURRENT_PREFIX, "舊版") else new_dir
    return "%s/%s" % (folder, filename)


def _migrated_rel(value):
    """舊寫法的清單路徑 → 新寫法：「現行規章/甲.docx」「現行_甲.docx」→「1_現行文件/甲.docx」；
    不是舊寫法（已經是新寫法、或手動列指到 規格包/ 這種別處）回 None。"""
    value = (value or "").replace("\\", "/")
    for old_dir, folder in LEGACY_ROLE_DIRS:
        if value.startswith(old_dir + "/"):
            return "%s/%s" % (folder, value[len(old_dir) + 1:])
    if "/" not in value:
        for prefix, folder in ((CURRENT_PREFIX, CURRENT_DIR), (DRAFT_PREFIX, DRAFT_DIR)):
            if value.startswith(prefix) and len(value) > len(prefix):
                return "%s/%s" % (folder, value[len(prefix):])
    return None


def _rewrite_manifest(path):
    """規章清單的舊寫法路徑改成新寫法；有改才寫，改之前留一份 規章清單.csv.遷移前。"""
    if not os.path.isfile(path):
        return False
    rows = read_manifest_rows(path)
    changed = False
    for row in rows:
        for column in ("舊版", "新版草稿"):
            new_value = _migrated_rel(row.get(column))
            if new_value is not None:
                row[column] = new_value
                changed = True
    if not changed:
        return False
    backup = path + ".遷移前"
    if not os.path.exists(backup):
        shutil.copy2(path, backup)
    temp = path + ".tmp"
    write_manifest(rows, temp)
    replace_file(temp, path)
    return True


def _copy_into_roles(root, sources, mark):
    """sources：[(原檔完整路徑, 新的清單相對路徑)]。先全部檢查、再複製；任何衝突都不搬一半，
    複製到一半失敗就把已複製的收回。複製完改規章清單、寫新的工作區標記，回傳複製了幾份。"""
    imported = os.path.join(root, IMPORT_DIR)
    targets = [target for _source, target in sources]
    duplicated = sorted({target for target in targets if targets.count(target) > 1})
    if duplicated:
        raise WorkspaceError("同一個角色有同名規章，無法安全遷移：%s" % "、".join(duplicated))
    collisions = [target for target in targets if os.path.exists(os.path.join(imported, target))]
    if collisions:
        raise WorkspaceError("遷移目標已存在，未覆寫：%s" % "、".join(collisions))
    copied = []
    try:
        for source, target in sources:
            destination = os.path.join(imported, target)
            os.makedirs(os.path.dirname(destination), exist_ok=True)
            shutil.copy2(source, destination)
            copied.append(destination)
        _rewrite_manifest(os.path.join(imported, "規章清單.csv"))
        _write_json_atomic(_layout_path(root), dict(mark))
    except Exception:
        for destination in copied:
            try:
                os.remove(destination)
            except OSError:
                pass
        raise
    return len(copied)


def migrate_legacy(root):
    """更早的分類資料夾（現行規章／修訂規章、舊版／新版）安全複製進 1_現行文件／2_修訂文件；
    舊資料夾保留，不自動刪除。"""
    root = os.path.abspath(root)
    imported = os.path.join(root, IMPORT_DIR)
    legacy_dirs = [(os.path.join(imported, old_dir), folder)
                   for old_dir, folder in LEGACY_ROLE_DIRS
                   if os.path.isdir(os.path.join(imported, old_dir))]
    if not legacy_dirs:
        ensure_layout(root)
        return []
    sources, unsafe = [], []
    for source_dir, folder in legacy_dirs:
        for name in sorted(os.listdir(source_dir)):
            path = os.path.join(source_dir, name)
            if name == GUIDE_NAME or name == CACHE_DIR or not os.path.isfile(path):
                continue
            if os.path.splitext(name)[1].lower() not in SUPPORTED_EXTS:
                unsafe.append(os.path.join(os.path.basename(source_dir), name))
                continue
            sources.append((path, "%s/%s" % (folder, name)))
    if unsafe:
        raise WorkspaceError("舊分類資料夾有不支援檔案，未遷移：%s" % "、".join(unsafe))
    count = _copy_into_roles(root, sources, dict(LAYOUT_MARK, 由舊版遷移=True))
    notes = ["已複製 %d 個舊分類規章檔到 %s／%s；舊資料夾保留作備份" % (count, CURRENT_DIR, DRAFT_DIR)]
    if os.path.isfile(os.path.join(imported, "規章清單.csv.遷移前")):
        notes.append("規章清單已改成新的資料夾路徑；舊清單備份為 規章清單.csv.遷移前")
    return notes


def migrate_prefixes(root):
    """前一版（格式 2）放在 匯入/ 最上層的 現行_／修訂_ 檔，複製進 1_現行文件／2_修訂文件並拿掉前綴；
    原檔搬到 匯入/遷移前備份/（留在最上層的話，之後每次開始都會被當成沒放好的規章檔）。"""
    from _common import tw_now, tw_today
    root = os.path.abspath(root)
    imported = os.path.join(root, IMPORT_DIR)
    sources, unsafe = [], []
    for name in _input_files(imported):
        for prefix, folder in ((CURRENT_PREFIX, CURRENT_DIR), (DRAFT_PREFIX, DRAFT_DIR)):
            if name.startswith(prefix):
                if len(name) == len(prefix) or os.path.splitext(name)[1].lower() not in SUPPORTED_EXTS:
                    unsafe.append(name)
                else:
                    sources.append((os.path.join(imported, name), "%s/%s" % (folder, name[len(prefix):])))
                break
    if unsafe:
        raise WorkspaceError("匯入/ 有不支援的前綴檔，未遷移：%s" % "、".join(unsafe))
    count = _copy_into_roles(root, sources, dict(LAYOUT_MARK, 由檔名前綴遷移=True))
    if not count:
        return ["已轉成 %s／%s 兩個資料夾（原本沒有規章檔要搬）" % (CURRENT_DIR, DRAFT_DIR)]
    backup = os.path.join(imported, PREFIX_BACKUP_DIR)
    os.makedirs(backup, exist_ok=True)
    stuck = []
    for source, _target in sources:
        destination = os.path.join(backup, os.path.basename(source))
        try:
            if os.path.exists(destination):
                stem, ext = os.path.splitext(destination)
                destination = "%s（%s）%s" % (stem, tw_now().strftime("%Y%m%d%H%M%S"), ext)
            replace_file(source, destination)
        except OSError:
            stuck.append(os.path.basename(source))
    notes = ["已把 %d 個 現行_／修訂_ 檔複製到 %s／%s（拿掉前綴）；原檔搬到 匯入/%s/"
             % (count, CURRENT_DIR, DRAFT_DIR, PREFIX_BACKUP_DIR)]
    if stuck:
        notes.append("有 %d 個原檔搬不進備份資料夾（多半是開在 Word 裡）：%s——關掉後手動移走，"
                     "不然配對會說 匯入/ 最上層有沒放好的規章檔" % (len(stuck), "、".join(stuck)))
    if os.path.isfile(os.path.join(imported, "規章清單.csv.遷移前")):
        notes.append("規章清單已改成新的資料夾路徑；舊清單備份為 規章清單.csv.遷移前")
    return notes


def initialize(root):
    """「建工作區」動作：建立新結構；遇到舊版工作區（分類資料夾或檔名前綴）安全複製並遷移。"""
    root = os.path.abspath(root)
    migrated = True
    if _legacy_layout(root):
        notes = migrate_legacy(root)
    elif uses_prefix_layout(root):
        notes = migrate_prefixes(root)
    else:
        notes, migrated = [], False
    created = ensure_layout(root)
    if created:
        notes.append("已建立 %d 個工作區資料夾" % len(created))
    written = write_guides(root, refresh=migrated)
    if written:
        notes.append("已寫入 %d 份資料夾說明" % len(written))
    return notes


# ---------------------------------------------------------------------------
# 正規化與配對（規格第三節）
# ---------------------------------------------------------------------------

# 括號（含內容）：（）()［］[]【】
_BRACKET_RE = re.compile(r"[（(［\[【][^）)］\]】]*[）)］\]】]")
# 逐字套用（順序照規格：長詞在前，避免「修訂版」先被「修訂」吃掉一半）。
# item6：「新版本」「最新版」之前沒列在表裡，會先被子字串「新版」吃掉一半，
# 剩下「本」「最」沒去乾淨——「新版本」要整個當一個詞去掉，不能靠「新版」
# 順帶處理；同理「舊版本」「最新版」。
# 第四批：「修正後」「修訂後」「修改後」「對照」這種常見寫法以前只去掉「修正」兩個字，剩下「後」
# 配不上（甲要點_修正後.docx ↔ 甲要點.docx 變成未配對）；長詞一律排在短詞前面。
_VERSION_WORDS = ["新版本", "舊版本", "最新版", "舊版", "新版", "草稿", "草案",
                  "修正後", "修正前", "修訂後", "修訂前", "修改後", "修改前", "修正草案", "修訂草案",
                  "修訂版", "修訂", "修正版", "修正", "修改版", "修改", "定稿", "確定版", "核定版",
                  "乾淨版", "現行版", "現行", "最終版", "最終", "對照表", "版本"]
_V_NUM_RE = re.compile(r"v\d+(\.\d+)?", re.IGNORECASE)
_VER_NUM_RE = re.compile(r"ver\.?\d+", re.IGNORECASE)
_DI_VERSION_RE = re.compile(r"第\d+版")
_DATE_RE = re.compile(r"\d{6,8}")
_STRIP_CHARS = "_-.~～"


_LEADING_NUMBER_RE = re.compile(r"^\s*(\d{1,3})\s*[.．、_\-]\s*")


def _leading_number(name):
    match = _LEADING_NUMBER_RE.match(unicodedata.normalize("NFKC", name or ""))
    return match.group(1) if match else ""


def _strip_leading_number(stem):
    """「02.保險代理業務手冊_壹」→「保險代理業務手冊_壹」：檔名前面的冊次編號。"""
    return _LEADING_NUMBER_RE.sub("", stem or "", count=1).strip(_STRIP_CHARS)


def normalize_stem(name):
    """規格第三節 2.：NFKC、小寫、去空白、去括號及括號內文字、去版本字樣、去日期、去頭尾分隔符。"""
    s = unicodedata.normalize("NFKC", name or "")
    s = s.lower()
    s = re.sub(r"\s+", "", s)
    s = _BRACKET_RE.sub("", s)
    for word in _VERSION_WORDS:
        s = s.replace(word, "")
    s = _V_NUM_RE.sub("", s)
    s = _VER_NUM_RE.sub("", s)
    s = _DI_VERSION_RE.sub("", s)
    s = _DATE_RE.sub("", s)
    s = s.strip(_STRIP_CHARS)
    return s


def display_name(name):
    """給人看的規章名（對照表標題、公文）：尾巴的版本字（_修正後、現行版……）與分隔符拿掉，其餘照原樣
    （不像 normalize_stem 會轉小寫、去日期）。"""
    text = (name or "").strip()
    while True:
        stripped = text.rstrip("_-.～~ 　")
        word = next((w for w in _VERSION_WORDS if stripped.endswith(w) and len(stripped) > len(w)), None)
        if not word:
            return stripped
        text = stripped[:-len(word)]


# 引用比對用的日期：「1130501」「20240501」「113.05.01」「113年5月1日」
_CITE_DATE_RE = re.compile(r"[0-9０-９]{6,8}|[0-9０-９]{2,4}[.．/／\-－年][0-9０-９]{1,2}[.．/／\-－月][0-9０-９]{1,2}日?")


def citation_name(name):
    """別本引用比對用的名稱：去空白、去括號（含內容）、去日期與版本字、去頭尾分隔符，其餘照原字
    （不像 normalize_stem 會轉小寫、轉全半形——比對的對象是別本條文裡的原字）。

    規章名是舊版檔名（見 match），常帶「(現行)」「_1130501」這種字；別本引用寫的是正式名稱：
    「保險業務員招攬作業要點(現行)」「保險業務員招攬作業要點_1130501」→「保險業務員招攬作業要點」。"""
    text = re.sub(r"\s+", "", name or "")
    text = _BRACKET_RE.sub("", text)
    text = _CITE_DATE_RE.sub("", text)
    text = _V_NUM_RE.sub("", text)
    text = _VER_NUM_RE.sub("", text)
    text = _DI_VERSION_RE.sub("", text)
    while True:
        stripped = display_name(text.strip(_STRIP_CHARS + "　 "))
        if stripped == text:
            return text
        text = stripped


def _exact_key(stem):
    """規格第三節 1.：檔名完全相同，不含副檔名，忽略大小寫與全半形。"""
    return unicodedata.normalize("NFKC", stem).lower()


def _stem(filename):
    """去副檔名與角色前綴後的規章名稱。"""
    name = os.path.basename(filename or "")
    for prefix in (CURRENT_PREFIX, DRAFT_PREFIX):
        if name.startswith(prefix):
            name = name[len(prefix):]
            break
    return os.path.splitext(name)[0]


def list_inputs(folder):
    """回傳 (支援的輸入檔名, 略過的檔名)，兩份都排序過。

    支援的副檔名照 _common.SUPPORTED_EXTS（.docx／.txt／.md）。
    子資料夾與 Word 的 `~$` 鎖定檔兩邊都不算：前者不是檔，後者是 Word 開著檔案
    時的暫存檔，使用者根本沒放過它，報「略過」只會嚇到人。

    為什麼要回傳「略過的」而不是安靜忽略（no 14）：使用者把十本丟進 匯入/，
    其中兩本是 .doc 或 .pdf，舊的 list_docx 直接跳過，畫面上就只寫「配對 8 本」。
    少掉的那兩本沒有任何一行提過，使用者要自己數才會發現。
    """
    if not os.path.isdir(folder):
        return [], []
    names = []
    skipped = []
    for entry in os.listdir(folder):
        if entry.startswith("~$") or entry == GUIDE_NAME:
            continue
        if not os.path.isfile(os.path.join(folder, entry)):
            continue
        if os.path.splitext(entry)[1].lower() in SUPPORTED_EXTS:
            names.append(entry)
        else:
            skipped.append(entry)
    return sorted(names), sorted(skipped)


def list_docx(folder):
    """list_inputs 的舊名，只回「支援的輸入檔名」那一半。

    名字留著是因為 match()／stale_reasons() 這些呼叫端只要檔名清單；
    要「略過了哪些」的呼叫端（配對 CLI）請直接用 list_inputs。
    """
    return list_inputs(folder)[0]


def list_spec_names(spec_folder):
    """規格包底下的規章名清單：資料夾名，且 LATEST.json 存在才算（規格第三節
    6.）。給「配對」CLI 在呼叫 match() 前篩 spec_names 用。"""
    if not os.path.isdir(spec_folder):
        return []
    names = []
    for entry in os.listdir(spec_folder):
        full = os.path.join(spec_folder, entry)
        if os.path.isdir(full) and os.path.isfile(os.path.join(full, "LATEST.json")):
            names.append(entry)
    return sorted(names)


def match(old_names, new_names, spec_names, old_dir="", new_dir=""):
    """配對舊版／新版檔名，回傳規章清單列。

    old_dir／new_dir：兩邊檔名寫進清單時前面接的資料夾（相對 匯入/），呼叫端用 role_dirs(root) 給。

    spec_names 是規格包底下的資料夾名清單；呼叫端要先用 list_spec_names() 篩過
    「LATEST.json 存在才算」（規格第三節 6.），這裡只負責用資料夾名對規章名。

    裁定（寫進程式註解）：舊版有、新版沒有的列，「配對方式」欄留空、「備註」寫
    「沒改」；METHODS 驗證只對非空值（見 read_manifest_rows）。正規化後仍對到
    多個候選時（規格第三節 3.），同樣不配、配對方式留空，備註寫「多個候選：…」，
    對應的舊版候選各自留在「沒改」列，交給人手動改清單、把配對方式改成「手動」。
    """
    spec_set = set(spec_names or [])

    def _at(folder, name):
        return "%s/%s" % (folder, name) if folder else name

    def spec_root_rel(name):
        return "規格包/%s" % name if name in spec_set else ""

    old_stems = [_stem(n) for n in old_names]
    new_stems = [_stem(n) for n in new_names]
    old_file_by_stem = dict(zip(old_stems, old_names))
    new_file_by_stem = dict(zip(new_stems, new_names))

    # 第一階段：檔名完全相同（忽略大小寫與全半形）
    old_by_exact = {}
    for s in old_stems:
        old_by_exact.setdefault(_exact_key(s), []).append(s)
    new_by_exact = {}
    for s in new_stems:
        new_by_exact.setdefault(_exact_key(s), []).append(s)

    paired_old = set()
    paired_new = set()
    pair_method = {}  # old_stem -> (new_stem, 配對方式)

    for key, olds in old_by_exact.items():
        news = new_by_exact.get(key)
        if news and len(olds) == 1 and len(news) == 1:
            pair_method[olds[0]] = (news[0], "檔名相同")
            paired_old.add(olds[0])
            paired_new.add(news[0])

    # 第二階段：正規化去版本字
    remaining_old = [s for s in old_stems if s not in paired_old]
    remaining_new = [s for s in new_stems if s not in paired_new]

    old_by_norm = {}
    for s in remaining_old:
        old_by_norm.setdefault(normalize_stem(s), []).append(s)
    new_by_norm = {}
    for s in remaining_new:
        new_by_norm.setdefault(normalize_stem(s), []).append(s)

    ambiguous = {}  # new_stem -> [舊版候選 stem, ...]

    for norm_key, news in new_by_norm.items():
        if not norm_key:
            # 正規化後變空字串（檔名整個都是版本字，例如「新版.docx」「版本.docx」）
            # 沒有辨識力，不能拿來配對——不然任兩個「都只寫版本字」的檔名會被
            # 判成「去版本字」互相配對。讓它們照一般規則落到 未配對／沒改。
            continue
        olds = old_by_norm.get(norm_key, [])
        if len(olds) == 1 and len(news) == 1:
            pair_method[olds[0]] = (news[0], "去版本字")
            paired_old.add(olds[0])
            paired_new.add(news[0])
        elif olds:
            # 正規化後仍對到多個（不管是舊版還是新版那邊有超過一個候選）：不配。
            for n in news:
                ambiguous[n] = list(olds)
                paired_new.add(n)

    # 第三階段：連前面的編號也不看。手冊常在檔名前加冊次編號，改版時編號跟著重排
    # （實測現行「02.保險代理業務手冊_壹-法令遵循篇202511」、修訂「01.…壹-法令遵循篇20260623」），
    # 以前配不起來，整條流程卡在配對。只有去掉編號後兩邊都剛好一個才配，備註寫清楚。
    notes = {}
    left_old = [s for s in old_stems if s not in paired_old]
    left_new = [s for s in new_stems if s not in paired_new]
    old_by_bare, new_by_bare = {}, {}
    for s in left_old:
        old_by_bare.setdefault(_strip_leading_number(normalize_stem(s)), []).append(s)
    for s in left_new:
        new_by_bare.setdefault(_strip_leading_number(normalize_stem(s)), []).append(s)
    for bare, news in new_by_bare.items():
        olds = old_by_bare.get(bare, [])
        if bare and len(olds) == 1 and len(news) == 1:
            pair_method[olds[0]] = (news[0], "去版本字")
            paired_old.add(olds[0])
            paired_new.add(news[0])
            notes[olds[0]] = "前面的編號不同（%s／%s），當成同一本" % (
                _leading_number(olds[0]) or "無", _leading_number(news[0]) or "無")

    rows = []
    for old_stem in sorted(old_stems):
        old_file = old_file_by_stem[old_stem]
        release = spec_root_rel(old_stem)
        if old_stem in pair_method:
            new_stem, method = pair_method[old_stem]
            rows.append({"規章名": old_stem,
                         "舊版": _at(old_dir, old_file),
                         "新版草稿": _at(new_dir, new_file_by_stem[new_stem]),
                         "發布根目錄": release, "配對方式": method, "備註": notes.get(old_stem, "")})
        else:
            rows.append({"規章名": old_stem,
                         "舊版": _at(old_dir, old_file),
                         "新版草稿": "", "發布根目錄": release,
                         "配對方式": "", "備註": "沒改"})

    tail_new = []
    for new_stem in new_stems:
        if new_stem in paired_new and new_stem not in ambiguous:
            continue  # 已經配到舊版、併進上面的列了
        new_file = new_file_by_stem[new_stem]
        release = spec_root_rel(new_stem)
        if new_stem in ambiguous:
            note = "多個候選：" + "、".join(ambiguous[new_stem])
            tail_new.append({"規章名": new_stem, "舊版": "",
                             "新版草稿": _at(new_dir, new_file),
                             "發布根目錄": release, "配對方式": "", "備註": note})
        else:
            # v1.56.0：沒有對應的現行版＝新訂規章，不再要人先處理。規格包有同名資料夾表示以前發布過，
            # 多半其實有舊版：規格包比對要舊版才能跑，不帶，但把這件事寫進備註讓人看到
            tail_new.append({"規章名": new_stem, "舊版": "",
                             "新版草稿": _at(new_dir, new_file),
                             "發布根目錄": "", "配對方式": NEW_RULE,
                             "備註": "規格包有同名資料夾，確認是不是其實有舊版" if release else ""})
    tail_new.sort(key=lambda r: r["規章名"])
    rows.extend(tail_new)
    return rows


DRAFT_MISSING_NOTE = "草稿不存在，需人工"


def _rel_key(rel):
    """清單裡的相對路徑 → 比對用的鍵：normcase＋normpath，把大小寫、斜線方向、
    多餘的 ./ 這些寫法差異拉平，但**保留整段路徑**。

    no 13：這裡以前取的是 os.path.basename，只要檔名一樣就當成同一份檔。手動列
    的「舊版」可以指到 舊版/ 以外（例如 規格包/甲/甲.docx），這時 舊版/甲.docx
    會被誤判成「已經被那個手動列用掉」而整列刪掉；補孤兒那一段又因為 basename
    已經在 referenced_old 裡而不補回來——整本規章就這樣從清單消失，畫面上連一句
    話都沒有。用整段相對路徑當鍵，同名不同路徑就是兩份不同的檔。"""
    return os.path.normcase(os.path.normpath((rel or "").strip()))


def merge_manual(auto_rows, old_rows, root):
    """把既有清單裡「手動」列蓋回這次重新算出來的 auto_rows，回傳
    (rows, kept_names, dropped_names, draft_missing)。

    只有「配對方式＝手動」且 舊版 欄指到的檔還存在的列才沿用（保留人填的
    舊版／新版草稿／發布根目錄／備註，用 規章名 對回 auto_rows 同一列）；
    檔案不存在的手動列不沿用，回到這次自動配對的結果（呼叫端據此印
    「已改回自動配對」）。

    no 16：沿用前也要看「新版草稿」欄指到的檔還在不在——以前只檢查舊版，草稿被
    刪掉時整列原樣寫回去，然後「開始」才在過期檢查那一關擋下來（而且清單已經被
    重寫過一次，下次配對又原樣寫回，永遠卡在同一個錯）。草稿不見時這一列還是留著
    （人填的舊版、發布根目錄別浪費），但把「新版草稿」欄清空、備註改成
    「草稿不存在，需人工」，並把 (規章名, 原本的草稿路徑) 放進 draft_missing 交給
    呼叫端提醒；欄位清空之後重跑配對就不會再把那個不存在的路徑寫回去。

    手動列指定的舊版檔，若被 auto_rows 另一列（規章名不同）當成自己的舊版檔
    （多半是原本「多個候選」的候選之一，各自留了一條「沒改」列），合併後要
    把那一列整筆丟掉，不然同一個舊版檔會出現兩列。草稿那邊同理：手動列認領走的
    草稿，auto_rows 裡那條「未配對」列要丟掉（不然人明明配好了，畫面永遠寫
    「有 1 本要人處理」）；若那一列自己有舊版檔，就退回「沒改」而不是整列刪掉。

    反過來，手動列把規章名改指去別的舊版檔之後，原本那個規章名底下的舊檔
    會變成沒有任何一列引用——不能讓它悄悄從清單消失，合併完成後補成一條
    獨立的「沒改」列（見函式最後一段）。"""
    p = paths(root)
    manual_by_name = {}
    dropped_names = []
    draft_missing = []
    excluded = set(_rel_key(value) for value in excluded_files(root))
    for row in old_rows or []:
        if row.get("配對方式") != "手動":
            continue
        old_rel = row.get("舊版", "")
        if not (old_rel and os.path.isfile(os.path.join(p["匯入"], old_rel))) or _rel_key(old_rel) in excluded:
            dropped_names.append(row["規章名"])
            continue
        row = dict(row)
        new_rel = row.get("新版草稿", "")
        if new_rel and (not os.path.isfile(os.path.join(p["匯入"], new_rel)) or _rel_key(new_rel) in excluded):
            row["新版草稿"] = ""
            row["備註"] = DRAFT_MISSING_NOTE
            draft_missing.append((row["規章名"], new_rel))
        manual_by_name[row["規章名"]] = row

    used_old_files = set()
    used_new_files = set()
    for row in manual_by_name.values():
        if row.get("舊版"):
            used_old_files.add(_rel_key(row["舊版"]))
        if row.get("新版草稿"):
            used_new_files.add(_rel_key(row["新版草稿"]))

    rows = []
    seen_names = set()
    for row in auto_rows:
        name = row["規章名"]
        if name in manual_by_name:
            rows.append(dict(manual_by_name[name]))
            seen_names.add(name)
            continue
        old_rel = row.get("舊版", "")
        if old_rel and _rel_key(old_rel) in used_old_files:
            continue  # 這個舊版檔已經被某個手動列用掉，這一列不再獨立列出
        new_rel = row.get("新版草稿", "")
        if new_rel and _rel_key(new_rel) in used_new_files:
            if not old_rel:
                continue  # 純粹的「未配對」列，草稿已被手動列認領，整列丟掉
            row = dict(row)
            row["新版草稿"] = ""
            row["配對方式"] = ""
            row["備註"] = "沒改"
        rows.append(row)
        seen_names.add(name)

    kept_names = sorted(manual_by_name)
    for name, row in manual_by_name.items():
        if name not in seen_names:
            rows.append(dict(row))

    # item2：手動列把「規章名」改指去別的舊版檔之後，原本那個規章名底下的舊檔
    # （現在沒有任何一列的「舊版」指到它）會整個從清單消失——它可能是另一份
    # 還沒改的規章，不該悄悄不見。合併完成後，舊版/ 底下沒被任何一列引用到的
    # 檔，補成一列獨立的「沒改」；規章名先用檔名（去副檔名），跟既有規章名
    # 衝突就加 (2)(3)… 直到不衝突為止。
    referenced_old = set()
    for row in rows:
        old_rel = row.get("舊版", "")
        if old_rel:
            referenced_old.add(_rel_key(old_rel))
    existing_names = set(row["規章名"] for row in rows)
    for filename in list_role_inputs(root, ROLE_CURRENT):
        rel = _role_rel(root, ROLE_CURRENT, filename)
        if _rel_key(rel) in referenced_old:
            continue
        stem = _stem(filename)
        name = stem
        n = 2
        while name in existing_names:
            name = "%s(%d)" % (stem, n)
            n += 1
        existing_names.add(name)
        rows.append({"規章名": name, "舊版": rel, "新版草稿": "",
                    "發布根目錄": "", "配對方式": "", "備註": "沒改"})

    return rows, kept_names, sorted(dropped_names), sorted(draft_missing)


def is_new_rule(row):
    """清單這一列是不是新訂規章（沒有現行版、有修訂版）。"""
    return row.get("配對方式") == NEW_RULE and not row.get("舊版") and bool(row.get("新版草稿"))


# ---------------------------------------------------------------------------
# 清單讀寫
# ---------------------------------------------------------------------------

def write_manifest(rows, path):
    folder = os.path.dirname(path)
    if folder:
        os.makedirs(folder, exist_ok=True)
    with io.open(path, "w", encoding="utf-8-sig", newline="") as f:
        w = csv.DictWriter(f, fieldnames=MANIFEST_COLUMNS, quoting=csv.QUOTE_ALL)
        w.writeheader()
        for row in rows:
            w.writerow(dict((c, row.get(c, "")) for c in MANIFEST_COLUMNS))
    return path


def read_manifest_rows(path):
    """讀規章清單.csv；六欄缺一就 WorkspaceError。METHODS 驗證只對非空值（沒改的
    本、多個候選的本，配對方式本來就留空，不當錯誤）。"""
    if not os.path.isfile(path):
        raise WorkspaceError("找不到規章清單：%s" % path)
    from _common import open_csv
    with open_csv(path) as f:        # 人會用 Excel 確認、改清單，另存可能是 Big5
        reader = csv.DictReader(f)
        missing = [c for c in MANIFEST_COLUMNS if c not in (reader.fieldnames or [])]
        if missing:
            raise WorkspaceError("規章清單缺欄位：%s" % "、".join(missing))
        rows = list(reader)

    out = []
    for index, row in enumerate(rows, 2):
        item = dict((c, row.get(c) or "") for c in MANIFEST_COLUMNS)
        method = item["配對方式"]
        if method and method not in METHODS:
            raise WorkspaceError("第 %d 列配對方式不合法：%s" % (index, method))
        out.append(item)
    return out


# ---------------------------------------------------------------------------
# 過期檢查（規格第四節 2.）
# ---------------------------------------------------------------------------

def stale_reasons(rows, root):
    """清單與目前匯入檔是否一致：清單列的檔都在、兩個角色資料夾裡的檔都有列到。

    比對用 _rel_key（不分大小寫、斜線方向拉平）：清單寫 甲.txt、檔案是 甲.TXT 不算過期，
    不然手動列永遠判過期，每次「繼續」都重開一輪。手動列可以指到角色資料夾以外（例如
    規格包/甲/甲.docx），只要檔在就好。"""
    if uses_prefix_layout(root):
        return ["這是用檔名前綴的舊工作區：先跑「建工作區」轉成 匯入/%s、匯入/%s 兩個資料夾"
                % (CURRENT_DIR, DRAFT_DIR)]
    p = paths(root)
    reasons = []
    current_files = list_role_inputs(root, ROLE_CURRENT)
    draft_files = list_role_inputs(root, ROLE_DRAFT)
    current_rel = dict((_rel_key(_role_rel(root, ROLE_CURRENT, name)), _role_rel(root, ROLE_CURRENT, name))
                       for name in current_files)
    draft_rel = dict((_rel_key(_role_rel(root, ROLE_DRAFT, name)), _role_rel(root, ROLE_DRAFT, name))
                     for name in draft_files)
    if not _legacy_layout(root):
        unsorted = [value for value in list_import_files(root)[2] if value.endswith(UNSORTED_NOTE)]
        if unsorted:
            reasons.append("匯入/ 最上層有規章檔沒放進 %s 或 %s：%s"
                           % (CURRENT_DIR, DRAFT_DIR, "、".join(v[:-len(UNSORTED_NOTE)] for v in unsorted)))

    listed_current, listed_draft = set(), set()
    for row in rows:
        name = row["規章名"]
        old_rel = (row.get("舊版") or "").replace("\\", "/")
        new_rel = (row.get("新版草稿") or "").replace("\\", "/")
        if not old_rel and row.get("配對方式") == "未配對":
            # 舊版程式留下的清單：現在沒有現行版的本都當新訂，重新配對一次
            reasons.append("%s：之前沒配到現行版，重新配對（確定沒有現行版的當新訂）" % name)
        if old_rel:
            if not os.path.isfile(os.path.join(p["匯入"], old_rel)):
                reasons.append("%s：現行檔不存在（%s）" % (name, old_rel))
            listed_current.add(_rel_key(old_rel))
        if new_rel:
            if not os.path.isfile(os.path.join(p["匯入"], new_rel)):
                reasons.append("%s：修訂檔不存在（%s）" % (name, new_rel))
            listed_draft.add(_rel_key(new_rel))

    for key in sorted(set(current_rel) - listed_current):
        reasons.append("匯入/ 多出清單沒列的現行檔：%s" % current_rel[key])
    for key in sorted(set(draft_rel) - listed_draft):
        reasons.append("匯入/ 多出清單沒列的修訂檔：%s" % draft_rel[key])
    return reasons


# ---------------------------------------------------------------------------
# 歸檔（規格第四節 3.）
# ---------------------------------------------------------------------------

def history_root(base):
    """這一層的 歷次/ 在哪裡：<base>/2_Log檔案/歷次/。

    去向不是寫死在這裡的，是問 _common.home_of（FILE_HOMES 那張表登記了
    「歷次」→ 2_Log檔案）——改去向只改那一張表，這裡會跟著動。
    不建資料夾：_resolve_stamp 只是在找有沒有撞名，單純找路徑不該有副作用。
    """
    return os.path.join(base, home_of("歷次"), "歷次")


def _archive_plan(base, skip=()):
    """這一層有哪些東西要搬進 歷次/<stamp>/：[(來源絕對路徑, 目的地相對路徑), ...]。

    產出分三格之後，「上一輪的東西」不是一層平鋪的檔案，是 2_Log檔案／2_Log檔案／
    2_Log檔案 三個資料夾——所以整格搬，歷次/<stamp>/ 底下長得跟搬走之前一模一樣，
    人回頭翻上一輪時不用重新學一套排法。

    2_Log檔案 這一格例外：歷次/ 自己就住在裡面，整格搬會把歷次搬進自己。改成只搬
    它的內容（輸入/、異動清單.json…），歷次/ 留在原地，目的地照樣是
    歷次/<stamp>/2_Log檔案/<同名>。

    舊排法殘留在第一層的平鋪檔一樣收進來：不搬的話新舊兩輪會混在同一層，
    人分不出哪個檔是這一輪的。舊排法留在第一層的 歷次/ 則照舊不搬（搬了就是
    把上一輪的歸檔再歸檔一次）。
    """
    plan = []
    if not os.path.isdir(base):
        return plan
    skip = set(skip)
    system = SYSTEM_DIR
    for entry in sorted(os.listdir(base)):
        # 第一層跟規章名同名的資料夾是上一版的排法（產出/<規章名>/），不跳過：
        # 整包收進根層級的 歷次/，產出第一層才會只剩 1_結果彙整／2_Log檔案／2_Log檔案
        if entry == system or entry == "歷次" or entry == GUIDE_NAME:
            continue
        plan.append((os.path.join(base, entry), entry))
    system_dir = os.path.join(base, system)
    if os.path.isdir(system_dir):
        for entry in sorted(os.listdir(system_dir)):
            # 批次各本的過程檔住在 產出/2_Log檔案/<規章名>/，各本自己歸檔進自己的 歷次/，
            # 根層級不能把整本搬走
            if entry == "歷次" or entry in skip:
                continue
            plan.append((os.path.join(system_dir, entry), os.path.join(system, entry)))
    return plan


def _resolve_stamp(out_root, book_names, need_root, stamp):
    """回傳這次真正要用的時間戳：stamp 本身若會撞到既有的 歷次/<stamp>/（不管是
    某本的還是根層級的），依序試 stamp_2、stamp_3…直到所有這次真的要寫的目的地
    都還沒有人用過。只檢查這次真的要搬東西的本／根層級，避免「這次沒東西可搬」
    的呼叫被誤判成撞名（那樣會破壞冪等：見 archive_previous）。"""
    candidate = stamp
    n = 1
    while True:
        collision = need_root and os.path.isdir(os.path.join(history_root(out_root), candidate))
        if not collision:
            for name in book_names:
                if os.path.isdir(os.path.join(history_root(book_dir(out_root, name, legacy=False)),
                                              candidate)):
                    collision = True
                    break
        if not collision:
            return candidate
        n += 1
        candidate = "%s_%d" % (stamp, n)


def archive_previous(root, names, stamp=None):
    """產出/2_Log檔案/<名>/ 已有東西就整包搬到 產出/2_Log檔案/<名>/2_Log檔案/歷次/<stamp>/；
    產出/ 根層級（除了 2_Log檔案/ 裡的各本資料夾；上一版排法留在第一層的 產出/<名>/
    也算根層級，整包收走）搬到 產出/2_Log檔案/歷次/<stamp>/。回傳搬過的目的地。

    搬的單位是三格資料夾（見 _archive_plan）：2_Log檔案／2_Log檔案 整格搬，
    2_Log檔案 只搬內容（歷次/ 住在那一格裡，整格搬會搬進自己）。搬完那一格只剩
    歷次/。冪等：歷次/ 永遠被排除在「要搬的東西」之外；上一輪東西都搬光後再呼叫
    一次，兩層都沒有東西可搬，回傳 []（不做撞名檢查，不然會誤判出一個沒東西可搬
    的 stamp_2）。

    撞名（同一分鐘內兩次歸檔、或呼叫端自己重複用了同一個 stamp）：若這次真的要
    寫的 歷次/<stamp>/ 已經存在，整次呼叫改用 stamp_2、stamp_3…（本與根層級共用
    同一個解出來的時間戳），不覆蓋、不搬進既有的那份裡。

    item4：某個目的地檔案卡在 Excel 裡（Windows 鎖檔）時，shutil.move 會噴
    OSError。不接住的話會是一整條 traceback，使用者看不懂要做什麼。這裡接住、
    改丟 WorkspaceError，訊息附上「已經搬了幾處」——已經搬完的那幾處（moved
    這個 list 目前的長度）是真的搬走了，不是全部作廢；呼叫端（cmd_start／
    cmd_batch）印「[中止]」後 return 1，人關掉 Excel 再重跑即可，不用擔心
    重複搬（歸檔本身冪等，見上）。"""
    from _common import tw_now, tw_today
    stamp = stamp or tw_now().strftime("%Y%m%d_%H%M")
    p = paths(root)
    out_root = p["產出"]
    moved = []
    if not os.path.isdir(out_root):
        return moved

    name_set = set(names or [])
    book_plans = {}
    for name in names or []:
        plan = _archive_plan(book_dir(out_root, name, legacy=False))
        if plan:
            book_plans[name] = plan

    root_plan = _archive_plan(out_root, skip=name_set)

    if not book_plans and not root_plan:
        return moved

    # 先全部檢查一遍，有一個檔開著就一處都不搬（A10）。以前先搬各本、再搬根層：
    # 根層的合一表開在 Excel 時搬到一半才失敗，各本已經歸檔、合一表還在原地；
    # 人照提示存檔再跑，合一表被歸到另一格（_2），新一輪沿用的是第一格裡上一輪的決定——
    # 人剛填的「改」被無聲改回「不改」。
    busy = []
    for plan in list(book_plans.values()) + ([root_plan] if root_plan else []):
        for src, _ in plan:
            busy += _locked_files(src)
    if busy:
        raise WorkspaceError(
            "歸檔前檢查：有 %d 個檔開著（可能在 Excel），這次一處都沒搬：%s。關掉檔案（有改就先存檔）後重跑"
            % (len(busy), "、".join(os.path.relpath(b, out_root) for b in busy[:5])))

    stamp = _resolve_stamp(out_root, list(book_plans.keys()), bool(root_plan), stamp)

    def move_plan(base, plan):
        dest = os.path.join(history_root(base), stamp)
        os.makedirs(dest, exist_ok=True)
        for src, rel in plan:
            target = os.path.join(dest, rel)
            try:
                # rel 可能是「2_Log檔案/輸入」這種兩層的相對路徑（2_Log檔案 那一格是
                # 搬內容不是搬整格），目的地那一層要先建出來 shutil.move 才收得下。
                parent = os.path.dirname(target)
                if parent and not os.path.isdir(parent):
                    os.makedirs(parent, exist_ok=True)
                move_path(src, target)
            except OSError as exc:
                raise WorkspaceError(
                    "歸檔失敗：%s（可能有檔案開在 Excel）；已搬 %d 處到 %s，關掉檔案後重跑"
                    % (exc, len(moved), dest))
        moved.append(dest)

    for name, plan in book_plans.items():
        move_plan(book_dir(out_root, name, legacy=False), plan)

    if root_plan:
        move_plan(out_root, root_plan)
    return moved


def _locked_files(path):
    """path（檔或資料夾）底下開著、搬不動的檔。搬檔就是改名：改個名再改回來試試，
    Excel、Word 或別的程式握著的檔都會失敗。"""
    files = [path] if os.path.isfile(path) else [
        os.path.join(d, f) for d, _, fs in os.walk(path) for f in fs]
    busy = []
    for name in files:
        probe = name + ".歸檔檢查"
        try:
            rename_file(name, probe, QUICK_WAIT)
        except OSError:
            busy.append(name)
            continue
        try:
            rename_file(probe, name)
        except OSError:
            busy.append(name)
    return busy


# ---------------------------------------------------------------------------
# 摘要與畫面輸出
# ---------------------------------------------------------------------------

def summarize(rows, skipped=0):
    """「配對 N 本：檔名相同 a、去版本字 b、新訂 c、多個候選 e；沒改的本 d」。

    「多個候選」桶：備註以「多個候選」開頭的列（match() 對到多個候選時，配對方式
    留空、備註寫「多個候選：…」，不落在 counts 的任何一個配對方式桶）。

    skipped 非 0 時尾巴再加「；略過不支援的檔 N 個」——略過幾個檔不能只出現在
    上面那一則提醒裡，摘要這一行常常是唯一被複製貼走的一行（no 14）。"""
    counts = dict((m, 0) for m in ("檔名相同", "去版本字", NEW_RULE))
    no_change = 0
    multiple = 0
    for row in rows:
        method = row.get("配對方式", "")
        if method in counts:
            counts[method] += 1
        note = row.get("備註", "")
        if note == "沒改":
            no_change += 1
        elif note.startswith("多個候選"):
            multiple += 1
    text = ("配對 %d 本：檔名相同 %d、去版本字 %d、新訂 %d、多個候選 %d；沒改的本 %d"
            % (len(rows), counts["檔名相同"], counts["去版本字"], counts[NEW_RULE],
               multiple, no_change))
    if skipped:
        text += "；略過不支援的檔 %d 個" % skipped
    return text


def print_table(rows):
    """畫面印一張表（規章名｜現行版檔｜修訂版檔｜規格包｜配對方式）。"""
    header = ("規章名", "現行版檔", "修訂版檔", "規格包", "配對方式")
    print("｜".join(header))
    for row in rows:
        old_file = os.path.basename(row["舊版"]) if row["舊版"] else "（無）"
        new_file = os.path.basename(row["新版草稿"]) if row["新版草稿"] else "（無）"
        release = "有" if row["發布根目錄"] else "無"
        method = row["配對方式"] or ("備註：%s" % row["備註"] if row["備註"] else "（未定）")
        print("｜".join((row["規章名"], old_file, new_file, release, method)))
