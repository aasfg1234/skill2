# -*- coding: utf-8 -*-
"""
語意交換包：這台電腦算不了 BGE-M3，要到有模型的電腦算的時候，只帶一個檔來回。

以前要把整個工作區複製過去、再整個帶回來：工作區可能很大，而且整個帶回來會把這段時間
在這台填的決定表蓋掉。現在：

    這台   開始 把每一本的語意輸入打包成 產出/2_Log檔案/語意候選/語意交換包.zip
    那台   python scripts/semantic_candidates.py --交換包 "<語意交換包.zip>" --model "<模型資料夾>"
           算完把 <規章名>.csv 寫回同一個 zip（向量快取留在那台 skill 資料夾裡的 memoization/，下次沒改的段落不重算；重新解壓換版會清掉，只是要重算）
    這台   把 zip 放回原位（或直接放進 匯入/），跑 繼續（或 batch-semantic）：取出結果、逐本併入

zip 裡：交換包.json（輪次、參數、規章名）、<規章名>_語意輸入.json；算完多了 <規章名>.csv。
輪次依參數、作業目錄名與各本輸入內容計算；內容相同不重寫交換包，保留已算好的結果。
這台另記一份在 語意候選/交換包紀錄.json：輪次不同的包仍判成上一輪，提示拿本輪的包重算。
"""

import datetime
import hashlib
import io
import json
import os
import shutil
import sys
import zipfile
from file_replace import replace_file

HERE = os.path.dirname(os.path.abspath(__file__))
REG = os.path.dirname(HERE)
for _path in (HERE, os.path.join(HERE, "regdiff")):
    if _path not in sys.path:
        sys.path.insert(0, _path)

PACK_NAME = "語意交換包.zip"
MANIFEST = "交換包.json"
RECORD = "交換包紀錄.json"
INPUT_SUFFIX = "_語意輸入.json"
# 有模型的那台電腦上，向量快取的預設位置：那台 skill 資料夾的 memoization/（不跟著交換包走：快取只有算的那台用得到）
def _default_cache():
    import batch as bt
    return bt.cache_dir()


class ExchangeError(ValueError):
    pass


def _now():
    from _common import tw_now, tw_today
    return tw_now().strftime("%Y-%m-%d %H:%M")


def _output_name(folder):
    """語意候選資料夾所屬的日期作業目錄名稱；單本舊路徑回空字串。"""
    root = os.path.dirname(os.path.dirname(os.path.abspath(folder or "")))
    return os.path.basename(root)


def _safe_book_name(value):
    """交換包內的規章名只能是單一檔名片段，不能帶路徑或跳脫字元。"""
    if not isinstance(value, str):
        raise ExchangeError("交換包的規章名不是文字")
    name = value.strip()
    if (not name or name in (".", "..") or "/" in name or "\\" in name
            or os.path.isabs(name) or os.path.basename(name) != name):
        raise ExchangeError("交換包的規章名不安全：%r" % value)
    return name


def _safe_result_path(folder, name):
    name = _safe_book_name(name)
    base = os.path.abspath(folder)
    target = os.path.abspath(os.path.join(base, name + ".csv"))
    if os.path.dirname(target) != base:
        raise ExchangeError("交換包結果路徑不安全：%s" % name)
    return target


def pack(folder, params=None):
    """把 folder 裡每一個 <規章名>_語意輸入.json 打包成 folder/語意交換包.zip，回傳 zip 路徑
    （沒有任何輸入回 None）。params：這台設定的門檻、每處最多幾筆、粗篩、取前幾名、重排序，那台照這一份算。"""
    names = sorted(_safe_book_name(n[:-len(INPUT_SUFFIX)])
                   for n in os.listdir(folder) if n.endswith(INPUT_SUFFIX))
    if not names:
        return None
    from _common import stable_zip_info, write_generated
    inputs = {}
    for name in names:
        with open(os.path.join(folder, name + INPUT_SUFFIX), "rb") as f:
            inputs[name] = f.read()
    output = _output_name(folder)
    content = [params or {}, output, [(name, hashlib.sha256(inputs[name]).hexdigest()) for name in names]]
    round_id = hashlib.sha256(json.dumps(content, ensure_ascii=False, sort_keys=True).encode("utf-8")).hexdigest()[:32]
    record = {"輪次": round_id, "作業目錄": output, "規章": names}
    path = os.path.join(folder, PACK_NAME)
    if os.path.isfile(path):
        try:
            previous, _entries = read_manifest(path)
        except ExchangeError:
            pass
        else:
            if previous.get("輪次") == round_id:
                write_generated(os.path.join(folder, RECORD), record)
                return path
    manifest = dict(record, 版本=2, 打包=_now(), 參數=params or {})
    tmp = path + ".tmp"
    with zipfile.ZipFile(tmp, "w", zipfile.ZIP_DEFLATED) as z:
        z.writestr(stable_zip_info(MANIFEST, zipfile.ZIP_DEFLATED), json.dumps(manifest, ensure_ascii=False, indent=2))
        for name in names:
            z.writestr(stable_zip_info(name + INPUT_SUFFIX, zipfile.ZIP_DEFLATED), inputs[name])
    replace_file(tmp, path)
    write_generated(os.path.join(folder, RECORD), record)
    return path


def read_manifest(path):
    """回傳已驗證的交換包資訊；規章名含路徑時一律拒絕。"""
    try:
        with zipfile.ZipFile(path) as z:
            names = set(z.namelist())
            manifest = json.loads(z.read(MANIFEST).decode("utf-8"))
    except (OSError, KeyError, ValueError, zipfile.BadZipFile) as exc:
        raise ExchangeError("語意交換包讀不出來：%s（%s）" % (path, exc))
    if not isinstance(manifest, dict) or not isinstance(manifest.get("規章"), list):
        raise ExchangeError("交換包缺少規章清單")
    books = [_safe_book_name(name) for name in manifest["規章"]]
    if len(set(books)) != len(books):
        raise ExchangeError("交換包有重複規章名")
    manifest["規章"] = books
    output = manifest.get("作業目錄")
    if output not in (None, ""):
        _safe_book_name(str(output))
    return manifest, names


def _record(folder):
    path = os.path.join(folder, RECORD)
    if not os.path.isfile(path):
        return {}
    try:
        with io.open(path, encoding="utf-8") as f:
            return json.load(f)
    except (OSError, ValueError):
        return {}


def places(folder, workspace_root=None):
    """放回來的交換包可能在哪：原位（語意候選/），或工作區的 匯入/（瀏覽器下載常改名成
    「語意交換包 (1).zip」，開頭對得上就算）。"""
    found = [os.path.join(folder, PACK_NAME)]
    if workspace_root:
        imp = os.path.join(workspace_root, "匯入")
        if os.path.isdir(imp):
            found += [os.path.join(imp, n) for n in sorted(os.listdir(imp))
                      if n.startswith(os.path.splitext(PACK_NAME)[0]) and n.lower().endswith(".zip")]
    return [p for p in found if os.path.isfile(p)]


def returned(folder, workspace_root=None):
    """找已經算好（zip 裡有結果）、而且是這一輪的交換包：回傳 (路徑, 有結果的規章 list) 或 None。
    只找到上一輪算好的包 → ExchangeError（講清楚要拿這一輪的包重算）。"""
    record = _record(folder)
    current = record.get("輪次")
    current_output = record.get("作業目錄") or _output_name(folder)
    expected = set(record.get("規章") or [])
    stale = None
    for path in places(folder, workspace_root):
        manifest, names = read_manifest(path)
        done = [n for n in manifest.get("規章") or [] if n + ".csv" in names]
        if not done:
            continue
        if ((current and manifest.get("輪次") != current)
                or (manifest.get("作業目錄") and current_output
                    and manifest.get("作業目錄") != current_output)):
            stale = path
            continue
        # 輪次對得上才看規章：上一輪的包規章可能比這一輪多（期間拿掉了一本），要先判成「上一輪」，
        # 不然錯誤訊息講「含本輪沒有的規章」，人看不出是拿錯包、也不知道要拿這一輪的重算
        if expected and not set(manifest.get("規章") or []).issubset(expected):
            raise ExchangeError("交換包含本輪沒有的規章，不能併入：%s"
                                % "、".join(sorted(set(manifest.get("規章") or []) - expected)))
        return path, done
    if stale:
        raise ExchangeError("%s 是上一輪（重跑開始之前）的語意交換包，結果對不上這一輪；"
                            "請把這一輪的 %s 帶去有模型的電腦重算" % (stale, os.path.join(folder, PACK_NAME)))
    return None


def unpack(path, folder, names):
    """安全取出已算好的 CSV；不接受跳出語意候選資料夾的規章名。"""
    manifest, entries = read_manifest(path)
    allowed = set(manifest.get("規章") or [])
    requested = [_safe_book_name(name) for name in names]
    if any(name not in allowed for name in requested):
        raise ExchangeError("要求取出的規章不在交換包裡")
    os.makedirs(folder, exist_ok=True)
    with zipfile.ZipFile(path) as z:
        for name in requested:
            entry = name + ".csv"
            if entry not in entries:
                raise ExchangeError("交換包裡少了 %s" % entry)
            target = _safe_result_path(folder, name)
            temp = target + ".tmp"
            try:
                with open(temp, "wb") as output:
                    output.write(z.read(entry))
                replace_file(temp, target)
            except (OSError, KeyError) as exc:
                try:
                    os.remove(temp)
                except OSError:
                    pass
                raise ExchangeError("取出 %s 失敗：%s" % (entry, exc))
    home = os.path.join(folder, PACK_NAME)
    if os.path.normcase(os.path.abspath(path)) != os.path.normcase(os.path.abspath(home)):
        shutil.copy2(path, home)
        try:
            os.remove(path)
        except OSError:
            pass
    return requested


def _results_text(rows, draft_sha):
    import semantic_candidates as sc
    return sc.results_text(rows, draft_sha)


def compute(path, model, cache_dir=None, threshold=None, top=None, recall_top=None, say=print,
            rerank=None, rerank_model="", rerank_threshold=None):
    """有模型的那台：算交換包裡每一本，結果寫回同一個 zip。回傳離開代碼（0 成功、1 包有問題、2 載不起模型）。
    門檻、每處最多幾筆、粗篩沒給就照包裡記的（打包那台的設定），兩台算法才一致。"""
    import semantic_candidates as sc
    try:
        manifest, names = read_manifest(path)
    except ExchangeError as exc:
        say("[中止] %s" % exc)
        return 1
    params = manifest.get("參數") or {}
    threshold = threshold if threshold is not None else params.get("門檻")
    top = top if top is not None else (params.get("最多幾筆") or sc.DEFAULT_TOP)
    recall_top = recall_top if recall_top is not None else params.get("粗篩")
    rerank_top = params.get("取前幾名") or sc.RERANK_TOP
    batch = params.get("批次") or sc.DEFAULT_BATCH
    rerank = rerank if rerank is not None else bool(params.get("重排序"))
    rerank_threshold = rerank_threshold if rerank_threshold is not None else params.get("重排序門檻")
    inputs = []
    with zipfile.ZipFile(path) as z:
        for name in manifest.get("規章") or []:
            entry = name + INPUT_SUFFIX
            if entry not in names:
                say("[中止] 交換包裡少了 %s" % entry)
                return 1
            try:
                data = json.loads(z.read(entry).decode("utf-8-sig"))
            except (ValueError, zipfile.BadZipFile):
                say("[中止] 交換包裡的 %s 讀不出來：請拿原本那台電腦重新打包的交換包" % entry)
                return 1
            if not isinstance(data, dict) or data.get("格式版本") != 1 or "段落" not in data or "異動" not in data:
                say("[中止] 交換包裡的 %s 格式不對" % entry)
                return 1
            inputs.append((name, data))
    if cache_dir is None:
        cache_dir = _default_cache()
        try:
            os.makedirs(cache_dir, exist_ok=True)
        except OSError:
            cache_dir = None
    say("載入模型：%s" % model)
    scorer = sc.load_model(model, recall_top=recall_top, cache_dir=cache_dir, rerank_top=rerank_top,
                           batch_size=batch)
    if scorer is None:
        say("[跳過] 這個環境載不起 BGE-M3。請在有模型的電腦執行這支程式。")
        return 2
    sc.estimate_inputs(scorer, [data for _, data in inputs], say)
    used = threshold if threshold is not None else getattr(scorer, "default_threshold", sc.DEFAULT_THRESHOLD)
    reranker = None
    if rerank:
        # 打包那台開了重排序：這台也要重排，兩台算法才一致；找不到模型就停，不悄悄少做一步
        rerank_path = sc.find_local_model(rerank_model, sc.RERANKER_NAME)
        reranker = (sc.load_reranker(rerank_path, cache_dir, batch_size=params.get("重排序批次") or sc.RERANKER_BATCH)
                    if rerank_path else None)
        if reranker is None:
            say("[中止] 交換包要求重排序（設定.html 開了「語意重排序」），但這台電腦找不到或載不起 %s"
                % sc.RERANKER_NAME)
            return 2
        say("重排序：%s" % rerank_path)
    results = {}
    for name, data in inputs:
        try:
            rows = sc.find_candidates(scorer, data["異動"], data["段落"], threshold, top, data.get("目標規章", ""),
                                      reranker=reranker, rerank_threshold=rerank_threshold)
        except sc.SemanticError as exc:
            # 結果最後才一起寫回 zip：交換包原封不動，修好再算一次，或這一輪跑 語意併入 --略過
            say("[跳過] %s。交換包沒有改動；修好再算一次，或回原本那台跑 語意併入 --略過" % exc)
            return 2
        results[name] = _results_text(rows, data["草稿"]["SHA256"])
        say("%s：語意候選 %d 列（門檻 %.2f）" % (name, len(rows), used))
    manifest["算完"] = _now()
    tmp = path + ".tmp"
    with zipfile.ZipFile(path) as src, zipfile.ZipFile(tmp, "w", zipfile.ZIP_DEFLATED) as dst:
        dst.writestr(MANIFEST, json.dumps(manifest, ensure_ascii=False, indent=2))
        for item in src.infolist():
            replaced = item.filename.endswith(".csv") and item.filename[:-4] in results
            if item.filename == MANIFEST or replaced:
                continue
            dst.writestr(item, src.read(item.filename))
        for name, text in results.items():
            dst.writestr(name + ".csv", text.encode("utf-8-sig"))
    replace_file(tmp, path)
    cache = getattr(scorer, "cache", None)
    if cache is not None:
        say("向量快取：沿用 %d 個、新算 %d 個（%s）" % (cache.hits, cache.misses, cache.path))
    say("算完 %d 本，結果已寫回 %s。把這個檔帶回原本那台電腦，放回原位（或放進工作區的 匯入/），"
        "跑 繼續（或 語意併入）併入" % (len(inputs), path))
    return 0
