# -*- coding: utf-8 -*-
"""
單位事實表（v1.19.0）：工作區 匯入/單位事實.csv。

AI 判不了、要承辦回答的事（本行跟關係企業的證券公司算不算共同行銷、有沒有辦保費融資、要不要用 MID＋OTP……）：
AI 報告審查判「請人確認」的，程式自動加一列等回答；承辦把「回答」填上，下一輪三條流程（比對、體檢、法規追蹤）
的評分標準都附這幾條給 AI 照著判，不用每一輪重問。

放工作區、不放 skill 的 memoization：這是本單位的內部安排，skill 給別人用時不能帶出去。
"""

import csv
import datetime
import io
import os
import re
import unicodedata

from _common import open_csv, warn_read_failure
from file_replace import replace_file


class FactsReadError(ValueError):
    pass

FILE = "單位事實.csv"
HEADER = ["序號", "問題", "回答", "誰確認", "確認日期", "來源"]
_WORKSPACE = [""]            # 這一次執行用的工作區（run_all 開頭設；沒設＝不附單位事實）
# v1.51.0：CSV 第一列是給承辦看的說明（表頭在第二列）；讀的程式跳過它，舊檔沒有這一列照讀
NOTE_HEAD = "這份表怎麼填"
NOTE = (NOTE_HEAD + "：一列一題，只要在「回答」欄填 是、否 或說明（要寫誰確認、日期就填那兩欄）；"
        "第一列這句和第二列表頭不要改、不要刪。填好存檔，下一輪 AI 就照著判，不再重問。")
QUESTION_FORMAT = "請問本行是否…？（是／否／說明）"
_QUESTION_RE = re.compile(r"^請問本行是否.+[？?]\s*[（(]是[／/]否[／/]說明[）)]$", re.S)
_TWO_QUESTIONS_RE = re.compile(r"是否[^？?]*?(?:[；;]|、及)[^？?]*?是否")
# AI 自己的備忘不是要問承辦的本行業務事實（真實資料：單位事實.csv 一格多題、夾 AI 備忘）
_MEMO_RE = re.compile(r"備忘|前後不一|自我提醒|給自己")
_REVIEW_SOURCE_RE = re.compile(r"^AI報告審查\s+(\S+)\s*(.*)$", re.S)


def set_workspace(root):
    _WORKSPACE[0] = root or ""


def current_workspace():
    return _WORKSPACE[0]


def path(workspace):
    return os.path.join(workspace, "匯入", FILE)


def _skip_note(f):
    """檔案開頭那一列說明跳過（v1.51.0）；舊檔第一列就是表頭，退回開頭。回傳同一個 f。"""
    start = f.tell()
    first = f.readline()
    if not first.lstrip('﻿"\' \t').startswith(NOTE_HEAD):
        f.seek(start)
    return f


def _hard_problems(text):
    """絕對不能進單位事實的問句：夾 AI 備忘、一句問兩件事。回傳問題 list。"""
    text = (text or "").strip()
    found = []
    if _MEMO_RE.search(text):
        found.append("這是 AI 自己的備忘，不是要問承辦的本行業務事實，不要寫進單位事實（「備忘」「前後不一」這類自己處理掉）")
    if _TWO_QUESTIONS_RE.search(text) or len(re.findall(r"[？?]", text)) > 1:
        found.append("一列只能問一件事：拆成兩列，每列一個「是否」")
    return found


def question_problems(text):
    """AI 要問承辦的問句驗一遍（v1.51.0）：一題一列、格式限定 QUESTION_FORMAT、不准夾 AI 備忘。回傳問題 list，沒問題回 []。"""
    text = (text or "").strip()
    found = _hard_problems(text)
    if not _QUESTION_RE.match(text):
        found.append("問句要寫成「%s」：「%s」" % (QUESTION_FORMAT, text[:60]))
    return found


def report_source(source):
    """來源欄的寫法：「報告位置：產出…／頁／第 N 列」（v1.51.0）。report_review 給的「AI報告審查 <產出> <頁>／<位置>」
    換成這個樣子，承辦才找得到是報告哪一列問的；別的寫法照原樣。"""
    source = (source or "").strip()
    match = _REVIEW_SOURCE_RE.match(source)
    if not match:
        return source
    parts = [p.strip() for p in match.group(2).split("／") if p.strip()]
    if parts and parts[-1].isdigit():
        parts[-1] = "第 %s 列" % parts[-1]
    return "報告位置：" + "／".join([match.group(1)] + parts)


def read(workspace):
    """單位事實的列（問題空白的略過）。沒有這個檔回 []。"""
    if not workspace:
        return []
    target = path(workspace)
    if not os.path.isfile(target):
        return []
    try:
        with open_csv(target) as f:
            rows = list(csv.DictReader(_skip_note(f)))
    except (OSError, ValueError, csv.Error) as exc:
        warn_read_failure(target, exc, "單位事實讀不出來，無法取得承辦回答；本次不新增問題、不覆寫原檔", "單位事實")
        raise FactsReadError("%s 讀不出來，請關閉 Excel 或另存成 CSV UTF-8 後重跑" % target) from exc
    return [r for r in rows if (r.get("問題") or "").strip()]


def _write(workspace, rows, extra=()):
    """寫回單位事實表。v1.45.0：先寫暫存檔再換掉（寫到一半失敗不會把原檔截斷）；extra＝承辦自己加的欄，照樣留著。"""
    target = path(workspace)
    os.makedirs(os.path.dirname(target), exist_ok=True)
    header = HEADER + [c for c in extra if c and c not in HEADER]
    tmp = target + ".tmp"
    with io.open(tmp, "w", encoding="utf-8-sig", newline="") as f:
        writer = csv.writer(f, quoting=csv.QUOTE_ALL)
        writer.writerow([NOTE])
        writer.writerow(header)
        number = 0
        for row in rows:
            if (row.get("問題") or "").strip():
                number += 1
                first = str(number)
            else:
                first = (row.get("序號") or "").strip()      # 問題空白、但有寫別的欄的列：原樣留著、不編號
            writer.writerow([first] + [(row.get(c) or "").strip() for c in header[1:]])
    replace_file(tmp, target)


def _read_all(workspace):
    """整張表（含問題空白的列、承辦自己加的欄）：(列, 表頭)。改一列再寫回時用，不能只寫 read() 回的那些。"""
    target = path(workspace)
    if not os.path.isfile(target):
        return [], list(HEADER)
    read(workspace)                        # 讀不出來照 read() 的規矩報錯
    with open_csv(target) as f:
        reader = csv.DictReader(_skip_note(f))
        rows = [r for r in reader if any(isinstance(v, str) and v.strip() for k, v in r.items() if k and k != "序號")]
        return rows, list(reader.fieldnames or HEADER)


def add_questions(workspace, questions):
    """questions＝[(問題, 來源)]；同一個問題已經有就不再加。回傳加了幾列。
    v1.51.0：夾 AI 備忘、一句問兩件事的不收（照樣提醒）；來源換成「報告位置：…」。"""
    if not workspace or not os.path.isdir(os.path.join(workspace, "匯入")):
        return 0
    try:
        rows, fields = _read_all(workspace)
    except FactsReadError:
        return 0
    known = set((r.get("問題") or "").strip() for r in rows)
    added = 0
    for question, source in questions:
        question = (question or "").strip()
        problems = _hard_problems(question)
        if problems:
            import notices as nt
            nt.notice(nt.WARNING, "單位事實沒收這一題（%s）：%s" % ("；".join(problems), question[:60]), "單位事實")
            continue
        if question and question not in known:
            rows.append({"問題": question, "回答": "", "誰確認": "", "確認日期": "", "來源": report_source(source)})
            known.add(question)
            added += 1
    if added:
        _write(workspace, rows, fields)
    return added


def record_answer(workspace, question, answer, who="使用者（對話中回答）", source="AI 對話"):
    """v1.45.0：使用者在對話裡回答的單位事實存下來（同一個問題就改回答）。回傳「新增」「更新」「沒變」。
    以前 AI 問了「是不是銀行兼營保險代理」、使用者答了，只在那一次對話有用，下一輪、下一條流程又問一次。"""
    question, answer = (question or "").strip(), (answer or "").strip()
    if not question or not answer:
        raise ValueError("問題、回答都要有字")
    rows, fields = _read_all(workspace)
    number = re.fullmatch(r"(?:#|序號\s*)?(-?\d+)", question)
    if number:
        wanted = int(number.group(1))
        matches = [r for r in rows if (r.get("序號") or "").strip() == str(wanted)
                   and (r.get("問題") or "").strip()]
        if wanted <= 0 or not matches:
            raise ValueError("沒有序號 %d" % wanted)
        candidates = matches[:1]
    else:
        def normalized(text):
            text = unicodedata.normalize("NFKC", text)
            return "".join(c for c in text if not c.isspace() and not unicodedata.category(c).startswith("P"))
        candidates = [r for r in rows if (r.get("問題") or "").strip()
                      and normalized(r["問題"]) == normalized(question)]
    for row in candidates:
        if (row.get("回答") or "").strip() == answer:
            return "沒變"
        row.update({"回答": answer, "誰確認": who, "確認日期": today()})
        _write(workspace, rows, fields)
        return "更新"
    rows.append({"問題": question, "回答": answer, "誰確認": who, "確認日期": today(), "來源": source})
    _write(workspace, rows, fields)
    return "新增"


PROFILE_WORDS = ("機構類型", "單位類型", "業務範圍", "業務類型", "兼營", "主體")


def profile_fact(workspace=None):
    """v1.60.10：承辦在對話裡回答過單位類型或業務範圍（記事實）的那一題，回「問題：回答」；沒有回 ""。
    模擬時用記事實存了「銀行兼營保險代理」，設定頁還是空白，程式一直提醒「單位類型空白」，評分標準也寫「空白就是還不知道」。"""
    try:
        rows = answered(workspace if workspace is not None else current_workspace())
    except FactsReadError:
        return ""
    for row in rows:
        question = row.get("問題") or ""
        if any(word in question for word in PROFILE_WORDS):
            return "%s：%s" % (question.strip(), (row.get("回答") or "").strip())
    return ""


def answered(workspace):
    return [r for r in read(workspace) if (r.get("回答") or "").strip()]


def pending(workspace):
    return [r for r in read(workspace) if not (r.get("回答") or "").strip()]


def lines(workspace=None):
    """附給 AI 的那一段（評分標準、先讀我）。沒有回答過的事實回 []。"""
    workspace = workspace if workspace is not None else current_workspace()
    try:
        facts = answered(workspace)
    except FactsReadError:
        return ["**單位事實.csv 這一輪讀不出來**：沒有可用的承辦回答事實；要看單位事實才能判的，"
                "照「待確認」處理，不要自己假設。"]
    if not facts:
        return []
    out = ["**本單位已確認的事實**（工作區 匯入/%s，承辦回答過的；照這些判，不要再列成「請確認」）：" % FILE]
    for row in facts:
        who = "、".join(filter(None, [(row.get("誰確認") or "").strip(), (row.get("確認日期") or "").strip()]))
        out.append("- %s → %s%s" % (row["問題"].strip(), row["回答"].strip(), "（%s）" % who if who else ""))
    return out


def todo_line(workspace):
    """人工待辦「看報告時留意」那一行：有幾題等承辦回答。沒有回 ""。"""
    try:
        waiting = pending(workspace)
    except FactsReadError:
        return "匯入/單位事實.csv 讀不出來：請關閉 Excel，或另存成 CSV UTF-8 後重跑"
    if not waiting:
        return ""
    return ("有 %d 個問題要承辦回答（AI 判不了的本行業務事實）：打開 工作區/匯入/%s 填「回答」，"
            "下一輪 AI 就照著判，不再重問" % (len(waiting), FILE))


def today():
    from _common import tw_now, tw_today
    return tw_today().isoformat()
