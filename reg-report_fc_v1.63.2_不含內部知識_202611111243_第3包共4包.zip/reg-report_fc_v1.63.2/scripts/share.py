# -*- coding: utf-8 -*-
"""
打包分享（v1.20.0）：把這個 skill 打成一個 zip 給別人用。

skill 資料夾裡除了程式，還有越做越準累積的「內部知識」（本單位的 AI 判斷、判例、語意向量、內部規範……）。
**一定要先問使用者要不要包進去**：沒指定「--內部知識 含／不含」就不打包，只列出內部知識有哪些、多大，
AI 照這個用選擇框問使用者，再帶著使用者的選擇重跑。

不含內部知識時：內部的檔不放進 zip，設定.html 的分析單位基本資料、AI 單位資料建議、電腦資訊、工作區路徑回到預設。
這個包要能放心給外人，所以一律白名單：確定公開才包，判斷不了就不包；scripts/、references/ 只收程式清單列的檔，
清單讀不到、清單或程式包裡有不該有的檔，就停下來不打包（見 check_ready）。
pack 沒有預設值：一定要明講含或不含，開始時先印這次是哪一種、排除了什麼。
zip 放在 skill 資料夾旁邊的 分享/（不放在 skill 裡面，免得下一次打包把上一次的 zip 也包進去）。
"""

import datetime
import fnmatch
import io
import json
import os
import shutil
import tempfile
import zipfile

HERE = os.path.dirname(os.path.abspath(__file__))
SKILL = os.path.dirname(HERE)
OUT_FOLDER = "分享"
# 內部知識（相對 skill 資料夾，/ 分隔；* 可以配任何字）
INTERNAL = [
    ("memoization/內部知識/*", "越做越準累積的本單位知識：判例、判斷準則、錯漏字白名單、跨工作區的 AI 答案、報告審查經驗、套語、同義詞建議"),
    ("memoization/AI查證紀錄.json", "外部引用查證紀錄（理由會寫到手冊內容）"),
    ("memoization/語意向量.sqlite", "手冊段落的語意向量，和語意比對結果（含異動與候選段落全文）"),
    ("memoization/外部規章排除表.csv", "不是外部法規的名稱（含本單位手冊名稱）"),
    ("memoization/設定已問過.json", "本單位已確認過設定（不含內部知識時設定會重設，收到的人要再問一次）"),
    ("memoization/資料庫快取/*", "規範資料庫讀出的文字（含內部規範）"),
    ("memoization/法規追蹤/適用判斷.json", "法規適用判斷（理由寫到本單位）"),
    ("memoization/法規追蹤/重複公告.json", "重複公告紀錄（AI 判不適用的理由會寫到本單位業務範圍）"),
    ("memoization/法規追蹤/PDF文字/*", "公告附件與使用者補入的 PDF 轉出的文字（可能含非公開文件）"),
    ("memoization/法規追蹤/候選快取.json", "法規對到手冊的哪幾段"),
    ("memoization/法規追蹤/補查紀錄.json", "AI 上網補查紀錄（結果偶爾提到手冊段落）"),
    ("memoization/法規追蹤/[0-9a-f]*/*", "各工作區的法規已審查答案（含手冊段落原文）"),
    ("資料庫/內部規範/*", "使用者放的本行內部規範全文"),
    ("資料庫/轉文字/內部規範/*", "內部規範的圖片轉文字"),
    ("資料庫/目錄.csv", "規範資料庫目錄（列出內部規範名稱）"),
    ("資料庫/待轉文字.txt", "待轉文字清單"),
]
# v1.22.0：memoization/ 改成「只有這幾樣算公開」，其他（含備份檔 .bak、-journal、某某備份、「- 複製」）一律算內部。
# 以前是列出哪些算內部，清單外的檔（S8 外部規章表裡的「本行內規」名稱、備份檔）不含內部知識也照包。
# 2026-11-05：重複公告（理由寫到本單位業務範圍）、PDF文字（使用者補入的 PDF 也存這裡）不算公開了。
# 法規追蹤/網頁快取/ 另外照索引逐檔判（見 _public_web），不在這個清單上
PUBLIC_MEMO = [
    "memoization/法規追蹤/法規版本表.json",       # 法規最新修正日（公開資料）
    "memoization/S8_外部規章表.csv",              # 外部法規名稱；「本行內規」那幾列打包時拿掉（見 _public_s8）
]
OTHER_INTERNAL = "其他累積資料（AI 答案、快取、備份檔等）"
WEB_CACHE = "memoization/法規追蹤/網頁快取/"
WEB_INDEX = WEB_CACHE + "索引.json"
WEB_UNOFFICIAL = "網頁快取裡證明不了是官方來源的檔（本機放進去的、索引對不上的、非官方網址）"
S8 = "memoization/S8_外部規章表.csv"
INTERNAL_CATEGORY = "本行內規"
# v1.51.0：不含內部知識時 skill 根目錄和 資料庫/ 也改白名單（以前是黑名單：使用者在根目錄放備忘、
# 在 資料庫/ 另開資料夾放內規草案，不含內部知識照包）。memoization/ 另外照 PUBLIC_MEMO
# 程式清單.json 列的檔都要在白名單上（preflight 少一個就擋下開始、繼續；test_v1510_seams 會查）
PROGRAM_LIST = "scripts/程式清單.json"
PROGRAM_ZIP = "隔離區/reg-report程式.zip"
PUBLIC_FILES = ("SKILL.md", "requirements.txt", "設定.html", "打開設定.cmd", "執行下一步.cmd", PROGRAM_ZIP, "隔離區/啟動.py",
                "資料庫/（說明）怎麼放.txt", PROGRAM_LIST)
PUBLIC_FOLDERS = ("memoization/", "資料庫/外部規範/", "資料庫/轉文字/外部規範/")
# 2026-11-05：scripts/、references/ 不再整個資料夾算公開（放進去的備忘、草稿會進包）：要列在程式清單上。
# 副檔名再擋一層：更新程式清單 是掃整個資料夾的，放進 scripts/ 的備忘下一次就進清單了
PROGRAM_FOLDERS = (("scripts/", (".py", ".ps1")), ("references/", (".md",)))
SHOW_UNLISTED = 20
SKIP = ("__pycache__", ".tmp", "~$")
SETTINGS_RESET = {"法規機構類型": "", "法規業務範圍": "", "法規追蹤主題": "保險,洗錢,個人資料,資訊安全", "工作區根目錄": "",
                  "語意模型路徑": "", "重排序模型路徑": "", "法規資料庫": []}   # v1.22.0：模型路徑會帶電腦使用者名稱、自訂資料庫可能是內網
DROP_KEYS = ("單位資料建議", "電腦資訊", "同義詞建議", "同義詞已拒絕", "語意本機狀態")
MACHINE_KEYS = ("語意本機狀態",)       # 只跟這台電腦有關，含內部知識的包也不帶（對方電腦不是這一台）


class ShareError(ValueError):
    """沒指定含不含，或不含內部知識的包沒辦法確定乾淨：寧可不打包。"""


def _files():
    for folder, dirs, names in os.walk(SKILL):
        dirs[:] = [d for d in dirs if d != "_請求" and not any(d.startswith(s) or d == s for s in SKIP)]
        for name in names:
            if name.endswith(".tmp") or name.startswith("~$"):
                continue
            path = os.path.join(folder, name)
            yield os.path.relpath(path, SKILL).replace(os.sep, "/"), path


def _public_web():
    """網頁快取裡可以公開的部分：{網址: 檔名}。

    程式只會把官方網址抓到的東西存進來（law_sources.fetch 擋掉其他網址），但這個資料夾擋不住別的來路：
    手動放進去的檔、備份資料夾、合併累積資料帶來的索引。所以逐筆核對：網址是官方來源、檔名是程式照網址算的、檔案在。
    索引讀不出來就回空的（證明不了就不包）。檔案內容沒辦法驗，被整個換掉抓不到。"""
    import law_sources as ls
    try:
        with io.open(os.path.join(SKILL, *WEB_INDEX.split("/")), encoding="utf-8") as f:
            index = json.load(f)
    except (OSError, ValueError):
        return {}

    def provable(url, name):
        try:
            return ls.official_source(url) and name == ls.digest(url.encode("utf-8"))[:32] + ".bin"
        except ValueError:                   # 網址本身是壞的
            return False
    if not isinstance(index, dict):
        return {}
    return {url: name for url, name in index.items()
            if provable(url, name) and os.path.isfile(os.path.join(SKILL, *(WEB_CACHE + name).split("/")))}


def internal_reason(rel, web=None):
    """這個檔算不算內部（回傳說明；公開回 ""）。memoization/ 底下不在 PUBLIC_MEMO 的一律算內部。
    web：_public_web() 的結果（一輪裡很多檔要問，算一次帶進來）。"""
    for pattern, reason in INTERNAL:
        if fnmatch.fnmatch(rel, pattern):
            return reason
    for pattern, reason in INTERNAL:
        # 備份、改名的變體（AI查證紀錄.json.bak、語意向量.sqlite-journal、目錄.csv 的備份）跟原檔同一類
        if "*" not in pattern and rel.startswith(pattern):
            return reason
    if rel.startswith(WEB_CACHE):
        names = (_public_web() if web is None else web).values()
        return "" if rel == WEB_INDEX or rel[len(WEB_CACHE):] in names else WEB_UNOFFICIAL
    if rel.startswith("memoization/") and not any(fnmatch.fnmatch(rel, p) for p in PUBLIC_MEMO):
        return OTHER_INTERNAL
    return ""


def _program_list():
    """程式清單.json 列的檔；讀不到、格式不對回 None（分不出哪些是程式，不猜）。"""
    try:
        with io.open(os.path.join(SKILL, *PROGRAM_LIST.split("/")), encoding="utf-8-sig") as f:
            names = json.load(f)
    except (OSError, ValueError):
        return None
    if not isinstance(names, list) or not names or any(not isinstance(n, str) for n in names):
        return None
    return set(names)


def unlisted(rel, programs=None):
    """不在公開白名單上（不含內部知識時不包）。programs：_program_list() 的結果（算一次帶進來）。"""
    if rel in PUBLIC_FILES or rel.startswith(PUBLIC_FOLDERS):
        return False
    programs = _program_list() if programs is None else programs
    return not (programs and rel in programs
                and any(rel.startswith(folder) and rel.endswith(suffixes) for folder, suffixes in PROGRAM_FOLDERS))


def _strays(web, programs):
    """不是內部知識、也不在白名單上的檔（備忘、草稿、程式清單外的檔）。"""
    return sorted(rel for rel, _path in _files() if not internal_reason(rel, web) and unlisted(rel, programs))


def check_ready():
    """不含內部知識打包前的檢查，回傳程式清單。清單讀不到、清單列了不該給外人的檔、程式包裡有清單外的檔，
    都是分不清楚哪些能給：丟 ShareError，一個檔都不寫。程式包是整包進 zip 的，不看裡面就等於開後門。"""
    programs = _program_list()
    if not programs:
        raise ShareError("%s 讀不到或格式不對，分不出哪些是程式、哪些是內部檔，所以不打包。先跑 更新程式清單、打包程式" % PROGRAM_LIST)
    odd = sorted(n for n in programs if unlisted(n, programs))
    if odd:
        raise ShareError("程式清單列了不是程式或說明的檔：%s。不能給外人，所以不打包。請把這些檔搬出 skill 資料夾，"
                         "再跑 更新程式清單、打包程式" % "、".join(odd[:SHOW_UNLISTED]))
    path = os.path.join(SKILL, *PROGRAM_ZIP.split("/"))
    if os.path.isfile(path):
        try:
            with zipfile.ZipFile(path) as z:
                names = z.namelist()
        except (OSError, zipfile.BadZipFile) as exc:
            raise ShareError("%s 打不開（%s），看不到裡面有什麼，所以不打包。先跑 打包程式" % (PROGRAM_ZIP, exc)) from exc
        odd = sorted(n for n in names if n not in programs or unlisted(n, programs))
        if odd:
            raise ShareError("%s 裡有程式清單以外的檔：%s。不能給外人，所以不打包。先跑 打包程式 重做程式包"
                             % (PROGRAM_ZIP, "、".join(odd[:SHOW_UNLISTED])))
    return programs


def _public_s8(path):
    """S8 外部規章表拿掉「本行內規」那幾列（會寫出本單位手冊、甚至機構全名）。回傳過濾後的文字。"""
    import csv
    with io.open(path, encoding="utf-8-sig", newline="") as f:
        rows = list(csv.reader(f))
    out = io.StringIO()
    writer = csv.writer(out, lineterminator="\r\n")
    for i, row in enumerate(rows):
        if i and len(row) > 1 and row[1].strip() == INTERNAL_CATEGORY:
            continue
        writer.writerow(row)
    return "\ufeff" + out.getvalue()


def inventory(web=None):
    """內部知識有哪些：[(說明, 檔數, 大小 bytes)]（照 INTERNAL 的順序，沒有檔的不列）。"""
    web = _public_web() if web is None else web
    found = {}
    for rel, path in _files():
        reason = internal_reason(rel, web)
        if reason:
            count, size = found.get(reason, (0, 0))
            found[reason] = (count + 1, size + os.path.getsize(path))
    order = [reason for _p, reason in INTERNAL] + [OTHER_INTERNAL, WEB_UNOFFICIAL]
    return [(reason,) + found[reason] for reason in order if reason in found]


def _size(n):
    return "%.1f MB" % (n / 1024 / 1024) if n >= 1024 * 1024 else "%d KB" % max(1, n // 1024)


def _clean_settings(path):
    """不含內部知識：設定.html 的本單位資料回到預設（只動資料區塊）。"""
    import settings_server as ss
    text = io.open(path, encoding="utf-8-sig").read()
    match = ss._DATA_RE.search(text)
    data = json.loads(match.group(2)) if match else {}
    for key in DROP_KEYS:
        data.pop(key, None)
    data.setdefault("設定", {}).update(SETTINGS_RESET)
    ss.write_data(path, data)


def _drop_machine_keys(path):
    import settings_server as ss
    match = ss._DATA_RE.search(io.open(path, encoding="utf-8-sig").read())
    data = json.loads(match.group(2)) if match else {}
    if any(key in data for key in MACHINE_KEYS):
        ss.write_data(path, {key: value for key, value in data.items() if key not in MACHINE_KEYS})


def _plan_lines(include_internal, items, strays):
    """開始打包時印的：這次是哪一種、排除了什麼（AI 轉述、使用者看畫面都看得到）。"""
    files, size = sum(item[1] for item in items), sum(item[2] for item in items)
    if include_internal:
        return ["[打包分享] 這次打的是「含內部知識」的包：只能給本單位的人，不要給外人。"
                "%d 類內部知識（共 %d 個檔、%s）和清單外的檔 %d 個都會進包，設定頁的單位資料也照留"
                % (len(items), files, _size(size), len(strays))]
    return (["[打包分享] 這次打的是「不含內部知識」的包，可以給外人：排除 %d 類內部知識（共 %d 個檔、%s）、清單外的檔 %d 個"
             % (len(items), files, _size(size), len(strays))]
            + ["  - %s：%d 個檔、%s" % (reason, count, _size(bytes_)) for reason, count, bytes_ in items]
            + ["  另外：外部規章表的「本行內規」那幾列拿掉，設定頁的單位資料、路徑、自訂法規資料庫回到預設"])


def pack(include_internal, out_dir=None, say=print):
    """打包。include_internal：True 含內部知識、False 不含，一定要明講（沒有預設值）。回傳 zip 路徑。"""
    from _common import tw_now, tw_today
    if not isinstance(include_internal, bool):
        raise ShareError("沒指定含不含內部知識，不打包：先問使用者")
    programs = (_program_list() or set()) if include_internal else check_ready()
    web = _public_web()
    items = inventory(web)
    strays = _strays(web, programs)
    for line in _plan_lines(include_internal, items, strays):
        say(line)
    out_dir = out_dir or os.path.join(os.path.dirname(SKILL), OUT_FOLDER)
    os.makedirs(out_dir, exist_ok=True)
    name = "%s_%s內部知識_%s.zip" % (os.path.basename(SKILL), "含" if include_internal else "不含",
                                   tw_now().strftime("%Y%m%d%H%M"))
    target = os.path.join(out_dir, name)
    work = tempfile.mkdtemp(prefix="reg-share-")
    try:
        settings_copy = os.path.join(work, "設定.html")
        shutil.copy2(os.path.join(SKILL, "設定.html"), settings_copy)
        if not include_internal:
            _clean_settings(settings_copy)
        else:
            _drop_machine_keys(settings_copy)
        with zipfile.ZipFile(target, "w", zipfile.ZIP_DEFLATED) as z:
            for rel, path in _files():
                if not include_internal and (internal_reason(rel, web) or unlisted(rel, programs)):
                    continue
                if not include_internal and rel == S8:
                    z.writestr(os.path.basename(SKILL) + "/" + rel, _public_s8(path).encode("utf-8"))
                    continue
                if not include_internal and rel == WEB_INDEX:      # 非官方的網址本身也不能留在索引裡
                    z.writestr(os.path.basename(SKILL) + "/" + rel, json.dumps(web, ensure_ascii=False).encode("utf-8"))
                    continue
                source = settings_copy if rel == "設定.html" else path
                z.write(source, os.path.basename(SKILL) + "/" + rel)
    finally:
        shutil.rmtree(work, ignore_errors=True)
    if include_internal:
        say("已打包：%s（含內部知識，只能給本單位的人）" % target)
        return target
    say("已打包：%s（不含內部知識，略過 %d 個內部檔、%d 個清單外的檔，設定頁的單位資料回到預設）"
        % (target, sum(item[1] for item in items), len(strays)))
    if strays:
        say("沒包的：%s%s（不在分享白名單上，算內部；要給對方請另外傳）"
            % ("、".join(strays[:SHOW_UNLISTED]), " 等 %d 個" % len(strays) if len(strays) > SHOW_UNLISTED else ""))
    if any(rel.startswith(("scripts/", "references/")) for rel in strays):
        say("  scripts/、references/ 底下新寫的程式或說明要進包：先跑 更新程式清單、打包程式，再打包一次；"
            "不是程式的檔請搬出 skill 資料夾（留著會被 更新程式清單 列進去）")
    return target


def ask_lines():
    """還沒選含不含：印給 AI 照著問使用者的那幾行。"""
    web = _public_web()
    items = inventory(web)
    strays = _strays(web, _program_list() or set())
    lines = []
    try:
        check_ready()
    except ShareError as exc:
        # v1.54.0：先講，不要等使用者選了「不含」才發現打不了包
        lines.append("[打不了包] 選「不含」現在打不了包：%s。先處理好再問使用者" % exc)
    lines.append("[先問分享] 要不要把內部知識庫一起包進去？（這是本單位越做越準累積的資料，給別人用可能會外流）")
    if items:
        lines += ["  內部知識有："] + ["  - %s：%d 個檔、%s" % (reason, count, _size(size)) for reason, count, size in items]
    else:
        lines.append("  （目前沒有內部知識）")
    if strays:
        lines.append("  另外有 %d 個檔不在分享白名單上（備忘、草稿、程式清單外的檔）：選不含不會包，選含會一起包" % len(strays))
    lines += ["  另外：外部規章表裡的「本行內規」名稱、設定頁的分析單位基本資料、AI 單位資料建議、AI 同義詞建議、電腦資訊、"
              "工作區路徑、模型路徑、自訂法規資料庫也算本單位資料（選不含會拿掉、回到預設）；設定頁的同義詞表照包（比對用的詞組）",
              "  要包：加 --內部知識 含 再跑一次；不要包：加 --內部知識 不含 再跑一次"]
    return lines
